# AF3 layout and performance plan

## File ownership

| Area | Main files | Scope |
|---|---|---|
| Shared appearance | `Includes_Furniture.xml`, `Includes_Textures.xml`, `Includes_Colors.xml` | Clock and weather, focus plates, palette |
| Settings | `Includes_Settings.xml`, `Includes_SkinSettings_{Interface,Browsing,DetailsAndPlayback}.xml` | Settings chrome, navigation and individual entries |
| Layouts | `Includes_Layouts_{Navigation,Guide,Lists,Artwork}.xml` | Menus, PVR guide, text lists, artwork cards |
| Information | `Includes_Info_{Metadata,Header,Formats,Plot}.xml` | Display metadata, titles, format badges and descriptions |
| Playback | `Includes_OSD_{NextUp,Streams,Timeline,Controls}.xml` | Up Next, stream selection, seek and playback controls |

Register new include files in `1080i/Includes.xml`. Keep XML control IDs, action ordering, and localisation IDs stable when moving definitions.

## Layout direction

- Use landscape artwork for Continue Watching, posters for discovery, and a compact list for long episode runs. Apply the same lift, border and inset progress to shared artwork layouts before changing individual rows.
- Keep Search's current navigation. Use shared status and focus styles on the search controls and results.
- Keep playback text legible on bright frames. Reuse the same palette and focus treatment in AF3 playback panels and native dialogs.

See the [window audit](af3-window-audit.md) for the live findings and complete AF3 XML inventory.

## Remaining work

1. Recheck native library layouts with real library entries and review profile, music, game and PVR windows when the content is available.
2. Recheck time to the first populated widget when Continue Watching returns items after a cold start.

## Performance review

Tested Kodi 21.3 on Windows with widget waiting and hub preloading disabled. Cold runs started a new Kodi process with disk caches intact. Warm returns opened Settings and then returned to Home. Home timing ends when Kodi first reports the Home window. Skin load timing covers the log interval from font loading to skin ready.

| Check | Range | Median |
|---|---|---|
| Warm return to Home, five runs | 84–178 ms | 176 ms |
| Cached Continue Watching visible after warm return | 105–214 ms | 189 ms |
| Warm skin reload to skin ready, five runs | 735–1,039 ms | 753 ms |
| Cold process start to Home before startup cleanup, five runs | 3.56–4.44 s | 3.70 s |
| Cold process start to Home after startup cleanup, five runs | 3.61–3.72 s | 3.70 s |
| Cold skin load after cleanup, five runs | 430–459 ms | 438 ms |
| Cold Continue Watching request after cleanup, five runs | 1.00–1.27 s | 1.10 s |

Startup initializes the splash once. The 300 ms sleep now runs only when the PVR retry path is active. The five cold-start samples have the same median before and after this cleanup.

Continue Watching returned **No Results** after each cold start. The request log showed a completion about 1.49–1.67 s after Home XML loaded. Time to a populated widget remains unmeasured for that path. Preload, provider, and cache settings are unchanged.

## Live verification

- Kodi reloaded the split XML. All nine Skin Settings categories populated and native Settings retained the focus path from the category list to the controls.
- Home retained artwork focus and inset progress. Search retained its keyboard layout with the new field and clock. A temporary local high-contrast clip verified the seek bar, clock, transport buttons, and the darker lower scrim.
- Five warm reload samples after the refactor and playback contrast change were 364, 366, 375, 522 and 484 ms (422 ms mean). These timings overlap the original range and do not establish a speedup from splitting XML. Waiting for widgets was disabled and hub preloading was off for those samples.
- The performance measurements above use the installed configuration and existing user data. The earlier warm-reload baseline is retained for reference.
