# AF3 window audit

Reviewed all 138 AF3 window XML files as part of a 251-file XML parse. The live review covered representative windows and dialog states.

## Live findings

| Window family | Observation | Suggested change |
|---|---|---|
| Home and movie hub | Artwork uses the shared lift, outline and inset progress. The active menu tab uses a plain light pill. | Keep this as the reference for artwork focus and navigation. |
| Skin Settings and Kodi Settings | The clock capsule and content panels match. Settings has rounded focus pills, and the selected category remains visible while working inside the panel. | Use these settings controls as the reference for native text and list focus. |
| Add-on Browser, System Information, File Manager | Headers and panels match Settings. File Manager uses a rectangular highlight on file rows alongside the pill in the sidebar. | Apply the shared row focus to file lists while preserving selected-item markers and the two-pane layout. |
| Confirmation | The native confirmation still uses rectangular Yes and No focus controls and a large message area. | Reuse rounded action controls and test short and long messages before changing dialog geometry. Keep the default selection and button order. |
| Selection and context menu | Both use the shared dialog panel, with the older square focus rows. | Match the Settings focus shape, text inset, icon alignment, and title spacing. Keep selection checkmarks and context submenu affordances. |
| On-screen keyboard and Search | The keyboard has compact rectangular keys and a circular action focus. Search uses the charcoal field and the shared clock. | Match the keyboard input and accent treatment with Search. Keep key shapes compact to maintain clear spacing in the grid. |
| Weather | Forecast tiles and the shared header render. The header repeats the current temperature already present on the first tile and the location and attribution line can truncate. | Consider clock-only status on Weather. Give attribution its own quieter line so it has room. |
| Playback | The seek bar and clock were checked over a temporary bright-and-dark clip in the preceding pass. | Bring the stream and chapter panels into the same style when testing with media that exposes those controls. |

The library window opened, but this review did not exercise every library layout. PVR has no configured TV or radio channels on this Kodi installation. Game, music playback, profile/login, companion add-on windows, and specialised player states were checked in the XML inventory. Their appearance needs live checks with the relevant content or device.

## Focus style follow-up

- **Skin Settings → Appearance → Focus style** now exposes Solid and Outlined directly. Both use the same rounded shape for Settings controls, dialog actions, selection rows, context menus, File Manager rows, and Search suggestions. The outline uses light foreground text and icons on the dark interior.
- Checked the setting switch in Kodi and opened confirmation, selection, and context menus in both modes. Confirmation still defaults to **No**. Checked File Manager in Outlined mode.
- The inventory below was captured before this follow-up. Native library, utility, and modal windows also use AF3's older focus-aware includes. Artwork cards, the active menu tab, keyboard keys, and specialised playback controls keep their respective focus cues.

## Keyboard, Weather, details and playback follow-up

- Opened the keyboard and Weather in Kodi and checked the shared input treatment and the revised forecast header.
- Opened movie, show and episode information with test media tags. Verified navigation between the action buttons and checked an episode without an air date.
- Rendered the shared basic and expanded list layouts in a temporary AF3 window with test items because Kodi's native video library was empty.
- Switched audio and subtitles on a local test clip with two tracks of each type and selected its middle chapter in the chapter panel. Kodi reported the selected tracks and chapter.

## Refactor cleanup

- Parsed all 251 skin XML files and verified that the split Settings, information, layouts and OSD files still register their original definitions.
- Removed the unused focus includes, retired setting labels and superseded fonts. Reset the saved Tab Icons, Progress Style and Indicator Style settings through Kodi.
- The AF3 theme selector preserves the selected font. Kodi's own Interface theme selector can reset the font when changing texture packs.
- Opened Profile Settings, Music and Games in Kodi. The focused fallback icons in the Music and Games grids were dim. Kodi's native video and music libraries were empty, the Games screen had no configured games, and the PVR API returned no usable channel list.
- After a skin reload, checked that the expanded episode rows use matching thumbnail corners with and without focus. Verified single-line Audio and Subtitles rows in playback and confirmed that the plot and end time disappear while the stream panels are open. Long labels can truncate in the single-line layout.

## Static inventory

The table records whether the window can reach an explicit shared include by following literal include names. Conditional references can be inactive, and a dynamic layout parameter can resolve to shared styling even where the table shows a dash.

| AF3 window | Shared clock | Dialog panel | Settings focus plate |
|---|---|---|---|
| [AddonBrowser.xml](../1080i/AddonBrowser.xml) | Yes | — | — |
| [Custom_1101_Hub.xml](../1080i/Custom_1101_Hub.xml) | — | — | — |
| [Custom_1102_Hub.xml](../1080i/Custom_1102_Hub.xml) | — | — | — |
| [Custom_1103_Hub.xml](../1080i/Custom_1103_Hub.xml) | — | — | — |
| [Custom_1104_Hub.xml](../1080i/Custom_1104_Hub.xml) | — | — | — |
| [Custom_1105_Search.xml](../1080i/Custom_1105_Search.xml) | Yes | — | Yes |
| [Custom_1106_Hub.xml](../1080i/Custom_1106_Hub.xml) | — | — | — |
| [Custom_1107_Hub.xml](../1080i/Custom_1107_Hub.xml) | — | — | — |
| [Custom_1108_Hub.xml](../1080i/Custom_1108_Hub.xml) | — | — | — |
| [Custom_1109_Hub.xml](../1080i/Custom_1109_Hub.xml) | — | — | — |
| [Custom_1111_Dialog_ColourPicker.xml](../1080i/Custom_1111_Dialog_ColourPicker.xml) | — | Yes | — |
| [Custom_1113_Dialog_Plot.xml](../1080i/Custom_1113_Dialog_Plot.xml) | — | Yes | — |
| [Custom_1114_Dialog_CustomPlot.xml](../1080i/Custom_1114_Dialog_CustomPlot.xml) | — | Yes | — |
| [Custom_1115_Window_Shortcuts.xml](../1080i/Custom_1115_Window_Shortcuts.xml) | Yes | — | — |
| [Custom_1116_Dialog_Shortcuts.xml](../1080i/Custom_1116_Dialog_Shortcuts.xml) | — | Yes | Yes |
| [Custom_1117_Dialog_IconSelector.xml](../1080i/Custom_1117_Dialog_IconSelector.xml) | — | Yes | Yes |
| [Custom_1118_Dialog_Settings.xml](../1080i/Custom_1118_Dialog_Settings.xml) | — | Yes | — |
| [Custom_1119_Dialog_Select.xml](../1080i/Custom_1119_Dialog_Select.xml) | — | Yes | — |
| [Custom_1120_Dialog_SelectCrew.xml](../1080i/Custom_1120_Dialog_SelectCrew.xml) | — | Yes | — |
| [Custom_1122_Dialog_SelectTrailer.xml](../1080i/Custom_1122_Dialog_SelectTrailer.xml) | — | Yes | — |
| [Custom_1123_Dialog_Trailer.xml](../1080i/Custom_1123_Dialog_Trailer.xml) | — | Yes | — |
| [Custom_1124_Dialog_Shortcut_Settings.xml](../1080i/Custom_1124_Dialog_Shortcut_Settings.xml) | — | Yes | — |
| [Custom_1125_Dialog_WidgetMode.xml](../1080i/Custom_1125_Dialog_WidgetMode.xml) | — | Yes | — |
| [Custom_1126_Dialog_FileProperties.xml](../1080i/Custom_1126_Dialog_FileProperties.xml) | — | Yes | — |
| [Custom_1127_Dialog_EpisodeRatings.xml](../1080i/Custom_1127_Dialog_EpisodeRatings.xml) | — | Yes | — |
| [Custom_1128_Dialog_HubType.xml](../1080i/Custom_1128_Dialog_HubType.xml) | — | Yes | — |
| [Custom_1130_Dialog_SetupWizard.xml](../1080i/Custom_1130_Dialog_SetupWizard.xml) | — | Yes | — |
| [Custom_1131_Dialog_Tiles.xml](../1080i/Custom_1131_Dialog_Tiles.xml) | — | Yes | — |
| [Custom_1132_Dialog_SelectDetailed.xml](../1080i/Custom_1132_Dialog_SelectDetailed.xml) | — | Yes | — |
| [Custom_1133_Dialog_AddHub.xml](../1080i/Custom_1133_Dialog_AddHub.xml) | — | Yes | — |
| [Custom_1134_Dialog_Cards.xml](../1080i/Custom_1134_Dialog_Cards.xml) | — | Yes | — |
| [Custom_1135_Dialog_BackgroundStyle.xml](../1080i/Custom_1135_Dialog_BackgroundStyle.xml) | — | Yes | — |
| [Custom_1136_Dialog_SplashPreview.xml](../1080i/Custom_1136_Dialog_SplashPreview.xml) | — | — | — |
| [Custom_1140_OSD_Playlist.xml](../1080i/Custom_1140_OSD_Playlist.xml) | — | — | — |
| [Custom_1141_OSD_Cast.xml](../1080i/Custom_1141_OSD_Cast.xml) | — | — | — |
| [Custom_1142_OSD_MusicTracks.xml](../1080i/Custom_1142_OSD_MusicTracks.xml) | — | — | — |
| [Custom_1143_OSD_NextOverlay.xml](../1080i/Custom_1143_OSD_NextOverlay.xml) | — | — | — |
| [Custom_1145_OSD_InfoPanel.xml](../1080i/Custom_1145_OSD_InfoPanel.xml) | — | — | — |
| [Custom_1146_OSD_AudioStreams.xml](../1080i/Custom_1146_OSD_AudioStreams.xml) | — | — | — |
| [Custom_1147_OSD_SubtitleStreams.xml](../1080i/Custom_1147_OSD_SubtitleStreams.xml) | — | — | — |
| [Custom_1148_OSD_VideoStreams.xml](../1080i/Custom_1148_OSD_VideoStreams.xml) | — | — | Yes |
| [Custom_1151_OSD_MusicInfoOverlay.xml](../1080i/Custom_1151_OSD_MusicInfoOverlay.xml) | — | — | — |
| [Custom_1152_OSD_VideoInfoOverlay.xml](../1080i/Custom_1152_OSD_VideoInfoOverlay.xml) | — | — | — |
| [Custom_1153_OSD_VideoInfoOverlayTop.xml](../1080i/Custom_1153_OSD_VideoInfoOverlayTop.xml) | — | — | — |
| [Custom_1159_OSD_PPI_VS10.xml](../1080i/Custom_1159_OSD_PPI_VS10.xml) | — | — | — |
| [Custom_1160_Dialog_Favourites.xml](../1080i/Custom_1160_Dialog_Favourites.xml) | — | Yes | — |
| [Custom_1161_Dialog_Weather.xml](../1080i/Custom_1161_Dialog_Weather.xml) | — | Yes | — |
| [Custom_1170_Dialog_Options.xml](../1080i/Custom_1170_Dialog_Options.xml) | — | Yes | — |
| [Custom_1171_Dialog_Views.xml](../1080i/Custom_1171_Dialog_Views.xml) | — | Yes | — |
| [Custom_1172_Dialog_InfoOptions.xml](../1080i/Custom_1172_Dialog_InfoOptions.xml) | — | Yes | — |
| [Custom_1180_Dialog_Bumper.xml](../1080i/Custom_1180_Dialog_Bumper.xml) | — | — | — |
| [Custom_1181_Dialog_Submenu.xml](../1080i/Custom_1181_Dialog_Submenu.xml) | — | Yes | — |
| [Custom_1182_Dialog_Topmenu_Overlay.xml](../1080i/Custom_1182_Dialog_Topmenu_Overlay.xml) | Yes | — | — |
| [Custom_1190_TMDbHelper.xml](../1080i/Custom_1190_TMDbHelper.xml) | — | — | — |
| [Custom_1191_Test.xml](../1080i/Custom_1191_Test.xml) | — | — | — |
| [Custom_1192_SeasonalTheme.xml](../1080i/Custom_1192_SeasonalTheme.xml) | — | — | — |
| [Custom_1193_VideoOSDInfo.xml](../1080i/Custom_1193_VideoOSDInfo.xml) | — | — | — |
| [Custom_1194_Debug_Grid.xml](../1080i/Custom_1194_Debug_Grid.xml) | — | — | — |
| [Custom_1195_SkinUserLoginScreen.xml](../1080i/Custom_1195_SkinUserLoginScreen.xml) | — | — | — |
| [Custom_1198_Dialog_Startup.xml](../1080i/Custom_1198_Dialog_Startup.xml) | — | — | — |
| [Custom_1199_Debug_Overlay.xml](../1080i/Custom_1199_Debug_Overlay.xml) | — | — | — |
| [DialogAddonInfo.xml](../1080i/DialogAddonInfo.xml) | — | Yes | — |
| [DialogAddonSettings.xml](../1080i/DialogAddonSettings.xml) | — | Yes | Yes |
| [DialogBusy.xml](../1080i/DialogBusy.xml) | — | — | — |
| [DialogButtonMenu.xml](../1080i/DialogButtonMenu.xml) | — | — | — |
| [DialogColorPicker.xml](../1080i/DialogColorPicker.xml) | — | Yes | — |
| [DialogConfirm.xml](../1080i/DialogConfirm.xml) | — | Yes | — |
| [DialogContextMenu.xml](../1080i/DialogContextMenu.xml) | — | Yes | Yes |
| [DialogExtendedProgressBar.xml](../1080i/DialogExtendedProgressBar.xml) | — | — | — |
| [DialogFullScreenInfo.xml](../1080i/DialogFullScreenInfo.xml) | — | — | — |
| [DialogGameControllers.xml](../1080i/DialogGameControllers.xml) | — | Yes | Yes |
| [DialogKeyboard.xml](../1080i/DialogKeyboard.xml) | — | Yes | — |
| [DialogMediaSource.xml](../1080i/DialogMediaSource.xml) | — | Yes | — |
| [DialogMusicInfo.xml](../1080i/DialogMusicInfo.xml) | — | — | — |
| [DialogNotification.xml](../1080i/DialogNotification.xml) | — | — | — |
| [DialogNumeric.xml](../1080i/DialogNumeric.xml) | — | Yes | — |
| [DialogPictureInfo.xml](../1080i/DialogPictureInfo.xml) | — | Yes | — |
| [DialogPlayerProcessInfo.xml](../1080i/DialogPlayerProcessInfo.xml) | — | Yes | — |
| [DialogPVRChannelGuide.xml](../1080i/DialogPVRChannelGuide.xml) | — | — | — |
| [DialogPVRChannelManager.xml](../1080i/DialogPVRChannelManager.xml) | — | Yes | Yes |
| [DialogPVRChannelsOSD.xml](../1080i/DialogPVRChannelsOSD.xml) | — | — | — |
| [DialogPVRGroupManager.xml](../1080i/DialogPVRGroupManager.xml) | — | Yes | — |
| [DialogPVRGuideSearch.xml](../1080i/DialogPVRGuideSearch.xml) | — | Yes | Yes |
| [DialogPVRInfo.xml](../1080i/DialogPVRInfo.xml) | — | Yes | — |
| [DialogSeekBar.xml](../1080i/DialogSeekBar.xml) | Yes | — | — |
| [DialogSelect.xml](../1080i/DialogSelect.xml) | — | Yes | — |
| [DialogSettings.xml](../1080i/DialogSettings.xml) | — | Yes | Yes |
| [DialogSlider.xml](../1080i/DialogSlider.xml) | — | — | — |
| [DialogSubtitles.xml](../1080i/DialogSubtitles.xml) | — | Yes | — |
| [DialogTextViewer.xml](../1080i/DialogTextViewer.xml) | — | Yes | — |
| [DialogVideoInfo.xml](../1080i/DialogVideoInfo.xml) | — | — | — |
| [DialogVideoManager.xml](../1080i/DialogVideoManager.xml) | — | Yes | — |
| [DialogVolumeBar.xml](../1080i/DialogVolumeBar.xml) | — | — | — |
| [EventLog.xml](../1080i/EventLog.xml) | Yes | — | Yes |
| [FileBrowser.xml](../1080i/FileBrowser.xml) | — | Yes | — |
| [FileManager.xml](../1080i/FileManager.xml) | Yes | — | Yes |
| [GameOSD.xml](../1080i/GameOSD.xml) | — | Yes | — |
| [Home.xml](../1080i/Home.xml) | — | — | — |
| [LoginScreen.xml](../1080i/LoginScreen.xml) | — | — | — |
| [MusicOSD.xml](../1080i/MusicOSD.xml) | — | — | — |
| [MusicVisualisation.xml](../1080i/MusicVisualisation.xml) | — | — | — |
| [MyFavourites.xml](../1080i/MyFavourites.xml) | — | — | — |
| [MyGames.xml](../1080i/MyGames.xml) | — | — | — |
| [MyMusicNav.xml](../1080i/MyMusicNav.xml) | — | — | — |
| [MyMusicPlaylistEditor.xml](../1080i/MyMusicPlaylistEditor.xml) | Yes | — | Yes |
| [MyPics.xml](../1080i/MyPics.xml) | — | — | — |
| [MyPlaylist.xml](../1080i/MyPlaylist.xml) | — | — | — |
| [MyPrograms.xml](../1080i/MyPrograms.xml) | — | — | — |
| [MyPVRChannels.xml](../1080i/MyPVRChannels.xml) | Yes | — | — |
| [MyPVRGuide.xml](../1080i/MyPVRGuide.xml) | Yes | — | — |
| [MyPVRRecordings.xml](../1080i/MyPVRRecordings.xml) | — | — | — |
| [MyPVRSearch.xml](../1080i/MyPVRSearch.xml) | — | — | — |
| [MyPVRTimers.xml](../1080i/MyPVRTimers.xml) | — | — | — |
| [MyVideoNav.xml](../1080i/MyVideoNav.xml) | — | — | — |
| [MyWeather.xml](../1080i/MyWeather.xml) | Yes | — | — |
| [PlayerControls.xml](../1080i/PlayerControls.xml) | — | — | — |
| [Pointer.xml](../1080i/Pointer.xml) | — | — | — |
| [screensaver-arctic-mirage.xml](../1080i/screensaver-arctic-mirage.xml) | — | — | — |
| [script-cu-lrclyrics-main.xml](../1080i/script-cu-lrclyrics-main.xml) | — | — | — |
| [script-game-manuals-finder.xml](../1080i/script-game-manuals-finder.xml) | — | Yes | — |
| [script-game-manuals-viewer.xml](../1080i/script-game-manuals-viewer.xml) | — | — | — |
| [script-plex-skip_marker.xml](../1080i/script-plex-skip_marker.xml) | — | — | — |
| [script-upnext-stillwatching.xml](../1080i/script-upnext-stillwatching.xml) | — | — | — |
| [script-upnext-upnext.xml](../1080i/script-upnext-upnext.xml) | — | — | — |
| [script-wikipedia.xml](../1080i/script-wikipedia.xml) | — | Yes | — |
| [Settings.xml](../1080i/Settings.xml) | Yes | — | Yes |
| [SettingsCategory.xml](../1080i/SettingsCategory.xml) | Yes | — | Yes |
| [SettingsProfile.xml](../1080i/SettingsProfile.xml) | Yes | — | Yes |
| [SettingsScreenCalibration.xml](../1080i/SettingsScreenCalibration.xml) | — | — | — |
| [SettingsSystemInfo.xml](../1080i/SettingsSystemInfo.xml) | Yes | — | Yes |
| [SkinSettings.xml](../1080i/SkinSettings.xml) | Yes | — | Yes |
| [SlideShow.xml](../1080i/SlideShow.xml) | — | — | — |
| [SmartPlaylistEditor.xml](../1080i/SmartPlaylistEditor.xml) | — | Yes | Yes |
| [SmartPlaylistRule.xml](../1080i/SmartPlaylistRule.xml) | — | Yes | Yes |
| [Startup.xml](../1080i/Startup.xml) | — | — | — |
| [VideoFullScreen.xml](../1080i/VideoFullScreen.xml) | — | — | — |
| [VideoOSD.xml](../1080i/VideoOSD.xml) | — | — | — |
| [VideoOSDBookmarks.xml](../1080i/VideoOSDBookmarks.xml) | — | — | — |
