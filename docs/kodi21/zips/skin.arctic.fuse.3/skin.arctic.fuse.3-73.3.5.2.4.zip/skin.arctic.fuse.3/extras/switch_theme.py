import json

import xbmc


def setting(method, name, **params):
    request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": f"Settings.{method}",
        "params": {"setting": name, **params},
    }
    response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    if "error" in response:
        raise RuntimeError(response["error"])
    return response["result"]


def switch_theme():
    theme_id = "lookandfeel.skintheme"
    font_id = "lookandfeel.font"
    theme = setting("GetSettingValue", theme_id)["value"]
    font = setting("GetSettingValue", font_id)["value"]
    if font.casefold() == "soft":
        font = "Default"

    target = "SKINDEFAULT" if theme.casefold() == "soft" else "Soft"
    if setting("SetSettingValue", theme_id, value=target):
        # Kodi sets the font to the theme name when the texture pack changes.
        setting("SetSettingValue", font_id, value=font)


if __name__ == "__main__":
    switch_theme()
