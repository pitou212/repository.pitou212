# Follows the focused item and keeps AF3.ListItem.Current.BlurImage (Home) up to date -- and AF3.ListItem.BlurImage
# on an info dialog -- while Arctic Fuse 3 is the active skin with blur on -- and AF3.ListItem.StudioLogo (blur on or
# off). No network requests here.
import time

import xbmc
import xbmcgui

from resources.lib import blur

SKIN = 'skin.arctic.fuse.3'
POLL = 0.2       # seconds between looks at the focused item
SETTLE = 0.25    # the source must stay the same this long before it is blurred: scrolling past items costs nothing


def enabled():
	return xbmc.getSkinDir() == SKIN and blur.cond('Skin.HasSetting(TMDbHelper.EnableBlur)')


def dialog_window():
	"""The info dialog's window when one is open (the skin reads Window.Property(AF3.ListItem.BlurImage) there)."""
	if blur.cond('Window.IsVisible(movieinformation) | Window.IsVisible(musicinformation)'):
		return xbmcgui.Window(xbmcgui.getCurrentWindowDialogId())
	return None


class State:
	seen, seen_at, shown, output = None, 0.0, None, ''
	studio = None


def update_studio(state, prefix):
	"""AF3.ListItem.StudioLogo: the focused item's studio logo when resource.images.studios.coloured has one, else empty
	(2026-11-12; the skin's Image_CombinedStudio reads it). Runs with blur on or off."""
	studio = blur.info(prefix + 'Studio')
	if studio != state.studio:
		state.studio = studio
		from resources.lib import studios
		blur.HOME.setProperty('AF3.ListItem.StudioLogo', studios.logo(studio))


def sync_dialog(state):
	"""An info dialog opened on the item already blurred (same source, so no new work) still needs its own
	Window.Property(AF3.ListItem.BlurImage): the dialog's background reads it, not Home's."""
	window = dialog_window()
	if window is not None and state.output and window.getProperty('AF3.ListItem.BlurImage') != state.output:
		blur.set_props(window, 'ListItem', state.output, state.shown)


def tick(state):
	if xbmc.getSkinDir() != SKIN or blur.cond('Container.Scrolling'):
		return
	prefix = blur.focused_prefix()
	if prefix is None:
		return
	# 2026-11-12: a Home widget row is Container(<id>), which plain Container.Scrolling does not cover
	if prefix.startswith('Container(') and blur.cond(prefix[:-len('ListItem.')] + 'Scrolling'):
		return
	update_studio(state, prefix)
	if not enabled():
		return
	spec =blur.HOME.getProperty('AF3.Blur.SourceImage') or 'Art(fanart)'
	source = blur.resolve(prefix, spec) or blur.fallback()
	now = time.time()
	if source != state.seen:
		state.seen, state.seen_at = source, now
		return
	if source == state.shown:
		sync_dialog(state)
		return
	if now - state.seen_at < SETTLE:
		return
	state.shown = source   # before the work: a source that keeps failing is not retried every tick
	state.output = blur.blur(source)
	blur.set_props(blur.HOME, 'ListItem.Current', state.output, source)
	sync_dialog(state)


def start_ratings():
	"""Online ratings (resources.lib.ratings, ported from Short Fuse) on their own thread, only when AF3 has an MDBList or
	OMDb key at startup -- without one it costs nothing; a key entered later needs a Kodi restart (the skin says so)."""
	try:
		from resources.lib import ratings
		if not ratings.has_api_key():
			return
		import threading
		threading.Thread(target=ratings.RatingsService().run, name='AF3Ratings', daemon=True).start()
	except Exception as exc:
		xbmc.log('[script.af3.helper] ratings did not start: %s' % type(exc).__name__, xbmc.LOGWARNING)


def main():
	monitor = xbmc.Monitor()
	try: blur.prune()
	except Exception: pass
	start_ratings()
	state = State()
	while not monitor.waitForAbort(POLL):
		try: tick(state)
		except Exception as exc:   # one bad item must not stop the service
			xbmc.log('[script.af3.helper] service tick failed: %s' % type(exc).__name__, xbmc.LOGWARNING)


if __name__ == '__main__':
	main()
