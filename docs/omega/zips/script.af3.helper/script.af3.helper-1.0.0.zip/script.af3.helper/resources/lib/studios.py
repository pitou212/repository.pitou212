# Which studio logos resource.images.studios.coloured has, so the skin only asks Kodi for logos that exist.
# The skin used to build resource://resource.images.studios.coloured/<Studio>.png for every focused item; for a studio
# the pack lacks, Kodi failed the load and logged an error each time focus landed there (45 in one 46 s scroll,
# 2026-11-12). The pack is one Textures.xbt; only its index (names) is read, once.
import struct

import xbmcvfs

PACK = 'resource.images.studios.coloured'
XBT = 'special://home/addons/%s/resources/Textures.xbt' % PACK
_names = None


def _load():
	names = set()
	try:
		with open(xbmcvfs.translatePath(XBT), 'rb') as f:
			if f.read(4) != b'XBTF':
				return names
			f.read(1)   # version
			count = struct.unpack('<I', f.read(4))[0]
			for _ in range(count):
				path = f.read(256).split(b'\0')[0].decode('utf-8', 'replace')
				_loop, frames = struct.unpack('<II', f.read(8))
				f.seek(40 * frames, 1)   # frame records: not needed
				names.add(path.lower())
	except (OSError, struct.error):
		pass   # no pack, or an unreadable one: no logos rather than failed loads
	return names


def logo(studio):
	"""resource:// path of the studio's logo, '' when the pack has none (or the label holds several studios)."""
	global _names
	if not studio or '/' in studio:
		return ''
	if _names is None:
		_names = _load()
	return 'resource://%s/%s.png' % (PACK, studio) if (studio + '.png').lower() in _names else ''
