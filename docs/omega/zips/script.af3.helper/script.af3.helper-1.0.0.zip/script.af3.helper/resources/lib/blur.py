# Blurred backgrounds for Arctic Fuse 3 -- the part of TMDb Helper's image monitor the skin still uses.
# The file names match TMDb Helper's, because the skin builds the rounded one's name itself:
#   <md5>-<radius>-<size>.jpg  and  <md5>-<radius>-<size>.jpg-diffuse-<corner>.jpg
import hashlib
import os
import time
import urllib.parse

import xbmc
import xbmcgui
import xbmcvfs

SAVE_DIR = 'special://profile/addon_data/script.af3.helper/blur/'
HOME = xbmcgui.Window(10000)
PROP = 'AF3.'
# Setting ids are the skin's existing ones, so values saved under TMDb Helper carry over.
S_SIZE, S_RADIUS, S_CORNER = 'TMDbHelper.Blur.Size', 'TMDbHelper.Blur.Radius', 'TMDbHelper.Corner.Radius'
FANART = ['Art(fanart)', 'Art(thumb)']

_PIL = None


def pil():
	global _PIL
	if _PIL is None:
		from PIL import Image, ImageDraw, ImageFilter
		_PIL = (Image, ImageDraw, ImageFilter)
	return _PIL


def info(label):
	return xbmc.getInfoLabel(label)


def cond(expr):
	return xbmc.getCondVisibility(expr)


def _int(value, default):
	try: return int(value)
	except (TypeError, ValueError): return default


def md5(value):
	return hashlib.md5(value.encode('utf-8', 'ignore')).hexdigest()


def set_props(window, prefix, output, source):
	"""prefix e.g. 'ListItem.Current' -> AF3.ListItem.Current.BlurImage (+ .Original, the sharp FlixArt layer's image:
	the local copy blur() kept when it had to download the source, else the source itself)."""
	name = '%s%s.BlurImage' % (PROP, prefix)
	if output:
		window.setProperty(name, output); window.setProperty(name + '.Original', sharp(source))
	else:
		window.clearProperty(name); window.clearProperty(name + '.Original')



# ---- reading the source image -------------------------------------------------------------------------------------

_CYCLE_HOLD, _CYCLE_GONE = 8, 15   # same as the DeadLight patch on TMDb Helper (2026-10-27): step every 8 s, reset after 15 s away
_cycle = {}


def _cycle_pick(spec, artworks):
	"""In order, not random: a new item starts on its own fanart, then steps every _CYCLE_HOLD seconds."""
	now, key = time.time(), (spec, artworks[0])
	state = _cycle.get(spec)
	if not state or state['key'] != key or now - state['seen'] > _CYCLE_GONE:
		state = _cycle[spec] = {'key': key, 'index': 0, 'time': now, 'seen': now}
	elif now - state['time'] >= _CYCLE_HOLD:
		state['index'], state['time'] = (state['index'] + 1) % len(artworks), now
	state['seen'] = now
	return artworks[state['index'] % len(artworks)]


def _item_label(prefix, label, spec_key):
	if '{x}' not in label:
		return info(prefix + label)
	first = info(prefix + label.format(x=''))
	if not first:
		_cycle.pop(spec_key, None); return ''
	artworks = [first]
	for x in range(1, 9):
		art = info(prefix + label.format(x=x))
		if not art: break
		artworks.append(art)
	if len(artworks) == 1:
		_cycle.pop(spec_key, None); return first
	return _cycle_pick(spec_key, artworks)


def resolve(prefix, spec):
	"""spec as the skin writes it: 'Art(a)|Art(b)||EPGEventIcon' -- '||' separates fallback groups, '|' items."""
	for group in (spec or '').split('||'):
		labels = [l for l in group.split('|') if l] or FANART
		for label in labels:
			# The cycle position is kept per LABEL, as TMDb Helper did: keyed per group, a movie's empty
			# Art(tvshow.fanart{x}) cleared the position Art(fanart{x}) had just stored, every tick, so it never stepped
			# (user: 'cycle fanart not working', 2026-11-11).
			art = _item_label(prefix, label, label)
			if art: return art
	return ''


def fallback():
	"""The skin's stand-in when the item has no art: per content type first (AF3.Blur.Fallback.genres, set with
	stylised backgrounds on), then the general one."""
	content = info('Container.Content').lower()
	return (content and HOME.getProperty('%sBlur.Fallback.%s' % (PROP, content))) or HOME.getProperty('%sBlur.Fallback' % PROP)


def focused_prefix():
	"""Where the focused item is: a widget the skin named in AF3.WidgetContainer (window first, then Home), else the
	current list. None when nothing should be followed (fullscreen video, screensaver)."""
	if cond('Window.IsActive(fullscreenvideo) | Window.IsActive(screensaver) | Window.IsActive(visualisation)'):
		return None
	# Only while a list with items is on screen (TMDb Helper's is_on_listitem): Search, settings and other windows have
	# none, and following them would swap the blur for the fallback a moment after they open (seen 2026-11-11: press S on
	# Home -> the item's blur, then grey). None keeps the last blur.
	if cond('Window.IsVisible(movieinformation) | Window.IsVisible(musicinformation)'):
		return 'ListItem.'
	wc = info('Window.Property(%sWidgetContainer)' % PROP) or HOME.getProperty('%sWidgetContainer' % PROP)
	if wc and cond('Control.IsVisible(%s) + Integer.IsGreater(Container(%s).NumItems,0)' % (wc, wc)):
		return 'Container(%s).ListItem.' % wc
	if cond('Window.IsMedia + Integer.IsGreater(Container.NumItems,0)'):
		return 'ListItem.'
	return None


# ---- making the images -------------------------------------------------------------------------------------------

def _cached_thumb(source):
	unquoted = urllib.parse.unquote(source.replace('image://', '')).rstrip('/')
	for path in (xbmc.getCacheThumbName(unquoted), xbmc.getCacheThumbName(source)):
		for candidate in ('special://profile/Thumbnails/%s/%s.jpg' % (path[0], path[:-4]),
		                  'special://profile/Thumbnails/%s/%s.png' % (path[0], path[:-4])):
			if xbmcvfs.exists(candidate): return xbmcvfs.translatePath(candidate)
	return None


def _open(source, temp_name):
	"""PIL image + temp file to delete (or None). Kodi's own texture cache first; skin-packed textures can't be read."""
	Image = pil()[0]
	local = _cached_thumb(source)
	if local: return Image.open(local), None
	if source.startswith('special://') or os.path.isabs(source):
		path = xbmcvfs.translatePath(source)
		return (Image.open(path), None) if os.path.exists(path) else (None, None)
	temp = xbmcvfs.translatePath(SAVE_DIR + temp_name)
	if not xbmcvfs.copy(source, temp): return None, None
	return Image.open(temp), temp


def _tiled(img, destination):
	"""2x2 mirrored tile of the blur, as TMDb Helper's _add_tile made it: AF3's blur layer behind the FlixArt fanart
	(Background_Blur_Quadrants) reads <blur>.jpg-tiled.jpg. Without it the left side of the screen stays black."""
	Image = pil()[0]
	w, h = img.size
	tile = Image.new('RGB', (w * 2, h * 2))
	flip = img.copy()
	tile.paste(flip, (w, 0))                                   # top right
	flip = flip.transpose(Image.FLIP_TOP_BOTTOM)
	tile.paste(flip, (w, h))                                   # bottom right
	flip = flip.transpose(Image.FLIP_LEFT_RIGHT)
	flip = flip.resize((w * 2, h), Image.BILINEAR).crop((w, 0, w * 2, h))
	tile.paste(flip, (0, h))                                   # bottom left
	flip = flip.transpose(Image.FLIP_TOP_BOTTOM)
	tile.paste(flip, (0, 0))                                   # top left
	tile.save(destination, 'PNG')   # PNG for the same reason as the blur itself (stretched, no JPEG blocks)
	tile.close(); flip.close()


def _rounded(img, destination, radius, aa=4):
	Image, ImageDraw, _ = pil()
	img = img.copy()
	diameter = radius * 2
	circle = Image.new('L', (diameter * aa, diameter * aa), 0)
	ImageDraw.Draw(circle).ellipse((0, 0, diameter * aa, diameter * aa), fill=255)
	circle = circle.resize((diameter, diameter), Image.LANCZOS)
	alpha = Image.new('L', img.size, 'white')
	w, h = img.size
	alpha.paste(circle.crop((0, 0, radius, radius)), (0, 0))
	alpha.paste(circle.crop((0, radius, radius, diameter)), (0, h - radius))
	alpha.paste(circle.crop((radius, 0, diameter, radius)), (w - radius, 0))
	alpha.paste(circle.crop((radius, radius, diameter, diameter)), (w - radius, h - radius))
	img.putalpha(alpha)
	img.save(destination, 'PNG')


def _safe(source):
	"""For the log: no query string and no user:password@ -- an image URL can carry a token."""
	try:
		parts = urllib.parse.urlsplit(urllib.parse.unquote(source.replace('image://', '')))
		return urllib.parse.urlunsplit((parts.scheme, parts.hostname or '', parts.path, '', '')) if parts.scheme else md5(source)
	except Exception:   # a malformed URL (e.g. an unbalanced [host]) must not escape the caller's error handler
		return md5(source)


def _save(img, destination, write):
	"""Write to a part file of our own, then move it into place. The service and a RunScript can make the same image
	at the same moment (the plain background is both the startup blur and the service's fallback), and on Windows the
	move fails while the other writer or Kodi's texture loader has the file open: then the finished file is used."""
	import threading
	part = '%s.%d-%d.part' % (destination, os.getpid(), threading.get_ident())
	try:
		write(part)
		os.replace(part, destination)
	except PermissionError:
		if not os.path.exists(destination): raise
	finally:
		if os.path.exists(part):
			try: os.remove(part)
			except OSError: pass


def _paths(source):
	"""(size, radius, corner, file name, destination, rounded or None, tiled) for a source."""
	size = _int(info('Skin.String(%s)' % S_SIZE), 0) or 480
	radius = _int(info('Skin.String(%s)' % S_RADIUS), 0) or 40
	corner = _int(info('Skin.String(%s)' % S_CORNER), 20)
	# -v2: PNG content (2026-11-11). The skin appends -diffuse-N.jpg / -tiled.jpg to this path itself, so the name keeps
	# ending in .jpg; Kodi reads the format from the file, as it did for TMDb Helper's PNG-in-.jpg files.
	# -v3: enlarged 2x (see _smooth), so blurs made before it are made again once. (The first v3 files of 2026-11-11 were
	# also dithered; they look the same or better, so the name was kept rather than re-blurring everything a second time.)
	name = '%s-%s-%s-v3.jpg' % (md5(source), radius, size)
	destination = os.path.join(xbmcvfs.translatePath(SAVE_DIR), name)
	rounded = '%s-diffuse-%s.jpg' % (destination, corner) if corner > 0 else None
	return size, radius, corner, name, destination, rounded, destination + '-tiled.jpg'


def _src_path(source):
	"""Where blur() keeps a source it had to download (one per source, whatever the blur settings)."""
	return os.path.join(xbmcvfs.translatePath(SAVE_DIR), md5(source) + '-src.jpg')


def sharp(source):
	"""The image for the sharp layer: the kept download when there is one, else the source (Kodi has it cached, or it is
	local). 2026-11-12: with cycle fanart each step's fanart was new to Kodi, so the skin's sharp layer downloaded it AGAIN
	while the blur (a local file) was already on screen -- the new blur around the old fanart, then the fanart changed
	(user: 'flashes ... then turned to new blur'; Kodi's cache files were created at each 8 s step). Local, both layers
	load in the same few ms."""
	if not source: return source
	src = _src_path(source)
	if os.path.exists(src):
		try: os.utime(src)   # keeps it out of prune() while in use
		except OSError: pass
		return src
	return source


def existing(source):
	"""The blur's path when it was made before (all its files are there), else ''. No image work."""
	if not source: return ''
	destination, rounded, tiled = _paths(source)[4:]
	if os.path.exists(destination) and os.path.exists(tiled) and (not rounded or os.path.exists(rounded)):
		try: os.utime(destination)   # keeps it out of prune()
		except OSError: pass
		return destination
	return ''


UPSCALE = 2        # the saved blur is this many times Blur.Size: Kodi then stretches it ~3x to 1080p, not ~6x


def _smooth(img):
	"""Against the 'pixelated pattern' (user, 2026-11-11): a 320 px blur stretched ~6x turns each one-step change of the
	gradient into a 6 px band, with R, G and B stepping at different places -- a faint mosaic of stripes. Enlarging with
	BICUBIC first makes the bands half as wide and smooth-edged (~60 ms a blur on the PC, was ~40).
	A dither baked in here was tried and dropped the same day: noise barely compresses, so the PNGs grew ~10x and each
	blur took ~240 ms, mostly in the PNG save (user: 'takes too much time to process'). Dither belongs in the skin, as
	one static grain texture over the blur, if the remaining bands show."""
	Image = pil()[0]
	w, h = img.size
	return img.resize((w * UPSCALE, h * UPSCALE), Image.BICUBIC)


def blur(source):
	"""Path of the blurred image (made once, then reused), '' on failure."""
	if not source: return ''
	made = existing(source)
	if made: return made
	size, radius, corner, name, destination, rounded, tiled = _paths(source)
	os.makedirs(os.path.dirname(destination), exist_ok=True)
	img, temp, made_ok = None, None, False
	try:
		img, temp = _open(source, 'temp_' + name)
		if img is None: return ''
		if img.format == 'JPEG': img.draft('RGB', (size, size))   # decode at reduced scale: much faster for big fanart
		img.thumbnail((size, size))
		img = _smooth(img.convert('RGB').filter(pil()[2].GaussianBlur(radius)))
		# PNG, not JPEG: the blur is small (Blur.Size, e.g. 320) and Kodi stretches it ~6x to the screen, which turns JPEG's
		# 8x8 blocks into visible squares on the smooth gradient (user: 'smooth but pixelated', 2026-11-11). TMDb Helper
		# saved PNG too. Kodi never sees a half-written file (_save).
		_save(img, destination, lambda f: img.save(f, 'PNG'))
		# the corner radius is in blur pixels: the enlarged image needs it UPSCALE times larger to look the same
		if rounded: _save(img, rounded, lambda f: _rounded(img, f, corner * UPSCALE))
		_save(img, tiled, lambda f: _tiled(img, f))
		made_ok = True
		return destination
	except Exception as exc:
		xbmc.log('[script.af3.helper] blur failed for %s: %s' % (_safe(source), type(exc).__name__), xbmc.LOGWARNING)
		return ''
	finally:
		if img is not None:
			try: img.close()
			except Exception: pass
		if temp:
			# a blur made: keep the download for the sharp layer (sharp()); a failed one: drop it
			try:
				if made_ok: os.replace(temp, _src_path(source))
				else: xbmcvfs.delete(temp)
			except OSError:
				xbmcvfs.delete(temp)


def prune(days=30):
	"""Drop blurred images not used for `days` (mtime is refreshed on reuse by the service)."""
	folder = xbmcvfs.translatePath(SAVE_DIR)
	if not os.path.isdir(folder): return
	limit = time.time() - days * 86400
	for f in os.listdir(folder):
		p = os.path.join(folder, f)
		try:
			if os.path.getmtime(p) < limit: os.remove(p)
		except OSError: pass
