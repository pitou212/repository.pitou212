# RunScript(script.af3.helper,blur_image=<path>,prefix=SimpleBackground) -> AF3.SimpleBackground.BlurImage on Home.
import sys

from resources.lib import blur


def params():
	out = {}
	for arg in sys.argv[1:]:
		key, _, value = arg.partition('=')
		out[key] = value
	return out


def main():
	p = params()
	if 'blur_image' in p:
		source = p['blur_image']
		blur.set_props(blur.HOME, p.get('prefix') or 'ListItem', blur.blur(source), source)


if __name__ == '__main__':
	main()
