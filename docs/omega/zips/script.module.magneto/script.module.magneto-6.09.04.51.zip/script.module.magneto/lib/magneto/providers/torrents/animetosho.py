# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-27: AnimeTosho provider -- anime episodes matched by ID.
#
# WHY THIS PROVIDER IS DIFFERENT FROM EVERY OTHER ONE HERE
# The rest of this directory searches by title and then decides, from the release
# NAME, whether a row is the episode the user asked for. For anime that decision is
# not reliably decidable. The same episode ships under genuinely different, equally
# correct numbers:
#
#   Bleach TYBW premiere   -> "S01E01"  AND  "S17E01"   (both on nyaa, both correct)
#   Re:ZERO TMDb ep 50     -> "Season 2 - 24"
#   Attack on Titan S3E20  -> "S03E20 (57)"
#   Boruto ep 220          -> "- 220"
#
# nyaa.py has grown a rule for each of these shapes and every rule risks the next
# show. That is a losing shape of problem, so this provider does not play it.
#
# AnimeTosho mirrored nyaa's English-translated anime category and tagged each torrent
# with the AniDB episode id (eid) it belongs to. Fen Light resolves the eid for the
# requested episode before scraping (Fribb -> AniList id -> ani.zip -> eid, all
# cached), so this provider asks the index a question that has one right answer:
# "which torrents ARE eid 259237?" -- and does no name parsing whatsoever.
#
# Verified against the four cases above: all four return the correct episode, in
# every naming convention at once, with no filtering applied.
#
# *** THE INDEX IS FROZEN -- READ THIS BEFORE DEBUGGING AN EMPTY RESULT ***
# AnimeTosho stopped ingesting on 2026-05-08. The API still answers HTTP 200 and still
# serves everything indexed up to that date, so this provider remains genuinely useful
# for the back catalogue -- but it holds NOTHING released after it, and that share
# grows every week.
#
# The symptom is a show returning zero rows by both eid and aid while nyaa has plenty:
# Chainsmoker Cat (premiered 2026-02, indexed nowhere here) gave 0 from animetosho and
# 22 from nyaa. That is the frozen index, not a broken lookup -- checking the newest
# `timestamp` in an unfiltered /json?limit=25 call confirms it in one request.
#
# So: nyaa is what covers current seasons and must stay enabled; seadex.py (live,
# updated daily) covers curated picks; this provider covers the archive.
#
# SCOPE
# Two queries, because they find different things:
#   sources()       ?eid=<episode id>  single episodes, exact, no parsing
#   sources_packs() ?aid=<anime id>    season packs, which the eid query cannot see
# See the note on pack_capable below for why both are needed.
#
# On remux: AnimeTosho's own index leans toward encodes over raws, and none of the
# six episodes measured while building this returned a remux -- though the pack query
# does surface them (Bleach TYBW has a 76.6GB BD Remux batch). Remux rows are tagged
# rather than assumed away: `name_info` below is what lets Fen Light apply its REMUX
# filter and quality sort to them.
#
# API: https://feed.animetosho.net/json?eid=<eid>   No key. No auth. JSON list.
#
# LOCAL PATCH 2026-09-15: .org -> .net, AnimeTosho's newer domain. Both hosts run the
# same software and answer the same AniDB semantics -- verified identical JSON schema
# (28 keys, no field differs) and both correctly report anidb_eid for the queried id --
# but they are NOT mirrors: their internal `id` spaces are disjoint, so the same release
# carries a different id on each. Compare by info_hash, never by id.
#
# .net measured equal or better on 6 of 7 real aids (Steins;Gate aid=129 returned 22 rows
# on .org against 75 on .net; four others hit the 75 cap on both). The one regression was
# aid=17069, 1 row on .org and 0 on .net. Single-episode eid=259237 gave 31 on .org and 48
# on .net, sharing only 20 info_hashes -- so each still holds releases the other lacks.
# Querying both and deduping by hash would strictly beat either; not done, one request.

from magneto.modules import client
from magneto.modules import source_utils
# LOCAL PATCH 2026-09-15: sibling-cour reject, see sources(). The same helper nyaa.py uses,
# so the three competing anime numbering schemes stay implemented in exactly one place.
try:
	from magneto.modules.anime_utils import cour_match
except Exception:
	cour_match = None

# LOCAL PATCH 2026-09-22: the same extractor cour_match uses, for the pack range check in
# sources_packs. Imported separately so a failure there cannot disable cour_match.
try:
	from magneto.modules.anime_utils import _clean_for_extract, _extract_meta, alias_titles
except Exception:
	_clean_for_extract = _extract_meta = alias_titles = None

# LOCAL PATCH 2026-09-23: the whole-run name check in sources(). Separate import, same reason.
try:
	from magneto.modules.anime_utils import whole_run_episode
except Exception:
	whole_run_episode = None

# LOCAL PATCH 2026-09-23: another cour's words in a PACK name, see sources/sources_packs.
try:
	from magneto.modules.anime_utils import names_foreign_cour
except Exception:
	names_foreign_cour = None

# LOCAL PATCH 2026-09-24: the pack-name readers, moved to anime_utils. Separate import, same reason.
try:
	from magneto.modules.anime_utils import pack_excludes_episode, pack_declares_season_only, pack_names_sibling_series
except Exception:
	pack_excludes_episode = pack_declares_season_only = pack_names_sibling_series = None

try:
	from statistics import median as _median
except ImportError:
	_median = None

try:
	import json as _json
except ImportError:
	_json = None

import re

# Raw Blu-ray disc structures and disc images. These carry no episode files to pick
# from -- a BDMV is a tree of .m2ts streams under BDMV/STREAM -- so the debrid layer
# can never resolve one to an episode and the row would only ever fail on click.
# Seen for real: a 440-file 95.6GB "[BDMV] Attack on Titan Season 4 Part 2 [US]" row
# returned under the Season 3 aid.
_DISC_STRUCTURE = re.compile(r'(?:^|[^a-z0-9])(?:bdmv|m2ts|iso|disc\s?\d|bdiso)(?:[^a-z0-9]|$)', re.I)

# LOCAL PATCH 2026-09-22: the feed's real per-page cap is 200, not 75.
# _fetch_index hardcoded limit=75 and a comment in sources_packs asserted the feed capped
# a page there, which is simply wrong: measured on aid 239, limit=150 returns 150 rows and
# limit=300 returns 200, so 200 is the ceiling. That one number is what lets the pack query
# be a SINGLE self-calibrating request -- a 200-row size-sorted page reaches down far enough
# to contain single-file rows (25 of 200 on aid 239) where a 75-row one contains none.
# Costs 1.31s and 199 KB against 0.53s and 74 KB for 75 rows, medians of 3.
_PAGE_MAX = 200

# LOCAL PATCH 2026-09-23: how many times heavier a 'single episode' may be than a file
# inside a pack before it is disbelieved. See _one_episode_size. Measured over the
# 200-row size-sorted window of five aids: JoJo Stone Ocean p1 1.1x, Re:ZERO S2 p1 1.9x,
# Naruto 2.7x, Re:ZERO S1 6.8x (1080p singles against packs holding 480p) -- all
# legitimate. One Piece reads 65.7x. 10 clears every real case and still catches it.
_SINGLE_FILE_SANITY = 10

# LOCAL PATCH 2026-09-24: the pack-NAME readers live in anime_utils (pack_excludes_episode,
# pack_declares_season_only, pack_names_sibling_series). This file keeps the ROW plumbing:
# which of a row's fields carry a name, and in what order both are read.
def _row_names(row):
	return [n for n in (row.get('title'), row.get('torrent_name')) if n]


def _declares_season_without_episodes(row):
	if not pack_declares_season_only: return False
	return pack_declares_season_only(_row_names(row))




class source:
	priority = 5
	# LOCAL PATCH 2026-08-27 (revised): was False. sources() alone can only ever see
	# batches that AnimeTosho has file-indexed and matched to episodes -- most are not,
	# so they sit at anidb_eid=None and an ?eid= query cannot return them. Measured:
	#
	#   anime          packs via ?eid=   packs via ?aid=
	#   Frieren S2            0                10
	#   Bleach TYBW           0                42     <- incl. a 76.6GB BD Remux
	#   Re:ZERO S2 P2         2                16
	#   AoT S3 P2             0                29
	#
	# sources_packs() closes that by asking with the ANIME id instead. Two things make
	# it safe, and neither was true before this week: the aid comes from Fribb offline
	# (so the pack path needs no ani.zip at all), and the debrid layer can now pick the
	# right file out of an anime pack (the 2026-08-27 cour-numbering fix) -- without
	# that, every pack returned here would have failed on click.
	pack_capable = True
	# Anime films are one AniDB episode too, but Fen Light only resolves an eid on the
	# episode path, so a movie scrape would always no-op. Left off until it passes one.
	hasMovies = False
	hasEpisodes = True

	def __init__(self):
		self.language = ['en']
		# ONE index, two domains. .net is the live host; .xyz serves the same data and is
		# tried only when .net cannot be reached -- measured identical by info_hash (48/48
		# and 75/75, zero exclusives either way), so asking both would return the same rows
		# twice and the dedupe would drop every one.
		#
		# feed.animetosho.ORG IS DEAD AND MUST NOT BE ADDED BACK. It still answers HTTP 200
		# with a full-looking payload, which is exactly the trap: its index STOPPED UPDATING
		# on 2026-05-07. Measured 2026-09-15 on the `timestamp` field --
		#
		#   Re:ZERO S4  aid=19242 : .net newest 2026-09-14   .org newest 2026-05-07
		#   Bleach TYBW eid=259237: .net newest 2025-03-22   .org newest 2022-12-28
		#
		# so it looked like a second index worth merging (75 rows on Re:ZERO sharing NOTHING
		# with .net) when those rows were simply everything .net had already moved past. For
		# a currently-airing show it can only contribute stale, likely-dead torrents and one
		# wasted request per scrape. Freshness here is the `timestamp` field, not HTTP status.
		self.base_link = 'https://feed.animetosho.net'
		# NOT self.sources -- that name is the provider's own sources() METHOD, and assigning
		# it here silently replaced the bound method with a tuple. The loader hands the class
		# to Fen Light, which calls module().sources(data, hostDict); with the attribute set,
		# every scrape died on "'tuple' object is not callable" and animetosho returned zero
		# rows while every other provider looked fine.
		self.feed_hosts = ((self.base_link, 'https://feed.animetosho.xyz'),)
		# Matches nyaa.py: this provider is debrid-only, and a 0-seeder torrent can
		# still be cached and instantly playable, so seeders must not gate it here.
		self.min_seeders = 0

	# LOCAL PATCH 2026-09-15: query BOTH hosts and merge, deduped on info_hash.
	#
	# .net and .org run the same software over INDEPENDENTLY BUILT indexes -- neither is a
	# mirror of the other and neither is a superset. Measured 2026-09-15 on eid=259237:
	# .org 31 rows, .net 48, sharing only 20 info_hashes. So .org held 11 releases .net
	# could not see and .net held 28 .org could not. Asking one host silently costs results.
	#
	# Dedupe is on info_hash and NEVER on `id`: the two hosts number their rows separately,
	# so the same release carries a different id on each and an id-keyed merge would return
	# every duplicate twice. magnet_uri is the fallback key for a row with no hash.
	#
	# Hosts are tried in order and a failing one is skipped, so this is also the failover:
	# either host being down degrades results rather than emptying them. Cost is one extra
	# request per query, both keyless and ~0.9s.
	def _fetch_index(self, host, params, pages, limit=75):
		"""All pages from ONE host, or None if the host could not be reached.

		None and [] mean different things and the caller depends on it: None is "ask this
		index's other domain", [] is "this index answered and genuinely has nothing"."""
		out = []
		for page in range(1, pages + 1):
			url = '%s/json?%s&limit=%d%s' % (host, params, limit,
										'&page=%d' % page if page > 1 else '')
			try:
				batch = _json.loads(client.request(url, timeout=10) or '[]')
			except Exception:
				return None if not out else out
			if not isinstance(batch, list): return None if not out else out
			out.extend(batch)
			# A short page means the index is exhausted. Compared against the limit ASKED for,
			# not a literal 75, or a 200-row request would always look short and stop early.
			if len(batch) < limit: break
		return out

	def _query(self, params, pages=1, limit=75):
		"""Rows from every index, deduped on info_hash.

		One entry in self.feed_hosts is one INDEX; its domains are interchangeable, so the first
		that answers wins and the rest are skipped -- querying an alias would return the same
		rows and every one would be dropped by the dedupe anyway. Indexes, by contrast, hold
		different releases and are all merged.

		Dedupe is on info_hash and NEVER on `id`: the indexes number rows separately, so the
		same release carries a different id on each and an id-keyed merge would double every
		shared row. magnet_uri is the fallback key for a row carrying no hash.
		"""
		rows, seen = [], set()
		for domains in self.feed_hosts:
			for host in domains:
				batch = self._fetch_index(host, params, pages, limit)
				if batch is None: continue          # unreachable -- try this index's alias
				for row in batch:
					if not isinstance(row, dict): continue
					key = (row.get('info_hash') or row.get('magnet_uri') or '').lower()
					if key:
						if key in seen: continue
						seen.add(key)
					rows.append(row)
				break                                # this index answered; skip its aliases
		return rows

	def _one_episode_size(self, rows):
		"""What one episode of this anime weighs, from the single-file rows in `rows`.

		Self-calibrating on purpose. A hardcoded "packs are over N GB" would be wrong
		across a 350MB SD show and a 3GB 1080p one, and reading "Batch" out of the title
		would be the name parsing this provider exists to avoid. The separation is wide:
		real batches measured at 18.5x and 45.7x the median, while the false positive
		this rejects -- one episode shipping a separate subtitle file -- sat at 0.5x.
		"""
		singles = [r.get('total_size') or 0 for r in rows
				if isinstance(r, dict) and int(r.get('num_files') or 1) == 1]
		singles = [x for x in singles if x > 0]
		one = _median(singles) if (singles and _median) else 0
		# LOCAL PATCH 2026-09-23: a single FILE is not always a single EPISODE.
		#
		# AnimeTosho files a franchise's FILMS under the series aid. On One Piece (aid 69) the
		# size-sorted window holds 195 multi-file rows and just 5 single-file ones -- and all
		# five are Film Red remuxes, 31 to 53 GB. Their median, 45.30 GB, then became 'one
		# episode', so _is_pack's 2x threshold sat at 90.6 GB and 111 of those 195 packs were
		# judged NOT packs. [F-R] One Piece 0629-0686 (58 files) and [Judas] One Piece 783-1023
		# (241 files) were offered as the single episode S1E1, and being unlabelled they also
		# escaped every pack safeguard downstream -- the real-size correction and the
		# drop-if-it-lacks-the-episode check both require the package tag.
		#
		# The cross-check: a file INSIDE a pack is an episode by construction, so the median
		# per-file size of the multi-file rows says what an episode of this show weighs without
		# trusting any name. One Piece reads 0.69 GB against the 45.30 GB above, a 66x
		# contradiction. Only a contradiction this large intervenes -- a show whose singles are
		# simply higher quality than its packs is normal and must not be touched (Re:ZERO S1
		# reads 6.8x and is correct).
		#
		# Deliberately a VETO, not a replacement. The single-file median stays the measurement
		# everywhere it is sane; the pack statistic only overrides it when it is provably
		# describing something that is not an episode. Two earlier attempts to derive this
		# threshold FROM the pack rows failed, so it is not trusted as the primary reading.
		if not one: return 0
		per_file = []
		for r in rows:
			if not isinstance(r, dict): continue
			try: n = int(r.get('num_files') or 1)
			except (TypeError, ValueError): continue
			if n < 2: continue
			try: size = float(r.get('total_size') or 0)
			except (TypeError, ValueError): continue
			if size > 0: per_file.append(size / n)
		# No pack rows to cross-check against (a film entry, or an eid query returning only
		# single files) -- nothing contradicts the reading, so keep it.
		if not (per_file and _median): return one
		typical = _median(per_file)
		if typical and one > _SINGLE_FILE_SANITY * typical: return typical
		return one

	def _is_pack(self, row, one_episode, allow_unknown=False):
		"""Several files only means a pack if it also weighs like one.

		LOCAL PATCH 2026-09-22: `allow_unknown` covers the case where one_episode could not
		be measured at all -- no single-file row in the window to take a median of. The old
		unconditional `if not one_episode: return False` then rejected EVERY row, so the
		provider returned nothing at all, silently. Measured on aid 239: a size-sorted window
		of a 220-episode show holds 0 single-file rows, so the threshold was 0 and all 137
		real packs were dropped.

		With no threshold the file count alone has to decide, which re-admits the one false
		positive the size test exists to catch -- a single episode shipping a separate
		subtitle. That is the right trade ONLY where the alternative is returning nothing, so
		it is opt-in per caller: sources() keeps the strict reading, since there a mislabel
		would relabel a real result rather than rescue a lost one."""
		try:
			if int(row.get('num_files') or 1) < 2: return False
			if not one_episode: return bool(allow_unknown)
			return float(row.get('total_size') or 0) >= 2 * one_episode
		except (TypeError, ValueError): return False

	def _build(self, row, data, package, undesirables, check_foreign_audio):
		"""One feed row -> one Fen Light source, or None if it should be dropped."""
		info_hash = (row.get('info_hash') or '').lower()
		magnet = row.get('magnet_uri')
		if not info_hash or not magnet: return None
		# Which of the two names to use depends on what the row IS.
		#   single file -> `torrent_name` is the actual filename, the most accurate thing
		#                  available, and better than the posting title.
		#   pack        -> `torrent_name` is the torrent's ROOT FOLDER, which is often
		#                  useless or unreadable. A real example: a 115-file complete-series
		#                  pack whose folder is "[Furretar] 台粤 - 进击的巨人 V5" reduces to
		#                  just "V5" once non-ASCII is stripped, losing the release entirely,
		#                  while its title reads "(Season 1-4 + Kanketsu-hen ...)". Titles
		#                  also carry the resolution and codec tags that folders omit, which
		#                  is what quality detection and the REMUX filter read.
		posting, filename = row.get('title') or '', row.get('torrent_name') or ''
		raw = (posting or filename) if package else (filename or posting)
		# Descriptive rejects, not identity ones: this only asks what KIND of thing the
		# row is, never which episode it is.
		if _DISC_STRUCTURE.search(raw): return None
		name = source_utils.clean_name(raw)
		if not name: return None
		# name_info drives Fen Light's quality and tag detection (REMUX / BLURAY / HEVC /
		# AV1 / WEB / audio codecs). Without it, scrapers/external.py falls back to parsing
		# the magnet URL, where url_strip() flattens separators to spaces and the dotted
		# tokens get_info() looks for ('.web.', '.av1.', '.sdr') can never match -- so rows
		# arrived under-tagged and were sorted and filtered wrongly.
		name_info = source_utils.info_from_name(
			name, data.get('tvshowtitle') or '', str(data.get('year') or ''),
			season=str(data.get('season') or ''), pack=package)
		# These read the name only to DESCRIBE or veto a release, never to decide which
		# episode it is. A misread here costs one row; a misread episode plays the wrong
		# thing -- which is why episode identity comes from the id and never from here.
		if source_utils.remove_lang(name_info, check_foreign_audio): return None
		if undesirables and source_utils.remove_undesirables(name_info, undesirables): return None
		try:
			seeders = int(row.get('seeders') or 0)
			if seeders < 0: seeders = 0   # AnimeTosho reports -1 for "unknown"
		except (TypeError, ValueError): seeders = 0
		if self.min_seeders > seeders: return None
		quality, info = source_utils.get_release_quality(name_info, magnet)
		# total_size is bytes, unlike the human-readable strings every other provider
		# scrapes, so it is converted here rather than via _size().
		#
		# Packs report a PER-EPISODE size computed from their own file count, and
		# scrapers/external.py is told not to divide them again (this provider is in its
		# no-divide list). That list exists because Fen Light's default is to divide a
		# pack by the TMDb season's episode_count, which for anime is routinely nothing
		# to do with what the pack holds -- TMDb files every Re:ZERO cour under season 1,
		# so its episode_count is 85 while a cour pack has 12 files, and a 65GB BD remux
		# was displaying as 0.77GB. Measured errors before this: 7.1x under for Re:ZERO,
		# 3.8x for Bleach, 2.8x for Frieren, all understated and so sorted far too low.
		#
		# num_files is not perfect -- a release shipping subtitles as separate files
		# inflates it and understates the result -- but it is the pack's own count
		# rather than an unrelated number, and it was closer in every case measured.
		try:
			total = float(row.get('total_size') or 0) / 1073741824
			files = int(row.get('num_files') or 1) if package else 1
			dsize = round(total / max(files, 1), 2)
			if dsize: info.insert(0, '%.2f GB' % dsize)
			# The full size still matters -- it is what the debrid service has to hold.
			if package and total: info.append('%.1f GB pack' % total)
		except (TypeError, ValueError): dsize = 0
		item = {'provider': 'animetosho', 'source': 'torrent', 'seeders': seeders,
				'hash': info_hash, 'name': name, 'name_info': name_info, 'quality': quality,
				'language': 'en', 'url': magnet, 'info': ' | '.join(info), 'direct': False,
				'debridonly': True, 'size': dsize}
		# LOCAL PATCH 2026-09-22: the release group, for the picker's Group column. Read
		# from `raw` because clean_name() has already stripped the leading bracket tag off
		# `name`, which is where a fansub group lives.
		group = source_utils.release_group(raw)
		if group: item['release_group'] = group
		if package: item['package'] = package
		# LOCAL PATCH 2026-09-23: tell Fen Light this pack's name names a season and no
		# episodes, so it can drop it when no file listing exists to check it against.
		# Packs only -- a single-file row is its own evidence.
		if package:
			try:
				if _declares_season_without_episodes(row): item['season_only'] = True
			except Exception: pass
		return item

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		eid = data.get('anidb_eid')
		# No eid means the chain upstream could not identify the episode (a show with no
		# Fribb cour row, or ani.zip unreachable). Returning nothing is correct -- guessing
		# from names here would reintroduce exactly what this provider avoids.
		if not eid:
			# LOCAL PATCH 2026-09-22: say so. This return is the single most common reason this
			# provider contributes nothing (no Fribb row, or ani.zip withholding an eid for a
			# whole-run entry -- Naruto, Naruto Shippuden), and it fired BEFORE the diag line at
			# the end of this method, so the log showed nothing at all and it looked like a
			# scrape that simply found no releases.
			try:
				import xbmc as _x
				_x.log('TOSHO-DIAG: sources SKIPPED, no anidb_eid (aid=%s) -- packs only for this show'
					% data.get('anidb_aid'), _x.LOGINFO)
			except Exception: pass
			return sources
		try:
			rows = self._query('eid=%s' % eid)
			if not rows: return sources
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('ANIMETOSHO')
			return sources

		one_episode = self._one_episode_size(rows)
		cour_season = data.get('cour_season')
		# LOCAL PATCH 2026-09-22: title + aliases, for cour_match's title-anchored episode
		# read. Built the same way sources_packs builds its own list.
		_titles = []
		if alias_titles:
			try: _titles = [t for t in ([data.get('tvshowtitle')] + alias_titles(data)) if t]
			except Exception: _titles = []
		seen = set()
		_cour_rejected = 0
		# LOCAL PATCH 2026-09-23: which anime a row belongs to, for the aid reject below.
		_want_aids = set()
		for _a in ([data.get('anidb_aid')] + list(data.get('anidb_part_aids') or [])):
			try:
				if _a: _want_aids.add(int(_a))
			except (TypeError, ValueError): continue
		_aid_rejected = 0
		_name_rejected = 0
		try: _want_abs = int(data.get('absolute_episode') or 0) or None
		except (TypeError, ValueError): _want_abs = None
		for row in rows:
			try:
				if not isinstance(row, dict): continue
				# LOCAL PATCH 2026-09-23: an eid query can return rows belonging to a DIFFERENT
				# anime, and those are never this episode.
				#
				# ?eid=977 (One Piece episode 10) returns 14 rows, of which 3 report
				# anidb_aid=18968 -- 'One Piece Log: Fish-Man Island Saga', a recap series that is
				# its own AniDB anime. Its episode 10 is not One Piece's episode 10. ?eid=440
				# (episode 1) carries one such row too.
				#
				# An id test, not a name test: the row states which anime it is and we state which
				# one we asked about, so nothing has to be parsed. Sibling part aids count, because
				# a split season's parts are legitimately the same show -- the same set the pack
				# query merges. Skipped entirely when we do not know our own aid, since an empty
				# expectation must not reject everything.
				if _want_aids:
					try: _ra = int(row.get('anidb_aid') or 0)
					except (TypeError, ValueError): _ra = 0
					if _ra and _ra not in _want_aids:
						_aid_rejected += 1
						continue
				# A multi-file row here is a batch that CONTAINS this eid, so it is a
				# legitimate result and is kept, labelled so Fen Light shows it as a PACK.
				package = 'season' if self._is_pack(row, one_episode) else None
				# LOCAL PATCH 2026-09-23: for a WHOLE-RUN show the name must state this episode.
				#
				# The aid reject above removes rows filed under another anime. What survives it on
				# One Piece is filed under aid 69 but speaks a different numbering: ?eid=977
				# (episode 10) returned 11 such rows -- 'Gyojin Tou-hen - 10', 'One Piece Log -
				# Fish-Man Island Saga - 10' -- and exactly ONE real episode 10. ?eid=440 (episode
				# 1) added S18E01 / S28E01 / Barto / Episode of Sabo / S00E01 on top of the real ones.
				#
				# This inverts the provider's trust-the-index principle, so it is scoped tightly:
				# only when DeadLight says the entry is the whole series (whole_run), only for single
				# files, and only against the absolute number that whole-run eid was looked up by.
				# A cour-sized entry keeps the old behaviour, where absence of evidence is not
				# evidence of absence. Measured 2026-09-23 over One Piece 1/10/500/1000/1179 and
				# Naruto 1 -- see whole_run_episode for the naming the reader has to accept.
				if data.get('whole_run') and not package and whole_run_episode and _titles:
					_nm = row.get('torrent_name') or row.get('title') or ''
					if whole_run_episode(_nm, _titles) != _want_abs:
						_name_rejected += 1
						continue
				# LOCAL PATCH 2026-09-23: a pack is exempt from cour_match below, but not from its
				# foreign-cour step. ?eid=22206 (Bleach ep 1) returned seven TYBW batches -- 'Sennen
				# Kessen Hen - 01 ~ 13', 'S17E01-E13 ... Thousand-Year Blood War' -- all filed under
				# Bleach's aid, all offered for Bleach S1E1. A batch that NAMES another cour is that
				# cour; the exemption exists for batches spanning this one, which never do.
				if package and names_foreign_cour:
					_nm = ' | '.join(n for n in (row.get('title'), row.get('torrent_name')) if n)
					if names_foreign_cour(_nm, data.get('foreign_cour_tokens')):
						_cour_rejected += 1
						continue
				# LOCAL PATCH 2026-09-15: reject a row whose NAME contradicts the cour asked for.
				# This provider trusts the index and parses no names, which is right until the
				# index is wrong -- and here it is. AnimeTosho files a batch of Re:ZERO SEASON 4
				# releases under season 1's ids: ?eid=176270 (Re:ZERO S1 ep1, via anilist 21355)
				# returned 64 rows all reporting anidb_aid=11370, nine of them plainly "S04E01".
				# Those same releases also sit correctly under eid=309964, so this is a bad file
				# match upstream, not AniDB folding the seasons together. Measured 2026-09-15:
				# cour_match dropped exactly those 9 and kept all 55 real ones.
				#
				# A REJECT, never an identity test -- the eid still decides which episode this is.
				# cour_season is Fribb's season.tvdb, the number releases actually write, never
				# TMDb's -- which is the objection sources_packs raises against filter_season_pack
				# and the reason that one stays unvalidated. Skipped when the cour context is
				# absent, so a show with no Fribb row keeps the old trust-the-index behaviour.
				# Packs are exempt: a batch spanning cours is a legitimate answer to this query.
				if cour_season and not package and cour_match:
					_nm = row.get('torrent_name') or row.get('title') or ''
					if not cour_match(_nm, cour_season=cour_season,
									cour_episode=data.get('cour_episode'),
									absolute_episode=data.get('absolute_episode'),
									season_episode=data.get('season_episode'),
									cour_part=data.get('cour_part'),
									foreign_tokens=data.get('foreign_cour_tokens'),
									titles=_titles,
									# The eid already identified this episode; the name is only being read for a
									# CONTRADICTION. See cour_match's trust_id -- a name with no season marker, or a
									# bare cour-relative number in a split season, contradicts nothing.
									trust_id=True,
									# LOCAL PATCH 2026-09-24: so JoJo's story 'Part 6' is not read as a cour part.
									cour_part_count=data.get('cour_part_count')):
						_cour_rejected += 1
						continue
				item = self._build(row, data, package, undesirables, check_foreign_audio)
				if not item or item['hash'] in seen: continue
				seen.add(item['hash'])
				sources.append(item)
			except Exception:
				source_utils.scraper_error('ANIMETOSHO')
				continue
		# LOCAL PATCH 2026-09-21: this provider reported nothing about its own work, so a
		# silent over-reject looked exactly like the index having no releases. That hid the
		# split-cour bug fixed in anime_utils.cour_match the same day: 32 rows came back for
		# eid 246509 and 5 were dropped, with nothing on screen or in the log saying so.
		# Mirrors nyaa.py's NYAA-DIAG so both anime providers report the same way.
		try:
			import xbmc as _x
			_x.log('TOSHO-DIAG: sources eid=%s raw=%d aid_rejected=%d name_rejected=%d cour_rejected=%d kept=%d'
				% (eid, len(rows), _aid_rejected, _name_rejected, _cour_rejected, len(sources)), _x.LOGINFO)
		except Exception: pass
		return sources

	# LOCAL PATCH 2026-09-22: a pack whose NAME declares an episode range must actually
	# contain the episode being scraped.
	#
	# sources_packs applies no validation because "an AniDB aid IS one cour", so every row
	# belongs to the right anime and cour. That holds for a 12-26 episode entry. It breaks
	# for a long single-entry show: Naruto is ONE aid (239) covering all 220 episodes, so
	# its packs are BOX / VOL / SET / EP-range subdivisions and "right anime" no longer
	# implies "holds this episode". Observed 2026-09-22 scraping S4E212: 21 results, among
	# them "(EP 37-50)" and "(EP 51-76)", neither of which can serve episode 212.
	#
	# This is a range REJECT, not the season parsing that docstring argues against: it reads
	# no season number and compares nothing to TMDb. A pack that declares no range is kept
	# untouched, so BOX 01 / VOL 09 / SET 1 and every cour-sized pack behave as before.
	def _pack_excludes_episode(self, row, wanted):
		"""True only when the names state a range and the wanted episode is outside it."""
		if not pack_excludes_episode: return False
		return pack_excludes_episode(_row_names(row), row.get('num_files'), wanted)


	def _spans_sibling_series(self, row, titles):
		"""The distinguishing word when a '+' segment names another series, else None."""
		if not pack_names_sibling_series: return None
		return pack_names_sibling_series(_row_names(row), titles)


	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		"""Season packs, found with the ANIME id rather than the episode id.

		Why a separate query rather than more of sources(): a batch only carries an
		anidb_eid once AnimeTosho has file-indexed it and matched its files to episodes,
		and most are never indexed. Asking by aid sidesteps that, and is where nearly all
		the packs actually live -- 42 for Bleach TYBW against 0 by eid.

		No title or season validation is applied, and `bypass_filter` is therefore unused.
		That is deliberate rather than lax: an AniDB aid IS one cour, so every row this
		query returns already belongs to the exact anime and cour being scraped. Running
		filter_season_pack over them would re-introduce the name parsing this provider
		exists to avoid AND reject correct rows -- it looks for "S02"-style markers against
		TMDb's season number, which for anime is routinely not what the release says.
		torrentio's kitsu path skips validation for the same reason.
		"""
		sources = []
		if not data: return sources
		# AniDB files an anime per cour, so there is no whole-franchise grouping to ask
		# for. Returning nothing is honest; nyaa still answers show-pack requests.
		if search_series: return sources
		aid = data.get('anidb_aid')
		if not aid: return sources
		try:
			# LOCAL PATCH 2026-09-22: ONE request, biggest rows first, at the feed's real page cap.
			#
			# Three things were learned in order, and the current shape is the third:
			#
			#  1. Ask for the BIGGEST rows, not the newest. The default order is date-descending,
			#     which on a long-running anime is an arbitrary slice -- aid 17870 has 477 rows over
			#     7 pages. Packs are the only thing this method wants and packs are by definition the
			#     large rows. `order` accepts ONLY size-d and size-a: date-d, seeders-d and a
			#     deliberately bogus value all return the default order, so there is no seeders sort
			#     to be had here and a typo fails quietly.
			#
			#  2. Sorting by size destroys the sample that sets the pack threshold, which is why this
			#     used to issue a second, unsorted request. _one_episode_size medians the SINGLE-FILE
			#     rows it is handed, and the biggest 75 rows of a long show are ALL multi-file -- so a
			#     75-row sorted page holds no single-file row at all, the median is 0, and _is_pack
			#     rejected every row. Measured: one 75-row sorted page alone returned 0 packs for
			#     Naruto, silently, while Apothecary (39) and Ace (4) looked fine.
			#
			#  3. The cap is 200, not 75 (see _PAGE_MAX), and that dissolves the problem in 2. A
			#     200-row sorted page reaches far enough down the index to contain single-file rows --
			#     25 of 200 on aid 239 -- so one request carries both the packs and its own
			#     calibration. Packs kept end to end, measured 2026-09-22:
			#
			#       config                          req   Naruto   Apothecary S1   Ace of Diamond
			#       2 sorted pages + calibration     3       62          38              4
			#       1 sorted page  + calibration     2       62          38              4
			#       1 sorted page, 200 rows          1       75          37              4
			#
			#     Strictly better than any two-request version on the show that matters, and one fewer
			#     round trip. The price is one pack on Apothecary: its 200-row window is 160 singles,
			#     so the median runs high (1.30 GB against the unsorted sample's 0.69) and the
			#     threshold with it. On aid 239 the two agree closely (0.76 vs 0.70 GB).
			#
			# The 0-packs failure in 2 is guarded rather than merely avoided: the cap is undocumented,
			# and if it ever returns to 75 a sorted window loses its singles again. _is_pack's
			# allow_unknown makes that case fall back to the file count instead of dropping everything,
			# and one_ep is now in the diag line so a zeroed threshold is visible in the log.
			# LOCAL PATCH 2026-09-22: ask every part of this season, not just the one being
			# scraped. A split season is several AniDB entries, and a pack covering the WHOLE
			# season is filed under the FIRST part's aid, so a query made from part 2's aid never
			# sees it although it plainly holds part 2's episodes. Measured, packs per part:
			#   JoJo Stone Ocean   p1 12   p2 2   p3 1
			#   Mushoku Tensei S1  p1 83   p2 13
			#   Mushoku Tensei S2  p1 39   p2 6
			# and part 1's biggest row gives it away every time -- 46 files for a 38-episode
			# Stone Ocean, 250 for Mushoku S02. Whole-season releases, not part-1 releases.
			#
			# One request per part, and a season has one part for most anime, so this costs
			# nothing at all outside split cours. Rows are merged and deduped on info_hash, and
			# every one still faces the same validation: _pack_excludes_episode against a range
			# the name declares, _spans_sibling_series, and -- for a cached pack -- the file
			# listing check in Fen Light that proves whether the episode is actually inside.
			#
			# The current aid is asked FIRST so that a partial failure still returns this part's
			# own packs, which are the ones most likely to be right.
			_aids = [aid]
			for _pa in (data.get('anidb_part_aids') or []):
				try:
					if int(_pa) != int(aid): _aids.append(int(_pa))
				except (TypeError, ValueError): continue
			# Serial on purpose. Fetching the parts in parallel was measured 2026-09-26 on JoJo Stone
			# Ocean (aids 16187/17286/17664) and gained nothing: overlapping queries each took about
			# twice as long (16187: 0.85 s alone, 2.04 s concurrent), 2.9 s total either way.
			rows, _seen_h, _own_h = [], set(), set()
			for _a in _aids:
				for _r in (self._query('aid=%s&order=size-d' % _a, pages=1, limit=_PAGE_MAX) or []):
					if not isinstance(_r, dict): continue
					_k = (_r.get('info_hash') or _r.get('magnet_uri') or '').lower()
					if _k:
						if _k in _seen_h: continue
						_seen_h.add(_k)
					rows.append(_r)
					if _k and int(_a) == int(aid): _own_h.add(_k)
			if not rows: return sources
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('ANIMETOSHO')
			return sources

		# One window, self-calibrating. A 200-row size-sorted page reaches far enough down the
		# index to include single-file rows even on a long-running show (25 of 200 on aid 239),
		# so the median that sets the pack threshold comes out of the same request as the packs.
		# Measured: sorted-200 gives 0.76 GB against the unsorted sample's 0.70 GB on aid 239 --
		# close enough that the bias which forced a separate page at 75 rows is gone. Where the
		# window is mostly singles the median still runs high (Apothecary 1.30 vs 0.69 GB), which
		# costs exactly one pack there and is the whole price.
		one_episode = self._one_episode_size(rows)
		# No single-file row in the window at all: judge on file count rather than dropping
		# everything. See _is_pack's allow_unknown.
		_no_threshold = not one_episode
		# Any of the three numberings may be the one a pack counts in, so a hit on any is
		# enough: a cour pack says 1-12 while the absolute number is 41.
		# LOCAL PATCH 2026-09-22: the COUR-RELATIVE number is dropped once sibling parts have
		# been merged in, because it is ambiguous across them -- every part restarts at 1.
		#
		# Re:ZERO S2 is two parts. Asking for part 2 episode 1 gives cour_episode=1, and a
		# PART 1 pack declaring '01~12' contains 1, so _pack_excludes_episode let it through
		# and part 1's packs appeared in part 2's results -- both parts returned an identical
		# 65. The season-relative number (13) and the absolute one (39) both count across the
		# whole season, so they cannot collide between its parts; they are the only numbers
		# that mean anything once the windows are merged. Exactly the reasoning cour_match
		# applies at its step 3b for the same reason.
		#
		# Only when siblings were actually merged. A single-part season keeps all three, where
		# the cour-relative number is often the only one a release name carries.
		# ...but ONLY for a row that came from a SIBLING part. Which numbering a declared
		# range speaks is decided by which entry the row is filed under, not by the name:
		# '[Erai-raws] Re:Zero ... 2nd Season Part 2 - 01 ~ 12' under part 2's aid counts
		# PART-relative, so its 1-12 really is this part's episodes 1-12, while the identical
		# '01~12' under part 1's aid is part 1's. Measured on Re:ZERO S2 part 2 episode 1: of
		# the 22 packs a blanket drop of the cour number rejected, 13 came from part 2's own
		# aid and were correct, 9 came from part 1's and were not.
		def _num(_key):
			try:
				_v = data.get(_key)
				return None if _v is None else int(_v)
			except (TypeError, ValueError): return None
		_wanted = set(x for x in (_num('cour_episode'), _num('season_episode'),
			_num('absolute_episode')) if x is not None)
		_wanted_sibling = set(x for x in (_num('season_episode'), _num('absolute_episode'))
			if x is not None) if len(_aids) > 1 else _wanted
		_range_rejected = _sibling_rejected = _foreign_rejected = _part_rejected = 0
		# LOCAL PATCH 2026-09-24: the part a pack NAMES outranks the aid it is filed under.
		#
		# The own/sibling choice above goes by which aid's query returned the row, and
		# AnimeTosho cross-files: of Re:ZERO S2's packs, TTGA, EMBER x2 and Beatrice-Raws 'Season
		# 2 Part 02' sit under PART 1's aid 14792, and Peekaboo 'Part 1 - 1-13' under part 2's.
		# So a part 2 request measured TTGA Part 02 (12 files, episodes 14-25) against the
		# season-wide 13 and 39, and _pack_excludes_episode's file-count rule -- which assumes a
		# pack starts at the season's episode 1 -- rejected it; Part 01 (13 files) passed the
		# same test and was offered instead. A name stating ONE part that is ours is ours, and is
		# read in our own numbering; a name stating only another part is that part.
		#
		# Only for a merged split season, and only when every declared part is a plausible one
		# (1..number of parts merged): 'JoJo's Bizarre Adventure Part 6: Stone Ocean' uses Part
		# for the story arc and must not be read as a cour.
		try: _want_part = int(data.get('cour_part') or 0) or None
		except (TypeError, ValueError): _want_part = None
		def _declared_parts(_row):
			_found = set()
			for _n in (_row.get('title'), _row.get('torrent_name')):
				if not _n: continue
				try: _found |= set(int(p) for p in (_extract_meta(_clean_for_extract(_n))[2] or ()))
				except Exception: continue
			return _found if _found and all(1 <= p <= len(_aids) for p in _found) else set()
		# Title + aliases, via anime_utils so the normalisation lives in one place.
		_titles = []
		if alias_titles:
			try: _titles = [t for t in ([data.get('tvshowtitle')] + alias_titles(data)) if t]
			except Exception: _titles = []
		seen = set()
		for row in rows:
			try:
				if not isinstance(row, dict): continue
				if not self._is_pack(row, one_episode, allow_unknown=_no_threshold): continue
				_w = _wanted if (row.get('info_hash') or '').lower() in _own_h else _wanted_sibling
				if _want_part and len(_aids) > 1 and _extract_meta:
					_dp = _declared_parts(row)
					if _dp and _want_part not in _dp:
						_part_rejected += 1
						continue
					if _dp == set([_want_part]): _w = _wanted
				if _w and self._pack_excludes_episode(row, _w):
					_range_rejected += 1
					continue
				if self._spans_sibling_series(row, _titles):
					_sibling_rejected += 1
					continue
				# LOCAL PATCH 2026-09-23: a pack naming ANOTHER cour of this TMDb show is that cour.
				# ?aid=2369 (Bleach 2004) returned 180 of 225 rows as Thousand-Year Blood War, which
				# AniDB keeps as its own entries but AnimeTosho files under Bleach's aid. The range
				# test above cannot see 'Sennen Kessen Hen - 01 ~ 13', whose range holds episode 1.
				# Measured over every multi-file row of that query and of ?eid=22206: no pack joins the
				# original run to TYBW in one name, so this rejects nothing that could serve S1.
				if names_foreign_cour and names_foreign_cour(
						' | '.join(n for n in (row.get('title'), row.get('torrent_name')) if n),
						data.get('foreign_cour_tokens')):
					_foreign_rejected += 1
					continue
				item = self._build(row, data, 'season', undesirables, check_foreign_audio)
				if not item or item['hash'] in seen: continue
				seen.add(item['hash'])
				sources.append(item)
			except Exception:
				source_utils.scraper_error('ANIMETOSHO')
				continue
		try:
			import xbmc as _x
			_x.log('TOSHO-DIAG: packs aid=%s parts=%d raw=%d one_ep=%.2fGB range_rejected=%d sibling_rejected=%d foreign_rejected=%d part_rejected=%d kept=%d wanted=%s'
				% (aid, len(_aids), len(rows), (one_episode or 0) / 1073741824.0, _range_rejected,
				_sibling_rejected, _foreign_rejected, _part_rejected, len(sources), sorted(_wanted) or '-'), _x.LOGINFO)
		except Exception: pass
		return sources
