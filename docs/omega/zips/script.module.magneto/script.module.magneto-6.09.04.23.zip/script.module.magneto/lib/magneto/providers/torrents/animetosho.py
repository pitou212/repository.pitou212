# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-27: AnimeTosho provider -- anime episodes matched by ID.
#
# WHY THIS PROVIDER IS DIFFERENT FROM EVERY OTHER ONE HERE
# The rest of this directory searches by title and then decides, from the release
# NAME, whether a row is the episode the user asked for. For anime that decision is
# not reliably decidable. The same episode ships under genuinely different, equally
# correct numbers:
#
#   Bleach TYBW premiere   -> "S01E01"  AND  "S17E01"   (both on nyaa, both correct)
#   Re:ZERO TMDb ep 50     -> "Season 2 - 24"
#   Attack on Titan S3E20  -> "S03E20 (57)"
#   Boruto ep 220          -> "- 220"
#
# nyaa.py has grown a rule for each of these shapes and every rule risks the next
# show. That is a losing shape of problem, so this provider does not play it.
#
# AnimeTosho mirrored nyaa's English-translated anime category and tagged each torrent
# with the AniDB episode id (eid) it belongs to. Fen Light resolves the eid for the
# requested episode before scraping (Fribb -> AniList id -> ani.zip -> eid, all
# cached), so this provider asks the index a question that has one right answer:
# "which torrents ARE eid 259237?" -- and does no name parsing whatsoever.
#
# Verified against the four cases above: all four return the correct episode, in
# every naming convention at once, with no filtering applied.
#
# *** THE INDEX IS FROZEN -- READ THIS BEFORE DEBUGGING AN EMPTY RESULT ***
# AnimeTosho stopped ingesting on 2026-05-08. The API still answers HTTP 200 and still
# serves everything indexed up to that date, so this provider remains genuinely useful
# for the back catalogue -- but it holds NOTHING released after it, and that share
# grows every week.
#
# The symptom is a show returning zero rows by both eid and aid while nyaa has plenty:
# Chainsmoker Cat (premiered 2026-02, indexed nowhere here) gave 0 from animetosho and
# 22 from nyaa. That is the frozen index, not a broken lookup -- checking the newest
# `timestamp` in an unfiltered /json?limit=25 call confirms it in one request.
#
# So: nyaa is what covers current seasons and must stay enabled; seadex.py (live,
# updated daily) covers curated picks; this provider covers the archive.
#
# SCOPE
# Two queries, because they find different things:
#   sources()       ?eid=<episode id>  single episodes, exact, no parsing
#   sources_packs() ?aid=<anime id>    season packs, which the eid query cannot see
# See the note on pack_capable below for why both are needed.
#
# On remux: AnimeTosho's own index leans toward encodes over raws, and none of the
# six episodes measured while building this returned a remux -- though the pack query
# does surface them (Bleach TYBW has a 76.6GB BD Remux batch). Remux rows are tagged
# rather than assumed away: `name_info` below is what lets Fen Light apply its REMUX
# filter and quality sort to them.
#
# API: https://feed.animetosho.net/json?eid=<eid>   No key. No auth. JSON list.
#
# LOCAL PATCH 2026-09-15: .org -> .net, AnimeTosho's newer domain. Both hosts run the
# same software and answer the same AniDB semantics -- verified identical JSON schema
# (28 keys, no field differs) and both correctly report anidb_eid for the queried id --
# but they are NOT mirrors: their internal `id` spaces are disjoint, so the same release
# carries a different id on each. Compare by info_hash, never by id.
#
# .net measured equal or better on 6 of 7 real aids (Steins;Gate aid=129 returned 22 rows
# on .org against 75 on .net; four others hit the 75 cap on both). The one regression was
# aid=17069, 1 row on .org and 0 on .net. Single-episode eid=259237 gave 31 on .org and 48
# on .net, sharing only 20 info_hashes -- so each still holds releases the other lacks.
# Querying both and deduping by hash would strictly beat either; not done, one request.

from magneto.modules import client
from magneto.modules import source_utils
# LOCAL PATCH 2026-09-15: sibling-cour reject, see sources(). The same helper nyaa.py uses,
# so the three competing anime numbering schemes stay implemented in exactly one place.
try:
	from magneto.modules.anime_utils import cour_match
except Exception:
	cour_match = None

try:
	from statistics import median as _median
except ImportError:
	_median = None

try:
	import json as _json
except ImportError:
	_json = None

import re

# Raw Blu-ray disc structures and disc images. These carry no episode files to pick
# from -- a BDMV is a tree of .m2ts streams under BDMV/STREAM -- so the debrid layer
# can never resolve one to an episode and the row would only ever fail on click.
# Seen for real: a 440-file 95.6GB "[BDMV] Attack on Titan Season 4 Part 2 [US]" row
# returned under the Season 3 aid.
_DISC_STRUCTURE = re.compile(r'(?:^|[^a-z0-9])(?:bdmv|m2ts|iso|disc\s?\d|bdiso)(?:[^a-z0-9]|$)', re.I)


class source:
	priority = 5
	# LOCAL PATCH 2026-08-27 (revised): was False. sources() alone can only ever see
	# batches that AnimeTosho has file-indexed and matched to episodes -- most are not,
	# so they sit at anidb_eid=None and an ?eid= query cannot return them. Measured:
	#
	#   anime          packs via ?eid=   packs via ?aid=
	#   Frieren S2            0                10
	#   Bleach TYBW           0                42     <- incl. a 76.6GB BD Remux
	#   Re:ZERO S2 P2         2                16
	#   AoT S3 P2             0                29
	#
	# sources_packs() closes that by asking with the ANIME id instead. Two things make
	# it safe, and neither was true before this week: the aid comes from Fribb offline
	# (so the pack path needs no ani.zip at all), and the debrid layer can now pick the
	# right file out of an anime pack (the 2026-08-27 cour-numbering fix) -- without
	# that, every pack returned here would have failed on click.
	pack_capable = True
	# Anime films are one AniDB episode too, but Fen Light only resolves an eid on the
	# episode path, so a movie scrape would always no-op. Left off until it passes one.
	hasMovies = False
	hasEpisodes = True

	def __init__(self):
		self.language = ['en']
		# ONE index, two domains. .net is the live host; .xyz serves the same data and is
		# tried only when .net cannot be reached -- measured identical by info_hash (48/48
		# and 75/75, zero exclusives either way), so asking both would return the same rows
		# twice and the dedupe would drop every one.
		#
		# feed.animetosho.ORG IS DEAD AND MUST NOT BE ADDED BACK. It still answers HTTP 200
		# with a full-looking payload, which is exactly the trap: its index STOPPED UPDATING
		# on 2026-05-07. Measured 2026-09-15 on the `timestamp` field --
		#
		#   Re:ZERO S4  aid=19242 : .net newest 2026-09-14   .org newest 2026-05-07
		#   Bleach TYBW eid=259237: .net newest 2025-03-22   .org newest 2022-12-28
		#
		# so it looked like a second index worth merging (75 rows on Re:ZERO sharing NOTHING
		# with .net) when those rows were simply everything .net had already moved past. For
		# a currently-airing show it can only contribute stale, likely-dead torrents and one
		# wasted request per scrape. Freshness here is the `timestamp` field, not HTTP status.
		self.base_link = 'https://feed.animetosho.net'
		# NOT self.sources -- that name is the provider's own sources() METHOD, and assigning
		# it here silently replaced the bound method with a tuple. The loader hands the class
		# to Fen Light, which calls module().sources(data, hostDict); with the attribute set,
		# every scrape died on "'tuple' object is not callable" and animetosho returned zero
		# rows while every other provider looked fine.
		self.feed_hosts = ((self.base_link, 'https://feed.animetosho.xyz'),)
		# Matches nyaa.py: this provider is debrid-only, and a 0-seeder torrent can
		# still be cached and instantly playable, so seeders must not gate it here.
		self.min_seeders = 0

	# LOCAL PATCH 2026-09-15: query BOTH hosts and merge, deduped on info_hash.
	#
	# .net and .org run the same software over INDEPENDENTLY BUILT indexes -- neither is a
	# mirror of the other and neither is a superset. Measured 2026-09-15 on eid=259237:
	# .org 31 rows, .net 48, sharing only 20 info_hashes. So .org held 11 releases .net
	# could not see and .net held 28 .org could not. Asking one host silently costs results.
	#
	# Dedupe is on info_hash and NEVER on `id`: the two hosts number their rows separately,
	# so the same release carries a different id on each and an id-keyed merge would return
	# every duplicate twice. magnet_uri is the fallback key for a row with no hash.
	#
	# Hosts are tried in order and a failing one is skipped, so this is also the failover:
	# either host being down degrades results rather than emptying them. Cost is one extra
	# request per query, both keyless and ~0.9s.
	def _fetch_index(self, host, params, pages):
		"""All pages from ONE host, or None if the host could not be reached.

		None and [] mean different things and the caller depends on it: None is "ask this
		index's other domain", [] is "this index answered and genuinely has nothing"."""
		out = []
		for page in range(1, pages + 1):
			url = '%s/json?%s&limit=75%s' % (host, params,
										'&page=%d' % page if page > 1 else '')
			try:
				batch = _json.loads(client.request(url, timeout=10) or '[]')
			except Exception:
				return None if not out else out
			if not isinstance(batch, list): return None if not out else out
			out.extend(batch)
			if len(batch) < 75: break
		return out

	def _query(self, params, pages=1):
		"""Rows from every index, deduped on info_hash.

		One entry in self.feed_hosts is one INDEX; its domains are interchangeable, so the first
		that answers wins and the rest are skipped -- querying an alias would return the same
		rows and every one would be dropped by the dedupe anyway. Indexes, by contrast, hold
		different releases and are all merged.

		Dedupe is on info_hash and NEVER on `id`: the indexes number rows separately, so the
		same release carries a different id on each and an id-keyed merge would double every
		shared row. magnet_uri is the fallback key for a row carrying no hash.
		"""
		rows, seen = [], set()
		for domains in self.feed_hosts:
			for host in domains:
				batch = self._fetch_index(host, params, pages)
				if batch is None: continue          # unreachable -- try this index's alias
				for row in batch:
					if not isinstance(row, dict): continue
					key = (row.get('info_hash') or row.get('magnet_uri') or '').lower()
					if key:
						if key in seen: continue
						seen.add(key)
					rows.append(row)
				break                                # this index answered; skip its aliases
		return rows

	def _one_episode_size(self, rows):
		"""What one episode of this anime weighs, from the single-file rows in `rows`.

		Self-calibrating on purpose. A hardcoded "packs are over N GB" would be wrong
		across a 350MB SD show and a 3GB 1080p one, and reading "Batch" out of the title
		would be the name parsing this provider exists to avoid. The separation is wide:
		real batches measured at 18.5x and 45.7x the median, while the false positive
		this rejects -- one episode shipping a separate subtitle file -- sat at 0.5x.
		"""
		singles = [r.get('total_size') or 0 for r in rows
				if isinstance(r, dict) and int(r.get('num_files') or 1) == 1]
		singles = [x for x in singles if x > 0]
		return _median(singles) if (singles and _median) else 0

	def _is_pack(self, row, one_episode):
		"""Several files only means a pack if it also weighs like one."""
		try:
			if int(row.get('num_files') or 1) < 2: return False
			if not one_episode: return False
			return float(row.get('total_size') or 0) >= 2 * one_episode
		except (TypeError, ValueError): return False

	def _build(self, row, data, package, undesirables, check_foreign_audio):
		"""One feed row -> one Fen Light source, or None if it should be dropped."""
		info_hash = (row.get('info_hash') or '').lower()
		magnet = row.get('magnet_uri')
		if not info_hash or not magnet: return None
		# Which of the two names to use depends on what the row IS.
		#   single file -> `torrent_name` is the actual filename, the most accurate thing
		#                  available, and better than the posting title.
		#   pack        -> `torrent_name` is the torrent's ROOT FOLDER, which is often
		#                  useless or unreadable. A real example: a 115-file complete-series
		#                  pack whose folder is "[Furretar] 台粤 - 进击的巨人 V5" reduces to
		#                  just "V5" once non-ASCII is stripped, losing the release entirely,
		#                  while its title reads "(Season 1-4 + Kanketsu-hen ...)". Titles
		#                  also carry the resolution and codec tags that folders omit, which
		#                  is what quality detection and the REMUX filter read.
		posting, filename = row.get('title') or '', row.get('torrent_name') or ''
		raw = (posting or filename) if package else (filename or posting)
		# Descriptive rejects, not identity ones: this only asks what KIND of thing the
		# row is, never which episode it is.
		if _DISC_STRUCTURE.search(raw): return None
		name = source_utils.clean_name(raw)
		if not name: return None
		# name_info drives Fen Light's quality and tag detection (REMUX / BLURAY / HEVC /
		# AV1 / WEB / audio codecs). Without it, scrapers/external.py falls back to parsing
		# the magnet URL, where url_strip() flattens separators to spaces and the dotted
		# tokens get_info() looks for ('.web.', '.av1.', '.sdr') can never match -- so rows
		# arrived under-tagged and were sorted and filtered wrongly.
		name_info = source_utils.info_from_name(
			name, data.get('tvshowtitle') or '', str(data.get('year') or ''),
			season=str(data.get('season') or ''), pack=package)
		# These read the name only to DESCRIBE or veto a release, never to decide which
		# episode it is. A misread here costs one row; a misread episode plays the wrong
		# thing -- which is why episode identity comes from the id and never from here.
		if source_utils.remove_lang(name_info, check_foreign_audio): return None
		if undesirables and source_utils.remove_undesirables(name_info, undesirables): return None
		try:
			seeders = int(row.get('seeders') or 0)
			if seeders < 0: seeders = 0   # AnimeTosho reports -1 for "unknown"
		except (TypeError, ValueError): seeders = 0
		if self.min_seeders > seeders: return None
		quality, info = source_utils.get_release_quality(name_info, magnet)
		# total_size is bytes, unlike the human-readable strings every other provider
		# scrapes, so it is converted here rather than via _size().
		#
		# Packs report a PER-EPISODE size computed from their own file count, and
		# scrapers/external.py is told not to divide them again (this provider is in its
		# no-divide list). That list exists because Fen Light's default is to divide a
		# pack by the TMDb season's episode_count, which for anime is routinely nothing
		# to do with what the pack holds -- TMDb files every Re:ZERO cour under season 1,
		# so its episode_count is 85 while a cour pack has 12 files, and a 65GB BD remux
		# was displaying as 0.77GB. Measured errors before this: 7.1x under for Re:ZERO,
		# 3.8x for Bleach, 2.8x for Frieren, all understated and so sorted far too low.
		#
		# num_files is not perfect -- a release shipping subtitles as separate files
		# inflates it and understates the result -- but it is the pack's own count
		# rather than an unrelated number, and it was closer in every case measured.
		try:
			total = float(row.get('total_size') or 0) / 1073741824
			files = int(row.get('num_files') or 1) if package else 1
			dsize = round(total / max(files, 1), 2)
			if dsize: info.insert(0, '%.2f GB' % dsize)
			# The full size still matters -- it is what the debrid service has to hold.
			if package and total: info.append('%.1f GB pack' % total)
		except (TypeError, ValueError): dsize = 0
		item = {'provider': 'animetosho', 'source': 'torrent', 'seeders': seeders,
				'hash': info_hash, 'name': name, 'name_info': name_info, 'quality': quality,
				'language': 'en', 'url': magnet, 'info': ' | '.join(info), 'direct': False,
				'debridonly': True, 'size': dsize}
		if package: item['package'] = package
		return item

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		eid = data.get('anidb_eid')
		# No eid means the chain upstream could not identify the episode (a show with no
		# Fribb cour row, or ani.zip unreachable). Returning nothing is correct -- guessing
		# from names here would reintroduce exactly what this provider avoids.
		if not eid: return sources
		try:
			rows = self._query('eid=%s' % eid)
			if not rows: return sources
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('ANIMETOSHO')
			return sources

		one_episode = self._one_episode_size(rows)
		cour_season = data.get('cour_season')
		seen = set()
		for row in rows:
			try:
				if not isinstance(row, dict): continue
				# A multi-file row here is a batch that CONTAINS this eid, so it is a
				# legitimate result and is kept, labelled so Fen Light shows it as a PACK.
				package = 'season' if self._is_pack(row, one_episode) else None
				# LOCAL PATCH 2026-09-15: reject a row whose NAME contradicts the cour asked for.
				# This provider trusts the index and parses no names, which is right until the
				# index is wrong -- and here it is. AnimeTosho files a batch of Re:ZERO SEASON 4
				# releases under season 1's ids: ?eid=176270 (Re:ZERO S1 ep1, via anilist 21355)
				# returned 64 rows all reporting anidb_aid=11370, nine of them plainly "S04E01".
				# Those same releases also sit correctly under eid=309964, so this is a bad file
				# match upstream, not AniDB folding the seasons together. Measured 2026-09-15:
				# cour_match dropped exactly those 9 and kept all 55 real ones.
				#
				# A REJECT, never an identity test -- the eid still decides which episode this is.
				# cour_season is Fribb's season.tvdb, the number releases actually write, never
				# TMDb's -- which is the objection sources_packs raises against filter_season_pack
				# and the reason that one stays unvalidated. Skipped when the cour context is
				# absent, so a show with no Fribb row keeps the old trust-the-index behaviour.
				# Packs are exempt: a batch spanning cours is a legitimate answer to this query.
				if cour_season and not package and cour_match:
					_nm = row.get('torrent_name') or row.get('title') or ''
					if not cour_match(_nm, cour_season=cour_season,
									cour_episode=data.get('cour_episode'),
									absolute_episode=data.get('absolute_episode'),
									season_episode=data.get('season_episode'),
									cour_part=data.get('cour_part'),
									foreign_tokens=data.get('foreign_cour_tokens')):
						continue
				item = self._build(row, data, package, undesirables, check_foreign_audio)
				if not item or item['hash'] in seen: continue
				seen.add(item['hash'])
				sources.append(item)
			except Exception:
				source_utils.scraper_error('ANIMETOSHO')
				continue
		return sources

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		"""Season packs, found with the ANIME id rather than the episode id.

		Why a separate query rather than more of sources(): a batch only carries an
		anidb_eid once AnimeTosho has file-indexed it and matched its files to episodes,
		and most are never indexed. Asking by aid sidesteps that, and is where nearly all
		the packs actually live -- 42 for Bleach TYBW against 0 by eid.

		No title or season validation is applied, and `bypass_filter` is therefore unused.
		That is deliberate rather than lax: an AniDB aid IS one cour, so every row this
		query returns already belongs to the exact anime and cour being scraped. Running
		filter_season_pack over them would re-introduce the name parsing this provider
		exists to avoid AND reject correct rows -- it looks for "S02"-style markers against
		TMDb's season number, which for anime is routinely not what the release says.
		torrentio's kitsu path skips validation for the same reason.
		"""
		sources = []
		if not data: return sources
		# AniDB files an anime per cour, so there is no whole-franchise grouping to ask
		# for. Returning nothing is honest; nyaa still answers show-pack requests.
		if search_series: return sources
		aid = data.get('anidb_aid')
		if not aid: return sources
		try:
			# Two pages: batches are heavily front-loaded (Bleach TYBW gave 42 on page 1,
			# then 4, then 2), so a third page costs a round trip for almost nothing.
			rows = self._query('aid=%s' % aid, pages=2)
			if not rows: return sources
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('ANIMETOSHO')
			return sources

		one_episode = self._one_episode_size(rows)
		seen = set()
		for row in rows:
			try:
				if not isinstance(row, dict): continue
				if not self._is_pack(row, one_episode): continue
				item = self._build(row, data, 'season', undesirables, check_foreign_audio)
				if not item or item['hash'] in seen: continue
				seen.add(item['hash'])
				sources.append(item)
			except Exception:
				source_utils.scraper_error('ANIMETOSHO')
				continue
		return sources
