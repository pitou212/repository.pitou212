# -*- coding: utf-8 -*-
"""Anime release-name parsing, shared by the magneto providers.

LOCAL PATCH 2026-08-27. Extracted verbatim from providers/torrents/nyaa.py, which
was the only place in magneto that could read an anime release name. comet needs
the same parsing for its kitsu path, and duplicating it would have meant two
copies of some very fiddly regexes drifting apart.

Nothing here is new and nothing existing changed behaviour: source_utils.check_title
and the rest of the shared matcher are untouched, so non-anime scraping is
unaffected. The names keep their leading underscores so nyaa.py needed no edits
beyond the import.

What this handles that the western matcher cannot:
  - season markers inside brackets: "(Season 3)", "[S01-02]"
  - the absolute-numbering convention: "S03E20.(57)" is ONE episode, not 20-57
  - bare ordinals: "Re:Zero ... 4th - 01~11" is season 4
  - cour/part ranges: "Season 3 Part 2 - 01 ~ 10"
"""
import re


_TOKEN_STOPWORDS = frozenset((
	'the', 'and', 'of', 'a', 'an', 'in', 'on', 'to', 'for',
	'season', 'part', 'cour', 'movie', 'ova', 'tv', 'anime',
	'no', 'wa', 'ga', 'ni', 'wo', 'ka', 'kara', 'made',
))

_ROMAN_MAP = {'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5}
_WORD_MAP = {'first': 1, 'second': 2, 'third': 3, 'fourth': 4, 'fifth': 5,
			 'sixth': 6, 'seventh': 7, 'eighth': 8}

# Otaku-style: strip quality/codec/audio noise BEFORE regex-extracting season/ep.
_NOISE_PATTERNS = re.compile(
	r'\b(?:360p|480p|576p|720p|1080p|1440p|2160p|4k)(?!\d)'
	r'|\b10\s?bits?\b'
	r'|\b(?:h\.?\s?264|x\.?\s?264|h\.?\s?265|x\.?\s?265|hevc|avc|hls|vp9|av1)(?!\d)'
	r'|\b(?:web-dl|webrip|bluray|hdrip|dvdrip|hdtv|pdtv|cam|screener|bdrip)\b'
	r'|\b(?:hdr10\+?|hdr|sdr|dv|dolby\s?vision|dovi)\b'
	r'|\b(?:mp4|mkv|mpeg|xvid|divx|wmv|flac)\b'
	r'|\b(?:aac|mp3|opus|ddp|dd|ac3|dts(?:-hdma|-hdhr|-x)?|atmos|truehd)(?:\d+(?:\.\d+)?)?\b'
	r'|\b(?:1\.0|2\.0|5\.1|7\.1|2ch|5ch|7ch|8ch)\b'
	r'|\b(?:multi\s?audio|dual\s?audio|dub(?:bed)?|multi\s?sub|subbed|multi[- ]?sub(?:title)?s?)\b'
	, re.I
)


def _tokenize(text):
	"""Lowercase word tokens of length >=3, stopwords removed."""
	if not text: return set()
	words = re.findall(r'[A-Za-z0-9]+', str(text).lower())
	return {w for w in words if len(w) >= 3 and w not in _TOKEN_STOPWORDS}


# LOCAL PATCH 2026-08-27: contiguous title matching.
#
# The accept_tokens guard below accepts a row when it shares ANY ONE token with the
# title set. For Re:ZERO that set is {zero, starting, life, another, world, different,
# from}, so a single generic word was enough and these all came through as Re:ZERO:
#
#   Fate.Zero / Aldnoah.Zero / Eden.Zero / Ga-Rei-Zero / Zero.no.Tsukaima   (zero)
#   The.World's.Finest.Assassin...                                        (world)
#   Steins;Gate / Our.Dating.Story...                                     (one word)
#
# Overlap SIZE cannot separate them: the romaji 'Re:Zero kara Hajimeru Isekai
# Seikatsu' also shares exactly one token (zero) and is legitimate. What does separate
# them is ADJACENCY -- a real release contains a title candidate as consecutive words.
# 'Ga Rei Zero' never contains the pair (re, zero); 'Re Zero kara ...' always does.
#
# Measured over 6 shows / 211 accepted rows: drops exactly the 10 wrong-show entries,
# keeps all 201 legitimate ones.
#
# Apostrophes are deleted rather than treated as separators so that TMDb's
# "Journey's End" and a group's "Journeys.End" produce the same token run.
_APOS = re.compile('[' + chr(39) + chr(0x2019) + chr(0x02BC) + ']')


def _title_seq(text):
	"""Ordered alphanumeric word run. Keeps short words -- adjacency needs them."""
	return re.findall(r'[a-z0-9]+', _APOS.sub('', str(text or '').lower()))


# What may legally sit next to a title match. Anything else means the name belongs to
# a DIFFERENT, longer-titled show: 'Boruto - Naruto Next Generations' and 'Naruto
# Shippuden' both contain 'Naruto' and are separate TMDb shows, so plain containment
# lets them answer a Naruto request.
_TITLE_EDGE_OK = re.compile(
	r'^(?:\d+|\d+(?:st|nd|rd|th)|s\d+\w*|e\d+|v\d+|ep\d*|complete|series|batch|collection|season|seasons|'
	r'part|parts|pt\d*|cour|vol|volume|movie|movies|ova|oad|oav|special|specials|nc\w*|'
	r'bd|bdrip|bdmv|bluray|blu|ray|web|webrip|webdl|dl|dvd|dvdrip|remux|hevc|avc|hdr|'
	r'x264|x265|h264|h265|av1|xvid|aac|flac|opus|ac3|eac3|dts|truehd|dual|multi|'
	r'eng|jpn|jap|esp|ita|fre|ger|por|sub|subs|subbed|subtitle|subtitles|dub|dubbed|'
	r'raw|final|arc|the|and|uncut|uncensored|censored|repack|proper|hi10|10bit|8bit|'
	# LOCAL PATCH 2026-08-27: the same structural words in the other languages release
	# groups use. Without them a legitimate 'Naruto (Integrale) VOSTFR' was rejected,
	# because 'integrale' looked like a word from some other show's title.
	r'integrale|integral|integrali|complet|completa|completo|completos|coffret|'
	r'stagione|saison|temporada|staffel|sezon|serie|boxset|vostfr|truefrench|'
	r'castellano|latino|dublado|legendado)$',
	re.I)


def _seq_matches(name_seq, cand_seqs):
	"""True when any candidate matches the row, as consecutive words or joined.

	A match must sit on clean boundaries. Without that, containment alone makes every
	longer show name that happens to include ours look like a hit -- a Naruto scrape
	filled up with 'Boruto - Naruto Next Generations' and 'Naruto Shippuden', both
	separate TMDb shows. Having several candidates makes this cheap to satisfy: only
	one of them has to match cleanly, so 'Attack on Titan (Shingeki no Kyojin) - 01'
	still passes on the alias even though the primary title is followed by a word.

	The joined form covers groups that drop separators entirely:
	  'Attack.on.TitanShingeki.no.Kyojin...' -> (.., titanshingeki, ..)
	  'SPYFAMILY../.SPYxFAMILY.-.01...'      -> the × in SPY×FAMILY is stripped
	It cannot honour boundaries, so it needs a length that cannot collide by accident:
	at 6 it matched 'naruto' inside 'borutonarutonextgenerations' and readmitted every
	row the boundary check had just rejected. 10 still covers both cases above
	("attackontitan", "spyxfamily").
	"""
	if not cand_seqs: return True
	# LOCAL PATCH 2026-08-27: a neighbouring word belonging to one of OUR OWN candidate
	# titles is not evidence of a different show. Release names carry the title twice in
	# two forms all the time -- 'Naruto/NARUTO --][001-220TV][BOX1-8]' -- and the plain
	# edge rule read the second copy as a foreign title word and threw the row away.
	# This cannot readmit what the rule exists to block: 'boruto' and 'shippuden' are not
	# words of the Naruto candidates, so those still reject.
	cand_words = set(w for c in cand_seqs for w in c)
	for cand in cand_seqs:
		n = len(cand)
		if not n or n > len(name_seq): continue
		for i in range(len(name_seq) - n + 1):
			if name_seq[i:i + n] != cand: continue
			before = name_seq[i - 1] if i > 0 else None
			after = name_seq[i + n] if i + n < len(name_seq) else None
			# a short neighbour is noise ('Naruto HD (001-220)'), a long one is a title word
			if before is not None and len(before) >= 4:
				if not _TITLE_EDGE_OK.match(before) and before not in cand_words: continue
			if after is not None and len(after) > 2:
				if not _TITLE_EDGE_OK.match(after) and after not in cand_words: continue
			return True
	joined = ''.join(name_seq)
	for cand in cand_seqs:
		cj = ''.join(cand)
		if len(cj) >= 10 and cj in joined: return True
	return False


_BRACKET_GROUP = re.compile(r'\[(.*?)\]|\((.*?)\)')
# Bracketed episode ranges have to survive too: '(26-50)' is how a season-2 batch is
# labelled when the group counts episodes from the start of the series. Stripping it
# left no episode at all, so the row read as a bare batch and matched every episode
# of every season. The lookarounds are what exclude year spans: without them
# '2011-2018' still matches, because \d{1,3} happily binds to '011-201' inside it.
# LOCAL PATCH 2026-09-22: the endpoints may carry an 'E'. '[sam] ... (S01) (E01-E12)'
# put its only episode range inside a bracket group, and with no bare digit on either
# side of the dash this pattern did not match, so the group was discarded whole and the
# pack read as a bare batch -- then offered for E13 and E14, which it cannot hold. The
# 'S01 E18-E25' form never showed this, because _PK_RNG_SE reads that off the
# unbracketed text before bracket handling matters.
_RANGEISH = re.compile(r'(?<![\da-z])e?\d{1,3}\s*(?:[-~]|\bto\b)\s*e?\d{1,3}(?!\d)', re.I)
_SEASONISH = re.compile(r'\bseason\b|\bs\d{1,2}|\bcour\b|\bpart\b|\d{1,2}(?:st|nd|rd|th)\s*season', re.I)


def _keep_if_seasonish(m):
	"""Keep a bracket group's text when it carries season/part info, else drop it."""
	inner = m.group(1) if m.group(1) is not None else m.group(2)
	if inner and (_SEASONISH.search(inner) or _RANGEISH.search(inner)):
		return ' ' + inner + ' '
	return ' '


def _clean_for_extract(name):
	"""Strip quality/codec/audio noise + brackets so numeric extraction is unambiguous.
	magneto's clean_name has already converted spaces to dots; we normalize back."""
	s = name.lower().replace('.', ' ').replace('_', ' ')
	# LOCAL PATCH 2026-08-27: was a blanket strip of every (...) and [...] group.
	# That also deleted the season, because plenty of groups write it inside the
	# brackets: 'Re:Zero kara Hajimeru Isekai Seikatsu (Season 3) [1080p]' reduced
	# to 're zero kara hajimeru isekai seikatsu'. With no season parsed, the guard
	# in sources() ('if seasons and season_num not in seasons') sees an empty set,
	# reads it as 'makes no season claim', and lets the row through -- so every
	# (Season N) release surfaced under every season. Unbracketed 'S03' was fine,
	# which is why this hid for so long.
	#
	# Groups whose text mentions a season/part/cour keep their contents (brackets
	# dropped); everything else is still discarded, so quality tags and CRC32
	# stamps cannot leak digits into episode parsing. CRC32 is hex, so it cannot
	# contain the 's' that _SEASONISH needs.
	s = _BRACKET_GROUP.sub(_keep_if_seasonish, s)
	# A truncated name can leave an UNCLOSED bracket, which the pattern above cannot
	# match and therefore cannot remove. comet cuts long filenames at ~70 chars:
	#   'Re-Zero-...-3rd-season--16-(BS11-1920x1080-..'
	# leaving '(bs11-1920x1080-' in the text, where the episode scan read '11-1920'
	# as a range and matched practically any episode. Cut from the stray opener on.
	s = re.sub(r'[(\[][^)\]]*$', ' ', s)
	s = _NOISE_PATTERNS.sub(' ', s)
	s = re.sub(r'\s+', ' ', s).strip()
	return s


# Unified extractors — run on the CLEANED text.
_EX_SEASON = re.compile(r'\bs(?:eason)?[ ._-]?(\d{1,2})(?!\d)', re.I)
_EX_SEASON_ORD = re.compile(r'\b(\d{1,2})(?:st|nd|rd|th)\s+season\b', re.I)
# LOCAL PATCH 2026-08-27: bare ordinal season, used ONLY as a fallback (see below).
# Anime releases frequently drop the word 'season' entirely -- 'Re:Zero kara Hajimeru
# Isekai Seikatsu 4th - 01~11][67~77]' is season 4, and 'Spy x Family 2nd - 01' is
# season 2. Both were parsed as making no season claim, so they passed the season
# guard for every season and showed up under season 1.
#
# The negative lookahead skips ordinals that are not seasons ('10th Anniversary',
# '2nd Movie', '4th Plate'). Checked over 6 shows / 211 rows: every bare-ordinal hit
# was a real season marker, and the ones already carrying the word 'season' are
# resolved by _EX_SEASON_ORD first, so this never runs on them.
# LOCAL PATCH 2026-08-27: season RANGE, e.g. '[S01-02]', 'S01-S04', 'S1-S3'.
# _EX_SEASON alone matched just the 's01' and left the '-02' dangling, which the
# episode pass then read as episode 2 -- so an S01-04 complete-series pack announced
# itself as episode 2 and matched nothing else. Both endpoints are taken and the
# span expanded, which is what a multi-season pack actually covers.
# Requires the dash straight after the season number, so 'S02E06-08' (an EPISODE
# range) and 'S01.E01-E14' are left for the episode logic.
# LOCAL PATCH 2026-08-27: a season RANGE needs the 's' on both ends, or no spaces
# around the separator. Without that constraint the extremely common anime form
# 'Attack on Titan S3 - 08' parsed as seasons 3 THROUGH 8: the episode number was
# read as the far end of a season range. Every such release then looked like a
# six-season batch with no episode information, so it was accepted for virtually
# any request -- part 1 episodes answering part 2, and worse. Real season ranges
# are written 'S01-S04', 'S01 - S04' or 'S01-04'; all still match.
_EX_SEASON_RANGE = re.compile(r'\bs(\d{1,2})(?:\s*[-~]\s*s|[-~])(\d{1,2})\b', re.I)
_EX_SEASON_ORD_BARE = re.compile(r'\b(\d{1,2})(?:st|nd|rd|th)\b(?!\s*(?:anniversary|ann\b|movie|ova|special|plate))', re.I)
_EX_SEASON_ACT = re.compile(r'\bact\s+(i{1,3}v?|iv|v)\b', re.I)
_EX_SEASON_WORD = re.compile(r'\b(first|second|third|fourth|fifth|sixth|seventh|eighth)\s+season\b', re.I)
# Roman numeral as standalone token — used only when NO other season signal found.
# Catches "Mushoku Tensei III", "Overlord IV", "Attack on Titan II" style sequel naming.
# Skips bare "I" (too false-positive-prone: single letter, common in titles).
_EX_SEASON_ROMAN = re.compile(r'\b(ii|iii|iv|v|vi|vii|viii)\b', re.I)
_EX_PART = re.compile(r'\b(?:part|cour)\s?(\d+)\b', re.I)
_EX_SXX_EYY = re.compile(r's(\d{1,2})e(\d{1,4})', re.I)
# The trailing guard keeps a resolution out of the range: in 'x264-1920x1080' the
# pair 264-1920 otherwise parses as an episode range covering 1657 episodes.
# LOCAL PATCH 2026-08-27: 'to' joins a range as well as '-' and '~'. Without it a
# pack named 'NARUTO (2002) - Episodes 031 to 040' yielded no episode numbers at
# all, so cour_match fell through to its batch rule and accepted it for ANY
# episode -- it was answering requests for episode 159. With the range parsed the
# same pack is correctly rejected for 159 and correctly accepted for 35.
# LOCAL PATCH 2026-09-22: optional 'E' on either endpoint, so 'E01-E12' reads the same
# as '01-12'. The lookbehind stops the first number binding to the tail of a word.
_EX_EP_RANGE = re.compile(r'(?<![a-z])e?(\d{1,4})\s*(?:[~\-]|\bto\b)\s*e?(\d{1,4})(?![\dxp])', re.I)
_EX_EP_DASH = re.compile(r'(?:^|\s)-\s*(\d{1,4})(?!\d)')
# LOCAL PATCH 2026-09-22: a span BOUND TO a volume/box/disc word counts volumes, not
# episodes. '(Vol 01-02)' is two Blu-ray volumes and 'Vol.01~04' is four, but both
# parsed as episodes 1-2 and 1-4, so a 150-file BD set was rejected for every episode
# from 3 up.
#
# The binding is the whole point, and the reason this is not a name-wide test: Naruto's
# '[DBD-Raws][193-220TV][BOX8]' and '[001-027TV][Vol.01]' carry a REAL episode range in
# a token separate from the volume marker, and 9 such packs parse correctly today.
# Suppressing any range that merely shares a name with 'BOX' would destroy them, so only
# the digits the volume word itself introduces are removed.
_EX_VOLUME_SPAN = re.compile(r'\b(?:vol|volume|box|disc|disk|set)[^a-z0-9]{0,2}\d{1,3}(?:\s*(?:[-~]|\bto\b)\s*\d{1,3})?', re.I)
_EX_EP_PREFIX = re.compile(r'\b(?:episode|ep|e)\s*(\d{1,4})(?!\d)', re.I)


def _strip_season_ranges(text, seasons=None):
	"""Remove genuine season ranges ("S01-02", "S01-S04") and record them.

	Only spans that validate are removed. The pattern also matches a season marker
	followed by an episode range -- 'S2 - 01~10' looks like s=2..01 -- and blanket
	removal there destroyed both the S2 marker and the episode range, so the row
	ended up with no season and no episode at all."""
	out, last = [], 0
	for m in _EX_SEASON_RANGE.finditer(text):
		try: a, b = int(m.group(1)), int(m.group(2))
		except (TypeError, ValueError): continue
		if not (0 < a < b <= 50): continue   # descending or implausible: not a season range
		if seasons is not None: seasons.update(range(a, b + 1))
		out.append(text[last:m.start()]); out.append(' '); last = m.end()
	out.append(text[last:])
	return ''.join(out)


def _extract_meta(cleaned):
	"""Return (seasons:set, episodes:set|None, part_nums:set, is_range:bool).
	episodes is None when no episode number could be pulled — bare batches."""
	seasons = set()
	episodes = set()
	parts = set()
	is_range = False

	# --- season ---
	# LOCAL PATCH 2026-08-27: ORDER MATTERS here. The '<N>th season' / 'second
	# season' / 'act II' forms are read and then REMOVED before the plain
	# 'season <N>' scan, because otherwise the number that follows them is counted
	# as a second season:
	#   'Re:Zero ... 2nd Season 1~13' -> ORD gives 2, then _EX_SEASON matches
	#   'Season 1' out of 'Season 1~13', where that 1 opens the EPISODE range.
	# That produced seasons={1,2}; the guard in sources() only needs the requested
	# season to appear somewhere in the set, so a season-2 batch passed a season-1
	# scrape. Consuming the explicit forms first leaves nothing for the plain scan
	# to misread.
	_season_scan = cleaned
	_season_scan = _strip_season_ranges(_season_scan, seasons)
	for m in _EX_SEASON_ORD.finditer(_season_scan):
		try: seasons.add(int(m.group(1)))
		except: pass
	_season_scan = _EX_SEASON_ORD.sub(' ', _season_scan)
	for m in _EX_SEASON_WORD.finditer(_season_scan):
		w = m.group(1).lower()
		if w in _WORD_MAP: seasons.add(_WORD_MAP[w])
	_season_scan = _EX_SEASON_WORD.sub(' ', _season_scan)
	for m in _EX_SEASON_ACT.finditer(_season_scan):
		r = m.group(1).lower()
		if r in _ROMAN_MAP: seasons.add(_ROMAN_MAP[r])
	_season_scan = _EX_SEASON_ACT.sub(' ', _season_scan)
	for m in _EX_SEASON.finditer(_season_scan):
		try: seasons.add(int(m.group(1)))
		except: pass
	# Fallback: bare ordinal ('4th', '2nd') when nothing above claimed a season.
	if not seasons:
		for m in _EX_SEASON_ORD_BARE.finditer(cleaned):
			try:
				seasons.add(int(m.group(1)))
				break   # first hit only, as with the Roman fallback
			except: pass

	# Fallback: standalone Roman numeral only if we found no other season signal.
	# Guards against false positives from titles that legitimately contain Roman numerals.
	if not seasons:
		_ROMAN_STANDALONE = {'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7, 'viii': 8}
		for m in _EX_SEASON_ROMAN.finditer(cleaned):
			r = m.group(1).lower()
			if r in _ROMAN_STANDALONE:
				seasons.add(_ROMAN_STANDALONE[r])
				break   # only take first hit to avoid double-counting "II" + "III"

	# --- parts ---
	for m in _EX_PART.finditer(cleaned):
		try: parts.add(int(m.group(1)))
		except: pass

	# --- episode ---
	# Remove already-consumed markers so digits inside them don't leak as episodes.
	# LOCAL PATCH 2026-08-27: 'S02E06-08' spans three episodes, but _EX_SXX_EYY
	# below matches only 's02e06' and consumes it, orphaning the '-08' -- so the
	# file registered as episode 6 alone and never matched a request for 7 or 8.
	# _PK_RNG_SE is the pattern _pack_shape already uses for exactly this shape,
	# and it deliberately does NOT match the anime absolute form 'S03E20.(57)'.
	work = cleaned
	for m in _PK_RNG_SE.finditer(cleaned):
		try: a, b = int(m.group(1)), int(m.group(2))
		except: continue
		if 0 < a < b <= 999:
			episodes.update(range(a, b + 1))
			is_range = True
	if is_range: work = _PK_RNG_SE.sub(' ', work)
	work = _EX_SXX_EYY.sub(lambda m: episodes.add(int(m.group(2))) or ' ', work)
	work = _EX_PART.sub(' ', work)
	# LOCAL PATCH 2026-08-27: season markers have to go too, for the same reason
	# the line above removes parts -- otherwise their digits are read as episodes.
	# 'Shingeki no Kyojin Season 2 - 11' parsed as the RANGE 2-11, so one episode-11
	# file matched every request from 2 to 11; and 'Season 3 - 01 ~ 12' matched
	# '3 - 01' first, which is descending, so the real 01~12 range was never seen.
	# _EX_SEASON_ORD goes FIRST for the same reason it does in the season scan:
	# in '2nd Season 1~13' the plain _EX_SEASON matches 'Season 1' and removing it
	# would swallow the 1 that opens the episode range, leaving a bare '~13'.
	work = _strip_season_ranges(work)   # valid ranges only; see above
	for _rx in (_EX_SEASON_ORD, _EX_SEASON_WORD, _EX_SEASON,
					 _EX_SEASON_ORD_BARE):
		work = _rx.sub(' ', work)

	# A volume/box span is not an episode span -- see _EX_VOLUME_SPAN.
	work = _EX_VOLUME_SPAN.sub(' ', work)

	# episode range like "01-24" or "01~47"
	rng = _EX_EP_RANGE.search(work)
	if rng:
		try:
			a, b = int(rng.group(1)), int(rng.group(2))
			if 0 < a < b <= 9999:
				episodes.update(range(a, b + 1))
				is_range = True
		except: pass

	if not episodes:
		# "- 12", "-12", " 12 "
		for m in _EX_EP_DASH.finditer(work):
			try: episodes.add(int(m.group(1)))
			except: pass
	# always-good prefix: "E12", "Ep 12", "Episode 12"
	for m in _EX_EP_PREFIX.finditer(work):
		try: episodes.add(int(m.group(1)))
		except: pass

	return seasons, (episodes or None), parts, is_range


# LOCAL PATCH 2026-08-27: nyaa.si is blocked here by TWO independent mechanisms,
# which is why fixing one was not enough. Measured on this network:
#
#   nyaa.si                 DNS sinkhole (resolved to an ISP IP that drops packets).
#                           After fixing DNS an SNI/DPI reset ALSO applies: TCP
#                           connects, TLS with SNI=nyaa.si is RST, TLS with any
#                           other SNI to the SAME IP completes. Intermittent --
#                           5/8 handshakes, 2/6 real searches.
#   nyaa.media              8/8 handshakes, 1.6s median, BUT broken query semantics
#                           (see the ordering note below) -- fallback only.
#   nyaa-si.translate.goog  Google Translate proxy. Immune to an SNI filter on
#                           nyaa.si because the SNI on the wire says translate.goog.
#                           Needs the _x_tr_* params appended. ~2.0s.
#   nyaa.land, nyaa.iss.one Cloudflare 403 on /search, and 502. Not usable.
#
# Try hosts in order, keep the first that answers, remember it for the Kodi session.
# A window property rather than a module global: Fen Light runs with
# reuselanguageinvoker=false, so module state dies with every plugin invocation and
# a global would re-probe a dead host on every scrape.
# ORDER MATTERS, and it is about SEARCH SEMANTICS, not speed. This provider batches
# episode/batch variants into few requests using Nyaa's OR syntax
# (`title "Batch"|"Complete"|"S01"|...`). nyaa.media is reachable and marginally
# faster but does NOT implement those semantics -- measured:
#
#            query                        nyaa.media   translate.goog
#            "Frieren"                        55            75
#            "Frieren Batch"                  55  <-same     28  <-correctly narrower
#            'Frieren "Batch"|"Complete"'     27            29
#            '"Batch"|"Complete"'             27  <-same     75
#
# It ignores extra AND terms and mangles OR, so the batch queries silently collapse.
# Real cost: the BluRay season packs vanish -- Frieren 0 hits vs 75 (10 BluRay),
# Mushoku Tensei 0 vs 75 (18 BluRay), Tongari Boushi 11/0 vs 75/6.
#
# translate.goog proxies the REAL nyaa.si, so its semantics are correct, and its SNI
# reads translate.goog which sidesteps the filter on nyaa.si. It leads for correctness.
# nyaa.media stays as a fallback: still useful for plain single-title searches if the
# proxy is unavailable.
# LOCAL PATCH 2026-08-27: anime-aware pack shape test.
#
# source_utils.filter_season_pack is written for western release names and misreads
# the anime absolute-numbering convention. "Attack.on.Titan.S03E20.(57)" means
# season 3 episode 20, which is episode 57 counted from the series start; after
# release_title_format strips the brackets it reads as "s03e20.57" and the helper's
# range regex `s\d+e(\d+)[-.](\d+)` reports "episodes 20 through 57".
#
# Measured on real scrapes: 23 of 32 AoT S3 "season packs" and 24 of 33 Jujutsu
# Kaisen S2 ones were single episodes carrying fabricated ranges. Fen Light offers
# any pack whose range covers the wanted episode (scrapers/external.py), so asking
# for episode 25 would hand the user a torrent holding only episode 20 -- the debrid
# file filter then matches nothing and playback fails with no explanation.
#
# So the range that filter_season_pack reports is discarded and recomputed here.
# Verified 18/18 on a table of real nyaa names covering both conventions.
_PK_ABS_EP = re.compile(r's\d{1,3}[._ ]?e\d{1,3}[._ ]*[(\[]\d{1,4}[)\]]', re.I)
_PK_RNG_SE = re.compile(r's\d{1,3}[._ ]?e(\d{1,3})[._ ]*[-~][._ ]*e?(\d{1,3})(?![\dp])', re.I)
# The second number sits in a LOOKAHEAD so a junk match ("Part.2.-.01") does not
# consume the digits that begin the real range ("01.~.10") -- finditer would
# otherwise resume past them and never see it.
_PK_RNG_BARE = re.compile(r'(?<![\d])(\d{1,3})[._ ]*[-~][._ ]*(?=(\d{1,3})(?:[\s.\])]|$))')


def _pk_first_valid(rx, text, min_span=1):
	"""First ascending, plausible pair -- earlier matches are often junk."""
	for m in rx.finditer(text):
		try: a, b = int(m.group(1)), int(m.group(2))
		except Exception: continue
		if 0 < a < b <= 999 and (b - a) >= min_span: return a, b
	return 0, 0


def _pack_shape(name):
	"""(is_pack, episode_start, episode_end). 0/0 means a whole-season pack."""
	if _PK_ABS_EP.search(name): return False, 0, 0        # SxxEyy.(abs) -> one episode
	a, b = _pk_first_valid(_PK_RNG_SE, name)
	if a: return True, a, b                               # SxxE06-08 -> real range
	try:
		seasons, episodes, parts, is_range = _extract_meta(_clean_for_extract(name))
	except Exception:
		return True, 0, 0                                 # unparseable: leave it to the caller
	if episodes is None: return True, 0, 0                # no episode at all -> batch
	if is_range: return True, min(episodes), max(episodes)
	a, b = _pk_first_valid(_PK_RNG_BARE, name, min_span=2)
	if a: return True, a, b                               # "01.~.10" style batch
	return False, 0, 0                                    # a single, specific episode

# A film or OVA is not a TV episode. Requiring the ABSENCE of a season marker as
# well keeps genuine show packs that merely list their extras -- 'Attack on Titan
# (Complete Collection) (S01-S04+OVA+Movie)' declares S01-S04 and is kept, while
# 'Bleach the Movie: Memories of Nobody' and '[DBD-Raws] Bleach [OVA][01-02]'
# declare no season and are dropped. Both were answering episode-1 requests.
# What a genuine batch SAYS about itself. cour_match used to accept any name it could
# not read an episode number out of, on the theory that such a name must be a batch.
# It is not: a film, a special, or a name whose numbering was mangled beyond parsing
# all look identical to a batch under that rule, and every one of them then answers
# EVERY episode request. Measured on a Jujutsu Kaisen S01E01 scrape, comet returned
# 737 rows of which 508 came in through that door -- 81 of them the film 'Jujutsu
# Kaisen 0', the rest largely CJK-stripped names like '_Sousou.no.Frieren][30][' that
# are a specific episode whose number simply could not be read.
#
# Requiring the claim to be explicit drops 397 of those 737 and 181 of a 447-row
# Frieren scrape, while costing nyaa only 1-2 rows per scrape.
_BATCH_EVIDENCE = re.compile(
	r'complete|batch|collection|box\s?set|\bbox\b|all\s?episodes|integrale|integral|'
	r'full\s?series|season|seasons|serie|series|temporada|staffel|saison|stagione|'
	r'\bvol\b|volume|bd\s?box|bdmv|\btv\b', re.I)

_MOVIE_OVA = re.compile(r'\b(?:movies?|gekijou?ban|ova|oad|nc(?:op|ed))\b', re.I)


# LOCAL PATCH 2026-09-22: the episode number a release writes straight after the show's
# own title, with no delimiter at all.
#
# '[ShouryuuReppa] Mushoku Tensei: Jobless Reincarnation 13 1080p [HEVC][x265]...' carries
# its episode as a bare 13. _EX_EP_DASH needs a dash, _EX_EP_PREFIX needs an E and the
# range forms need two numbers, so _extract_meta returned episodes=None, cour_match fell
# through to its batch rule, found no batch evidence either and REJECTED the row. Measured
# 2026-09-22 on eid=246509: 2 of 32 rows lost that way, both correct for the episode.
#
# No purely syntactic rule can read that number, which is why this sat open for a session:
# 'Mob Psycho 100' cleans to exactly the same shape, and any trailing-number rule stamps it
# 'episode 100' and then answers no episode of that show at all. The discriminator is not
# syntax, it is POSITION RELATIVE TO THE TITLE -- 'Mob Psycho 100' spends its own 100 as a
# title word and leaves nothing behind, while 'Mushoku Tensei: Jobless Reincarnation' ends
# before the 13. _TITLE_EDGE_OK already says a bare number may legally sit beside a title
# match; this reads the number that does.
#
# THE FIRST CLEAN TITLE MATCH IS FINAL, and that is the whole safety argument. Candidates
# are tried LONGEST FIRST, and once one matches, a shorter one may not re-read the digits it
# just consumed. Without that rule the alias 'Mob Psycho' re-reads the 100 the title had
# already accounted for: measured, 50 of 225 rows became 'episode 100', every one a real
# season pack. Prefix aliases are not hypothetical -- 28 of the 553 cached shows that carry
# alternative_titles have one and make_alias_dict feeds every one of them in ('Jaws 3-D'
# <- 'Jaws 3', 'Demon Slayer: Kimetsu no Yaiba' <- 'Demon Slayer'), and tmdb 94664's own
# alias list contains the bare 'Mushoku Tensei'.
#
# The match is final even when it is the WHOLE name. '[DB] Mob Psycho 100 [Dual Audio 10bit
# BD1080p]' cleans to exactly the three title tokens, so writing the length test as "no room
# for a number after it, skip this candidate" handed the row to the short alias by the back
# door and gave 1 of those 50 back. A candidate that fills the name matches, and answers None.
def _title_anchored_episode(cleaned, titles):
	"""The number written immediately after the show's own title, or None.

	`cleaned` is _clean_for_extract output; `titles` is the show title plus its aliases.
	Boundary handling follows _seq_matches: a long word in FRONT of the match means some
	other show's longer title ('Boruto - Naruto Next Generations'), unless _TITLE_EDGE_OK
	allows it or it is a word of one of our own candidates.
	"""
	seq = _title_seq(cleaned)
	cands = sorted((c for c in (_title_seq(t) for t in (titles or []) if t) if c),
				   key=len, reverse=True)
	if not seq or not cands: return None
	cand_words = set(w for c in cands for w in c)
	for cand in cands:
		n = len(cand)
		if n > len(seq): continue
		for i in range(len(seq) - n + 1):
			if seq[i:i + n] != cand: continue
			before = seq[i - 1] if i > 0 else None
			if before is not None and len(before) >= 4:
				if not _TITLE_EDGE_OK.match(before) and before not in cand_words: continue
			nxt = seq[i + n] if i + n < len(seq) else None
			# This title match is FINAL: every path below RETURNS, none falls through to a
			# shorter candidate. Measured over 381 blind rows from 8 shows, only 4 reach here
			# with a digit at all -- the other 311 carry a word ('season' 51, 'the' 32, 's01'
			# 30, 'vol' 27), and 47 have the title filling the whole name.
			if not nxt or not nxt.isdigit(): return None
			val = int(nxt)
			# Matches _EX_EP_RANGE's ceiling so the two episode readers agree.
			if not 0 < val <= 9999: return None
			# A bare year is not an episode: 'Show Name 2016 [BD]' would otherwise read as
			# episode 2016. Tested on the VALUE rather than on four digits of text, so a
			# zero-padded '02016' cannot walk around it. Known cost: a genuine ABSOLUTE
			# episode number in this band is refused -- real long-runners are nowhere near
			# it (One Piece is around 1150), and the bound cannot simply be 999 because
			# absolute numbering does pass 1000.
			if 1900 <= val <= 2099: return None
			return val
	return None


# LOCAL PATCH 2026-09-23: the episode a WHOLE-RUN release names, for animetosho's eid check.
#
# One AniDB entry covering a whole long-runner (One Piece aid 69) has an eid index that
# AnimeTosho fills with other numberings of the same number: ?eid=977 (episode 10) returns
# 'One Piece - Gyojin Tou-hen - 10' (the Fish-Man Island recap, arc-relative) and ?eid=440
# (episode 1) returns 'One Piece - S18E01' (TVDB season-relative). Both sit under aid 69, so
# no id test separates them; only which number the name writes after the title does.
#
# _title_anchored_episode alone reads a bare number, and on the measured eid replies that
# lost 12 real releases which write a MARKER first -- 'ep0001', 'e1179', 'episode 1000',
# 's01e1179', 's1e001'. Every contaminant instead puts an arc name between title and number,
# or a season other than 1. So the marker is folded into a bare number and the unchanged
# reader does the rest.
#
# The marker must sit directly in front of the digits, and only season 1 counts: in a whole-run
# show 'S18E01' is TVDB's season-relative numbering, not the absolute episode, so it stays
# unread and is rejected. A bare 'e' needs a digit straight after it, so 'e-ac3' and 'eac3'
# cannot match, and a word boundary in front, so the 'e' INSIDE 's18e01' is not a marker.
# 'SE.001' is left alone: SE can mean Special Edition.
_EP_MARKER = re.compile(r'\b(?:s0*1\s*e|episode\s*|ep\s*|e)(?=\d)', re.I)


def _normalise_episode_marker(cleaned):
	"""Rewrite an episode marker in front of a number into the bare number.

	`cleaned` is _clean_for_extract output. The result is fed to _title_anchored_episode,
	which reads only a bare number immediately after the title:
	'one piece ep0001' -> 'one piece  0001', 'one piece s01e1179 ...' -> 'one piece  1179 ...'.
	"""
	if not cleaned: return cleaned
	return _EP_MARKER.sub(' ', cleaned)


def whole_run_episode(name, titles):
	"""The absolute episode a release name states for a whole-run show, or None."""
	if not name or not titles: return None
	return _title_anchored_episode(_normalise_episode_marker(_clean_for_extract(name)), titles)


# LOCAL PATCH 2026-09-23: cour_match's step 0, lifted out so animetosho's PACK paths apply
# the very same test. Packs skip cour_match (a batch spanning cours is a legitimate answer),
# and that exemption let every Thousand-Year Blood War batch through for a Bleach (2004)
# request: AnimeTosho files TYBW under Bleach's own aid 2369, and 'Sennen Kessen Hen -
# 01 ~ 13' declares a range that contains episode 1, so the range check cannot see it.
def names_foreign_cour(name, foreign_tokens):
	"""True when the name carries a distinctive word of ANOTHER cour of this TMDb show."""
	if not foreign_tokens or not name: return False
	_nt = set(w for w in re.findall(r'[a-z0-9]+', name.lower()) if len(w) >= 4)
	return bool(_nt & set(foreign_tokens))


def cour_match(name, cour_season=None, cour_episode=None, absolute_episode=None,
               season_episode=None, cour_part=None, foreign_tokens=None, titles=None,
               trust_id=False, cour_part_count=None):
	"""Does this release name hold the wanted episode of the wanted cour?

	LOCAL PATCH 2026-08-27. Anime carries two numbering schemes at once and both
	are in active use for the same episode:
	    [Erai-raws] Sousou no Frieren 2nd Season - 02   cour-relative
	    [ANi] Sousou no Frieren S02 - 30                absolute (from series start)

	`cour_season` is the RELEASE season number - Fribb's season.tvdb, not TMDb's.
	TMDb files every Re:ZERO cour under season 1, so its number says nothing about
	what an "S02" in a release name refers to.

	ORDER MATTERS here; both alternatives were tried and both lose results:

	  1. Absolute number first. It is unique across the series, so it identifies an
	     episode with no season marker at all - "[SubsPlease] Shingeki no Kyojin -
	     38" is S3E01. Putting the season check ahead of this rejected 34 real AoT
	     results whose only number was the absolute one.
	  2. Season check next. The cour-relative number IS ambiguous between cours, so
	     for cour 2+ a name with no season marker is cour 1, not a wildcard.
	     Otherwise "[aL] Sousou no Frieren (2023) - 02" (cour 1 episode 2) answers a
	     cour 2 episode 2 request - exactly what comet's kitsu endpoint returns.
	  3. Batches only after the season check. Accepting them earlier let
	     "Frieren: Beyond Journey's End (2023) (Season 1) [BDRip]" through for a
	     cour 2 request.
	"""
	# 0. a name carrying another cour's distinctive words IS that cour, whatever
	#    numbering it uses. Bleach and Thousand-Year Blood War are separate anime
	#    under one TMDb show, and TYBW releases label themselves S01E01 in their own
	#    numbering -- so no season or episode test can separate them. Only the title
	#    can, and 'Sennen Kessen-hen' is the form most of those releases use.
	if names_foreign_cour(name, foreign_tokens): return False
	_cleaned = _clean_for_extract(name)
	seasons, episodes, parts, is_range = _extract_meta(_cleaned)
	# LOCAL PATCH 2026-09-24: a Part number larger than the season has parts is not a cour
	# part. JoJo names its story arcs that way -- 'Part 6: Stone Ocean' -- and step 3 below
	# compared the 6 against Stone Ocean's cour part 3 and rejected a correct S05E25. The
	# same guard animetosho's pack check applies. Only when the caller knows the count.
	try:
		if parts and cour_part_count and any(int(p) > int(cour_part_count) for p in parts): parts = set()
	except (TypeError, ValueError): pass
	# LOCAL PATCH 2026-09-22: a name whose only number sits bare after the title reads as
	# unreadable to _extract_meta, and an unreadable name with no batch evidence is REJECTED
	# further down. `titles` is what lets it be read -- see _title_anchored_episode. Applied
	# ONLY when nothing else found an episode, so it can neither override a number a
	# delimiter already yielded nor change any row that parses today.
	if episodes is None and titles:
		_anchored = _title_anchored_episode(_cleaned, titles)
		if _anchored is not None: episodes = set([_anchored])
	# films / OVAs, unless the name also claims a season (then it is a show pack
	# that merely lists its extras)
	# underscores are word characters, so \b will not fire against them:
	# 'Gekijouban_Bleach_...[MOVIE_IV]' has to be split first
	if not seasons and _MOVIE_OVA.search((name or '').replace('_', ' ')): return False
	def _int(v):
		try: return int(v)
		except (TypeError, ValueError): return None
	cour_season, cour_episode = _int(cour_season), _int(cour_episode)
	absolute_episode, season_episode = _int(absolute_episode), _int(season_episode)
	# The season-relative number is the one release names carry when a season is
	# split across cours (Re:ZERO S2 ep 24 = cour 2 of 2, cour_ep 12). Where the
	# season is a single cour the two are identical, so accepting both is free.
	wanted = set(x for x in (season_episode, cour_episode) if x is not None)

	# 1. unambiguous absolute hit (skipped for cour 1, where the two numbers are
	#    the same and a bare number really is ambiguous)
	if (episodes and absolute_episode is not None
			and absolute_episode not in wanted and absolute_episode in episodes):
		return True

	# 2. the release must belong to our cour
	if cour_season and cour_season > 1:
		# LOCAL PATCH 2026-09-22: reject only a name claiming a LATER season than the one
		# asked for. A franchise with named sub-series is numbered TWICE: every database
		# counts across the franchise while release groups count within the sub-series.
		# Ace of the Diamond S04 is 'Act II -Second Season-', so Fribb and TVDB both say
		# season 4 while the releases say 'Act II S2', 'Act II Second Season' and
		# 'Act II - S02E01' -- seasons={2} against cour_season=4. Measured 2026-09-22:
		# `4 not in {2}` rejected all 10 rows AnimeTosho returns for eid 310190, so S03
		# and S04 found nothing at all. Only [Judas] numbers by franchise season.
		#
		# The direction is what carries the signal. Mis-filing -- the thing this reject
		# exists for -- is always sequel content landing under a PREQUEL's id, so the
		# name claims a HIGHER season than requested: Re:ZERO S4 releases under S1's ids
		# say 'S04E01' against cour_season=1. Sub-series numbering is the opposite, a
		# LOWER number than the franchise season. So a lower number is trusted to the eid
		# and a higher one is still refused.
		#
		# A name with NO season marker is still refused, unchanged: for cour 2+ the bare
		# cour-relative number reads as cour 1 rather than as a wildcard (see the
		# docstring's point 2).
		#
		# Known cost: a mis-filed row whose sub-series season happens to EQUAL the
		# requested franchise season now passes -- asking for Ace S02 while Act II S2
		# rows sit under S02's eid. It needs a mis-file and a matching episode number,
		# and those rows live under aid 18638, so they should not reach an S02 query.
		# LOCAL PATCH 2026-09-22: `trust_id` -- the caller identified this episode by an ID
		# rather than by reading the name, so a name that says nothing about its season
		# contradicts nothing. This rule reads a missing marker as 'cour 1', which is right
		# when the name is the only evidence there is (nyaa and comet search by title) and
		# wrong on an eid query, where animetosho's own comment says the eid still decides
		# which episode this is and this test exists only to catch a MIS-FILED row. A
		# mis-file announces itself -- the Re:ZERO season 4 releases sitting under season
		# 1's ids plainly say 'S04E01'. A name with no marker announces nothing.
		#
		# Measured on JoJo: TMDb season 5 is Stone Ocean, whose parts are NAMED rather than
		# numbered, so '[SubsPlease] JoJo no Kimyou na Bouken - Stone Ocean - 01' carries no
		# Sxx token at all. Against cour_season=5 every such row was rejected, on all three
		# parts and every episode: 'cour_rejected=2 kept=0' on eids 250393, 258797, 261521.
		# Only [Judas], which writes S05E01, survived.
		if not seasons:
			if not trust_id: return False
		elif cour_season not in seasons and min(seasons) > cour_season: return False
	elif seasons and min(seasons) > 1:
		# LOCAL PATCH 2026-09-21: some groups number a split season's COURS as seasons,
		# and that is not a later season at all. Mushoku Tensei S1 is two cours; Fribb
		# files both under season.tvdb 1, but Erai-raws ships the second as
		# 'Mushoku Tensei - Isekai Ittara Honki Dasu 2nd Season - 02'. That reads as
		# seasons={2} against cour_season=1 and was rejected, losing 3 of the 32 rows
		# AnimeTosho returns for eid 246509 -- all of them correct for the episode.
		#
		# The tell is that the name's number CANNOT be a real season: it exceeds the
		# season this episode actually belongs to, and it equals the cour part we want.
		# Re:ZERO S2 part 2 is the case this must NOT catch -- there cour_season is 2, so
		# min(seasons) > cour_season is false, '2nd Season' really does mean season 2, and
		# the branch above handles it as before.
		#
		# Recorded as a PART rather than just waved through: the name has told us which
		# cour it is, which is exactly what 3b below needs to stop treating the
		# cour-relative number as ambiguous. Waving it through would clear step 2 and then
		# still fail 3b, which is what made this a two-line fix rather than a one-line one.
		if (cour_part and cour_season and min(seasons) == int(cour_part)
			and min(seasons) > cour_season):
			parts = set(parts) | {int(cour_part)}
		else:
			return False   # targeting cour 1, name claims a later season

	# 3. a batch of the right cour: caller picks the file inside it. A Part number
	#    is the one thing a batch does say about WHICH episodes it holds, so honour
	#    it -- '(Season 2 Part 01)' cannot contain an episode from Part 2, and with
	#    no episode numbers to check it would otherwise sail through.
	if parts and cour_part and int(cour_part) not in parts: return False
	# No episode number: only a batch if the name actually claims to be one. See
	# _BATCH_EVIDENCE -- without this test a film or an unparseable name matched every
	# episode of the show. `seasons` and `parts` count as a claim in their own right,
	# and a season pack has already been checked against our cour above.
	if episodes is None:
		return bool(seasons or parts or _BATCH_EVIDENCE.search(name or ''))

	# 3b. a split season makes the COUR-relative number ambiguous across parts, in
	#     exactly the way the cour-relative number is ambiguous across cours above.
	#     Attack on Titan S3 is two parts; our S3E20 is part 2 episode 8, but part 1
	#     episode 8 is ALSO named 'Attack on Titan S3 - 08', and it was matching. A
	#     part marker resolves that and is honoured just above -- when there is none
	#     the bare number reads as part 1, so only the unambiguous numbers may be
	#     used: the season-relative one (20) and the absolute one, both of which
	#     count across the whole season and so cannot collide between its parts.
	# Skipped for an id-keyed caller, for the same reason as the season rule above: this
	# treats a bare cour-relative number as ambiguous BETWEEN PARTS, which it is when the
	# name is all we have, but with an eid the part is already known. JoJo again -- Stone
	# Ocean part 2 episode 1 is named '- 01', so wanted={1, 13} would be narrowed to the
	# season-relative 13 and miss, rejecting a correct row a second time even after the
	# season rule let it through.
	if cour_part and int(cour_part) > 1 and not parts and not trust_id:
		unambiguous = set(x for x in (season_episode, absolute_episode) if x is not None)
		return bool(unambiguous & set(episodes))

	# 4. cour-relative number, now that the cour is established
	return bool(wanted & set(episodes))


def title_guard(name, title, aliases):
	"""Does this release name actually belong to the show we asked for?

	LOCAL PATCH 2026-08-27. The Kitsu paths in torrentio and comet skip the normal
	title check, on the reasoning that querying by an ID already scopes the result to
	one anime. That reasoning turned out to be too trusting on both counts:

	  - comet's kitsu endpoint leaks unrelated shows. A kitsu:11:159 (Naruto) query
	    returned "11.22.63.S01.2160p.HULU.WEB-DL", and a Frieren query returned
	    "In Spectre S02E02".
	  - the ID itself can be wrong. ani.zip maps Fairy Tail to kitsu_id 1, which is
	    Cowboy Bebop -- so a query built from it returns 559 Cowboy Bebop rows, every
	    one of which the episode checks happily accept because they never look at
	    the title.

	No episode-level test can catch either: they are the right episode number of the
	wrong show. Only the title can, so it is checked here as a last line of defence.

	Uses the boundary-aware matcher rather than source_utils.check_title, which
	requires an SxxExx token that anime releases do not carry.
	"""
	cands = [_title_seq(t) for t in ([title] + list(aliases or [])) if t]
	cands = [c for c in cands if c]
	if not cands: return True
	return _seq_matches(_title_seq(name), cands)


def alias_titles(data):
	"""Show title + alias strings from a Fen Light data dict, for title_guard."""
	out = []
	for alias in (data.get('aliases') or []):
		if isinstance(alias, dict):
			if alias.get('title'): out.append(alias['title'])
		elif alias: out.append(str(alias))
	# LOCAL PATCH 2026-09-24: '<show> <TMDb season name>', when Fen Light passes the season's
	# name. Release groups write it between the title and the number -- '[Some-Stuffs] Jojo's
	# Bizarre Adventure Stone Ocean 25' -- and _title_anchored_episode reads only a number
	# straight after a candidate, so without this the row had no episode and was rejected.
	# A generic 'Season 2' name adds nothing a release would write that way, so it is skipped.
	_st, _show = data.get('season_title'), data.get('tvshowtitle')
	if _st and _show and not re.match(r'^\s*season\s*\d+\s*$', str(_st), re.I):
		out.append('%s %s' % (_show, _st))
	return out


# ---------------------------------------------------------------------------------------------
# PACK NAMES
#
# LOCAL PATCH 2026-09-24: moved here from providers/torrents/animetosho.py so that every
# anime name reader lives in this one module. Behaviour unchanged -- the functions take the
# names a row carries (title, then torrent_name) instead of the row, and animetosho passes
# them in. The measurements quoted below were taken there and still hold.
# ---------------------------------------------------------------------------------------------

# LOCAL PATCH 2026-09-22: a pack naming itself a numbered SUBDIVISION -- Box 05, Vol 09,
# Set 1, Part 2, Disc 3 -- holds some slice of the run without saying which episodes.
# Used by _pack_excludes_episode; the reasoning is there.
# 2026-09-22 (second pass): season markers count as subdivisions too. A 41-file
# '[BlackRabbit] Naruto (2002) - S05' cannot serve episode 220 any more than Box 01 can,
# and it reached the picker because it names a SEASON rather than a box. Safe for the
# same reason: the file-count test is against min(wanted), so a cour anime's own season
# pack (12 files, cour_episode 1-12) is never touched.
# LOCAL PATCH 2026-09-22: a pack that names a SIBLING SERIES alongside this one spans
# more than the anime being scraped, and its episode numbering is then ambiguous.
# 'Naruto + Naruto Shippuden' holds two episode 220s, and nothing in the feed says
# which file answers a request for 220. AnimeTosho is not wrong to list them under
# aid 239 -- they do contain Naruto -- so this is a deliberate policy reject, not a
# mis-filing guard.
#
# Words below are the ones that legitimately follow a '+' without naming another
# series. The list will never be complete, which is why the length floor below
# carries the real weight.
_SIBLING_EXTRAS = frozenset((
	'movie', 'movies', 'film', 'films', 'ova', 'ovas', 'oad', 'oads', 'special',
	'specials', 'extra', 'extras', 'opening', 'openings', 'ending', 'endings',
	'batch', 'complete', 'collection', 'season', 'seasons', 'remux', 'bluray',
	'dual', 'audio', 'project', 'subtitle', 'subtitles', 'uncensored',
))
# Seven, measured. At five, 'season' (Mushoku Tensei's own alt-title line) and
# 'break' (Re:ZERO Break Time) both produced false rejects; at seven neither does,
# while 'shippuden' and 'shippuuden' still fire. It misses short continuation names
# such as Dragon Ball KAI, and that is the direction to fail in: a miss leaves today's
# behaviour, an over-reject removes a working source.

# LOCAL PATCH 2026-09-23: a MOVIE-numbered range is not an episode range.
#
# AnimeTosho files a franchise's films under the series aid, so a Naruto Shippuden pack
# query returns '[Koten_Gars] Naruto Shippuden - The Movie 1-8' and '[BDMV] Naruto
# Shippuden - The Movie Collection (Movie 1-4)'. _extract_meta reads '1-8' and '1-4' as
# EPISODES, so both were offered for episodes 1 to 8 -- measured, 2 movie rows kept at
# episode 1 and 1 at episode 8, against 0 at episode 32 where the range happens not to
# reach. The films cannot contain a TV episode at any number.
_SEASON_RANGE = re.compile(r'\b(?:seasons?|s)[^a-z0-9]{0,3}\d{1,2}\s*[-~]\s*\d{1,2}', re.I)

_MOVIE_RANGE = re.compile(
	r'\b(?:movies?|films?|gekijou?ban)\b[^a-z0-9]{0,4}(\d{1,2})\s*[-~]\s*(\d{1,2})', re.I)

# LOCAL PATCH 2026-09-23: a bare episode range wrapped in brackets or parentheses.
#
# _extract_meta reads '0629-0686' and '783-1023' but not '(1086-1155)', '(0996-1069)',
# '(892-1085)' or '[0207-0336]' -- the same range, wrapped. '(E01-E12)' parses only
# because of the E. So a One Piece Egghead-arc pack declared nothing, and an unreadable
# name contradicts nothing, which is why it was kept for episode 1.
#
# LOCAL PATCH 2026-09-23 (b): 'to'/'thru' as the separator as well as a dash --
# '[Anime Time] One Piece (1001 to 1085)'. Only inside brackets, where the whole
# bracket IS the range. An unbracketed compound like 'One Piece - 1061, 1062 & 1070 to
# 1076' is deliberately left unread: taking 1070-1076 as its declared set would reject
# a request for 1061, which the name plainly also offers.
#
# Unwrapped for _pack_excludes_episode ONLY. anime_utils' extractor is also what
# cour_match reads, and teaching it a new range form would change episode matching for
# every id-keyed provider; this filter is the one place the gap is known to bite.
#
# LOCAL PATCH 2026-09-24: the range may be followed by EXTRAS inside the same bracket --
# '[Anime Time] One Piece (0001-1071+Movies+Specials)', 'Naruto Shippuden Complete (001-500
# + Movies)'. Required the close bracket straight after the second number, so neither was
# read and a 1071-episode pack was offered for episode 1179. The extras are films and
# specials, never more TV episodes, so the range is still the episode set. Only a WORD may
# follow the + or &: '(1070 to 1076 & 1080)' stays unread, for the compound-list reason above.
_BRACKETED_RANGE = re.compile(
	r'[\(\[]\s*(\d{1,4})\s*(?:[-~]|[\s._]+(?:to|thru)[\s._]+)\s*(\d{1,4})\s*(?:[\)\]]|(?=[+&]\s*[a-z]))', re.I)


def _unwrap_bracketed_range(name):
	"""'(1086-1155)' -> ' 1086-1155 ', which _extract_meta then reads. Unchanged if none.

	A YEAR span is left wrapped: 'One Piece (TV; Seasons 1 through 4; 1999-2002)' is a
	pack that DOES hold episode 1, and reading 1999-2002 as episodes would reject it.
	Both endpoints plausible years and a reach of 30 or less is the test -- an episode
	range that narrow, that high, would have to be a 4-part pack numbered past 1900."""
	def _sub(m):
		try: lo, hi = int(m.group(1)), int(m.group(2))
		except (TypeError, ValueError): return m.group(0)
		if 1900 <= lo <= 2099 and 1900 <= hi <= 2099 and 0 <= hi - lo <= 30: return m.group(0)
		return ' %d-%d ' % (lo, hi)
	try: return _BRACKETED_RANGE.sub(_sub, name)
	except Exception: return name


def pack_declares_season_only(names):
	"""True when the names state a SEASON and no episode range at all.

	'One Piece Season 17 (Dress Rosa) - Vol.15-22' and 'Naruto Shippuden Season 3' say
	which season they are and never say which episodes, so _pack_excludes_episode has
	nothing to test and keeps them -- an unreadable name contradicts nothing. That is the
	right default, but it means a season 17 pack is offered for episode 1.

	The season number itself is NOT compared here. It is TVDB's, not TMDb's, and for a
	cour-split show the two diverge -- that is what cour_season exists for -- while a show
	scraped in absolute order has no meaningful season to compare against at all. So this
	only reports that the name is season-shaped and episode-silent; Fen Light decides what
	to do with that, and does so only for a pack it cannot verify against a file listing.

	A name stating a range is never flagged, however many seasons it also names:
	'One Piece (001-746)(Seasons.01-17)' is verifiable and is left alone.
	"""
	if not (_extract_meta and _clean_for_extract): return False
	names = [n for n in (names or ()) if n]
	if not names: return False
	names = names + [u for u in (_unwrap_bracketed_range(n) for n in names) if u not in names]
	# A SEASON RANGE is a collection, not one season. _extract_meta reports 'Season 1-18'
	# as seasons=[1] -- it reads the first number only -- so it is indistinguishable from a
	# genuine season 1 pack without this. '[HcLs] Naruto Shippuden Season 1-18' is a
	# complete-series set and must not be dropped. The dash has to follow the digits
	# directly, so 'Season 17 (Dress Rosa) - Vol.15-22' is not caught by it.
	if any(_SEASON_RANGE.search(n) for n in names): return False
	seen_season = False
	for name in names:
		try:
			seasons, episodes, _parts, is_range = _extract_meta(_clean_for_extract(name))
		except Exception:
			continue
		if is_range and episodes: return False
		if seasons: seen_season = True
	return seen_season
_SIBLING_MIN_LEN = 7
_SIBLING_JOIN = re.compile(r'[+&]')
_SIBLING_BRACKETS = re.compile(r'\[[^\]]*\]|\([^)]*\)|\{[^}]*\}')

# LOCAL PATCH 2026-09-24: three digits, not two. '[uP] One Piece - Vol.003' (8 files) matched
# neither this nor, above episode 8, _SINGLE_VOLUME's arithmetic, so it was offered for
# episode 200. _SINGLE_VOLUME already read \d{1,3}; the two now agree.
_SUBDIVISION = re.compile(r'(?:^|[^a-z0-9])(?:box|vol|volume|set|part|pt|disc|disk|s|season)[^a-z0-9]{0,2}\d{1,3}(?:[^a-z0-9]|$)', re.I)

# LOCAL PATCH 2026-09-24: a pack of FILMS that states no range. _MOVIE_RANGE needs 'Movie
# 1-8'; 'Naruto.Shippuden.-.Movies.[BD-Remux]' and '[uP] Bleach - Movies' say only Movies,
# so they declared nothing and were kept -- the Shippuden remux (15 files, 208 GB) topped the
# S1E1 picker at 13.86 GB a file. Its TorBox listing is Movie 1 to Movie 7, and the listing
# check could not drop it either: finding no episode anywhere reads as an unreadable naming
# convention, not as absence. So the name has to settle it.
# A name that also says it holds EPISODES is a collection that happens to include the films
# ('One Piece [ Episodes + Movies + OVAs + Specials ]', 2260 files) and is left alone.
# So is one naming the films as an ADDITION -- '[DB] Re:Zero ... + Movies' (56 files) and
# '[Tenrai-Sensei] Re Zero ... S1+S2+OVAs+Movies' (102) were both falsely rejected by a first
# cut that looked for the word alone. A films-only pack names them as its SUBJECT: 'Naruto
# Shippuden - Movies', 'Bleach - Movies'.
_MOVIE_WORD = re.compile(r'\b(?:movies?|films?|gekijou?ban)\b', re.I)
_MOVIE_ADDITION = re.compile(r'(?:[+&]|\band\b|\bwith\b)[^a-z0-9]{0,3}(?:the[^a-z0-9]+)?(?:movies?|films?|gekijou?ban)\b', re.I)
_EPISODE_WORD = re.compile(r'\b(?:episodes?|eps?|tv|series|complete|collection|batch|seasons?|integrale|s\d{1,2})\b', re.I)

# LOCAL PATCH 2026-09-22: a pack labelled volume N>1 does not start at episode 1.
# The file-count fallback below can only say 'a 6-file pack cannot REACH episode 7',
# never 'volume 2 BEGINS at episode 7', so MTBB's Mushoku Tensei Volume 2 and Volume 3
# were both offered for episode 1 and TACHiKEN's Apothecary Vol 03 for episodes 1-6.
#
# Two guards keep this off the packs it would wreck, both learned from Naruto:
#   - a SPAN is excluded by the lookahead ('Vol.05~12' covers eight volumes, so its
#     181 files are not one volume's worth and the arithmetic below is meaningless);
#   - a pack bigger than _MAX_VOLUME_FILES is excluded, because '[uP] Set.5' with 130
#     files is a box, not a volume, and its own count says nothing about where it starts.
# Measured across Mushoku S1, Apothecary S1+S2 and Naruto: the correct rejects land at
# low episodes (Naruto drops 20 single-volume packs at ep 1, all of them Vol.09+) and
# NOTHING new is rejected at ep 55, 110 or 220 -- the rule only fires where it is sure.
_SINGLE_VOLUME = re.compile(r'\b(?:vol|volume|box|disc|disk|set)[^a-z0-9]{0,2}(\d{1,3})(?![^a-z0-9]{0,2}[-~]\s*\d)', re.I)
_MAX_VOLUME_FILES = 15


def pack_excludes_episode(names, num_files, wanted):
	"""True only when the names state a range and the wanted episode is outside it."""
	if not (_extract_meta and _clean_for_extract): return False
	# LOCAL PATCH 2026-09-22: read BOTH name fields, not `torrent_name or title`.
	# A row carries two names and either may be the informative one. Measured on
	# aid 17870: the 14-file [sam] pack has torrent_name '[sam] Kusuriya no
	# Hitorigoto [BD 1080p FLAC]' -- no range at all -- while its title reads
	# '[sam] The Apothecary Diaries Season 1 (S01) (E01-E12) | ...'. Preferring
	# torrent_name threw the range away and the pack was offered for E13/E14. The
	# 28-file pack in the same feed has an EMPTY torrent_name, so neither field can
	# be preferred outright -- and _build already reads them the other way round for
	# packs (`posting or filename`), so the two disagreed about the same row.
	names = [n for n in (names or ()) if n]
	if not names: return False
	# LOCAL PATCH 2026-09-23: add an unwrapped variant of any name carrying a bracketed
	# range, so the loop below can read it. ADDED, never substituted -- the original name
	# stays in the list, so nothing that already parsed can start parsing differently.
	names = names + [u for u in (_unwrap_bracketed_range(n) for n in names) if u not in names]
	# LOCAL PATCH 2026-09-23: a film collection cannot hold a TV episode.
	#
	# Only when the movie range is the ONLY range the name states. 'One Piece Collection
	# 1-750 + OVAs + Specials + Movies 1-12' names both, and it is a legitimate episode
	# pack that happens to bundle the films -- rejecting on the mere presence of the word
	# would throw it away. So the movie range is stripped and the name re-read: if an
	# episode range survives, the normal logic below decides; if nothing does, the row was
	# only ever describing films.
	if any(_MOVIE_RANGE.search(n) for n in names):
		_leftover = False
		for _n in names:
			try:
				_s, _e, _p, _r = _extract_meta(_clean_for_extract(_MOVIE_RANGE.sub(' ', _n)))
			except Exception:
				continue
			if _r and _e:
				_leftover = True
				break
		if not _leftover: return True
	declared = set()
	for name in names:
		try:
			_seasons, episodes, _parts, is_range = _extract_meta(_clean_for_extract(name))
		except Exception:
			continue
		if is_range and episodes: declared.update(episodes)
	# Any name that states a range is evidence; the union is what the pack can hold.
	if declared:
		return not (wanted & declared)
	# LOCAL PATCH 2026-09-24: films only, no range -- see _MOVIE_WORD. Underscores are word
	# characters, so 'Gekijouban_Bleach' is split before \b can see the word.
	_flat = [n.replace('_', ' ') for n in names]
	if (any(_MOVIE_WORD.search(_MOVIE_ADDITION.sub(' ', n)) for n in _flat)
			and not any(_EPISODE_WORD.search(n) for n in _flat)):
		return True
	# A single numbered volume cannot hold an episode that sits inside volume 1's span.
	# Only the LOW end is tested: volume sizes vary between groups (MTBB's Apothecary
	# volumes run 6-7 files while Lia's Mushoku Volume 3 declares episodes 12-17), so an
	# upper bound from one pack's file count would produce false rejects. The lower bound
	# does not depend on that variation.
	for name in names:
		m = _SINGLE_VOLUME.search(name)
		if not m: continue
		try:
			volume = int(m.group(1)); files = int(num_files or 1)
		except (TypeError, ValueError):
			continue
		if volume >= 2 and 1 <= files <= _MAX_VOLUME_FILES and max(wanted) <= files:
			return True

	# No range declared by either name. A numbered subdivision is then unverifiable
	# from the name, so fall back to the one hard fact the feed gives: its file count.
	# A pack cannot reach episode N even numbered from 1 if it holds fewer than N
	# files, so Box 05 with 27 files cannot serve episode 212.
	#
	# Compared against the SMALLEST candidate numbering on purpose. A cour pack
	# legitimately holds 12 files while the absolute number is 212, so testing the
	# largest would reject every cour pack in the library. Taking the smallest means
	# this can only fire when even the lowest plausible episode number exceeds the
	# pack -- exactly the long single-entry shows this is for (Naruto: one aid for 220
	# episodes, and TOSHO-DIAG shows wanted=[220], a single number). Cour anime is
	# untouched, its cour_episode being small.
	#
	# Cost, accepted deliberately: Box 8 really does hold episode 212 and is rejected
	# along with Box 1, because the name never says which episodes it covers. The
	# complete-series packs DO declare 001-220 and still answer.
	if any(_SUBDIVISION.search(n) for n in names):
		try: files = int(num_files or 1)
		except (TypeError, ValueError): return False
		return files < min(wanted)
	return False


def pack_names_sibling_series(names, titles):
	"""The distinguishing word when a '+' segment names another series, else None."""
	if not titles: return None
	# LOCAL PATCH 2026-09-22: both names, same reason as _pack_excludes_episode --
	# torrent_name is empty on some rows and abbreviated on others.
	name = ' | '.join(n for n in (names or ()) if n)
	# Bracketed groups carry release tags and fansub names, never a second series.
	body = _SIBLING_BRACKETS.sub(' ', name)
	segments = _SIBLING_JOIN.split(body)
	if len(segments) < 2: return None
	known = set()
	for title in titles:
		known.update(w for w in re.split(r'[^a-z0-9]+', title.lower()) if w)
	for segment in segments[1:]:
		for word in re.split(r'[^a-z0-9]+', segment.lower()):
			if len(word) < _SIBLING_MIN_LEN: continue
			if word in known or word in _SIBLING_EXTRAS: continue
			return word
	return None
