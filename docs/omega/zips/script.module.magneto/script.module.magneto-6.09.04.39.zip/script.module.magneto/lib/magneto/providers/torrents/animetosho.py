# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-27: AnimeTosho provider -- anime episodes matched by ID.
#
# WHY THIS PROVIDER IS DIFFERENT FROM EVERY OTHER ONE HERE
# The rest of this directory searches by title and then decides, from the release
# NAME, whether a row is the episode the user asked for. For anime that decision is
# not reliably decidable. The same episode ships under genuinely different, equally
# correct numbers:
#
#   Bleach TYBW premiere   -> "S01E01"  AND  "S17E01"   (both on nyaa, both correct)
#   Re:ZERO TMDb ep 50     -> "Season 2 - 24"
#   Attack on Titan S3E20  -> "S03E20 (57)"
#   Boruto ep 220          -> "- 220"
#
# nyaa.py has grown a rule for each of these shapes and every rule risks the next
# show. That is a losing shape of problem, so this provider does not play it.
#
# AnimeTosho mirrored nyaa's English-translated anime category and tagged each torrent
# with the AniDB episode id (eid) it belongs to. Fen Light resolves the eid for the
# requested episode before scraping (Fribb -> AniList id -> ani.zip -> eid, all
# cached), so this provider asks the index a question that has one right answer:
# "which torrents ARE eid 259237?" -- and does no name parsing whatsoever.
#
# Verified against the four cases above: all four return the correct episode, in
# every naming convention at once, with no filtering applied.
#
# *** THE INDEX IS FROZEN -- READ THIS BEFORE DEBUGGING AN EMPTY RESULT ***
# AnimeTosho stopped ingesting on 2026-05-08. The API still answers HTTP 200 and still
# serves everything indexed up to that date, so this provider remains genuinely useful
# for the back catalogue -- but it holds NOTHING released after it, and that share
# grows every week.
#
# The symptom is a show returning zero rows by both eid and aid while nyaa has plenty:
# Chainsmoker Cat (premiered 2026-02, indexed nowhere here) gave 0 from animetosho and
# 22 from nyaa. That is the frozen index, not a broken lookup -- checking the newest
# `timestamp` in an unfiltered /json?limit=25 call confirms it in one request.
#
# So: nyaa is what covers current seasons and must stay enabled; seadex.py (live,
# updated daily) covers curated picks; this provider covers the archive.
#
# SCOPE
# Two queries, because they find different things:
#   sources()       ?eid=<episode id>  single episodes, exact, no parsing
#   sources_packs() ?aid=<anime id>    season packs, which the eid query cannot see
# See the note on pack_capable below for why both are needed.
#
# On remux: AnimeTosho's own index leans toward encodes over raws, and none of the
# six episodes measured while building this returned a remux -- though the pack query
# does surface them (Bleach TYBW has a 76.6GB BD Remux batch). Remux rows are tagged
# rather than assumed away: `name_info` below is what lets Fen Light apply its REMUX
# filter and quality sort to them.
#
# API: https://feed.animetosho.net/json?eid=<eid>   No key. No auth. JSON list.
#
# LOCAL PATCH 2026-09-15: .org -> .net, AnimeTosho's newer domain. Both hosts run the
# same software and answer the same AniDB semantics -- verified identical JSON schema
# (28 keys, no field differs) and both correctly report anidb_eid for the queried id --
# but they are NOT mirrors: their internal `id` spaces are disjoint, so the same release
# carries a different id on each. Compare by info_hash, never by id.
#
# .net measured equal or better on 6 of 7 real aids (Steins;Gate aid=129 returned 22 rows
# on .org against 75 on .net; four others hit the 75 cap on both). The one regression was
# aid=17069, 1 row on .org and 0 on .net. Single-episode eid=259237 gave 31 on .org and 48
# on .net, sharing only 20 info_hashes -- so each still holds releases the other lacks.
# Querying both and deduping by hash would strictly beat either; not done, one request.

from magneto.modules import client
from magneto.modules import source_utils
# LOCAL PATCH 2026-09-15: sibling-cour reject, see sources(). The same helper nyaa.py uses,
# so the three competing anime numbering schemes stay implemented in exactly one place.
try:
	from magneto.modules.anime_utils import cour_match
except Exception:
	cour_match = None

# LOCAL PATCH 2026-09-22: the same extractor cour_match uses, for the pack range check in
# sources_packs. Imported separately so a failure there cannot disable cour_match.
try:
	from magneto.modules.anime_utils import _clean_for_extract, _extract_meta, alias_titles
except Exception:
	_clean_for_extract = _extract_meta = alias_titles = None

try:
	from statistics import median as _median
except ImportError:
	_median = None

try:
	import json as _json
except ImportError:
	_json = None

import re

# Raw Blu-ray disc structures and disc images. These carry no episode files to pick
# from -- a BDMV is a tree of .m2ts streams under BDMV/STREAM -- so the debrid layer
# can never resolve one to an episode and the row would only ever fail on click.
# Seen for real: a 440-file 95.6GB "[BDMV] Attack on Titan Season 4 Part 2 [US]" row
# returned under the Season 3 aid.
_DISC_STRUCTURE = re.compile(r'(?:^|[^a-z0-9])(?:bdmv|m2ts|iso|disc\s?\d|bdiso)(?:[^a-z0-9]|$)', re.I)

# LOCAL PATCH 2026-09-22: a pack naming itself a numbered SUBDIVISION -- Box 05, Vol 09,
# Set 1, Part 2, Disc 3 -- holds some slice of the run without saying which episodes.
# Used by _pack_excludes_episode; the reasoning is there.
# 2026-09-22 (second pass): season markers count as subdivisions too. A 41-file
# '[BlackRabbit] Naruto (2002) - S05' cannot serve episode 220 any more than Box 01 can,
# and it reached the picker because it names a SEASON rather than a box. Safe for the
# same reason: the file-count test is against min(wanted), so a cour anime's own season
# pack (12 files, cour_episode 1-12) is never touched.
# LOCAL PATCH 2026-09-22: a pack that names a SIBLING SERIES alongside this one spans
# more than the anime being scraped, and its episode numbering is then ambiguous.
# 'Naruto + Naruto Shippuden' holds two episode 220s, and nothing in the feed says
# which file answers a request for 220. AnimeTosho is not wrong to list them under
# aid 239 -- they do contain Naruto -- so this is a deliberate policy reject, not a
# mis-filing guard.
#
# Words below are the ones that legitimately follow a '+' without naming another
# series. The list will never be complete, which is why the length floor below
# carries the real weight.
_SIBLING_EXTRAS = frozenset((
	'movie', 'movies', 'film', 'films', 'ova', 'ovas', 'oad', 'oads', 'special',
	'specials', 'extra', 'extras', 'opening', 'openings', 'ending', 'endings',
	'batch', 'complete', 'collection', 'season', 'seasons', 'remux', 'bluray',
	'dual', 'audio', 'project', 'subtitle', 'subtitles', 'uncensored',
))
# Seven, measured. At five, 'season' (Mushoku Tensei's own alt-title line) and
# 'break' (Re:ZERO Break Time) both produced false rejects; at seven neither does,
# while 'shippuden' and 'shippuuden' still fire. It misses short continuation names
# such as Dragon Ball KAI, and that is the direction to fail in: a miss leaves today's
# behaviour, an over-reject removes a working source.
# LOCAL PATCH 2026-09-22: the feed's real per-page cap is 200, not 75.
# _fetch_index hardcoded limit=75 and a comment in sources_packs asserted the feed capped
# a page there, which is simply wrong: measured on aid 239, limit=150 returns 150 rows and
# limit=300 returns 200, so 200 is the ceiling. That one number is what lets the pack query
# be a SINGLE self-calibrating request -- a 200-row size-sorted page reaches down far enough
# to contain single-file rows (25 of 200 on aid 239) where a 75-row one contains none.
# Costs 1.31s and 199 KB against 0.53s and 74 KB for 75 rows, medians of 3.
_PAGE_MAX = 200

# LOCAL PATCH 2026-09-23: how many times heavier a 'single episode' may be than a file
# inside a pack before it is disbelieved. See _one_episode_size. Measured over the
# 200-row size-sorted window of five aids: JoJo Stone Ocean p1 1.1x, Re:ZERO S2 p1 1.9x,
# Naruto 2.7x, Re:ZERO S1 6.8x (1080p singles against packs holding 480p) -- all
# legitimate. One Piece reads 65.7x. 10 clears every real case and still catches it.
_SINGLE_FILE_SANITY = 10

# LOCAL PATCH 2026-09-23: a MOVIE-numbered range is not an episode range.
#
# AnimeTosho files a franchise's films under the series aid, so a Naruto Shippuden pack
# query returns '[Koten_Gars] Naruto Shippuden - The Movie 1-8' and '[BDMV] Naruto
# Shippuden - The Movie Collection (Movie 1-4)'. _extract_meta reads '1-8' and '1-4' as
# EPISODES, so both were offered for episodes 1 to 8 -- measured, 2 movie rows kept at
# episode 1 and 1 at episode 8, against 0 at episode 32 where the range happens not to
# reach. The films cannot contain a TV episode at any number.
_SEASON_RANGE = re.compile(r'\b(?:seasons?|s)[^a-z0-9]{0,3}\d{1,2}\s*[-~]\s*\d{1,2}', re.I)

_MOVIE_RANGE = re.compile(
	r'\b(?:movies?|films?|gekijou?ban)\b[^a-z0-9]{0,4}(\d{1,2})\s*[-~]\s*(\d{1,2})', re.I)

# LOCAL PATCH 2026-09-23: a bare episode range wrapped in brackets or parentheses.
#
# _extract_meta reads '0629-0686' and '783-1023' but not '(1086-1155)', '(0996-1069)',
# '(892-1085)' or '[0207-0336]' -- the same range, wrapped. '(E01-E12)' parses only
# because of the E. So a One Piece Egghead-arc pack declared nothing, and an unreadable
# name contradicts nothing, which is why it was kept for episode 1.
#
# LOCAL PATCH 2026-09-23 (b): 'to'/'thru' as the separator as well as a dash --
# '[Anime Time] One Piece (1001 to 1085)'. Only inside brackets, where the whole
# bracket IS the range. An unbracketed compound like 'One Piece - 1061, 1062 & 1070 to
# 1076' is deliberately left unread: taking 1070-1076 as its declared set would reject
# a request for 1061, which the name plainly also offers.
#
# Unwrapped for _pack_excludes_episode ONLY. anime_utils' extractor is also what
# cour_match reads, and teaching it a new range form would change episode matching for
# every id-keyed provider; this filter is the one place the gap is known to bite.
_BRACKETED_RANGE = re.compile(
	r'[\(\[]\s*(\d{1,4})\s*(?:[-~]|[\s._]+(?:to|thru)[\s._]+)\s*(\d{1,4})\s*[\)\]]', re.I)


def _unwrap_bracketed_range(name):
	"""'(1086-1155)' -> ' 1086-1155 ', which _extract_meta then reads. Unchanged if none.

	A YEAR span is left wrapped: 'One Piece (TV; Seasons 1 through 4; 1999-2002)' is a
	pack that DOES hold episode 1, and reading 1999-2002 as episodes would reject it.
	Both endpoints plausible years and a reach of 30 or less is the test -- an episode
	range that narrow, that high, would have to be a 4-part pack numbered past 1900."""
	def _sub(m):
		try: lo, hi = int(m.group(1)), int(m.group(2))
		except (TypeError, ValueError): return m.group(0)
		if 1900 <= lo <= 2099 and 1900 <= hi <= 2099 and 0 <= hi - lo <= 30: return m.group(0)
		return ' %d-%d ' % (lo, hi)
	try: return _BRACKETED_RANGE.sub(_sub, name)
	except Exception: return name


def _declares_season_without_episodes(row):
	"""True when the names state a SEASON and no episode range at all.

	'One Piece Season 17 (Dress Rosa) - Vol.15-22' and 'Naruto Shippuden Season 3' say
	which season they are and never say which episodes, so _pack_excludes_episode has
	nothing to test and keeps them -- an unreadable name contradicts nothing. That is the
	right default, but it means a season 17 pack is offered for episode 1.

	The season number itself is NOT compared here. It is TVDB's, not TMDb's, and for a
	cour-split show the two diverge -- that is what cour_season exists for -- while a show
	scraped in absolute order has no meaningful season to compare against at all. So this
	only reports that the name is season-shaped and episode-silent; Fen Light decides what
	to do with that, and does so only for a pack it cannot verify against a file listing.

	A name stating a range is never flagged, however many seasons it also names:
	'One Piece (001-746)(Seasons.01-17)' is verifiable and is left alone.
	"""
	if not (_extract_meta and _clean_for_extract): return False
	names = [n for n in (row.get('title'), row.get('torrent_name')) if n]
	if not names: return False
	names = names + [u for u in (_unwrap_bracketed_range(n) for n in names) if u not in names]
	# A SEASON RANGE is a collection, not one season. _extract_meta reports 'Season 1-18'
	# as seasons=[1] -- it reads the first number only -- so it is indistinguishable from a
	# genuine season 1 pack without this. '[HcLs] Naruto Shippuden Season 1-18' is a
	# complete-series set and must not be dropped. The dash has to follow the digits
	# directly, so 'Season 17 (Dress Rosa) - Vol.15-22' is not caught by it.
	if any(_SEASON_RANGE.search(n) for n in names): return False
	seen_season = False
	for name in names:
		try:
			seasons, episodes, _parts, is_range = _extract_meta(_clean_for_extract(name))
		except Exception:
			continue
		if is_range and episodes: return False
		if seasons: seen_season = True
	return seen_season
_SIBLING_MIN_LEN = 7
_SIBLING_JOIN = re.compile(r'[+&]')
_SIBLING_BRACKETS = re.compile(r'\[[^\]]*\]|\([^)]*\)|\{[^}]*\}')

_SUBDIVISION = re.compile(r'(?:^|[^a-z0-9])(?:box|vol|volume|set|part|pt|disc|disk|s|season)[^a-z0-9]{0,2}\d{1,2}(?:[^a-z0-9]|$)', re.I)

# LOCAL PATCH 2026-09-22: a pack labelled volume N>1 does not start at episode 1.
# The file-count fallback below can only say 'a 6-file pack cannot REACH episode 7',
# never 'volume 2 BEGINS at episode 7', so MTBB's Mushoku Tensei Volume 2 and Volume 3
# were both offered for episode 1 and TACHiKEN's Apothecary Vol 03 for episodes 1-6.
#
# Two guards keep this off the packs it would wreck, both learned from Naruto:
#   - a SPAN is excluded by the lookahead ('Vol.05~12' covers eight volumes, so its
#     181 files are not one volume's worth and the arithmetic below is meaningless);
#   - a pack bigger than _MAX_VOLUME_FILES is excluded, because '[uP] Set.5' with 130
#     files is a box, not a volume, and its own count says nothing about where it starts.
# Measured across Mushoku S1, Apothecary S1+S2 and Naruto: the correct rejects land at
# low episodes (Naruto drops 20 single-volume packs at ep 1, all of them Vol.09+) and
# NOTHING new is rejected at ep 55, 110 or 220 -- the rule only fires where it is sure.
_SINGLE_VOLUME = re.compile(r'\b(?:vol|volume|box|disc|disk|set)[^a-z0-9]{0,2}(\d{1,3})(?![^a-z0-9]{0,2}[-~]\s*\d)', re.I)
_MAX_VOLUME_FILES = 15


class source:
	priority = 5
	# LOCAL PATCH 2026-08-27 (revised): was False. sources() alone can only ever see
	# batches that AnimeTosho has file-indexed and matched to episodes -- most are not,
	# so they sit at anidb_eid=None and an ?eid= query cannot return them. Measured:
	#
	#   anime          packs via ?eid=   packs via ?aid=
	#   Frieren S2            0                10
	#   Bleach TYBW           0                42     <- incl. a 76.6GB BD Remux
	#   Re:ZERO S2 P2         2                16
	#   AoT S3 P2             0                29
	#
	# sources_packs() closes that by asking with the ANIME id instead. Two things make
	# it safe, and neither was true before this week: the aid comes from Fribb offline
	# (so the pack path needs no ani.zip at all), and the debrid layer can now pick the
	# right file out of an anime pack (the 2026-08-27 cour-numbering fix) -- without
	# that, every pack returned here would have failed on click.
	pack_capable = True
	# Anime films are one AniDB episode too, but Fen Light only resolves an eid on the
	# episode path, so a movie scrape would always no-op. Left off until it passes one.
	hasMovies = False
	hasEpisodes = True

	def __init__(self):
		self.language = ['en']
		# ONE index, two domains. .net is the live host; .xyz serves the same data and is
		# tried only when .net cannot be reached -- measured identical by info_hash (48/48
		# and 75/75, zero exclusives either way), so asking both would return the same rows
		# twice and the dedupe would drop every one.
		#
		# feed.animetosho.ORG IS DEAD AND MUST NOT BE ADDED BACK. It still answers HTTP 200
		# with a full-looking payload, which is exactly the trap: its index STOPPED UPDATING
		# on 2026-05-07. Measured 2026-09-15 on the `timestamp` field --
		#
		#   Re:ZERO S4  aid=19242 : .net newest 2026-09-14   .org newest 2026-05-07
		#   Bleach TYBW eid=259237: .net newest 2025-03-22   .org newest 2022-12-28
		#
		# so it looked like a second index worth merging (75 rows on Re:ZERO sharing NOTHING
		# with .net) when those rows were simply everything .net had already moved past. For
		# a currently-airing show it can only contribute stale, likely-dead torrents and one
		# wasted request per scrape. Freshness here is the `timestamp` field, not HTTP status.
		self.base_link = 'https://feed.animetosho.net'
		# NOT self.sources -- that name is the provider's own sources() METHOD, and assigning
		# it here silently replaced the bound method with a tuple. The loader hands the class
		# to Fen Light, which calls module().sources(data, hostDict); with the attribute set,
		# every scrape died on "'tuple' object is not callable" and animetosho returned zero
		# rows while every other provider looked fine.
		self.feed_hosts = ((self.base_link, 'https://feed.animetosho.xyz'),)
		# Matches nyaa.py: this provider is debrid-only, and a 0-seeder torrent can
		# still be cached and instantly playable, so seeders must not gate it here.
		self.min_seeders = 0

	# LOCAL PATCH 2026-09-15: query BOTH hosts and merge, deduped on info_hash.
	#
	# .net and .org run the same software over INDEPENDENTLY BUILT indexes -- neither is a
	# mirror of the other and neither is a superset. Measured 2026-09-15 on eid=259237:
	# .org 31 rows, .net 48, sharing only 20 info_hashes. So .org held 11 releases .net
	# could not see and .net held 28 .org could not. Asking one host silently costs results.
	#
	# Dedupe is on info_hash and NEVER on `id`: the two hosts number their rows separately,
	# so the same release carries a different id on each and an id-keyed merge would return
	# every duplicate twice. magnet_uri is the fallback key for a row with no hash.
	#
	# Hosts are tried in order and a failing one is skipped, so this is also the failover:
	# either host being down degrades results rather than emptying them. Cost is one extra
	# request per query, both keyless and ~0.9s.
	def _fetch_index(self, host, params, pages, limit=75):
		"""All pages from ONE host, or None if the host could not be reached.

		None and [] mean different things and the caller depends on it: None is "ask this
		index's other domain", [] is "this index answered and genuinely has nothing"."""
		out = []
		for page in range(1, pages + 1):
			url = '%s/json?%s&limit=%d%s' % (host, params, limit,
										'&page=%d' % page if page > 1 else '')
			try:
				batch = _json.loads(client.request(url, timeout=10) or '[]')
			except Exception:
				return None if not out else out
			if not isinstance(batch, list): return None if not out else out
			out.extend(batch)
			# A short page means the index is exhausted. Compared against the limit ASKED for,
			# not a literal 75, or a 200-row request would always look short and stop early.
			if len(batch) < limit: break
		return out

	def _query(self, params, pages=1, limit=75):
		"""Rows from every index, deduped on info_hash.

		One entry in self.feed_hosts is one INDEX; its domains are interchangeable, so the first
		that answers wins and the rest are skipped -- querying an alias would return the same
		rows and every one would be dropped by the dedupe anyway. Indexes, by contrast, hold
		different releases and are all merged.

		Dedupe is on info_hash and NEVER on `id`: the indexes number rows separately, so the
		same release carries a different id on each and an id-keyed merge would double every
		shared row. magnet_uri is the fallback key for a row carrying no hash.
		"""
		rows, seen = [], set()
		for domains in self.feed_hosts:
			for host in domains:
				batch = self._fetch_index(host, params, pages, limit)
				if batch is None: continue          # unreachable -- try this index's alias
				for row in batch:
					if not isinstance(row, dict): continue
					key = (row.get('info_hash') or row.get('magnet_uri') or '').lower()
					if key:
						if key in seen: continue
						seen.add(key)
					rows.append(row)
				break                                # this index answered; skip its aliases
		return rows

	def _one_episode_size(self, rows):
		"""What one episode of this anime weighs, from the single-file rows in `rows`.

		Self-calibrating on purpose. A hardcoded "packs are over N GB" would be wrong
		across a 350MB SD show and a 3GB 1080p one, and reading "Batch" out of the title
		would be the name parsing this provider exists to avoid. The separation is wide:
		real batches measured at 18.5x and 45.7x the median, while the false positive
		this rejects -- one episode shipping a separate subtitle file -- sat at 0.5x.
		"""
		singles = [r.get('total_size') or 0 for r in rows
				if isinstance(r, dict) and int(r.get('num_files') or 1) == 1]
		singles = [x for x in singles if x > 0]
		one = _median(singles) if (singles and _median) else 0
		# LOCAL PATCH 2026-09-23: a single FILE is not always a single EPISODE.
		#
		# AnimeTosho files a franchise's FILMS under the series aid. On One Piece (aid 69) the
		# size-sorted window holds 195 multi-file rows and just 5 single-file ones -- and all
		# five are Film Red remuxes, 31 to 53 GB. Their median, 45.30 GB, then became 'one
		# episode', so _is_pack's 2x threshold sat at 90.6 GB and 111 of those 195 packs were
		# judged NOT packs. [F-R] One Piece 0629-0686 (58 files) and [Judas] One Piece 783-1023
		# (241 files) were offered as the single episode S1E1, and being unlabelled they also
		# escaped every pack safeguard downstream -- the real-size correction and the
		# drop-if-it-lacks-the-episode check both require the package tag.
		#
		# The cross-check: a file INSIDE a pack is an episode by construction, so the median
		# per-file size of the multi-file rows says what an episode of this show weighs without
		# trusting any name. One Piece reads 0.69 GB against the 45.30 GB above, a 66x
		# contradiction. Only a contradiction this large intervenes -- a show whose singles are
		# simply higher quality than its packs is normal and must not be touched (Re:ZERO S1
		# reads 6.8x and is correct).
		#
		# Deliberately a VETO, not a replacement. The single-file median stays the measurement
		# everywhere it is sane; the pack statistic only overrides it when it is provably
		# describing something that is not an episode. Two earlier attempts to derive this
		# threshold FROM the pack rows failed, so it is not trusted as the primary reading.
		if not one: return 0
		per_file = []
		for r in rows:
			if not isinstance(r, dict): continue
			try: n = int(r.get('num_files') or 1)
			except (TypeError, ValueError): continue
			if n < 2: continue
			try: size = float(r.get('total_size') or 0)
			except (TypeError, ValueError): continue
			if size > 0: per_file.append(size / n)
		# No pack rows to cross-check against (a film entry, or an eid query returning only
		# single files) -- nothing contradicts the reading, so keep it.
		if not (per_file and _median): return one
		typical = _median(per_file)
		if typical and one > _SINGLE_FILE_SANITY * typical: return typical
		return one

	def _is_pack(self, row, one_episode, allow_unknown=False):
		"""Several files only means a pack if it also weighs like one.

		LOCAL PATCH 2026-09-22: `allow_unknown` covers the case where one_episode could not
		be measured at all -- no single-file row in the window to take a median of. The old
		unconditional `if not one_episode: return False` then rejected EVERY row, so the
		provider returned nothing at all, silently. Measured on aid 239: a size-sorted window
		of a 220-episode show holds 0 single-file rows, so the threshold was 0 and all 137
		real packs were dropped.

		With no threshold the file count alone has to decide, which re-admits the one false
		positive the size test exists to catch -- a single episode shipping a separate
		subtitle. That is the right trade ONLY where the alternative is returning nothing, so
		it is opt-in per caller: sources() keeps the strict reading, since there a mislabel
		would relabel a real result rather than rescue a lost one."""
		try:
			if int(row.get('num_files') or 1) < 2: return False
			if not one_episode: return bool(allow_unknown)
			return float(row.get('total_size') or 0) >= 2 * one_episode
		except (TypeError, ValueError): return False

	def _build(self, row, data, package, undesirables, check_foreign_audio):
		"""One feed row -> one Fen Light source, or None if it should be dropped."""
		info_hash = (row.get('info_hash') or '').lower()
		magnet = row.get('magnet_uri')
		if not info_hash or not magnet: return None
		# Which of the two names to use depends on what the row IS.
		#   single file -> `torrent_name` is the actual filename, the most accurate thing
		#                  available, and better than the posting title.
		#   pack        -> `torrent_name` is the torrent's ROOT FOLDER, which is often
		#                  useless or unreadable. A real example: a 115-file complete-series
		#                  pack whose folder is "[Furretar] 台粤 - 进击的巨人 V5" reduces to
		#                  just "V5" once non-ASCII is stripped, losing the release entirely,
		#                  while its title reads "(Season 1-4 + Kanketsu-hen ...)". Titles
		#                  also carry the resolution and codec tags that folders omit, which
		#                  is what quality detection and the REMUX filter read.
		posting, filename = row.get('title') or '', row.get('torrent_name') or ''
		raw = (posting or filename) if package else (filename or posting)
		# Descriptive rejects, not identity ones: this only asks what KIND of thing the
		# row is, never which episode it is.
		if _DISC_STRUCTURE.search(raw): return None
		name = source_utils.clean_name(raw)
		if not name: return None
		# name_info drives Fen Light's quality and tag detection (REMUX / BLURAY / HEVC /
		# AV1 / WEB / audio codecs). Without it, scrapers/external.py falls back to parsing
		# the magnet URL, where url_strip() flattens separators to spaces and the dotted
		# tokens get_info() looks for ('.web.', '.av1.', '.sdr') can never match -- so rows
		# arrived under-tagged and were sorted and filtered wrongly.
		name_info = source_utils.info_from_name(
			name, data.get('tvshowtitle') or '', str(data.get('year') or ''),
			season=str(data.get('season') or ''), pack=package)
		# These read the name only to DESCRIBE or veto a release, never to decide which
		# episode it is. A misread here costs one row; a misread episode plays the wrong
		# thing -- which is why episode identity comes from the id and never from here.
		if source_utils.remove_lang(name_info, check_foreign_audio): return None
		if undesirables and source_utils.remove_undesirables(name_info, undesirables): return None
		try:
			seeders = int(row.get('seeders') or 0)
			if seeders < 0: seeders = 0   # AnimeTosho reports -1 for "unknown"
		except (TypeError, ValueError): seeders = 0
		if self.min_seeders > seeders: return None
		quality, info = source_utils.get_release_quality(name_info, magnet)
		# total_size is bytes, unlike the human-readable strings every other provider
		# scrapes, so it is converted here rather than via _size().
		#
		# Packs report a PER-EPISODE size computed from their own file count, and
		# scrapers/external.py is told not to divide them again (this provider is in its
		# no-divide list). That list exists because Fen Light's default is to divide a
		# pack by the TMDb season's episode_count, which for anime is routinely nothing
		# to do with what the pack holds -- TMDb files every Re:ZERO cour under season 1,
		# so its episode_count is 85 while a cour pack has 12 files, and a 65GB BD remux
		# was displaying as 0.77GB. Measured errors before this: 7.1x under for Re:ZERO,
		# 3.8x for Bleach, 2.8x for Frieren, all understated and so sorted far too low.
		#
		# num_files is not perfect -- a release shipping subtitles as separate files
		# inflates it and understates the result -- but it is the pack's own count
		# rather than an unrelated number, and it was closer in every case measured.
		try:
			total = float(row.get('total_size') or 0) / 1073741824
			files = int(row.get('num_files') or 1) if package else 1
			dsize = round(total / max(files, 1), 2)
			if dsize: info.insert(0, '%.2f GB' % dsize)
			# The full size still matters -- it is what the debrid service has to hold.
			if package and total: info.append('%.1f GB pack' % total)
		except (TypeError, ValueError): dsize = 0
		item = {'provider': 'animetosho', 'source': 'torrent', 'seeders': seeders,
				'hash': info_hash, 'name': name, 'name_info': name_info, 'quality': quality,
				'language': 'en', 'url': magnet, 'info': ' | '.join(info), 'direct': False,
				'debridonly': True, 'size': dsize}
		# LOCAL PATCH 2026-09-22: the release group, for the picker's Group column. Read
		# from `raw` because clean_name() has already stripped the leading bracket tag off
		# `name`, which is where a fansub group lives.
		group = source_utils.release_group(raw)
		if group: item['release_group'] = group
		if package: item['package'] = package
		# LOCAL PATCH 2026-09-23: tell Fen Light this pack's name names a season and no
		# episodes, so it can drop it when no file listing exists to check it against.
		# Packs only -- a single-file row is its own evidence.
		if package:
			try:
				if _declares_season_without_episodes(row): item['season_only'] = True
			except Exception: pass
		return item

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		eid = data.get('anidb_eid')
		# No eid means the chain upstream could not identify the episode (a show with no
		# Fribb cour row, or ani.zip unreachable). Returning nothing is correct -- guessing
		# from names here would reintroduce exactly what this provider avoids.
		if not eid:
			# LOCAL PATCH 2026-09-22: say so. This return is the single most common reason this
			# provider contributes nothing (no Fribb row, or ani.zip withholding an eid for a
			# whole-run entry -- Naruto, Naruto Shippuden), and it fired BEFORE the diag line at
			# the end of this method, so the log showed nothing at all and it looked like a
			# scrape that simply found no releases.
			try:
				import xbmc as _x
				_x.log('TOSHO-DIAG: sources SKIPPED, no anidb_eid (aid=%s) -- packs only for this show'
					% data.get('anidb_aid'), _x.LOGINFO)
			except Exception: pass
			return sources
		try:
			rows = self._query('eid=%s' % eid)
			if not rows: return sources
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('ANIMETOSHO')
			return sources

		one_episode = self._one_episode_size(rows)
		cour_season = data.get('cour_season')
		# LOCAL PATCH 2026-09-22: title + aliases, for cour_match's title-anchored episode
		# read. Built the same way sources_packs builds its own list.
		_titles = []
		if alias_titles:
			try: _titles = [t for t in ([data.get('tvshowtitle')] + alias_titles(data)) if t]
			except Exception: _titles = []
		seen = set()
		_cour_rejected = 0
		for row in rows:
			try:
				if not isinstance(row, dict): continue
				# A multi-file row here is a batch that CONTAINS this eid, so it is a
				# legitimate result and is kept, labelled so Fen Light shows it as a PACK.
				package = 'season' if self._is_pack(row, one_episode) else None
				# LOCAL PATCH 2026-09-15: reject a row whose NAME contradicts the cour asked for.
				# This provider trusts the index and parses no names, which is right until the
				# index is wrong -- and here it is. AnimeTosho files a batch of Re:ZERO SEASON 4
				# releases under season 1's ids: ?eid=176270 (Re:ZERO S1 ep1, via anilist 21355)
				# returned 64 rows all reporting anidb_aid=11370, nine of them plainly "S04E01".
				# Those same releases also sit correctly under eid=309964, so this is a bad file
				# match upstream, not AniDB folding the seasons together. Measured 2026-09-15:
				# cour_match dropped exactly those 9 and kept all 55 real ones.
				#
				# A REJECT, never an identity test -- the eid still decides which episode this is.
				# cour_season is Fribb's season.tvdb, the number releases actually write, never
				# TMDb's -- which is the objection sources_packs raises against filter_season_pack
				# and the reason that one stays unvalidated. Skipped when the cour context is
				# absent, so a show with no Fribb row keeps the old trust-the-index behaviour.
				# Packs are exempt: a batch spanning cours is a legitimate answer to this query.
				if cour_season and not package and cour_match:
					_nm = row.get('torrent_name') or row.get('title') or ''
					if not cour_match(_nm, cour_season=cour_season,
									cour_episode=data.get('cour_episode'),
									absolute_episode=data.get('absolute_episode'),
									season_episode=data.get('season_episode'),
									cour_part=data.get('cour_part'),
									foreign_tokens=data.get('foreign_cour_tokens'),
									titles=_titles,
									# The eid already identified this episode; the name is only being read for a
									# CONTRADICTION. See cour_match's trust_id -- a name with no season marker, or a
									# bare cour-relative number in a split season, contradicts nothing.
									trust_id=True):
						_cour_rejected += 1
						continue
				item = self._build(row, data, package, undesirables, check_foreign_audio)
				if not item or item['hash'] in seen: continue
				seen.add(item['hash'])
				sources.append(item)
			except Exception:
				source_utils.scraper_error('ANIMETOSHO')
				continue
		# LOCAL PATCH 2026-09-21: this provider reported nothing about its own work, so a
		# silent over-reject looked exactly like the index having no releases. That hid the
		# split-cour bug fixed in anime_utils.cour_match the same day: 32 rows came back for
		# eid 246509 and 5 were dropped, with nothing on screen or in the log saying so.
		# Mirrors nyaa.py's NYAA-DIAG so both anime providers report the same way.
		try:
			import xbmc as _x
			_x.log('TOSHO-DIAG: sources eid=%s raw=%d cour_rejected=%d kept=%d'
				% (eid, len(rows), _cour_rejected, len(sources)), _x.LOGINFO)
		except Exception: pass
		return sources

	# LOCAL PATCH 2026-09-22: a pack whose NAME declares an episode range must actually
	# contain the episode being scraped.
	#
	# sources_packs applies no validation because "an AniDB aid IS one cour", so every row
	# belongs to the right anime and cour. That holds for a 12-26 episode entry. It breaks
	# for a long single-entry show: Naruto is ONE aid (239) covering all 220 episodes, so
	# its packs are BOX / VOL / SET / EP-range subdivisions and "right anime" no longer
	# implies "holds this episode". Observed 2026-09-22 scraping S4E212: 21 results, among
	# them "(EP 37-50)" and "(EP 51-76)", neither of which can serve episode 212.
	#
	# This is a range REJECT, not the season parsing that docstring argues against: it reads
	# no season number and compares nothing to TMDb. A pack that declares no range is kept
	# untouched, so BOX 01 / VOL 09 / SET 1 and every cour-sized pack behave as before.
	def _pack_excludes_episode(self, row, wanted):
		"""True only when the names state a range and the wanted episode is outside it."""
		if not (_extract_meta and _clean_for_extract): return False
		# LOCAL PATCH 2026-09-22: read BOTH name fields, not `torrent_name or title`.
		# A row carries two names and either may be the informative one. Measured on
		# aid 17870: the 14-file [sam] pack has torrent_name '[sam] Kusuriya no
		# Hitorigoto [BD 1080p FLAC]' -- no range at all -- while its title reads
		# '[sam] The Apothecary Diaries Season 1 (S01) (E01-E12) | ...'. Preferring
		# torrent_name threw the range away and the pack was offered for E13/E14. The
		# 28-file pack in the same feed has an EMPTY torrent_name, so neither field can
		# be preferred outright -- and _build already reads them the other way round for
		# packs (`posting or filename`), so the two disagreed about the same row.
		names = [n for n in (row.get('title'), row.get('torrent_name')) if n]
		if not names: return False
		# LOCAL PATCH 2026-09-23: add an unwrapped variant of any name carrying a bracketed
		# range, so the loop below can read it. ADDED, never substituted -- the original name
		# stays in the list, so nothing that already parsed can start parsing differently.
		names = names + [u for u in (_unwrap_bracketed_range(n) for n in names) if u not in names]
		# LOCAL PATCH 2026-09-23: a film collection cannot hold a TV episode.
		#
		# Only when the movie range is the ONLY range the name states. 'One Piece Collection
		# 1-750 + OVAs + Specials + Movies 1-12' names both, and it is a legitimate episode
		# pack that happens to bundle the films -- rejecting on the mere presence of the word
		# would throw it away. So the movie range is stripped and the name re-read: if an
		# episode range survives, the normal logic below decides; if nothing does, the row was
		# only ever describing films.
		if any(_MOVIE_RANGE.search(n) for n in names):
			_leftover = False
			for _n in names:
				try:
					_s, _e, _p, _r = _extract_meta(_clean_for_extract(_MOVIE_RANGE.sub(' ', _n)))
				except Exception:
					continue
				if _r and _e:
					_leftover = True
					break
			if not _leftover: return True
		declared = set()
		for name in names:
			try:
				_seasons, episodes, _parts, is_range = _extract_meta(_clean_for_extract(name))
			except Exception:
				continue
			if is_range and episodes: declared.update(episodes)
		# Any name that states a range is evidence; the union is what the pack can hold.
		if declared:
			return not (wanted & declared)
		# A single numbered volume cannot hold an episode that sits inside volume 1's span.
		# Only the LOW end is tested: volume sizes vary between groups (MTBB's Apothecary
		# volumes run 6-7 files while Lia's Mushoku Volume 3 declares episodes 12-17), so an
		# upper bound from one pack's file count would produce false rejects. The lower bound
		# does not depend on that variation.
		for name in names:
			m = _SINGLE_VOLUME.search(name)
			if not m: continue
			try:
				volume = int(m.group(1)); files = int(row.get('num_files') or 1)
			except (TypeError, ValueError):
				continue
			if volume >= 2 and 1 <= files <= _MAX_VOLUME_FILES and max(wanted) <= files:
				return True

		# No range declared by either name. A numbered subdivision is then unverifiable
		# from the name, so fall back to the one hard fact the feed gives: its file count.
		# A pack cannot reach episode N even numbered from 1 if it holds fewer than N
		# files, so Box 05 with 27 files cannot serve episode 212.
		#
		# Compared against the SMALLEST candidate numbering on purpose. A cour pack
		# legitimately holds 12 files while the absolute number is 212, so testing the
		# largest would reject every cour pack in the library. Taking the smallest means
		# this can only fire when even the lowest plausible episode number exceeds the
		# pack -- exactly the long single-entry shows this is for (Naruto: one aid for 220
		# episodes, and TOSHO-DIAG shows wanted=[220], a single number). Cour anime is
		# untouched, its cour_episode being small.
		#
		# Cost, accepted deliberately: Box 8 really does hold episode 212 and is rejected
		# along with Box 1, because the name never says which episodes it covers. The
		# complete-series packs DO declare 001-220 and still answer.
		if any(_SUBDIVISION.search(n) for n in names):
			try: files = int(row.get('num_files') or 1)
			except (TypeError, ValueError): return False
			return files < min(wanted)
		return False


	def _spans_sibling_series(self, row, titles):
		"""The distinguishing word when a '+' segment names another series, else None."""
		if not titles: return None
		# LOCAL PATCH 2026-09-22: both names, same reason as _pack_excludes_episode --
		# torrent_name is empty on some rows and abbreviated on others.
		name = ' | '.join(n for n in (row.get('title'), row.get('torrent_name')) if n)
		# Bracketed groups carry release tags and fansub names, never a second series.
		body = _SIBLING_BRACKETS.sub(' ', name)
		segments = _SIBLING_JOIN.split(body)
		if len(segments) < 2: return None
		known = set()
		for title in titles:
			known.update(w for w in re.split(r'[^a-z0-9]+', title.lower()) if w)
		for segment in segments[1:]:
			for word in re.split(r'[^a-z0-9]+', segment.lower()):
				if len(word) < _SIBLING_MIN_LEN: continue
				if word in known or word in _SIBLING_EXTRAS: continue
				return word
		return None

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		"""Season packs, found with the ANIME id rather than the episode id.

		Why a separate query rather than more of sources(): a batch only carries an
		anidb_eid once AnimeTosho has file-indexed it and matched its files to episodes,
		and most are never indexed. Asking by aid sidesteps that, and is where nearly all
		the packs actually live -- 42 for Bleach TYBW against 0 by eid.

		No title or season validation is applied, and `bypass_filter` is therefore unused.
		That is deliberate rather than lax: an AniDB aid IS one cour, so every row this
		query returns already belongs to the exact anime and cour being scraped. Running
		filter_season_pack over them would re-introduce the name parsing this provider
		exists to avoid AND reject correct rows -- it looks for "S02"-style markers against
		TMDb's season number, which for anime is routinely not what the release says.
		torrentio's kitsu path skips validation for the same reason.
		"""
		sources = []
		if not data: return sources
		# AniDB files an anime per cour, so there is no whole-franchise grouping to ask
		# for. Returning nothing is honest; nyaa still answers show-pack requests.
		if search_series: return sources
		aid = data.get('anidb_aid')
		if not aid: return sources
		try:
			# LOCAL PATCH 2026-09-22: ONE request, biggest rows first, at the feed's real page cap.
			#
			# Three things were learned in order, and the current shape is the third:
			#
			#  1. Ask for the BIGGEST rows, not the newest. The default order is date-descending,
			#     which on a long-running anime is an arbitrary slice -- aid 17870 has 477 rows over
			#     7 pages. Packs are the only thing this method wants and packs are by definition the
			#     large rows. `order` accepts ONLY size-d and size-a: date-d, seeders-d and a
			#     deliberately bogus value all return the default order, so there is no seeders sort
			#     to be had here and a typo fails quietly.
			#
			#  2. Sorting by size destroys the sample that sets the pack threshold, which is why this
			#     used to issue a second, unsorted request. _one_episode_size medians the SINGLE-FILE
			#     rows it is handed, and the biggest 75 rows of a long show are ALL multi-file -- so a
			#     75-row sorted page holds no single-file row at all, the median is 0, and _is_pack
			#     rejected every row. Measured: one 75-row sorted page alone returned 0 packs for
			#     Naruto, silently, while Apothecary (39) and Ace (4) looked fine.
			#
			#  3. The cap is 200, not 75 (see _PAGE_MAX), and that dissolves the problem in 2. A
			#     200-row sorted page reaches far enough down the index to contain single-file rows --
			#     25 of 200 on aid 239 -- so one request carries both the packs and its own
			#     calibration. Packs kept end to end, measured 2026-09-22:
			#
			#       config                          req   Naruto   Apothecary S1   Ace of Diamond
			#       2 sorted pages + calibration     3       62          38              4
			#       1 sorted page  + calibration     2       62          38              4
			#       1 sorted page, 200 rows          1       75          37              4
			#
			#     Strictly better than any two-request version on the show that matters, and one fewer
			#     round trip. The price is one pack on Apothecary: its 200-row window is 160 singles,
			#     so the median runs high (1.30 GB against the unsorted sample's 0.69) and the
			#     threshold with it. On aid 239 the two agree closely (0.76 vs 0.70 GB).
			#
			# The 0-packs failure in 2 is guarded rather than merely avoided: the cap is undocumented,
			# and if it ever returns to 75 a sorted window loses its singles again. _is_pack's
			# allow_unknown makes that case fall back to the file count instead of dropping everything,
			# and one_ep is now in the diag line so a zeroed threshold is visible in the log.
			# LOCAL PATCH 2026-09-22: ask every part of this season, not just the one being
			# scraped. A split season is several AniDB entries, and a pack covering the WHOLE
			# season is filed under the FIRST part's aid, so a query made from part 2's aid never
			# sees it although it plainly holds part 2's episodes. Measured, packs per part:
			#   JoJo Stone Ocean   p1 12   p2 2   p3 1
			#   Mushoku Tensei S1  p1 83   p2 13
			#   Mushoku Tensei S2  p1 39   p2 6
			# and part 1's biggest row gives it away every time -- 46 files for a 38-episode
			# Stone Ocean, 250 for Mushoku S02. Whole-season releases, not part-1 releases.
			#
			# One request per part, and a season has one part for most anime, so this costs
			# nothing at all outside split cours. Rows are merged and deduped on info_hash, and
			# every one still faces the same validation: _pack_excludes_episode against a range
			# the name declares, _spans_sibling_series, and -- for a cached pack -- the file
			# listing check in Fen Light that proves whether the episode is actually inside.
			#
			# The current aid is asked FIRST so that a partial failure still returns this part's
			# own packs, which are the ones most likely to be right.
			_aids = [aid]
			for _pa in (data.get('anidb_part_aids') or []):
				try:
					if int(_pa) != int(aid): _aids.append(int(_pa))
				except (TypeError, ValueError): continue
			rows, _seen_h, _own_h = [], set(), set()
			for _a in _aids:
				for _r in (self._query('aid=%s&order=size-d' % _a, pages=1, limit=_PAGE_MAX) or []):
					if not isinstance(_r, dict): continue
					_k = (_r.get('info_hash') or _r.get('magnet_uri') or '').lower()
					if _k:
						if _k in _seen_h: continue
						_seen_h.add(_k)
					rows.append(_r)
					if _k and int(_a) == int(aid): _own_h.add(_k)
			if not rows: return sources
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('ANIMETOSHO')
			return sources

		# One window, self-calibrating. A 200-row size-sorted page reaches far enough down the
		# index to include single-file rows even on a long-running show (25 of 200 on aid 239),
		# so the median that sets the pack threshold comes out of the same request as the packs.
		# Measured: sorted-200 gives 0.76 GB against the unsorted sample's 0.70 GB on aid 239 --
		# close enough that the bias which forced a separate page at 75 rows is gone. Where the
		# window is mostly singles the median still runs high (Apothecary 1.30 vs 0.69 GB), which
		# costs exactly one pack there and is the whole price.
		one_episode = self._one_episode_size(rows)
		# No single-file row in the window at all: judge on file count rather than dropping
		# everything. See _is_pack's allow_unknown.
		_no_threshold = not one_episode
		# Any of the three numberings may be the one a pack counts in, so a hit on any is
		# enough: a cour pack says 1-12 while the absolute number is 41.
		# LOCAL PATCH 2026-09-22: the COUR-RELATIVE number is dropped once sibling parts have
		# been merged in, because it is ambiguous across them -- every part restarts at 1.
		#
		# Re:ZERO S2 is two parts. Asking for part 2 episode 1 gives cour_episode=1, and a
		# PART 1 pack declaring '01~12' contains 1, so _pack_excludes_episode let it through
		# and part 1's packs appeared in part 2's results -- both parts returned an identical
		# 65. The season-relative number (13) and the absolute one (39) both count across the
		# whole season, so they cannot collide between its parts; they are the only numbers
		# that mean anything once the windows are merged. Exactly the reasoning cour_match
		# applies at its step 3b for the same reason.
		#
		# Only when siblings were actually merged. A single-part season keeps all three, where
		# the cour-relative number is often the only one a release name carries.
		# ...but ONLY for a row that came from a SIBLING part. Which numbering a declared
		# range speaks is decided by which entry the row is filed under, not by the name:
		# '[Erai-raws] Re:Zero ... 2nd Season Part 2 - 01 ~ 12' under part 2's aid counts
		# PART-relative, so its 1-12 really is this part's episodes 1-12, while the identical
		# '01~12' under part 1's aid is part 1's. Measured on Re:ZERO S2 part 2 episode 1: of
		# the 22 packs a blanket drop of the cour number rejected, 13 came from part 2's own
		# aid and were correct, 9 came from part 1's and were not.
		def _num(_key):
			try:
				_v = data.get(_key)
				return None if _v is None else int(_v)
			except (TypeError, ValueError): return None
		_wanted = set(x for x in (_num('cour_episode'), _num('season_episode'),
			_num('absolute_episode')) if x is not None)
		_wanted_sibling = set(x for x in (_num('season_episode'), _num('absolute_episode'))
			if x is not None) if len(_aids) > 1 else _wanted
		_range_rejected = _sibling_rejected = 0
		# Title + aliases, via anime_utils so the normalisation lives in one place.
		_titles = []
		if alias_titles:
			try: _titles = [t for t in ([data.get('tvshowtitle')] + alias_titles(data)) if t]
			except Exception: _titles = []
		seen = set()
		for row in rows:
			try:
				if not isinstance(row, dict): continue
				if not self._is_pack(row, one_episode, allow_unknown=_no_threshold): continue
				_w = _wanted if (row.get('info_hash') or '').lower() in _own_h else _wanted_sibling
				if _w and self._pack_excludes_episode(row, _w):
					_range_rejected += 1
					continue
				if self._spans_sibling_series(row, _titles):
					_sibling_rejected += 1
					continue
				item = self._build(row, data, 'season', undesirables, check_foreign_audio)
				if not item or item['hash'] in seen: continue
				seen.add(item['hash'])
				sources.append(item)
			except Exception:
				source_utils.scraper_error('ANIMETOSHO')
				continue
		try:
			import xbmc as _x
			_x.log('TOSHO-DIAG: packs aid=%s parts=%d raw=%d one_ep=%.2fGB range_rejected=%d sibling_rejected=%d kept=%d wanted=%s'
				% (aid, len(_aids), len(rows), (one_episode or 0) / 1073741824.0, _range_rejected,
				_sibling_rejected, len(sources), sorted(_wanted) or '-'), _x.LOGINFO)
		except Exception: pass
		return sources
