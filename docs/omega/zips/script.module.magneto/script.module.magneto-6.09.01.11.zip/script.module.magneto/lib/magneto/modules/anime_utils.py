# -*- coding: utf-8 -*-
"""Anime release-name parsing, shared by the magneto providers.

LOCAL PATCH 2026-08-27. Extracted verbatim from providers/torrents/nyaa.py, which
was the only place in magneto that could read an anime release name. comet needs
the same parsing for its kitsu path, and duplicating it would have meant two
copies of some very fiddly regexes drifting apart.

Nothing here is new and nothing existing changed behaviour: source_utils.check_title
and the rest of the shared matcher are untouched, so non-anime scraping is
unaffected. The names keep their leading underscores so nyaa.py needed no edits
beyond the import.

What this handles that the western matcher cannot:
  - season markers inside brackets: "(Season 3)", "[S01-02]"
  - the absolute-numbering convention: "S03E20.(57)" is ONE episode, not 20-57
  - bare ordinals: "Re:Zero ... 4th - 01~11" is season 4
  - cour/part ranges: "Season 3 Part 2 - 01 ~ 10"
"""
import re


_TOKEN_STOPWORDS = frozenset((
	'the', 'and', 'of', 'a', 'an', 'in', 'on', 'to', 'for',
	'season', 'part', 'cour', 'movie', 'ova', 'tv', 'anime',
	'no', 'wa', 'ga', 'ni', 'wo', 'ka', 'kara', 'made',
))

_ROMAN_MAP = {'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5}
_WORD_MAP = {'first': 1, 'second': 2, 'third': 3, 'fourth': 4, 'fifth': 5,
			 'sixth': 6, 'seventh': 7, 'eighth': 8}

# Otaku-style: strip quality/codec/audio noise BEFORE regex-extracting season/ep.
_NOISE_PATTERNS = re.compile(
	r'\b(?:360p|480p|576p|720p|1080p|1440p|2160p|4k)(?!\d)'
	r'|\b10\s?bits?\b'
	r'|\b(?:h\.?\s?264|x\.?\s?264|h\.?\s?265|x\.?\s?265|hevc|avc|hls|vp9|av1)(?!\d)'
	r'|\b(?:web-dl|webrip|bluray|hdrip|dvdrip|hdtv|pdtv|cam|screener|bdrip)\b'
	r'|\b(?:hdr10\+?|hdr|sdr|dv|dolby\s?vision|dovi)\b'
	r'|\b(?:mp4|mkv|mpeg|xvid|divx|wmv|flac)\b'
	r'|\b(?:aac|mp3|opus|ddp|dd|ac3|dts(?:-hdma|-hdhr|-x)?|atmos|truehd)(?:\d+(?:\.\d+)?)?\b'
	r'|\b(?:1\.0|2\.0|5\.1|7\.1|2ch|5ch|7ch|8ch)\b'
	r'|\b(?:multi\s?audio|dual\s?audio|dub(?:bed)?|multi\s?sub|subbed|multi[- ]?sub(?:title)?s?)\b'
	, re.I
)


def _tokenize(text):
	"""Lowercase word tokens of length >=3, stopwords removed."""
	if not text: return set()
	words = re.findall(r'[A-Za-z0-9]+', str(text).lower())
	return {w for w in words if len(w) >= 3 and w not in _TOKEN_STOPWORDS}


# LOCAL PATCH 2026-08-27: contiguous title matching.
#
# The accept_tokens guard below accepts a row when it shares ANY ONE token with the
# title set. For Re:ZERO that set is {zero, starting, life, another, world, different,
# from}, so a single generic word was enough and these all came through as Re:ZERO:
#
#   Fate.Zero / Aldnoah.Zero / Eden.Zero / Ga-Rei-Zero / Zero.no.Tsukaima   (zero)
#   The.World's.Finest.Assassin...                                        (world)
#   Steins;Gate / Our.Dating.Story...                                     (one word)
#
# Overlap SIZE cannot separate them: the romaji 'Re:Zero kara Hajimeru Isekai
# Seikatsu' also shares exactly one token (zero) and is legitimate. What does separate
# them is ADJACENCY -- a real release contains a title candidate as consecutive words.
# 'Ga Rei Zero' never contains the pair (re, zero); 'Re Zero kara ...' always does.
#
# Measured over 6 shows / 211 accepted rows: drops exactly the 10 wrong-show entries,
# keeps all 201 legitimate ones.
#
# Apostrophes are deleted rather than treated as separators so that TMDb's
# "Journey's End" and a group's "Journeys.End" produce the same token run.
_APOS = re.compile('[' + chr(39) + chr(0x2019) + chr(0x02BC) + ']')


def _title_seq(text):
	"""Ordered alphanumeric word run. Keeps short words -- adjacency needs them."""
	return re.findall(r'[a-z0-9]+', _APOS.sub('', str(text or '').lower()))


# What may legally sit next to a title match. Anything else means the name belongs to
# a DIFFERENT, longer-titled show: 'Boruto - Naruto Next Generations' and 'Naruto
# Shippuden' both contain 'Naruto' and are separate TMDb shows, so plain containment
# lets them answer a Naruto request.
_TITLE_EDGE_OK = re.compile(
	r'^(?:\d+|\d+(?:st|nd|rd|th)|s\d+\w*|e\d+|v\d+|ep\d*|complete|series|batch|collection|season|seasons|'
	r'part|parts|pt\d*|cour|vol|volume|movie|movies|ova|oad|oav|special|specials|nc\w*|'
	r'bd|bdrip|bdmv|bluray|blu|ray|web|webrip|webdl|dl|dvd|dvdrip|remux|hevc|avc|hdr|'
	r'x264|x265|h264|h265|av1|xvid|aac|flac|opus|ac3|eac3|dts|truehd|dual|multi|'
	r'eng|jpn|jap|esp|ita|fre|ger|por|sub|subs|subbed|subtitle|subtitles|dub|dubbed|'
	r'raw|final|arc|the|and|uncut|uncensored|censored|repack|proper|hi10|10bit|8bit|'
	# LOCAL PATCH 2026-08-27: the same structural words in the other languages release
	# groups use. Without them a legitimate 'Naruto (Integrale) VOSTFR' was rejected,
	# because 'integrale' looked like a word from some other show's title.
	r'integrale|integral|integrali|complet|completa|completo|completos|coffret|'
	r'stagione|saison|temporada|staffel|sezon|serie|boxset|vostfr|truefrench|'
	r'castellano|latino|dublado|legendado)$',
	re.I)


def _seq_matches(name_seq, cand_seqs):
	"""True when any candidate matches the row, as consecutive words or joined.

	A match must sit on clean boundaries. Without that, containment alone makes every
	longer show name that happens to include ours look like a hit -- a Naruto scrape
	filled up with 'Boruto - Naruto Next Generations' and 'Naruto Shippuden', both
	separate TMDb shows. Having several candidates makes this cheap to satisfy: only
	one of them has to match cleanly, so 'Attack on Titan (Shingeki no Kyojin) - 01'
	still passes on the alias even though the primary title is followed by a word.

	The joined form covers groups that drop separators entirely:
	  'Attack.on.TitanShingeki.no.Kyojin...' -> (.., titanshingeki, ..)
	  'SPYFAMILY../.SPYxFAMILY.-.01...'      -> the × in SPY×FAMILY is stripped
	It cannot honour boundaries, so it needs a length that cannot collide by accident:
	at 6 it matched 'naruto' inside 'borutonarutonextgenerations' and readmitted every
	row the boundary check had just rejected. 10 still covers both cases above
	("attackontitan", "spyxfamily").
	"""
	if not cand_seqs: return True
	# LOCAL PATCH 2026-08-27: a neighbouring word belonging to one of OUR OWN candidate
	# titles is not evidence of a different show. Release names carry the title twice in
	# two forms all the time -- 'Naruto/NARUTO --][001-220TV][BOX1-8]' -- and the plain
	# edge rule read the second copy as a foreign title word and threw the row away.
	# This cannot readmit what the rule exists to block: 'boruto' and 'shippuden' are not
	# words of the Naruto candidates, so those still reject.
	cand_words = set(w for c in cand_seqs for w in c)
	for cand in cand_seqs:
		n = len(cand)
		if not n or n > len(name_seq): continue
		for i in range(len(name_seq) - n + 1):
			if name_seq[i:i + n] != cand: continue
			before = name_seq[i - 1] if i > 0 else None
			after = name_seq[i + n] if i + n < len(name_seq) else None
			# a short neighbour is noise ('Naruto HD (001-220)'), a long one is a title word
			if before is not None and len(before) >= 4:
				if not _TITLE_EDGE_OK.match(before) and before not in cand_words: continue
			if after is not None and len(after) > 2:
				if not _TITLE_EDGE_OK.match(after) and after not in cand_words: continue
			return True
	joined = ''.join(name_seq)
	for cand in cand_seqs:
		cj = ''.join(cand)
		if len(cj) >= 10 and cj in joined: return True
	return False


_BRACKET_GROUP = re.compile(r'\[(.*?)\]|\((.*?)\)')
# Bracketed episode ranges have to survive too: '(26-50)' is how a season-2 batch is
# labelled when the group counts episodes from the start of the series. Stripping it
# left no episode at all, so the row read as a bare batch and matched every episode
# of every season. The lookarounds are what exclude year spans: without them
# '2011-2018' still matches, because \d{1,3} happily binds to '011-201' inside it.
_RANGEISH = re.compile(r'(?<!\d)\d{1,3}\s*(?:[-~]|\bto\b)\s*\d{1,3}(?!\d)', re.I)
_SEASONISH = re.compile(r'\bseason\b|\bs\d{1,2}|\bcour\b|\bpart\b|\d{1,2}(?:st|nd|rd|th)\s*season', re.I)


def _keep_if_seasonish(m):
	"""Keep a bracket group's text when it carries season/part info, else drop it."""
	inner = m.group(1) if m.group(1) is not None else m.group(2)
	if inner and (_SEASONISH.search(inner) or _RANGEISH.search(inner)):
		return ' ' + inner + ' '
	return ' '


def _clean_for_extract(name):
	"""Strip quality/codec/audio noise + brackets so numeric extraction is unambiguous.
	magneto's clean_name has already converted spaces to dots; we normalize back."""
	s = name.lower().replace('.', ' ').replace('_', ' ')
	# LOCAL PATCH 2026-08-27: was a blanket strip of every (...) and [...] group.
	# That also deleted the season, because plenty of groups write it inside the
	# brackets: 'Re:Zero kara Hajimeru Isekai Seikatsu (Season 3) [1080p]' reduced
	# to 're zero kara hajimeru isekai seikatsu'. With no season parsed, the guard
	# in sources() ('if seasons and season_num not in seasons') sees an empty set,
	# reads it as 'makes no season claim', and lets the row through -- so every
	# (Season N) release surfaced under every season. Unbracketed 'S03' was fine,
	# which is why this hid for so long.
	#
	# Groups whose text mentions a season/part/cour keep their contents (brackets
	# dropped); everything else is still discarded, so quality tags and CRC32
	# stamps cannot leak digits into episode parsing. CRC32 is hex, so it cannot
	# contain the 's' that _SEASONISH needs.
	s = _BRACKET_GROUP.sub(_keep_if_seasonish, s)
	# A truncated name can leave an UNCLOSED bracket, which the pattern above cannot
	# match and therefore cannot remove. comet cuts long filenames at ~70 chars:
	#   'Re-Zero-...-3rd-season--16-(BS11-1920x1080-..'
	# leaving '(bs11-1920x1080-' in the text, where the episode scan read '11-1920'
	# as a range and matched practically any episode. Cut from the stray opener on.
	s = re.sub(r'[(\[][^)\]]*$', ' ', s)
	s = _NOISE_PATTERNS.sub(' ', s)
	s = re.sub(r'\s+', ' ', s).strip()
	return s


# Unified extractors — run on the CLEANED text.
_EX_SEASON = re.compile(r'\bs(?:eason)?[ ._-]?(\d{1,2})(?!\d)', re.I)
_EX_SEASON_ORD = re.compile(r'\b(\d{1,2})(?:st|nd|rd|th)\s+season\b', re.I)
# LOCAL PATCH 2026-08-27: bare ordinal season, used ONLY as a fallback (see below).
# Anime releases frequently drop the word 'season' entirely -- 'Re:Zero kara Hajimeru
# Isekai Seikatsu 4th - 01~11][67~77]' is season 4, and 'Spy x Family 2nd - 01' is
# season 2. Both were parsed as making no season claim, so they passed the season
# guard for every season and showed up under season 1.
#
# The negative lookahead skips ordinals that are not seasons ('10th Anniversary',
# '2nd Movie', '4th Plate'). Checked over 6 shows / 211 rows: every bare-ordinal hit
# was a real season marker, and the ones already carrying the word 'season' are
# resolved by _EX_SEASON_ORD first, so this never runs on them.
# LOCAL PATCH 2026-08-27: season RANGE, e.g. '[S01-02]', 'S01-S04', 'S1-S3'.
# _EX_SEASON alone matched just the 's01' and left the '-02' dangling, which the
# episode pass then read as episode 2 -- so an S01-04 complete-series pack announced
# itself as episode 2 and matched nothing else. Both endpoints are taken and the
# span expanded, which is what a multi-season pack actually covers.
# Requires the dash straight after the season number, so 'S02E06-08' (an EPISODE
# range) and 'S01.E01-E14' are left for the episode logic.
# LOCAL PATCH 2026-08-27: a season RANGE needs the 's' on both ends, or no spaces
# around the separator. Without that constraint the extremely common anime form
# 'Attack on Titan S3 - 08' parsed as seasons 3 THROUGH 8: the episode number was
# read as the far end of a season range. Every such release then looked like a
# six-season batch with no episode information, so it was accepted for virtually
# any request -- part 1 episodes answering part 2, and worse. Real season ranges
# are written 'S01-S04', 'S01 - S04' or 'S01-04'; all still match.
_EX_SEASON_RANGE = re.compile(r'\bs(\d{1,2})(?:\s*[-~]\s*s|[-~])(\d{1,2})\b', re.I)
_EX_SEASON_ORD_BARE = re.compile(r'\b(\d{1,2})(?:st|nd|rd|th)\b(?!\s*(?:anniversary|ann\b|movie|ova|special|plate))', re.I)
_EX_SEASON_ACT = re.compile(r'\bact\s+(i{1,3}v?|iv|v)\b', re.I)
_EX_SEASON_WORD = re.compile(r'\b(first|second|third|fourth|fifth|sixth|seventh|eighth)\s+season\b', re.I)
# Roman numeral as standalone token — used only when NO other season signal found.
# Catches "Mushoku Tensei III", "Overlord IV", "Attack on Titan II" style sequel naming.
# Skips bare "I" (too false-positive-prone: single letter, common in titles).
_EX_SEASON_ROMAN = re.compile(r'\b(ii|iii|iv|v|vi|vii|viii)\b', re.I)
_EX_PART = re.compile(r'\b(?:part|cour)\s?(\d+)\b', re.I)
_EX_SXX_EYY = re.compile(r's(\d{1,2})e(\d{1,4})', re.I)
# The trailing guard keeps a resolution out of the range: in 'x264-1920x1080' the
# pair 264-1920 otherwise parses as an episode range covering 1657 episodes.
# LOCAL PATCH 2026-08-27: 'to' joins a range as well as '-' and '~'. Without it a
# pack named 'NARUTO (2002) - Episodes 031 to 040' yielded no episode numbers at
# all, so cour_match fell through to its batch rule and accepted it for ANY
# episode -- it was answering requests for episode 159. With the range parsed the
# same pack is correctly rejected for 159 and correctly accepted for 35.
_EX_EP_RANGE = re.compile(r'(\d{1,4})\s*(?:[~\-]|\bto\b)\s*(\d{1,4})(?![\dxp])', re.I)
_EX_EP_DASH = re.compile(r'(?:^|\s)-\s*(\d{1,4})(?!\d)')
_EX_EP_PREFIX = re.compile(r'\b(?:episode|ep|e)\s*(\d{1,4})(?!\d)', re.I)


def _strip_season_ranges(text, seasons=None):
	"""Remove genuine season ranges ("S01-02", "S01-S04") and record them.

	Only spans that validate are removed. The pattern also matches a season marker
	followed by an episode range -- 'S2 - 01~10' looks like s=2..01 -- and blanket
	removal there destroyed both the S2 marker and the episode range, so the row
	ended up with no season and no episode at all."""
	out, last = [], 0
	for m in _EX_SEASON_RANGE.finditer(text):
		try: a, b = int(m.group(1)), int(m.group(2))
		except (TypeError, ValueError): continue
		if not (0 < a < b <= 50): continue   # descending or implausible: not a season range
		if seasons is not None: seasons.update(range(a, b + 1))
		out.append(text[last:m.start()]); out.append(' '); last = m.end()
	out.append(text[last:])
	return ''.join(out)


def _extract_meta(cleaned):
	"""Return (seasons:set, episodes:set|None, part_nums:set, is_range:bool).
	episodes is None when no episode number could be pulled — bare batches."""
	seasons = set()
	episodes = set()
	parts = set()
	is_range = False

	# --- season ---
	# LOCAL PATCH 2026-08-27: ORDER MATTERS here. The '<N>th season' / 'second
	# season' / 'act II' forms are read and then REMOVED before the plain
	# 'season <N>' scan, because otherwise the number that follows them is counted
	# as a second season:
	#   'Re:Zero ... 2nd Season 1~13' -> ORD gives 2, then _EX_SEASON matches
	#   'Season 1' out of 'Season 1~13', where that 1 opens the EPISODE range.
	# That produced seasons={1,2}; the guard in sources() only needs the requested
	# season to appear somewhere in the set, so a season-2 batch passed a season-1
	# scrape. Consuming the explicit forms first leaves nothing for the plain scan
	# to misread.
	_season_scan = cleaned
	_season_scan = _strip_season_ranges(_season_scan, seasons)
	for m in _EX_SEASON_ORD.finditer(_season_scan):
		try: seasons.add(int(m.group(1)))
		except: pass
	_season_scan = _EX_SEASON_ORD.sub(' ', _season_scan)
	for m in _EX_SEASON_WORD.finditer(_season_scan):
		w = m.group(1).lower()
		if w in _WORD_MAP: seasons.add(_WORD_MAP[w])
	_season_scan = _EX_SEASON_WORD.sub(' ', _season_scan)
	for m in _EX_SEASON_ACT.finditer(_season_scan):
		r = m.group(1).lower()
		if r in _ROMAN_MAP: seasons.add(_ROMAN_MAP[r])
	_season_scan = _EX_SEASON_ACT.sub(' ', _season_scan)
	for m in _EX_SEASON.finditer(_season_scan):
		try: seasons.add(int(m.group(1)))
		except: pass
	# Fallback: bare ordinal ('4th', '2nd') when nothing above claimed a season.
	if not seasons:
		for m in _EX_SEASON_ORD_BARE.finditer(cleaned):
			try:
				seasons.add(int(m.group(1)))
				break   # first hit only, as with the Roman fallback
			except: pass

	# Fallback: standalone Roman numeral only if we found no other season signal.
	# Guards against false positives from titles that legitimately contain Roman numerals.
	if not seasons:
		_ROMAN_STANDALONE = {'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7, 'viii': 8}
		for m in _EX_SEASON_ROMAN.finditer(cleaned):
			r = m.group(1).lower()
			if r in _ROMAN_STANDALONE:
				seasons.add(_ROMAN_STANDALONE[r])
				break   # only take first hit to avoid double-counting "II" + "III"

	# --- parts ---
	for m in _EX_PART.finditer(cleaned):
		try: parts.add(int(m.group(1)))
		except: pass

	# --- episode ---
	# Remove already-consumed markers so digits inside them don't leak as episodes.
	# LOCAL PATCH 2026-08-27: 'S02E06-08' spans three episodes, but _EX_SXX_EYY
	# below matches only 's02e06' and consumes it, orphaning the '-08' -- so the
	# file registered as episode 6 alone and never matched a request for 7 or 8.
	# _PK_RNG_SE is the pattern _pack_shape already uses for exactly this shape,
	# and it deliberately does NOT match the anime absolute form 'S03E20.(57)'.
	work = cleaned
	for m in _PK_RNG_SE.finditer(cleaned):
		try: a, b = int(m.group(1)), int(m.group(2))
		except: continue
		if 0 < a < b <= 999:
			episodes.update(range(a, b + 1))
			is_range = True
	if is_range: work = _PK_RNG_SE.sub(' ', work)
	work = _EX_SXX_EYY.sub(lambda m: episodes.add(int(m.group(2))) or ' ', work)
	work = _EX_PART.sub(' ', work)
	# LOCAL PATCH 2026-08-27: season markers have to go too, for the same reason
	# the line above removes parts -- otherwise their digits are read as episodes.
	# 'Shingeki no Kyojin Season 2 - 11' parsed as the RANGE 2-11, so one episode-11
	# file matched every request from 2 to 11; and 'Season 3 - 01 ~ 12' matched
	# '3 - 01' first, which is descending, so the real 01~12 range was never seen.
	# _EX_SEASON_ORD goes FIRST for the same reason it does in the season scan:
	# in '2nd Season 1~13' the plain _EX_SEASON matches 'Season 1' and removing it
	# would swallow the 1 that opens the episode range, leaving a bare '~13'.
	work = _strip_season_ranges(work)   # valid ranges only; see above
	for _rx in (_EX_SEASON_ORD, _EX_SEASON_WORD, _EX_SEASON,
					 _EX_SEASON_ORD_BARE):
		work = _rx.sub(' ', work)

	# episode range like "01-24" or "01~47"
	rng = _EX_EP_RANGE.search(work)
	if rng:
		try:
			a, b = int(rng.group(1)), int(rng.group(2))
			if 0 < a < b <= 9999:
				episodes.update(range(a, b + 1))
				is_range = True
		except: pass

	if not episodes:
		# "- 12", "-12", " 12 "
		for m in _EX_EP_DASH.finditer(work):
			try: episodes.add(int(m.group(1)))
			except: pass
	# always-good prefix: "E12", "Ep 12", "Episode 12"
	for m in _EX_EP_PREFIX.finditer(work):
		try: episodes.add(int(m.group(1)))
		except: pass

	return seasons, (episodes or None), parts, is_range


# LOCAL PATCH 2026-08-27: nyaa.si is blocked here by TWO independent mechanisms,
# which is why fixing one was not enough. Measured on this network:
#
#   nyaa.si                 DNS sinkhole (resolved to an ISP IP that drops packets).
#                           After fixing DNS an SNI/DPI reset ALSO applies: TCP
#                           connects, TLS with SNI=nyaa.si is RST, TLS with any
#                           other SNI to the SAME IP completes. Intermittent --
#                           5/8 handshakes, 2/6 real searches.
#   nyaa.media              8/8 handshakes, 1.6s median, BUT broken query semantics
#                           (see the ordering note below) -- fallback only.
#   nyaa-si.translate.goog  Google Translate proxy. Immune to an SNI filter on
#                           nyaa.si because the SNI on the wire says translate.goog.
#                           Needs the _x_tr_* params appended. ~2.0s.
#   nyaa.land, nyaa.iss.one Cloudflare 403 on /search, and 502. Not usable.
#
# Try hosts in order, keep the first that answers, remember it for the Kodi session.
# A window property rather than a module global: Fen Light runs with
# reuselanguageinvoker=false, so module state dies with every plugin invocation and
# a global would re-probe a dead host on every scrape.
# ORDER MATTERS, and it is about SEARCH SEMANTICS, not speed. This provider batches
# episode/batch variants into few requests using Nyaa's OR syntax
# (`title "Batch"|"Complete"|"S01"|...`). nyaa.media is reachable and marginally
# faster but does NOT implement those semantics -- measured:
#
#            query                        nyaa.media   translate.goog
#            "Frieren"                        55            75
#            "Frieren Batch"                  55  <-same     28  <-correctly narrower
#            'Frieren "Batch"|"Complete"'     27            29
#            '"Batch"|"Complete"'             27  <-same     75
#
# It ignores extra AND terms and mangles OR, so the batch queries silently collapse.
# Real cost: the BluRay season packs vanish -- Frieren 0 hits vs 75 (10 BluRay),
# Mushoku Tensei 0 vs 75 (18 BluRay), Tongari Boushi 11/0 vs 75/6.
#
# translate.goog proxies the REAL nyaa.si, so its semantics are correct, and its SNI
# reads translate.goog which sidesteps the filter on nyaa.si. It leads for correctness.
# nyaa.media stays as a fallback: still useful for plain single-title searches if the
# proxy is unavailable.
# LOCAL PATCH 2026-08-27: anime-aware pack shape test.
#
# source_utils.filter_season_pack is written for western release names and misreads
# the anime absolute-numbering convention. "Attack.on.Titan.S03E20.(57)" means
# season 3 episode 20, which is episode 57 counted from the series start; after
# release_title_format strips the brackets it reads as "s03e20.57" and the helper's
# range regex `s\d+e(\d+)[-.](\d+)` reports "episodes 20 through 57".
#
# Measured on real scrapes: 23 of 32 AoT S3 "season packs" and 24 of 33 Jujutsu
# Kaisen S2 ones were single episodes carrying fabricated ranges. Fen Light offers
# any pack whose range covers the wanted episode (scrapers/external.py), so asking
# for episode 25 would hand the user a torrent holding only episode 20 -- the debrid
# file filter then matches nothing and playback fails with no explanation.
#
# So the range that filter_season_pack reports is discarded and recomputed here.
# Verified 18/18 on a table of real nyaa names covering both conventions.
_PK_ABS_EP = re.compile(r's\d{1,3}[._ ]?e\d{1,3}[._ ]*[(\[]\d{1,4}[)\]]', re.I)
_PK_RNG_SE = re.compile(r's\d{1,3}[._ ]?e(\d{1,3})[._ ]*[-~][._ ]*e?(\d{1,3})(?![\dp])', re.I)
# The second number sits in a LOOKAHEAD so a junk match ("Part.2.-.01") does not
# consume the digits that begin the real range ("01.~.10") -- finditer would
# otherwise resume past them and never see it.
_PK_RNG_BARE = re.compile(r'(?<![\d])(\d{1,3})[._ ]*[-~][._ ]*(?=(\d{1,3})(?:[\s.\])]|$))')


def _pk_first_valid(rx, text, min_span=1):
	"""First ascending, plausible pair -- earlier matches are often junk."""
	for m in rx.finditer(text):
		try: a, b = int(m.group(1)), int(m.group(2))
		except Exception: continue
		if 0 < a < b <= 999 and (b - a) >= min_span: return a, b
	return 0, 0


def _pack_shape(name):
	"""(is_pack, episode_start, episode_end). 0/0 means a whole-season pack."""
	if _PK_ABS_EP.search(name): return False, 0, 0        # SxxEyy.(abs) -> one episode
	a, b = _pk_first_valid(_PK_RNG_SE, name)
	if a: return True, a, b                               # SxxE06-08 -> real range
	try:
		seasons, episodes, parts, is_range = _extract_meta(_clean_for_extract(name))
	except Exception:
		return True, 0, 0                                 # unparseable: leave it to the caller
	if episodes is None: return True, 0, 0                # no episode at all -> batch
	if is_range: return True, min(episodes), max(episodes)
	a, b = _pk_first_valid(_PK_RNG_BARE, name, min_span=2)
	if a: return True, a, b                               # "01.~.10" style batch
	return False, 0, 0                                    # a single, specific episode

# A film or OVA is not a TV episode. Requiring the ABSENCE of a season marker as
# well keeps genuine show packs that merely list their extras -- 'Attack on Titan
# (Complete Collection) (S01-S04+OVA+Movie)' declares S01-S04 and is kept, while
# 'Bleach the Movie: Memories of Nobody' and '[DBD-Raws] Bleach [OVA][01-02]'
# declare no season and are dropped. Both were answering episode-1 requests.
# What a genuine batch SAYS about itself. cour_match used to accept any name it could
# not read an episode number out of, on the theory that such a name must be a batch.
# It is not: a film, a special, or a name whose numbering was mangled beyond parsing
# all look identical to a batch under that rule, and every one of them then answers
# EVERY episode request. Measured on a Jujutsu Kaisen S01E01 scrape, comet returned
# 737 rows of which 508 came in through that door -- 81 of them the film 'Jujutsu
# Kaisen 0', the rest largely CJK-stripped names like '_Sousou.no.Frieren][30][' that
# are a specific episode whose number simply could not be read.
#
# Requiring the claim to be explicit drops 397 of those 737 and 181 of a 447-row
# Frieren scrape, while costing nyaa only 1-2 rows per scrape.
_BATCH_EVIDENCE = re.compile(
	r'complete|batch|collection|box\s?set|\bbox\b|all\s?episodes|integrale|integral|'
	r'full\s?series|season|seasons|serie|series|temporada|staffel|saison|stagione|'
	r'\bvol\b|volume|bd\s?box|bdmv|\btv\b', re.I)

_MOVIE_OVA = re.compile(r'\b(?:movies?|gekijou?ban|ova|oad|nc(?:op|ed))\b', re.I)


def cour_match(name, cour_season=None, cour_episode=None, absolute_episode=None,
               season_episode=None, cour_part=None, foreign_tokens=None):
	"""Does this release name hold the wanted episode of the wanted cour?

	LOCAL PATCH 2026-08-27. Anime carries two numbering schemes at once and both
	are in active use for the same episode:
	    [Erai-raws] Sousou no Frieren 2nd Season - 02   cour-relative
	    [ANi] Sousou no Frieren S02 - 30                absolute (from series start)

	`cour_season` is the RELEASE season number - Fribb's season.tvdb, not TMDb's.
	TMDb files every Re:ZERO cour under season 1, so its number says nothing about
	what an "S02" in a release name refers to.

	ORDER MATTERS here; both alternatives were tried and both lose results:

	  1. Absolute number first. It is unique across the series, so it identifies an
	     episode with no season marker at all - "[SubsPlease] Shingeki no Kyojin -
	     38" is S3E01. Putting the season check ahead of this rejected 34 real AoT
	     results whose only number was the absolute one.
	  2. Season check next. The cour-relative number IS ambiguous between cours, so
	     for cour 2+ a name with no season marker is cour 1, not a wildcard.
	     Otherwise "[aL] Sousou no Frieren (2023) - 02" (cour 1 episode 2) answers a
	     cour 2 episode 2 request - exactly what comet's kitsu endpoint returns.
	  3. Batches only after the season check. Accepting them earlier let
	     "Frieren: Beyond Journey's End (2023) (Season 1) [BDRip]" through for a
	     cour 2 request.
	"""
	# 0. a name carrying another cour's distinctive words IS that cour, whatever
	#    numbering it uses. Bleach and Thousand-Year Blood War are separate anime
	#    under one TMDb show, and TYBW releases label themselves S01E01 in their own
	#    numbering -- so no season or episode test can separate them. Only the title
	#    can, and 'Sennen Kessen-hen' is the form most of those releases use.
	if foreign_tokens:
		_nt = set(w for w in re.findall(r'[a-z0-9]+', (name or '').lower()) if len(w) >= 4)
		if _nt & set(foreign_tokens): return False
	seasons, episodes, parts, is_range = _extract_meta(_clean_for_extract(name))
	# films / OVAs, unless the name also claims a season (then it is a show pack
	# that merely lists its extras)
	# underscores are word characters, so \b will not fire against them:
	# 'Gekijouban_Bleach_...[MOVIE_IV]' has to be split first
	if not seasons and _MOVIE_OVA.search((name or '').replace('_', ' ')): return False
	def _int(v):
		try: return int(v)
		except (TypeError, ValueError): return None
	cour_season, cour_episode = _int(cour_season), _int(cour_episode)
	absolute_episode, season_episode = _int(absolute_episode), _int(season_episode)
	# The season-relative number is the one release names carry when a season is
	# split across cours (Re:ZERO S2 ep 24 = cour 2 of 2, cour_ep 12). Where the
	# season is a single cour the two are identical, so accepting both is free.
	wanted = set(x for x in (season_episode, cour_episode) if x is not None)

	# 1. unambiguous absolute hit (skipped for cour 1, where the two numbers are
	#    the same and a bare number really is ambiguous)
	if (episodes and absolute_episode is not None
			and absolute_episode not in wanted and absolute_episode in episodes):
		return True

	# 2. the release must belong to our cour
	if cour_season and cour_season > 1:
		if not seasons or cour_season not in seasons: return False
	elif seasons and min(seasons) > 1:
		return False   # targeting cour 1, name claims a later season

	# 3. a batch of the right cour: caller picks the file inside it. A Part number
	#    is the one thing a batch does say about WHICH episodes it holds, so honour
	#    it -- '(Season 2 Part 01)' cannot contain an episode from Part 2, and with
	#    no episode numbers to check it would otherwise sail through.
	if parts and cour_part and int(cour_part) not in parts: return False
	# No episode number: only a batch if the name actually claims to be one. See
	# _BATCH_EVIDENCE -- without this test a film or an unparseable name matched every
	# episode of the show. `seasons` and `parts` count as a claim in their own right,
	# and a season pack has already been checked against our cour above.
	if episodes is None:
		return bool(seasons or parts or _BATCH_EVIDENCE.search(name or ''))

	# 3b. a split season makes the COUR-relative number ambiguous across parts, in
	#     exactly the way the cour-relative number is ambiguous across cours above.
	#     Attack on Titan S3 is two parts; our S3E20 is part 2 episode 8, but part 1
	#     episode 8 is ALSO named 'Attack on Titan S3 - 08', and it was matching. A
	#     part marker resolves that and is honoured just above -- when there is none
	#     the bare number reads as part 1, so only the unambiguous numbers may be
	#     used: the season-relative one (20) and the absolute one, both of which
	#     count across the whole season and so cannot collide between its parts.
	if cour_part and int(cour_part) > 1 and not parts:
		unambiguous = set(x for x in (season_episode, absolute_episode) if x is not None)
		return bool(unambiguous & set(episodes))

	# 4. cour-relative number, now that the cour is established
	return bool(wanted & set(episodes))


def title_guard(name, title, aliases):
	"""Does this release name actually belong to the show we asked for?

	LOCAL PATCH 2026-08-27. The Kitsu paths in torrentio and comet skip the normal
	title check, on the reasoning that querying by an ID already scopes the result to
	one anime. That reasoning turned out to be too trusting on both counts:

	  - comet's kitsu endpoint leaks unrelated shows. A kitsu:11:159 (Naruto) query
	    returned "11.22.63.S01.2160p.HULU.WEB-DL", and a Frieren query returned
	    "In Spectre S02E02".
	  - the ID itself can be wrong. ani.zip maps Fairy Tail to kitsu_id 1, which is
	    Cowboy Bebop -- so a query built from it returns 559 Cowboy Bebop rows, every
	    one of which the episode checks happily accept because they never look at
	    the title.

	No episode-level test can catch either: they are the right episode number of the
	wrong show. Only the title can, so it is checked here as a last line of defence.

	Uses the boundary-aware matcher rather than source_utils.check_title, which
	requires an SxxExx token that anime releases do not carry.
	"""
	cands = [_title_seq(t) for t in ([title] + list(aliases or [])) if t]
	cands = [c for c in cands if c]
	if not cands: return True
	return _seq_matches(_title_seq(name), cands)


def alias_titles(data):
	"""Show title + alias strings from a Fen Light data dict, for title_guard."""
	out = []
	for alias in (data.get('aliases') or []):
		if isinstance(alias, dict):
			if alias.get('title'): out.append(alias['title'])
		elif alias: out.append(str(alias))
	return out
