# created by Venom for Fenomscrapers
"""
	Fenomscrapers Project
"""

import re
import concurrent.futures
from urllib.parse import quote_plus, unquote_plus
from magneto.modules import cleantitle
from magneto.modules import client
from magneto.modules import source_utils


# LOCAL PATCH 2026-07-20: Otaku-style rewrite. Uses Nyaa's OR-query syntax to
# fetch all episode/batch variants in fewer HTTP calls, then filters via a
# clean-text-then-extract approach (strip quality/codec tokens BEFORE regex on
# name so tags like `1080p`/`H264`/`AAC` don't get misread as episode numbers).
# Auto-accepts torrents with no explicit season/episode/part info (bare batches
# like "Show.Complete") — matches Otaku's behavior. Also queries alias titles
# because anime torrents commonly use Japanese/romaji names (e.g. `Diamond no
# Ace`) that don't share tokens with the TMDb English title (`Ace of Diamond`).

# LOCAL PATCH 2026-08-27: the anime name parsing that used to live here now sits in
# magneto/modules/anime_utils.py so comet can use it too. Moved verbatim; the names
# are unchanged, so everything below this line reads exactly as it did before.
from magneto.modules.anime_utils import (
	_TOKEN_STOPWORDS, _tokenize, _title_seq, _seq_matches,
	_clean_for_extract, _extract_meta, _pack_shape, cour_match)

# LOCAL PATCH 2026-08-27 (revised): nyaa.media REMOVED. It is not a mirror, it is a
# different search backend that silently IGNORES AND terms. Measured same-minute:
#
#   query                                   translate.goog   nyaa.media
#   "Witch Hat Atelier"                         75 magnets   55 magnets
#   "Witch Hat Atelier S01E01"                  18 magnets   55 magnets  <- unchanged!
#   'Witch Hat Atelier "Batch"|"Complete"'      75 magnets   11 magnets
#
# Identical count with and without the episode term = the term was dropped. This
# provider's whole design is narrow OR-batched queries, so a host that ignores terms
# returns a large set of WRONG rows that then die in the episode filter. That is
# exactly what happened: the 08:31 scrape via nyaa.media logged
# 'final source count=5 ... rejects={token: 22, episode: 157}' and no season packs,
# while the same scrape via translate.goog yields 46 sources including 9 packs.
#
# A host that lies is worse than a host that fails: it passes every liveness check,
# gets remembered for the session, and silently degrades results. Hence both the
# removal and the magnet-based liveness test in _fetch_urls.
# 2026-08-27 (later the same day): order swapped -- nyaa.si FIRST.
# The translate proxy works, but it is rate limited: a burst of scrapes earns a
# blanket HTTP 429, and since a 429 body carries no magnets every query in that
# scrape comes back empty. Measured right after a heavy test run:
#     nyaa-si.translate.goog  HTTP 429
#     nyaa.si                 HTTP 200, 75 magnets
# nyaa.si is also the authoritative host with correct AND/OR query semantics, so it
# belongs first whenever it is reachable. Its ISP block was always intermittent, and
# the magnet-based liveness test in _fetch_urls falls through to the proxy the moment
# nyaa.si returns nothing -- so this ordering degrades gracefully in both directions.
_NYAA_HOSTS = (
	('https://nyaa.si', ''),
	('https://nyaa-si.translate.goog', '&_x_tr_sl=es&_x_tr_tl=en&_x_tr_hl=en'),
)
_NYAA_HOST_PROP = 'magneto.nyaa_host'


def _nyaa_hosts_in_order():
	"""Preferred host first, then the rest as fallbacks."""
	try:
		import xbmcgui
		preferred = xbmcgui.Window(10000).getProperty(_NYAA_HOST_PROP)
	except Exception:
		preferred = ''
	if preferred:
		chosen = [h for h in _NYAA_HOSTS if h[0] == preferred]
		if chosen: return chosen + [h for h in _NYAA_HOSTS if h[0] != preferred]
	return list(_NYAA_HOSTS)


def _remember_nyaa_host(base):
	try:
		import xbmcgui
		win = xbmcgui.Window(10000)
		if win.getProperty(_NYAA_HOST_PROP) != base: win.setProperty(_NYAA_HOST_PROP, base)
	except Exception: pass

class source:
	priority = 5
	# LOCAL PATCH 2026-08-27: was False -- nyaa had no sources_packs(), so Fen Light
	# never asked it for season/show packs (scrapers/external.py builds its pack list
	# from this flag). Worse, the bare batches sources() already returned carried no
	# `package` key, so resolve_cached() got pack=False and never picked the requested
	# episode out of the torrent -- a season pack played the wrong file.
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		self.language = ['en']
		# LOCAL PATCH 2026-08-27: resolved from _NYAA_HOSTS; see the note above.
		self.base_link, self.url_suffix = _nyaa_hosts_in_order()[0]
		self.search_link = '/?f=0&c=0_0&q=%s&s=seeders&o=desc'
		# LOCAL PATCH 2026-08-09: was 1. This provider is debridonly — a 0-seeder
		# 2015-era batch can still be RD/TorBox-cached and instant-playable. Rejecting
		# on seeders BEFORE the debrid cache check threw away valid cached sources
		# (4 of them in the Ace of Diamond S1E43 test scrape). Otaku keeps cached
		# torrents regardless of seeder count; match that behavior. Fen Light's
		# sources window shows uncached separately, so dead uncached torrents are
		# still visually distinguishable downstream.
		self.min_seeders = 0

	def _fetch_urls(self, urls):
		"""Fetch all urls, walking the host list until one answers.

		LOCAL PATCH 2026-08-27: lifted out of sources() unchanged so sources_packs()
		shares it. A blocked host fails fast (SNI reset ~0.5s) or hits the 5s timeout,
		so trying the next is bounded; the winner is remembered for the session."""
		import xbmc as _xbmc_diag   # was a local of sources(); needed here after extraction
		if not urls: return []
		def _fetch(u):
			try: return u, client.request(u, timeout=5)
			except Exception: return u, None
		def _fetch_all(_urls):
			try:
				with concurrent.futures.ThreadPoolExecutor(max_workers=min(8, len(_urls))) as _ex:
					return list(_ex.map(_fetch, _urls))
			except Exception:
				# fall back to sequential if threading blows up for any reason
				return [_fetch(u) for u in _urls]
		def _has_magnets(html):
			# A page body is not proof of success: a rate-limited 429, a Cloudflare
			# interstitial and a blocked-host error page are all non-empty HTML with
			# zero magnets. Only magnets count.
			return bool(html) and 'magnet:' in html

		def _alt_urls_for(idxs, alt_base, alt_suffix):
			out = []
			for i in idxs:
				u = urls[i].replace(self.base_link, alt_base, 1)
				if self.url_suffix: u = u.replace(self.url_suffix, '', 1)
				if alt_suffix: u = '%s%s' % (u, alt_suffix)
				out.append(u)
			return out

		# LOCAL PATCH 2026-08-27 (revised): retry PER URL, not all-or-nothing.
		# nyaa.si is blocked intermittently at the request level -- a scrape usually
		# gets some queries through and loses the rest. The previous check ('did ANY
		# url return a magnet?') treated that as success, so the dead queries were
		# silently dropped: 27 sources from 158 rows instead of 46 from 326, and the
		# BluRay season pack happened to sit in a query that died. Retrying just the
		# empty ones on the next host recovers them at the cost of one extra request
		# per failed query.
		fetch_results = _fetch_all(urls)
		missing = [i for i, r in enumerate(fetch_results) if not _has_magnets(r[1])]
		for _alt_base, _alt_suffix in _nyaa_hosts_in_order()[1:]:
			if not missing: break
			if _alt_base == self.base_link: continue
			_xbmc_diag.log('NYAA-DIAG: %d/%d queries empty on %s, retrying on %s'
					% (len(missing), len(urls), self.base_link, _alt_base), _xbmc_diag.LOGINFO)
			_retry = _fetch_all(_alt_urls_for(missing, _alt_base, _alt_suffix))
			_still = []
			for _idx, _res in zip(missing, _retry):
				if _has_magnets(_res[1]): fetch_results[_idx] = _res
				else: _still.append(_idx)
			missing = _still
		# Remember whichever host answered the FIRST query, so the next scrape starts
		# where this one succeeded rather than re-probing a dead host.
		if any(_has_magnets(r[1]) for r in fetch_results): _remember_nyaa_host(self.base_link)
		return fetch_results

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		"""Season / show packs. LOCAL PATCH 2026-08-27.

		Mirrors torrentio.sources_packs: the shared source_utils.filter_season_pack /
		filter_show_pack helpers decide validity, and the item carries `package` so
		Fen Light resolves the requested episode from inside the torrent.

		CAVEAT: those helpers assume western season numbering, while nyaa batches are
		anime cours -- a batch labelled S01 may be one cour of a TMDb season. Expect
		some valid packs filtered out; season packs are safer than show packs here."""
		sources = []
		if not data: return sources
		sources_append = sources.append
		try:
			import xbmc as _x
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data.get('title')
			if not title: return sources
			title = title.replace('&', 'and').replace('/', ' ').replace('$', 's')
			aliases = list(data.get('aliases') or [])
			mal_title = data.get('mal_title')
			if mal_title and mal_title not in [a if isinstance(a, str) else a.get('title', '') for a in aliases]:
				aliases.append({'title': mal_title})
			# str, not int: source_utils.filter_season_pack does season.zfill(2) and
			# show_title.replace(year, ''), so both must be strings. Fen Light already
			# passes 'season': str(self.season) (scrapers/external.py); passing an int
			# here raised AttributeError INSIDE filter_season_pack, whose except returns
			# a bare True while every other path returns a 3-tuple -- so the unpack blew
			# up in this method, was caught by the outer except, and the whole provider
			# silently returned zero packs. season_num stays int for query formatting.
			year, imdb = str(data.get('year') or ''), data.get('imdb')
			season = str(data.get('season') or '1')
			try: season_num = int(season)
			except Exception: season_num, season = 1, '1'
			# Same title candidates sources() uses: primary plus romaji/alias forms, which
			# is how most anime packs are actually named.
			cands = [title]
			for a in aliases[:3]:
				t = a if isinstance(a, str) else a.get('title', '')
				if t and t not in cands: cands.append(t)
			s2 = '%02d' % season_num
			# Batch OR-pattern, same shape sources() uses. `01-NN` ranges are left open
			# ended here because a pack search does not know the episode count.
			batch_or = '"Batch"|"Complete"|"S%s"|"Season %s"|"Seasons"|"Complete Series"' % (s2, s2)
			if search_series:
				batch_or = '"Batch"|"Complete"|"Complete Series"|"Seasons"|"S01-"'
			urls = []
			for t in cands:
				urls.append('%s%s%s' % (self.base_link, self.search_link % quote_plus('%s %s' % (t, batch_or)), self.url_suffix))
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('NYAA')
			return sources
		fetch_results = self._fetch_urls(urls)
		seen_hashes = set()
		_kept = 0
		for _u, results in fetch_results:
			try:
				if not results or 'magnet:' not in results: continue
				results = re.sub(r'[\n\t]', '', results)
				rows = client.parseDOM(client.parseDOM(results, 'tbody'), 'tr')
				for row in rows:
					links = zip(
									# LOCAL PATCH 2026-08-27: was [^"\']+ -- a class excluding BOTH quote characters.
									# The intent was to accept either quoting style, but it stops at whichever quote
									# appears first, so a magnet sitting inside href="..." is truncated at any literal
									# apostrophe in the torrent name. Real example: nyaa serves
									#   dn=%5BArg0%5D+Frieren:+Beyond+Journey's+End+(2023)+-+S01E01+v3+...
									# and the name arrived as just 'Frieren:.Beyond.Journey' -- 70 of 133 rows for that
									# show. Everything downstream then breaks: no SxxExx to match, no quality, no
									# season marker. It also produced the phantom 'The.World' row and the
									# 'REJECT sequel-token hit={director}' spam (Director's Cut, cut at the quote).
									# Backreference \1 closes on the SAME quote that opened the attribute.
									[_m.group(2) for _m in re.finditer(r'href\s*=\s*(["\'])(magnet:.+?)\1', row, re.DOTALL | re.I)],
									re.findall(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', row, re.DOTALL),
									[re.findall(r'<td class\s*=\s*["\']text-center["\']>([0-9]+)</td>', row, re.DOTALL)])
					for link in links:
						magnet = unquote_plus(link[0]).replace('&amp;', '&').split('&tr')[0].replace(' ', '.')
						magnet = source_utils.strip_non_ascii_and_unprintable(magnet)
						try: hash = re.search(r'btih:(.*?)&', magnet, re.I).group(1)
						except Exception: continue
						if hash in seen_hashes: continue
						try: name = source_utils.clean_name(magnet.split('&dn=')[1])
						except Exception: continue
						episode_start = episode_end = 0
						last_season = total_seasons
						# filter_season_pack still decides TITLE and SEASON validity -- that part
						# is sound (verified 7/7 including romaji aliases and S02-vs-S01). Only
						# its episode range is discarded, for the reason in _pack_shape above.
						is_pack, shape_start, shape_end = _pack_shape(name)
						if search_series:
							if not bypass_filter:
								if not is_pack: continue
								valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season, name, total_seasons)
								if not valid: continue
							package = 'show'
						else:
							if not bypass_filter:
								if not is_pack: continue
								valid, _fsp_start, _fsp_end = source_utils.filter_season_pack(title, aliases, year, season, name)
								if not valid: continue
							episode_start, episode_end = shape_start, shape_end
							package = 'season'
						name_info = source_utils.info_from_name(name, title, year, season=season, pack=package)
						if source_utils.remove_lang(name_info, check_foreign_audio): continue
						if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue
						try:
							seeders = int(link[2][0])
							if self.min_seeders > seeders: continue
						except Exception: seeders = 0
						quality, info = source_utils.get_release_quality(name_info, magnet)
						try:
							dsize, isize = source_utils._size(link[1])
							info.insert(0, isize)
						except Exception: dsize = 0
						info = ' | '.join(info)
						seen_hashes.add(hash)
						item = {
							'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True,
							'true_size': True, 'provider': 'nyaa', 'hash': hash, 'url': magnet,
							'name': name, 'name_info': name_info, 'quality': quality, 'info': info,
							'size': dsize, 'seeders': seeders, 'package': package
						}
						if search_series: item.update({'last_season': last_season})
						elif episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end})
						sources_append(item)
						_kept += 1
			except Exception:
				source_utils.scraper_error('NYAA')
				continue
		_x.log('NYAA-DIAG: sources_packs kind=%s urls=%d kept=%d' % ('show' if search_series else 'season', len(urls), _kept), _x.LOGINFO)
		return sources

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		append = sources.append
		try:
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			aliases = list(data.get('aliases') or [])
			# LOCAL PATCH 2026-08-09: Fen Light passes anime romaji title via
			# data['mal_title'] for anime (looked up per-cour via Fribb). Nyaa
			# releases commonly use romaji titles that don't share tokens with
			# TMDb English titles — e.g. Slime S3 is "Tensei Shitara Slime
			# Datta Ken (2021) Dai 2 Bu" on Nyaa, not "That Time I Got
			# Reincarnated as a Slime S3". Feeding romaji as an alias fixes
			# 20-40% recall gap for many anime.
			mal_title = data.get('mal_title')
			if mal_title and mal_title not in [a if isinstance(a, str) else a.get('title', '') for a in aliases]:
				aliases.append({'title': mal_title})
			year = data['year']
			is_show = 'tvshowtitle' in data
			season_num = int(data['season']) if is_show else 0
			episode_num = int(data['episode']) if is_show else 0
			# LOCAL PATCH 2026-08-27: cour context, set by Fen Light for anime only.
			# TMDb's episode number is not what anime releases carry: Frieren S1E30 is
			# '2nd Season - 02' to most groups and '- 30' to the rest, never 'S01E30'.
			cour_episode = data.get('cour_episode') if is_show else None
			cour_season = data.get('cour_season') if is_show else None
			absolute_episode = data.get('absolute_episode') if is_show else None
			season_episode = data.get('season_episode') if is_show else None
			try: season_episode = int(season_episode) if season_episode is not None else None
			except (TypeError, ValueError): season_episode = None
			cour_part = data.get('cour_part') if is_show else None
			foreign_cour_tokens = data.get('foreign_cour_tokens') if is_show else None
			try: cour_episode = int(cour_episode) if cour_episode is not None else None
			except (TypeError, ValueError): cour_episode = None
			try: absolute_episode = int(absolute_episode) if absolute_episode is not None else None
			except (TypeError, ValueError): absolute_episode = None
			hdlr = 'S%02dE%02d' % (season_num, episode_num) if is_show else year

			import xbmc as _xbmc_diag
			_xbmc_diag.log('NYAA-DIAG: entering sources() title=%r season=%s episode=%s is_show=%s' % (title, data.get('season'), data.get('episode'), is_show), _xbmc_diag.LOGINFO)

			# --- title candidates: primary + up to 3 aliases (deduped) ---
			def _clean_q(s):
				return re.sub(r'[^A-Za-z0-9\s\.-]+', ' ', s).strip()
			clean_title = _clean_q(title)
			primary_lc = clean_title.lower()

			# LOCAL PATCH 2026-07-20: filter out sequel-style aliases.
			# TMDb (and Fen Light) sometimes lists sequel/spinoff titles as "aliases" of
			# the parent show — e.g. "Bleach" primary has "Bleach: Thousand-Year Blood War"
			# as an alias, but TYBW is a SEPARATE TMDb entry (its own show, its own seasons).
			# Detect these: any alias where primary_title is a prefix followed by a
			# separator (`:`, `-`, `~`) is a sequel/subtitle variant. Skip such aliases
			# from BOTH queries (don't fetch them from Nyaa) AND from accept_tokens
			# (don't let their tokens whitelist sequel torrents).
			def _is_sequel_variant(a_lc):
				if not a_lc or a_lc == primary_lc: return False
				if not a_lc.startswith(primary_lc): return False
				rest = a_lc[len(primary_lc):]
				return bool(rest) and rest[0] in ':-~.,/ '

			title_candidates = [clean_title]
			seen_titles_lc = {primary_lc}
			safe_aliases = []       # non-sequel aliases we CAN query
			sequel_extra_tokens = set()  # tokens ONLY in sequel aliases — used for reject list
			for alias in aliases:
				try:
					name_al = alias.get('title') if isinstance(alias, dict) else alias
					if not name_al: continue
					c = _clean_q(name_al)
					if not c or c.lower() in seen_titles_lc: continue
					seen_titles_lc.add(c.lower())
					if _is_sequel_variant(c.lower()):
						# collect tokens beyond the primary as sequel-only tokens
						sequel_extra_tokens |= (_tokenize(c) - _tokenize(clean_title))
					else:
						safe_aliases.append(c)
				except Exception: pass
			# cap safe aliases at 3 (same behavior as before, applied post-filter)
			for c in safe_aliases[:3]:
				title_candidates.append(c)

			# --- title-token guard set (primary + SAFE aliases only) ---
			accept_tokens = _tokenize(title)
			# Phrase forms of the same candidates; see _title_seq above.
			title_seqs = [_title_seq(title)]
			for c in safe_aliases[:3]:
				accept_tokens |= _tokenize(c)
				_cs = _title_seq(c)
				if _cs and _cs not in title_seqs: title_seqs.append(_cs)
			title_seqs = [t for t in title_seqs if t]

			# LOCAL PATCH 2026-08-07: cross-season contamination filter. Fen Light
			# passes tokens from OTHER seasons' TMDb names via data['foreign_season_tokens'].
			# Reject torrents matching those tokens unless they explicitly claim our target
			# season. Fixes "Bleach S1 shows TYBW torrents" and equivalent cases.
			foreign_reject_tokens = set()
			try:
				for _t in (data.get('foreign_season_tokens') or []):
					try:
						_t = str(_t).lower()
						if _t and len(_t) >= 4 and _t not in _TOKEN_STOPWORDS:
							foreign_reject_tokens.add(_t)
					except Exception: continue
			except Exception: pass

			# --- build OR-syntax queries ---
			# Nyaa search syntax: quoted phrases OR'd with `|`. One query per title
			# candidate covers all common episode formats; a second covers batches.
			queries = []
			if is_show:
				ep2 = '%02d' % episode_num
				s2 = '%02d' % season_num
				ep_or = '"- %s"|"S%sE%s"|"E%s"|"Episode %s"|"Ep %s"' % (ep2, s2, ep2, ep2, ep2, ep2)
				# LOCAL PATCH 2026-08-27: also ask for the cour-relative number. The title
				# candidates already include the cour's own name ('Sousou no Frieren 2nd
				# Season', from data['mal_title']) -- it was only ever paired with TMDb's
				# episode number, so the dominant '<Cour Title> - NN' naming never matched.
				# Added alongside, not instead: some groups do number from the series start.
				cour_or = ''
				# season_episode first: when a season spans several cours the groups keep
				# counting across them (Re:ZERO S2 ep 24 is cour 2's episode 12), so it is
				# the number that appears in names. Falls back to the cour number.
				# Absolute last: shows like Naruto have no Fribb cour at all, so this is the
				# only alternative number available -- and it is the one every release uses.
				_qep = season_episode or cour_episode or absolute_episode
				if _qep and _qep != episode_num:
					cep2 = '%02d' % _qep
					cour_or = '"- %s"|"E%s"|"Episode %s"|"Ep %s"' % (cep2, cep2, cep2, cep2)
				batch_or = '"Batch"|"Complete"|"S%s"|"Season %s"|"01-%s"|"01~%s"|"01 - %s"|"01 ~ %s"' % (s2, s2, ep2, ep2, ep2, ep2)
				for t in title_candidates:
					queries.append('%s %s' % (t, ep_or))
					if cour_or: queries.append('%s %s' % (t, cour_or))
					queries.append('%s %s' % (t, batch_or))
			else:
				# movies
				for t in title_candidates:
					queries.append('%s %s' % (t, year))

			urls = ['%s%s%s' % (self.base_link, self.search_link % quote_plus(q), self.url_suffix) for q in queries]
			# LOCAL PATCH 2026-08-09: bare-title queries (Otaku's get_show_sources /
			# 'additional' pattern), downloads-sorted. Our token-scoped queries above
			# require '- NN' / 'Batch' / 'S01' etc IN THE TORRENT NAME — but the best
			# BD batches often have none of those (e.g. '[Moozzi2] Diamond no Ace
			# BD-BOX', '[DB] Diamond no Ace [10bit BD1080p]', '[Erai-raws] ... 01 ~ 75').
			# Bare-title fetch surfaces them; the extract/filter pass below keeps
			# correctness. Verified: +7 legit S1-viable batches for Ace of Diamond
			# S1E43 that the token queries never fetched.
			if is_show:
				_bare_link = '/?f=0&c=0_0&q=%s&s=downloads&o=desc'
				for t in title_candidates:
					urls.append('%s%s%s' % (self.base_link, _bare_link % quote_plus(t), self.url_suffix))
			_xbmc_diag.log('NYAA-DIAG: title_candidates=%r queries=%d' % (title_candidates, len(queries)), _xbmc_diag.LOGINFO)

			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('NYYAA')
			return sources

		# --- parallel fetch (Otaku-style): all N queries at once, then process ---
		# LOCAL PATCH 2026-07-20: HTTP round-trips are the entire wall clock of a Nyaa
		# scrape (parsing is <1ms). Fire all URLs through a ThreadPoolExecutor so the
		# scrape finishes in max(single_query) rather than sum(all_queries).
		import time as _time
		_t_fetch_start = _time.time()
		fetch_results = self._fetch_urls(urls)
		_xbmc_diag.log('NYAA-DIAG: parallel fetch %d urls took %.2fs' % (len(urls), _time.time() - _t_fetch_start), _xbmc_diag.LOGINFO)

		# --- filter (sequential — parsing is CPU-bound and cheap) ---
		# LOCAL PATCH 2026-08-09: track rejection reasons for diagnosis
		_reject_stats = {'token': 0, 'season': 0, 'episode': 0, 's2_ambig': 0, 'sequel': 0, 'foreign_lang': 0, 'foreign_season': 0, 'seeders': 0, 'duplicate': 0}
		_pre_filter_count = 0
		seen_hashes = set()
		for url, results in fetch_results:
			try:
				if not results or 'magnet:' not in results:
					continue
				results = re.sub(r'[\n\t]', '', results)
				tbody = client.parseDOM(results, 'tbody')
				rows = client.parseDOM(tbody, 'tr')

				for row in rows:
					links = zip(
									# LOCAL PATCH 2026-08-27: was [^"\']+ -- a class excluding BOTH quote characters.
									# The intent was to accept either quoting style, but it stops at whichever quote
									# appears first, so a magnet sitting inside href="..." is truncated at any literal
									# apostrophe in the torrent name. Real example: nyaa serves
									#   dn=%5BArg0%5D+Frieren:+Beyond+Journey's+End+(2023)+-+S01E01+v3+...
									# and the name arrived as just 'Frieren:.Beyond.Journey' -- 70 of 133 rows for that
									# show. Everything downstream then breaks: no SxxExx to match, no quality, no
									# season marker. It also produced the phantom 'The.World' row and the
									# 'REJECT sequel-token hit={director}' spam (Director's Cut, cut at the quote).
									# Backreference \1 closes on the SAME quote that opened the attribute.
									[_m.group(2) for _m in re.finditer(r'href\s*=\s*(["\'])(magnet:.+?)\1', row, re.DOTALL | re.I)],
									re.findall(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', row, re.DOTALL),
									[re.findall(r'<td class\s*=\s*["\']text-center["\']>([0-9]+)</td>', row, re.DOTALL)])
					for link in links:
						magnet = unquote_plus(link[0]).replace('&amp;', '&').split('&tr')[0].replace(' ', '.')
						magnet = source_utils.strip_non_ascii_and_unprintable(magnet)
						try: hash = re.search(r'btih:(.*?)&', magnet, re.I).group(1)
						except: continue
						if hash in seen_hashes:
							_reject_stats['duplicate'] += 1
							continue
						try: name = source_utils.clean_name(magnet.split('&dn=')[1])
						except: continue
						_pre_filter_count += 1

						# ---------- manga/audio junk guard ----------
						# LOCAL PATCH 2026-08-09: bare-title queries pull in manga volumes
						# ('vol 01-47', 'v41-44 (Digital)', scanlation packs) and music
						# albums whose volume ranges satisfy the episode-range check
						# (43 ∈ 1..47). Nothing here is ever a playable video source.
						# GATE (2026-08-09 rev2): only reject when the name has NO video
						# signal (resolution / codec / rip-source / video container).
						# Real BD/WEB video releases can legitimately contain "Digital"
						# (e.g. CR WEB-DL "Digital") — rejecting on that token alone was
						# eating ~7 valid sources per scrape. Manga scans + OST albums
						# never carry 720p/1080p/x264/BD/mkv etc, so this gate is safe.
						_name_lc = name.lower().replace('.', ' ')
						_has_video_signal = re.search(
							r'\b(?:360p|480p|540p|576p|720p|1080p|1440p|2160p|4k|hd|sd|uhd)\b'
							r'|\b(?:x264|x265|h ?264|h ?265|hevc|avc|av1|xvid|vp9)\b'
							r'|\b(?:bd|bdrip|bluray|blu-ray|web-?dl|webrip|hdtv|dvdrip|remux|bdmv|hdrip)\b'
							r'|\b(?:mkv|mp4|avi|m2ts|ts)\b', _name_lc)
						if not _has_video_signal and re.search(
								r'\bvol\b|\bv\d{1,3}\s*[-~]\s*v?\d{1,3}\b|scanlation|\bdigital\b'
								r'|\bcomplete\s+songs\b|\bost\b|\bsoundtrack\b|\bhi-?res\b'
								r'|\bflac\b|\bmp3\b|\b\d{2,3}kbps\b|\b\d{2}bit\b|\bkhz\b', _name_lc):
							_reject_stats['manga_audio'] = _reject_stats.get('manga_audio', 0) + 1
							continue

						# ---------- title phrase guard (cross-show contamination) ----------
						# Strictly stronger than the token guard below, so it runs first; the token
						# guard is left in place because name_tokens is needed further down anyway.
						# Deliberately NO fallback-when-empty: restoring the token behaviour would
						# bring back exactly the wrong-show rows this exists to remove. If some show
						# is named in a way no candidate spells out, the 'title_phrase' counter in the
						# NYAA-DIAG line makes that visible instead of hiding it.
						_name_seq = _title_seq(name)   # hoisted: the generator below re-ran it per candidate
						if title_seqs and not _seq_matches(_name_seq, title_seqs):
							_reject_stats['title_phrase'] = _reject_stats.get('title_phrase', 0) + 1
							continue
						# ---------- title-token guard (cross-show contamination) ----------
						if accept_tokens:
							name_tokens = _tokenize(name)
							if not (accept_tokens & name_tokens):
								_reject_stats['token'] += 1
								continue
						else:
							name_tokens = _tokenize(name)

						# ---------- Otaku-style extract on cleaned text ----------
						seasons, episodes, parts, is_range = (set(), None, set(), False)
						if is_show:
							cleaned = _clean_for_extract(name)
							seasons, episodes, parts, is_range = _extract_meta(cleaned)

							# LOCAL PATCH 2026-08-07: cross-season contamination reject.
							# When Fen Light passed tokens from OTHER seasons' TMDb names
							# (e.g. Bleach S2 = "Thousand-Year Blood War"), reject any torrent
							# that hits those tokens UNLESS it explicitly claims our target
							# season (i.e. we can trust its S# marker).
							if foreign_reject_tokens and (foreign_reject_tokens & name_tokens):
								if season_num not in seasons:  # includes empty seasons set
									_xbmc_diag.log('NYAA-DIAG: REJECT foreign-season-token hit=%s name=%r' % ((foreign_reject_tokens & name_tokens), name), _xbmc_diag.LOGINFO)
									_reject_stats['foreign_season'] += 1
									continue

							# LOCAL PATCH 2026-08-27: with a cour mapping, judge by the cour instead.
							# season_num/episode_num are TMDb's, and for split seasons they match
							# nothing: every Re:ZERO cour is TMDb season 1. cour_match compares the
							# release season (Fribb's season.tvdb) and accepts either the cour-relative
							# or the absolute episode number.
							if cour_episode is not None and cour_season:
								if not cour_match(name, cour_season, cour_episode, absolute_episode,
									season_episode, cour_part, foreign_cour_tokens):
									_reject_stats['cour'] = _reject_stats.get('cour', 0) + 1
									continue
							else:
								# season check — reject if explicit season present AND not ours
								if seasons and season_num not in seasons:
									_reject_stats['season'] += 1
									continue

								# episode check — accept when episodes covers our target OR
								# when no episode could be extracted (bare batch, auto-accept).
								# The absolute number counts as our target too: without a Fribb cour this
								# is the only path, and 'Naruto - 159' is TMDb's S04E01.
								_want_eps = set([episode_num])
								if absolute_episode: _want_eps.add(absolute_episode)
								if episodes is not None and not (_want_eps & set(episodes)):
									_reject_stats['episode'] += 1
									continue

								# S2+ ambiguity guard: reject any torrent that has NO season
								# indicator AND matches via a BATCH-style pattern (no episode
								# extracted OR extracted an episode range). Bare individual
								# episodes without season markers are still accepted — that's
								# the weekly-release naming convention (`[Group] Show - 05`).
								if season_num >= 2 and not seasons and (episodes is None or is_range):
									_reject_stats['s2_ambig'] += 1
									continue

						# ---------- sequel/spinoff reject (deferred until AFTER season extract) ----------
						# LOCAL PATCH 2026-07-20: TMDb sometimes lists sequel/spinoff titles as
						# aliases of the parent show (e.g. "Bleach: Thousand-Year Blood War" as
						# alias of Bleach). When the user targets the ORIGINAL season, we want to
						# reject those. But when they target the SEQUEL season (e.g. Bleach S17
						# which IS TYBW in TMDb), the torrents legitimately carry those tokens.
						# Skip the sequel reject when the torrent has an explicit season marker
						# matching our target — that torrent has claimed to be our season, trust it.
						if accept_tokens and sequel_extra_tokens and (sequel_extra_tokens & name_tokens):
							if season_num not in seasons:   # includes empty seasons set
								_xbmc_diag.log('NYAA-DIAG: REJECT sequel-token hit=%s name=%r' % ((sequel_extra_tokens & name_tokens), name), _xbmc_diag.LOGINFO)
								_reject_stats['sequel'] += 1
								continue

						# ---------- foreign-lang guard ----------
						if source_utils.remove_lang(name, check_foreign_audio):
							_reject_stats['foreign_lang'] += 1
							continue

						# ---------- seeders ----------
						try:
							seeders = int(link[2][0])
							if self.min_seeders > seeders:
								_reject_stats['seeders'] += 1
								continue
						except: seeders = 0

						quality, info = source_utils.get_release_quality(name, magnet)
						try:
							size = link[1]
							dsize, isize = source_utils._size(size)
							info.insert(0, isize)
						except: dsize = 0
						info = ' | '.join(info)

						seen_hashes.add(hash)
						append({'provider': 'nyaa', 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name, 'quality': quality,
										'language': 'en', 'url': magnet, 'info': info, 'direct': False, 'debridonly': True, 'size': dsize})
			except:
				source_utils.scraper_error('NYAA')
				continue
		_xbmc_diag.log('NYAA-DIAG: final source count=%d (pre-filter unique=%d) rejects=%s' % (
			len(sources), _pre_filter_count, {k: v for k, v in _reject_stats.items() if v}), _xbmc_diag.LOGINFO)
		return sources
