# created by kodifitzwell for Fenomscrapers
"""
	Fenomscrapers Project
"""

from json import loads as jsloads
import re, queue
from magneto.modules import client
from magneto.modules import source_utils
from magneto.modules.control import setting as getSetting
from magneto.modules import anime_utils


class source:
	timeout = 10
	priority = 1
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	_queue = queue.SimpleQueue()
	def __init__(self):
		self.language = ['en']
		self.base_link = (
			"https://comet.stremio.ru",
			"https://comet.feels.legal",
			"https://cometfortheweebs.midnightignite.me"
		)[int(getSetting('comet.url', '0'))]
		self.movieSearch_link = '/stream/movie/%s.json'
		self.tvSearch_link = '/stream/series/%s:%s:%s.json'
		# LOCAL PATCH 2026-08-27: Kitsu endpoint for anime. Comet answers the TMDb
		# coordinate poorly because nobody names anime that way -- measured on Frieren
		# S1E30 (cour 2 episode 2): imdb tt22248376:1:30 returned 2 streams, while
		# kitsu:49240:2 returned 556.
		self.tvSearch_link_kitsu = '/stream/series/kitsu:%s:%s.json'
		self.min_seeders = 0

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		sources_append = sources.append
		try:
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
			aliases = data['aliases']
			episode_title = data['title'] if 'tvshowtitle' in data else None
			year = data['year']
			imdb = data['imdb']
			if 'tvshowtitle' in data:
				season = data['season']
				episode = data['episode']
				hdlr = 'S%02dE%02d' % (int(season), int(episode))
				# Fen Light fills these in for anime only (scrapers/external.py), from the
				# Fribb cour mapping. cour_season is the RELEASE season number (season.tvdb),
				# which is what a release's 'S02'/'2nd Season' marker actually refers to.
				kitsu_id = data.get('kitsu_id')
				cour_episode = data.get('cour_episode')
				cour_season = data.get('cour_season')
				absolute_episode = data.get('absolute_episode')
				season_episode = data.get('season_episode')
				cour_part = data.get('cour_part')
				foreign_cour_tokens = data.get('foreign_cour_tokens')
				kitsu_mode = bool(kitsu_id) and cour_episode is not None
				if kitsu_mode:
					url = '%s%s' % (self.base_link, self.tvSearch_link_kitsu % (kitsu_id, cour_episode))
				else:
					url = '%s%s' % (self.base_link, self.tvSearch_link % (imdb, season, episode))
			else:
				hdlr = year
				kitsu_mode, cour_season, cour_episode = False, None, None
				absolute_episode, season_episode, cour_part = None, None, None
				foreign_cour_tokens = None
				url = '%s%s' % (self.base_link, self.movieSearch_link % imdb)
			# log_utils.log('url = %s' % url)
			try:
				results = client.request(url, timeout=self.timeout)
				files = jsloads(results)['streams']
			except:
				files = []
				raise
			finally:
				self._queue.put_nowait(files) # if seasons
				self._queue.put_nowait(files) # if shows
			_INFO = re.compile(r'💾.*')
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('COMET')
			return sources

		for file in files:
			try:
				hash = file['infoHash']
				file_title = file['description'].replace('┈➤', '\n').split('\n')
				file_info = [x for x in file_title if _INFO.search(x)][0]

				name = source_utils.clean_name(file_title[0])

				# LOCAL PATCH 2026-08-27: check_title requires the SxxExx token in the release
				# name, which anime releases do not carry -- that alone discarded nearly every
				# anime result regardless of what the query returned.
				#
				# Unlike torrentio's kitsu path we do NOT skip validation entirely. Torrentio's
				# kitsu endpoint is genuinely cour-scoped; comet's is not -- a cour 2 episode 2
				# query also returns '[aL] Sousou no Frieren (2023) - 02', which is cour ONE
				# episode 2. Dropping the check would import the wrong episode.
				if kitsu_mode:
					# LOCAL PATCH 2026-08-27: check the SHOW before the episode. comet's kitsu
					# endpoint leaks unrelated series -- kitsu:11:159 (Naruto) returned
					# '11.22.63.S01.2160p.HULU.WEB-DL' -- and cour_match cannot catch that,
					# because those rows carry a perfectly plausible episode number. Measured:
					# this drops 267 of 536 Naruto rows and 119 of 381 Frieren rows, all noise.
					if not anime_utils.title_guard(name, title, anime_utils.alias_titles(data)): continue
					if not anime_utils.cour_match(name, cour_season, cour_episode,
						absolute_episode, season_episode, cour_part,
						foreign_cour_tokens): continue
				elif not source_utils.check_title(title, aliases, name.replace('.(Archie.Bunker', ''), hdlr, year): continue
				name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)

				try:
					seeders = int(re.search(r'👤\s*(\d+)', file_info).group(1))
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				try:
					size = re.search(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', file_info).group(0)
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)

				sources_append({
					'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True,
					'provider': 'comet', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
					'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders
				})
			except:
				source_utils.scraper_error('COMET')
		return sources

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		sources = []
		if not data: return sources
		sources_append = sources.append
		try:
			title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
			aliases = data['aliases']
			imdb = data['imdb']
			year = data['year']
			season = data['season']
			url = '%s%s' % (self.base_link, self.tvSearch_link % (imdb, season, data['episode']))
			files = self._queue.get(timeout=self.timeout + 1)
			_INFO = re.compile(r'💾.*')
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('COMET')
			return sources

		for file in files:
			try:
				hash = file['infoHash']
				file_title = file['description'].replace('┈➤', '\n').split('\n')
				file_info = [x for x in file_title if _INFO.search(x)][0]

				name = source_utils.clean_name(file_title[0])

				episode_start, episode_end = 0, 0
				if not search_series:
					if not bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, season, name.replace('.(Archie.Bunker', ''))
						if not valid: continue
					package = 'season'

				elif search_series:
					if not bypass_filter:
						valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season, name.replace('.(Archie.Bunker', ''), total_seasons)
						if not valid: continue
					else: last_season = total_seasons
					package = 'show'

				name_info = source_utils.info_from_name(name, title, year, season=season, pack=package)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
				try:
					seeders = int(re.search(r'👤\s*(\d+)', file_info).group(1))
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				try:
					size = re.search(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', file_info).group(0)
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)

				item = {
					'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True,
					'provider': 'comet', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
					'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders, 'package': package
				}
				if search_series: item.update({'last_season': last_season})
				elif episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end}) # for partial season packs
				sources_append(item)
			except:
				source_utils.scraper_error('COMET')
		return sources
