# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-27: SeaDex provider -- the curated best release, by ID.
#
# WHAT SEADEX IS
# releases.moe is a small, hand-maintained index (~2,800 anime) recording which
# release of a given anime is the best one, and why. It is not a tracker and not a
# search engine: for each anime it names specific torrents, with the release group,
# the infoHash, and the full file listing. Entries are keyed on AniList id, which
# scrapers/external.py already resolves and passes in as data['anilist_id'] -- so
# unlike animetosho.py this needs no new mapping layer at all.
#
# WHY IT IS WORTH A PROVIDER
# The other anime providers answer "what exists for this episode?" and return
# everything, sorted by seeders. Seeders measure popularity, not quality. SeaDex
# answers a different question -- "which one should I actually watch?" -- and the
# answer is often a release the seeder sort buries: for Frieren it picks a PMR BD
# Remux at 7.5GB an episode, which no popularity ranking would ever surface first.
#
# Measured against this library before building it (187 anime in metacache):
#   105 shows had a SeaDex entry (56%); the rest fall through to the other providers
#   96% of the curated releases were ALREADY CACHED on TorBox (150/157)
#   99% of covered shows had at least one cached release (104/105)
# That cache rate is the whole reason this is useful rather than aspirational -- a
# curated pick that had to be downloaded first would be no use for streaming.
#
# WHY IT ONLY WORKS NOW
# SeaDex releases are cour PACKS, so playing one means picking the right file out of
# it. That happens in the debrid layer, which until the 2026-08-27 cour-numbering fix
# matched TMDb's episode number against anime filenames and failed. This provider
# would have returned sources that all failed on click before that change landed.
#
# Because the API hands over the file list, this provider does something the others
# cannot: it locates the episode's actual file up front, so it can skip a release
# that does not contain the episode (SeaDex flags some entries `incomplete`) and
# report the true size of the file that will play rather than a divided estimate.
#
# API: https://releases.moe/api/collections/entries/records?filter=alID=<id>&expand=trs
# No key, no auth.

import re

from magneto.modules import client
from magneto.modules import source_utils

try:
	import json as _json
except ImportError:
	_json = None

_API = ('https://releases.moe/api/collections/entries/records'
		'?filter=alID=%s&expand=trs&perPage=1')

# Trackers a magnet needs to be usable if a debrid service has to fetch it fresh.
# SeaDex stores only the infoHash, so the magnet is assembled here.
_TRACKERS = (
	'http://nyaa.tracker.wf:7777/announce',
	'udp://open.stealth.si:80/announce',
	'udp://tracker.opentrackr.org:1337/announce',
	'udp://exodus.desync.com:6969/announce',
	'udp://tracker.torrent.eu.org:451/announce',
)

_VIDEO = ('.mkv', '.mp4', '.avi', '.m4v', '.ts')

# In the pack but not the show: openings, endings, previews, menus, extras. Kept out
# of episode matching so an "NCOP 01" cannot answer a request for episode 1.
_NOT_AN_EPISODE = re.compile(
	r'(?:^|[^a-z0-9])(?:nc)?(?:op|ed)\d*(?:[^a-z0-9]|$)|'
	r'(?:^|[^a-z0-9])(?:menu|preview|pv|cm|extra|extras|bonus|interview|'
	r'trailer|teaser|creditless|clean|sample|logo|special|specials|'
	r'sp\d+|oad|ova|omake|recap)(?:[^a-z0-9]|$)', re.I)


def _episode_in(name, season, episode):
	"""True when `name` is episode `episode` (of `season`), on clean digit edges.

	Deliberately narrow. This runs over the files of ONE known anime, so the title is
	not in question and only the number has to be read -- which means the loose
	fallbacks a search provider needs (and which cause its false positives) are
	unnecessary here and are left out.
	"""
	n = re.sub(r'[._]+', ' ', name)
	e2, s2 = '%02d' % episode, '%02d' % season
	patterns = (
		r'\bs%s ?e%s(?!\d)' % (s2, e2),
		r'\bs%d ?e%s(?!\d)' % (season, e2),
		r'\be%s(?!\d)' % e2,
		r'(?<!\d)- ?%s(?!\d)' % e2,          # "[Group] Show - 07"
		r'(?<!\d)- ?%d(?!\d)' % episode,     # "- 7" and "- 107"
		r'\[%s\](?!\d)' % e2,
		r'(?<!\d)%s(?!\d)(?= ?[\[(])' % e2,  # "Show 07 [1080p]"
	)
	return any(re.search(p, n, re.I) for p in patterns)


def _pick_file(files, candidates):
	"""The file dict for the requested episode, trying candidates in order.

	`candidates` is ordered highest-episode-number first for the same reason the
	debrid resolver orders that way: a pack numbered per-cour holds no file carrying
	the series-absolute number, but a pack numbered absolutely DOES hold a file whose
	number matches the cour-relative one -- and it is the wrong episode.
	"""
	usable = [f for f in files
			if isinstance(f, dict)
			and (f.get('name') or '').lower().endswith(_VIDEO)
			and not _NOT_AN_EPISODE.search(f.get('name') or '')]
	if not usable: return None
	for season, episode in candidates:
		for f in usable:
			if _episode_in(f['name'], season, episode): return f
	# A single-file entry for a single episode needs no matching at all.
	if len(usable) == 1: return usable[0]
	return None


class source:
	priority = 5
	# Every SeaDex release is already a pack; there is no separate pack query to make,
	# and Fen Light must not ask for one (there is no sources_packs here).
	pack_capable = False
	hasMovies = False
	hasEpisodes = True

	def __init__(self):
		self.language = ['en']
		self.base_link = 'https://releases.moe'
		# SeaDex records no seeder counts. These are curated, widely-mirrored releases
		# and the point of them is the debrid cache, so seeders must gate nothing.
		self.min_seeders = 0

	def _candidates(self, data):
		"""(season, episode) numberings to look for, highest episode number first.

		LOCAL PATCH 2026-08-27: this used to re-derive the ordering, with a docstring
		admitting it 'mirrors' modules/source_utils.anime_episode_candidates on the Fen
		Light side. Two copies of a rule this subtle drift apart, and the two consumers
		-- this provider choosing a file, and the debrid resolver choosing a file out of
		the very same pack -- disagreeing about which numbers count is exactly the bug
		that would be hardest to see. Fen Light now publishes the list it uses, and this
		reads it.

		The local build is a fallback for being driven directly (tests, or any caller
		that did not come through scrapers/external.py).
		"""
		published = data.get('episode_candidates')
		if published:
			out = []
			for pair in published:
				try: out.append((int(pair[0]), int(pair[1])))
				except (TypeError, ValueError, IndexError): continue
			if out: return out
		def _int(key):
			try: return int(data.get(key))
			except (TypeError, ValueError): return None
		season = _int('season') or 1
		cour_season = _int('cour_season') or season
		out = []
		for number, use_season in ((_int('absolute_episode'), season),
						(_int('episode'), season),
						(_int('season_episode'), cour_season),
						(_int('cour_episode'), cour_season)):
			if number and (use_season, number) not in out: out.append((use_season, number))
		out.sort(key=lambda pair: -pair[1])
		return out

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		append = sources.append
		alid = data.get('anilist_id')
		# Without an AniList id there is nothing to look up. Shows whose Fribb row
		# carries no season (Naruto, One Piece and friends) land here and are left to
		# the other providers, which is correct -- SeaDex has no entry for them anyway.
		if not alid: return sources
		try:
			response = client.request(_API % alid, timeout=10)
			if not response: return sources
			payload = _json.loads(response)
			items = (payload or {}).get('items') or []
			if not items: return sources
			entry = items[0]
			torrents = (entry.get('expand') or {}).get('trs') or []
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('SEADEX')
			return sources

		# Public tracker only: SeaDex also indexes private trackers, whose entries
		# carry no usable infoHash and which no debrid service could fetch anyway.
		nyaa = [t for t in torrents if isinstance(t, dict) and t.get('tracker') == 'Nyaa'
				and len(t.get('infoHash') or '') == 40]
		# `isBest` is the entire point of the index -- SeaDex's verdict rather than a
		# popularity measure. Fall back to the rest only when nothing is flagged, which
		# keeps the provider's meaning simple: a SEADEX row IS the curated pick.
		best = [t for t in nyaa if t.get('isBest')] or nyaa
		if not best: return sources

		candidates = self._candidates(data)
		incomplete = bool(entry.get('incomplete'))
		seen = set()
		for torrent in best:
			try:
				info_hash = torrent['infoHash'].lower()
				if info_hash in seen: continue
				chosen = _pick_file(torrent.get('files') or [], candidates)
				# No file for this episode: either the release genuinely stops short
				# (SeaDex marks those `incomplete`) or it covers a season we are not
				# asking for. Returning it would produce a source that cannot play.
				if not chosen: continue
				name = source_utils.clean_name(chosen['name'])
				if not name: continue
				name_info = source_utils.info_from_name(
					name, data.get('tvshowtitle') or '', str(data.get('year') or ''),
					season=str(data.get('season') or ''))
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				magnet = 'magnet:?xt=urn:btih:%s&dn=%s%s' % (
					info_hash, name, ''.join('&tr=%s' % t for t in _TRACKERS))
				quality, info = source_utils.get_release_quality(name_info, magnet)
				# The size of the FILE that will play, not of the pack it sits in. Every
				# other provider can only estimate this by dividing the pack size by an
				# episode count; SeaDex gives the real per-file length.
				dsize = round(float(chosen.get('length') or 0) / 1073741824, 2)
				if dsize: info.insert(0, '%.2f GB' % dsize)
				# LOCAL PATCH 2026-08-27: label multi-episode releases as packs so they are
				# tagged and filterable like any other. Safe to do only because seadex is in
				# scrapers/external.py's no-divide list -- otherwise Fen Light would divide
				# this exact per-file size by the TMDb season's episode_count and wreck it.
				videos = [f for f in (torrent.get('files') or [])
						if isinstance(f, dict) and (f.get('name') or '').lower().endswith(_VIDEO)]
				package = 'season' if len(videos) > 1 else None
				if package:
					total = sum(float(f.get('length') or 0) for f in videos) / 1073741824
					if total: info.append('%.1f GB pack' % total)
				group = torrent.get('releaseGroup')
				if group: info.append('SEADEX %s' % group)
				if torrent.get('dualAudio'): info.append('DUAL AUDIO')
				if incomplete: info.append('INCOMPLETE RELEASE')

				seen.add(info_hash)
				item = {'provider': 'seadex', 'source': 'torrent', 'seeders': 0,
						'hash': info_hash, 'name': name, 'name_info': name_info,
						'quality': quality, 'language': 'en', 'url': magnet,
						'info': ' | '.join(info), 'direct': False, 'debridonly': True,
						'size': dsize}
				if package: item['package'] = package
				append(item)
			except Exception:
				source_utils.scraper_error('SEADEX')
				continue
		return sources
