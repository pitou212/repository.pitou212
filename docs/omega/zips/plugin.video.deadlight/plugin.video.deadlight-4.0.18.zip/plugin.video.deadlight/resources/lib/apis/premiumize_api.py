# -*- coding: utf-8 -*-
import re
import json
import time
from threading import Thread
from urllib.parse import urlencode
from caches.main_cache import cache_object
from caches.settings_cache import get_setting, set_setting
from modules.utils import copy2clip, make_qrcode
from modules.source_utils import supported_video_extensions, seas_ep_filter, extras, pick_episode_files
from modules.kodi_utils import sleep, ok_dialog, progress_dialog, notification, make_session
# logger = kodi_utils.logger

# LOCAL PATCH 2026-06-20 (perf): pooled HTTP session reuses TCP connections across Premiumize calls.
session = make_session('https://www.premiumize.me/')

class PremiumizeAPI:
	def __init__(self):
		self.token = get_setting('deadlight.pm.token', 'empty_setting')

	def auth(self):
		self.token = ''
		line = '%s[CR]%s[CR]%s'
		data = {'response_type': 'device_code', 'client_id': '888228107'}
		url = 'https://www.premiumize.me/token'
		response = self._post(url, data)
		user_code = response['user_code']
		auth_url = response.get('verification_uri')
		qr_code = make_qrcode(auth_url) or ''
		copy2clip(auth_url)
		content = 'Authorize Debrid Services[CR]Navigate to: [B]%s[/B][CR]Enter the following code: [B]%s[/B]' % (auth_url, user_code)
		progressDialog = progress_dialog('Premiumize Authorize', qr_code)
		progressDialog.update(content, 0)
		device_code = response['device_code']
		expires_in = int(response['expires_in'])
		sleep_interval = int(response['interval'])
		poll_url = 'https://www.premiumize.me/token'
		data = {'grant_type': 'device_code', 'client_id': '888228107', 'code': device_code}
		start, time_passed = time.time(), 0
		while not progressDialog.iscanceled() and time_passed < expires_in and not self.token:
			sleep(1000 * sleep_interval)
			response = self._post(poll_url, data)
			if 'error' in response:
				time_passed = time.time() - start
				progress = int(100 * time_passed/float(expires_in))
				progressDialog.update(content, progress)
				continue
			try:
				progressDialog.close()
				self.token = str(response['access_token'])
				set_setting('pm.token', self.token)
			except:
				 ok_dialog(text='Error')
				 break
		try: progressDialog.close()
		except: pass
		if self.token:
			account_info = self.account_info()
			set_setting('pm.account_id', str(account_info['customer_id']))
			set_setting('pm.enabled', 'true')
			ok_dialog(text='Success')

	def revoke(self):
		set_setting('pm.token', 'empty_setting')
		set_setting('pm.account_id', 'empty_setting')
		set_setting('pm.enabled', 'false')
		notification('Premiumize Authorization Reset', 3000)

	def account_info(self):
		url = 'account/info'
		response = self._post(url)
		return response

	def check_cache(self, hashes):
		url = 'cache/check'
		data = {'items[]': hashes}
		response = self._post(url, data)
		return response

	def unrestrict_link(self, link):
		data = {'src': link}
		url = 'transfer/directdl'
		response = self._post(url, data)
		try: return self.add_headers_to_url(response['content'][0]['link'])
		except: return None

	# LOCAL PATCH 2026-08-27: ep_candidates carries the alternate numberings an anime
	# release may use for this episode (see source_utils.anime_episode_candidates).
	# Empty/None for everything else, so non-anime resolution is byte-for-byte as before.
	# _matched is the numbering that actually found the file; the split=True call below
	# MUST reuse it, because with split=True a miss raises instead of returning False.
	def resolve_magnet(self, magnet_url, info_hash, store_to_cloud, title, season, episode, ep_candidates=None):
		# LOCAL PATCH 2026-10-25 (4.0.5): every failed exit says why, as TorBox and Real-Debrid do (log + sources.RESOLVE_REASON_PROP)
		def _why(reason):
			try:
				from modules.kodi_utils import logger, set_property
				from modules.utils import redact_url
				reason = redact_url(str(reason))
				logger('Premiumize resolve', '%s S%sE%s %s: %s' % (info_hash, season, episode, title, reason))
				set_property('deadlight.resolve_reason', 'Premiumize: %s' % reason)
			except Exception: pass
		try:
			file_url = None
			correct_files = []
			append = correct_files.append
			extensions = supported_video_extensions()
			result = self.instant_transfer(magnet_url)
			if not 'status' in result or result['status'] != 'success':
				_why('not cached on Premiumize (%s)' % (result.get('message') or result.get('status') or 'no answer') if isinstance(result, dict) else 'no answer')
				return None
			content = result.get('content')
			valid_results = [i for i in content if any(i.get('path').lower().endswith(x) for x in extensions) and not i.get('link', '') == '']
			if len(valid_results) == 0:
				_why('no video file among %d files' % len(content or []))
				return
			if season:
				extras_filter = extras()
				episode_title = re.sub(r'[^A-Za-z0-9-]+', '.', title.replace('\'', '').replace('&', 'and').replace('%', '.percent')).lower()
				_hits, _matched = pick_episode_files(
					valid_results, season, episode, lambda f: f['path'].split('/')[-1], ep_candidates, title)
				for item in _hits: append(item)
				if correct_files:
					for i in correct_files:
						compare_link = seas_ep_filter(_matched[0], _matched[1], i['path'], split=True)
						compare_link = re.sub(episode_title, '', compare_link)
						if not any(x in compare_link for x in extras_filter):
							file_url = i['link']
							break
			else:
				file_url = max(valid_results, key=lambda x: int(x.get('size'))).get('link', None)
				if not any(file_url.lower().endswith(x) for x in extensions): file_url = None
			if file_url:
				if store_to_cloud: Thread(target=self.create_transfer, args=(magnet_url,)).start()
				return self.add_headers_to_url(file_url)
			_why('no file for this episode among %d video files' % len(valid_results) if season else 'largest file is not a playable video')
		except Exception as e:
			_why('failed: %s' % type(e).__name__)
			return None

	def display_magnet_pack(self, magnet_url, info_hash):
		from modules.source_utils import supported_video_extensions
		try:
			end_results = []
			append = end_results.append
			extensions = supported_video_extensions()
			result = self.instant_transfer(magnet_url)
			if not 'status' in result or result['status'] != 'success': return None
			for item in result.get('content'):
				if any(item.get('path').lower().endswith(x) for x in extensions) and not item.get('link', '') == '':
					try: path = item['path'].split('/')[-1]
					except: path = item['path']
					append({'link': item['link'], 'filename': path, 'size': item['size']})
			return end_results
		except: return None

	def user_cloud(self, folder_id=None):
		if folder_id:
			string = 'pm_user_cloud_%s' % folder_id
			url = 'folder/list?id=%s' % folder_id
		else:
			string = 'pm_user_cloud_root'
			url = 'folder/list'
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_all(self):
		string = 'pm_user_cloud_all_files'
		url = 'item/listall'
		return cache_object(self._get, string, url, False, 0.03)

	def rename_cache_item(self, file_type, file_id, new_name):
		if file_type == 'folder': url = 'folder/rename'
		else: url = 'item/rename'
		data = {'id': file_id , 'name': new_name}
		response = self._post(url, data)
		return response['status']

	def transfers_list(self):
		url = 'transfer/list'
		return self._get(url)

	def instant_transfer(self, magnet_url):
		url = 'transfer/directdl'
		data = {'src': magnet_url}
		return self._post(url, data)

	def create_transfer(self, magnet):
		data = {'src': magnet, 'folder_id': 0}
		url = 'transfer/create'
		return self._post(url, data)

	def delete_transfer(self, transfer_id):
		data = {'id': transfer_id}
		url = 'transfer/delete'
		return self._post(url, data)

	def delete_object(self, object_type, object_id):
		data = {'id': object_id}
		url = '%s/delete' % object_type
		response = self._post(url, data)
		return response['status']

	def get_item_details(self, item_id):
		string = 'pm_item_details_%s' % item_id
		url = 'item/details'
		data = {'id': item_id}
		args = [url, data]
		return cache_object(self._post, string, args, False, 0.5)

	def add_headers_to_url(self, url):
		return url + '|' + urlencode(self.headers())

	def headers(self):
		return {'User-Agent': 'DeadLight for Kodi', 'Authorization': 'Bearer %s' % self.token}

	def _get(self, url, data={}):
		if self.token in ('empty_setting', ''): return None
		url = 'https://www.premiumize.me/api/' + url
		response = session.get(url, data=data, headers=self.headers(), timeout=20).text
		try: return json.loads(response)
		except: return response

	def _post(self, url, data={}):
		if self.token in ('empty_setting', '') and not 'token' in url: return None
		if not 'token' in url: url = 'https://www.premiumize.me/api/' + url
		response = session.post(url, data=data, headers=self.headers(), timeout=20).text
		try: return json.loads(response)
		except: return response

	def clear_cache(self, clear_hashes=True):
		from caches.debrid_cache import clear_account_cache   # LOCAL PATCH 2026-11-01 (cleanup): shared body
		return clear_account_cache('pm', ('pm_user_cloud%', 'pm_transfers_list'), clear_hashes)

Premiumize = PremiumizeAPI()
