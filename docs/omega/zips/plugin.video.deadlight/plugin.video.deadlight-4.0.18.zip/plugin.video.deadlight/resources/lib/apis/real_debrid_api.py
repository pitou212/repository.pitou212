# -*- coding: utf-8 -*-
import re
import time
from threading import Thread
from caches.main_cache import cache_object
from caches.settings_cache import get_setting, set_setting
from modules.utils import copy2clip, make_tinyurl, make_qrcode
from modules.source_utils import supported_video_extensions, seas_ep_filter, extras, pick_episode_files, split_disc
from modules.kodi_utils import sleep, ok_dialog, progress_dialog, notification, make_session
# from modules.kodi_utils import logger

# LOCAL PATCH 2026-06-20 (perf): pooled HTTP session reuses TCP connections across RD calls.
# host swaps between app.real-debrid.com and api.real-debrid.com depending on user setting,
# so mount to 'https://' (covers both hosts via the default adapter).
session = make_session('https://')
_AUTH_TOKEN = re.compile(r'(auth_token=)[^&\s)\'"]+')   # LOCAL PATCH 2026-10-15: see resolve_magnet._why
_RD_PENDING = ('magnet_conversion', 'waiting_files_selection', 'queued')   # LOCAL PATCH 2026-10-25 (4.0.5): see _selected_info

class RealDebridAPI:
	def __init__(self):
		self.client_ID = get_setting('deadlight.rd.client_id', 'empty_setting')
		if self.client_ID in ('empty_setting', ''): self.client_ID = 'X245A4XAIBGVM'
		url = {'true': 'app.real-debrid.com', 'false': 'api.real-debrid.com'}[get_setting('deadlight.rd.alternate_base_url', 'false')]
		self.base_url = 'https://%s/rest/1.0/' % url
		self.auth_url = 'https://%s/oauth/v2/' % url
		self.token = get_setting('deadlight.rd.token', 'empty_setting')
		self.secret = get_setting('deadlight.rd.secret', 'empty_setting')
		self.refresh = get_setting('deadlight.rd.refresh', 'empty_setting')
		self.device_code = ''
		self.refresh_retries = 0
		self.break_auth_loop = False

	def auth(self):
		self.secret = ''
		self.client_ID = 'X245A4XAIBGVM'
		url = self.auth_url + 'device/code?%s' % 'client_id=%s&new_credentials=yes' % self.client_ID
		response = session.get(url, timeout=20).json()
		user_code = response['user_code']
		auth_url = response['direct_verification_url']
		qr_code = make_qrcode(auth_url) or ''
		short_url = make_tinyurl(auth_url)
		copy2clip(auth_url)
		if short_url: p_dialog_insert = 'OR visit this URL: [B]%s[/B][CR]OR Enter this Code: [B]%s[/B]' % (short_url, user_code)
		else: p_dialog_insert = 'OR Enter this Code: [B]%s[/B]' % user_code
		content = 'Please Scan the QR Code%s[CR]' % p_dialog_insert
		progressDialog = progress_dialog('Real Debrid Authorize', qr_code)
		progressDialog.update(content, 0)
		expires_in = int(response['expires_in'])
		sleep_interval = int(response['interval'])
		device_code = response['device_code']
		poll_url = self.auth_url + 'device/credentials?%s' % 'client_id=%s&code=%s' % (self.client_ID, device_code)
		start, time_passed = time.time(), 0
		while not progressDialog.iscanceled() and time_passed < expires_in and not self.secret:
			sleep(1000 * sleep_interval)
			try: response = session.get(poll_url, timeout=20).json()
			except: continue
			if 'error' in response:
				time_passed = time.time() - start
				progress = int(100 * time_passed/float(expires_in))
				progressDialog.update(content, progress)
				continue
			try:
				set_setting('rd.client_id', response['client_id'])
				set_setting('rd.secret', response['client_secret'])
				self.secret = response['client_secret']
				self.client_ID = response['client_id']
				progressDialog.close()
			except:
				ok_dialog(text='Error')
				break
		try: progressDialog.close()
		except: pass
		if self.secret:
			data = {'client_id': self.client_ID, 'client_secret': self.secret, 'code': device_code, 'grant_type': 'http://oauth.net/grant_type/device/1.0'}
			url = '%stoken' % self.auth_url
			response = session.post(url, data=data, timeout=20).json()
			self.token = response['access_token']
			self.refresh = response['refresh_token']
			username = self.account_info()['username']
			set_setting('rd.token', self.token)
			set_setting('rd.refresh', self.refresh)
			set_setting('rd.account_id', username)
			set_setting('rd.enabled', 'true')
			try:   # LOCAL PATCH 2026-10-11: a fresh authorisation ends any 'premium gone' skip
				from modules.debrid import rd_mark_premium
				rd_mark_premium(False)
			except Exception: pass
			ok_dialog(text='Success')

	def refresh_token(self):
		try:
			url = self.auth_url + 'token'
			data = {'client_id': self.client_ID, 'client_secret': self.secret, 'code': self.refresh, 'grant_type': 'http://oauth.net/grant_type/device/1.0'}
			# LOCAL PATCH 2026-10-15: timeout -- the only RD call without one; a hung socket here froze resolve and scrape.
			response = session.post(url, data=data, timeout=20).json()
			self.token = response['access_token']
			self.refresh = response['refresh_token']
			set_setting('rd.token', self.token)
			set_setting('rd.refresh', self.refresh)
			return True
		except: return False

	def revoke(self):
		set_setting('rd.client_id', 'empty_setting')
		set_setting('rd.secret', 'empty_setting')
		set_setting('rd.refresh', 'empty_setting')
		set_setting('rd.token', 'empty_setting')
		set_setting('rd.account_id', 'empty_setting')
		set_setting('rd.enabled', 'false')
		notification('Real Debrid Authorization Reset', 3000)

	def account_info(self):
		url = 'user'
		return self._get(url)

	def check_cache(self, hashes):
		hash_string = '/'.join(hashes)
		url = 'torrents/instantAvailability/%s' % hash_string
		return self._get(url)

	def torrents_activeCount(self):
		url = 'torrents/activeCount'
		return self._get(url)

	def user_cloud(self):
		string = 'rd_user_cloud'
		url = 'torrents?limit=500'
		return cache_object(self._get, string, url, False, 0.03)


	def downloads(self):
		string = 'rd_downloads'
		url = 'downloads?limit=500'
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_info(self, file_id):
		string = 'rd_user_cloud_info_%s' % file_id
		url = 'torrents/info/%s' % file_id
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_info_check(self, file_id):
		url = 'torrents/info/%s' % file_id
		return self._get(url)

	# LOCAL PATCH 2026-10-25 (4.0.5): replaces a fixed sleep(1000) after selectFiles (and a second one before the activeCount
	# loop) -- ~2 s on every RD play, cached or not. Ask at once; while RD is still converting/selecting, re-ask every 250 ms
	# for up to ~2 s. A cached torrent is usually 'downloaded' on the first ask.
	def _selected_info(self, torrent_id):
		torrent_info = self.user_cloud_info_check(torrent_id)
		deadline = time.time() + 1.0   # the old fixed wait: a stuck conversion is never slower than before, a quick one still plays
		while isinstance(torrent_info, dict) and torrent_info.get('status') in _RD_PENDING and time.time() < deadline:
			sleep(250)
			torrent_info = self.user_cloud_info_check(torrent_id)
		return torrent_info

	def torrent_info(self, file_id):
		url = 'torrents/info/%s' % file_id
		return self._get(url)

	def unrestrict_link(self, link):
		url = 'unrestrict/link'
		post_data = {'link': link}
		response = self._post(url, post_data)
		try: return response['download']
		except: return None

	def add_magnet(self, magnet):
		# LOCAL PATCH 2026-08-10 (Red Light 2.1.9 port): two guards.
		# (1) Always hand callers a dict. Callers do `if 'error' in torrent` /
		#     `torrent['id']`; a None or string response (network hiccup, HTML error
		#     page) made that raise TypeError instead of failing cleanly.
		# (2) Back off on RD's rate limit. error_code 34 / 'too_many_requests' is
		#     common right after a run of rejected magnets — which the FNEF filename
		#     ban makes routine (see filter.banned_keywords). Without a pause the
		#     resolve loop burns every remaining source at full speed and they all
		#     fail, so genuinely-cached links later in the list never get a chance.
		post_data = {'magnet': magnet}
		url = 'torrents/addMagnet'
		result = self._post(url, post_data)
		if not isinstance(result, dict):
			return {'error': 'invalid_response'}
		try:
			if result.get('error_code') == 34 or 'too_many_requests' in str(result.get('error', '')):
				sleep(2000)
		except Exception: pass
		return result

	def create_transfer(self, magnet_url):
		try:
			extensions = supported_video_extensions()
			torrent = self.add_magnet(magnet_url)
			torrent_id = torrent['id']
			info = self.torrent_info(torrent_id)
			files = info['files']
			self.add_torrent_select(torrent_id, 'all')
			return 'success'
		except:
			self.delete_torrent(torrent_id)
			return 'failed'

	def add_torrent_select(self, torrent_id, file_ids):
		# LOCAL PATCH 2026-10-25 (4.0.5): the clear drops the cached cloud lists (rd_user_cloud*, rd_downloads) so the cloud
		# browser shows the new torrent -- a LIKE scan + eval of every info blob on maincache. Nothing on the play path reads
		# those caches, so it runs beside the selectFiles call instead of in front of it (connections are per-thread).
		Thread(target=self.clear_cache, kwargs={'clear_hashes': False}).start()
		url = 'torrents/selectFiles/%s' % torrent_id
		post_data = {'files': file_ids}
		return self._post(url, post_data)

	def delete_torrent(self, folder_id):
		if self.token in ('empty_setting', ''): return None
		url = 'torrents/delete/%s?auth_token=%s' % (folder_id, self.token)
		response = session.delete(self.base_url + url, timeout=20)
		return response

	def delete_download(self, download_id):
		if self.token in ('empty_setting', ''): return None
		url = 'downloads/delete/%s?auth_token=%s' % (download_id, self.token)
		response = session.delete(self.base_url + url, timeout=20)
		return response

	# LOCAL PATCH 2026-08-27: ep_candidates carries the alternate numberings an anime
	# release may use for this episode (see source_utils.anime_episode_candidates).
	# Empty/None for everything else, so non-anime resolution is byte-for-byte as before.
	# _matched is the numbering that actually found the file; the split=True call below
	# MUST reuse it, because with split=True a miss raises instead of returning False.
	def resolve_magnet(self, magnet_url, info_hash, store_to_cloud, title, season, episode, ep_candidates=None):
		# LOCAL PATCH 2026-10-11: say why a resolve gave up. Every exit below returned None silently, so a failed play
		# (The Alienist S01-02 pack, 2026-10-11 15:43: playback_failed_action 0.7 s after the pick) left no reason at all.
		def _why(reason):
			try:
				from modules.kodi_utils import logger
				# LOCAL PATCH 2026-10-15: a requests ConnectionError's text carries the full URL, ?auth_token= included
				# (_get / _post put the token in the query) -- mask it so a shared kodi.log never holds the RD token.
				reason = _AUTH_TOKEN.sub(r'\1***', str(reason))
				logger('Real-Debrid resolve', '%s S%sE%s %s: %s' % (info_hash, season, episode, title, reason))
				from modules.kodi_utils import set_property   # LOCAL PATCH 2026-10-15: shown on screen (sources.RESOLVE_REASON_PROP)
				set_property('deadlight.resolve_reason', 'Real-Debrid: %s' % reason)
			except Exception: pass
		compare_title = re.sub(r'[^A-Za-z0-9]+', '.', title.replace('\'', '').replace('&', 'and').replace('%', '.percent')).lower()
		attempts, transfer_finished = 0, False
		extensions = supported_video_extensions()
		torrent_id = None
		try:
			torrent = self.add_magnet(magnet_url)
			if 'error' in torrent:
				_why('addMagnet refused: %s (code %s)' % (torrent.get('error'), torrent.get('error_code')))
				if torrent.get('error_code') == 35 or torrent.get('error') == 'infringing_file':
					from modules.debrid import rd_block
					rd_block(info_hash)
					_why('blocked on Real-Debrid -- shown uncached for a week')
				# LOCAL PATCH 2026-10-11: code 9 on every add = the account has no premium (modules.debrid.RD_NO_PREMIUM_KEY)
				elif torrent.get('error_code') == 9 or torrent.get('error') == 'permission_denied':
					try:
						account = self.account_info() or {}
						if isinstance(account, dict) and not account.get('premium'):
							from modules.debrid import rd_premium_lost, rd_mark_premium
							first = not rd_premium_lost()
							rd_mark_premium(True)
							_why('account %s is %s (premium %s, until %s) -- Real-Debrid skipped for 6 h' % (account.get('username'),
								account.get('type'), account.get('premium'), account.get('expiration')))
							if first: notification('Real-Debrid premium has expired -- using your other debrids', 6000)
					except Exception: pass
				return None
			torrent_id = torrent['id']
			self.add_torrent_select(torrent_id, 'all')
			torrent_info = self._selected_info(torrent_id)
			if not torrent_info['links'] or 'error' in torrent_info:
				_why('not cached on RD: status %s, %s links' % (torrent_info.get('status'), len(torrent_info.get('links') or [])))
				self.delete_torrent(torrent_id)
				# LOCAL PATCH 2026-10-25 (4.0.5): and remember it for a day. With DMM gone, RD's 'cached' is Torrentio's and
				# MediaFusion's word, which can be stale (Spider-Man: Brand New Day 59a4d2ad, 13:15: listed, RD 'queued'); the row
				# read cached and failed the same way at every pick. Through rd_block, so 'Clear Scrapers Cache' cannot undo it.
				try:
					from modules.debrid import rd_block
					rd_block(info_hash, hours=24)
				except Exception: pass
				return None
			# LOCAL PATCH 2026-10-25 (4.0.5): 'downloaded' with links is finished -- the activeCount check is for anything else.
			if torrent_info.get('status') == 'downloaded': transfer_finished = True
			else: sleep(1000)
			while attempts <= 4 and not transfer_finished:
				active_count = self.torrents_activeCount()
				active_list = active_count['list']
				attempts += 1
				if info_hash in active_list: sleep(1000)
				else: transfer_finished = True
			if not transfer_finished:
				_why('still downloading after %d checks' % attempts)
				self.delete_torrent(torrent_id)
				return None
			files = [i for i in torrent_info['files'] if i['selected'] == 1 and i['path'].lower().endswith(tuple(extensions))]
			selected_files = [(idx, i) for idx, i in enumerate(files)]
			selected_files = sorted(selected_files, key=lambda x: x[1]['bytes'], reverse=True)
			match = False
			if season:
				# selected_files is sorted largest-first and the original took the first hit;
				# [:1] keeps that behaviour exactly.
				_hits, _matched = pick_episode_files([v[1] for v in selected_files], season, episode, 'path', ep_candidates, title)
				correct_files = _hits[:1]
				if len(correct_files) == 0: match = False
				else:
					for i in correct_files:
						compare_link = seas_ep_filter(_matched[0], _matched[1], i['path'], split=True)
						compare_link = re.sub(compare_title, '', compare_link)
						extras_filter = extras()
						if any(x in compare_link for x in extras_filter): continue
						else: match = True; break
				if match: index = [i[0] for i in selected_files if i[1]['path'] == correct_files[0]['path']][0]
			else:
				if self._m2ts_check(selected_files): self.delete_torrent(torrent_id) ; return None
				for value in selected_files:
					filename = re.sub(r'[^A-Za-z0-9-]+', '.', value[1]['path'].rsplit('/', 1)[1].replace('\'', '').replace('&', 'and').replace('%', '.percent')).lower()
					filename_info = filename.replace(compare_title, '')
					extras_filter = extras()
					if any(x in filename_info for x in extras_filter): continue
					match, index = True, value[0]; break
			if match:
				rd_link = torrent_info['links'][index]
				file_url = self.unrestrict_link(rd_link)
				if file_url.endswith('rar'): file_url = None
				if not any(file_url.lower().endswith(x) for x in extensions): file_url = None
				if not store_to_cloud: Thread(target=self.delete_torrent, args=(torrent_id,)).start()
				if not file_url: _why('unrestricted link is not a playable video')
				return file_url
			else:
				_why('no file for this episode among %d video files' % len(files))
				self.delete_torrent(torrent_id)
		except Exception as e:
			_why('failed: %r' % e)
			if torrent_id: self.delete_torrent(torrent_id)
			return None

	def display_magnet_pack(self, magnet_url, info_hash):
		try:
			torrent_id = None
			torrent = self.add_magnet(magnet_url)
			# LOCAL PATCH 2026-08-10 (Red Light 2.1.9 port): bail cleanly on an error
			# response instead of KeyError-ing on torrent['id'].
			if 'error' in torrent: return None
			torrent_id = torrent['id']
			self.add_torrent_select(torrent_id, 'all')
			torrent_info = self._selected_info(torrent_id)   # LOCAL PATCH 2026-10-25 (4.0.5): see resolve_magnet
			if not torrent_info['links'] or 'error' in torrent_info:
				self.delete_torrent(torrent_id)
				return None
			attempts, transfer_finished = 0, torrent_info.get('status') == 'downloaded'
			if not transfer_finished: sleep(1000)
			while attempts <= 4 and not transfer_finished:
				active_count = self.torrents_activeCount()
				active_list = active_count['list']
				attempts += 1
				if info_hash in active_list: sleep(1000)
				else: transfer_finished = True
			if not transfer_finished:
				self.delete_torrent(torrent_id)
				return None
			files = [i for i in torrent_info['files'] if i['selected'] == 1]
			list_file_items = [dict(i, **{'link': torrent_info['links'][idx]}) for idx, i in enumerate(files)]
			list_file_items = [{'link': i['link'], 'filename': i['path'].replace('/', ''), 'size': i['bytes']} for i in list_file_items]
			self.delete_torrent(torrent_id)
			return list_file_items
		except:
			if torrent_id: self.delete_torrent(torrent_id)
			return None


	def _m2ts_check(self, folder_details):
		# LOCAL PATCH 2026-09-29: refuse only a disc whose film may be split over streams (source_utils.split_disc)
		return split_disc([(item['path'], item['bytes']) for idx, item in folder_details])

	def _get(self, url, _retried=False):
		original_url = url
		url = self.base_url + url
		if self.token in ('empty_setting', ''): return None
		if '?' not in url: url += '?auth_token=%s' % self.token
		else: url += '&auth_token=%s' % self.token
		response = session.get(url, timeout=20)
		# LOCAL PATCH 2026-10-15: refresh and retry ONCE, and only on a token error. 'Bad Request' is any 400 body -- with it
		# in the refresh test a persistent 400 refreshed the token and retried forever (refresh_retries was never used). Both
		# still answer None, as before.
		if not _retried and 'bad_token' in response.text:
			return self._get(original_url, _retried=True) if self.refresh_token() else None
		if any(value in response.text for value in ('bad_token', 'Bad Request')): return None
		try: return response.json()
		except: return response

	def _post(self, url, post_data, _retried=False):
		original_url = url
		url = self.base_url + url
		if self.token in ('empty_setting', ''): return None
		if '?' not in url: url += '?auth_token=%s' % self.token
		else: url += '&auth_token=%s' % self.token
		response = session.post(url, data=post_data, timeout=20)
		if not _retried and 'bad_token' in response.text:   # LOCAL PATCH 2026-10-15: see _get
			return self._post(original_url, post_data, _retried=True) if self.refresh_token() else None
		if any(value in response.text for value in ('bad_token', 'Bad Request')): return None
		try: return response.json()
		except: return response

	def clear_cache(self, clear_hashes=True):
		# LOCAL PATCH 2026-11-01 (cleanup): debrid_cache.clear_account_cache. Was: read every rd_user_cloud_info_% row to
		# rebuild 'rd_user_cloud_info_<its id>' and delete that -- the same rows the LIKE deletes, every user_cloud_info key
		# being rd_user_cloud_info_<file_id> -- plus rd_user_cloud and rd_downloads.
		from caches.debrid_cache import clear_account_cache
		return clear_account_cache('rd', ('rd_user_cloud', 'rd_user_cloud_info_%', 'rd_downloads'), clear_hashes)

RealDebrid = RealDebridAPI()

