# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-28: AniList browse renderer.
#
# AniList responses give us `id` (AniList ID) + `idMal` (MAL ID) + `title` +
# `format`, but NO IMDb/TMDb IDs. To feed items into DeadLight's Movies/TVShows
# workers we need TMDb IDs. Strategy: resolve via TMDb title+year search per
# item, cached at the meta_cache layer. Rough success rate for popular anime:
# ~85%. Items that don't resolve are skipped (logged for diagnostics).
#
# Same rendering tail as MDBList (indexers/mdblist_lists.py:_render_content) —
# pack resolved TMDb IDs into `{'list': [(order, media_ids)], 'id_type':
# 'trakt_dict'}` and hand to Movies/TVShows.worker() in parallel threads.

import re
import sys
import time

from apis import anilist_api
from apis.tmdb_api import tmdb_tv_search, tmdb_movies_search
from caches import fribb_mappings
from caches.meta_cache import meta_cache
from indexers.media_list_base import render_mixed, finish_dir
from modules import kodi_utils
from modules.settings import max_threads
from modules.utils import TaskPool
from modules.settings import widget_hide_next_page

# AniList returns per-SEASON anime entries (e.g. "Sousou no Frieren 2nd Season",
# "Sousou no Frieren: ●● no Mahou Part 2"), while TMDb groups all seasons under
# one show. Strip these season/part/cour/movie/OVA suffixes before hitting TMDb
# so all Frieren AniList entries resolve to the same TMDb Frieren show, then
# dedupe.  Order matters: longer / more-specific patterns first.
_SEASON_SUFFIX_RE = re.compile(
	r'\s*[:\-]?\s*(?:'
	r'\d+(?:st|nd|rd|th)\s+season'
	r'|season\s+\d+'
	r'|part\s+\d+'
	r'|cour\s+\d+'
	r'|movie\s+\d+'
	r'|the\s+movie'
	r'|special\s+\d*'
	r'|ova\s*\d*'
	r'|ona\s*\d*'
	r'|final\s+season'
	r')\s*$',
	re.IGNORECASE,
)


def _strip_season_suffix(title):
	"""Trim trailing 'Season 2' / '2nd Season' / 'Part 3' / etc so title matches
	the parent show's TMDb entry."""
	if not title: return title
	prev = None
	# Loop because titles like "Frieren S2 Part 2" have layered suffixes.
	while prev != title:
		prev = title
		title = _SEASON_SUFFIX_RE.sub('', title).strip()
	return title

ANILIST_ICON = 'anime'


# AniList `format` enum categorisation.
_TV_FORMATS = {'TV', 'TV_SHORT', 'ONA', 'OVA', 'SPECIAL'}
_MOVIE_FORMATS = {'MOVIE'}
# 'MUSIC' is out of scope — DeadLight has no music-video routing.


def _classify(fmt):
	if fmt in _MOVIE_FORMATS: return 'movie'
	if fmt in _TV_FORMATS: return 'tvshow'
	return None


def _title_for_search(item):
	"""Prefer English title if present, else romaji, else native.
	Strips season/part suffixes so 'Frieren S2' → 'Frieren' → matches TMDb."""
	t = item.get('title') or {}
	raw = t.get('english') or t.get('romaji') or t.get('native') or ''
	return _strip_season_suffix(raw)


# LOCAL PATCH 2026-08-26: cour identity. TMDb and the anime DBs disagree about what
# a "season" is -- TMDb 220542 (Apothecary Diaries) is ONE season of 49 episodes,
# while AniList/Simkl list its three cours as three separate shows. Every tier of
# _resolve_ids() collapses to the PARENT tmdb id, which is right for browsing but
# means an upcoming cour renders with the first cour's poster, year and plot: in a
# premieres catalog, S3 was indistinguishable from the 2023 S1 you already watched.
#
# Fix: carry the source's own title alongside the id so the tile can name the cour.
# Only the displayed label changes -- see _display_label() in indexers/tvshows.py.

def _raw_source_title(item):
	"""Unstripped source title, e.g. 'The Apothecary Diaries Season 3'.
	Deliberately NOT _title_for_search(), which strips the season suffix in order
	to match the parent show on TMDb -- here the suffix is the whole point."""
	t = item.get('title') or {}
	return t.get('english') or t.get('romaji') or t.get('native') or ''


def _cour_suffix(raw_title):
	"""The trailing season marker alone, e.g. 'Season 3' out of 'The Apothecary
	Diaries Season 3'. Reuses _strip_season_suffix, so whatever that removes is
	exactly what we hand back -- including layered markers like 'Season 3 Part 2'.

	Used only when the source title and the TMDb title are in different naming
	languages (AniList falls back to romaji when it has no English title). The
	consumer then renders 'TMDb Title - Season 3' rather than flipping the whole
	tile to romaji. See _display_label() in indexers/tvshows.py."""
	if not raw_title: return ''
	stripped = _strip_season_suffix(raw_title)
	if stripped and len(stripped) < len(raw_title):
		return raw_title[len(stripped):].strip(' :-–—')
	return ''


_YOUTUBE_PLAY_URL = 'plugin://plugin.video.youtube/play/?video_id=%s'


def _cour_trailer(item):
	"""AniList trailer for THIS cour as a Kodi-playable URL, or '' .

	tvshow_meta() picks a single trailer off the TMDb SHOW, so every cour of a
	multi-season anime inherits the season 1 trailer. AniList entries ARE cours, so
	its per-entry trailer is the season-correct one (Apothecary S1/S2/S3 return three
	different YouTube ids). Only 'youtube' is honoured -- AniList also serves
	dailymotion, which DeadLight has no player route for."""
	t = item.get('trailer') or {}
	try:
		if (t.get('site') or '').lower() != 'youtube': return ''
		# AniList occasionally returns ids with trailing whitespace/tabs.
		vid = (t.get('id') or '').strip()
		return _YOUTUBE_PLAY_URL % vid if vid else ''
	except Exception:
		return ''


def _is_later_cour(row):
	"""True when this Fribb row is a cour other than the show's first.

	The discriminator is the PAIR (season.tmdb, episode_offset.tmdb), not either
	alone. Apothecary splits purely by offset (S1 off 0/24/48); Attack on Titan has
	real TMDb seasons AND offset splits inside them (S3 off 0 and S3 off 12). A
	synthetic 'cour N' index would mislabel AoT's 4th row, which is 'Season 3 Part 2'."""
	if not row: return False
	try:
		season = (row.get('season') or {}).get('tmdb')
		offset = (row.get('episode_offset') or {}).get('tmdb') or 0
		return (int(season or 1) > 1) or (int(offset) > 0)
	except Exception:
		return False


# ═══════════════════════════════════════════════════════════════════════════
#  TMDb resolution (title + year → TMDb ID)
# ═══════════════════════════════════════════════════════════════════════════

def _search_tmdb_tv(title, year):
	"""TMDb TV search by title+year. Returns TMDb ID (str) or None."""
	try:
		res = tmdb_tv_search(title, 1)
		if not res: return None
		results = (res.get('results') if isinstance(res, dict) else res) or []
		if not results: return None
		if year:
			for r in results:
				fad = r.get('first_air_date', '') or ''
				if fad.startswith(str(year)):
					return str(r.get('id') or '')
		return str((results[0] or {}).get('id') or '')
	except Exception:
		return None


def _search_tmdb_movie(title, year):
	"""TMDb movie search by title+year. Returns TMDb ID (str) or None.
	Anime movie titles are often the English or romaji form; try year-match
	first (accurate) then fall back to top result."""
	try:
		res = tmdb_movies_search(title, 1)
		if not res: return None
		results = (res.get('results') if isinstance(res, dict) else res) or []
		if not results: return None
		if year:
			for r in results:
				rd = r.get('release_date', '') or ''
				if rd.startswith(str(year)):
					return str(r.get('id') or '')
		return str((results[0] or {}).get('id') or '')
	except Exception:
		return None


# LOCAL PATCH 2026-10-04: a resolved TMDb id can stop existing. TMDb first listed Black Clover's second season as its
# own show (336735), then deleted it and added Season 2 to Black Clover (73223). SIMKL still answers 336735, the
# resolution was cached for a week, and once the show's cached meta was refreshed TMDb answered 404: the blank entry
# is skipped by the list builder, so the AniList tile simply vanished. A gone id is now treated as no answer and the
# next resolver runs -- here the title search, which strips 'Season 2' and lands on the parent show.
def _tmdb_gone(media_type, tmdb_id, fetch=False):
	"""True when TMDb says this id does not exist (its meta is a blank entry). fetch=True asks TMDb when the meta is
	not cached -- the list builder would fetch it next anyway, so this only moves the request earlier."""
	if not tmdb_id: return False
	db_type = 'movie' if media_type == 'movie' else 'tvshow'
	try:
		meta = meta_cache.get(db_type, 'tmdb_id', str(tmdb_id))
		if meta is None and fetch:
			from modules import metadata, settings
			from modules.utils import get_datetime
			builder = metadata.movie_meta if db_type == 'movie' else metadata.tvshow_meta
			meta = builder('tmdb_id', str(tmdb_id), settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
		return bool(isinstance(meta, dict) and meta.get('blank_entry'))
	except Exception: return False


def _resolve_ids(item):
	"""Return (media_type, {'imdb': '', 'tmdb': tmdb_id, 'tvdb': ''}) or (None, None)."""
	media_type = _classify(item.get('format'))
	if not media_type: return None, None
	# LOCAL PATCH 2026-07-29: try the offline anime-mappings DB FIRST — precise
	# AniList/MAL → TMDb resolution for ~31k anime titles. Falls back to TMDb
	# title+year search for anime not in the mappings (newer / niche).
	anilist_id = item.get('id')
	mal_id = item.get('idMal')
	# LOCAL PATCH 2026-08-26: key bumped to _v2 when cour_label/cour_trailer were added.
	# _resolve_ids returns early on a cache hit, so pre-patch entries (168h TTL) would
	# otherwise suppress the new keys for a week with no way to tell from the UI.
	# LOCAL PATCH 2026-10-21: a backup row (apis/anime_backup.py) can carry a MAL id and no AniList one; MAL and AniList
	# ids are different numbers for different shows, so it is keyed 'mal<id>' -- an AniList row is keyed as before.
	cache_key = 'anilist_tmdb_v2_%s_%s' % (anilist_id or ('mal%s' % mal_id if mal_id else ''), media_type)
	cached = None
	try: cached = meta_cache.get_function(cache_key)
	except Exception: cached = None
	# LOCAL PATCH 2026-10-27: a film cached as its series' TMDb TV id (fribb_mappings._row_tmdb used to fall back to it:
	# the Naruto films as 'Chilly Dogs') is resolved again, not served for the rest of its week
	if cached and not cached.get('miss') and media_type == 'movie':
		try:
			_row = fribb_mappings.anilist_to_fribb(anilist_id) or fribb_mappings.mal_to_fribb(mal_id) or {}
			if str(cached.get('tmdb')) == str((_row.get('themoviedb_id') or {}).get('tv')): cached = None
		except Exception: pass
	if cached:
		# LOCAL PATCH 2026-08-26: misses are cached too (see below), so distinguish them.
		if cached.get('miss'): return None, None
		if not _tmdb_gone(media_type, cached.get('tmdb')): return media_type, cached
		kodi_utils.logger('anilist resolve', 'anilist %s: cached tmdb %s no longer exists on TMDb, resolving again' % (anilist_id, cached.get('tmdb')))
	gone = str(cached.get('tmdb')) if cached and not cached.get('miss') else None
	# LOCAL PATCH 2026-08-10: Fribb anime-lists is now the sole exact-ID mapping
	# source. It replaced Goldenfreddy's anime_mappings DB, whose upstream froze
	# 2026-05-31 — measured across 75 current-season items, anime_mappings resolved
	# 7 while Fribb resolved 43. Fribb's `themoviedb_id.tv` is the PARENT show id
	# (the cour's season lives in `season.tmdb`), which is what catalogs want.
	tmdb_id = None
	# LOCAL PATCH 2026-08-26: fetch the row ONCE here. It was previously looked up
	# only inside the Simkl tier (for simkl_id); the cour check needs it too, and
	# both are in-memory dict hits off the same index.
	fribb_row = None
	try: fribb_row = fribb_mappings.anilist_to_fribb(anilist_id) or fribb_mappings.mal_to_fribb(mal_id)
	except Exception: fribb_row = None
	try:
		if fribb_mappings.is_available():
			tmdb_id = fribb_mappings.fribb_tmdb_for(anilist_id=anilist_id, mal_id=mal_id, media_type=media_type)
	except Exception: pass
	# LOCAL PATCH 2026-10-04: Fribb can hold the deleted id too -- Cyberpunk: Edgerunners 2 (AniList 195539) is
	# 326788 there, TMDb 404, now Season 2 of 105248. Only the id just proven gone is dropped; no request is made.
	if tmdb_id and str(tmdb_id) == gone:
		kodi_utils.logger('anilist resolve', 'anilist %s: Fribb says tmdb %s, which TMDb no longer has; trying SIMKL' % (anilist_id, tmdb_id))
		tmdb_id = None
	# LOCAL PATCH 2026-08-26: Simkl as tier 2, ahead of the title search. Measured on a
	# 50-item current-season page: of Fribb's 12 misses, TMDb title search resolved ZERO
	# while Simkl resolved 10 (exact curated mappings, not a fuzzy guess). Fribb's own
	# simkl_id is used when present (1 request), else Simkl's AniList/MAL lookup finds it
	# (2 requests). Needs only the api-key, so it works with no Simkl account signed in.
	if not tmdb_id:
		try:
			from apis.simkl_api import simkl_tmdb_for
			simkl_id = (fribb_row or {}).get('simkl_id')
			tmdb_id = simkl_tmdb_for(simkl_id=simkl_id, anilist_id=anilist_id, mal_id=mal_id)
		except Exception: pass
		# LOCAL PATCH 2026-10-04: SIMKL keeps ids TMDb has since deleted (see _tmdb_gone)
		if tmdb_id and (str(tmdb_id) == gone or _tmdb_gone(media_type, tmdb_id, fetch=True)):
			kodi_utils.logger('anilist resolve', 'anilist %s: SIMKL says tmdb %s, which TMDb no longer has; trying a title search' % (anilist_id, tmdb_id))
			tmdb_id = None
	if not tmdb_id:
		# Both exact sources missed → last-resort fuzzy title+year TMDb search.
		title = _title_for_search(item)
		if not title: return None, None
		year = (item.get('startDate') or {}).get('year')
		if media_type == 'movie':
			tmdb_id = _search_tmdb_movie(title, year)
		else:
			tmdb_id = _search_tmdb_tv(title, year)
	if not tmdb_id:
		# LOCAL PATCH 2026-08-26: cache the failure. Previously an unresolvable item was
		# re-searched against TMDb on EVERY load of the catalog, forever -- roughly a
		# third of a 25-item page never resolves, so that was ~8 wasted HTTP searches
		# per open. Short TTL (24h vs 168h for hits) so newly-added mappings still get
		# picked up promptly.
		try: meta_cache.set_function(cache_key, {'miss': True}, expiration=24)
		except Exception: pass
		return None, None
	ids = {'imdb': '', 'tmdb': tmdb_id, 'tvdb': ''}
	# LOCAL PATCH 2026-08-26: tag later cours with the source's own title so the tile
	# can name them. Movies have no cours. tvshow_meta() reads only tmdb/imdb/tvdb off
	# a trakt_dict (modules/metadata.py:191-195), so the extra key rides along unused.
	if media_type == 'tvshow' and _is_later_cour(fribb_row):
		cour_label = _raw_source_title(item)
		if cour_label:
			ids['cour_label'] = cour_label
			suffix = _cour_suffix(cour_label)
			if suffix: ids['cour_suffix'] = suffix
		cour_trailer = _cour_trailer(item)
		if cour_trailer: ids['cour_trailer'] = cour_trailer
	try: meta_cache.set_function(cache_key, ids, expiration=168)
	except Exception: pass
	return media_type, ids


# ═══════════════════════════════════════════════════════════════════════════
#  Rendering
# ═══════════════════════════════════════════════════════════════════════════

def _start_date(start):
	"""LOCAL PATCH 2026-10-25: AniList's startDate {year, month, day} as 'YYYY-MM-DD' when the day is known, else 'YYYY' (or '')."""
	try:
		year, month, day = (start or {}).get('year'), (start or {}).get('month'), (start or {}).get('day')
		if not year: return ''
		if month and day: return '%04d-%02d-%02d' % (int(year), int(month), int(day))
		return '%04d' % int(year)
	except (TypeError, ValueError): return ''


def _render(items, list_name, mode_for_next, params, page_no, has_next):
	handle = int(sys.argv[1])
	is_external = kodi_utils.external()
	# LOCAL PATCH 2026-07-29: dedupe by TMDb ID so multiple AniList "seasons" of
	# the same show (S1/S2/S3 all pointing to the same TMDb show entry) collapse
	# to a single row instead of showing as N duplicate tiles.
	# LOCAL PATCH 2026-08-26: resolve IDs in parallel. This loop used to be sequential,
	# and _resolve_ids performs a BLOCKING TMDb title search whenever the Fribb mapping
	# misses -- which is roughly a third of a 25-item page, so ~8 serial HTTP round trips
	# (several seconds) before rendering could even begin. Fan out over TaskPool, which
	# already carries the CoreELEC thread-cap guard and falls back to an inline drain if
	# threads cannot be started. Results are keyed by position so catalog order (these
	# are ranked "trending"/"popular" lists) is preserved exactly.
	resolved = {}
	# LOCAL PATCH 2026-08-29: keep each entry's AniList cover alongside its resolved ids.
	# AniList art is PER COUR -- Mushoku Tensei's airing cour has its own key visual -- but
	# _resolve_ids deliberately returns the PARENT TMDb show id, so handing that to TVShows
	# renders the show-level TMDb poster and the row stops matching anilist.co. Carrying the
	# cover here lets it be put back on the listitem after the builder has run.
	# setdefault, not assignment: the dedupe below keeps the FIRST cour of a show, so the
	# poster must come from that same one.
	# LOCAL PATCH 2026-09-05: carry AniList's averageScore through to the listitem. It is
	# already in the GraphQL response (_MEDIA_FIELDS has always requested it) and was simply
	# discarded, so this costs nothing extra. TMDb's rating for anime is thin and often
	# missing, while AniList's is the number these rows are actually ranked by.
	# Same setdefault reasoning as covers/tags: the dedupe keeps the FIRST cour of a show.
	# LOCAL PATCH 2026-10-18: kept per position and applied after the dedupe below. setdefault from the worker threads
	# kept whichever cour FINISHED first (a cached one beats a SIMKL lookup), not the cour the dedupe keeps -- a tile
	# labelled Season 2 could carry Season 1's cover, tags and score, differently on each load.
	extras = {}
	def _resolve_worker(position, it):
		try:
			mtype, ids = _resolve_ids(it)
			if not ids: return
			# LOCAL PATCH 2026-10-25: AniList's start date rides along (on a copy: ids is the 168 h resolve cache, and a premiere
			# date moves). TMDb often has no first-air date for an anime that has not started, so the row had no year at all
			# while AniList already names the day; the builders use it only when TMDb has none.
			ids = dict(ids, anilist_start=_start_date(it.get('startDate')))
			resolved[position] = (mtype, ids)
			art = it.get('coverImage') or {}
			cover = art.get('extraLarge') or art.get('large')
			names = anilist_api.anilist_tag_names(it)
			score_str = None
			# averageScore is 0-100 on AniList; anilist.co and MAL both present it out of 10,
			# so divide. Guard on `is not None` rather than truthiness: a genuine 0 is falsy
			# but so is the far more common None for unrated/unaired entries, and only the
			# latter should be skipped.
			score = it.get('averageScore')
			if score is not None:
				try: score_str = '%.1f' % (float(score) / 10.0)
				except Exception: pass
			extras[position] = ('%s_%s' % (mtype, ids.get('tmdb', '')), cover, names, score_str)
		except Exception: kodi_utils.log_row_error('anilist.resolve')
	if items:
		threads = TaskPool().tasks_enumerate(_resolve_worker, items, min(len(items), max_threads()))
		[t.join() for t in threads]

	# LOCAL PATCH 2026-11-01 (cleanup): each kept entry's extras ride beside its ids (show_extras / movie_extras) instead of
	# being copied into covers / tags / scores dicts keyed 'tvshow_<tmdb>'; still taken after the dedupe (the 10-18 rule).
	movies, shows, movie_extras, show_extras = [], [], [], []
	seen_tmdb = {'movie': set(), 'tvshow': set()}
	for position in sorted(resolved):
		mtype, ids = resolved[position]
		tmdb = ids.get('tmdb', '')
		if tmdb and tmdb in seen_tmdb.get(mtype, set()): continue
		extra = extras.get(position, (None, None, None, None))
		if mtype == 'movie':
			movies.append(ids); movie_extras.append(extra); seen_tmdb['movie'].add(tmdb)
		elif mtype == 'tvshow':
			shows.append(ids); show_extras.append(extra); seen_tmdb['tvshow'].add(tmdb)

	# LOCAL PATCH 2026-10-27: the search row keeps watched titles; the browse widgets still follow widget_hide_watched.
	show_watched = 'true' if params.get('mode') == 'anilist.list.build_anilist_search' else 'false'
	tv_list = {'list': [(i, ids) for i, ids in enumerate(shows)], 'id_type': 'trakt_dict', 'custom_order': 'true', 'show_watched': show_watched}
	mv_list = {'list': [(i + len(shows), ids) for i, ids in enumerate(movies)], 'id_type': 'trakt_dict', 'custom_order': 'true', 'show_watched': show_watched}
	item_list = render_mixed(mv_list, tv_list)
	# position -> (key 'tvshow_<tmdb>' / 'movie_<tmdb>', cover, tags, score) of the AniList entry. Both builders key their
	# results on the position handed to them, so this is the only link back from a rendered listitem to its AniList entry.
	by_position = dict(enumerate(show_extras))
	by_position.update((i + len(shows), extra) for i, extra in enumerate(movie_extras))
	from modules.settings import anime_provider
	genre_choice, score_choice = anime_provider('genre'), anime_provider('score')
	for entry, position in item_list:
		key, cover, names, score = by_position.get(position) or (None, None, None, None)
		if not key: continue
		listitem = entry[1]
		# LOCAL PATCH 2026-08-29: swap the TMDb show poster for the AniList cour cover. Only poster/thumb are touched; fanart and
		# clearlogo stay TMDb/fanart.tv, which carry better art than AniList's bannerImage.
		# LOCAL PATCH 2026-09-14: tvshow.poster no longer set here, see the note at _art in indexers/episodes.py.
		if cover:
			try: listitem.setArt({'poster': cover, 'thumb': cover})
			except Exception: pass
		# LOCAL PATCH 2026-08-29: append AniList tags to the row's genres. TMDb genres for anime
		# are near-useless ("Animation, Action & Adventure" on everything); AniList tags say
		# "Female Protagonist", "Episodic", "Time Manipulation". Genres is used rather than a
		# custom property because every skin already displays it, so this needs no skin patch.
		# LOCAL PATCH 2026-10-18: only as the Anime Genres setting says -- this ran after the builders and replaced MyAnimeList
		# genres (and the TMDb choice) with AniList's tags on every AniList list and widget. MAL chosen: the tags stand in only
		# for a show with no MAL genres cached (still better than TMDb's); TMDb chosen: never.
		if names and genre_choice != 'tmdb':
			has_mal_genres = False
			if genre_choice == 'mal' and key.startswith('tvshow_'):
				try: cached = meta_cache.get('tvshow', 'tmdb_id', key[7:]) or {}
				except Exception: cached = {}
				has_mal_genres = bool((cached.get('mal_info') or {}).get('genres'))   # the builder already set them
			if not has_mal_genres:
				try:
					# LOCAL PATCH 2026-10-07: the tags alone, as metadata.display_genres shows them everywhere else
					listitem.getVideoInfoTag().setGenres(list(names))
				except Exception: pass
		# LOCAL PATCH 2026-09-05: expose the AniList score as a listitem property for the skin.
		# A property rather than setRating(): the builders have already set a TMDb rating on
		# these rows, and overwriting it would change sorting and every existing rating chip.
		# This adds a parallel value the AF3 AniList chip reads, leaving TMDb's rating intact.
		# Named to match the extra_*_rating convention in modules/utils.extra_rating_props.
		if score:
			try:
				# LOCAL PATCH 2026-10-18: Anime Score = MyAnimeList keeps the MAL chip alone where it has one
				# (metadata.anime_choice_props took the AniList one off; this put it back)
				if not (score_choice == 'mal' and listitem.getProperty('extra_mal_rating')): listitem.setProperty('extra_anilist_rating', score)
			except Exception: pass
	kodi_utils.add_items(handle, [i[0] for i in item_list])

	if mode_for_next and has_next and not (is_external and widget_hide_next_page()):
		new_page = str(page_no + 1)
		p = dict(params or {})
		p['new_page'] = new_page
		kodi_utils.add_dir(handle, p, 'Next Page (%s) >>' % new_page, 'nextpage', kodi_utils.get_icon('nextpage_landscape'))

	content = 'tvshows' if len(shows) >= len(movies) else 'movies'
	# LOCAL PATCH 2026-09-04: match every other builder's cacheToDisc policy. This called
	# end_directory(handle) with the default cacheToDisc=True even for widget renders, while
	# movies.py:125, tvshows.py:186 and episodes.py:275 all pass False when is_external --
	# i.e. Kodi was writing these AniList pages to its own directory cache on the widget
	# path only here.
	# LOCAL PATCH 2026-09-04: pass `content` and `is_external`, as personal_lists.py:140
	# already does. set_view_mode's signature is (view_type, content='files', is_external=None)
	# and it BLOCKS until container_content() == content -- so passing neither meant it waited
	# for 'files' while this page had just been set to 'tvshows'/'movies'. That never matches,
	# so on a non-widget browse it span its full 3000-iteration timeout (~3 s of 1 ms sleeps)
	# and then returned WITHOUT applying the viewtype. Widgets were unaffected only because
	# is_external short-circuits first. Passing is_external also saves re-deriving it from a
	# Container.PluginName infolabel.
	# NOTE this makes the configured viewtype actually apply to AniList browse pages, which
	# it never did before -- a visible (and intended) change, not just a speed-up.
	# (Both now in media_list_base.finish_dir.)
	finish_dir(handle, content, list_name, is_external, view='view.main')
	return len(item_list)


# ═══════════════════════════════════════════════════════════════════════════
#  Router entry points — one per menu button
# ═══════════════════════════════════════════════════════════════════════════

_BROWSE_METHODS = {
	'airing_this_season':   (anilist_api.anilist_airing_this_season,  'Airing This Season'),
	'airing_next_season':   (anilist_api.anilist_airing_next_season,  'Airing Next Season'),
	'airing_last_season':   (anilist_api.anilist_airing_last_season,  'Airing Last Season'),
	'trending_this_season': (anilist_api.anilist_trending_this_season,'Trending This Season'),
	'trending_this_year':   (anilist_api.anilist_trending_this_year,  'Trending This Year'),
	'trending_all_time':    (anilist_api.anilist_trending_all_time,   'All Time Trending'),
	'popular_this_season':  (anilist_api.anilist_popular_this_season, 'Popular This Season'),
	'popular_this_year':    (anilist_api.anilist_popular_this_year,   'Popular This Year'),
	'popular_all_time':     (anilist_api.anilist_popular_all_time,    'All Time Popular'),
	'top_100':              (anilist_api.anilist_top_100,             'Top 100 Anime'),
	'favourites_all_time':  (anilist_api.anilist_favourites_all_time, 'Most Favorited'),
	# LOCAL PATCH 2026-09-04: periods the engine already had, plus format browse.
	'popular_last_year':    (anilist_api.anilist_popular_last_year,    'Popular Last Year'),
	'trending_last_season': (anilist_api.anilist_trending_last_season, 'Trending Last Season'),
	'anime_movies':         (anilist_api.anilist_movies,               'Anime Movies'),
	'anime_tv_shorts':      (anilist_api.anilist_tv_shorts,            'TV Shorts'),
	'anime_ovas':           (anilist_api.anilist_ovas,                 'OVAs'),
	'anime_onas':           (anilist_api.anilist_onas,                 'ONAs'),
	'anime_specials':       (anilist_api.anilist_specials,             'Specials'),
}


def browse_fetcher(browse_type, genre=None):
	"""(fetcher, list name) for a browse_type. LOCAL PATCH 2026-10-27: browse_type 'genre' + genre is Anime > Genres
	(anilist_api.ANILIST_GENRES); the page prefetch asks here too, so a genre widget's next page warms like the others."""
	if browse_type == 'genre' and genre in anilist_api.ANILIST_GENRES:
		return (lambda page_no: anilist_api.anilist_genre(genre, page_no)), genre
	return _BROWSE_METHODS.get(browse_type, _BROWSE_METHODS['airing_this_season'])


def build_anilist_browse(params):
	"""Router entry: params carry `browse_type` (e.g. 'airing_this_season') + `new_page`.
	Falls back to airing_this_season if browse_type unknown."""
	browse_type = params.get('browse_type', 'airing_this_season')
	page_no = int(params.get('new_page', params.get('page', 1)))
	genre = params.get('genre') if browse_type == 'genre' else None
	fetcher, list_name = browse_fetcher(browse_type, genre)
	page_params = {'mode': 'anilist.list.build_anilist_browse', 'browse_type': browse_type}
	if genre: page_params['genre'] = genre
	# LOCAL PATCH 2026-10-20: new titles build their artwork from TMDb alone and get fanart.tv / TVDB's after the list is
	# shown (metadata._ArtBackfill), as the search lists do. A page of 20 new anime (mode 3: fanart.tv first) made 123
	# requests, 36 of them fanart.tv / TVDB, and the two titles SIMKL resolves ran TMDb -> fanart.tv -> TVDB login ->
	# TVDB artworks one after another (2.5 s) before the other 18 started. The tile poster is AniList's cover anyway.
	from modules.metadata import defer_artwork
	defer_artwork()
	from modules.page_prefetch import page_marks, log_page   # LOCAL PATCH 2026-10-16: ###page timing###
	marks = page_marks()
	try:
		data = fetcher(page_no)
	except Exception:
		data = {'items': [], 'has_next': False, 'page': page_no}
	rows_start = time.time()
	rows = _render(data.get('items') or [], list_name,
			mode_for_next='anilist.list.build_anilist_browse',
			params=page_params,
			page_no=page_no,
			has_next=bool(data.get('has_next')))
	if kodi_utils.external():
		# LOCAL PATCH 2026-10-25 (4.0.5): a widget records its next page for the service to warm later (page_prefetch) --
		# only when the widget shows Next Page at all (Widgets: Hide Next Page off)
		if data.get('has_next') and not widget_hide_next_page():
			from modules.page_prefetch import note_widget_page
			note_widget_page('anilist_browse', dict({'browse_type': browse_type, 'page': page_no + 1}, **({'genre': genre} if genre else {})))
		return
	log_page('anime', 'genre %s' % genre if genre else browse_type, page_no, rows or 0, marks, rows_start)
	# LOCAL PATCH 2026-10-16: warm the next page once this one is on screen, as the TMDb / Trakt catalogues do
	# (modules/page_prefetch.py): a cold AniList page took 5.7-7.1 s, a warm one 0.3-0.5 s
	if data.get('has_next'):
		from modules.page_prefetch import queue
		queue('mixed', 'trakt_dict', lambda: _next_page_ids(fetcher, page_no + 1))


def _next_page_ids(fetcher, page_no):
	"""LOCAL PATCH 2026-10-16: the page prefetch's half of _render -- the AniList page (cached by _cached_page) and each
	entry's TMDb id (cached by _resolve_ids) -- as (media_type, ids) pairs for page_prefetch.run to build the metas of.
	Nothing while AniList has us backing off: one more request then is one more 429."""
	from modules.settings import anime_catalogue_provider
	# LOCAL PATCH 2026-10-22: only when the lists come from AniList (Anime Catalogues) -- MyAnimeList / Kitsu do not care
	if anime_catalogue_provider() == 'anilist' and anilist_api.anilist_score_on_cooldown(): return []
	items = (fetcher(page_no) or {}).get('items') or []
	pairs = {}
	def _one(position, it):
		try:
			mtype, ids = _resolve_ids(it)
			if ids: pairs[position] = (mtype, ids)
		except Exception: pass
	if items: [t.join() for t in TaskPool().tasks_enumerate(_one, items, min(len(items), max_threads()))]
	return [pairs[p] for p in sorted(pairs)]


def build_anilist_search(params):
	"""Wraps anilist_api.anilist_search. Called by the search router when
	media_type=anime_anilist is invoked."""
	query = params.get('query') or params.get('search_query') or ''
	if not query: return
	page_no = int(params.get('new_page', 1))
	# LOCAL PATCH 2026-10-07: AF3's AniList search row asks on every key. AniList allows 30 requests a minute, so a row from
	# the skin waits like the TMDb rows (tmdb_api.search_superseded: empty once the box has moved on) and does not search
	# under SEARCH_MIN_CHARS characters -- 'f', 'fr' would spend two requests on lists nobody reads.
	if kodi_utils.external():
		from apis.tmdb_api import search_superseded, SEARCH_MIN_CHARS
		if len(query.strip()) < SEARCH_MIN_CHARS or search_superseded(query, True):
			return _render([], 'AniList Search: %s' % query, mode_for_next='anilist.list.build_anilist_search',
					params={'mode': 'anilist.list.build_anilist_search', 'query': query}, page_no=page_no, has_next=False)
	try:
		data = anilist_api.anilist_search(query, page_no)
	except Exception:
		data = {'items': [], 'has_next': False, 'page': page_no}
	_render(data.get('items') or [], 'AniList Search: %s' % query,
			mode_for_next='anilist.list.build_anilist_search',
			params={'mode': 'anilist.list.build_anilist_search', 'query': query},
			page_no=page_no,
			has_next=bool(data.get('has_next')))


# ═══════════════════════════════════════════════════════════════════════════
#  Watchlist (LOCAL PATCH 2026-08-29)
#
#  Lives here rather than in its own module so it reuses _render / _resolve_ids /
#  _SEASON_SUFFIX_RE untouched. That suffix regex is the reason: AniList entries are
#  per-cour ("Sousou no Frieren 2nd Season") while TMDb groups cours under one show, and
#  a second copy of that resolver would drift from this one.
#
#  MediaListCollection returns the whole list in one response -- no paging, unlike the
#  browse queries -- so page is always 1 and has_next always False.
# ═══════════════════════════════════════════════════════════════════════════

_WATCHLIST_STATUSES = {
	'watching':   ('CURRENT',   'Watching'),
	'planning':   ('PLANNING',  'Plan to Watch'),
	'completed':  ('COMPLETED', 'Completed'),
	'paused':     ('PAUSED',    'On Hold'),
	'dropped':    ('DROPPED',   'Dropped'),
	'repeating':  ('REPEATING', 'Rewatching'),
}


def build_anilist_watchlist(params):
	"""Router entry: params carry `status` ('watching', 'planning', ...)."""
	from apis.anilist_api import anilist_media_list, anilist_user_active
	from caches.anilist_cache import anilist_cache_object
	if not anilist_user_active():
		return kodi_utils.notification('AniList not authorized', 4000)
	status_key = params.get('status', 'watching')
	api_status, list_name = _WATCHLIST_STATUSES.get(status_key, _WATCHLIST_STATUSES['watching'])
	try:
		items = anilist_cache_object(anilist_media_list, status_key, api_status) or []
	except Exception:
		items = []
	_render(items, 'AniList: %s' % list_name,
			mode_for_next='anilist.list.build_anilist_watchlist',
			params={'mode': 'anilist.list.build_anilist_watchlist', 'status': status_key},
			page_no=1,
			has_next=False)


# ═══════════════════════════════════════════════════════════════════════════
#  Watch order (LOCAL PATCH 2026-10-27)
#
#  The 'Watch Order' context-menu entry on an anime show: anilist_api.anilist_watch_order's steps for the franchise,
#  numbered, with what is optional / recap / side story / the film version / not out yet marked. A TV step opens its
#  TMDb season (Fribb), a film plays like any movie, an entry Fribb has no TMDb id for is listed for reference.
# ═══════════════════════════════════════════════════════════════════════════

_WO_FORMAT_NAMES = {'TV': 'TV', 'TV_SHORT': 'Short', 'MOVIE': 'Film', 'OVA': 'OVA', 'ONA': 'ONA', 'SPECIAL': 'Special'}
_WO_KIND_NOTES = {'alternative': 'or watch this instead', 'recap': 'recap, skippable', 'side story': 'side story, optional',
				'optional': 'optional', 'upcoming': 'not released yet'}


def _watch_order_seed(tmdb_id):
	"""The AniList id to walk from for a TMDb show: its first season's Fribb row."""
	rows = [r for r in fribb_mappings.tmdb_tv_to_fribb_rows(tmdb_id) if r.get('anilist_id')]
	if not rows: return None
	season = lambda r: (r.get('season') or {}).get('tmdb')
	return min(rows, key=lambda r: (season(r) if isinstance(season(r), int) and season(r) > 0 else 99, r['anilist_id']))['anilist_id']


def _watch_order_film_seed(tmdb_id, imdb_id=None):
	"""LOCAL PATCH 2026-10-31: the AniList id of an anime FILM: its Fribb row, else ani.zip by the row's AniDB id (Fribb's film
	rows often carry no anilist_id -- the scraper recovers it the same way, scrapers/external.py)."""
	if not tmdb_id: return None
	ids = fribb_mappings.query_ids_for_tmdb_movie(tmdb_id, imdb_id if str(imdb_id or '').startswith('tt') else None) or {}
	if ids.get('anilist_id'): return ids['anilist_id']
	if ids.get('anidb_id'):
		try:
			from caches.anizip_mappings import anizip_episode_ids
			found = (anizip_episode_ids(None, cour_episode=1, anidb_id=ids['anidb_id']) or {}).get('anilist')
			if found: return found
		except Exception: pass
	return _watch_order_film_by_title(tmdb_id)

_WO_FILM_QUERY = 'query ($q: String) { Page(perPage: 10) { media(search: $q, type: ANIME, format: MOVIE) { id startDate { year month day } } } }'

def _watch_order_film_by_title(tmdb_id):
	"""LOCAL PATCH 2026-10-31: a film Fribb has no row for yet (Made in Abyss: Mezameru Shinpi, TMDb 1526917, out 2026-10-23;
	AniList 160275) -- AniList MOVIE entries found by TMDb's title, then the original. Taken only when ONE candidate starts
	in TMDb's release year (+-1), or when several do, the one starting within 45 days of it; anything else is no answer, so
	a franchise's other films never stand in. Cached 24 h, the miss too."""
	from caches.main_cache import main_cache
	key = 'anilist_wo_film_%s' % tmdb_id
	cached = main_cache.get(key)
	if cached is not None: return cached or None
	from modules.metadata import cached_meta, movie_meta
	from modules.settings import tmdb_api_key, mpaa_region
	from modules.utils import get_datetime
	meta = cached_meta('movie', tmdb_id)
	if not meta:
		try: meta = movie_meta('tmdb_id', tmdb_id, tmdb_api_key(), mpaa_region(), get_datetime())
		except Exception: meta = None
	# Not strptime: Kodi's embedded Python breaks it on worker threads (see anilist_api.anilist_for_tmdb_season)
	import datetime
	try: tmdb_day = datetime.date(*(int(p) for p in str((meta or {}).get('premiered') or '')[:10].split('-')))
	except Exception: return None
	found = None
	for title in dict.fromkeys(t for t in ((meta or {}).get('title'), (meta or {}).get('original_title')) if t):
		res = anilist_api._post_anilist(_WO_FILM_QUERY, {'q': title})
		if res is None: return None   # no answer: not cached
		cands = [m for m in res.get('media') or [] if (m.get('startDate') or {}).get('year') and abs(m['startDate']['year'] - tmdb_day.year) <= 1]
		if len(cands) > 1:
			def days(m):
				d = m['startDate']
				try: return abs((datetime.date(d['year'], d.get('month') or 1, d.get('day') or 1) - tmdb_day).days)
				except Exception: return 9999
			cands = [m for m in cands if days(m) <= 45]
		if len(cands) == 1:
			found = cands[0]['id']
			break
	main_cache.set(key, found or 0, expiration=24)
	return found

# LOCAL PATCH 2026-11-01: the steps as plain rows, shared by the Watch Order window (windows/watch_order.py, opened by
# dialogs.watch_order_choice from the context menu) and the folder below (kept for any saved link to the old mode).
# AniList list status per step rides along when an AniList account is signed in (one request, anilist_media_list_all).
_WO_STATUS = {'COMPLETED': 'done', 'CURRENT': 'partial', 'REPEATING': 'partial', 'PAUSED': 'partial', 'PLANNING': 'planned',
			'DROPPED': 'dropped'}

def _cour_place(tmdb_id, season, anilist_id, episodes, step_ids=()):
	"""(TMDb season, (first, last) episode or None) where this AniList entry really sits, from fribb_mappings' REPAIRED cour
	rows: the starts are corrected (Fribb's raw [0, 24, 36, 50] for Tokyo Revengers is [0, 24, 37, 50]) and an entry Fribb files
	under a season TMDb does not have is found where the repair placed it (JUJUTSU KAISEN Season 2: Fribb 'season 2', TMDb has
	only Season 1, the repair puts it at Season 1 e25-47 -- the link opened an empty Season 2). The span only for a season
	holding more than one cour; Fribb's season is tried first, then the show's other TMDb seasons. (season, False) when the
	entry is in none of them: a season announced but not aired (Frieren 3rd Season) -- the caller lists it as announced
	instead of opening the whole of Fribb's season."""
	try: seasons = fribb_mappings._tmdb_season_numbers(int(tmdb_id)) or set()
	except Exception: seasons = set()
	order = [season] + sorted(x for x in seasons if x and x != season)
	for s in order:
		if seasons and s not in seasons: continue
		try: cours = fribb_mappings._season_cour_rows(int(tmdb_id), int(s))
		except Exception: continue
		for i, (offset, row) in enumerate(cours):
			if str(row.get('anilist_id')) != str(anilist_id): continue
			if len(cours) < 2: return s, None
			# ends where the next cour starts: AniList counts an episode 0 that TMDb files under Specials (Mushoku Tensei
			# Season 2: 13 on AniList, 12 here), which overlapped the next step by one
			# only a cour that is ANOTHER STEP ends this one: TMDb / MAL split STONE OCEAN Part 2 into two cours (the second has
			# no AniList id -- AniList keeps one 26-episode entry), and stopping there left episodes 25-38 unreachable
			following = next((o for o, r in cours[i + 1:] if str(r.get('anilist_id')) in step_ids), None) if step_ids else 				(cours[i + 1][0] if i + 1 < len(cours) else None)
			end = offset + int(episodes) if episodes else following
			if end and following: end = min(end, following)
			# no end: the last cour with no episode count -- Fribb files an announced season after TMDb's last episode
			# (Frieren 3rd Season at e39 of 38); opening the whole season would be wrong, so it counts as not placed
			return s, ((offset + 1, end) if end and end > offset else False)
	return season, False

def _wo_date(value):
	import datetime
	try: return datetime.date(*(int(p) for p in str(value)[:10].split('-')))
	except Exception: return None

def _season0_run(show, step):
	"""(first, last) of the TMDb season-0 episodes that are this step, or None: the episodes aired within 3 days of its
	AniList start, its episode count from the first; one under half AniList's length is passed over (Re:ZERO's 3-minute
	'Manner Movie' clips aired the day of its hour-long OVAs). Shared by the Watch Order window (_special_place) and the
	player's AniList / MAL push for a special (special_entry_for_episode)."""
	import datetime
	try: start = datetime.date(*(int(x) for x in step['date'][:3]))
	except Exception: return None
	from modules.metadata import tvshow_meta, episodes_meta
	from modules import settings
	try:
		meta = tvshow_meta('tmdb_id', show, settings.tmdb_api_key(), settings.mpaa_region(), datetime.date.today().isoformat())
		eps = sorted((e for e in (episodes_meta(0, meta) or []) if e.get('episode')), key=lambda e: e['episode'])
	except Exception: return None
	al_seconds = (step.get('duration') or 0) * 60
	def fits(e):
		aired = _wo_date(e.get('premiered'))
		if not aired or abs((aired - start).days) > 3: return False
		return not (al_seconds and e.get('duration') and e['duration'] < al_seconds / 2)
	hits = [i for i, e in enumerate(eps) if fits(e)]
	if not hits: return None
	run = eps[hits[0]:hits[0] + max(1, int(step.get('episodes') or 1))]
	return run[0]['episode'], run[-1]['episode']


def special_entry_for_episode(tmdb_id, episode):
	"""LOCAL PATCH 2026-11-01: {'anilist', 'mal', 'cour_ep', 'via'} for a TMDb SPECIAL (season 0) just watched, or {}. Fribb
	maps no special to AniList, so a finished special never reached AniList / MAL (Attack on Titan S0E37, 2026-11-01). The
	Watch Order's own mapping in reverse: the franchise's OVA / ONA / special / short step whose season-0 run holds this
	episode (_season0_run), and the episode's place in it. TV and film steps are not asked: a season premiere can air the
	day a special does."""
	try: episode = int(episode)
	except (TypeError, ValueError): return {}
	seed = _watch_order_seed(tmdb_id)
	if not seed: return {}
	for step in anilist_api.anilist_watch_order(seed) or []:
		if step.get('format') not in ('OVA', 'ONA', 'SPECIAL', 'TV_SHORT') or step.get('kind') == 'upcoming': continue
		span = _season0_run(tmdb_id, step)
		if span and span[0] <= episode <= span[1]:
			mal = (fribb_mappings.anilist_to_fribb(step['id']) or {}).get('mal_id')
			return {'anilist': step['id'], 'mal': mal, 'cour_ep': episode - span[0] + 1, 'via': 'watch order special'}
	return {}


_WO_MONTHS = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')

def _expected(date):
	"""'expected Oct 2027' / 'expected 2027' / 'date not announced' from AniList's [year, month, day]."""
	year, month = (list(date or []) + [None, None])[:2]
	if not year: return 'date not announced'
	return 'expected %s%s' % ('%s ' % _WO_MONTHS[month - 1] if month and 1 <= month <= 12 else '', year)

def _special_place(shows, step, key):
	"""LOCAL PATCH 2026-11-01: (url, action, where, open label) for a special / OVA / short / recap film step that Fribb maps
	to TMDb's whole Specials list or not at all -- a click opened 90 Re:ZERO specials, or an AniList search that only found
	the show. By AniList's start date, the one fact AniList, TMDb and Fribb agree on:
	  A. season 0 of the franchise's TMDb show(s): the episodes aired within 3 days of it, the step's episode count from the
	     first (Attack on Titan OVA = Specials 7-9, LINK CLICK Episode 5.5 = Special 1). An episode under half AniList's
	     length is passed over: Re:ZERO's 3-minute 'Manner Movie' clips aired the day of its hour-long OVAs.
	  B. a TMDb FILM by the step's title, released within 45 days (Attack on Titan's recap films, JUJUTSU KAISEN: Execution).
	None when neither: the step stays as it was. harness/watch_order_specials_probe.py: 19 of 21 found."""
	import datetime
	try: start = datetime.date(*(int(x) for x in step['date'][:3]))
	except Exception: return None
	for show in shows:
		span = _season0_run(show, step)
		if not span: continue
		first, last = span
		url = kodi_utils.build_url({'mode': 'build_episode_list', 'tmdb_id': show, 'season': 0, 'cour_offset': first - 1,
			'cour_len': last - first + 1, 'cour_title': step['title'], 'cour_poster': step.get('cover') or ''})
		where = 'Special %d' % first if first == last else 'Specials %d–%d' % (first, last)
		return url, 'folder', where, 'Open ' + where
	for title in dict.fromkeys(t for t in (step.get('title'), step.get('english'), step.get('romaji')) if t):
		try: results = (tmdb_movies_search(title, 1) or {}).get('results') or []
		except Exception: continue
		near = [(abs((_wo_date(m.get('release_date')) - start).days), m) for m in results if _wo_date(m.get('release_date'))]
		near = sorted((d, m['id']) for d, m in near if d <= 45)
		if near:
			film = near[0][1]
			return kodi_utils.build_url({'mode': 'playback.%s' % key, 'media_type': 'movie', 'tmdb_id': film, key: key}), 'play', 'TMDb film', None
	return None

def watch_order_rows(params):
	"""(seed AniList id, [row]) for params tmdb_id / media_type / imdb_id / anilist_id. A row: number, title, kind, note,
	facts, where, url (a plugin url), action ('folder' / 'play' / 'search'), anilist_id, mal_id, cover, fanart, landscape,
	clearlogo, status ('done' / 'partial' / 'planned' / 'dropped' / '' = not on the list / None = no account), progress."""
	tmdb_id = params.get('tmdb_id')
	if params.get('media_type') == 'movie': seed = _watch_order_film_seed(tmdb_id, params.get('imdb_id'))   # LOCAL PATCH 2026-10-31
	else: seed = _watch_order_seed(tmdb_id) if tmdb_id else None
	anilist_id = params.get('anilist_id') or seed
	steps = anilist_api.anilist_watch_order(anilist_id) if anilist_id else []
	if not steps:
		kodi_utils.notification('No watch order found' if anilist_id else 'Not on AniList (no Fribb mapping)', 3000)
		return anilist_id, []
	from modules.settings import playback_key
	from modules.metadata import cached_meta
	key = playback_key()
	on_list = None
	if anilist_api.anilist_user_active():
		try: on_list = anilist_api.anilist_media_list_all() or {}
		except Exception: on_list = None
	rows, step_ids, shows = [], {str(x['id']) for x in steps}, [str(tmdb_id)] if tmdb_id and params.get('media_type') != 'movie' else []
	for s in steps:
		open_label = None
		row = fribb_mappings.anilist_to_fribb(s['id'])
		is_movie = s['format'] == 'MOVIE'
		tmdb = fribb_mappings._row_tmdb(row, want_movie=is_movie) if row else None
		# LOCAL PATCH 2026-10-31: opened from a film Fribb has no row for, that film's own step is the TMDb film we came from
		if not tmdb and is_movie and params.get('media_type') == 'movie' and str(s['id']) == str(anilist_id): tmdb = tmdb_id
		season = (row.get('season') or {}).get('tmdb') if row and not is_movie else None
		span = None
		# LOCAL PATCH 2026-11-01: a series step Fribb gives no TMDb id (STEEL BALL RUN 2nd & 3rd STAGE: MAL 61469 is shared with
		# 1st STAGE, so its row has none) -- looked for in the franchise's own show(s), where the repair may have placed it
		if not tmdb and not is_movie:
			for show in shows:
				place, place_span = _cour_place(show, None, s['id'], s['episodes'], step_ids)
				if place is not None and place_span is not False: tmdb, season, span = show, place, place_span; break
		elif tmdb and isinstance(season, int) and season > 0:
			season, span = _cour_place(tmdb, season, s['id'], s['episodes'], step_ids)
			if span is False: tmdb = None   # announced, not placed in any TMDb season yet: listed below as announced
		if tmdb and not is_movie and str(tmdb) not in shows: shows.append(str(tmdb))
		if tmdb and is_movie:
			url, action, where = kodi_utils.build_url({'mode': 'playback.%s' % key, 'media_type': 'movie', 'tmdb_id': tmdb, key: key}), 'play', 'TMDb film'
		elif tmdb and isinstance(season, int):
			# LOCAL PATCH 2026-11-01: the season and episodes this step REALLY is (_cour_place above: repaired cour rows) -- one
			# TMDb season holding several cours read 'Season 1' on every step, and a season TMDb lacks opened an empty list
			url, action = kodi_utils.build_url({'mode': 'build_episode_list', 'tmdb_id': tmdb, 'season': season}), 'folder'
			where = 'Season %s' % season if season else 'Specials'
			if span:
				where, open_label = '%s · eps %d–%d' % (where, span[0], span[1]), 'Open Episodes %d–%d' % span
				# the cour's own slice of the season, as the season list's cour rows link it (seasons.py): only these
				# episodes, titled after the step, so the list's first-unwatched focus lands inside this step
				url = kodi_utils.build_url({'mode': 'build_episode_list', 'tmdb_id': tmdb, 'season': season, 'cour_offset': span[0] - 1,
					'cour_len': span[1] - span[0] + 1, 'cour_title': s['title'], 'cour_poster': s.get('cover') or ''})
		elif tmdb:
			url, action, where = kodi_utils.build_url({'mode': 'build_season_list', 'tmdb_id': tmdb}), 'folder', 'all seasons'
		else:
			url, action = kodi_utils.build_url({'mode': 'anilist.list.build_anilist_search', 'query': s['title']}), 'search'
			where = 'announced' if s['kind'] == 'upcoming' or span is False else 'not on TMDb yet'   # LOCAL PATCH 2026-10-31 / 11-01
		# LOCAL PATCH 2026-11-01: a special that would open the whole Specials list or an AniList search: its own specials or film
		if s['kind'] != 'upcoming' and span is not False and (action == 'search' or (action == 'folder' and season == 0)):
			found = _special_place(shows, s, key)
			if found: url, action, where, open_label = found
		# LOCAL PATCH 2026-11-01: announced, nothing to open yet -- 'plan' (the window's Plan to Watch puts it on the list) and
		# the date AniList expects, instead of a search that only found the show. The url stays the search (folder view).
		if action == 'search' and (s['kind'] == 'upcoming' or span is False):
			action, where = 'plan', _expected(s['date'])
		year = s['date'][0] or 'TBA'
		fmt = _WO_FORMAT_NAMES.get(s['format'], s['format'])
		eps = '%s eps' % s['episodes'] if s['episodes'] and s['format'] != 'MOVIE' else None
		facts = ' · '.join(str(x) for x in (fmt, eps, year, where) if x)
		# LOCAL PATCH 2026-10-31: TMDb's fanart / landscape when the show or film is in the meta cache (no request), else
		# AniList's banner; an entry with neither (a sequel just announced) takes the franchise's, filled in after the loop.
		meta = cached_meta('movie' if is_movie else 'tvshow', tmdb) if tmdb else None
		wide = (meta or {}).get('fanart') or s.get('banner') or ''
		entry = (on_list or {}).get(int(s['id'])) if on_list is not None else None
		status = None if on_list is None else _WO_STATUS.get((entry or {}).get('status'), '')
		rows.append({'number': s['number'], 'title': s['title'], 'kind': s['kind'], 'note': _WO_KIND_NOTES.get(s['kind']) or '',
			'facts': facts, 'short_facts': ' · '.join(str(x) for x in (fmt, eps, year) if x), 'where': where, 'url': url, 'action': action,
			'anilist_id': s['id'], 'mal_id': (row or {}).get('mal_id'), 'cover': s.get('cover') or '', 'fanart': wide,
			'landscape': (meta or {}).get('landscape') or wide, 'clearlogo': (meta or {}).get('clearlogo') or '',
			'status': status, 'progress': (entry or {}).get('progress') or 0, 'episodes': s['episodes'] or 0, 'open_label': open_label})
	franchise = next((r for r in rows if r['fanart']), None)
	if franchise:
		for r in rows:
			if not r['fanart']: r['fanart'], r['landscape'] = franchise['fanart'], franchise['landscape']
			if not r['clearlogo']: r['clearlogo'] = franchise['clearlogo']
	return anilist_id, rows


def next_step_index(rows):
	"""The row the Watch Order window opens on: where the user should carry on.

	rows are in watch order; each has 'kind' ('main', 'alternative', 'recap', 'side story', 'optional', 'upcoming'),
	'number' (0 for an alternative), 'status' ('done' / 'partial' / 'planned' / 'dropped' / '' not on the list /
	None when no AniList account is signed in), 'progress' (episodes watched) and 'episodes' (0 = unknown).
	Return an index into rows (0 when there is nothing better)."""
	# TODO(user): decide what "next to watch" means -- see the request in the session.
	return 0


def build_anilist_watch_order(params):
	"""The folder version (LOCAL PATCH 2026-10-27); the context menu now opens the window (dialogs.watch_order_choice)."""
	handle = int(sys.argv[1])
	title = params.get('title') or 'Anime'
	_seed, rows = watch_order_rows(params)
	fanart = kodi_utils.get_addon_fanart()
	items = []
	for r in rows:
		if r['kind'] == 'alternative': label = '      or: %s' % r['title']
		elif r['number']: label = '%d.  %s' % (r['number'], r['title'])
		else: label = '      %s' % r['title']
		if r['note']: label += '  [COLOR FF8E8E93]· %s[/COLOR]' % r['note']
		listitem = kodi_utils.make_listitem()
		listitem.setLabel(label)
		listitem.setLabel2(r['facts'])
		art = {'poster': r['cover'], 'thumb': r['cover'], 'icon': r['cover'], 'fanart': r['fanart'] or fanart, 'landscape': r['landscape']}
		if r['clearlogo']: art['clearlogo'] = r['clearlogo']
		listitem.setArt(art)
		info_tag = listitem.getVideoInfoTag(True)
		info_tag.setTitle(r['title'])
		info_tag.setPlot(r['facts'] + ('\n%s' % r['note'].capitalize() if r['note'] else ''))
		is_folder = r['action'] != 'play'
		if not is_folder: listitem.setProperty('IsPlayable', 'false')
		items.append((r['url'], listitem, is_folder))
	kodi_utils.add_items(handle, items)
	kodi_utils.set_content(handle, 'videos')
	kodi_utils.set_category(handle, 'Watch Order: %s' % title)
	kodi_utils.end_directory(handle, cacheToDisc=False)
	kodi_utils.set_view_mode('view.main', 'videos')
