# -*- coding: utf-8 -*-
# LOCAL PATCH (2026-06-12): Port of HDHub + HDHub4u scrapers from plugin.video.tmdbmovies
# (Angelitto). This is a near-verbatim copy of the relevant functions; the only
# adaptations are at the top (imports + log shim) so the rest of the code stays close
# to upstream for easy re-pulls.
#
# Upstream source: plugin.video.tmdbmovies/resources/lib/scraper.py (Angelitto)
# Public entry points used by http_streams.py wrapper:
#   - _scrape_json_provider(base_url, pattern, label, imdb_id, content_type, season, episode, ...)
#   - _identify_host_from_url(url)
#
# LOCAL PATCH 2026-11-01 (cleanup): TRIMMED to what DeadLight uses -- the two entry points above and what they call
# (_extract_quality_from_string, get_headers, get_random_ua, log). The HubCloud / GDFlix / FilesDL / BuzzServer resolvers,
# the m3u8 / quality helpers, the sessions and the ADDON settings shim were never called and are gone (1961 -> 381
# lines). Re-extract a function from upstream scraper.py when it is needed again; do not hand-edit the upstream code.

import requests
import xbmc
import re
from urllib.parse import urlparse
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)   # _scrape_json_provider asks with verify=False

# ----- Adaptation shims (DeadLight side) -----

def log(msg, level=None):
    try: xbmc.log('DeadLight [http_streams]: %s' % str(msg), xbmc.LOGINFO)
    except: pass

# ----- End shims -----

def get_random_ua():
    return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0'

def get_headers():
    """Shim for tmdbmovies/config.get_headers — default JSON request headers."""
    return {
        'User-Agent': get_random_ua(),
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Connection': 'keep-alive',
    }

# =============================================================================
# _extract_quality_from_string  (from scraper.py:1917-2010)
# =============================================================================

def _extract_quality_from_string(text):
    """
    Extrage calitatea video dintr-un string.
    """
    if not text:
        return None
    
    t = text.lower()

    
    # === ADAUGARE NOUĂ: Detectare Multi-Rezoluție (pentru link-uri generice) ===
    clean_t = t.replace('ds4k', '').replace('hdr4k', '').replace('sdr4k', '').replace('4khdhub', '')
    res_count = sum(1 for r in ['2160p', '1080p', '720p', '480p', '360p'] if r in t)
    if re.search(r'(?:^|[\.\-\s_])4k(?:$|[\.\-\s_])', clean_t) and '2160p' not in t: 
        res_count += 1
    
    if res_count >= 2:
        # log(f"[QUALITY] Multi-resolution detected -> forcing SD")
        return 'SD'
    # =======================================================================
    
    # =================================================================
    # METODA 1 (PRIORITARĂ): Caută AN.CALITATE sau AN-CALITATE
    # Exemplu: "2025.720p" sau "2025-1080p" sau "2025.4K"
    # =================================================================
    
    # Captează ce vine IMEDIAT după an (primul segment)
    after_year_match = re.search(r'(?:19|20)\d{2}[\.\-\s_]+([^\.\-\s_]+)', t)
    if after_year_match:
        first_segment = after_year_match.group(1).lower()
        
        # Verifică calități standard
        if first_segment.startswith('2160p'):
            # log(f"[QUALITY] Found 2160p after year -> 4K")
            return '4K'
        if first_segment.startswith('1080p'):
            # log(f"[QUALITY] Found 1080p after year")
            return '1080p'
        if first_segment.startswith('720p'):
            # log(f"[QUALITY] Found 720p after year")
            return '720p'
        if first_segment.startswith('480p'):
            # log(f"[QUALITY] Found 480p after year")
            return '480p'
        if first_segment.startswith('360p'):
            # log(f"[QUALITY] Found 360p after year")
            return '360p'
        # 4K trebuie să fie EXACT "4k" la început, nu parte din alt cuvânt
        if first_segment == '4k' or first_segment.startswith('4k-') or first_segment.startswith('4k.'):
            # log(f"[QUALITY] Found 4K after year")
            return '4K'
    
    # =================================================================
    # METODA 2 (FALLBACK): Caută oriunde în text
    # IMPORTANT: 720p și 1080p au PRIORITATE față de 4K!
    # =================================================================
    
    # Verifică calitățile numerice ÎN ORDINE DE PRIORITATE
    # (evităm să găsim 4K din DS4K înainte de 720p real)
    if '720p' in t:
        # log(f"[QUALITY] Fallback: found 720p in text")
        return '720p'
    
    if '1080p' in t:
        # log(f"[QUALITY] Fallback: found 1080p in text")
        return '1080p'
    
    if '2160p' in t:
        # log(f"[QUALITY] Fallback: found 2160p in text -> 4K")
        return '4K'
    
    if '480p' in t:
        # log(f"[QUALITY] Fallback: found 480p in text")
        return '480p'
    
    if '360p' in t:
        # log(f"[QUALITY] Fallback: found 360p in text")
        return '360p'
    
    # 4K DOAR dacă nu e precedat de literă (evită DS4K, HDR4K, SDR4K)
    # Pattern: spațiu/punct/început + 4k + non-literă
    if re.search(r'(?:^|[\.\-\s_])4k(?:$|[\.\-\s_])', t):
        # log(f"[QUALITY] Fallback: found standalone 4K")
        return '4K'
    
    # UHD = 4K
    if 'uhd' in t or 'ultrahd' in t:
        # log(f"[QUALITY] Fallback: found UHD -> 4K")r
        return '4K'
    
    # log(f"[QUALITY] No quality found in: {t[:50]}")
    return None




# =============================================================================
# _identify_host_from_url  (from scraper.py:2035-2124)
# =============================================================================

def _identify_host_from_url(url):
    """Identifică numele host-ului din URL - VERSIUNE V3 cu TrashBytes și altele."""
    if not url:
        return 'Direct'
    
    url_lower = url.lower()
    
    # Ordinea contează - cele mai specifice primele!
    if 'pixeldrain.dev/api/file' in url_lower or 'pixeldrain.com/api/file' in url_lower:
        return 'PixelDrain'
    elif 'pixel.hubcdn' in url_lower:
        return 'HubPixel (10Gbps)'
    elif 'yummy.monster' in url_lower:
        return 'FSL Server'
    elif 'trashbytes.net' in url_lower:
        return 'TrashBytes'
    elif 'awsdllaaa' in url_lower or 'aws-storage' in url_lower:
        return 'FastCloud'
    elif 'bbdownload.filesdl' in url_lower:
        if 'adl.php' in url_lower:
            return 'FastCloud-02'
        elif 'fdownload.php' in url_lower:
            return 'DirectDL'
        else:
            return 'FilesDL'
    elif 'busycdn' in url_lower or 'instant.busycdn' in url_lower:
        return 'InstantDL'
    elif 'r2.cloudflarestorage.com' in url_lower:
        return 'FSL-V2'
    elif 'r2.dev' in url_lower or 'pub-' in url_lower:
        return 'CloudR2'
    elif 'gpdl' in url_lower and 'hubcdn' in url_lower:
        return 'HubCDN'
    elif 'fsl-lover' in url_lower:
        return 'FSL-Lover'
    elif 'fsl-buckets' in url_lower or 'fsl.gdboka' in url_lower:
        return 'CDN'
    elif 'gdboka' in url_lower:
        return 'FastServer'
    elif 'polgen.buzz' in url_lower:
        return 'Flash'
    elif 'workers.dev' in url_lower:
        return 'CFWorker'
    elif 'hubcdn' in url_lower:
        return 'HubCDN'
    elif 'hubcloud' in url_lower:
        return 'HubCloud'
    elif 'gdflix' in url_lower:
        return 'GDFlix'
    elif 'filesdl' in url_lower:
        return 'FilesDL'
    elif 'gofile' in url_lower:
        return 'GoFile'
    elif 'mediafire' in url_lower:
        return 'MediaFire'
    elif 'mega.nz' in url_lower or 'mega.co' in url_lower:
        return 'MEGA'
    elif 'streamtape' in url_lower:
        return 'StreamTape'
    elif 'doodstream' in url_lower or 'dood.' in url_lower:
        return 'DoodStream'
    elif 'mixdrop' in url_lower:
        return 'MixDrop'
    elif 'upstream' in url_lower:
        return 'UpStream'
    elif 'buzzheavie' in url_lower:
        return 'BuzzHeavie'
    elif 'bzzhr' in url_lower:
        return 'BuzzShort'
    elif 'buzzserver' in url_lower:
        return 'BuzzServer'
    else:
        # Încearcă să extragă din domeniu
        try:
            parsed = urlparse(url)
            domain = parsed.netloc.lower().replace('www.', '')
            parts = domain.split('.')
            if parts and len(parts[0]) >= 2:
                # Capitalizează prima literă
                return parts[0].title()
        except:
            pass
        
        return 'Direct'



# =============================================================================
# _scrape_json_provider  (from scraper.py:4344-4464)
# =============================================================================

_AUTO_QUALITY = re.compile(r'(?<![A-Za-z])Auto(?![A-Za-z])')

def _scrape_json_provider(base_url, pattern, label, imdb_id, content_type, season, episode, title_query=None, year_query=None):
    """
    Helper pentru providerii JSON (StreamVix, Vidzee, Webstreamr, MeowTV).
    FIX: Extrage calitatea din name/title/description și folosește titlul fallback.
    """
    local_streams = []
    
    timeout = 12
    
    try:
        if content_type == 'movie':
            api_url = f"{base_url}/stream/movie/{imdb_id}.json" if pattern == 'stream' else f"{base_url}/movie/{imdb_id}.json"
        else:
            api_url = f"{base_url}/stream/series/{imdb_id}:{season}:{episode}.json" if pattern == 'stream' else f"{base_url}/series/{imdb_id}:{season}:{episode}.json"

        r = requests.get(api_url, headers=get_headers(), timeout=timeout, verify=False)
        r.raise_for_status()

        server_date = r.headers.get('Date')

        if r.status_code == 200:
            data = r.json()
            if 'streams' in data:
                # LOCAL PATCH 2026-06-15: don't attach Referer/Origin pointing at
                # the aggregator (hdhub.thevolecitor.qzz.io). Stream URLs returned
                # by the aggregator are pre-signed CDN URLs (cdn.fsl-buckets.work
                # etc.) that authenticate via ?token=... query params. Sending an
                # aggregator-domain Referer causes the CDN to 404 the request.
                # AIOStreams scraper sends no custom headers and plays fine; mirror
                # that behavior here so Kodi just makes a plain GET.
                ref = None
                origin = None

                for s in data['streams']:
                    url = s.get('url', '')
                    if not url: continue

                    # =====================================================
                    # FIX 1: OCOLIM CLOUDFLARE EXTRĂGÂND URL-UL DIRECT (M3U8)
                    # =====================================================
                    import urllib.parse
                    if 'meowserver' in url and 'url=' in url:
                        try:
                            parsed_qs = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
                            if 'url' in parsed_qs:
                                url = parsed_qs['url'][0]
                        except:
                            pass
                    
                    raw_name = s.get('name', '')
                    raw_title = s.get('title', '')
                    description = s.get('description', '')

                    # =====================================================
                    # FIX 2: IGNORĂM CALITATEA "AUTO" PENTRU A EVITA DEDUPLICAREA GRESITĂ A 1080P
                    # =====================================================
                    # LOCAL PATCH 2026-10-15: the WORD 'Auto' (the HLS quality), not the substring -- the description
                    # carries the release filename, so 'The Autopsy of Jane Doe' / 'Automata' / 'Autograph' lost every row.
                    if _AUTO_QUALITY.search(raw_name) or _AUTO_QUALITY.search(description):
                        continue

                    # =====================================================
                    # EXTRAGERE FILENAME ORIGINAL (Din description pt Volecitor/etc)
                    # =====================================================
                    if description:
                        first_line = description.split('\n')[0].strip()
                        # Verificăm strict dacă pe prima linie există o extensie video
                        if re.search(r'(\.mkv|\.mp4|\.avi|\.ts|\.webm)', first_line, re.IGNORECASE):
                            # Eliminăm doar parantezele pătrate de la început (ex: [10Gbps] [💾 9.58 GB])
                            clean_filename = re.sub(r'^(\[[^\]]+\]\s*)+', '', first_line).strip()
                            if clean_filename:
                                raw_title = clean_filename
                    
                    # APLICARE TITLU FALLBACK (Dacă nu s-a extras niciun fișier video și raw_title e gol)
                    if not raw_title and title_query:
                        if label == 'MeowTV':
                            base_name = f"{title_query} ({year_query})" if year_query else title_query
                            if content_type == 'tv' and season and episode:
                                raw_title = f"{base_name} S{int(season):02d}E{int(episode):02d}"
                            else:
                                raw_title = f"{base_name}"
                        else:
                            if content_type == 'tv' and season and episode:
                                raw_title = f"{title_query} S{int(season):02d}E{int(episode):02d}"
                            else:
                                raw_title = title_query

                    try: clean_name = raw_name.encode('ascii', 'ignore').decode('ascii')
                    except: clean_name = raw_name

                    # Eliminare nume provider din afișare
                    banned_names = ['WebStreamr', 'StreamVix', 'Vidzee', 'Sooti', 'Sootio', 'MeowTV', 'HDHub']
                    for bn in banned_names:
                        clean_name = clean_name.replace(bn, '').strip()
                    
                    clean_name = clean_name.replace('|', '').replace('[', '').replace(']', '').strip()
                    clean_name = clean_name.replace('\n', ' ').strip()
                    while '  ' in clean_name: clean_name = clean_name.replace('  ', ' ')

                    final_name = f"{label} | {clean_name}" if clean_name else label
                    
                    # Extragere Calitate
                    quality = None
                    if s.get('quality'): quality = s.get('quality')
                    if not quality and description: quality = _extract_quality_from_string(description)
                    if not quality or quality.upper() == 'SD': quality = _extract_quality_from_string(raw_name)
                    if not quality: quality = _extract_quality_from_string(raw_title)
                    if not quality: quality = _extract_quality_from_string(s.get('behaviorHints', {}).get('filename', ''))
                    if not quality: quality = 'SD'
                    
                    # Înglobăm description în info pentru ca regex-urile din player.py să extragă corect mărimea (ex: 💾 9.58 GB)
                    info_text = str(s.get('behaviorHints', {}).get('filename', '')) + " " + description
                    
                    # LOCAL PATCH 2026-06-15: bare URL (no |Header= suffix). The
                    # aggregator-returned URLs are pre-signed CDN links — adding
                    # any pipe-headers (User-Agent / Referer / Origin) makes the
                    # CDN 404. AIOStreams uses bare URLs too and plays fine.
                    stream_obj = {
                        'name': final_name,
                        'url': url,
                        'quality': quality,
                        'title': raw_title,
                        'info': info_text.strip(),
                        'provider_id': label.lower(),
                        # LOCAL PATCH 2026-08-29: carry the aggregator's Date header so the
                        # pre-signed expiry gate in http_streams can judge X-Amz-Expires
                        # against SERVER time. A CoreELEC box with no RTC can boot with a
                        # badly wrong clock, and a wrong clock there would drop every source.
                        'server_date': server_date,
                        # LOCAL PATCH 2026-11-02: the exact byte size, for http_streams._inherit_prerelease
                        'video_size': s.get('behaviorHints', {}).get('videoSize') or 0,
                    }
                    local_streams.append(stream_obj)
                
                log(f"[SCRAPER] ✓ {label}: {len(local_streams)} surse")
                
    except Exception as e:
        log(f"[JSON-PROV] Error {label}: {e}")
        # LOCAL PATCH 2026-10-15: a request that failed with nothing collected is a FAILURE, not an empty answer.
        # Returning [] let http_streams cache "no streams" for an hour after one 502 / 429 / timeout.
        if not local_streams: raise

    return local_streams
