# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-11-04: the anime EPISODE CARD -- every id and numbering of one episode, worked out in one place.

	WHY
	The ids an anime scrape runs on (AniDB aid / eid, AniList, Kitsu, MAL, the cour / season / absolute numbers and the
	episode candidates) were built inline in scrapers/external.py's results(), ~600 lines grown fix by fix: Fribb's cour,
	re-placed by air dates (Tokyo Revengers, Re:ZERO), repaired past an entry's end (Blue Box), ani.zip's whole-run entry
	(Naruto), a new season by air date (Black Clover S2), AniDB by MAL id (Steel Ball Run), specials (Steins;Gate 0). Each
	step writes self.data as it goes, so the ORDER of the steps is spread over the method and no single place says what
	an episode IS. This module is that place: resolve() runs the same steps in one pipeline and returns an EpisodeCard.

	PHASE 1 (2026-11-04, shadow): built beside the inline code and compared field by field -- 17 hard cases and the first
	real scrapes matched. PHASE 2 (2026-11-04, now): external.results() calls resolve() and copies card.fields into
	self.data; the inline steps are gone. The whole data dict of 28 hard cases was byte-identical before and after
	(addon_patches/harness/scrape_data_snapshot.py), save the specials' absolute_episode fix below.

	NOT HERE: the reject words (foreign_cour_tokens, own_cour_tokens, cour_plan) -- they judge RELEASES, not the episode,
	and are built in external.py from card.cour / card.title_key; the pack file pick (modules/pack_pick.py).
"""
import time
from modules import kodi_utils, source_utils

# self.data fields the card owns -- compared in shadow mode, copied from the card in phase 2
ID_FIELDS = ('mal_id', 'kitsu_id', 'anilist_id', 'anidb_aid', 'anidb_eid', 'anidb_part_aids')
NUMBER_FIELDS = ('absolute_episode', 'cour_episode', 'cour_season', 'season_episode', 'season_length', 'cour_part',
				'cour_part_count', 'whole_run', 'episode_candidates')
TITLE_FIELDS = ('season_title', 'mal_title')
CARD_FIELDS = ID_FIELDS + NUMBER_FIELDS + TITLE_FIELDS


class EpisodeCard(object):
	"""One episode: TMDb's pair, every other numbering, every id, and which path found them (`source`) with the notes
	each step left (`trail`). Plain attributes; `fields` holds the self.data-named values."""
	__slots__ = ('tmdb', 'special', 'source', 'fields', 'trail', 'cour', 'title_key')

	def __init__(self, tmdb, special):
		self.tmdb, self.special, self.source, self.fields, self.trail = tmdb, special, 'none', {}, []
		# cour: the Fribb cour dict the ids came from (None off the Fribb path); title_key: (id field, id) the cour's titles
		# are keyed by -- id None when the episode is past the entry (no cour title then)
		self.cour, self.title_key = None, None

	def set(self, field, value):
		if value is not None and value != '' and value != []: self.fields[field] = value

	def note(self, text): self.trail.append(text)


class _Scratch(object):
	"""Stands in for the external source when one of its helper methods must run (_new_season_ids, _mal_episode_ids
	write self.data): same meta and ids, its OWN data dict, so the real scrape's data is never touched."""
	def __init__(self, src):
		import types
		self.meta, self.tmdb_id, self.season, self.episode, self.data = src.meta, src.tmdb_id, src.season, src.episode, {}
		cls = type(src)
		self._mal_episode_ids = types.MethodType(cls._mal_episode_ids, self)
		self._new_season_ids = types.MethodType(cls._new_season_ids, self)


def _int(value):
	try: return int(value)
	except (TypeError, ValueError): return None


# ---------------------------------------------------------------- the steps, in the order resolve() runs them

def _cour(src, card, raw_s, raw_e, prefetch=False):
	"""Fribb's cour for the TMDb pair: re-placed by air dates where Fribb's offsets are stale, re-asked with the flat-season
	repair when the episode is past the entry's end, dropped when no entry holds it. None = no cour."""
	from caches import fribb_mappings as _fribb
	dated = None
	try: dated = src._dated_cour(raw_s, raw_e)
	except Exception as e: kodi_utils.logger('scrape.cour_dates', 'tmdb %s S%sE%s: failed: %r' % (src.tmdb_id, raw_s, raw_e, e))
	cour = dated or _fribb.find_cour_by_tmdb_coords(src.tmdb_id, raw_s, raw_e, allow_repair=False)
	if dated:
		card.note('cour placed by air date')
		was = _fribb.find_cour_by_tmdb_coords(src.tmdb_id, raw_s, raw_e, allow_repair=False) or {}
		kodi_utils.logger('scrape.cour_dates', 'tmdb %s S%sE%s: Fribb says AniList %s ep %s; by air date it is AniList %s ep %s' % (
			src.tmdb_id, raw_s, raw_e, was.get('anilist'), was.get('cour_ep'), dated.get('anilist'), dated.get('cour_ep')))
	# every network lookup the steps below may make, started at once (external._prefetch_anime_ids); they then read caches
	if prefetch:
		try: src._prefetch_anime_ids(cour, raw_s, raw_e)
		except Exception: pass
	try:
		cep = int((cour or {}).get('cour_ep') or 0)
		if cep > 1 and cour.get('anilist'):
			from apis.anilist_api import anilist_episode_count
			length = anilist_episode_count(cour['anilist'])
			if length and cep > int(length):
				rep = _fribb.find_cour_by_tmdb_coords(src.tmdb_id, raw_s, raw_e, allow_repair=True) or {}
				rlen = anilist_episode_count(rep['anilist']) if rep.get('anilist') else None
				if (rep.get('row') or {}).get('_synthetic'): rep = {}
				ok = bool(rep.get('anilist')) and rep.get('anilist') != cour.get('anilist') and (not rlen or int(rep.get('cour_ep') or 0) <= int(rlen))
				card.note('past AniList %s (%s eps): %s' % (cour['anilist'], length, 'repaired to %s' % rep.get('anilist') if ok else 'dropped'))
				kodi_utils.logger('scrape.cour', 'tmdb %s S%sE%s is past AniList %s (%s eps; Fribb says ep %s) -- %s' % (src.tmdb_id, raw_s, raw_e,
					cour['anilist'], length, cep, 'repaired: AniList %s ep %s (AniDB %s)' % (rep.get('anilist'), rep.get('cour_ep'), rep.get('anidb'))
					if ok else 'no later Fribb entry: its ids dropped, the new-season lookup picks the entry by air date'))
				cour = rep if ok else None
	except Exception: pass
	return cour, dated


def _candidates(src, info, raw_s, raw_e, dated):
	"""The ordered episode numbers a release / pack file may use for this episode (source_utils.ordered_episode_candidates):
	Fribb's, the dated cour's in place of a stale pair, the entry's own season pair where it differs from TVDB's -- or, for
	a special searched under TVDB's number, that pair alone."""
	if info.get('special_episode'): return [tuple(int(x) for x in info['special_episode'])]
	from caches import fribb_mappings as _fm
	cands = source_utils.anime_episode_candidates(src.meta, src.tmdb_id, raw_s, raw_e)
	if dated:
		stale = _fm.find_cour_by_tmdb_coords(src.tmdb_id, raw_s, raw_e, allow_repair=False) or {}
		drop = set((int(stale['cour_season']), int(n)) for n in (stale.get('season_ep'), stale.get('cour_ep')) if n and stale.get('cour_season'))
		cands = [c for c in cands if c not in drop]
		for n in (dated.get('season_ep'), dated.get('cour_ep')):
			if n and dated.get('cour_season') and not (int(dated['cour_season']) == int(raw_s) and int(n) != int(raw_e)):
				cands.append((int(dated['cour_season']), int(n)))
	try:
		from modules.metadata import cour_display_numbers
		ds, de = (int(x) for x in cour_display_numbers(src.meta, int(raw_s), int(raw_e)))
		tv = _fm.find_cour_by_tmdb_coords(src.tmdb_id, int(raw_s), int(raw_e)) or {}
		if (ds, de) != (int(tv.get('cour_season') or 0), int(tv.get('season_ep') or 0)) and ds != int(raw_s) and (ds, de) not in cands:
			cands.append((ds, de))
			count = next((x.get('episode_count') for x in (src.meta.get('season_data') or []) if x.get('season_number') == int(raw_s)), 0) or 0
			shown = {}
			for e in range(1, int(count) + 1):
				if e != int(raw_e): shown[tuple(int(x) for x in cour_display_numbers(src.meta, int(raw_s), e))] = e
			cands = [c for c in cands if not (isinstance(c[0], int) and c[0] != int(raw_s) and c != (ds, de) and c in shown)]
	except Exception: pass
	return source_utils.ordered_episode_candidates(int(raw_s), int(raw_e), cands)


def _cour_ids(src, card, cour, raw_s):
	"""Everything a Fribb cour gives: its ids, its sibling parts' AniDB ids, the release numbering and the AniDB eid."""
	from caches import fribb_mappings as _fribb
	card.source, card.cour = 'fribb', cour
	for key, field in (('mal', 'mal_id'), ('kitsu', 'kitsu_id'), ('anilist', 'anilist_id')):
		if cour.get(key): card.set(field, int(cour[key]))
	try:
		aids, tv = [], cour.get('cour_season')
		for _off, prow in _fribb._season_cour_rows(src.tmdb_id, raw_s, allow_repair=False):
			prow = prow or {}
			if (prow.get('season') or {}).get('tvdb') != tv: continue
			pa = prow.get('anidb_id')
			if pa and int(pa) not in aids: aids.append(int(pa))
		if len(aids) > 1: card.set('anidb_part_aids', aids)
	except Exception: pass
	for key, field in (('cour_ep', 'cour_episode'), ('cour_season', 'cour_season'), ('season_ep', 'season_episode')):
		if cour.get(key) is not None: card.set(field, int(cour[key]))
	try:
		slen = cour.get('season_len')
		if not slen and cour.get('season_start') is not None: slen = int(src.season_divider) - int(cour['season_start'])
		if slen and int(slen) > 0: card.set('season_length', int(slen))
	except Exception: pass
	if cour.get('cour_part') and (cour.get('cour_part_count') or 0) > 1:
		card.set('cour_part', int(cour['cour_part']))
		card.set('cour_part_count', int(cour['cour_part_count']))
	try:
		for sn in (src.meta.get('season_data') or []):
			if int(sn.get('season_number') or -1) == int(raw_s) and sn.get('name'): card.set('season_title', sn['name'])
	except Exception: pass
	try:
		from caches.anizip_mappings import anizip_episode_ids
		ids = anizip_episode_ids(cour.get('anilist'), cour.get('cour_ep'), card.fields.get('absolute_episode'), cour.get('anidb'))
		aid = cour.get('anidb') or ids.get('aid')
		if aid: card.set('anidb_aid', int(aid))
		if ids.get('eid'): card.set('anidb_eid', int(ids['eid']))
		# ani.zip only fills a gap Fribb's row leaves, never overwrites it
		for key, field in (('anilist', 'anilist_id'), ('kitsu', 'kitsu_id'), ('mal', 'mal_id')):
			if ids.get(key) and not card.fields.get(field): card.set(field, int(ids[key]))
	except Exception: pass
	_cour_title(card, cour)


def _cour_title(card, cour):
	"""The cour's romaji title (AniList), by its AniList id, else its MAL id; none when the episode is past the entry."""
	try:
		from apis.anilist_api import anilist_romaji_for_mal, anilist_romaji_for_id, anilist_episode_count
		al, mal = cour.get('anilist'), cour.get('mal')
		own = al or mal
		card.title_key = ('anilist_id', al) if al else ('mal_id', mal)
		cep = int(cour.get('cour_ep') or 0)
		if al and cep > 1:
			length = anilist_episode_count(al)
			if length and cep > int(length):
				own = None
				card.title_key = (card.title_key[0], None)
				kodi_utils.logger('scrape.cour', 'S%sE%s is cour ep %s of AniList %s, which has %s: cour mapping off, no cour title'
					% (card.tmdb[0], card.tmdb[1], cep, al, length))
		if own:
			title = anilist_romaji_for_id(al) if al else anilist_romaji_for_mal(mal)
			if title: card.set('mal_title', title)
	except Exception: pass


def _special_ids(src, card, info):
	"""A special Fribb does not map: no whole-run or new-season ids (TMDb's S0En has no place in either numbering) -- only
	its own AniDB ids from ani.zip (sources.make_search_info), the aid only when it ships in the season's packs."""
	card.source = 'special'
	kodi_utils.logger('scrape.special', 'tmdb %s S0E%s: a special with no Fribb row -- no whole-run / new-season ids' % (src.tmdb_id, card.tmdb[1]))
	sp = info.get('special_anidb')
	if sp:
		card.set('anidb_eid', int(sp[1]))
		if sp[2]: card.set('anidb_aid', int(sp[0]))
		card.source = 'special+anizip'


def _whole_run_ids(src, card):
	"""A show Fribb has no row for, when ONE ani.zip entry covers the whole run (Naruto 220/220): its ids, paired with the
	series-absolute number. True when it applied."""
	absolute = card.fields.get('absolute_episode')
	if not absolute: return False
	from caches.anizip_mappings import anizip_whole_run_ids, anizip_episode_ids
	run = anizip_whole_run_ids(src.tmdb_id, src.meta.get('total_aired_eps'))
	if run.get('kitsu') and int(absolute) > int(run.get('count') or 0):
		card.note('absolute %s past the whole-run entry (%s eps)' % (absolute, run.get('count')))
		kodi_utils.logger('scrape.new_season', 'tmdb %s: absolute %s is past the %s episodes of ani.zip\'s whole-run entry (AniDB %s) -- '
			'not the whole run' % (src.tmdb_id, absolute, run.get('count'), run.get('aid')))
		run = {}
	if not run.get('kitsu'): return False
	card.source = 'whole_run'
	card.set('kitsu_id', int(run['kitsu']))
	card.set('cour_episode', int(absolute))
	for key, field in (('mal', 'mal_id'), ('anilist', 'anilist_id'), ('aid', 'anidb_aid')):
		if run.get(key): card.set(field, int(run[key]))
	card.set('whole_run', True)
	try:
		eids = anizip_episode_ids(run.get('anilist'), absolute, anidb_id=run.get('aid')) or {}
		if eids.get('eid'): card.set('anidb_eid', int(eids['eid']))
	except Exception: pass
	return True


def _new_season(src, card, raw_s, raw_e):
	"""A season Fribb has not mapped yet: the AniList entry that starts it by air date, its ani.zip / MAL ids
	(external._new_season_ids, run on a scratch copy)."""
	scratch = _Scratch(src)
	try: scratch._new_season_ids(raw_s, raw_e)
	except Exception as e: card.note('new season lookup failed: %r' % e)
	if scratch.data:
		card.source = 'new_season'
		for field, value in scratch.data.items():
			if field in CARD_FIELDS: card.set(field, value)


# ---------------------------------------------------------------- the pipeline

def resolve(src, info, prefetch=False):
	"""The EpisodeCard for the anime episode an external source is about to scrape. `src` supplies meta, tmdb_id and
	season_divider and its date / new-season / prefetch helpers; `info` is sources.search_info (the special's remap and
	AniDB ids). prefetch: start the network lookups in parallel first (the scrape; the harness may skip it)."""
	raw_s, raw_e = src.meta.get('season', src.season), src.meta.get('episode', src.episode)
	card = EpisodeCard((_int(raw_s), _int(raw_e)), str(raw_s) == '0')
	# 1. the series-absolute number (TMDb's season_data alone). Not for a special: series_absolute_episode hands TMDb's S0En
	# back unchanged, and 'absolute 1' for Steins;Gate 0's Valentine OVA made every '- 01' name an acceptable number to the
	# providers' name checks (anime_utils.cour_match takes absolute_episode as one of the episode's numbers).
	if not card.special:
		try:
			from modules.metadata import series_absolute_episode
			absolute = series_absolute_episode(src.meta, raw_s, raw_e)
			if absolute: card.set('absolute_episode', int(absolute))
		except Exception: pass
	# 2. which cour
	cour, dated = _cour(src, card, raw_s, raw_e, prefetch)
	# 3. the numbers a release may use
	try: card.set('episode_candidates', _candidates(src, info, raw_s, raw_e, dated))
	except Exception: pass
	# 4. the ids, from the first path that knows the episode
	if cour: _cour_ids(src, card, cour, raw_s)
	elif card.special: _special_ids(src, card, info)
	elif not _whole_run_ids(src, card): _new_season(src, card, raw_s, raw_e)
	return card
