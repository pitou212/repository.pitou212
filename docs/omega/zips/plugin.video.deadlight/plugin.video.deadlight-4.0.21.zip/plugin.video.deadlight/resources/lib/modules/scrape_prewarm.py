# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-06: warm an anime episode's scrape ids once its episode list is on screen.
#
# Before a scrape dispatches any provider, scrapers/external.results works out the anime ids: Fribb (local), then AniList
# (the entry's episode count, its romaji titles, a new season's entry) and ani.zip (AniDB / Kitsu / MAL ids and the AniDB
# episode id). Every one is cached, but the first scrape of a show waited on them in turn -- 0.9 s for Reborn as a Space
# Mercenary S1E1, 1.0 s for Magical Explorer S1E1, 3 ms for Blue Box once warm (log 2026-10-06). So build_episode_list
# queues the episodes most likely to be played next (the first aired unwatched one and the newest aired one), deadlight.py
# starts run() on a thread once routing() has returned -- the list is already delivered, as with page_prefetch, and the
# thread runs beside the rating backfills instead of after them -- and run() executes that same
# results() code with warm_only set, which returns just before get_sources: no provider, no results cache, no dialog.
#
# Only in-addon browsing (never a widget or skin call) and only anime (metadata.is_anime_meta, the scrape's own test).
_PENDING = None

def queue(meta, episodes):
	"""episodes: [(season, episode, ep_name), ...], warmed in order; a repeat is warmed once."""
	global _PENDING
	_PENDING = (meta, episodes)

def _warm_tosho_packs(data, done, monitor):
	"""LOCAL PATCH 2026-11-04: AnimeTosho's pack lists for the episode's AniDB ids, into the cache the provider reads
	(animetosho._aid_packs, 3 days; it helps in-addon browsing only -- a widget click scrapes at once). AnimeTosho takes ~1 s to answer a query it has not served lately and a split season asks
	once per part -- TYBW's packs landed 4.8 s into the scrape (log 14:15:42) -- so they are fetched here, on this thread, while
	the episode list is on screen. Only with AnimeTosho switched on, at most 4 ids, each once per run; a cached list costs a cache
	read. Returns the ids fetched (for the log line), or ''."""
	try:
		from magneto import enabledCheck
		if not enabledCheck('animetosho'): return ''
		aids = []
		for a in [data.get('anidb_aid')] + list(data.get('anidb_part_aids') or []):
			try:
				if a and int(a) not in aids: aids.append(int(a))
			except (TypeError, ValueError): continue
		aids = [a for a in aids[:4] if ('tosho', a) not in done]
		if not aids: return ''
		from magneto.providers.torrents.animetosho import source as tosho
		provider = tosho()
		for a in aids:
			if monitor.abortRequested(): break
			done.add(('tosho', a))
			provider._aid_packs(a)
		return ','.join(str(a) for a in aids)
	except Exception: return ''


def run():
	global _PENDING
	pending, _PENDING = _PENDING, None
	if not pending: return
	import time
	from modules import kodi_utils
	monitor = kodi_utils.kodi_monitor()
	if kodi_utils.external() or monitor.abortRequested(): return
	show, episodes = pending
	try: from scrapers.external import source
	except Exception as e: return kodi_utils.logger('scrape prewarm', 'failed: %r' % e)
	done = set()
	for season, episode, ep_name in episodes:
		if (season, episode) in done or monitor.abortRequested(): continue
		done.add((season, episode))
		start = time.time()
		try:
			meta = dict(show, season=season, episode=episode, ep_name=ep_name, media_type='episode', background=False)
			info = {'media_type': 'episode', 'title': meta.get('title') or '', 'year': meta.get('year') or '', 'tmdb_id': meta.get('tmdb_id'),
					'imdb_id': meta.get('imdb_id'), 'tvdb_id': meta.get('tvdb_id'), 'aliases': [], 'season': season, 'episode': episode,
					'ep_name': ep_name or '', 'expiry_times': (0, 0, 0), 'total_seasons': meta.get('total_seasons', 1)}
			warm = source(meta, [('prewarm', None)], [], False, [], [], None)
			warm.warm_only = True
			data = warm.results(info) or {}
			packs = _warm_tosho_packs(data, done, monitor)
			kodi_utils.logger('scrape prewarm', 'tmdb %s S%sE%s in %.2f s: kitsu %s ep %s, anidb eid %s, anilist %s%s' % (meta.get('tmdb_id'),
				season, episode, time.time() - start, data.get('kitsu_id'), data.get('cour_episode'), data.get('anidb_eid'), data.get('anilist_id'),
				', animetosho packs %s' % packs if packs else ''))
		except Exception as e: kodi_utils.logger('scrape prewarm', 'S%sE%s failed: %r' % (season, episode, e))
