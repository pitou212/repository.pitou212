# created by kodifitzwell for Fenomscrapers
"""
	Fenomscrapers Project
"""

from json import loads as jsloads
import re
from threading import Lock
from magneto.modules import client
from magneto.modules import source_utils
from magneto.modules import anime_utils


class source(source_utils.SourceRegistry):
	timeout = 10
	priority = 1
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	# LOCAL PATCH 2026-10-06: one future per search (source_utils.SourceRegistry), not the class-wide queue
	_lock = Lock()
	_cache = {}
	def __init__(self):
		self.language = ['en']
		self.base_link = "https://meteorfortheweebs.midnightignite.me"
		self.movieSearch_link = '/stream/movie/%s.json'
		self.tvSearch_link = '/stream/series/%s:%s:%s.json'
		# LOCAL PATCH 2026-10-27: AniList endpoint for anime. Meteor maps every id it takes (tt / kitsu / anilist / mal / anidb)
		# to one entry, so the answer is the same rows whichever id asks -- measured on 16 later cours and seasons and 12 shows
		# airing now (Fall 2026), 0.4-0.5 s each. AniList over Kitsu: Meteor's Kitsu map lags new entries -- kitsu ids for
		# Black Clover Season 2 and Dragon Ball Super: Beerus gave 0 streams where anilist / anidb / mal / IMDb gave 39 each.
		# A film is episode 1 of its entry ('anilist:1047:1', On Your Mark: 7 rows); bare movie/anilist:1047 finds nothing.
		self.animeSearch_link = '/stream/anime/anilist:%s:%s.json'
		self.min_seeders = 0

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		future = self.start_future(data)
		sources_append = sources.append
		try:
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			aliases = data['aliases']
			episode_title = data['title'] if 'tvshowtitle' in data else None
			year = data['year']
			imdb = data['imdb']
			anilist_mode = anilist_film = False
			if 'tvshowtitle' in data:
				season = data['season']
				episode = data['episode']
				hdlr = 'S%02dE%02d' % (int(season), int(episode))
				air_date = data.get('premiered')   # LOCAL PATCH 2026-10-24: date-named releases (source_utils.air_date_pattern)
				# LOCAL PATCH 2026-10-27: DeadLight passes anilist_id + cour_episode (the entry's own episode, the absolute one for
				# a whole-run entry: anilist:21:1100 is One Piece 1100) for anime only (scrapers/external.py). Without both, IMDb.
				anilist_id, cour_ep = data.get('anilist_id'), data.get('cour_episode')
				anilist_mode = bool(data.get('is_anime')) and bool(anilist_id) and cour_ep is not None
				if anilist_mode:
					url = '%s%s' % (self.base_link, self.animeSearch_link % (anilist_id, cour_ep))
				else:
					url = '%s%s' % (self.base_link, self.tvSearch_link % ((imdb,) + source_utils.stremio_se(data, season, episode)))   # LOCAL PATCH 2026-10-25 (4.0.5)
			else:
				hdlr = year
				air_date = None
				# LOCAL PATCH 2026-10-27: an anime film keeps its IMDb id when it has one -- by IMDb Your Name gave 74 rows and Mugen
				# Train 87, by anilist:<id>:1 0 and 12. Only a film with no IMDb id is asked for by its AniList id.
				anilist_film = bool(data.get('anilist_id')) and not anime_utils.real_imdb(imdb)
				url = '%s%s' % (self.base_link, self.animeSearch_link % (data['anilist_id'], 1) if anilist_film else self.movieSearch_link % imdb)
			# log_utils.log('url = %s' % url)
			try:
				results = client.request(url, timeout=self.timeout)
				files = jsloads(results)['streams']
			except:
				files = []
				raise
			finally:
				source_utils.set_future(future, files)
			_INFO = re.compile(r'💾.*')
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.set_future(future, [])
			source_utils.scraper_error('METEOR')
			return sources

		for file in files:
			try:
				hash = file['infoHash']
				file_title = (file.get('title') or file['description']).split('\n')
				file_info = [x for x in file_title if _INFO.search(x)][0]

				name = source_utils.clean_name(file_title[0])

				# LOCAL PATCH 2026-10-27: judged like torrentio's Kitsu path. Meteor's AniList answer is scoped to the entry, and
				# anime names carry no S01E05 ('[Erai-raws] One Piece - 1100'), which check_title demands -- so the SHOW is checked
				# (anime_utils.title_guard), then the file Meteor picked for junk, a later season, another cour, another show's year
				if not (anilist_mode or anilist_film):
					if not source_utils.check_title(title, aliases, name.replace('.(Archie.Bunker', ''), hdlr, year, air_date=air_date, id_matched=True): continue
				elif not anime_utils.title_guard(name, title, anime_utils.alias_titles(data)): continue
				if data.get('is_anime'):
					_file = (file.get('behaviorHints') or {}).get('filename') or ''
					if anime_utils.stremio_junk(_file or file_title[0], [title] + anime_utils.alias_titles(data)): continue
					if anime_utils.later_season_reject([_file, file_title[0]], data): continue
					if anime_utils.foreign_cour_marked(_file, data) or anime_utils.foreign_cour_marked(file_title[0], data): continue
					if anime_utils.other_show_year(file_title[0], data) or anime_utils.other_show_year(_file, data): continue
				name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)

				try:
					seeders = int(re.search(r'👥\s*(\d+)', file_info).group(1))
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				try:
					size = re.search(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', file_info).group(0)
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)

				item = {
					'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True,
					'provider': 'meteor', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
					'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders
				}
				# LOCAL PATCH 2026-10-27: a batch ('[DB] Mob Psycho 100 III [BD1080p]') is tagged as one, like comet's Kitsu rows
				# (anime_utils.batch_fields); true_size because Meteor's size is the episode file's (source_utils.pack_size_divider)
				if anilist_mode:
					_m = anime_utils._extract_meta(anime_utils._clean_for_extract(name))
					_fields = anime_utils.batch_fields(name, _m[1], _m[3], data.get('season_length'))
					if _fields: item.update(_fields, true_size=True)
				sources_append(item)
			except:
				source_utils.scraper_error('METEOR')
		return sources

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		sources = []
		if not data: return sources
		sources_append = sources.append
		try:
			title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			aliases = data['aliases']
			imdb = data['imdb']
			year = data['year']
			season = data['season']
			url = '%s%s' % (self.base_link, self.tvSearch_link % (imdb, season, data['episode']))
			files = self.wait_future(data, self.timeout + 1)
			_INFO = re.compile(r'💾.*')
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('METEOR')
			return sources

		for file in files:
			try:
				hash = file['infoHash']
				file_title = (file.get('title') or file['description']).split('\n')
				file_info = [x for x in file_title if _INFO.search(x)][0]

				name = source_utils.clean_name(file_title[0])

				episode_start, episode_end = 0, 0
				if not search_series:
					if not bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, season, name.replace('.(Archie.Bunker', ''))
						if not valid: continue
					package = 'season'

				elif search_series:
					if not bypass_filter:
						valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season, name.replace('.(Archie.Bunker', ''), total_seasons)
						if not valid: continue
					else: last_season = total_seasons
					package = 'show'

				# LOCAL PATCH 2026-10-27: Meteor runs on anime now (source_utils.ANIME_PROVIDERS) -- torrentio's pack checks
				if data.get('is_anime'):
					_file = (file.get('behaviorHints') or {}).get('filename') or ''
					if package == 'season' and anime_utils.later_season_reject([file_title[0], _file], data): continue
					if anime_utils.other_show_year(file_title[0], data): continue   # a remake / live-action series
					if anime_utils.foreign_cour_marked(file_title[0], data): continue   # 'act II' packs under Ace S2
				name_info = source_utils.info_from_name(name, title, year, season=season, pack=package)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
				try:
					seeders = int(re.search(r'👥\s*(\d+)', file_info).group(1))
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				try:
					size = re.search(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', file_info).group(0)
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)

				item = {
					'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True, 'true_size': True,
					'provider': 'meteor', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
					'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders, 'package': package
				}
				if search_series: item.update({'last_season': last_season})
				elif episode_start: item.update(source_utils.pack_range_fields(episode_start, episode_end))   # LOCAL PATCH 2026-10-03: + pack_episodes for the size; # for partial season packs
				sources_append(item)
			except:
				source_utils.scraper_error('METEOR')
		return sources
