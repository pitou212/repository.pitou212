# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-10-31: torrentgalaxy -- TorrentGalaxy's JSON search, searched by NAME (POV 6.10 added it with its twin
	therarbg; they are ONE database: identical rows for every query tried, so this provider asks torrentgalaxy.one and falls
	back to therarbg.to when that request fails).

	Measured 2026-10-31 against Torrentio and knaben for the same titles (matching rows / in neither): The Last of Us S02E03
	44 / 7 (2160p + 1080p CRAV WEB-DL), Severance S02E05 34 / 8 (ATVP WEB-DL), Banshee S02E02 5 / 2 (AMZN WEB-DL), Dune:
	Part Two 50 / 8 (BluRay TrueHD); anime (Frieren) nothing. 0.6-1.3 s a query. This network resets ~40 % of its connections
	(WinError 10054, by SNI); client.request retries those.

	API: <base>/get-posts/format:json:keywords:<query>   No key. {'count', 'total', 'page_size': 50, 'links', 'results': [
	  {'n' name, 'h' info hash (upper case), 'se' seeders, 'le' leechers, 's' size in bytes, 'c' category ('TV', 'Movies',
	   ...), 'i' IMDb id or None, 'tg' tags, ...}]}  -- the first page only (50 rows), as POV.
	A row whose 'i' names ANOTHER IMDb id than the title's is dropped: 'Dance Brothers S01E06' matched a 'Brothers S01E06'
	query by name. Not in POV.

	Laid out like apibay.py (episode / season-pack / show-pack queries in parallel threads), using client.request so the
	loading window's ok / failed tally sees it.
"""

import json
import re
from urllib.parse import quote
from magneto.modules import client
from magneto.modules import source_utils
from magneto.modules import workers

_VIDEO = ('TV', 'Movies', 'Anime', 'Documentaries')


class source:
	priority = 3
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		self.language = ['en']
		self.base_links = ('https://torrentgalaxy.one', 'https://therarbg.to')
		self.search_link = '/get-posts/format:json:keywords:%s'
		self.min_seeders = 0

	def _query(self, query):
		"""The rows for one query: video categories only, another title's IMDb id dropped, each hash once per scrape."""
		results = None
		for base in self.base_links:
			results = client.request('%s%s' % (base, self.search_link % quote(query)), timeout=6)
			if results: break
		if not results: return []
		rows = []
		for row in json.loads(results).get('results') or []:
			hash = (row.get('h') or '').lower()
			if not hash or hash in self.seen: continue
			if row.get('c') and row['c'] not in _VIDEO: continue
			if self.imdb and row.get('i') and str(row['i']).startswith('tt') and row['i'] != self.imdb: continue
			self.seen.add(hash)
			rows.append(row)
		return rows

	def _item(self, row, name, name_info):
		"""The common part of an episode / movie / pack row, or None when it is below min_seeders."""
		try: seeders = int(row.get('se', 0) or 0)
		except: seeders = 0
		if self.min_seeders > seeders: return None
		hash = row['h'].lower()
		url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
		quality, info = source_utils.get_release_quality(name_info, url)
		try:
			dsize, isize = source_utils.convert_size(float(row.get('s', 0)), to='GB')
			info.insert(0, isize)
		except: dsize = 0
		return {'provider': 'torrentgalaxy', 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name, 'name_info': name_info,
				'quality': quality, 'language': 'en', 'url': url, 'info': ' | '.join(info), 'direct': False, 'debridonly': True, 'size': dsize}

	def _imdb(self, data):
		imdb = str(data.get('imdb') or '')
		return imdb if imdb.startswith('tt') and imdb.strip('t0') else None

	def sources(self, data, hostDict):
		self.items = []
		if not data: return self.items
		self.seen = set()
		try:
			self.aliases = data['aliases']
			self.year = data['year']
			self.imdb = self._imdb(data)
			if 'tvshowtitle' in data:
				self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
				self.episode_title = data['title']
				self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
				self.air_date = data.get('premiered')
			else:
				self.title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
				self.episode_title = None
				self.hdlr = self.year
				self.air_date = None
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			self.get_sources('%s %s' % (re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title), self.hdlr))
			if data.get('date_search') and self.air_date:   # and by air date for a date-released show (source_utils.air_date_query)
				self.get_sources('%s %s' % (re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title), source_utils.air_date_query(self.air_date)))
			return self.items
		except:
			source_utils.scraper_error('TORRENTGALAXY')
			return self.items

	def get_sources(self, query):
		try: rows = self._query(query)
		except:
			source_utils.scraper_error('TORRENTGALAXY')
			return
		for row in rows:
			try:
				name = source_utils.clean_name(row['n'])
				if not source_utils.check_title(self.title, self.aliases, name, self.hdlr, self.year, air_date=self.air_date): continue
				name_info = source_utils.info_from_name(name, self.title, self.year, self.hdlr, self.episode_title)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				if not self.episode_title: # episodes returned by a movie query
					ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
					name_lower = name.lower()
					if any(re.search(item, name_lower) for item in ep_strings): continue
				item = self._item(row, name, name_info)
				if item: self.items.append(item)
			except:
				source_utils.scraper_error('TORRENTGALAXY')

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		self.items = []
		if not data: return self.items
		self.seen = set()
		try:
			self.search_series = search_series
			self.total_seasons = total_seasons
			self.bypass_filter = bypass_filter
			self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			self.aliases = data['aliases']
			self.imdb = self._imdb(data)
			self.imdb_raw = data['imdb']
			self.year = data['year']
			self.season_x = data['season']
			self.season_xx = self.season_x.zfill(2)
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			query = re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title)
			if search_series: queries = [query + ' Season', query + ' Complete']
			else: queries = [query + ' S%s' % self.season_xx, query + ' Season %s' % self.season_x]
			threads = [workers.Thread(self.get_sources_packs, q) for q in queries]
			[i.start() for i in threads]
			[i.join() for i in threads]
			return self.items
		except:
			source_utils.scraper_error('TORRENTGALAXY')
			return self.items

	def get_sources_packs(self, query):
		try: rows = self._query(query)
		except:
			source_utils.scraper_error('TORRENTGALAXY')
			return
		for row in rows:
			try:
				name = source_utils.clean_name(row['n'])
				episode_start, episode_end = 0, 0
				if not self.search_series:
					if not self.bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(self.title, self.aliases, self.year, self.season_x, name)
						if not valid: continue
					package = 'season'
				else:
					if not self.bypass_filter:
						valid, last_season = source_utils.filter_show_pack(self.title, self.aliases, self.imdb_raw, self.year, self.season_x, name, self.total_seasons)
						if not valid: continue
					else: last_season = self.total_seasons
					package = 'show'
				name_info = source_utils.info_from_name(name, self.title, self.year, season=self.season_x, pack=package)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				item = self._item(row, name, name_info)
				if not item: continue
				item['package'] = package
				if self.search_series: item['last_season'] = last_season
				elif episode_start: item.update(source_utils.pack_range_fields(episode_start, episode_end))   # partial season packs
				self.items.append(item)
			except:
				source_utils.scraper_error('TORRENTGALAXY')
