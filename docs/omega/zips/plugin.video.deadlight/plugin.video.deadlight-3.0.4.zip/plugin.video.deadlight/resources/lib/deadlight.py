# -*- coding: utf-8 -*-
import sys
from modules.router import routing, sys_exit_check
# from modules.kodi_utils import logger

routing(sys)
# LOCAL PATCH 2026-09-26: rating backfills a directory listing deferred (see
# modules/metadata.flush_rating_backfills). routing() has returned, so endOfDirectory has
# already delivered the list; only runs if this process loaded metadata at all.
_metadata = sys.modules.get('modules.metadata')
if _metadata is not None:
	try: _metadata.flush_rating_backfills()
	except Exception: pass
# LOCAL PATCH 2026-09-26: action rows of Kodi's settings dialog close it before running (the dialog
# would otherwise overwrite what the action saves); reopen it on the same category afterwards.
if 'reopen_settings=' in sys.argv[2]:
	try:
		from urllib.parse import parse_qsl
		from modules.kodi_settings import open_settings
		open_settings(dict(parse_qsl(sys.argv[2].lstrip('?'))).get('reopen_settings'))
	except Exception: pass
# LOCAL PATCH 2026-09-27: close every database handle ourselves, now, rather than leaving them to Kodi's
# interpreter teardown -- see caches/base_cache.close_all_connections for the deadlock this avoids.
# LOCAL PATCH 2026-10-02: but first wait for this process's own worker threads. Marking Sakamoto Days watched crashed Kodi
# (access violation in _sqlite3.pyd, on the thread Kodi logged it was 'waiting on'): with MDBList as the watched provider,
# batch_erase_bookmark clears each in-progress episode on a thread, 1 s apart, and the close below pulled its database
# handle out from under it. Widget syncs (_sync_then_refresh) have the same shape. The list or action is already done
# by now, so waiting costs nothing visible; past the cap the close is skipped rather than risk the same crash.
import threading, time
_deadline = time.time() + 60
for _t in threading.enumerate():
	if _t is threading.current_thread() or _t.daemon or not _t.is_alive(): continue
	try: _t.join(max(0, _deadline - time.time()))
	except Exception: pass
_still_busy = any(_t.is_alive() and not _t.daemon for _t in threading.enumerate() if _t is not threading.current_thread())
_waited = 60 - (_deadline - time.time())
if _waited > 1 or _still_busy:
	try:
		from modules.kodi_utils import logger
		logger('exit wait', '%.1f s for worker threads%s' % (_waited, '; still running, databases left open' if _still_busy else ''))
	except Exception: pass
_base_cache = sys.modules.get('caches.base_cache')
if _base_cache is not None and not _still_busy:
	try: _base_cache.close_all_connections()
	except Exception: pass
if sys_exit_check(): sys.exit(1)
