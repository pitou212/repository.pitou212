# -*- coding: utf-8 -*-
from threading import Thread
from caches.base_cache import connect_database, kv_encode, kv_decode, replace_watched_rows, replace_progress_rows, is_failed_result
from modules.kodi_utils import sleep, confirm_dialog, close_all_dialog
# from modules.kodi_utils import logger

class TraktCache:
	def get(self, string):
		result = None
		try:
			dbcon = connect_database('trakt_db')
			cache_data = dbcon.execute('SELECT data FROM trakt_data WHERE id = ?', (string,)).fetchone()
			if cache_data: result = kv_decode(cache_data[0])   # LOCAL PATCH 2026-10-02, see base_cache.kv_encode
		except: pass
		return result

	def set(self, string, data):
		try:
			dbcon = connect_database('trakt_db')
			dbcon.execute('INSERT OR REPLACE INTO trakt_data (id, data) VALUES (?, ?)', (string, kv_encode(data)))
		except: return None

	def delete(self, string):
		try:
			dbcon = connect_database('trakt_db')
			dbcon.execute('DELETE FROM trakt_data WHERE id = ?', (string,))
		except: pass

trakt_cache = TraktCache()

class TraktWatched():
	def set_bulk_tvshow_status(self, insert_list):
		self._delete('DELETE FROM watched_status', ())
		self._executemany('INSERT INTO watched_status VALUES (?, ?, ?)', insert_list)

	def set_tvshow_status(self, insert_dict):
		dbcon = connect_database('trakt_db')
		dbcon.execute('INSERT OR REPLACE INTO trakt_data (id, data) VALUES (?, ?)', ('trakt_tvshow_status', repr(insert_dict),))

	# LOCAL PATCH 2026-07-04: guard the destructive DELETE against empty insert_lists.
	# _fetch_all_pages returns [] on any transient Trakt API failure (401 / 429 / partial
	# pagination / error-dict response). Prior code wiped the whole cache first then
	# inserted the empty list, permanently destroying local watched/progress history until
	# the next successful full sync (which may never happen if the API stays flaky). Now
	# we skip the wipe when insert_list is empty — old cache is preserved. Trakt is the
	# source of truth server-side; the next successful sync will overwrite fully.
	def set_bulk_movie_watched(self, insert_list, since=None):
		if not insert_list: return
		# LOCAL PATCH 2026-10-03: keeps marks made while the sync was downloading (base_cache.replace_watched_rows)
		replace_watched_rows(connect_database('trakt_db'), 'movie', insert_list, since)

	def set_bulk_tvshow_watched(self, insert_list, since=None):
		if not insert_list: return
		# LOCAL PATCH 2026-10-03: keeps marks made while the sync was downloading (base_cache.replace_watched_rows)
		replace_watched_rows(connect_database('trakt_db'), 'episode', insert_list, since)

	def set_bulk_movie_progress(self, insert_list, since=None):
		if not insert_list: return
		# LOCAL PATCH 2026-10-03 (Batch 2, base_cache.replace_progress_rows): keeps resume points saved while the sync was downloading.
		replace_progress_rows(connect_database('trakt_db'), 'movie', insert_list, since)

	def set_bulk_tvshow_progress(self, insert_list, since=None):
		if not insert_list: return
		# LOCAL PATCH 2026-10-03 (Batch 2, base_cache.replace_progress_rows): keeps resume points saved while the sync was downloading.
		replace_progress_rows(connect_database('trakt_db'), 'episode', insert_list, since)

	def _executemany(self, command, insert_list):
		dbcon = connect_database('trakt_db')
		dbcon.executemany(command, insert_list)

	def _delete(self, command, args):
		# LOCAL PATCH 2026-08-10 (Red Light 2.2.1 port): no VACUUM here. This runs on
		# EVERY bulk watched/progress write (4x per sync, each preceded by a DELETE),
		# and VACUUM rewrites the entire DB file each time. On slow storage (the box's
		# eMMC/SD) that stalled Next Episodes / In-Progress rebuilds after playback.
		# Space is reclaimed by the explicit VACUUM in clear_all_trakt_cache_data()
		# and by DatabaseMaintenance — it does not belong in the sync hot path.
		dbcon = connect_database('trakt_db')
		dbcon.execute(command, args)

trakt_watched_cache = TraktWatched()

def cache_trakt_object(function, string, url):
	cache = trakt_cache.get(string)
	if cache is not None: return cache
	result = function(url)
	# LOCAL PATCH 2026-10-03 (Batch 3): these rows never expire (only Trakt activity clears them), so a failure
	# (None) or a refusal body must never be stored.
	if result is None or is_failed_result(result): return None
	trakt_cache.set(string, result)
	return result

def set_list_custom_sort(list_id, data):
	string = 'trakt_list_custom_sort_%s' % list_id
	try:
		dbcon = connect_database('trakt_db')
		dbcon.execute('INSERT OR REPLACE INTO trakt_data (id, data) VALUES (?, ?)', (string, repr(data)))
		return True
	except: return False

def delete_list_custom_sort(list_id):
	string = 'trakt_list_custom_sort_%s' % list_id
	try:
		dbcon = connect_database('trakt_db')
		dbcon.execute('DELETE FROM trakt_data WHERE id=?', (string,))
		return True
	except: return False

def get_list_custom_sort(list_id):
	string = 'trakt_list_custom_sort_%s' % list_id
	try:
		dbcon = connect_database('trakt_db')
		cache_data = dbcon.execute('SELECT data FROM trakt_data WHERE id = ?', (string,)).fetchone()
		return kv_decode(cache_data[0])
	except: return {}

def get_all_lists_custom_sort():
	try:
		dbcon = connect_database('trakt_db')
		all_cache_data = dbcon.execute('SELECT data FROM trakt_data WHERE id LIKE %s' % "'trakt_list_custom_sort_%'").fetchall()
		all_cache_data = (kv_decode(i[0]) for i in all_cache_data)
		return dict([(i['list_id'], {'sort_by': i['sort_by'], 'sort_how': i['sort_how']}) for i in all_cache_data])
	except: return {}

def reset_activity(latest_activities):
	string = 'trakt_get_activity'
	try:
		dbcon = connect_database('trakt_db')
		data = dbcon.execute('SELECT data FROM trakt_data WHERE id = ?', (string,)).fetchone()
		if data: cached_data = kv_decode(data[0])
		else: cached_data = default_activities()
		dbcon.execute('DELETE FROM trakt_data WHERE id=?', (string,))
		trakt_cache.set(string, latest_activities)
	except: cached_data = default_activities()
	return cached_data

def clear_daily_cache():
	clear_trakt_calendar()
	clear_trakt_list_data('my_lists')
	clear_trakt_list_data('liked_lists')
	clear_trakt_list_data('user_lists')
	clear_trakt_list_contents_data('my_lists')
	clear_trakt_list_contents_data('liked_lists')
	clear_trakt_list_contents_data('user_lists')

def clear_trakt_hidden_data(list_type):
	string = 'trakt_hidden_items_%s' % list_type
	try:
		dbcon = connect_database('trakt_db')
		dbcon.execute('DELETE FROM trakt_data WHERE id=?', (string,))
	except: pass

def clear_trakt_collection_watchlist_data(list_type, media_type):
	if media_type == 'movies': media_type = 'movie'
	if media_type in ('tvshows', 'shows'): media_type = 'tvshow'
	string = 'trakt_%s_%s' % (list_type, media_type)
	try:
		dbcon = connect_database('trakt_db')
		dbcon.execute('DELETE FROM trakt_data WHERE id=?', (string,))
	except: pass

def clear_trakt_calendar():
	try:
		dbcon = connect_database('trakt_db')
		dbcon.execute('DELETE FROM trakt_data WHERE id LIKE "%s"' % 'trakt_get_my_calendar_%')
	except: return

def clear_trakt_list_contents_data(list_type):
	string = 'trakt_list_contents_' + list_type + '_%'
	try:
		dbcon = connect_database('trakt_db')
		dbcon.execute('DELETE FROM trakt_data WHERE id LIKE "%s"' % string)
	except: pass

def clear_trakt_list_data(list_type):
	string = 'trakt_%s' % list_type
	try:
		dbcon = connect_database('trakt_db')
		dbcon.execute('DELETE FROM trakt_data WHERE id=?', (string,))
	except: pass

def clear_trakt_recommendations():
	try:
		dbcon = connect_database('trakt_db')
		dbcon.execute('DELETE FROM trakt_data WHERE id LIKE "%s"' % 'trakt_recommendations_%')
	except: return

def clear_trakt_favorites():
	try:
		dbcon = connect_database('trakt_db')
		dbcon.execute('DELETE FROM trakt_data WHERE id LIKE "%s"' % 'trakt_favorites_%')
	except: return

def clear_all_trakt_cache_data(silent=False, refresh=True):
	try:
		start = silent or confirm_dialog()
		if not start: return False
		from caches.main_cache import main_cache
		main_cache_dbcon = connect_database('maincache_db')
		lists_with_media = main_cache_dbcon.execute('SELECT id FROM maincache WHERE id LIKE %s' % "'trakt_lists_with_media_%'").fetchall()
		for item in lists_with_media:
			try: main_cache.delete(item[0])
			except: pass
		main_cache.clean_database()
		dbcon = connect_database('trakt_db')
		for table in ('progress', 'watched', 'watched_status'): dbcon.execute('DELETE FROM %s' % table)
		dbcon.execute('DELETE FROM trakt_data WHERE id NOT LIKE %s' % "'trakt_list_custom_sort_%'")
		dbcon.execute('VACUUM')
		if refresh:
			from apis.trakt_api import trakt_sync_activities
			Thread(target=trakt_sync_activities).start()
		return True
	except: return False

def default_activities():
	return {
			'all': '2024-01-22T00:22:21.000Z',
			'movies':
				{
				'watched_at': '2020-01-01T00:00:01.000Z',
				'collected_at': '2020-01-01T00:00:01.000Z',
				'rated_at': '2020-01-01T00:00:01.000Z',
				'watchlisted_at': '2020-01-01T00:00:01.000Z',
				'favorited_at': '2020-01-01T00:00:01.000Z',
				'recommendations_at': '2020-01-01T00:00:01.000Z',
				'commented_at': '2020-01-01T00:00:01.000Z',
				'paused_at': '2020-01-01T00:00:01.000Z',
				'hidden_at': '2020-01-01T00:00:01.000Z'
				},
			'episodes':
				{
				'watched_at': '2020-01-01T00:00:01.000Z',
				'collected_at': '2020-01-01T00:00:01.000Z',
				'rated_at': '2020-01-01T00:00:01.000Z',
				'watchlisted_at': '2020-01-01T00:00:01.000Z',
				'commented_at': '2020-01-01T00:00:01.000Z',
				'paused_at': '2020-01-01T00:00:01.000Z'
				},
			'shows':
				{
				'rated_at': '2020-01-01T00:00:01.000Z',
				'watchlisted_at': '2020-01-01T00:00:01.000Z',
				'favorited_at': '2020-01-01T00:00:01.000Z',
				'recommendations_at': '2020-01-01T00:00:01.000Z',
				'commented_at': '2020-01-01T00:00:01.000Z',
				'dropped_at': '2020-01-01T00:00:01.000Z'
				},
			'seasons':
				{
				'rated_at': '2020-01-01T00:00:01.000Z',
				'watchlisted_at': '2020-01-01T00:00:01.000Z',
				'commented_at': '2020-01-01T00:00:01.000Z',
				'hidden_at': '2020-01-01T00:00:01.000Z'
				},
			'comments':
				{
				'liked_at': '2020-01-01T00:00:01.000Z',
				'blocked_at': '2020-01-01T00:00:01.000Z'
				},
			'lists':
				{
				'liked_at': '2020-01-01T00:00:01.000Z',
				'updated_at': '2020-01-01T00:00:01.000Z',
				'commented_at': '2020-01-01T00:00:01.000Z'
				},
			'watchlist':
				{
				'updated_at': '2020-01-01T00:00:01.000Z'
				},
			'favorites':
				{
				'updated_at': '2020-01-01T00:00:01.000Z'
				},
			'recommendations':
				{
				'updated_at': '2020-01-01T00:00:01.000Z'
				},
			'collaborations':
				{
				'updated_at': '2020-01-01T00:00:01.000Z'
				},
			'account':
				{
				'settings_at': '2020-01-01T00:00:01.000Z',
				'followed_at': '2020-01-01T00:00:01.000Z',
				'following_at': '2020-01-01T00:00:01.000Z',
				'pending_at': '2020-01-01T00:00:01.000Z',
				'requested_at': '2020-01-01T00:00:01.000Z'
				},
			'saved_filters':
				{
				'updated_at': '2020-01-01T00:00:01.000Z'
				},
			'notes':
				{
				'updated_at': '2020-01-01T00:00:01.000Z'
				}
			}
	