# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-10-14: retry TMDb Helper's thin rating sets.

AF3's rating chips come from TMDb Helper (since 2026-09-28), which caches every title's ratings for a flat 7 days
(RatingsDict.expiry_time in its ratings.py) whether or not they were complete. A film focused in its first days is
cached before MDBList has its IMDb / Letterboxd scores -- Animals (2026) and Matchbox the Movie, cached 10-10, still
showed Trakt only on 10-14 while MDBList had the full set. Deleting such a row makes TMDb Helper fetch it again the
next time the title is focused. Kept outside TMDb Helper so its updates cannot undo it.

Only movie and show rows (`movie.N`, `tv.N`): season / episode rows never carry MDBList or OMDb ratings and would be
refetched for nothing. Only titles released in the last NEW_DAYS: an older title missing a score will not gain one
(regional and older titles -- Main Hoon Jadugar, Pari Hoon Main -- are IMDb-only or nothing for good), and retrying
those daily would be pure waste. Unreleased titles are left alone -- nobody has rated them yet.

Thin = no IMDb score OR no Trakt score. Trakt covers nearly everything MDBList knows, so its absence on a new title
means MDBList had not caught up (Paris Cafe, Maremma: IMDb from OMDb, nothing from MDBList)."""
import os
import re
import sqlite3
import time

TMDBH_DATA = 'special://profile/addon_data/plugin.video.themoviedb.helper/'
TMDBH_EXPIRY = 7 * 86400   # RatingsDict.expiry_time; the write time is expiry minus this
MIN_AGE = 86400            # give MDBList a day before asking again
NEW_DAYS = 90              # how long after release a title keeps being retried
_TITLE_ROW = re.compile(r'^(movie|tv)\.\d+$')
_EMPTY = (None, '', 0)

def find_db(data_dir):
	"""The newest database_NN/ItemDetails.db (TMDb Helper bumps the folder on schema changes), or None."""
	try: folders = sorted((d for d in os.listdir(data_dir) if re.match(r'^database_\d+$', d)), key=lambda d: int(d.split('_')[1]))
	except OSError: return None
	for folder in reversed(folders):
		path = os.path.join(data_dir, folder, 'ItemDetails.db')
		if os.path.isfile(path): return path
	return None

def is_thin(row_id, imdb_rating, trakt_rating, written, expiry, premiered, now, today, oldest):
	"""True when this cached rating set should be fetched again. `oldest` is the earliest release date still retried."""
	if not _TITLE_ROW.match(row_id or ''): return False          # season / episode rows: always empty
	if imdb_rating not in _EMPTY and trakt_rating not in _EMPTY: return False   # complete enough
	if expiry < now: return False                                # already expired; TMDb Helper refetches it anyway
	if now - written < MIN_AGE: return False                     # fetched under a day ago
	if not premiered or premiered > today: return False          # unreleased (or undated): nothing to gain yet
	if premiered < oldest: return False                          # not new: a missing score is not coming
	return True

def tidy(db_path, now=None):
	"""Delete thin title rows. Returns (deleted ids, error or None). Never raises."""
	now = int(now or time.time())
	today = time.strftime('%Y-%m-%d', time.localtime(now))
	oldest = time.strftime('%Y-%m-%d', time.localtime(now - NEW_DAYS * 86400))
	try:
		con = sqlite3.connect(db_path, timeout=10)
		try:
			rows = con.execute(
				"SELECT r.id, r.imdb_rating, r.trakt_rating, r.expiry, COALESCE(m.premiered, t.premiered) FROM ratings r "
				"LEFT JOIN movie m ON m.id = r.id LEFT JOIN tvshow t ON t.id = r.id "
				"WHERE r.id LIKE 'movie.%' OR r.id LIKE 'tv.%'").fetchall()
			thin = [r[0] for r in rows if is_thin(r[0], r[1], r[2], r[3] - TMDBH_EXPIRY, r[3], r[4], now, today, oldest)]
			if thin:
				con.executemany('DELETE FROM ratings WHERE id = ?', [(i,) for i in thin])
				con.commit()
			return thin, None
		finally: con.close()
	except Exception as e:
		# a renamed table or column after a TMDb Helper update lands here -- logged by the caller, never fatal
		return [], '%s: %s' % (type(e).__name__, e)
