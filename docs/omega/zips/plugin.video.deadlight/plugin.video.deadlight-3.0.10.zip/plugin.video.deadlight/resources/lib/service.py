# -*- coding: utf-8 -*-
from xbmc import Monitor
import os
import json
import inspect
from time import time
from threading import Thread
from caches.settings_cache import get_setting, set_setting, sync_settings
from modules import kodi_utils

pause_services_prop = 'deadlight.pause_services'
firstrun_update_prop = 'deadlight.firstrun_update'
current_skin_prop = 'deadlight.current_skin'
trakt_service_string = 'TraktMonitor Service Update %s - %s'
trakt_success_line_dict = {'success': 'Trakt Update Performed', 'no account': '(Unauthorized) Trakt Update Performed'}
# LOCAL PATCH 2026-07-23: MDBList background sync monitor — mirrors TraktMonitor.
mdblist_service_string = 'MDBListMonitor Service Update %s - %s'
mdblist_success_line_dict = {'success': 'MDBList Update Performed', 'no account': '(Unauthorized) MDBList Update Performed'}
# LOCAL PATCH 2026-07-29: SIMKL sync monitor string constants.
simkl_service_string = 'SIMKLMonitor Service Update %s - %s'
simkl_success_line_dict = {'success': 'SIMKL Update Performed', 'no account': '(Unauthorized) SIMKL Update Performed'}
update_string = 'Next Update in %s minutes...'
anilist_service_string = 'AniListMonitor Service Update %s - %s'

# LOCAL PATCH 2026-10-02: the sync monitors keep their interval across Kodi restarts. Each one synced the moment the
# service started, however recently it last ran: a restart 21 minutes after the previous one (60-minute interval) re-ran
# all four, and MDBList's 12 s sync then reloaded every widget half way through the home screen's first build (a second
# wave of ~19 widget processes, 09:57:21 on 10-02). Now the first sync waits until it is due, and never runs sooner than
# _BOOT_SETTLE seconds after start, so the first widget build has the machine to itself. A long-off Kodi still syncs at
# ~45 s. The times live in a small file, not settings.db: set_setting refuses ids without a default row.
_BOOT_SETTLE = 45
_last_sync_lock = __import__('threading').Lock()

def _last_sync_file():
	return os.path.join(kodi_utils.translate_path(kodi_utils.addon_info('profile')), 'service_last_sync.json')

def _read_last_syncs():
	try:
		with open(_last_sync_file(), 'r', encoding='utf-8') as f: return json.load(f)
	except Exception: return {}

def _mark_synced(name):
	with _last_sync_lock:
		data = _read_last_syncs()
		data[name] = int(time())
		path = _last_sync_file()
		try:
			with open(path + '.tmp', 'w', encoding='utf-8') as f: json.dump(data, f)
			os.replace(path + '.tmp', path)
		except Exception as e: kodi_utils.logger('DeadLight', 'last sync write failed (%s): %s' % (name, e))

def _wait_until_due(name, interval, wait_for_abort):
	"""True if Kodi is closing. Waits until `name` is due again (last sync + interval), at least _BOOT_SETTLE."""
	try: last = float(_read_last_syncs().get(name) or 0)
	except Exception: last = 0.0
	delay = max(_BOOT_SETTLE, last + interval - time())
	kodi_utils.logger('DeadLight', '%s first sync in %d s' % (name, delay))
	return wait_for_abort(delay)

class SetAddonConstants:
	def run(self):
		kodi_utils.logger('DeadLight', 'SetAddonConstants Service Starting')
		import random
		# LOCAL PATCH 2026-10-02: ONE Addon object. kodi_utils.addon_info builds a new xbmcaddon.Addon() per call, and this
		# made nine of them (addon_fanart() is a tenth while its property is still empty): 38-68 ms on the boot thread.
		import xbmcaddon
		info = xbmcaddon.Addon('plugin.video.deadlight').getAddonInfo
		path, icon = info('path'), kodi_utils.translate_path(info('icon'))
		addon_items = [
			('deadlight.playback_key', str(random.randint(1000, 10000))),
			('deadlight.addon_name', info('name')),
			('deadlight.addon_version', info('version')),
			('deadlight.addon_path', path),
			('deadlight.addon_profile', kodi_utils.translate_path(info('profile'))),
			('deadlight.addon_icon', icon),
			('deadlight.addon_icon_mini', os.path.join(path, 'resources', 'media', 'addon_icons', 'minis', os.path.basename(icon))),
			('deadlight.addon_fanart', kodi_utils.translate_path(info('fanart')))
					]
		for item in addon_items: kodi_utils.set_property(*item)
		return kodi_utils.logger('DeadLight', 'SetAddonConstants Service Finished')

class DatabaseMaintenance:
	def run(self):
		kodi_utils.logger('DeadLight', 'DatabaseMaintenance Service Starting')
		# LOCAL PATCH 2026-05-26: defer 15s so PRAGMA integrity_check across 15 SQLite DBs
		# (potentially 100-500ms) doesn't block Kodi's critical boot path. Integrity is safety-
		# critical but checking it 15s into the session vs at t=0 has no user-visible difference.
		# LOCAL PATCH 2026-09-04: gate on "not playing" instead of picking a bigger number.
		#
		# An earlier version of this patch moved the defer 15s -> 90s, reasoning that 15s
		# landed in the home screen's widget build. That was a bad trade and it broke
		# playback: integrity_check READS EVERY BYTE of every DB (~40 MB here) on its own
		# database.connect() handles, which bypass the thread-local pool, and 90s after boot
		# is precisely when a user has finished navigating and pressed play. Observed:
		# service start 18:57:19, check fired 18:58:50, four seconds after the demuxer came
		# up on a 2160p HDR stream, which then stalled. 15s is a moment when nothing else is
		# happening; 90s is a moment when everything is.
		#
		# The delay was never the real control. Every sync monitor in this file already waits
		# on `is_playing() or pause_services`, and this is the one background job heavy enough
		# to need it most. So: keep the proven 15s, then hold for playback the same way they
		# do. Contending with a widget build only makes widgets slower; contending with a
		# video stream makes it stutter.
		monitor = kodi_utils.kodi_monitor()
		player = kodi_utils.kodi_player()
		if monitor.waitForAbort(15):
			return kodi_utils.logger('DeadLight', 'DatabaseMaintenance Service Finished')
		while player.isPlayingVideo() or kodi_utils.get_property(pause_services_prop) == 'true':
			if monitor.waitForAbort(10):
				return kodi_utils.logger('DeadLight', 'DatabaseMaintenance Service Finished')
		from caches.base_cache import check_databases_integrity
		check_databases_integrity(silent=True)
		# LOCAL PATCH 2026-09-26: weekly expired-row purge (see base_cache.purge_expired_rows). The
		# marker's own 168h expiry is the schedule, so it survives restarts with no extra setting.
		try:
			from caches.base_cache import purge_expired_rows
			from caches.main_cache import main_cache
			if main_cache.get('deadlight_expired_purge') is None:
				kodi_utils.logger('DeadLight', 'purged %d expired cache rows' % purge_expired_rows())
				main_cache.set('deadlight_expired_purge', 'done', expiration=168)
		except Exception as e: kodi_utils.logger('DeadLight', 'expired purge failed: %s' % e)
		return kodi_utils.logger('DeadLight', 'DatabaseMaintenance Service Finished')

class SyncSettings:
	def run(self):
		kodi_utils.logger('DeadLight', 'SyncSettings Service Starting')
		sync_settings()
		return kodi_utils.logger('DeadLight', 'SyncSettings Service Finished')

class OnUpdateChanges:
	def run(self):
		kodi_utils.logger('DeadLight', 'OnUpdateChanges Service Starting')
		try:
			for method in list(filter(lambda x: x[0] != 'run', inspect.getmembers(OnUpdateChanges, predicate=inspect.isfunction))):
				if not get_setting('deadlight.updatechecks.%s' % method[0], 'false') == 'true':
					method[1](self)
					set_setting('updatechecks.%s' % method[0], 'true')
		except Exception as e: kodi_utils.logger('DeadLight', 'OnUpdateChanges failed: %s' % e)
		return kodi_utils.logger('DeadLight', 'OnUpdateChanges Service Finished')

	def refresh_addon_keys(self):
		# For update 2.2.01 - 03
		from caches.trakt_cache import clear_all_trakt_cache_data
		from caches.tmdb_lists import tmdb_lists_cache
		from caches.settings_cache import restore_setting_default
		show_dialog = False
		if get_setting('deadlight.tmdb_api') == 'b370b60447737762ca38457bd77579b3':
			restore_setting_default({'silent': 'true', 'setting_id': 'tmdb_api'})
			set_setting('tmdb.token', 'empty_setting')
			set_setting('tmdb.account_id', 'empty_setting')
			set_setting('tmdb.username', 'empty_setting')
			set_setting('tmdb.session_id', 'empty_setting')
			set_setting('tmdb.account_session_id', 'empty_setting')
			tmdb_lists_cache.clear_all()
			show_dialog = True
		if get_setting('deadlight.trakt.client') == '1038ef327e86e7f6d39d80d2eb5479bff66dd8394e813c5e0e387af0f84d89fb':
			restore_setting_default({'silent': 'true', 'setting_id': 'trakt.client'})
			set_setting('trakt.user', 'empty_setting')
			set_setting('trakt.expires', '0')
			set_setting('trakt.token', '0')
			set_setting('trakt.refresh', '0')
			set_setting('trakt.next_daily_clear', '0')
			set_setting('watched_indicators', '0')
			clear_all_trakt_cache_data(silent=True, refresh=False)
			show_dialog = True
		if show_dialog:
			text = 'The original developer of DeadLight has revoked all keys (Trakt, TMDb) that have been used up until now '\
			'within this addon, with permission, due to security concerns.'
			kodi_utils.ok_dialog(heading='Addon Credentials Reset', text=text)
			text = 'This unfortunately means you will need to re-authenticate your Trakt & TMDb accounts through DeadLight AM  if you are currently using them. ' \
			'My apologies, but with the previous keys being revoked, this is necessary.'
			kodi_utils.ok_dialog(heading='Addon Credentials Reset', text=text)

	# LOCAL PATCH 2026-08-29: cm_sort_order drops any item missing from the STORED order, so
	# a new context entry is invisible on an existing install without this. Same shape as
	# register_drop_show_cm below.
	def register_anilist_manager_cm(self):
		for key in ('context_menu.enabled', 'context_menu.order'):
			stored = get_setting('deadlight.%s' % key, '')
			if not stored or 'anilist_manager' in stored.split(','): continue
			items = stored.split(',')
			try: idx = items.index('trakt_manager') + 1
			except ValueError: idx = len(items)
			items.insert(idx, 'anilist_manager')
			set_setting(key, ','.join(items))

	def register_drop_show_cm(self):
		for key in ('context_menu.enabled', 'context_menu.order'):
			stored = get_setting('deadlight.%s' % key, '')
			if not stored or 'drop_show' in stored.split(','): continue
			items = stored.split(',')
			try: idx = items.index('trakt_manager') + 1
			except ValueError: idx = len(items)
			items.insert(idx, 'drop_show')
			set_setting(key, ','.join(items))

class CustomWindowsPrepare:
	def run(self):
		kodi_utils.logger('DeadLight', 'CustomWindowsPrepare Service Starting')
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		kodi_utils.clear_property(current_skin_prop)
		# LOCAL PATCH 2026-05-26: defer the heavy windows.base_window import + ExtrasUtils().run()
		# off Kodi's critical boot path. Wait 15s for Kodi to settle, then do the one-shot init
		# and start the font-monitor loop. Cuts boot-blocking work by ~50-150ms.
		if wait_for_abort(15):
			return kodi_utils.logger('DeadLight', 'CustomWindowsPrepare Service Finished')
		from windows.base_window import FontUtils, ExtrasUtils
		# LOCAL PATCH 2026-10-15: guarded. One raise here (an empty extras_order; a skin XML Kodi holds open -> Errno 22)
		# ended the thread, and the font / skin-change watcher never ran again that session. The wait now honours abort.
		try: ExtrasUtils().run()
		except Exception as e: kodi_utils.logger('CustomWindowsPrepare', 'extras prepare failed: %s' % e)
		font_utils = FontUtils()
		while not monitor.abortRequested():
			try: font_utils.execute_custom_fonts()
			except Exception as e: kodi_utils.logger('CustomWindowsPrepare', 'custom fonts failed: %s' % e)
			if wait_for_abort(20): break
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('DeadLight', 'CustomWindowsPrepare Service Finished')

# LOCAL PATCH 2026-10-03 (3.0.8): a monitor about to sync the ACTIVE provider stamps the widgets' sync guard
# (watched_status._SYNC_GUARD_PROP, same 'provider:epoch' value), so a widget render in the next minute does not
# start the same sync a second time alongside it. Not stamped for a provider that is not the active one: the
# widgets would still need theirs.
def _stamp_widget_sync_guard(provider):
	try:
		from modules.settings import watched_indicators
		if watched_indicators() == provider: kodi_utils.set_property('deadlight.provider_sync_at', '%s:%s' % (provider, int(time())))
	except Exception: pass

class TraktMonitor:
	def run(self):
		kodi_utils.logger('DeadLight', 'TraktMonitor Service Starting')
		from apis.trakt_api import trakt_sync_activities
		from modules.settings import trakt_user_active, trakt_sync_interval, watched_indicators
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		if _wait_until_due('trakt', trakt_sync_interval()[1], wait_for_abort):   # LOCAL PATCH 2026-10-02, see _wait_until_due
			return kodi_utils.logger('DeadLight', 'TraktMonitor Service Finished')
		while not monitor.abortRequested():
			# LOCAL PATCH 2026-10-15: leave on abort. waitForAbort returns True at once while Kodi quits, and the result was
			# ignored -- so quitting (or powering off) from the screensaver or sleep, when pause_services is set, left this
			# loop spinning a core and Kodi's shutdown waiting on the thread.
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true':
				if wait_for_abort(10): break
			if monitor.abortRequested(): break
			wait_time = 1800
			try:
				sync_interval, wait_time = trakt_sync_interval()
				next_update_string = update_string % sync_interval
				# LOCAL PATCH 2026-09-12: was `if trakt_user_active:` -- the bare function
				# object, always truthy, so the 'no_auth' branch below was unreachable and a
				# de-authenticated Trakt logged 'Success' every hour. MDBListMonitor already
				# calls its equivalent. trakt_sync_activities() guards internally, so this
				# only ever mislabelled the log -- but during an auth outage that misdirects.
				if trakt_user_active():
					_stamp_widget_sync_guard(1)
					status = trakt_sync_activities()
				else: status = 'no_auth'
				if status != 'failed': _mark_synced('trakt')
				if status == 'failed': kodi_utils.logger('DeadLight', trakt_service_string % ('Failed. Error from Trakt', next_update_string))
				elif status == 'no_auth': kodi_utils.logger('DeadLight', trakt_service_string % ('Not Run. No Current Trakt Account', next_update_string))
				else:
					if status in ('success', 'no account'):
						kodi_utils.logger('DeadLight', trakt_service_string % ('Success. %s' % trakt_success_line_dict[status], next_update_string))
					else:
						kodi_utils.logger('DeadLight', trakt_service_string % ('Success. No Changes Needed', next_update_string))# 'not needed'
					# LOCAL PATCH 2026-10-03: as SIMKL below -- only when Trakt is the watched provider (1). Under MDBList the
					# hourly Trakt tick reloaded every widget for nothing on screen: 11:17:57 MDBList then 11:18:12 Trakt,
					# 17:07:27 Trakt then 17:07:42 MDBList -- two full rebuilds per tick.
					if status == 'success' and watched_indicators() == 1 \
						and get_setting('deadlight.trakt.refresh_widgets', 'false') == 'true':
						kodi_utils.auto_kodi_refresh('Trakt sync')
			except Exception as e: kodi_utils.logger('DeadLight', trakt_service_string % ('Failed', 'The following Error Occured: %s' % str(e)))
			wait_for_abort(wait_time)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('DeadLight', 'TraktMonitor Service Finished')

# LOCAL PATCH 2026-07-23: MDBList background sync — same shape as TraktMonitor.
# Runs in its own thread, polls mdbl_sync_activities on the configured interval,
# gated on mdblist_user_active + not-playing + pause-services flag.
class MDBListMonitor:
	def run(self):
		kodi_utils.logger('DeadLight', 'MDBListMonitor Service Starting')
		# LOCAL PATCH 2026-08-07 (POV OAuth port): also import mdbl_expires so we refresh
		# the OAuth access_token proactively before the next sync tick when in OAuth mode.
		# No-op when in legacy API-key mode.
		from apis.mdblist_api import mdbl_sync_activities, mdbl_expires
		from modules.settings import mdblist_user_active, mdblist_sync_interval
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		if _wait_until_due('mdblist', mdblist_sync_interval()[1], wait_for_abort):   # LOCAL PATCH 2026-10-02, see _wait_until_due
			return kodi_utils.logger('DeadLight', 'MDBListMonitor Service Finished')
		while not monitor.abortRequested():
			# LOCAL PATCH 2026-10-15: leave on abort. waitForAbort returns True at once while Kodi quits, and the result was
			# ignored -- so quitting (or powering off) from the screensaver or sleep, when pause_services is set, left this
			# loop spinning a core and Kodi's shutdown waiting on the thread.
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true':
				if wait_for_abort(10): break
			if monitor.abortRequested(): break
			wait_time = 1800
			try:
				sync_interval, wait_time = mdblist_sync_interval()
				next_update_string = update_string % sync_interval
				if mdblist_user_active():
					try: mdbl_expires()  # refresh access_token if close to expiry (OAuth mode only)
					except Exception: pass
					_stamp_widget_sync_guard(2)
					status = mdbl_sync_activities()
				else: status = 'no_auth'
				if status != 'failed': _mark_synced('mdblist')
				if status == 'failed': kodi_utils.logger('DeadLight', mdblist_service_string % ('Failed. Error from MDBList', next_update_string))
				elif status == 'no_auth': kodi_utils.logger('DeadLight', mdblist_service_string % ('Not Run. No Current MDBList Account', next_update_string))
				else:
					if status in ('success', 'no account'):
						kodi_utils.logger('DeadLight', mdblist_service_string % ('Success. %s' % mdblist_success_line_dict[status], next_update_string))
					else:
						kodi_utils.logger('DeadLight', mdblist_service_string % ('Success. No Changes Needed', next_update_string))
					if status == 'success' and get_setting('deadlight.mdblist.refresh_widgets', 'false') == 'true':
						kodi_utils.auto_kodi_refresh('MDBList sync')
			except Exception as e: kodi_utils.logger('DeadLight', mdblist_service_string % ('Failed', 'The following Error Occured: %s' % str(e)))
			wait_for_abort(wait_time)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('DeadLight', 'MDBListMonitor Service Finished')


# LOCAL PATCH 2026-07-29: SIMKL background sync — same shape as MDBListMonitor.
# Runs whenever a SIMKL account is signed in. Polls /sync/activities on the
# simkl.sync_interval; when any timestamp advances, invalidates list caches.
# Widgets are reloaded only when SIMKL is the watched provider (watched_indicators == 3).
class SIMKLMonitor:
	def run(self):
		kodi_utils.logger('DeadLight', 'SIMKLMonitor Service Starting')
		from apis.simkl_api import simkl_sync_activities
		from modules.settings import simkl_user_active, simkl_sync_interval, watched_indicators
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		if _wait_until_due('simkl', simkl_sync_interval()[1], wait_for_abort):   # LOCAL PATCH 2026-10-02, see _wait_until_due
			return kodi_utils.logger('DeadLight', 'SIMKLMonitor Service Finished')
		while not monitor.abortRequested():
			# LOCAL PATCH 2026-10-15: leave on abort. waitForAbort returns True at once while Kodi quits, and the result was
			# ignored -- so quitting (or powering off) from the screensaver or sleep, when pause_services is set, left this
			# loop spinning a core and Kodi's shutdown waiting on the thread.
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true':
				if wait_for_abort(10): break
			if monitor.abortRequested(): break
			wait_time = 1800
			try:
				sync_interval, wait_time = simkl_sync_interval()
				next_update_string = update_string % sync_interval
				if simkl_user_active():
					_stamp_widget_sync_guard(3)
					status = simkl_sync_activities()
				else: status = 'no_auth'
				if status != 'failed': _mark_synced('simkl')
				if status == 'failed': kodi_utils.logger('DeadLight', simkl_service_string % ('Failed. Error from SIMKL', next_update_string))
				elif status == 'no_auth': kodi_utils.logger('DeadLight', simkl_service_string % ('Not Run. No Current SIMKL Account', next_update_string))
				else:
					if status in ('success', 'no account'):
						kodi_utils.logger('DeadLight', simkl_service_string % ('Success. %s' % simkl_success_line_dict[status], next_update_string))
					else:
						kodi_utils.logger('DeadLight', simkl_service_string % ('Success. No Changes Needed', next_update_string))
					# LOCAL PATCH 2026-10-02: the rebuilt mirror only feeds the widgets when SIMKL is the
					# watched provider (3); under any other provider the reload changed nothing on screen.
					if status == 'success' and watched_indicators() == 3 \
						and get_setting('deadlight.simkl.refresh_widgets', 'true') == 'true':
						kodi_utils.auto_kodi_refresh('SIMKL sync')
			except Exception as e: kodi_utils.logger('DeadLight', simkl_service_string % ('Failed', 'The following Error Occured: %s' % str(e)))
			wait_for_abort(wait_time)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('DeadLight', 'SIMKLMonitor Service Finished')


# LOCAL PATCH 2026-08-29: AniList watchlist invalidation.
#
# Shorter than the Trakt/MDbList/SIMKL monitors because AniList has no sync endpoint to
# call -- it is never the primary watched-indicator provider, so there is nothing to pull
# into local tables. All this does is notice that the user changed their list somewhere
# else (the AniList app, the website) and drop the cached list pages so the next browse
# re-reads. One cheap Viewer query per interval.
class AniListMonitor:
	def run(self):
		kodi_utils.logger('DeadLight', 'AniListMonitor Service Starting')
		from apis.anilist_api import anilist_last_activity
		from caches.anilist_cache import clear_anilist_lists_cache
		from modules.settings import anilist_user_active, anilist_sync_interval
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		if _wait_until_due('anilist', anilist_sync_interval()[1], wait_for_abort):   # LOCAL PATCH 2026-10-02, see _wait_until_due
			return kodi_utils.logger('DeadLight', 'AniListMonitor Service Finished')
		while not monitor.abortRequested():
			# LOCAL PATCH 2026-10-15: leave on abort. waitForAbort returns True at once while Kodi quits, and the result was
			# ignored -- so quitting (or powering off) from the screensaver or sleep, when pause_services is set, left this
			# loop spinning a core and Kodi's shutdown waiting on the thread.
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true':
				if wait_for_abort(10): break
			if monitor.abortRequested(): break
			wait_time = 1800
			try:
				sync_interval, wait_time = anilist_sync_interval()
				next_update_string = update_string % sync_interval
				if not anilist_user_active():
					kodi_utils.logger('DeadLight', anilist_service_string % ('Not Run. No Current AniList Account', next_update_string))
				else:
					activity = anilist_last_activity()
					if activity is not None: _mark_synced('anilist')
					if activity is None:
						kodi_utils.logger('DeadLight', anilist_service_string % ('Failed. Error from AniList', next_update_string))
					elif activity != get_setting('deadlight.anilist.last_activity', ''):
						set_setting('anilist.last_activity', activity)
						clear_anilist_lists_cache()
						kodi_utils.logger('DeadLight', anilist_service_string % ('Success. AniList Lists Refreshed', next_update_string))
						if get_setting('deadlight.anilist.refresh_widgets', 'true') == 'true':
							kodi_utils.auto_kodi_refresh('AniList sync')
					else:
						kodi_utils.logger('DeadLight', anilist_service_string % ('Success. No Changes Needed', next_update_string))
			except Exception as e: kodi_utils.logger('DeadLight', anilist_service_string % ('Failed', 'The following Error Occured: %s' % str(e)))
			wait_for_abort(wait_time)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('DeadLight', 'AniListMonitor Service Finished')


# LOCAL PATCH 2026-07-29: anime-mappings DB bootstrap. Delays 8s at first
# call to let the boot sequence settle, then downloads if missing / stale.
# LOCAL PATCH 2026-08-10: Goldenfreddy Otaku-Mappings retired — its upstream
# froze 2026-05-31 and it resolved only 7 of 75 current-season items vs Fribb's
# 43, while its one unique field (mal_title) is now sourced live from AniList.
# Fribb anime-lists is the sole mapping download: mal/anilist → tmdb + season +
# episode_offset, all local (7.2 MB JSON, no per-lookup network).
# LOCAL PATCH 2026-10-05: checked every hour while Kodi runs, not once at start. A box that runs for weeks (the CoreELEC
# one) never refreshed the file at all between restarts. The check is a file date against the clock; download_mappings
# downloads only when Fribb's weekly Tuesday list is newer than our copy (fribb_mappings._needs_download). Not while a video
# plays or the services are paused, like the other monitors.
def _bootstrap_anime_mappings():
	try:
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		if monitor.waitForAbort(8): return
		from caches import fribb_mappings
		while not monitor.abortRequested():
			if not player.isPlayingVideo() and kodi_utils.get_property(pause_services_prop) != 'true':
				try: fribb_mappings.download_mappings(silent=True)
				except Exception as e: kodi_utils.logger('fribb_mappings refresh', str(e))
			if monitor.waitForAbort(3600): return
	except Exception as e:
		kodi_utils.logger('fribb_mappings bootstrap', str(e))


class UpdateCheck:
	def run(self):
		if kodi_utils.get_property(firstrun_update_prop) == 'true': return
		kodi_utils.logger('DeadLight', 'UpdateCheck Service Starting')
		from modules.settings import update_action, update_delay
		# LOCAL PATCH 2026-10-02: update action 3 is Off -- update_check() returns at once for it, so there is nothing to
		# wait for; skip the updater import and the delay loop.
		if update_action() == 3:
			kodi_utils.set_property(firstrun_update_prop, 'true')
			return kodi_utils.logger('DeadLight', 'UpdateCheck Service Finished (updates off)')
		from modules.updater import update_check
		end_pause = time() + update_delay()
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			# LOCAL PATCH 2026-10-15: every wait leaves on abort. Ignoring waitForAbort's result spun a core for the rest of
			# update.delay (10-300 s) when Kodi quit early, then ran the update check -- download and add-on reload included
			# -- during shutdown.
			aborted = False
			while not aborted and time() < end_pause: aborted = wait_for_abort(1)
			while not aborted and (kodi_utils.get_property(pause_services_prop) == 'true' or is_playing()): aborted = wait_for_abort(1)
			if aborted or monitor.abortRequested(): break
			update_check(update_action())
			break
		kodi_utils.set_property(firstrun_update_prop, 'true')
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('DeadLight', 'UpdateCheck Service Finished')

class WidgetRefresher:
	def run(self):
		kodi_utils.logger('DeadLight', 'WidgetRefresher Service Starting')
		from time import time
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, self.is_playing = monitor.waitForAbort, player.isPlayingVideo
		if wait_for_abort(10): return
		try: self.set_next_refresh(time())   # LOCAL PATCH 2026-10-15: a raise here ended the refresher for the session
		except Exception as e: kodi_utils.logger('WidgetRefresher', 'set_next_refresh failed: %s' % e)
		while not monitor.abortRequested():
			try:
				wait_for_abort(10)
				offset = int(get_setting('deadlight.widget_refresh_timer', '60'))
				if offset != self.offset:
					self.set_next_refresh(time())
					continue
				if self.condition_check(): continue
				if self.next_refresh < time():
					kodi_utils.logger('DeadLight', 'WidgetRefresher Service - Widgets Refreshed')
					kodi_utils.refresh_widgets()
					self.set_next_refresh(time())
			except: pass
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('DeadLight', 'WidgetRefresher Service Finished')

	def condition_check(self):
		if not self.external(): return True

		if self.next_refresh == None or self.is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': return True
		if kodi_utils.get_property('deadlight.window_loaded') == 'true': return True 
		try:
			window_stack = json.loads(kodi_utils.get_property('deadlight.window_stack'))
			if window_stack or window_stack == []: return True
		except: pass
		return False

	def set_next_refresh(self, _time):
		self.offset = int(get_setting('deadlight.widget_refresh_timer', '60'))
		if self.offset: self.next_refresh = _time + (self.offset*60)
		else: self.next_refresh = None

	def external(self):
		return 'plugin' not in kodi_utils.get_infolabel('Container.PluginName')

class TMDbHelperRatingsTidy:
	"""LOCAL PATCH 2026-10-14: every 6 hours, drop TMDb Helper's thin rating sets for new titles so it fetches them
	again (it keeps every set 7 days, complete or not). Rule and reasons in modules/tmdbh_ratings_tidy.py."""
	INTERVAL = 6 * 3600

	def run(self):
		from modules.tmdbh_ratings_tidy import TMDBH_DATA, find_db, tidy
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		if wait_for_abort(_BOOT_SETTLE): return
		while not monitor.abortRequested():
			while kodi_utils.get_property(pause_services_prop) == 'true' or is_playing():
				if wait_for_abort(30): return
			try: db_path = find_db(kodi_utils.translate_path(TMDBH_DATA))   # LOCAL PATCH 2026-10-15: unguarded, it could end the tidy for good
			except Exception as e:
				db_path = None
				kodi_utils.logger('TMDbHelper ratings tidy', 'database lookup failed: %s' % e)
			if db_path:
				deleted, error = tidy(db_path)
				if error: kodi_utils.logger('TMDbHelper ratings tidy', 'failed: %s' % error)
				elif deleted: kodi_utils.logger('TMDbHelper ratings tidy', '%d thin set(s) dropped for a refetch: %s' % (len(deleted), ', '.join(deleted)))
			if wait_for_abort(self.INTERVAL): return

class AutoStart:
	def run(self):
		kodi_utils.logger('DeadLight', 'AutoStart Service Starting')
		from modules.settings import auto_start_deadlight
		if auto_start_deadlight(): kodi_utils.run_addon()
		return kodi_utils.logger('DeadLight', 'AutoStart Service Finished')

class AddonXMLCheck:
	def run(self):
		kodi_utils.logger('DeadLight', 'AddonXMLCheck Service Starting')
		self.addon_xml = kodi_utils.translate_path('special://home/addons/plugin.video.deadlight/addon.xml')
		# LOCAL PATCH 2026-10-02: compare the two tags as text first. The minidom parse took 137-223 ms on the boot thread
		# (14 ms standalone -- the rest is contention with the home widgets), for a file that almost never needs a change.
		try:
			import re
			with open(self.addon_xml, 'r', encoding='utf-8') as f: text = f.read()
			def _tag(name):
				m = re.search(r'<%s>([^<]*)</%s>' % (name, name), text)
				return m.group(1) if m else None
			wanted = ((get_setting('deadlight.reuse_language_invoker', None), 'reuselanguageinvoker'),
					  (get_setting('deadlight.addon_icon_choice', None), 'icon'))
			if all(value is None or _tag(tag) == value for value, tag in wanted):
				return kodi_utils.logger('DeadLight', 'AddonXMLCheck Service Finished')
		except Exception: pass   # anything odd: the full check below decides
		from xml.dom.minidom import parse as mdParse
		self.root = mdParse(self.addon_xml)
		self.change_list = []
		self.check_property('reuse_language_invoker', 'reuselanguageinvoker')
		self.check_property('addon_icon_choice', 'icon')
		self.change_xml_file()
		return kodi_utils.logger('DeadLight', 'AddonXMLCheck Service Finished')

	def check_property(self, setting, tag_name):
		current_addon_setting = get_setting('deadlight.%s' % setting, None)
		if current_addon_setting is None: return
		tag_instance = self.root.getElementsByTagName(tag_name)[0].firstChild
		current_property = tag_instance.data
		if current_property != current_addon_setting:
			tag_instance.data = current_addon_setting
			self.change_list.append(tag_name)

	def change_xml_file(self):
		if not self.change_list: return
		if 'icon' in self.change_list: self.reassign_addon_icon()
		kodi_utils.notification('Refreshing Addon XML. Restarting Addons')
		new_xml = str(self.root.toxml()).replace('<?xml version="1.0" ?>', '')
		# Explicit UTF-8: open(...,'w') uses the platform codec, which on Windows is
		# cp1252 and TRUNCATES addon.xml to 0 bytes on any character outside it -
		# and this runs automatically, so Kodi would simply stop loading the add-on.
		import io as _io, os as _os
		# LOCAL PATCH 2026-10-15: written whole or not at all (tmp + os.replace, as _mark_synced). An in-place write
		# truncates first, so a crash / power cut / kill in between left addon.xml empty and Kodi stopped loading the add-on.
		_tmp = self.addon_xml + '.tmp'
		with _io.open(_tmp, 'w', encoding='utf-8', newline='') as f: f.write(new_xml)
		_os.replace(_tmp, self.addon_xml)
		kodi_utils.logger('DeadLight', 'AddonXMLCheck Service - Change Detected. Restarting Addons')
		kodi_utils.execute_builtin('ActivateWindow(Home)', True)
		kodi_utils.update_local_addons()
		kodi_utils.disable_enable_addon()

	def reassign_addon_icon(self):
		from indexers.dialogs import addon_icon_choice
		# LOCAL PATCH 2026-09-05: fallback must name a file that exists. It said
		# deadlight_icon_01.png, and after the artwork was renamed to deadlight_* a
		# fresh settings.db (no addon_icon_choice_name row yet) made this rewrite
		# <icon> to a missing file, leaving the add-on with no tile at all.
		addon_icon_choice({'set_icon': get_setting('addon_icon_choice_name', 'deadlight_icon_09.png')})

class DeadLightMonitor(Monitor):
	def __init__ (self):
		Monitor.__init__(self)
		self.startServices()

	# LOCAL PATCH 2026-10-09: no onSettingsChanged pull -- Kodi holds no copy of DeadLight's settings any more (settings.xml is
	# one button that opens DeadLight's window), so there is nothing to bring back into settings.db.

	# LOCAL PATCH 2026-08-31: these handlers called a bare logger(), which this module never
	# imports -- it only imports kodi_utils. Any genuine startup failure therefore raised
	# NameError from inside its own except block, hiding the real error and propagating out
	# of __init__, so a transient service fault could take the whole service down.
	def startServices(self):
		try: SetAddonConstants().run()
		except Exception as e: kodi_utils.logger('SetAddonConstants', str(e))
		# LOCAL PATCH 2026-05-26: DatabaseMaintenance moved from synchronous boot path to a
		# background thread (with internal 15s delay inside .run()). Saves 100-500ms of boot.
		Thread(target=DatabaseMaintenance().run).start()
		try: SyncSettings().run()
		except Exception as e: kodi_utils.logger('SyncSettings', str(e))
		try: OnUpdateChanges().run()
		except Exception as e: kodi_utils.logger('OnUpdateChanges', str(e))
		try: AddonXMLCheck().run()
		except Exception as e: kodi_utils.logger('AddonXMLCheck', str(e))
		Thread(target=CustomWindowsPrepare().run).start()
		Thread(target=TraktMonitor().run).start()
		# LOCAL PATCH 2026-07-23: MDBList sync monitor runs alongside Trakt.
		Thread(target=MDBListMonitor().run).start()
		# LOCAL PATCH 2026-07-29: SIMKL sync monitor (4th watched-indicator provider).
		Thread(target=SIMKLMonitor().run).start()
		Thread(target=AniListMonitor().run).start()
		# LOCAL PATCH 2026-07-29: anime-mappings bootstrap -- since 2026-08-10 this is the Fribb
		# mapping file (caches/fribb_mappings), not the old anime-mappings DB the function is
		# still named after. Fetched on first run, then checked hourly against Fribb's Tuesday release (2026-10-05).
		Thread(target=_bootstrap_anime_mappings).start()
		Thread(target=UpdateCheck().run).start()
		Thread(target=WidgetRefresher().run).start()
		Thread(target=TMDbHelperRatingsTidy().run).start()
		try: AutoStart().run()
		except Exception as e: kodi_utils.logger('AutoStart', str(e))

	def onNotification(self, sender, method, data):
		if method in ('GUI.OnScreensaverActivated', 'System.OnSleep'):
			kodi_utils.set_property(pause_services_prop, 'true')
			kodi_utils.logger('OnNotificationActions', 'PAUSING DeadLight Services Due to Device Sleep')
		elif method in ('GUI.OnScreensaverDeactivated', 'System.OnWake'):
			kodi_utils.clear_property(pause_services_prop)
			kodi_utils.logger('OnNotificationActions', 'UNPAUSING DeadLight Services Due to Device Awake')

kodi_utils.logger('DeadLight', 'Main Monitor Service Starting')
DeadLightMonitor().waitForAbort()
kodi_utils.logger('DeadLight', 'Main Monitor Service Finished')
