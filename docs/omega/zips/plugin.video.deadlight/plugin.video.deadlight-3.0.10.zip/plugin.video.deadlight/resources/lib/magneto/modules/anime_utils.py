# -*- coding: utf-8 -*-
"""Anime release-name parsing, shared by the magneto providers.

LOCAL PATCH 2026-08-27. Extracted verbatim from providers/torrents/nyaa.py, which
was the only place in magneto that could read an anime release name. comet needs
the same parsing for its kitsu path, and duplicating it would have meant two
copies of some very fiddly regexes drifting apart.

Nothing here is new and nothing existing changed behaviour: source_utils.check_title
and the rest of the shared matcher are untouched, so non-anime scraping is
unaffected. The names keep their leading underscores so nyaa.py needed no edits
beyond the import.

What this handles that the western matcher cannot:
  - season markers inside brackets: "(Season 3)", "[S01-02]"
  - the absolute-numbering convention: "S03E20.(57)" is ONE episode, not 20-57
  - bare ordinals: "Re:Zero ... 4th - 01~11" is season 4
  - cour/part ranges: "Season 3 Part 2 - 01 ~ 10"
"""
import re


_TOKEN_STOPWORDS = frozenset((
	'the', 'and', 'of', 'a', 'an', 'in', 'on', 'to', 'for',
	'season', 'part', 'cour', 'movie', 'ova', 'tv', 'anime',
	'no', 'wa', 'ga', 'ni', 'wo', 'ka', 'kara', 'made',
))

_ROMAN_MAP = {'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5}
_WORD_MAP = {'first': 1, 'second': 2, 'third': 3, 'fourth': 4, 'fifth': 5,
			 'sixth': 6, 'seventh': 7, 'eighth': 8}

# Otaku-style: strip quality/codec/audio noise BEFORE regex-extracting season/ep.
_NOISE_PATTERNS = re.compile(
	r'\b(?:360p|480p|576p|720p|1080p|1440p|2160p|4k)(?!\d)'
	r'|\b10\s?bits?\b'
	r'|\b(?:h\.?\s?264|x\.?\s?264|h\.?\s?265|x\.?\s?265|hevc|avc|hls|vp9|av1)(?!\d)'
	r'|\b(?:web-dl|webrip|bluray|hdrip|dvdrip|hdtv|pdtv|cam|screener|bdrip)\b'
	r'|\b(?:hdr10\+?|hdr|sdr|dv|dolby\s?vision|dovi)\b'
	r'|\b(?:mp4|mkv|mpeg|xvid|divx|wmv|flac)\b'
	r'|\b(?:aac|mp3|opus|ddp|dd|ac3|dts(?:-hdma|-hdhr|-x)?|atmos|truehd)(?:\d+(?:\.\d+)?)?\b'
	r'|\b(?:1\.0|2\.0|5\.1|7\.1|2ch|5ch|7ch|8ch)\b'
	r'|\b(?:multi\s?audio|dual\s?audio|dub(?:bed)?|multi\s?sub|subbed|multi[- ]?sub(?:title)?s?)\b'
	, re.I
)


def _tokenize(text):
	"""Lowercase word tokens of length >=3, stopwords removed."""
	if not text: return set()
	words = re.findall(r'[A-Za-z0-9]+', str(text).lower())
	return {w for w in words if len(w) >= 3 and w not in _TOKEN_STOPWORDS}


# LOCAL PATCH 2026-08-27: contiguous title matching.
#
# The accept_tokens guard below accepts a row when it shares ANY ONE token with the
# title set. For Re:ZERO that set is {zero, starting, life, another, world, different,
# from}, so a single generic word was enough and these all came through as Re:ZERO:
#
#   Fate.Zero / Aldnoah.Zero / Eden.Zero / Ga-Rei-Zero / Zero.no.Tsukaima   (zero)
#   The.World's.Finest.Assassin...                                        (world)
#   Steins;Gate / Our.Dating.Story...                                     (one word)
#
# Overlap SIZE cannot separate them: the romaji 'Re:Zero kara Hajimeru Isekai
# Seikatsu' also shares exactly one token (zero) and is legitimate. What does separate
# them is ADJACENCY -- a real release contains a title candidate as consecutive words.
# 'Ga Rei Zero' never contains the pair (re, zero); 'Re Zero kara ...' always does.
#
# Measured over 6 shows / 211 accepted rows: drops exactly the 10 wrong-show entries,
# keeps all 201 legitimate ones.
#
# Apostrophes are deleted rather than treated as separators so that TMDb's
# "Journey's End" and a group's "Journeys.End" produce the same token run.
_APOS = re.compile('[' + chr(39) + chr(0x2019) + chr(0x02BC) + ']')


def _title_seq(text):
	"""Ordered alphanumeric word run. Keeps short words -- adjacency needs them."""
	return re.findall(r'[a-z0-9]+', _APOS.sub('', str(text or '').lower()))


# What may legally sit next to a title match. Anything else means the name belongs to
# a DIFFERENT, longer-titled show: 'Boruto - Naruto Next Generations' and 'Naruto
# Shippuden' both contain 'Naruto' and are separate TMDb shows, so plain containment
# lets them answer a Naruto request.
_TITLE_EDGE_OK = re.compile(
	r'^(?:\d+|\d+(?:st|nd|rd|th)|s\d+\w*|e\d+|v\d+|ep\d*|complete|series|batch|collection|season|seasons|'
	r'part|parts|pt\d*|cour|vol|volume|movie|movies|ova|oad|oav|special|specials|nc\w*|'
	r'bd|bdrip|bdmv|bluray|blu|ray|web|webrip|webdl|dl|dvd|dvdrip|remux|hevc|avc|hdr|'
	r'x264|x265|h264|h265|av1|xvid|aac|flac|opus|ac3|eac3|dts|truehd|dual|multi|'
	r'eng|jpn|jap|esp|ita|fre|ger|por|sub|subs|subbed|subtitle|subtitles|dub|dubbed|'
	r'raw|final|arc|the|and|uncut|uncensored|censored|repack|proper|hi10|10bit|8bit|'
	# LOCAL PATCH 2026-08-27: the same structural words in the other languages release
	# groups use. Without them a legitimate 'Naruto (Integrale) VOSTFR' was rejected,
	# because 'integrale' looked like a word from some other show's title.
	r'integrale|integral|integrali|complet|completa|completo|completos|coffret|'
	r'stagione|saison|temporada|staffel|sezon|serie|boxset|vostfr|truefrench|'
	r'castellano|latino|dublado|legendado)$',
	re.I)


def _seq_matches(name_seq, cand_seqs):
	"""True when any candidate matches the row, as consecutive words or joined.

	A match must sit on clean boundaries. Without that, containment alone makes every
	longer show name that happens to include ours look like a hit -- a Naruto scrape
	filled up with 'Boruto - Naruto Next Generations' and 'Naruto Shippuden', both
	separate TMDb shows. Having several candidates makes this cheap to satisfy: only
	one of them has to match cleanly, so 'Attack on Titan (Shingeki no Kyojin) - 01'
	still passes on the alias even though the primary title is followed by a word.

	The joined form covers groups that drop separators entirely:
	  'Attack.on.TitanShingeki.no.Kyojin...' -> (.., titanshingeki, ..)
	  'SPYFAMILY../.SPYxFAMILY.-.01...'      -> the × in SPY×FAMILY is stripped
	It cannot honour boundaries, so it needs a length that cannot collide by accident:
	at 6 it matched 'naruto' inside 'borutonarutonextgenerations' and readmitted every
	row the boundary check had just rejected. 10 still covers both cases above
	("attackontitan", "spyxfamily").
	"""
	if not cand_seqs: return True
	# LOCAL PATCH 2026-08-27: a neighbouring word belonging to one of OUR OWN candidate
	# titles is not evidence of a different show. Release names carry the title twice in
	# two forms all the time -- 'Naruto/NARUTO --][001-220TV][BOX1-8]' -- and the plain
	# edge rule read the second copy as a foreign title word and threw the row away.
	# This cannot readmit what the rule exists to block: 'boruto' and 'shippuden' are not
	# words of the Naruto candidates, so those still reject.
	cand_words = set(w for c in cand_seqs for w in c)
	for cand in cand_seqs:
		n = len(cand)
		if not n or n > len(name_seq): continue
		for i in range(len(name_seq) - n + 1):
			if name_seq[i:i + n] != cand: continue
			before = name_seq[i - 1] if i > 0 else None
			after = name_seq[i + n] if i + n < len(name_seq) else None
			# a short neighbour is noise ('Naruto HD (001-220)'), a long one is a title word
			if before is not None and len(before) >= 4:
				if not _TITLE_EDGE_OK.match(before) and before not in cand_words: continue
			if after is not None and len(after) > 2:
				if not _TITLE_EDGE_OK.match(after) and after not in cand_words: continue
			return True
	joined = ''.join(name_seq)
	for cand in cand_seqs:
		cj = ''.join(cand)
		if len(cj) >= 10 and cj in joined: return True
	return False


_BRACKET_GROUP = re.compile(r'\[(.*?)\]|\((.*?)\)')
# Bracketed episode ranges have to survive too: '(26-50)' is how a season-2 batch is
# labelled when the group counts episodes from the start of the series. Stripping it
# left no episode at all, so the row read as a bare batch and matched every episode
# of every season. The lookarounds are what exclude year spans: without them
# '2011-2018' still matches, because \d{1,3} happily binds to '011-201' inside it.
# LOCAL PATCH 2026-09-22: the endpoints may carry an 'E'. '[sam] ... (S01) (E01-E12)'
# put its only episode range inside a bracket group, and with no bare digit on either
# side of the dash this pattern did not match, so the group was discarded whole and the
# pack read as a bare batch -- then offered for E13 and E14, which it cannot hold. The
# 'S01 E18-E25' form never showed this, because _PK_RNG_SE reads that off the
# unbracketed text before bracket handling matters.
_RANGEISH = re.compile(r'(?<![\da-z])e?\d{1,3}\s*(?:[-~]|\bto\b)\s*e?\d{1,3}(?!\d)', re.I)
_SEASONISH = re.compile(r'\bseason\b|\bs\d{1,2}|\bcour\b|\bpart\b|\d{1,2}(?:st|nd|rd|th)\s*season', re.I)
# LOCAL PATCH 2026-10-06: 'season' in Italian, French, Spanish / Portuguese, German, Polish / Turkish, Dutch, Swedish, Danish /
# Norwegian, Finnish and Russian, followed by its number (_clean_for_extract); Chinese 第2季 ('season 2').
_FOREIGN_SEASON = re.compile(r'(?<![a-z0-9])(?:stagione|saison|temporada|staffel|sezon|seizoen|s[aä]song|s[aæ]son|kausi|сезон)(?=[\s._-]*\d)', re.I)
_CJK_SEASON = re.compile(r'第\s*(\d{1,2})\s*季')


def _keep_if_seasonish(m):
	"""Keep a bracket group's text when it carries season/part info, else drop it."""
	inner = m.group(1) if m.group(1) is not None else m.group(2)
	if inner and (_SEASONISH.search(inner) or _RANGEISH.search(inner)):
		return ' ' + inner + ' '
	return ' '


def _clean_for_extract(name):
	"""Strip quality/codec/audio noise + brackets so numeric extraction is unambiguous.
	magneto's clean_name has already converted spaces to dots; we normalize back."""
	s = name.lower().replace('.', ' ').replace('_', ' ')
	# LOCAL PATCH 2026-10-06: 'season' in other languages reads as 'season' -- Hunter x Hunter S1E1 kept comet's
	# '(Stagione.3).(ITA.JPN.1080p.WEB-DL.x264).[UBi]' as a season-1 pack, where 'Season 3' / 'S03' was refused. Done before
	# the bracket pass, so '(Stagione.2)' is kept by _SEASONISH like '(Season 2)'.
	s = _FOREIGN_SEASON.sub('season', s)
	s = _CJK_SEASON.sub(lambda m: ' season %s ' % m.group(1), s)
	# LOCAL PATCH 2026-08-27: was a blanket strip of every (...) and [...] group.
	# That also deleted the season, because plenty of groups write it inside the
	# brackets: 'Re:Zero kara Hajimeru Isekai Seikatsu (Season 3) [1080p]' reduced
	# to 're zero kara hajimeru isekai seikatsu'. With no season parsed, the guard
	# in sources() ('if seasons and season_num not in seasons') sees an empty set,
	# reads it as 'makes no season claim', and lets the row through -- so every
	# (Season N) release surfaced under every season. Unbracketed 'S03' was fine,
	# which is why this hid for so long.
	#
	# Groups whose text mentions a season/part/cour keep their contents (brackets
	# dropped); everything else is still discarded, so quality tags and CRC32
	# stamps cannot leak digits into episode parsing. CRC32 is hex, so it cannot
	# contain the 's' that _SEASONISH needs.
	s = _BRACKET_GROUP.sub(_keep_if_seasonish, s)
	# A truncated name can leave an UNCLOSED bracket, which the pattern above cannot
	# match and therefore cannot remove. comet cuts long filenames at ~70 chars:
	#   'Re-Zero-...-3rd-season--16-(BS11-1920x1080-..'
	# leaving '(bs11-1920x1080-' in the text, where the episode scan read '11-1920'
	# as a range and matched practically any episode. Cut from the stray opener on.
	s = re.sub(r'[(\[][^)\]]*$', ' ', s)
	s = _NOISE_PATTERNS.sub(' ', s)
	s = re.sub(r'\s+', ' ', s).strip()
	return s


# Unified extractors — run on the CLEANED text.
_EX_SEASON = re.compile(r'\bs(?:eason)?[ ._-]?(\d{1,2})(?!\d)', re.I)
_EX_SEASON_ORD = re.compile(r'\b(\d{1,2})(?:st|nd|rd|th)\s+season\b', re.I)
# LOCAL PATCH 2026-08-27: bare ordinal season, used ONLY as a fallback (see below).
# Anime releases frequently drop the word 'season' entirely -- 'Re:Zero kara Hajimeru
# Isekai Seikatsu 4th - 01~11][67~77]' is season 4, and 'Spy x Family 2nd - 01' is
# season 2. Both were parsed as making no season claim, so they passed the season
# guard for every season and showed up under season 1.
#
# The negative lookahead skips ordinals that are not seasons ('10th Anniversary',
# '2nd Movie', '4th Plate'). Checked over 6 shows / 211 rows: every bare-ordinal hit
# was a real season marker, and the ones already carrying the word 'season' are
# resolved by _EX_SEASON_ORD first, so this never runs on them.
# LOCAL PATCH 2026-08-27: season RANGE, e.g. '[S01-02]', 'S01-S04', 'S1-S3'.
# _EX_SEASON alone matched just the 's01' and left the '-02' dangling, which the
# episode pass then read as episode 2 -- so an S01-04 complete-series pack announced
# itself as episode 2 and matched nothing else. Both endpoints are taken and the
# span expanded, which is what a multi-season pack actually covers.
# Requires the dash straight after the season number, so 'S02E06-08' (an EPISODE
# range) and 'S01.E01-E14' are left for the episode logic.
# LOCAL PATCH 2026-08-27: a season RANGE needs the 's' on both ends, or no spaces
# around the separator. Without that constraint the extremely common anime form
# 'Attack on Titan S3 - 08' parsed as seasons 3 THROUGH 8: the episode number was
# read as the far end of a season range. Every such release then looked like a
# six-season batch with no episode information, so it was accepted for virtually
# any request -- part 1 episodes answering part 2, and worse. Real season ranges
# are written 'S01-S04', 'S01 - S04' or 'S01-04'; all still match.
_EX_SEASON_RANGE = re.compile(r'\bs(\d{1,2})(?:\s*[-~]\s*s|[-~])(\d{1,2})\b', re.I)
_EX_SEASON_ORD_BARE = re.compile(r'\b(\d{1,2})(?:st|nd|rd|th)\b(?!\s*(?:anniversary|ann\b|movie|ova|special|plate))', re.I)
_EX_SEASON_ACT = re.compile(r'\bact\s+(i{1,3}v?|iv|v)\b', re.I)
_EX_SEASON_WORD = re.compile(r'\b(first|second|third|fourth|fifth|sixth|seventh|eighth)\s+season\b', re.I)
# Roman numeral as standalone token — used only when NO other season signal found.
# Catches "Mushoku Tensei III", "Overlord IV", "Attack on Titan II" style sequel naming.
# Skips bare "I" (too false-positive-prone: single letter, common in titles).
_EX_SEASON_ROMAN = re.compile(r'\b(ii|iii|iv|v|vi|vii|viii)\b', re.I)
_EX_PART = re.compile(r'\b(?:part|cour)\s?(\d+)\b', re.I)
_EX_SXX_EYY = re.compile(r's(\d{1,2})e(\d{1,4})', re.I)
# The trailing guard keeps a resolution out of the range: in 'x264-1920x1080' the
# pair 264-1920 otherwise parses as an episode range covering 1657 episodes.
# LOCAL PATCH 2026-08-27: 'to' joins a range as well as '-' and '~'. Without it a
# pack named 'NARUTO (2002) - Episodes 031 to 040' yielded no episode numbers at
# all, so cour_match fell through to its batch rule and accepted it for ANY
# episode -- it was answering requests for episode 159. With the range parsed the
# same pack is correctly rejected for 159 and correctly accepted for 35.
# LOCAL PATCH 2026-09-22: optional 'E' on either endpoint, so 'E01-E12' reads the same
# as '01-12'. The lookbehind stops the first number binding to the tail of a word.
_EX_EP_RANGE = re.compile(r'(?<![a-z])e?(\d{1,4})\s*(?:[~\-]|\bto\b)\s*e?(\d{1,4})(?![\dxp])', re.I)
_EX_EP_DASH = re.compile(r'(?:^|\s)-\s*(\d{1,4})(?!\d)')
# LOCAL PATCH 2026-09-22: a span BOUND TO a volume/box/disc word counts volumes, not
# episodes. '(Vol 01-02)' is two Blu-ray volumes and 'Vol.01~04' is four, but both
# parsed as episodes 1-2 and 1-4, so a 150-file BD set was rejected for every episode
# from 3 up.
#
# The binding is the whole point, and the reason this is not a name-wide test: Naruto's
# '[DBD-Raws][193-220TV][BOX8]' and '[001-027TV][Vol.01]' carry a REAL episode range in
# a token separate from the volume marker, and 9 such packs parse correctly today.
# Suppressing any range that merely shares a name with 'BOX' would destroy them, so only
# the digits the volume word itself introduces are removed.
_EX_VOLUME_SPAN = re.compile(r'\b(?:vol|volume|box|disc|disk|set)[^a-z0-9]{0,2}\d{1,3}(?:\s*(?:[-~]|\bto\b)\s*\d{1,3})?', re.I)
_EX_EP_PREFIX = re.compile(r'\b(?:episode|ep|e)\s*(\d{1,4})(?!\d)', re.I)


def _strip_season_ranges(text, seasons=None):
	"""Remove genuine season ranges ("S01-02", "S01-S04") and record them.

	Only spans that validate are removed. The pattern also matches a season marker
	followed by an episode range -- 'S2 - 01~10' looks like s=2..01 -- and blanket
	removal there destroyed both the S2 marker and the episode range, so the row
	ended up with no season and no episode at all."""
	out, last = [], 0
	for m in _EX_SEASON_RANGE.finditer(text):
		try: a, b = int(m.group(1)), int(m.group(2))
		except (TypeError, ValueError): continue
		if not (0 < a < b <= 50): continue   # descending or implausible: not a season range
		if seasons is not None: seasons.update(range(a, b + 1))
		out.append(text[last:m.start()]); out.append(' '); last = m.end()
	out.append(text[last:])
	return ''.join(out)


def _extract_meta(cleaned):
	"""Return (seasons:set, episodes:set|None, part_nums:set, is_range:bool).
	episodes is None when no episode number could be pulled — bare batches."""
	seasons = set()
	episodes = set()
	parts = set()
	is_range = False

	# --- season ---
	# LOCAL PATCH 2026-08-27: ORDER MATTERS here. The '<N>th season' / 'second
	# season' / 'act II' forms are read and then REMOVED before the plain
	# 'season <N>' scan, because otherwise the number that follows them is counted
	# as a second season:
	#   'Re:Zero ... 2nd Season 1~13' -> ORD gives 2, then _EX_SEASON matches
	#   'Season 1' out of 'Season 1~13', where that 1 opens the EPISODE range.
	# That produced seasons={1,2}; the guard in sources() only needs the requested
	# season to appear somewhere in the set, so a season-2 batch passed a season-1
	# scrape. Consuming the explicit forms first leaves nothing for the plain scan
	# to misread.
	_season_scan = cleaned
	_season_scan = _strip_season_ranges(_season_scan, seasons)
	for m in _EX_SEASON_ORD.finditer(_season_scan):
		try: seasons.add(int(m.group(1)))
		except: pass
	_season_scan = _EX_SEASON_ORD.sub(' ', _season_scan)
	for m in _EX_SEASON_WORD.finditer(_season_scan):
		w = m.group(1).lower()
		if w in _WORD_MAP: seasons.add(_WORD_MAP[w])
	_season_scan = _EX_SEASON_WORD.sub(' ', _season_scan)
	for m in _EX_SEASON_ACT.finditer(_season_scan):
		r = m.group(1).lower()
		if r in _ROMAN_MAP: seasons.add(_ROMAN_MAP[r])
	_season_scan = _EX_SEASON_ACT.sub(' ', _season_scan)
	for m in _EX_SEASON.finditer(_season_scan):
		try: seasons.add(int(m.group(1)))
		except: pass
	# Fallback: bare ordinal ('4th', '2nd') when nothing above claimed a season.
	if not seasons:
		for m in _EX_SEASON_ORD_BARE.finditer(cleaned):
			try:
				seasons.add(int(m.group(1)))
				break   # first hit only, as with the Roman fallback
			except: pass

	# Fallback: standalone Roman numeral only if we found no other season signal.
	# Guards against false positives from titles that legitimately contain Roman numerals.
	if not seasons:
		_ROMAN_STANDALONE = {'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7, 'viii': 8}
		for m in _EX_SEASON_ROMAN.finditer(cleaned):
			r = m.group(1).lower()
			if r in _ROMAN_STANDALONE:
				seasons.add(_ROMAN_STANDALONE[r])
				break   # only take first hit to avoid double-counting "II" + "III"

	# --- parts ---
	for m in _EX_PART.finditer(cleaned):
		try: parts.add(int(m.group(1)))
		except: pass

	# --- episode ---
	# Remove already-consumed markers so digits inside them don't leak as episodes.
	# LOCAL PATCH 2026-08-27: 'S02E06-08' spans three episodes, but _EX_SXX_EYY
	# below matches only 's02e06' and consumes it, orphaning the '-08' -- so the
	# file registered as episode 6 alone and never matched a request for 7 or 8.
	# _PK_RNG_SE is the pattern _pack_shape already uses for exactly this shape,
	# and it deliberately does NOT match the anime absolute form 'S03E20.(57)'.
	work = cleaned
	for m in _PK_RNG_SE.finditer(cleaned):
		try: a, b = int(m.group(1)), int(m.group(2))
		except: continue
		if 0 < a < b <= 999:
			episodes.update(range(a, b + 1))
			is_range = True
	if is_range: work = _PK_RNG_SE.sub(' ', work)
	work = _EX_SXX_EYY.sub(lambda m: episodes.add(int(m.group(2))) or ' ', work)
	work = _EX_PART.sub(' ', work)
	# LOCAL PATCH 2026-08-27: season markers have to go too, for the same reason
	# the line above removes parts -- otherwise their digits are read as episodes.
	# 'Shingeki no Kyojin Season 2 - 11' parsed as the RANGE 2-11, so one episode-11
	# file matched every request from 2 to 11; and 'Season 3 - 01 ~ 12' matched
	# '3 - 01' first, which is descending, so the real 01~12 range was never seen.
	# _EX_SEASON_ORD goes FIRST for the same reason it does in the season scan:
	# in '2nd Season 1~13' the plain _EX_SEASON matches 'Season 1' and removing it
	# would swallow the 1 that opens the episode range, leaving a bare '~13'.
	work = _strip_season_ranges(work)   # valid ranges only; see above
	for _rx in (_EX_SEASON_ORD, _EX_SEASON_WORD, _EX_SEASON,
					 _EX_SEASON_ORD_BARE):
		work = _rx.sub(' ', work)

	# A volume/box span is not an episode span -- see _EX_VOLUME_SPAN.
	work = _EX_VOLUME_SPAN.sub(' ', work)

	# episode range like "01-24" or "01~47"
	rng = _EX_EP_RANGE.search(work)
	if rng:
		try:
			a, b = int(rng.group(1)), int(rng.group(2))
			if 0 < a < b <= 9999:
				episodes.update(range(a, b + 1))
				is_range = True
		except: pass

	if not episodes:
		# "- 12", "-12", " 12 "
		for m in _EX_EP_DASH.finditer(work):
			try: episodes.add(int(m.group(1)))
			except: pass
	# always-good prefix: "E12", "Ep 12", "Episode 12"
	for m in _EX_EP_PREFIX.finditer(work):
		try: episodes.add(int(m.group(1)))
		except: pass

	return seasons, (episodes or None), parts, is_range


# LOCAL PATCH 2026-08-27: nyaa.si is blocked here by TWO independent mechanisms,
# which is why fixing one was not enough. Measured on this network:
#
#   nyaa.si                 DNS sinkhole (resolved to an ISP IP that drops packets).
#                           After fixing DNS an SNI/DPI reset ALSO applies: TCP
#                           connects, TLS with SNI=nyaa.si is RST, TLS with any
#                           other SNI to the SAME IP completes. Intermittent --
#                           5/8 handshakes, 2/6 real searches.
#   nyaa.media              8/8 handshakes, 1.6s median, BUT broken query semantics
#                           (see the ordering note below) -- fallback only.
#   nyaa-si.translate.goog  Google Translate proxy. Immune to an SNI filter on
#                           nyaa.si because the SNI on the wire says translate.goog.
#                           Needs the _x_tr_* params appended. ~2.0s.
#   nyaa.land, nyaa.iss.one Cloudflare 403 on /search, and 502. Not usable.
#
# Try hosts in order, keep the first that answers, remember it for the Kodi session.
# A window property rather than a module global: DeadLight runs with
# reuselanguageinvoker=false, so module state dies with every plugin invocation and
# a global would re-probe a dead host on every scrape.
# ORDER MATTERS, and it is about SEARCH SEMANTICS, not speed. This provider batches
# episode/batch variants into few requests using Nyaa's OR syntax
# (`title "Batch"|"Complete"|"S01"|...`). nyaa.media is reachable and marginally
# faster but does NOT implement those semantics -- measured:
#
#            query                        nyaa.media   translate.goog
#            "Frieren"                        55            75
#            "Frieren Batch"                  55  <-same     28  <-correctly narrower
#            'Frieren "Batch"|"Complete"'     27            29
#            '"Batch"|"Complete"'             27  <-same     75
#
# It ignores extra AND terms and mangles OR, so the batch queries silently collapse.
# Real cost: the BluRay season packs vanish -- Frieren 0 hits vs 75 (10 BluRay),
# Mushoku Tensei 0 vs 75 (18 BluRay), Tongari Boushi 11/0 vs 75/6.
#
# translate.goog proxies the REAL nyaa.si, so its semantics are correct, and its SNI
# reads translate.goog which sidesteps the filter on nyaa.si. It leads for correctness.
# nyaa.media stays as a fallback: still useful for plain single-title searches if the
# proxy is unavailable.
# LOCAL PATCH 2026-08-27: anime-aware pack shape test.
#
# source_utils.filter_season_pack is written for western release names and misreads
# the anime absolute-numbering convention. "Attack.on.Titan.S03E20.(57)" means
# season 3 episode 20, which is episode 57 counted from the series start; after
# release_title_format strips the brackets it reads as "s03e20.57" and the helper's
# range regex `s\d+e(\d+)[-.](\d+)` reports "episodes 20 through 57".
#
# Measured on real scrapes: 23 of 32 AoT S3 "season packs" and 24 of 33 Jujutsu
# Kaisen S2 ones were single episodes carrying fabricated ranges. DeadLight offers
# any pack whose range covers the wanted episode (scrapers/external.py), so asking
# for episode 25 would hand the user a torrent holding only episode 20 -- the debrid
# file filter then matches nothing and playback fails with no explanation.
#
# So the range that filter_season_pack reports is discarded and recomputed here.
# Verified 18/18 on a table of real nyaa names covering both conventions.
_PK_ABS_EP = re.compile(r's\d{1,3}[._ ]?e\d{1,3}[._ ]*[(\[]\d{1,4}[)\]]', re.I)
_PK_RNG_SE = re.compile(r's\d{1,3}[._ ]?e(\d{1,3})[._ ]*[-~][._ ]*e?(\d{1,3})(?![\dp])', re.I)
# The second number sits in a LOOKAHEAD so a junk match ("Part.2.-.01") does not
# consume the digits that begin the real range ("01.~.10") -- finditer would
# otherwise resume past them and never see it.
_PK_RNG_BARE = re.compile(r'(?<![\d])(\d{1,3})[._ ]*[-~][._ ]*(?=(\d{1,3})(?:[\s.\])]|$))')


def _pk_first_valid(rx, text, min_span=1):
	"""First ascending, plausible pair -- earlier matches are often junk."""
	for m in rx.finditer(text):
		try: a, b = int(m.group(1)), int(m.group(2))
		except Exception: continue
		if 0 < a < b <= 999 and (b - a) >= min_span: return a, b
	return 0, 0


# LOCAL PATCH 2026-10-03: moved from nyaa.py so every provider tags batches the same way; capture groups added so the
# season span is known. 'Season 1 + 2', 'S01-S02', 'Seasons 1-3' -- a batch of more than one season. A bare second
# number only after 'Seasons' or a '+'/'and': in 'Season 2 - 01-12' and 'S2 - 05' it is an episode.
_MULTI_SEASON = re.compile(
	r'\bseasons\s*0*(\d{1,2})\s*(?:-|~|\+|&|and)\s*0*(\d{1,2})\b'
	r'|\bseason\s*0*(\d{1,2})\s*(?:\+|&|and)\s*(?:season\s*)?0*(\d{1,2})\b'
	r'|\b(?:season\s*|s)0*(\d{1,2})\s*(?:-|~|\+|&)\s*(?:season\s*|s)0*(\d{1,2})\b', re.I)

def multi_season_span(name):
	"""(first, last) seasons a multi-season batch names, or None."""
	m = _MULTI_SEASON.search(name.replace('.', ' '))
	if not m: return None
	nums = [int(g) for g in m.groups() if g is not None]
	if len(nums) != 2 or not 0 < nums[0] < nums[1] <= 50: return None
	return nums[0], nums[1]

def batch_fields(name, episodes, is_range, season_length=None):
	"""LOCAL PATCH 2026-10-03: the item keys for a batch, {} for a single episode. Inputs are _extract_meta's (episodes,
	is_range), so no name is read differently. DeadLight divides a pack's size by 'pack_episodes': the name's own range,
	else the release season's length (data['season_length']) for a one-season batch; absent, DeadLight uses TMDb's count.
	A multi-season batch is a 'show' pack carrying its seasons, and its range too when it names one ('Seasons 1-3 (001-075)')."""
	if episodes is not None and not is_range: return {}
	span = multi_season_span(name)
	if span:
		out = {'package': 'show', 'first_season': span[0], 'last_season': span[1]}
		if episodes and is_range: out['pack_episodes'] = len(episodes)
		return out
	if episodes and is_range: return {'package': 'season', 'pack_episodes': len(episodes)}
	out = {'package': 'season'}
	try:
		if season_length and int(season_length) > 0: out['pack_episodes'] = int(season_length)
	except (TypeError, ValueError): pass
	return out

def _pack_shape(name):
	"""(is_pack, episode_start, episode_end). 0/0 means a whole-season pack."""
	if _PK_ABS_EP.search(name): return False, 0, 0        # SxxEyy.(abs) -> one episode
	a, b = _pk_first_valid(_PK_RNG_SE, name)
	if a: return True, a, b                               # SxxE06-08 -> real range
	try:
		seasons, episodes, parts, is_range = _extract_meta(_clean_for_extract(name))
	except Exception:
		return True, 0, 0                                 # unparseable: leave it to the caller
	if episodes is None: return True, 0, 0                # no episode at all -> batch
	if is_range: return True, min(episodes), max(episodes)
	a, b = _pk_first_valid(_PK_RNG_BARE, name, min_span=2)
	if a: return True, a, b                               # "01.~.10" style batch
	return False, 0, 0                                    # a single, specific episode

# A film or OVA is not a TV episode. Requiring the ABSENCE of a season marker as
# well keeps genuine show packs that merely list their extras -- 'Attack on Titan
# (Complete Collection) (S01-S04+OVA+Movie)' declares S01-S04 and is kept, while
# 'Bleach the Movie: Memories of Nobody' and '[DBD-Raws] Bleach [OVA][01-02]'
# declare no season and are dropped. Both were answering episode-1 requests.
# What a genuine batch SAYS about itself. cour_match used to accept any name it could
# not read an episode number out of, on the theory that such a name must be a batch.
# It is not: a film, a special, or a name whose numbering was mangled beyond parsing
# all look identical to a batch under that rule, and every one of them then answers
# EVERY episode request. Measured on a Jujutsu Kaisen S01E01 scrape, comet returned
# 737 rows of which 508 came in through that door -- 81 of them the film 'Jujutsu
# Kaisen 0', the rest largely CJK-stripped names like '_Sousou.no.Frieren][30][' that
# are a specific episode whose number simply could not be read.
#
# Requiring the claim to be explicit drops 397 of those 737 and 181 of a 447-row
# Frieren scrape, while costing nyaa only 1-2 rows per scrape.
_BATCH_EVIDENCE = re.compile(
	r'complete|batch|collection|box\s?set|\bbox\b|all\s?episodes|integrale|integral|'
	r'full\s?series|season|seasons|serie|series|temporada|staffel|saison|stagione|'
	r'\bvol\b|volume|bd\s?box|bdmv|\btv\b', re.I)

_MOVIE_OVA = re.compile(r'\b(?:movies?|gekijou?ban|ova|oad|nc(?:op|ed))\b', re.I)


# LOCAL PATCH 2026-09-22: the episode number a release writes straight after the show's
# own title, with no delimiter at all.
#
# '[ShouryuuReppa] Mushoku Tensei: Jobless Reincarnation 13 1080p [HEVC][x265]...' carries
# its episode as a bare 13. _EX_EP_DASH needs a dash, _EX_EP_PREFIX needs an E and the
# range forms need two numbers, so _extract_meta returned episodes=None, cour_match fell
# through to its batch rule, found no batch evidence either and REJECTED the row. Measured
# 2026-09-22 on eid=246509: 2 of 32 rows lost that way, both correct for the episode.
#
# No purely syntactic rule can read that number, which is why this sat open for a session:
# 'Mob Psycho 100' cleans to exactly the same shape, and any trailing-number rule stamps it
# 'episode 100' and then answers no episode of that show at all. The discriminator is not
# syntax, it is POSITION RELATIVE TO THE TITLE -- 'Mob Psycho 100' spends its own 100 as a
# title word and leaves nothing behind, while 'Mushoku Tensei: Jobless Reincarnation' ends
# before the 13. _TITLE_EDGE_OK already says a bare number may legally sit beside a title
# match; this reads the number that does.
#
# THE FIRST CLEAN TITLE MATCH IS FINAL, and that is the whole safety argument. Candidates
# are tried LONGEST FIRST, and once one matches, a shorter one may not re-read the digits it
# just consumed. Without that rule the alias 'Mob Psycho' re-reads the 100 the title had
# already accounted for: measured, 50 of 225 rows became 'episode 100', every one a real
# season pack. Prefix aliases are not hypothetical -- 28 of the 553 cached shows that carry
# alternative_titles have one and make_alias_dict feeds every one of them in ('Jaws 3-D'
# <- 'Jaws 3', 'Demon Slayer: Kimetsu no Yaiba' <- 'Demon Slayer'), and tmdb 94664's own
# alias list contains the bare 'Mushoku Tensei'.
#
# The match is final even when it is the WHOLE name. '[DB] Mob Psycho 100 [Dual Audio 10bit
# BD1080p]' cleans to exactly the three title tokens, so writing the length test as "no room
# for a number after it, skip this candidate" handed the row to the short alias by the back
# door and gave 1 of those 50 back. A candidate that fills the name matches, and answers None.
def _title_anchored_episode(cleaned, titles):
	"""The number written immediately after the show's own title, or None.

	`cleaned` is _clean_for_extract output; `titles` is the show title plus its aliases.
	Boundary handling follows _seq_matches: a long word in FRONT of the match means some
	other show's longer title ('Boruto - Naruto Next Generations'), unless _TITLE_EDGE_OK
	allows it or it is a word of one of our own candidates.
	"""
	seq = _title_seq(cleaned)
	cands = sorted((c for c in (_title_seq(t) for t in (titles or []) if t) if c),
				   key=len, reverse=True)
	if not seq or not cands: return None
	cand_words = set(w for c in cands for w in c)
	for cand in cands:
		n = len(cand)
		if n > len(seq): continue
		for i in range(len(seq) - n + 1):
			if seq[i:i + n] != cand: continue
			before = seq[i - 1] if i > 0 else None
			if before is not None and len(before) >= 4:
				if not _TITLE_EDGE_OK.match(before) and before not in cand_words: continue
			nxt = seq[i + n] if i + n < len(seq) else None
			# This title match is FINAL: every path below RETURNS, none falls through to a
			# shorter candidate. Measured over 381 blind rows from 8 shows, only 4 reach here
			# with a digit at all -- the other 311 carry a word ('season' 51, 'the' 32, 's01'
			# 30, 'vol' 27), and 47 have the title filling the whole name.
			if not nxt or not nxt.isdigit(): return None
			val = int(nxt)
			# Matches _EX_EP_RANGE's ceiling so the two episode readers agree.
			if not 0 < val <= 9999: return None
			# A bare year is not an episode: 'Show Name 2016 [BD]' would otherwise read as
			# episode 2016. Tested on the VALUE rather than on four digits of text, so a
			# zero-padded '02016' cannot walk around it. Known cost: a genuine ABSOLUTE
			# episode number in this band is refused -- real long-runners are nowhere near
			# it (One Piece is around 1150), and the bound cannot simply be 999 because
			# absolute numbering does pass 1000.
			if 1900 <= val <= 2099: return None
			return val
	return None


# LOCAL PATCH 2026-09-23: the episode a WHOLE-RUN release names, for animetosho's eid check.
#
# One AniDB entry covering a whole long-runner (One Piece aid 69) has an eid index that
# AnimeTosho fills with other numberings of the same number: ?eid=977 (episode 10) returns
# 'One Piece - Gyojin Tou-hen - 10' (the Fish-Man Island recap, arc-relative) and ?eid=440
# (episode 1) returns 'One Piece - S18E01' (TVDB season-relative). Both sit under aid 69, so
# no id test separates them; only which number the name writes after the title does.
#
# _title_anchored_episode alone reads a bare number, and on the measured eid replies that
# lost 12 real releases which write a MARKER first -- 'ep0001', 'e1179', 'episode 1000',
# 's01e1179', 's1e001'. Every contaminant instead puts an arc name between title and number,
# or a season other than 1. So the marker is folded into a bare number and the unchanged
# reader does the rest.
#
# The marker must sit directly in front of the digits, and only season 1 counts: in a whole-run
# show 'S18E01' is TVDB's season-relative numbering, not the absolute episode, so it stays
# unread and is rejected. A bare 'e' needs a digit straight after it, so 'e-ac3' and 'eac3'
# cannot match, and a word boundary in front, so the 'e' INSIDE 's18e01' is not a marker.
# 'SE.001' is left alone: SE can mean Special Edition.
_EP_MARKER = re.compile(r'\b(?:s0*1\s*e|episode\s*|ep\s*|e)(?=\d)', re.I)


def _normalise_episode_marker(cleaned):
	"""Rewrite an episode marker in front of a number into the bare number.

	`cleaned` is _clean_for_extract output. The result is fed to _title_anchored_episode,
	which reads only a bare number immediately after the title:
	'one piece ep0001' -> 'one piece  0001', 'one piece s01e1179 ...' -> 'one piece  1179 ...'.
	"""
	if not cleaned: return cleaned
	return _EP_MARKER.sub(' ', cleaned)


def whole_run_episode(name, titles):
	"""The absolute episode a release name states for a whole-run show, or None."""
	if not name or not titles: return None
	return _title_anchored_episode(_normalise_episode_marker(_clean_for_extract(name)), titles)


# LOCAL PATCH 2026-09-23: cour_match's step 0, lifted out so animetosho's PACK paths apply
# the very same test. Packs skip cour_match (a batch spanning cours is a legitimate answer),
# and that exemption let every Thousand-Year Blood War batch through for a Bleach (2004)
# request: AnimeTosho files TYBW under Bleach's own aid 2369, and 'Sennen Kessen Hen -
# 01 ~ 13' declares a range that contains episode 1, so the range check cannot see it.
# LOCAL PATCH 2026-10-01: a cour's IDENTITY read from its name, for the providers that find releases by
# searching a title (nyaa). cour_match judges a release by the season NUMBER it claims, and a franchise whose
# later seasons are NAMED defeats that. Ace of the Diamond on TMDb is four seasons --
#     1 'Diamond no Ace'   2 'Diamond no Ace: Second Season'   3 '... act II'   4 '... act II: Second Season'
# -- and the 'II' of 'act II' reads as season 2, so on 2026-10-01 a Season 2 episode 10 search kept every
# 'Act II - 10' and 'Act II Second Season - 10' (seasons 3 and 4), and 'S01' packs passed under the rule that
# trusts a LOWER season claim (sub-series renumbering, see cour_match step 2). The foreign words list could not
# help: it keeps words of four letters or more, and 'act' and 'II' are three and two.
#
# Each cour title yields MARKERS: a short word followed by a numeral ('act ii' -> 'act2') and an ordinal season
# ('Second Season', '2nd Season', 'Season 2' -> 'S2'). Against its sibling cours a cour then has:
#     foreign  -- markers a sibling has and we do not: a name carrying one is that sibling's (Act II under S2)
#     require  -- for each sibling whose markers are a strict SUBSET of ours, the name must carry one of the
#                 markers that tell us apart (S4 must say 'Second Season' / S2 or it is S3's 'Act II - 05')
# A phrase marker is removed from the name before its season is read, so 'act II' is not 'season 2' any more.
_COUR_ROMAN = {'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7, 'viii': 8, 'ix': 9, 'x': 10}
# In a TITLE the word and its numeral are separate words ('act II'): with the separator optional the pattern split
# inside words -- 'Honki' read as 'honk i', 'III' as 'ii i' (Mushoku Tensei III). A name may still glue them ('actII',
# 'act2'); name_cour_check matches those per marker.
_COUR_PHRASE = re.compile(r'(?<![a-z0-9])([a-z]{2,4})[\s._\-]+(viii|vii|iii|ii|iv|vi|ix|x|v|i|\d{1,2})(?![a-z0-9])')
_COUR_PHRASE_SKIP = frozenset(('part', 'pt', 'season', 'cour', 'vol', 'ep', 'eps', 'no', 'the', 'of', 'oad', 'ova', 'ona',
	'sp', 'op', 'ed', 'hd', 'sd', 'bd', 'dvd', 'web', 'ver', 'ch', 'arc', 'vs', 'and', 'to', 'ga', 'wa', 'de', 'ni', 'wo', 'mo',
	'na', 'wi', 'ka', 'ne', 'in', 'on', 'at', 'is', 'it', 'or', 'by', 'top', 'aac', 'flac', 'dts'))
_COUR_ORDINAL = {'first': 1, 'second': 2, 'third': 3, 'fourth': 4, 'fifth': 5, 'sixth': 6, 'seventh': 7, 'eighth': 8, 'ninth': 9, 'tenth': 10}
_COUR_SEASON = re.compile(r'(?<![a-z0-9])(?:(\d{1,2})(?:st|nd|rd|th)|(first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth))'
	r'[\s._\-]*season(?![a-z])|(?<![a-z0-9])season[\s._\-]*(\d{1,2})(?![0-9])')


def title_cour_markers(title):
	t = (title or '').lower()
	marks = set()
	for m in _COUR_PHRASE.finditer(t):
		word, num = m.group(1), m.group(2)
		if word in _COUR_PHRASE_SKIP or not set(word) - set('ivx'): continue   # 'iii ii' is no word
		value = _COUR_ROMAN.get(num) or (int(num) if num.isdigit() else None)
		if value: marks.add('%s%d' % (word, value))
	for m in _COUR_SEASON.finditer(t):
		value = int(m.group(1) or m.group(3) or 0) or _COUR_ORDINAL.get(m.group(2) or '')
		if value and value > 1: marks.add('S%d' % value)
	return marks


def cour_marker_plan(own_title, sibling_titles):
	"""The foreign / require / phrase markers of a cour against its siblings, or None when names cannot tell them
	apart this way (every cour without markers, or all alike)."""
	own = title_cour_markers(own_title)
	foreign, require = set(), []
	for title in sibling_titles or ():
		sib = title_cour_markers(title)
		if sib < own:
			group = sorted(own - sib)
			if group not in require: require.append(group)
		elif sib != own: foreign |= (sib - own)
	if not foreign and not require: return None
	phrases = sorted(m for m in (own | foreign) if not m.startswith('S'))
	return {'own': sorted(own), 'foreign': sorted(foreign), 'require': require, 'phrases': phrases}


def name_cour_check(name, plan, cour_season=None, absolute_episode=None, wanted_episodes=()):
	"""(verdict, name_for_matching): False = another cour's release, True = named as ours (the season NUMBER may then
	be the sub-series' own, so cour_match should trust it), None = the markers say nothing. name_for_matching has the
	plan's phrase markers removed, so 'act II' cannot read as season 2 there either."""
	if not plan or not name: return None, name
	present, stripped = set(), name
	for marker in plan.get('phrases') or ():
		mm = re.match(r'([a-z]+)(\d+)$', marker)
		if not mm: continue
		word, value = mm.group(1), int(mm.group(2))
		forms = sorted([str(value)] + [r for r, v in _COUR_ROMAN.items() if v == value], key=len, reverse=True)
		rx = re.compile(r'(?<![a-z0-9])%s[\s._\-]*(?:%s)(?![a-z0-9])' % (re.escape(word), '|'.join(forms)), re.I)
		if rx.search(stripped):
			present.add(marker)
			stripped = rx.sub(' ', stripped)
	seasons, episodes, parts, is_range = _extract_meta(_clean_for_extract(stripped))
	# the absolute number is unique across the run: '- 85' is Season 2 episode 10 whatever else the name says --
	# unless it IS the cour's own number (Season 1 episode 10 is absolute 10), when it proves nothing
	try:
		if (absolute_episode and episodes and int(absolute_episode) in episodes and not is_range
				and int(absolute_episode) not in set(int(x) for x in wanted_episodes if x is not None)): return True, stripped
	except (TypeError, ValueError): pass
	# a franchise PACK that claims our season among others ('S01-S03') holds ours -- a pack only: a single episode
	# that lists both numberings ('S04E10 ... (Act II Second Season, Ace of Diamond Act II Season 2)') does not
	if cour_season and len(seasons) > 1 and int(cour_season) in seasons and (episodes is None or is_range): return True, stripped
	present |= set('S%d' % s for s in seasons)
	if present & set(plan.get('foreign') or ()): return False, stripped
	for group in plan.get('require') or ():
		if not (present & set(group)): return False, stripped
	return (True if plan.get('require') else None), stripped


def names_foreign_cour(name, foreign_tokens):
	"""True when the name carries a distinctive word of ANOTHER cour of this TMDb show."""
	if not foreign_tokens or not name: return False
	_nt = set(w for w in re.findall(r'[a-z0-9]+', name.lower()) if len(w) >= 4)
	return bool(_nt & set(foreign_tokens))


def cour_match(name, cour_season=None, cour_episode=None, absolute_episode=None,
               season_episode=None, cour_part=None, foreign_tokens=None, titles=None,
               trust_id=False, cour_part_count=None):
	"""Does this release name hold the wanted episode of the wanted cour?

	LOCAL PATCH 2026-08-27. Anime carries two numbering schemes at once and both
	are in active use for the same episode:
	    [Erai-raws] Sousou no Frieren 2nd Season - 02   cour-relative
	    [ANi] Sousou no Frieren S02 - 30                absolute (from series start)

	`cour_season` is the RELEASE season number - Fribb's season.tvdb, not TMDb's.
	TMDb files every Re:ZERO cour under season 1, so its number says nothing about
	what an "S02" in a release name refers to.

	ORDER MATTERS here; both alternatives were tried and both lose results:

	  1. Absolute number first. It is unique across the series, so it identifies an
	     episode with no season marker at all - "[SubsPlease] Shingeki no Kyojin -
	     38" is S3E01. Putting the season check ahead of this rejected 34 real AoT
	     results whose only number was the absolute one.
	  2. Season check next. The cour-relative number IS ambiguous between cours, so
	     for cour 2+ a name with no season marker is cour 1, not a wildcard.
	     Otherwise "[aL] Sousou no Frieren (2023) - 02" (cour 1 episode 2) answers a
	     cour 2 episode 2 request - exactly what comet's kitsu endpoint returns.
	  3. Batches only after the season check. Accepting them earlier let
	     "Frieren: Beyond Journey's End (2023) (Season 1) [BDRip]" through for a
	     cour 2 request.
	"""
	# 0. a name carrying another cour's distinctive words IS that cour, whatever
	#    numbering it uses. Bleach and Thousand-Year Blood War are separate anime
	#    under one TMDb show, and TYBW releases label themselves S01E01 in their own
	#    numbering -- so no season or episode test can separate them. Only the title
	#    can, and 'Sennen Kessen-hen' is the form most of those releases use.
	if names_foreign_cour(name, foreign_tokens): return False
	_cleaned = _clean_for_extract(name)
	seasons, episodes, parts, is_range = _extract_meta(_cleaned)
	# LOCAL PATCH 2026-09-24: a Part number larger than the season has parts is not a cour
	# part. JoJo names its story arcs that way -- 'Part 6: Stone Ocean' -- and step 3 below
	# compared the 6 against Stone Ocean's cour part 3 and rejected a correct S05E25. The
	# same guard animetosho's pack check applies. Only when the caller knows the count.
	try:
		if parts and cour_part_count and any(int(p) > int(cour_part_count) for p in parts): parts = set()
	except (TypeError, ValueError): pass
	# LOCAL PATCH 2026-09-22: a name whose only number sits bare after the title reads as
	# unreadable to _extract_meta, and an unreadable name with no batch evidence is REJECTED
	# further down. `titles` is what lets it be read -- see _title_anchored_episode. Applied
	# ONLY when nothing else found an episode, so it can neither override a number a
	# delimiter already yielded nor change any row that parses today.
	if episodes is None and titles:
		_anchored = _title_anchored_episode(_cleaned, titles)
		if _anchored is not None: episodes = set([_anchored])
	# films / OVAs, unless the name also claims a season (then it is a show pack
	# that merely lists its extras)
	# underscores are word characters, so \b will not fire against them:
	# 'Gekijouban_Bleach_...[MOVIE_IV]' has to be split first
	if not seasons and _MOVIE_OVA.search((name or '').replace('_', ' ')): return False
	def _int(v):
		try: return int(v)
		except (TypeError, ValueError): return None
	cour_season, cour_episode = _int(cour_season), _int(cour_episode)
	absolute_episode, season_episode = _int(absolute_episode), _int(season_episode)
	# The season-relative number is the one release names carry when a season is
	# split across cours (Re:ZERO S2 ep 24 = cour 2 of 2, cour_ep 12). Where the
	# season is a single cour the two are identical, so accepting both is free.
	wanted = set(x for x in (season_episode, cour_episode) if x is not None)

	# 1. unambiguous absolute hit (skipped for cour 1, where the two numbers are
	#    the same and a bare number really is ambiguous)
	if (episodes and absolute_episode is not None
			and absolute_episode not in wanted and absolute_episode in episodes):
		return True

	# 2. the release must belong to our cour
	if cour_season and cour_season > 1:
		# LOCAL PATCH 2026-09-22: reject only a name claiming a LATER season than the one
		# asked for. A franchise with named sub-series is numbered TWICE: every database
		# counts across the franchise while release groups count within the sub-series.
		# Ace of the Diamond S04 is 'Act II -Second Season-', so Fribb and TVDB both say
		# season 4 while the releases say 'Act II S2', 'Act II Second Season' and
		# 'Act II - S02E01' -- seasons={2} against cour_season=4. Measured 2026-09-22:
		# `4 not in {2}` rejected all 10 rows AnimeTosho returns for eid 310190, so S03
		# and S04 found nothing at all. Only [Judas] numbers by franchise season.
		#
		# The direction is what carries the signal. Mis-filing -- the thing this reject
		# exists for -- is always sequel content landing under a PREQUEL's id, so the
		# name claims a HIGHER season than requested: Re:ZERO S4 releases under S1's ids
		# say 'S04E01' against cour_season=1. Sub-series numbering is the opposite, a
		# LOWER number than the franchise season. So a lower number is trusted to the eid
		# and a higher one is still refused.
		#
		# A name with NO season marker is still refused, unchanged: for cour 2+ the bare
		# cour-relative number reads as cour 1 rather than as a wildcard (see the
		# docstring's point 2).
		#
		# Known cost: a mis-filed row whose sub-series season happens to EQUAL the
		# requested franchise season now passes -- asking for Ace S02 while Act II S2
		# rows sit under S02's eid. It needs a mis-file and a matching episode number,
		# and those rows live under aid 18638, so they should not reach an S02 query.
		# LOCAL PATCH 2026-09-22: `trust_id` -- the caller identified this episode by an ID
		# rather than by reading the name, so a name that says nothing about its season
		# contradicts nothing. This rule reads a missing marker as 'cour 1', which is right
		# when the name is the only evidence there is (nyaa and comet search by title) and
		# wrong on an eid query, where animetosho's own comment says the eid still decides
		# which episode this is and this test exists only to catch a MIS-FILED row. A
		# mis-file announces itself -- the Re:ZERO season 4 releases sitting under season
		# 1's ids plainly say 'S04E01'. A name with no marker announces nothing.
		#
		# Measured on JoJo: TMDb season 5 is Stone Ocean, whose parts are NAMED rather than
		# numbered, so '[SubsPlease] JoJo no Kimyou na Bouken - Stone Ocean - 01' carries no
		# Sxx token at all. Against cour_season=5 every such row was rejected, on all three
		# parts and every episode: 'cour_rejected=2 kept=0' on eids 250393, 258797, 261521.
		# Only [Judas], which writes S05E01, survived.
		if not seasons:
			if not trust_id: return False
		elif cour_season not in seasons and min(seasons) > cour_season: return False
	elif seasons and min(seasons) > 1:
		# LOCAL PATCH 2026-09-21: some groups number a split season's COURS as seasons,
		# and that is not a later season at all. Mushoku Tensei S1 is two cours; Fribb
		# files both under season.tvdb 1, but Erai-raws ships the second as
		# 'Mushoku Tensei - Isekai Ittara Honki Dasu 2nd Season - 02'. That reads as
		# seasons={2} against cour_season=1 and was rejected, losing 3 of the 32 rows
		# AnimeTosho returns for eid 246509 -- all of them correct for the episode.
		#
		# The tell is that the name's number CANNOT be a real season: it exceeds the
		# season this episode actually belongs to, and it equals the cour part we want.
		# Re:ZERO S2 part 2 is the case this must NOT catch -- there cour_season is 2, so
		# min(seasons) > cour_season is false, '2nd Season' really does mean season 2, and
		# the branch above handles it as before.
		#
		# Recorded as a PART rather than just waved through: the name has told us which
		# cour it is, which is exactly what 3b below needs to stop treating the
		# cour-relative number as ambiguous. Waving it through would clear step 2 and then
		# still fail 3b, which is what made this a two-line fix rather than a one-line one.
		if (cour_part and cour_season and min(seasons) == int(cour_part)
			and min(seasons) > cour_season):
			parts = set(parts) | {int(cour_part)}
		else:
			return False   # targeting cour 1, name claims a later season

	# 3. a batch of the right cour: caller picks the file inside it. A Part number
	#    is the one thing a batch does say about WHICH episodes it holds, so honour
	#    it -- '(Season 2 Part 01)' cannot contain an episode from Part 2, and with
	#    no episode numbers to check it would otherwise sail through.
	if parts and cour_part and int(cour_part) not in parts: return False
	# No episode number: only a batch if the name actually claims to be one. See
	# _BATCH_EVIDENCE -- without this test a film or an unparseable name matched every
	# episode of the show. `seasons` and `parts` count as a claim in their own right,
	# and a season pack has already been checked against our cour above.
	if episodes is None:
		return bool(seasons or parts or _BATCH_EVIDENCE.search(name or ''))

	# 3b. a split season makes the COUR-relative number ambiguous across parts, in
	#     exactly the way the cour-relative number is ambiguous across cours above.
	#     Attack on Titan S3 is two parts; our S3E20 is part 2 episode 8, but part 1
	#     episode 8 is ALSO named 'Attack on Titan S3 - 08', and it was matching. A
	#     part marker resolves that and is honoured just above -- when there is none
	#     the bare number reads as part 1, so only the unambiguous numbers may be
	#     used: the season-relative one (20) and the absolute one, both of which
	#     count across the whole season and so cannot collide between its parts.
	# Skipped for an id-keyed caller, for the same reason as the season rule above: this
	# treats a bare cour-relative number as ambiguous BETWEEN PARTS, which it is when the
	# name is all we have, but with an eid the part is already known. JoJo again -- Stone
	# Ocean part 2 episode 1 is named '- 01', so wanted={1, 13} would be narrowed to the
	# season-relative 13 and miss, rejecting a correct row a second time even after the
	# season rule let it through.
	if cour_part and int(cour_part) > 1 and not parts and not trust_id:
		unambiguous = set(x for x in (season_episode, absolute_episode) if x is not None)
		return bool(unambiguous & set(episodes))

	# 4. cour-relative number, now that the cour is established
	return bool(wanted & set(episodes))


def real_imdb(imdb):
	"""LOCAL PATCH 2026-10-06: an IMDb id a Stremio addon can answer ('tt5311514'), not '', None, 'tt' or 'tt0000000'.
	torrentio and comet search an anime film with no such id by its Kitsu id instead."""
	imdb = str(imdb or '').strip().lower()
	return imdb.startswith('tt') and imdb.strip('t0') != ''


def title_guard(name, title, aliases):
	"""Does this release name actually belong to the show we asked for?

	LOCAL PATCH 2026-08-27. The Kitsu paths in torrentio and comet skip the normal
	title check, on the reasoning that querying by an ID already scopes the result to
	one anime. That reasoning turned out to be too trusting on both counts:

	  - comet's kitsu endpoint leaks unrelated shows. A kitsu:11:159 (Naruto) query
	    returned "11.22.63.S01.2160p.HULU.WEB-DL", and a Frieren query returned
	    "In Spectre S02E02".
	  - the ID itself can be wrong. ani.zip maps Fairy Tail to kitsu_id 1, which is
	    Cowboy Bebop -- so a query built from it returns 559 Cowboy Bebop rows, every
	    one of which the episode checks happily accept because they never look at
	    the title.

	No episode-level test can catch either: they are the right episode number of the
	wrong show. Only the title can, so it is checked here as a last line of defence.

	Uses the boundary-aware matcher rather than source_utils.check_title, which
	requires an SxxExx token that anime releases do not carry.
	"""
	cands = [_title_seq(t) for t in ([title] + list(aliases or [])) if t]
	cands = [c for c in cands if c]
	if not cands: return True
	return _seq_matches(_title_seq(name), cands)


def alias_titles(data):
	"""Show title + alias strings from a DeadLight data dict, for title_guard."""
	out = []
	for alias in (data.get('aliases') or []):
		if isinstance(alias, dict):
			if alias.get('title'): out.append(alias['title'])
		elif alias: out.append(str(alias))
	# LOCAL PATCH 2026-09-24: '<show> <TMDb season name>', when DeadLight passes the season's
	# name. Release groups write it between the title and the number -- '[Some-Stuffs] Jojo's
	# Bizarre Adventure Stone Ocean 25' -- and _title_anchored_episode reads only a number
	# straight after a candidate, so without this the row had no episode and was rejected.
	# A generic 'Season 2' name adds nothing a release would write that way, so it is skipped.
	_st, _show = data.get('season_title'), data.get('tvshowtitle')
	if _st and _show and not re.match(r'^\s*season\s*\d+\s*$', str(_st), re.I):
		out.append('%s %s' % (_show, _st))
	return out


# ---------------------------------------------------------------------------------------------
# PACK NAMES
#
# LOCAL PATCH 2026-09-24: moved here from providers/torrents/animetosho.py so that every
# anime name reader lives in this one module. Behaviour unchanged -- the functions take the
# names a row carries (title, then torrent_name) instead of the row, and animetosho passes
# them in. The measurements quoted below were taken there and still hold.
# ---------------------------------------------------------------------------------------------

# LOCAL PATCH 2026-09-22: a pack naming itself a numbered SUBDIVISION -- Box 05, Vol 09,
# Set 1, Part 2, Disc 3 -- holds some slice of the run without saying which episodes.
# Used by _pack_excludes_episode; the reasoning is there.
# 2026-09-22 (second pass): season markers count as subdivisions too. A 41-file
# '[BlackRabbit] Naruto (2002) - S05' cannot serve episode 220 any more than Box 01 can,
# and it reached the picker because it names a SEASON rather than a box. Safe for the
# same reason: the file-count test is against min(wanted), so a cour anime's own season
# pack (12 files, cour_episode 1-12) is never touched.
# LOCAL PATCH 2026-09-22: a pack that names a SIBLING SERIES alongside this one spans
# more than the anime being scraped, and its episode numbering is then ambiguous.
# 'Naruto + Naruto Shippuden' holds two episode 220s, and nothing in the feed says
# which file answers a request for 220. AnimeTosho is not wrong to list them under
# aid 239 -- they do contain Naruto -- so this is a deliberate policy reject, not a
# mis-filing guard.
#
# Words below are the ones that legitimately follow a '+' without naming another
# series. The list will never be complete, which is why the length floor below
# carries the real weight.
_SIBLING_EXTRAS = frozenset((
	'movie', 'movies', 'film', 'films', 'ova', 'ovas', 'oad', 'oads', 'special',
	'specials', 'extra', 'extras', 'opening', 'openings', 'ending', 'endings',
	'batch', 'complete', 'collection', 'season', 'seasons', 'remux', 'bluray',
	'dual', 'audio', 'project', 'subtitle', 'subtitles', 'uncensored',
))
# Seven, measured. At five, 'season' (Mushoku Tensei's own alt-title line) and
# 'break' (Re:ZERO Break Time) both produced false rejects; at seven neither does,
# while 'shippuden' and 'shippuuden' still fire. It misses short continuation names
# such as Dragon Ball KAI, and that is the direction to fail in: a miss leaves today's
# behaviour, an over-reject removes a working source.

# LOCAL PATCH 2026-09-23: a MOVIE-numbered range is not an episode range.
#
# AnimeTosho files a franchise's films under the series aid, so a Naruto Shippuden pack
# query returns '[Koten_Gars] Naruto Shippuden - The Movie 1-8' and '[BDMV] Naruto
# Shippuden - The Movie Collection (Movie 1-4)'. _extract_meta reads '1-8' and '1-4' as
# EPISODES, so both were offered for episodes 1 to 8 -- measured, 2 movie rows kept at
# episode 1 and 1 at episode 8, against 0 at episode 32 where the range happens not to
# reach. The films cannot contain a TV episode at any number.
_SEASON_RANGE = re.compile(r'\b(?:seasons?|s)[^a-z0-9]{0,3}\d{1,2}\s*[-~]\s*\d{1,2}', re.I)

_MOVIE_RANGE = re.compile(
	r'\b(?:movies?|films?|gekijou?ban)\b[^a-z0-9]{0,4}(\d{1,2})\s*[-~]\s*(\d{1,2})', re.I)

# LOCAL PATCH 2026-09-23: a bare episode range wrapped in brackets or parentheses.
#
# _extract_meta reads '0629-0686' and '783-1023' but not '(1086-1155)', '(0996-1069)',
# '(892-1085)' or '[0207-0336]' -- the same range, wrapped. '(E01-E12)' parses only
# because of the E. So a One Piece Egghead-arc pack declared nothing, and an unreadable
# name contradicts nothing, which is why it was kept for episode 1.
#
# LOCAL PATCH 2026-09-23 (b): 'to'/'thru' as the separator as well as a dash --
# '[Anime Time] One Piece (1001 to 1085)'. Only inside brackets, where the whole
# bracket IS the range. An unbracketed compound like 'One Piece - 1061, 1062 & 1070 to
# 1076' is deliberately left unread: taking 1070-1076 as its declared set would reject
# a request for 1061, which the name plainly also offers.
#
# Unwrapped for _pack_excludes_episode ONLY. anime_utils' extractor is also what
# cour_match reads, and teaching it a new range form would change episode matching for
# every id-keyed provider; this filter is the one place the gap is known to bite.
#
# LOCAL PATCH 2026-09-24: the range may be followed by EXTRAS inside the same bracket --
# '[Anime Time] One Piece (0001-1071+Movies+Specials)', 'Naruto Shippuden Complete (001-500
# + Movies)'. Required the close bracket straight after the second number, so neither was
# read and a 1071-episode pack was offered for episode 1179. The extras are films and
# specials, never more TV episodes, so the range is still the episode set. Only a WORD may
# follow the + or &: '(1070 to 1076 & 1080)' stays unread, for the compound-list reason above.
_BRACKETED_RANGE = re.compile(
	r'[\(\[]\s*(\d{1,4})\s*(?:[-~]|[\s._]+(?:to|thru)[\s._]+)\s*(\d{1,4})\s*(?:[\)\]]|(?=[+&]\s*[a-z]))', re.I)


def _unwrap_bracketed_range(name):
	"""'(1086-1155)' -> ' 1086-1155 ', which _extract_meta then reads. Unchanged if none.

	A YEAR span is left wrapped: 'One Piece (TV; Seasons 1 through 4; 1999-2002)' is a
	pack that DOES hold episode 1, and reading 1999-2002 as episodes would reject it.
	Both endpoints plausible years and a reach of 30 or less is the test -- an episode
	range that narrow, that high, would have to be a 4-part pack numbered past 1900."""
	def _sub(m):
		try: lo, hi = int(m.group(1)), int(m.group(2))
		except (TypeError, ValueError): return m.group(0)
		if 1900 <= lo <= 2099 and 1900 <= hi <= 2099 and 0 <= hi - lo <= 30: return m.group(0)
		return ' %d-%d ' % (lo, hi)
	try: return _BRACKETED_RANGE.sub(_sub, name)
	except Exception: return name


def pack_declares_season_only(names):
	"""True when the names state a SEASON and no episode range at all.

	'One Piece Season 17 (Dress Rosa) - Vol.15-22' and 'Naruto Shippuden Season 3' say
	which season they are and never say which episodes, so _pack_excludes_episode has
	nothing to test and keeps them -- an unreadable name contradicts nothing. That is the
	right default, but it means a season 17 pack is offered for episode 1.

	The season number itself is NOT compared here. It is TVDB's, not TMDb's, and for a
	cour-split show the two diverge -- that is what cour_season exists for -- while a show
	scraped in absolute order has no meaningful season to compare against at all. So this
	only reports that the name is season-shaped and episode-silent; DeadLight decides what
	to do with that, and does so only for a pack it cannot verify against a file listing.

	A name stating a range is never flagged, however many seasons it also names:
	'One Piece (001-746)(Seasons.01-17)' is verifiable and is left alone.
	"""
	if not (_extract_meta and _clean_for_extract): return False
	names = [n for n in (names or ()) if n]
	if not names: return False
	names = names + [u for u in (_unwrap_bracketed_range(n) for n in names) if u not in names]
	# A SEASON RANGE is a collection, not one season. _extract_meta reports 'Season 1-18'
	# as seasons=[1] -- it reads the first number only -- so it is indistinguishable from a
	# genuine season 1 pack without this. '[HcLs] Naruto Shippuden Season 1-18' is a
	# complete-series set and must not be dropped. The dash has to follow the digits
	# directly, so 'Season 17 (Dress Rosa) - Vol.15-22' is not caught by it.
	if any(_SEASON_RANGE.search(n) for n in names): return False
	seen_season = False
	for name in names:
		try:
			seasons, episodes, _parts, is_range = _extract_meta(_clean_for_extract(name))
		except Exception:
			continue
		if is_range and episodes: return False
		if seasons: seen_season = True
	return seen_season
_SIBLING_MIN_LEN = 7
_SIBLING_JOIN = re.compile(r'[+&]')
_SIBLING_BRACKETS = re.compile(r'\[[^\]]*\]|\([^)]*\)|\{[^}]*\}')

# LOCAL PATCH 2026-09-24: three digits, not two. '[uP] One Piece - Vol.003' (8 files) matched
# neither this nor, above episode 8, _SINGLE_VOLUME's arithmetic, so it was offered for
# episode 200. _SINGLE_VOLUME already read \d{1,3}; the two now agree.
_SUBDIVISION = re.compile(r'(?:^|[^a-z0-9])(?:box|vol|volume|set|part|pt|disc|disk|s|season)[^a-z0-9]{0,2}\d{1,3}(?:[^a-z0-9]|$)', re.I)

# LOCAL PATCH 2026-09-24: a pack of FILMS that states no range. _MOVIE_RANGE needs 'Movie
# 1-8'; 'Naruto.Shippuden.-.Movies.[BD-Remux]' and '[uP] Bleach - Movies' say only Movies,
# so they declared nothing and were kept -- the Shippuden remux (15 files, 208 GB) topped the
# S1E1 picker at 13.86 GB a file. Its TorBox listing is Movie 1 to Movie 7, and the listing
# check could not drop it either: finding no episode anywhere reads as an unreadable naming
# convention, not as absence. So the name has to settle it.
# A name that also says it holds EPISODES is a collection that happens to include the films
# ('One Piece [ Episodes + Movies + OVAs + Specials ]', 2260 files) and is left alone.
# So is one naming the films as an ADDITION -- '[DB] Re:Zero ... + Movies' (56 files) and
# '[Tenrai-Sensei] Re Zero ... S1+S2+OVAs+Movies' (102) were both falsely rejected by a first
# cut that looked for the word alone. A films-only pack names them as its SUBJECT: 'Naruto
# Shippuden - Movies', 'Bleach - Movies'.
_MOVIE_WORD = re.compile(r'\b(?:movies?|films?|gekijou?ban)\b', re.I)
_MOVIE_ADDITION = re.compile(r'(?:[+&]|\band\b|\bwith\b)[^a-z0-9]{0,3}(?:the[^a-z0-9]+)?(?:movies?|films?|gekijou?ban)\b', re.I)
_EPISODE_WORD = re.compile(r'\b(?:episodes?|eps?|tv|series|complete|collection|batch|seasons?|integrale|s\d{1,2})\b', re.I)

# LOCAL PATCH 2026-09-22: a pack labelled volume N>1 does not start at episode 1.
# The file-count fallback below can only say 'a 6-file pack cannot REACH episode 7',
# never 'volume 2 BEGINS at episode 7', so MTBB's Mushoku Tensei Volume 2 and Volume 3
# were both offered for episode 1 and TACHiKEN's Apothecary Vol 03 for episodes 1-6.
#
# Two guards keep this off the packs it would wreck, both learned from Naruto:
#   - a SPAN is excluded by the lookahead ('Vol.05~12' covers eight volumes, so its
#     181 files are not one volume's worth and the arithmetic below is meaningless);
#   - a pack bigger than _MAX_VOLUME_FILES is excluded, because '[uP] Set.5' with 130
#     files is a box, not a volume, and its own count says nothing about where it starts.
# Measured across Mushoku S1, Apothecary S1+S2 and Naruto: the correct rejects land at
# low episodes (Naruto drops 20 single-volume packs at ep 1, all of them Vol.09+) and
# NOTHING new is rejected at ep 55, 110 or 220 -- the rule only fires where it is sure.
_SINGLE_VOLUME = re.compile(r'\b(?:vol|volume|box|disc|disk|set)[^a-z0-9]{0,2}(\d{1,3})(?![^a-z0-9]{0,2}[-~]\s*\d)', re.I)
_MAX_VOLUME_FILES = 15


def pack_excludes_episode(names, num_files, wanted):
	"""True only when the names state a range and the wanted episode is outside it."""
	if not (_extract_meta and _clean_for_extract): return False
	# LOCAL PATCH 2026-09-22: read BOTH name fields, not `torrent_name or title`.
	# A row carries two names and either may be the informative one. Measured on
	# aid 17870: the 14-file [sam] pack has torrent_name '[sam] Kusuriya no
	# Hitorigoto [BD 1080p FLAC]' -- no range at all -- while its title reads
	# '[sam] The Apothecary Diaries Season 1 (S01) (E01-E12) | ...'. Preferring
	# torrent_name threw the range away and the pack was offered for E13/E14. The
	# 28-file pack in the same feed has an EMPTY torrent_name, so neither field can
	# be preferred outright -- and _build already reads them the other way round for
	# packs (`posting or filename`), so the two disagreed about the same row.
	names = [n for n in (names or ()) if n]
	if not names: return False
	# LOCAL PATCH 2026-09-23: add an unwrapped variant of any name carrying a bracketed
	# range, so the loop below can read it. ADDED, never substituted -- the original name
	# stays in the list, so nothing that already parsed can start parsing differently.
	names = names + [u for u in (_unwrap_bracketed_range(n) for n in names) if u not in names]
	# LOCAL PATCH 2026-09-23: a film collection cannot hold a TV episode.
	#
	# Only when the movie range is the ONLY range the name states. 'One Piece Collection
	# 1-750 + OVAs + Specials + Movies 1-12' names both, and it is a legitimate episode
	# pack that happens to bundle the films -- rejecting on the mere presence of the word
	# would throw it away. So the movie range is stripped and the name re-read: if an
	# episode range survives, the normal logic below decides; if nothing does, the row was
	# only ever describing films.
	if any(_MOVIE_RANGE.search(n) for n in names):
		_leftover = False
		for _n in names:
			try:
				_s, _e, _p, _r = _extract_meta(_clean_for_extract(_MOVIE_RANGE.sub(' ', _n)))
			except Exception:
				continue
			if _r and _e:
				_leftover = True
				break
		if not _leftover: return True
	declared = set()
	for name in names:
		try:
			_seasons, episodes, _parts, is_range = _extract_meta(_clean_for_extract(name))
		except Exception:
			continue
		if is_range and episodes: declared.update(episodes)
	# Any name that states a range is evidence; the union is what the pack can hold.
	if declared:
		return not (wanted & declared)
	# LOCAL PATCH 2026-09-24: films only, no range -- see _MOVIE_WORD. Underscores are word
	# characters, so 'Gekijouban_Bleach' is split before \b can see the word.
	_flat = [n.replace('_', ' ') for n in names]
	if (any(_MOVIE_WORD.search(_MOVIE_ADDITION.sub(' ', n)) for n in _flat)
			and not any(_EPISODE_WORD.search(n) for n in _flat)):
		return True
	# A single numbered volume cannot hold an episode that sits inside volume 1's span.
	# Only the LOW end is tested: volume sizes vary between groups (MTBB's Apothecary
	# volumes run 6-7 files while Lia's Mushoku Volume 3 declares episodes 12-17), so an
	# upper bound from one pack's file count would produce false rejects. The lower bound
	# does not depend on that variation.
	for name in names:
		m = _SINGLE_VOLUME.search(name)
		if not m: continue
		try:
			volume = int(m.group(1)); files = int(num_files or 1)
		except (TypeError, ValueError):
			continue
		if volume >= 2 and 1 <= files <= _MAX_VOLUME_FILES and max(wanted) <= files:
			return True

	# No range declared by either name. A numbered subdivision is then unverifiable
	# from the name, so fall back to the one hard fact the feed gives: its file count.
	# A pack cannot reach episode N even numbered from 1 if it holds fewer than N
	# files, so Box 05 with 27 files cannot serve episode 212.
	#
	# Compared against the SMALLEST candidate numbering on purpose. A cour pack
	# legitimately holds 12 files while the absolute number is 212, so testing the
	# largest would reject every cour pack in the library. Taking the smallest means
	# this can only fire when even the lowest plausible episode number exceeds the
	# pack -- exactly the long single-entry shows this is for (Naruto: one aid for 220
	# episodes, and TOSHO-DIAG shows wanted=[220], a single number). Cour anime is
	# untouched, its cour_episode being small.
	#
	# Cost, accepted deliberately: Box 8 really does hold episode 212 and is rejected
	# along with Box 1, because the name never says which episodes it covers. The
	# complete-series packs DO declare 001-220 and still answer.
	if any(_SUBDIVISION.search(n) for n in names):
		try: files = int(num_files or 1)
		except (TypeError, ValueError): return False
		return files < min(wanted)
	return False


def pack_names_sibling_series(names, titles):
	"""The distinguishing word when a '+' segment names another series, else None."""
	if not titles: return None
	# LOCAL PATCH 2026-09-22: both names, same reason as _pack_excludes_episode --
	# torrent_name is empty on some rows and abbreviated on others.
	name = ' | '.join(n for n in (names or ()) if n)
	# Bracketed groups carry release tags and fansub names, never a second series.
	body = _SIBLING_BRACKETS.sub(' ', name)
	segments = _SIBLING_JOIN.split(body)
	if len(segments) < 2: return None
	known = set()
	for title in titles:
		known.update(w for w in re.split(r'[^a-z0-9]+', title.lower()) if w)
	for segment in segments[1:]:
		for word in re.split(r'[^a-z0-9]+', segment.lower()):
			if len(word) < _SIBLING_MIN_LEN: continue
			if word in known or word in _SIBLING_EXTRAS: continue
			return word
	return None


# LOCAL PATCH 2026-10-05: stricter anime checks for the Stremio-style providers, torrentio and comet. Both answer with the
# FILE they picked inside each torrent (comet only that, as its name; torrentio as line 2 of the title and
# behaviorHints.filename), so that file is what gets judged. Measured 2026-10-05 over 16 anime episodes, both providers,
# rows kept before this patch: PNG and 'AI Generated' .zip collections, an .exe 'Downloader', .ass subtitle packs, OST/FLAC
# rips, manga and novel scans, a 'JPN BD Menu' disc -- all of them from comet's Kitsu endpoint, which answers by title.
_STREMIO_NOT_VIDEO = re.compile(r'\.(?:zip|rar|7z|exe|bat|lnk|flac|mp3|m4a|wav|ogg|png|jpe?g|webp|gif|pdf|cbz|cbr|epub|txt|nfo|'
	r'srt|ass|ssa|sup|cue|log)\s*$', re.I)
_STREMIO_NOT_EPISODE = re.compile(r'(?<![a-z0-9])(?:soundtracks?|osts?|scans?|scanlated|artbooks?|art[\s._-]?book|ai[\s._-]?generated|'
	r'wallpapers?|manga|light[\s._-]?novel|novel|pages|bd[\s._-]?menus?|drama[\s._-]?cd|character[\s._-]?songs?|cue|\d{2,3}[\s._-]?khz|'
	r'subs?[\s._-]?only)(?![a-z0-9])', re.I)
# ' + OVA + Soundtracks + Extras', '.+.NC.OP.&.NC.ED.+.OST': extras bundled with the episodes, not what the torrent is. A '+' with
# no space or dot around it is not a bundle: '[FLAC+CUE+SCANS]' is a music rip.
_STREMIO_BUNDLED = re.compile(r'[\s._][+&][\s._][^+&()\[\]]*$')


def stremio_junk(file_name, titles=()):
	"""Why this file is no episode at all ('.zip', 'soundtrack' ...), or None. A word the show's own title carries is not
	held against it (a show named '... Manga ...')."""
	if not file_name: return None
	m = _STREMIO_NOT_VIDEO.search(file_name)
	if m: return 'not a video (%s)' % m.group(0).strip()
	own = set()
	for t in titles or ():
		if t: own.update(re.findall(r'[a-z0-9]+', str(t).lower()))
	for m in _STREMIO_NOT_EPISODE.finditer(file_name):
		if set(re.findall(r'[a-z0-9]+', m.group(0).lower())) <= own: continue
		if _STREMIO_BUNDLED.search(file_name[:m.start()]): continue
		return 'not an episode (%s)' % m.group(0)
	return None


# LOCAL PATCH 2026-10-06: three kinds of anime row that are no episode of the show, from every anime provider (DeadLight's
# scrapers/external.py applies it to all of them, cached rows included):
#   a RE-EDIT -- 'Chainsaw.Man.-.The.Compilation.-.01.(1080p)' (S1E1 by its '- 01'; Crunchyroll / ABEMA's 2025 two-part
#     re-edit of season 1), 'Part.01' / 'Part.1+2' packs of it, recaps, digests, 総集編;
#   an EXTRA -- 'Hunter.x.Hunter.(2011).Creditless.OP.&.ED', NCOP / NCED (bundled ones, '+ NCOP', stay: _STREMIO_BUNDLED);
#   a MANGA volume -- '33.[Hunter.x.Hunter.vol.33]', 'Colored.Edition.Volume.33.(English)': 'vol N' and no sign of video
#     at all. Blu-ray volumes ('Vol.1 [BDrip 1920x1080 x264 FLAC]') always carry one.
# A word the show's own title carries is not held against it (a show called '... Digest').
_REEDIT = re.compile(r'(?<![a-z0-9])(?:compilation|recaps?|digest|soushuuhen)(?![a-z0-9])|総集編', re.I)
_EXTRA = re.compile(r'(?<![a-z0-9])(?:creditless|nc[\s._-]?(?:op|ed)s?|ncop\d*|nced\d*)(?![a-z0-9])', re.I)
# LOCAL PATCH 2026-10-08: COMMENTARY -- someone talking about the show, not the show: One Punch Man S1E1 listed comet's
# 'One.Punch.Man.Season.1.Review.(BDRip.1920x1080.x264.10bit.FLAC).mkv' (one 2.6 GB file, TorBox-cached, read as a season
# pack) and 'One.Punch.Man.Season.1.vs.Season.3.#anime.#onepunchman.ia.mp4'. A '#tag' is a social-media clip.
_COMMENTARY = re.compile(r'(?<![a-z0-9])(?:reviews?|reactions?|reacts?|reacting|explained|analysis|breakdown)(?![a-z0-9])|#[a-z]{3,}', re.I)
_VOLUME = re.compile(r'(?<![a-z0-9])vol(?:ume)?[\s._-]?\d', re.I)
_VIDEO_SIGN = re.compile(r'(?<![a-z0-9])(?:\d{3,4}[pi]|\d{3,4}x\d{3,4}|4k|uhd|bd|bdrip|bdremux|blu[\s._-]?ray|web(?:[\s._-]?(?:dl|rip))?|'
	r'hdtv|dvd(?:rip)?|x26[45]|h[\s._]?26[45]|hevc|avc|av1|xvid|divx|hi10p?|10[\s._-]?bit|remux|flac|aac|ac3|e?ac3|dts|opus|'
	r'mkv|mp4|avi|m2ts|ts)(?![a-z0-9])', re.I)


def anime_not_episode(name, titles=()):
	"""Why this anime row is no episode of the show (a re-edit, an extra, a manga volume), or None."""
	if not name: return None
	own = set()
	for t in titles or ():
		if t: own.update(re.findall(r'[a-z0-9]+', str(t).lower()))
	for rx, why in ((_REEDIT, 're-edit'), (_EXTRA, 'extra'), (_COMMENTARY, 'commentary')):
		for m in rx.finditer(name):
			if set(re.findall(r'[a-z0-9]+', m.group(0).lower())) <= own and own: continue
			if why == 'extra' and _STREMIO_BUNDLED.search(name[:m.start()]): continue
			return '%s (%s)' % (why, m.group(0))
	if _VOLUME.search(name) and not _VIDEO_SIGN.search(name): return 'manga volume'
	return None


# Chinese release names count episodes as 第13集 / 第13话 / 第13話, which _extract_meta does not read: the BTHDTV rows that
# comet's kitsu:46474:15 (Frieren E15) returned are each one other episode -- 第05集, 第13集, 第20集 ... -- named 'S01', which
# cour_match then took for a season pack. A range (第01-04集) does not match and is left to cour_match.
_CJK_EPISODE = re.compile(r'第\s*(\d{1,4})\s*[集话話]')


def cjk_episode(name):
	"""The single episode a 第N集 marker names, or None."""
	m = _CJK_EPISODE.search(name or '')
	return int(m.group(1)) if m else None


def own_cour_words(name, own_tokens):
	"""True when the name carries a word only this cour's titles have (DeadLight's own_cour_tokens)."""
	if not own_tokens or not name: return False
	return bool(set(re.findall(r'[a-z0-9]+', name.lower())) & set(own_tokens))


def other_show_year(name, data):
	"""The year a name writes RIGHT AFTER the show's title when it is not the show's own (+-1), else None.

	LOCAL PATCH 2026-10-05: a remake or live-action series shares the title and says which it is by its year. comet's
	kitsu:12:228 (One Piece, 1999, whole run) returned the Netflix series -- 'ONE.PIECE.2023.S01.REPACK.2160p.NF...',
	'One.Piece.Season.1&2.(2023-2026)' -- and an 'S01' pack reads as a batch of a show with no release season, so they
	passed, one as TOP PICK. Only the TMDb show title is used: the longer aliases carry season names, and 'Bleach
	Thousand-Year Blood War (2022)' is that season's year, not another show's.

	Many groups write the SEASON's year there ('Vinland Saga (2023) (Season 2)', 'Attack on Titan (2019) S03P02'), so
	the year is held against the season the name claims -- DeadLight's season_years, each TMDb season's air year -- or
	the show's own, which Sonarr names write ('Attack on Titan (2013) - S03E13'): One Piece's S01 aired in 1999, as did
	the show, not 2023. A name claiming no season may carry any season's year, but no other: 'Hunter x
	Hunter (2011)' under the 1999 show. +-1 throughout (a cour airing across New Year, a release dated by its BD)."""
	try: year = int(str(data.get('year') or '')[:4])
	except (TypeError, ValueError): return None
	own = _title_seq(data.get('tvshowtitle') or '')
	if not own: return None
	seq = _title_seq(name)
	for i in range(len(seq) - len(own)):
		if seq[i:i + len(own)] != own: continue
		nxt = seq[i + len(own)]
		if not (len(nxt) == 4 and nxt.isdigit() and 1900 <= int(nxt) <= 2099): return None
		named = int(nxt)
		years = {}
		for k, v in (data.get('season_years') or {}).items():
			try: years[int(k)] = int(v)
			except (TypeError, ValueError): continue
		seasons = _extract_meta(_clean_for_extract(name))[0]
		if seasons and years:
			known = [years[s] for s in seasons if s in years]
			# that season's year, or the show's own: Sonarr names write 'Attack on Titan (2013) - S03E13'
			if known: return None if any(abs(named - y) <= 1 for y in known + [year]) else named
		allowed = set(years.values()) | {year}
		return None if any(abs(named - y) <= 1 for y in allowed) else named
	return None


def other_season_year(name, data):
	"""The OTHER TMDb season a name's year points at, when the name claims no season itself, else None.

	LOCAL PATCH 2026-10-08: Crunchyroll names a new season by its year alone -- 'One.Punch.Man.(2025).-.01' is S3E01 --
	and AnimeTosho (by S1E1's AniDB eid) and comet's kitsu:10740:1 both filed those under One Punch Man S1E1: eight rows,
	five cached, shown as S1E1. other_show_year lets a season-less name carry ANY season's year, so they passed. The year
	is held against ours: the wanted season's, the show's, the episode's own air year (a TMDb season spanning years) --
	+-1 each; a year only another season has means that season."""
	try:
		year, season = int(str(data.get('year') or '')[:4]), int(data.get('season') or 0)
	except (TypeError, ValueError): return None
	years = {}
	for k, v in (data.get('season_years') or {}).items():
		try: years[int(k)] = int(v)
		except (TypeError, ValueError): continue
	if season < 1 or season not in years or len(years) < 2: return None
	own = _title_seq(data.get('tvshowtitle') or '')
	if not own: return None
	seq = _title_seq(name)
	for i in range(len(seq) - len(own)):
		if seq[i:i + len(own)] != own: continue
		nxt = seq[i + len(own)]
		if not (len(nxt) == 4 and nxt.isdigit() and 1900 <= int(nxt) <= 2099): return None
		named = int(nxt)
		if _extract_meta(_clean_for_extract(name))[0]: return None   # it claims a season: other_show_year's job
		ours = {years[season], year}
		try: ours.add(int(str(data.get('episode_year') or '')[:4]))
		except (TypeError, ValueError): pass
		if any(abs(named - y) <= 1 for y in ours): return None
		other = [s for s, y in sorted(years.items()) if s != season and abs(named - y) <= 1]
		return other[0] if other else None
	return None


# LOCAL PATCH 2026-10-08: a row that is the show's specials and nothing else, for a regular-season scrape. One Punch Man
# S1E1 listed 'One.Punch.Man.[S1].[Ova.720p].v2', 'One.Punch.Man.-.01.-.Special.[BD]', 'One.Punch.Man.Season.1.Specials'
# and 'One.Punch.Man.OVA.(BD.1080p...)' -- each holds a 'Special 01', which the pack file picker then took for episode 1.
# A '+' / '&' / 'and' before the word bundles the specials with the series ('Season.1.+.Specials', 'S1+S2+OVA&ODA',
# '[1-12+Specials]') and stays, as do two seasons before it ('[S1.S2.OVA&ODA]'); ONE ('[S1].[Ova.720p]',
# 'Season.1.Specials') is that season's specials.
# 'Special Edition' / 'Special Edited Version' is the episodes, remastered (One Piece's East Blue 1-61).
_SPECIALS = re.compile(r"(?<![a-z0-9])(?:specials?(?![\s._-]*edit(?:ion|ed)?)(?![\s._-]*version)|ova'?s?|oads?|oavs?)(?![a-z0-9])", re.I)
_SPECIALS_BUNDLED = re.compile(r'[+&]|(?<![a-z0-9])and(?![a-z0-9])', re.I)
_SPECIALS_SEASON = re.compile(r'(?<![a-z0-9])(?:s\d{1,2}|season[\s._-]?\d{1,2})(?![a-z0-9])', re.I)


def specials_only(name, titles=()):
	"""The specials word ('OVA', 'Specials') when the row is the show's specials and nothing else, or None. A word the
	show's own titles carry is not held against it."""
	if not name: return None
	own = set()
	for t in titles or ():
		if t: own.update(re.findall(r'[a-z0-9]+', str(t).lower()))
	for m in _SPECIALS.finditer(name):
		if own and set(re.findall(r'[a-z0-9]+', m.group(0).lower())) <= own: continue
		before = name[:m.start()]
		if _SPECIALS_BUNDLED.search(before) or len(_SPECIALS_SEASON.findall(before)) >= 2: return None
		return m.group(0)
	return None


def foreign_cour_marked(name, data):
	"""True when the name carries a marker of ANOTHER cour of this show (cour_plan foreign: 'act II' under Ace of the
	Diamond S2). LOCAL PATCH 2026-10-05, for the providers that otherwise read only season numbers."""
	plan = data.get('cour_plan')
	if not plan or not plan.get('foreign') or not name: return False
	# a franchise pack whose season RANGE holds ours names the others too ('Attack on Titan Season 1-4 S01-S04' for S3)
	span, cs = multi_season_span(name), _wanted_release_season(data)
	if span and cs and span[0] <= cs <= span[1]: return False
	return name_cour_check(name, dict(plan, require=[]), _wanted_release_season(data), data.get('absolute_episode'),
		(data.get('season_episode'), data.get('cour_episode')))[0] is False


def _wanted_release_season(data):
	"""The release season wanted: Fribb's cour_season, or TMDb's for the new-season ids (see comet_kitsu_reject)."""
	def _int(v):
		try: return int(v)
		except (TypeError, ValueError): return None
	cs, ce, ab, s = _int(data.get('cour_season')), _int(data.get('cour_episode')), _int(data.get('absolute_episode')), _int(data.get('season'))
	if cs is None and ce is not None and ab is not None and ce != ab and s and s > 1: cs = s
	return cs


def later_season_reject(names, data):
	"""Why a row whose name claims a LATER season than the one asked for is not ours, or None.

	LOCAL PATCH 2026-10-05: torrentio's Kitsu answers are scoped to the entry, but its own file matching is not proof:
	kitsu:43907:12 (Mushoku Tensei S1 Part 2 episode 12 = TMDb S1E23) returned Kira's '[JP-EN] Mushoku Tensei II ...
	[2023-2024] COMPLETE' with the file 'Mushoku Tensei II - Episode 23' -- Season 2's episode 23, offered (and marked
	TOP PICK) for S1E23, as it was for S1E12. Same row on the IMDb and season-pack paths. `names` is the file first, then
	the torrent: the first that states a season decides. A LOWER claim is not refused here (a sub-series counts its own
	seasons, see cour_match step 2), nor a name with no season at all (SubsPlease 'Solo Leveling - 13' is S2E1).

	One later claim is ours: some groups ship a split season's second cour as '2nd Season' (Erai-raws 'Mushoku Tensei
	2nd Season - 02' is S1 Part 2 episode 2, cour_match step 2). Then the number is the cour's own, so it must be
	cour_episode: Kira's 'II - Episode 23' claims 2 as well, but 23 is Season 2's numbering, not Part 2's 12."""
	cs = _wanted_release_season(data)
	if not cs: return None
	for name in names or ():
		if not name: continue
		seasons, episodes, _parts, is_range = _extract_meta(_clean_for_extract(name))
		if not seasons: continue
		if min(seasons) <= cs: return None
		try: part, ce = int(data.get('cour_part') or 0), int(data.get('cour_episode') or 0)
		except (TypeError, ValueError): part, ce = 0, 0
		if part > 1 and min(seasons) == part and episodes and ce in episodes and not is_range: return None
		return 'season %s, wanted %d' % (','.join(str(s) for s in sorted(seasons)), cs)
	return None


def comet_kitsu_reject(name, data, titles=None):
	"""Why comet's Kitsu-mode row `name` is not the wanted episode, or None to keep it.

	comet's kitsu:<id>:<ep> is not scoped to the entry: it answers with every release of the FRANCHISE whose name carries
	episode <ep>. Measured 2026-10-05 (rows kept before this patch -> wrong ones):
	    Black Clover 2nd Season kitsu:50024:1      7 -> 7   all Season 1 episode 1 ('S01E01 (001)', 'saison 1 [01~51]')
	    Ace of the Diamond S4E10 kitsu:48878:10   11 -> 8   'act II - 10' (S3), '~Second Season~ - 10' (S2), their packs
	    Frieren S1E15 kitsu:46474:15             117 -> 36  Chinese single episodes named S01, art and junk
	So comet is judged like nyaa, which also finds releases by title: the cour's markers (cour_plan, name_cour_check) first,
	then cour_match -- but without cour_match's trust in a LOWER season claim, which exists for a provider that found the row
	by an eid. A lower claim passes here only when the name also carries this cour's own words (own_cour_tokens): 'Bleach
	Thousand-Year Blood War S01E01' is TVDB season 17 episode 1, 'Bleach S01E01 2004' is not.

	The season wanted is Fribb's cour_season, or -- for the ids _new_season_ids finds when Fribb has no row yet, which leave
	cour_season unset -- TMDb's season: that path matches the AniList entry that STARTS this TMDb season, so the season it
	names is the one releases use (Black Clover 'S02E01', '2nd Season - 01'). The whole-run path also leaves cour_season
	unset, but asks with the absolute number (cour_episode == absolute_episode), so it is told apart by that."""
	def _int(v):
		try: return int(v)
		except (TypeError, ValueError): return None
	cs, ce = _wanted_release_season(data), _int(data.get('cour_episode'))
	ab, se = _int(data.get('absolute_episode')), _int(data.get('season_episode'))
	later = later_season_reject([name], data)
	if later: return later
	wanted = set(x for x in (ce, se, ab) if x is not None)
	ep = cjk_episode(name)
	if ep is not None and ep not in wanted: return 'names episode %d' % ep
	plan = data.get('cour_plan')
	# LOCAL PATCH 2026-10-05: a marker of ANOTHER cour refuses first, whatever season the name states -- 'act II' reads as
	# season 2, so for Ace of the Diamond S2E9 (plan foreign ['act2']) 'act II - 09' (S3) and the act II packs passed the
	# shortcut below until this ran ahead of it
	if foreign_cour_marked(name, data): return 'another cour (markers)'
	named, cm_name = name_cour_check(name, plan, cs, ab, (se, ce))
	seasons = _extract_meta(_clean_for_extract(cm_name))[0]
	if cs and cs in seasons:
		# the name states our season outright: 'Ace of the Diamond S04E10' against a plan built from 'act II Second Season',
		# which REQUIRES those markers -- only a missing required marker is overridden, never a foreign one (above)
		named = True
	else:
		if named is False: return 'another cour (markers)'
		if not named and own_cour_words(name, data.get('own_cour_tokens')): named = True
		if cs and cs > 1 and not named:
			seasons, episodes = _extract_meta(_clean_for_extract(cm_name))[:2]
			if seasons and max(seasons) < cs and not (ab is not None and episodes and ab in episodes and ab not in (ce, se)):
				return 'season %s, wanted %d' % (','.join(str(s) for s in sorted(seasons)), cs)
	if not cour_match(cm_name, cs, ce, ab, se, data.get('cour_part'), data.get('foreign_cour_tokens'), titles=titles,
			trust_id=bool(named), cour_part_count=data.get('cour_part_count')):
		return 'cour_match'
	return None
