# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-09-29: Torrents-CSV -- torrents-csv.com's open search API, searched by NAME. The second indexer
	beside apibay (PirateBay).

	Timed 2026-09-29: 0.45-0.62 s per query. A SMALL index: Reacher S02E01 7 rows, Reacher S02 11, Oppenheimer 25,
	Monster: The Lizzie Borden Story none. Off by default; worth it only as a backup to PirateBay.

	API: https://torrents-csv.com/service/search?q=<query>&size=100   No key. JSON {'torrents': [...], 'next': id}:
	  {'infohash' (lower case), 'name', 'size_bytes' (int), 'seeders', 'leechers', 'created_unix', ...}
	No hits is an empty list. No category field, so non-video rows fall to check_title like torrentdownload's.

	Laid out like apibay.py (episode / season-pack / show-pack queries in parallel threads), using client.request so
	the loading window's ok / failed tally sees it.
"""

import json
import re
from urllib.parse import quote
from magneto.modules import client
from magneto.modules import source_utils
from magneto.modules import workers


class source:
	priority = 3
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		self.language = ['en']
		self.base_link = 'https://torrents-csv.com'
		self.search_link = '/service/search?q=%s&size=100'
		self.min_seeders = 0

	def _query(self, query):
		"""Torrents-CSV's rows for one query, each hash once per scrape."""
		url = '%s%s' % (self.base_link, self.search_link % quote(query))
		results = client.request(url, timeout=5)
		if not results: return []
		rows = []
		for row in json.loads(results).get('torrents') or []:
			hash = (row.get('infohash') or '').lower()
			if len(hash) != 40: continue
			if hash in self.seen: continue
			self.seen.add(hash)
			rows.append(row)
		return rows

	def _item(self, row, name, name_info):
		"""The common part of an episode / movie / pack row, or None when it is below min_seeders."""
		try: seeders = int(row.get('seeders', 0))
		except: seeders = 0
		if self.min_seeders > seeders: return None
		hash = row['infohash'].lower()
		url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
		quality, info = source_utils.get_release_quality(name_info, url)
		try:
			dsize, isize = source_utils.convert_size(float(row.get('size_bytes', 0)), to='GB')
			info.insert(0, isize)
		except: dsize = 0
		return {'provider': 'torrentscsv', 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name, 'name_info': name_info,
				'quality': quality, 'language': 'en', 'url': url, 'info': ' | '.join(info), 'direct': False, 'debridonly': True, 'size': dsize}

	def sources(self, data, hostDict):
		self.items = []
		if not data: return self.items
		self.seen = set()
		try:
			self.aliases = data['aliases']
			self.year = data['year']
			if 'tvshowtitle' in data:
				self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
				self.episode_title = data['title']
				self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
			else:
				self.title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
				self.episode_title = None
				self.hdlr = self.year
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			self.get_sources('%s %s' % (re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title), self.hdlr))
			return self.items
		except:
			source_utils.scraper_error('TORRENTSCSV')
			return self.items

	def get_sources(self, query):
		try: rows = self._query(query)
		except:
			source_utils.scraper_error('TORRENTSCSV')
			return
		for row in rows:
			try:
				name = source_utils.clean_name(row['name'])
				if not source_utils.check_title(self.title, self.aliases, name, self.hdlr, self.year): continue
				name_info = source_utils.info_from_name(name, self.title, self.year, self.hdlr, self.episode_title)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				if not self.episode_title: # episodes returned by a movie query
					ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
					name_lower = name.lower()
					if any(re.search(item, name_lower) for item in ep_strings): continue
				item = self._item(row, name, name_info)
				if item: self.items.append(item)
			except:
				source_utils.scraper_error('TORRENTSCSV')

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		self.items = []
		if not data: return self.items
		self.seen = set()
		try:
			self.search_series = search_series
			self.total_seasons = total_seasons
			self.bypass_filter = bypass_filter
			self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			self.aliases = data['aliases']
			self.imdb = data['imdb']
			self.year = data['year']
			self.season_x = data['season']
			self.season_xx = self.season_x.zfill(2)
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			query = re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title)
			if search_series: queries = [query + ' Season', query + ' Complete']
			else: queries = [query + ' S%s' % self.season_xx, query + ' Season %s' % self.season_x]
			threads = [workers.Thread(self.get_sources_packs, q) for q in queries]
			[i.start() for i in threads]
			[i.join() for i in threads]
			return self.items
		except:
			source_utils.scraper_error('TORRENTSCSV')
			return self.items

	def get_sources_packs(self, query):
		try: rows = self._query(query)
		except:
			source_utils.scraper_error('TORRENTSCSV')
			return
		for row in rows:
			try:
				name = source_utils.clean_name(row['name'])
				episode_start, episode_end = 0, 0
				if not self.search_series:
					if not self.bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(self.title, self.aliases, self.year, self.season_x, name)
						if not valid: continue
					package = 'season'
				else:
					if not self.bypass_filter:
						valid, last_season = source_utils.filter_show_pack(self.title, self.aliases, self.imdb, self.year, self.season_x, name, self.total_seasons)
						if not valid: continue
					else: last_season = self.total_seasons
					package = 'show'
				name_info = source_utils.info_from_name(name, self.title, self.year, season=self.season_x, pack=package)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				item = self._item(row, name, name_info)
				if not item: continue
				item['package'] = package
				if self.search_series: item['last_season'] = last_season
				elif episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end}) # partial season packs
				self.items.append(item)
			except:
				source_utils.scraper_error('TORRENTSCSV')
