# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-01: the results list's tags as outlined text chips (mock-up A) instead of flag logos.
# A Kodi list row has no box that sizes itself to its text, so each row's chips are drawn here as ONE strip
# image, packed from the left, and the skin shows that image. Strips are cached by their tag combination
# (a results list repeats a handful of combinations), so each is drawn once and then only looked up.
# Pillow 6.2 (Kodi 21 on Windows) has no rounded_rectangle and no textbbox, so both are done by hand.
import os
import hashlib
import threading
from modules.kodi_utils import translate_path, addon_profile, make_directory

STRIP_H = 88                   # px; shown at 36 in the rows and 42 in the detail panel, so drawn at 2x the larger
STRIP_MAX_W = 1650             # the row strip's 675 x 36 box at this height; chips past it are left out
_SCALE = 3                     # drawn this much larger and scaled down, for smooth corners and text
_VERSION = '8'                 # bump to redraw every cached strip after a change to the look

# flag file names (windows/sources.py _FLAG_COLUMNS) -> the chip's text
LABELS = {'dolbyvision': 'Dolby Vision', 'hdr10plus': 'HDR10+', 'hdr10': 'HDR10',
		  'web': 'WEB', 'bluray': 'Blu-ray', 'hdtv': 'HDTV', 'dvd': 'DVD', 'sdtv': 'SDTV',
		  'atmos': 'Atmos', 'truehd': 'TrueHD', 'dtsx': 'DTS:X', 'dtshd_ma': 'DTS-HD MA', 'dtshd_hra': 'DTS-HD', 'dts': 'DTS',
		  'eac3': 'DD+', 'ac3': 'DD', 'aac': 'AAC', 'opus': 'Opus', 'flac': 'FLAC', 'mp3': 'MP3',
		  'ch2': '2.0', 'ch6': '5.1', 'ch7': '6.1', 'ch8': '7.1', 'lang_multi': 'MULTI'}

_TEXT = (232, 237, 244, 255)
_BORDER = (232, 237, 244, 120)
_font = None
# One strip drawn at a time: Pillow's FreeType font is not safe to share between threads, and the rows are built
# on several. 2026-10-01: unlocked, a few rows of a 238-result list lost their chips and fell back to flags.
_lock = threading.Lock()


def _font_path():
	"""The active skin's bold face (AF3: Inter-Bold), else any of its fonts, else Kodi's own Arial."""
	folder = translate_path('special://skin/fonts/')
	try: files = [f for f in os.listdir(folder) if f.lower().endswith(('.ttf', '.otf'))]
	except Exception: files = []
	for want in ('semibold', 'medium', 'bold', 'regular'):
		hit = [f for f in files if want in f.lower() and 'italic' not in f.lower()]
		if hit: return os.path.join(folder, sorted(hit)[0])
	if files: return os.path.join(folder, sorted(files)[0])
	return translate_path('special://xbmc/media/Fonts/arial.ttf')


def _get_font():
	global _font
	if _font is None:
		from PIL import ImageFont
		path = _font_path()
		_font = (path, ImageFont.truetype(path, int(STRIP_H * _SCALE * 0.48)))
	return _font


def _measure(font, text):
	"""(width, height, x offset, y offset) of the ink, on Pillow 6 and on 8+."""
	if hasattr(font, 'getbbox'):
		left, top, right, bottom = font.getbbox(text)
		return right - left, bottom - top, left, top
	width, height = font.getsize(text)
	ox, oy = font.getoffset(text)
	return width - ox, height - oy, ox, oy


def _rounded(draw, box, radius, fill):
	x0, y0, x1, y1 = box
	draw.rectangle((x0 + radius, y0, x1 - radius, y1), fill=fill)
	draw.rectangle((x0, y0 + radius, x1, y1 - radius), fill=fill)
	d = radius * 2
	draw.pieslice((x0, y0, x0 + d, y0 + d), 180, 270, fill=fill)
	draw.pieslice((x1 - d, y0, x1, y0 + d), 270, 360, fill=fill)
	draw.pieslice((x0, y1 - d, x0 + d, y1), 90, 180, fill=fill)
	draw.pieslice((x1 - d, y1 - d, x1, y1), 0, 90, fill=fill)


def strip_width(path, height):
	"""Width a strip shows at in a box `height` px tall (keep aspect), read from the PNG header; 0 if none."""
	if not path: return 0
	try:
		with open(path, 'rb') as f: header = f.read(24)
		w, h = int.from_bytes(header[16:20], 'big'), int.from_bytes(header[20:24], 'big')
		return int(w * height / float(h)) if h else 0
	except Exception: return 0


def chip_label(name):
	"""lang_eng -> ENG; a known flag name -> its text."""
	if name in LABELS: return LABELS[name]
	if name.startswith('lang_'): return name[5:].upper()
	return name.upper()


def chip_strip(names):
	"""Path of a PNG strip of chips for these flag names, in order, or '' (no names, or drawing failed)."""
	if not names: return ''
	try:
		with _lock: font_path, font = _get_font()
		key = hashlib.md5(('%s|%s|%s' % (_VERSION, font_path, '|'.join(names))).encode('utf-8')).hexdigest()
		folder = os.path.join(addon_profile(), 'chips')
		path = os.path.join(folder, '%s.png' % key)
		if os.path.exists(path): return path
		with _lock: return _draw(names, font, folder, path)
	except Exception as e:
		from modules.kodi_utils import logger
		logger('chips', 'strip %s failed: %r' % ('|'.join(names), e))
		return ''


def _draw(names, font, folder, path):
	if os.path.exists(path): return path   # another thread drew it while this one waited
	from PIL import Image, ImageDraw
	s, h = _SCALE, STRIP_H * _SCALE
	pad, gap, line, radius = int(h * 0.27), int(h * 0.18), max(2, int(h * 0.05)), int(h * 0.22)
	chips, x = [], 0
	# every label centred on the CAPITAL height, so they share a baseline -- centring each on its own ink put
	# 'Blu-ray' (a descender) higher than 'HDR10' beside it
	_cw, cap_h, _cx, cap_top = _measure(font, 'H')
	for name in names:
		text = chip_label(name)
		tw, th, ox, oy = _measure(font, text)
		th, oy = cap_h, cap_top
		w = tw + pad * 2
		if x + w > STRIP_MAX_W * s: break
		chips.append((x, w, text, tw, th, ox, oy))
		x += w + gap
	if not chips: return ''
	width = chips[-1][0] + chips[-1][1]
	canvas = Image.new('RGBA', (width, h), (0, 0, 0, 0))
	draw = ImageDraw.Draw(canvas)
	for cx, w, text, tw, th, ox, oy in chips:
		_rounded(draw, (cx, 0, cx + w - 1, h - 1), radius, _BORDER)
		_rounded(draw, (cx + line, line, cx + w - 1 - line, h - 1 - line), max(1, radius - line), (0, 0, 0, 0))
		draw.text((cx + (w - tw) // 2 - ox, (h - th) // 2 - oy), text, font=font, fill=_TEXT)
	strip = canvas.resize((max(1, width // s), STRIP_H), Image.LANCZOS)
	if not os.path.isdir(folder): make_directory(folder)
	tmp = '%s.%d.tmp' % (path, threading.get_ident())   # the rows are built on several threads at once
	strip.save(tmp, 'PNG')
	os.replace(tmp, path)
	return path
