# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-09-26: Kodi's native settings dialog is DeadLight's settings UI (resources/settings.xml),
# while settings.db stays the store every code path reads. This module keeps the two in step:
#   push_to_kodi(): settings.db -> Kodi, for the UI, MIRROR and DERIVED ids of kodi_settings_spec, only
#                   where Kodi's value differs. Runs at startup, before the dialog opens, and from
#                   SettingsCache.set() for exposed ids (auth flows, choice dialogs, migrations).
#   pull_from_kodi(): Kodi -> settings.db for UI ids only, only where different, through settings_cache.set()
#                   so _name rows and deadlight.* window properties update exactly as before. Runs from the
#                   service's onSettingsChanged.
# Loops cannot form: a pull sets a flag that stops set() pushing back, and a push of an unchanged value
# writes nothing. Ids that are not exposed (tokens, refresh stamps, smartplay.state ...) never touch Kodi,
# so background token refreshes cause no settings events.
import threading
import xbmc
import xbmcaddon
from modules.kodi_settings_spec import UI, MIRROR, DERIVED, CATEGORIES

ADDON_ID = 'plugin.video.deadlight'
EMPTY = ('empty_setting', 'None', '', None)
_local = threading.local()
_EXPOSED = set(UI) | set(MIRROR)
_DERIVED_BY_SOURCE = {}
for _d, _s in DERIVED.items(): _DERIVED_BY_SOURCE.setdefault(_s, []).append(_d)

def _addon():
	return xbmcaddon.Addon(ADDON_ID)

def _db_value(setting_id):
	from caches.settings_cache import get_setting, default_setting_values
	value = get_setting('deadlight.%s' % setting_id, None)
	if value is None:
		row = default_setting_values(setting_id)
		value = row['setting_default'] if row else ''
	return value

def to_kodi(setting_id, db_value):
	if setting_id in DERIVED: return 'false' if db_value in EMPTY else 'true'
	if db_value in EMPTY: return ''
	if setting_id == 'default_addon_fanart':
		from caches.settings_cache import default_setting_values
		if db_value == default_setting_values(setting_id)['setting_default']: return ''
	if UI.get(setting_id) == 'integer':
		try: return str(int(float(db_value)))
		except (TypeError, ValueError): return db_value
	return db_value

def from_kodi(setting_id, kodi_value):
	if kodi_value in ('', None):
		from caches.settings_cache import default_setting_values
		row = default_setting_values(setting_id)
		default = row['setting_default'] if row else ''
		if default in ('empty_setting', 'None') or setting_id == 'default_addon_fanart': return default
		return ''
	if UI.get(setting_id) == 'integer':
		try: return str(int(float(kodi_value)))
		except (TypeError, ValueError): return kodi_value
	return kodi_value

def _source_value(setting_id):
	return _db_value(DERIVED[setting_id]) if setting_id in DERIVED else _db_value(setting_id)

def push_to_kodi(ids=None):
	"""settings.db -> Kodi, only what differs. Returns the ids written."""
	ids = list(ids) if ids is not None else list(UI) + list(MIRROR) + list(DERIVED)
	addon, written = _addon(), []
	for setting_id in ids:
		try:
			want = to_kodi(setting_id, _source_value(setting_id))
			if addon.getSetting(setting_id) != want:
				addon.setSetting(setting_id, want)
				written.append(setting_id)
		except Exception as e:
			xbmc.log('[ DeadLight ] kodi_settings push %s failed: %s' % (setting_id, e), xbmc.LOGWARNING)
	return written

def pull_from_kodi():
	"""Kodi -> settings.db for the ids the user edits in Kodi, only what changed. Returns the ids updated."""
	from caches.settings_cache import settings_cache
	addon, changed = _addon(), []
	_local.pulling = True
	try:
		for setting_id in UI:
			try:
				new = from_kodi(setting_id, addon.getSetting(setting_id))
				if new != from_kodi(setting_id, to_kodi(setting_id, _db_value(setting_id))):
					settings_cache.set(setting_id, new)
					changed.append(setting_id)
			except Exception as e:
				xbmc.log('[ DeadLight ] kodi_settings pull %s failed: %s' % (setting_id, e), xbmc.LOGWARNING)
	finally:
		_local.pulling = False
	derived = [d for s in changed for d in _DERIVED_BY_SOURCE.get(s, [])]
	if derived: push_to_kodi(derived)
	return changed

def after_set(setting_id):
	"""Called by SettingsCache.set(): mirror an exposed id (and anything derived from it) into Kodi."""
	if getattr(_local, 'pulling', False): return
	ids = ([setting_id] if setting_id in _EXPOSED else []) + _DERIVED_BY_SOURCE.get(setting_id, [])
	if ids: push_to_kodi(ids)

def open_settings(category=None):
	push_to_kodi()
	xbmc.executebuiltin('Addon.OpenSettings(%s)' % ADDON_ID)
	if category not in CATEGORIES: return
	# POV's focus trick: in Kodi 20+ the category buttons of the add-on settings dialog are (index - 200).
	try:
		xbmc.sleep(250)
		xbmc.executebuiltin('SetFocus(%d)' % (CATEGORIES.index(category) - 200))
	except Exception: pass
