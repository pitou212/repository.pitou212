# -*- coding: utf-8 -*-
import sys
from modules.router import routing, sys_exit_check
# from modules.kodi_utils import logger

routing(sys)
# LOCAL PATCH 2026-09-26: rating backfills a directory listing deferred (see
# modules/metadata.flush_rating_backfills). routing() has returned, so endOfDirectory has
# already delivered the list; only runs if this process loaded metadata at all.
_metadata = sys.modules.get('modules.metadata')
if _metadata is not None:
	try: _metadata.flush_rating_backfills()
	except Exception: pass
# LOCAL PATCH 2026-09-26: action rows of Kodi's settings dialog close it before running (the dialog
# would otherwise overwrite what the action saves); reopen it on the same category afterwards.
if 'reopen_settings=' in sys.argv[2]:
	try:
		from urllib.parse import parse_qsl
		from modules.kodi_settings import open_settings
		open_settings(dict(parse_qsl(sys.argv[2].lstrip('?'))).get('reopen_settings'))
	except Exception: pass
# LOCAL PATCH 2026-09-27: close every database handle ourselves, now, rather than leaving them to Kodi's
# interpreter teardown -- see caches/base_cache.close_all_connections for the deadlock this avoids.
_base_cache = sys.modules.get('caches.base_cache')
if _base_cache is not None:
	try: _base_cache.close_all_connections()
	except Exception: pass
if sys_exit_check(): sys.exit(1)
