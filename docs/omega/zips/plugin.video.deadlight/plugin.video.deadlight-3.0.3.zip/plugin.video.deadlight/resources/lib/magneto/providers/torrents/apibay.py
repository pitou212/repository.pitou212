# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-09-29: apibay -- The Pirate Bay's JSON search API, searched by NAME.

	Replaces knaben (removed the same day: seconds per search). Timed 2026-09-29: 0.43-0.81 s per query,
	Reacher S02E01 25 rows, and the Monster: The Lizzie Borden Story packs (TMDb gives that show no IMDb id,
	so every IMDb-keyed provider finds nothing) -- the reason a name search is bundled at all.

	API: https://apibay.org/q.php?q=<query>&cat=0   No key. JSON list of at most 100 rows:
	  {'name', 'info_hash' (upper case), 'seeders', 'size' (bytes, as a string), 'category', 'imdb', ...}
	No hits is ONE placeholder row, 'No results returned' with an all-zero hash.
	Category 2xx is video (201 movies, 205 TV, 207 HD movies, 208 HD TV, ...); 1xx audio (soundtracks),
	6xx e-books and the rest are dropped.

	Laid out like torrentdownload.py (episode / season-pack / show-pack queries in parallel threads), using
	client.request so the loading window's ok / failed tally sees it.
"""

import json
import re
from urllib.parse import quote
from magneto.modules import client
from magneto.modules import source_utils
from magneto.modules import workers

_NO_HASH = '0' * 40


class source:
	priority = 3
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		self.language = ['en']
		self.base_link = 'https://apibay.org'
		self.search_link = '/q.php?q=%s&cat=0'
		self.min_seeders = 0

	def _query(self, query):
		"""apibay's rows for one query: video categories only, placeholder dropped, each hash once per scrape."""
		url = '%s%s' % (self.base_link, self.search_link % quote(query))
		results = client.request(url, timeout=5)
		if not results: return []
		rows = []
		for row in json.loads(results):
			hash = (row.get('info_hash') or '').lower()
			if not hash or hash == _NO_HASH or not str(row.get('category', '')).startswith('2'): continue
			if hash in self.seen: continue
			self.seen.add(hash)
			rows.append(row)
		return rows

	def _item(self, row, name, name_info):
		"""The common part of an episode / movie / pack row, or None when it is below min_seeders."""
		try: seeders = int(row.get('seeders', 0))
		except: seeders = 0
		if self.min_seeders > seeders: return None
		hash = row['info_hash'].lower()
		url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
		quality, info = source_utils.get_release_quality(name_info, url)
		try:
			dsize, isize = source_utils.convert_size(float(row.get('size', 0)), to='GB')
			info.insert(0, isize)
		except: dsize = 0
		return {'provider': 'apibay', 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name, 'name_info': name_info,
				'quality': quality, 'language': 'en', 'url': url, 'info': ' | '.join(info), 'direct': False, 'debridonly': True, 'size': dsize}

	def sources(self, data, hostDict):
		self.items = []
		if not data: return self.items
		self.seen = set()
		try:
			self.aliases = data['aliases']
			self.year = data['year']
			if 'tvshowtitle' in data:
				self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
				self.episode_title = data['title']
				self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
			else:
				self.title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
				self.episode_title = None
				self.hdlr = self.year
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			self.get_sources('%s %s' % (re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title), self.hdlr))
			return self.items
		except:
			source_utils.scraper_error('APIBAY')
			return self.items

	def get_sources(self, query):
		try: rows = self._query(query)
		except:
			source_utils.scraper_error('APIBAY')
			return
		for row in rows:
			try:
				name = source_utils.clean_name(row['name'])
				if not source_utils.check_title(self.title, self.aliases, name, self.hdlr, self.year): continue
				name_info = source_utils.info_from_name(name, self.title, self.year, self.hdlr, self.episode_title)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				if not self.episode_title: # episodes returned by a movie query
					ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
					name_lower = name.lower()
					if any(re.search(item, name_lower) for item in ep_strings): continue
				item = self._item(row, name, name_info)
				if item: self.items.append(item)
			except:
				source_utils.scraper_error('APIBAY')

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		self.items = []
		if not data: return self.items
		self.seen = set()
		try:
			self.search_series = search_series
			self.total_seasons = total_seasons
			self.bypass_filter = bypass_filter
			self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			self.aliases = data['aliases']
			self.imdb = data['imdb']
			self.year = data['year']
			self.season_x = data['season']
			self.season_xx = self.season_x.zfill(2)
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			query = re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title)
			if search_series: queries = [query + ' Season', query + ' Complete']
			else: queries = [query + ' S%s' % self.season_xx, query + ' Season %s' % self.season_x]
			threads = [workers.Thread(self.get_sources_packs, q) for q in queries]
			[i.start() for i in threads]
			[i.join() for i in threads]
			return self.items
		except:
			source_utils.scraper_error('APIBAY')
			return self.items

	def get_sources_packs(self, query):
		try: rows = self._query(query)
		except:
			source_utils.scraper_error('APIBAY')
			return
		for row in rows:
			try:
				name = source_utils.clean_name(row['name'])
				episode_start, episode_end = 0, 0
				if not self.search_series:
					if not self.bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(self.title, self.aliases, self.year, self.season_x, name)
						if not valid: continue
					package = 'season'
				else:
					if not self.bypass_filter:
						valid, last_season = source_utils.filter_show_pack(self.title, self.aliases, self.imdb, self.year, self.season_x, name, self.total_seasons)
						if not valid: continue
					else: last_season = self.total_seasons
					package = 'show'
				name_info = source_utils.info_from_name(name, self.title, self.year, season=self.season_x, pack=package)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				item = self._item(row, name, name_info)
				if not item: continue
				item['package'] = package
				if self.search_series: item['last_season'] = last_season
				elif episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end}) # partial season packs
				self.items.append(item)
			except:
				source_utils.scraper_error('APIBAY')
