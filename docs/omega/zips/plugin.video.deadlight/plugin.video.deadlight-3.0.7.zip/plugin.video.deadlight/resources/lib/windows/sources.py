# -*- coding: utf-8 -*-
import json
import time
from windows.base_window import BaseDialog
from caches.settings_cache import set_setting
from modules.debrid import debrid_for_ext_cache_check
from modules.utils import TaskPool
from modules.source_utils import source_filters, release_group as _release_group, provider_display_name, dv_profile_named
from modules.chips import chip_strip, strip_width, text_lines
import re as _re

# LOCAL PATCH 2026-09-26: the widelist rows show extraInfo's tags as flags, in kind order -- HDR (2),
# source, audio (2), channels, language (2); no video codec, by choice -- packed from the left, so a row missing a kind
# has no gap (fixed columns were tried first and left one). The flag<n> property names are just the
# eight slots in order; the XML places them at an even step. Flags are AF3's colour flags, bundled in
# skins/Default/media/deadlight_flags/source_info with their CC BY-NC-SA credit. The table covers
# every tag source_utils.get_info can emit. A tag with no faithful flag, or one past its column's
# slots, stays text on the meta line: HYBRID, SDR, containers, and the Indian regional
# languages -- AF3's hin, tam and tel are the same Indian flag and its 'mal' is Malay, not
# Malayalam, so only Hindi is a flag.
# LOCAL PATCH 2026-09-27: white logos (source_white: AF3's colour flags recoloured white; languages stay in colour).
# The colour set is kept in source_info -- point back there to undo.
_FLAG_PATH = 'deadlight_flags/source_white/%s.png'
_FLAG_COLUMNS = (
	('hdr', 2, (('D/VISION', 'dolbyvision'), ('HDR10+', 'hdr10plus'), ('HDR', 'hdr10'))),
	# LOCAL PATCH 2026-10-01: + REMUX, ranked over BLURAY -- it is the more specific of the two and the column has
	# one slot (a BDRemux name often carries no BLURAY tag at all, and showed no source chip)
	('source', 1, (('REMUX', 'remux'), ('WEB', 'web'), ('BLURAY', 'bluray'), ('HDTV', 'hdtv'), ('DVD', 'dvd'), ('PDTV', 'sdtv'))),
	('audio', 2, (('ATMOS', 'atmos'), ('TRUEHD', 'truehd'), ('DTS-X', 'dtsx'), ('DTS-HD MA', 'dtshd_ma'), ('DTS-HD', 'dtshd_hra'),
				('DTS', 'dts'), ('DD+', 'eac3'), ('DD', 'ac3'), ('DD-EX', 'ac3'), ('AAC', 'aac'), ('OPUS', 'opus'), ('FLAC', 'flac'), ('MP3', 'mp3'))),
	('ch', 1, (('2CH', 'ch2'), ('6CH', 'ch6'), ('7CH', 'ch7'), ('8CH', 'ch8'))),
	('lang', 2, (('MULTI-LANG', 'lang_multi'), ('ENGLISH', 'lang_eng'), ('HINDI', 'lang_hin'), ('SPANISH', 'lang_spa'), ('FRENCH', 'lang_fre'), ('GERMAN', 'lang_ger'),
				('ITALIAN', 'lang_ita'), ('RUSSIAN', 'lang_rus'), ('JAPANESE', 'lang_jpn'), ('KOREAN', 'lang_kor'), ('CHINESE', 'lang_chi'),
				('ARABIC', 'lang_ara'), ('TURKISH', 'lang_tur'), ('DUTCH', 'lang_dut'), ('POLISH', 'lang_pol'), ('PORTUGUESE', 'lang_por'))))
_FLAG_OF = dict((tag, (column, rank, name)) for column, _, tags in _FLAG_COLUMNS for rank, (tag, name) in enumerate(tags))
_LEFT_FLAGS = tuple('flag%d' % (n + 1) for n in range(sum(slots for _, slots, _ in _FLAG_COLUMNS)))   # flag1..flag8
_CHIP_LINE = 885                                   # list row line 2, from the chips' left edge to the row's right margin
_SITE_SLOTS = tuple(range(200, 701, 50))           # the site . group label widths sources_results.xml offers (200..700)
_MARKUP = _re.compile(r'\[/?(?:B|I|COLOR[^\]]*)\]', _re.I)


# Streaming-service codes -> the studio logo shown on the row (resource.images.studios.coloured, the
# pack AF3 uses; file names as the pack's index lists them). Searched only from the resolution on
# ('2160p ATVP WEB-DL'), falling back to the part after SxxEyy/year: episode titles sit between the
# two, and 'Stan' / 'Hulu' there are title words.
_STUDIO_PATH = 'resource://resource.images.studios.coloured/%s.png'
# LOCAL PATCH 2026-09-26: display labels too long for the row's left block ('HTTP_STRE...'). DISPLAY ONLY,
# via provider_label and Site: -- 'provider' itself must keep the scraper's name: the filter panel sorts
# its provider list by the provider-order setting (make_filter_items), and 'DIRECT' is not in that list.
_SHORT_LABEL = {'HTTP_STREAMS': 'DIRECT'} # Direct Streams
# the left block's provider: full names, except HTTP_STREAMS (173 px at font10 bold -- wider than the
# 150 px column sized for REAL-DEBRID / AIOSTREAMS)
_SHORT_PROVIDER = {'HTTP_STREAMS': 'DIRECT'}
_SERVICES = (('atvp', 'apple tv+'), ('atv', 'apple tv+'), ('amzn', 'prime video'), ('nf', 'netflix'), ('dsnp', 'disney+'),
			 ('hmax', 'hbo max'), ('pcok', 'peacock'), ('pmtp', 'paramount+'), ('hulu', 'hulu'), ('cr', 'crunchyroll'),
			 ('stan', 'stan'), ('mubi', 'mubi'), ('stz', 'starz'), ('amcp', 'amc+'))
_SERVICE = _re.compile(r'(?i)(?<![a-z0-9])(%s)(?![a-z0-9])' % '|'.join(code for code, _ in _SERVICES))
_SERVICE_LOGO = dict(_SERVICES)
# LOCAL PATCH 2026-09-29: + a bare season number -- a season pack ('Neagley S01 MULTi VF2 2160p') has no SxxEyy,
# so its language tags before the resolution were never read
_TECH_START = _re.compile(r'(?i)(?<![a-z0-9])(?:s\d{1,2}\s?e\d{1,4}|s\d{1,2}|(?:19|20)\d{2}|\d{3,4}[pi])(?![a-z0-9])')
_RESOLUTION = _re.compile(r'(?i)(?<![a-z0-9])\d{3,4}[pi](?![a-z0-9])')


def _service_split(name):
	"""(everything before the service-bearing part, the service-bearing part)."""
	name = name or ''
	m = _RESOLUTION.search(name) or _TECH_START.search(name)
	return (name[:m.start()], name[m.start():]) if m else (name, '')


# LOCAL PATCH 2026-09-26: audio languages the release NAME states, as the tags get_info would have used.
# get_info only ever tags MULTI-LANG, and full language words come from http_streams alone -- so torrent
# rows ('... Amare ed essere amato ITA ENG 2160p ...') showed no language at all. Two readers, each
# guarded against title words:
#   * 3-letter codes: UPPERCASE only between SxxEyy / year and the resolution -- episode titles live
#     there and are Title Case, so 'Eng' or 'Ita' in one cannot match; ANY case from the resolution on,
#     where no title words are left (MediaFusion writes '... REMUX Fra').
#   * full words ('Hindi', 'French') and MULTI / DUAL AUDIO, any case, from the resolution on only.
# Codes for languages with no faithful flag (TAM, TEL, MAL, KAN) are left out -- they would only be text.
_LANG_CODES = {'ENG': 'ENGLISH', 'HIN': 'HINDI', 'SPA': 'SPANISH', 'ESP': 'SPANISH', 'FRA': 'FRENCH', 'FRE': 'FRENCH',
			   'GER': 'GERMAN', 'DEU': 'GERMAN', 'ITA': 'ITALIAN', 'RUS': 'RUSSIAN', 'JPN': 'JAPANESE', 'JAP': 'JAPANESE',
			   'KOR': 'KOREAN', 'CHI': 'CHINESE', 'CHN': 'CHINESE', 'ARA': 'ARABIC', 'TUR': 'TURKISH', 'DUT': 'DUTCH',
			   'NLD': 'DUTCH', 'POL': 'POLISH', 'POR': 'PORTUGUESE',
			   # LOCAL PATCH 2026-09-29: French scene tags -- VF (dub), VFF (France), VFQ (Quebec), VFI (international),
			   # VF2 (both), TRUEFRENCH ('Neagley S01 MULTi VF2 2160p' showed MULTI alone)
			   'VF': 'FRENCH', 'VFF': 'FRENCH', 'VFQ': 'FRENCH', 'VFI': 'FRENCH', 'VF2': 'FRENCH', 'TRUEFRENCH': 'FRENCH'}
_LANG_CODE = _re.compile(r'(?<![A-Za-z0-9])(%s)(?![A-Za-z0-9])' % '|'.join(_LANG_CODES))
_LANG_CODE_ANYCASE = _re.compile(r'(?i)(?<![a-z0-9])(%s)(?![a-z0-9])' % '|'.join(_LANG_CODES))
_LANG_WORD = _re.compile(r'(?i)(?<![a-z])(english|hindi|spanish|french|german|italian|russian|japanese|korean|chinese|arabic|'
						 r'turkish|dutch|polish|portuguese)(?![a-z])')
_MULTI_WORD = _re.compile(r'(?i)(?<![a-z])(?:multi|dual[\s._-]?audio)(?![a-z])')


def _name_languages(name):
	"""Language tags ('ENGLISH', 'MULTI-LANG', ...) a release name states, in order, once each."""
	name = name or ''
	m = _TECH_START.search(name)
	after_marker = name[m.start():] if m else ''
	from_resolution = _service_split(name)[1]
	out = []
	codes = _LANG_CODE.findall(after_marker) + [c.upper() for c in _LANG_CODE_ANYCASE.findall(from_resolution)]
	for tag in ([_LANG_CODES[c] for c in codes] + [w.upper() for w in _LANG_WORD.findall(from_resolution)]
				+ (['MULTI-LANG'] if _MULTI_WORD.search(from_resolution) else [])):
		if tag not in out: out.append(tag)
	return out


def _studio_flag(name, tags):
	"""The studio logo for a release, or ''. The name's service code first; get_info's APPLETV+ tag after."""
	m = _SERVICE.search(_service_split(name)[1])
	if m: return _STUDIO_PATH % _SERVICE_LOGO[m.group(1).lower()]
	if 'APPLETV+' in (t.upper() for t in tags): return _STUDIO_PATH % 'apple tv+'
	return ''


def _flag_columns(extra_info):
	"""({flag<n>: texture path}, the tags with no flag as text) for one extraInfo."""
	found, text, seen = {}, [], set()
	for raw in (extra_info or '').split('|'):
		tag = _MARKUP.sub('', raw).strip()
		if not tag or tag == 'N/A': continue
		hit = _FLAG_OF.get(tag.upper())
		if hit is None: text.append(tag)
		elif hit[2] not in seen:
			seen.add(hit[2])
			found.setdefault(hit[0], []).append((hit[1], hit[2], tag))
	# HDR10+ rows also carry the broad HDR tag (kept for the HDR filter); one HDR flag is enough
	if 'hdr10plus' in seen: found['hdr'] = [f for f in found['hdr'] if f[1] != 'hdr10']
	# MULTI only says "more than one language" -- with two languages named it would only push one of them
	# out of the two slots ('ITA ENG' showed MULTI + UK, no Italy). One named language keeps MULTI beside it.
	named = [f for f in found.get('lang', []) if f[1] != 'lang_multi']
	if len(named) >= 2: found['lang'] = named
	# HYBRID means DV + an HDR10 layer in one file -- two flags in the HDR column already say it, and the
	# word was what pushed the meta line past its width on every DV row
	if len(found.get('hdr', [])) >= 2: text = [t for t in text if t.upper() != 'HYBRID']
	# LOCAL PATCH 2026-09-26: PACKED, not fixed columns -- a row without HDR left a gap where the HDR
	# flags would sit. Kind order and per-kind limits stay; the flags fill the slots in order.
	packed = []
	for column, slots, _ in _FLAG_COLUMNS:
		ranked = sorted(found.get(column, []))
		packed.extend(_FLAG_PATH % name for _, name, _ in ranked[:slots])
		text.extend(tag for _, _, tag in ranked[slots:])   # past the kind's limit: kept, as text
	# LOCAL PATCH 2026-10-01: left-packed flag1..flag8. Every layout now shows these as text chips (modules/chips.py,
	# fed the flag names) and the logos only as the fallback when no strip could be drawn. The widelist's
	# right-packed col_* slots and flag_lead (its details-line width) went with the widelist's flag strip.
	props = dict((key, packed[n] if n < len(packed) else '') for n, key in enumerate(_LEFT_FLAGS))
	return props, text


# LOCAL PATCH 2026-09-29: the resolve screen's tag line (modules/sources.py resolve_display). extraInfo
# lists tags in whatever order the provider or get_info wrote them; here they read by kind, like the flags
# above -- HDR, codec, source, audio, channels, language, then the rest -- joined with the heading's dot.
# The same dedup as _flag_columns, and the languages the release name states (the results rows show them).
# LOCAL PATCH 2026-10-02: MPEG out of the codec kind -- get_info's MPEG is the .mp4 / .mpg CONTAINER (like MKV), so it
# read 'Dolby Vision . HEVC . MPEG . WEB' under VIDEO. Unranked now, it lands in OTHER beside MKV.
_TAG_KINDS = (('D/VISION', 'HDR10+', 'HDR', 'SDR', 'HYBRID'), ('HEVC', 'AV1', 'AVC', 'XVID', 'DIVX'),
			  ('REMUX', 'BLURAY', 'WEB', 'HDTV', 'DVD', 'PDTV', 'HDRIP'),
			  ('ATMOS', 'TRUEHD', 'DTS-X', 'DTS-HD MA', 'DTS-HD', 'DTS', 'DD+', 'DD-EX', 'DD', 'AAC', 'OPUS', 'FLAC', 'MP3'),
			  ('2CH', '6CH', '7CH', '8CH'),
			  ('MULTI-LANG',) + tuple(tag for tag, _ in _FLAG_COLUMNS[4][2] if tag != 'MULTI-LANG'))
_TAG_RANK = dict((tag, (kind, rank)) for kind, tags in enumerate(_TAG_KINDS) for rank, tag in enumerate(tags))
# how each tag READS on that line: words capitalised, acronyms (HDR, HEVC, DD+, WEB) left as they are, channel
# counts as speaker layouts. Display only -- extraInfo and the filters keep get_info's tags.
_TAG_DISPLAY = {'D/VISION': 'Dolby Vision', 'HYBRID': 'Hybrid', 'REMUX': 'Remux', 'BLURAY': 'Blu-ray', 'HDRIP': 'HDRip',
				'ATMOS': 'Atmos', 'TRUEHD': 'TrueHD', 'OPUS': 'Opus', 'XVID': 'XviD', 'DIVX': 'DivX',
				'2CH': '2.0', '6CH': '5.1', '7CH': '6.1', '8CH': '7.1', 'MULTI-LANG': 'Multi-Lang', 'SUBS': 'Subs',
				'APPLETV+': 'Apple TV+', 'AI ENHANCED/UPSCALED': 'AI Upscaled',
				# LOCAL PATCH 2026-10-01: the pack tag make_items prefixes ('%s PACK' % package) -- display only, extraInfo
				# keeps 'PACK' uppercase for Filter by Info's substring match
				'SEASON PACK': 'Season Pack', 'SHOW PACK': 'Show Pack', 'TRUE PACK': 'Pack'}
_TAG_DISPLAY.update((tag, tag.capitalize()) for tag in _TAG_KINDS[5][1:])   # ENGLISH -> English


def resolve_tags_line(extra_info, name=''):
	"""extraInfo's tags (+ the name's languages) in kind order, once each, joined with '  ·  '."""
	tags = []
	for raw in (extra_info or '').split('|') + _name_languages(name):
		tag = _MARKUP.sub('', raw).strip()
		if tag and tag != 'N/A' and tag.upper() not in (t.upper() for t in tags): tags.append(tag)
	upper = set(t.upper() for t in tags)
	drop = set()
	if 'HDR10+' in upper: drop.add('HDR')
	if 'D/VISION' in upper and ('HDR' in upper or 'HDR10+' in upper): drop.add('HYBRID')
	if len(upper & set(_TAG_KINDS[5][1:])) >= 2: drop.add('MULTI-LANG')
	other = len(_TAG_KINDS)
	ordered = sorted(enumerate(t for t in tags if t.upper() not in drop),
					 key=lambda p: _TAG_RANK.get(p[1].upper(), (other, p[0])))
	return '  ·  '.join(_TAG_DISPLAY.get(t.upper(), t) for _, t in ordered)


# LOCAL PATCH 2026-10-01: the list layout's detail panel (design A) shows the tags in rows by kind --
# VIDEO (HDR, codec, source), AUDIO (codec, channels), LANGUAGE, OTHER -- read off resolve_tags_line's
# ordered, de-duplicated output so both say the same thing.
_DISPLAY_KIND = dict((_TAG_DISPLAY.get(tag, tag), kind) for kind, tags in enumerate(_TAG_KINDS) for tag in tags)


_SIZE_UNITS = {'KB': 1024, 'MB': 1024 ** 2, 'GB': 1024 ** 3, 'TB': 1024 ** 4}   # size_label is bytes / 1024**n


def label_bytes(size_label):
	"""'87.98 GB' -> bytes, or 0."""
	try:
		number, unit = (size_label or '').split()
		return float(number) * _SIZE_UNITS[unit.upper()]
	except (ValueError, KeyError): return 0


def bitrate_label(size_label, duration, pack=False):
	"""'≈ 98 Mbps' from the size and the runtime (seconds), or '' -- a pack's size covers many episodes."""
	if pack or not duration: return ''
	try: mbps = label_bytes(size_label) * 8 / float(duration) / 1000000
	except (ValueError, ZeroDivisionError): return ''
	if mbps < 0.5: return ''
	# no-break spaces: the cards sidebar wrapped '≈ 41' and 'MBPS' onto separate lines (screenshot 120)
	return '≈ %s Mbps' % ('%d' % round(mbps) if mbps >= 10 else '%.1f' % mbps)


# LOCAL PATCH 2026-10-01: the cards layout's chips, two strips one above the other (sources_results.xml chips_a,
# chips_b: 381 x 32 each). Line 1 takes chips while they fit, measured from each chip's own one-chip strip (drawn
# once per tag and cached like every strip) plus _draw's gap; the rest go to line 2, shrunk to fit if they must.
_CARD_CHIP_W, _CARD_CHIP_H = 381, 32


def _card_chip_lines(names):
	"""(line 1 strip, line 2 strip) for these flag names; '' for an empty line."""
	if not names: return '', ''
	gap, used, split = _CARD_CHIP_H * 0.18, 0, 0
	for name in names:
		need = strip_width(chip_strip([name]), _CARD_CHIP_H) + (gap if split else 0)
		if split and used + need > _CARD_CHIP_W: break
		used += need
		split += 1
	return chip_strip(names[:split]), chip_strip(names[split:])


# LOCAL PATCH 2026-10-02: the tag rows' separator with NO-BREAK spaces after the dot. Kodi wraps a textbox at plain spaces
# only, so a wrapped line (the cards sidebar) now carries the dot down with its tag ('· WEB') instead of ending on '·'.
_WRAP_SEP = '  ·  '


# LOCAL PATCH 2026-10-02: known release groups, highlighted in BOLD colour (display only -- the sort is untouched).
# From TRaSH Guides (github.com/TRaSH-Guides/Guides, docs/json/{radarr,sonarr}/cf, read 2026-10-02), Radarr and Sonarr
# together: GOLD = tier 01 of Remux, UHD Bluray, HD Bluray and WEB; BLUE = their tiers 02-03; PINK (anime) = Anime BD tiers
# 01-03 and Anime Web tiers 01-02, plus SeaDex's own best groups (releases.moe, read the same day: marked best >= 20 times
# and at least as often as alternative). A group in two lists takes the higher. Lower anime tiers (Erai-Raws, SubsPlease...)
# stay uncoloured. Names are matched lower-case without '@' or edge dashes ('-ZR-' -> 'zr'). To refresh: re-read the same
# JSON files and rebuild these three tuples.
_TIER_GOLD = (
	'3l', 'abbie', 'ajp69', 'apex', 'atelier', 'bbq', 'bizkit', 'bluranium', 'blutonium', 'bmf', 'byndr', 'c0ke',
	'casstudio', 'chotab', 'cinephiles', 'cmrg', 'crfw', 'crisc', 'crud', 'ctrlhd', 'd-z0n3', 'dariush', 'decibel',
	'don', 'ebp', 'edph', 'flux', 'framestor', 'geek', 'gnome', 'hone', 'kings', 'kitsune', 'lolhd', 'madsky',
	'mainframe', 'monkee', 'ncmt', 'nosivid', 'ntb', 'ntg', 'piramidhead', 'pmp', 'pter', 'qoq', 'rawr', 'rtn', 'sic',
	't6d', 'tayto', 'tdd', 'tepes', 'thefarm', 'tnp', 'tommy', 'viethd', 'visum', 'w4nk3r', 'wildcat', 'zorosenpai',
	'zq')
_TIER_BLUE = (
	'12gaugeshotgun', '3ctweb', 'bhdstudio', 'bloom', 'btw', 'cinefeel', 'cit', 'coo7', 'db', 'deep', 'dooky',
	'dracula', 'ea', 'end', 'epsilon', 'ethics', 'fc', 'flights', 'gnomission', 'hallowed', 'hidt', 'hifi', 'hisd',
	'hqmux', 'ift', 'ijp', 'ika', 'it00nz', 'jetix', 'khn', 'kimchi', 'kralimarko', 'lazy', 'lord', 'miu', 'mzabi',
	'ninjacentral', 'npms', 'nyh', 'orbitron', 'phoenix', 'playbd', 'playhd', 'playweb', 'psig', 'ptp', 'randombytes',
	'roccat', 'rtfm', 'sa89', 'sbr', 'sdcc', 'sicfoi', 'sigma', 'slignome', 'smurf', 'sphd', 'spirit', 'sumvision',
	'surfinbird', 'swaglander', 't4h', 'toa', 'triton', 'tvsmash', 'vision', 'webdv', 'welp', 'xebec')
_TIER_ANIME = (
	'0x539', 'a&c', 'aergia', 'arc', 'arg0', 'arid', 'asakura', 'b00ba', 'baws', 'bbt-rmx', 'beatrice', 'beatrice-raws',
	'blackrose', 'cappybara', 'chucksmux', 'crucible', 'cunny', 'cunnysseur', 'cyan', 'cytox', 'dae', 'demihuman',
	'doc', 'fatesucks', 'fig', 'fle', 'flugel', 'foxtrot', 'gao', 'getittwisted', 'gsk_kun', 'half-baked', 'hatsubs',
	'hchcsen', 'headpatter', 'hydes', 'inka-subs', 'johntitor', 'jysze', 'kawatare', 'koala', 'kulot', 'lacroix',
	'lazyremux', 'legion', 'lostyears', 'lulu', 'lys1th3a', 'mald', 'mcballs', 'meakes', 'mehul', 'moxie', 'mtbb',
	'mysteria', 'nan0', 'nekotan', 'netaro', 'noiy', 'not-vodes', 'npz', 'ntrx', 'okay-subs', 'orphan', 'p9', 'pizza',
	'pmr', 'poopoo', 'rain', 'reza', 'rmx', 'rudy', 'sam', 'scy', 'sekkon', 'serendipity', 'setsugen', 'sgt', 'slyfox',
	'smol', 'solce', 'som', 'subsmix', 'sylvar', 'tenshi', 'ttga', 'uba', 'vodes', 'wap', 'yuri', 'z4st1n', 'zerobuild',
	'zr')
_GROUP_TIERS = dict([(g, 3) for g in _TIER_ANIME] + [(g, 2) for g in _TIER_BLUE] + [(g, 1) for g in _TIER_GOLD])
_GROUP_COLOUR = {1: 'FFE3B341', 2: 'FF9CC9FF', 3: 'FFE58FD9'}   # gold, light blue, pink (anime)


# LOCAL PATCH 2026-10-02: scrape.diag_timing for the window build -- seconds per step, summed over the rows (threads overlap,
# so the sum can exceed the wall time; what matters is which step dominates).
_build_times = {}


def _tick(label, t0):
	t1 = time.perf_counter()
	_build_times[label] = _build_times.get(label, 0.0) + (t1 - t0)
	return t1


# LOCAL PATCH 2026-10-02: the window's row and filter builders use at most 4 threads (fewer on a smaller CPU). The work is
# Python plus Kodi list-item calls, and Python runs one thread at a time: 243 rows took 19 ms on 1 thread, 20 ms on 4 and
# 24 ms on 32 off Kodi, while max_threads() (60, capped to 32 by TaskPool) was being used here. Thread start-up and
# switching cost several times more on the CoreELEC box. The scrapers keep max_threads(): they wait on the network.
def _build_threads(count):
	import os
	return max(1, min(count, 4, os.cpu_count() or 4, max_threads()))


def group_display(group):
	"""The group as the skin shows it: a known group bold in its tier colour, anything else as it is ('' stays '')."""
	colour = _GROUP_COLOUR.get(_GROUP_TIERS.get((group or '').lower().replace('@', '').strip('-')))
	return '[B][COLOR %s]%s[/COLOR][/B]' % (colour, group) if colour and group else (group or '')


# LOCAL PATCH 2026-10-02: per-list facts for the rows -- each quality's count, for the quality header.
def _list_facts(items):
	counts = {}
	for i in items or []:
		q = str(i.get('quality', 'SD')).upper()
		counts[q] = counts.get(q, 0) + 1
	return {'counts': counts}


def tag_groups(extra_info, name=''):
	"""{'tags_video', 'tags_audio', 'tags_lang', 'tags_other'}: resolve_tags_line split by kind, '' for an empty kind."""
	groups = {'tags_video': [], 'tags_audio': [], 'tags_lang': [], 'tags_other': []}
	line = resolve_tags_line(extra_info, name)
	for tag in (line.split('  ·  ') if line else []):
		kind = _DISPLAY_KIND.get(tag)
		key = 'tags_video' if kind in (0, 1, 2) else 'tags_audio' if kind in (3, 4) else 'tags_lang' if kind == 5 else 'tags_other'
		groups[key].append(tag)
	return dict((key, _WRAP_SEP.join(tags)) for key, tags in groups.items())
from modules.settings import provider_sort_ranks, avoid_episode_spoilers, max_threads
from modules.kodi_utils import get_icon, kodi_dialog, hide_busy_dialog, addon_fanart, select_dialog, ok_dialog, notification
# from modules.kodi_utils import logger

class SourcesResults(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.window_format = kwargs.get('window_format', 'list')
		self.window_id = kwargs.get('window_id', 2000)
		self.filter_window_id = 2100
		self.results = kwargs.get('results')
		self.uncached_results = kwargs.get('uncached_results', [])
		self.info_highlights_dict = kwargs.get('scraper_settings')
		self.episode_group_label = kwargs.get('episode_group_label', '')
		self.prescrape = kwargs.get('prescrape')
		self.meta = kwargs.get('meta')
		self.filters_ignored = kwargs.get('filters_ignored', False)
		self.meta_get = self.meta.get
		self.make_poster = self.window_format in ('list', 'medialist')
		self.empty_poster = get_icon('box_office')
		self.addon_fanart = addon_fanart()
		self.poster = self.meta_get('poster') or self.empty_poster
		self.external_cache_check = kwargs.get('external_cache_check')
		self.prerelease_values, self.prerelease_key = ('CAM', 'SCR', 'TELE'), 'CAM/SCR/TELE'
		self.info_icons_dict = {'easynews': get_icon('easynews'), 'alldebrid': get_icon('alldebrid'), 'real-debrid': get_icon('realdebrid'),
		'premiumize': get_icon('premiumize'), 'torbox': get_icon('torbox'), 'ad_cloud': get_icon('alldebrid'), 'rd_cloud': get_icon('realdebrid'),
		'pm_cloud': get_icon('premiumize'), 'tb_cloud': get_icon('torbox'), 'aiostreams': get_icon('aiostreams'), 'http_streams': get_icon('aiostreams')}
		self.info_quality_dict = {'4k': get_icon('flag_4k', 'flags'), '1080p': get_icon('flag_1080p', 'flags'), '720p': get_icon('flag_720p', 'flags'),
		'sd': get_icon('flag_sd', 'flags'), 'cam': get_icon('flag_sd', 'flags'), 'tele': get_icon('flag_sd', 'flags'), 'scr': get_icon('flag_sd', 'flags')}
		_t0 = time.perf_counter(); _build_times.clear()
		self.make_items()
		_t1 = time.perf_counter()
		self.make_filter_items()
		self.make_pills()
		_t2 = time.perf_counter()
		self.set_properties()
		# LOCAL PATCH 2026-10-02: scrape.diag_timing -- where the window build goes (see _tick)
		from caches.settings_cache import get_setting as _gs
		if _gs('deadlight.scrape.diag_timing', 'false') == 'true':
			from modules.kodi_utils import logger
			logger('scrape.timing', 'window build: rows %dms (%d), filters %dms, props %dms; per step (summed over threads): %s'
				% ((_t1 - _t0) * 1000, len(self.item_list or []), (_t2 - _t1) * 1000, (time.perf_counter() - _t2) * 1000,
				', '.join('%s %dms' % (k, v * 1000) for k, v in sorted(_build_times.items()))))

	def onInit(self):
		from modules.kodi_utils import logger
		import xbmc, time
		self.filter_applied = False
		if self.make_poster: self.set_poster()
		self.setProperty('window_format', self.window_format)
		item_count = len(self.item_list) if self.item_list else 0
		filter_count = len(self.filter_list) if self.filter_list else 0
		logger('SourcesResults onInit', 'window_format=%s window_id=%s items=%d filter_items=%d' % (self.window_format, self.window_id, item_count, filter_count))
		self.add_items(self.window_id, self.item_list)
		self.add_items(self.filter_window_id, self.filter_list)
		self.place_pills()
		# LOCAL PATCH 2026-09-26: poll for focus instead of fixed sleeps. The old sleep(80) + check +
		# sleep(120) + retry reported focusedId=0 at +80 ms on every open in the log and only landed
		# at +200 ms -- setFocusId is processed by the GUI thread, so an immediate getFocusId races
		# it. Now: check every 20 ms, re-issue setFocusId every 100 ms, give up at 400 ms (the old
		# path's worst case was ~200 ms, so this only waits longer where the old one fell back).
		try:
			start = time.time()
			focused = 0
			for step in range(20):
				if step % 5 == 0: self.setFocusId(self.window_id)
				xbmc.sleep(20)
				focused = self.getFocusId()
				if focused == self.window_id: break
			logger('SourcesResults onInit', 'focusedId=%s after %d ms' % (focused, int((time.time() - start) * 1000)))
			if focused != self.window_id:
				self.setFocusId(self.filter_window_id)
				logger('SourcesResults onInit', 'fallback focus to filter %s' % self.filter_window_id)
		except Exception as e:
			logger('SourcesResults onInit focus error', str(e))

	def run(self):
		self.doModal()
		self.clearProperties()
		self.clear_home_property('window_theme.sources')
		hide_busy_dialog()
		return self.selected

	def get_provider_and_path(self, provider):
		try: return provider, self.info_icons_dict[provider]
		except: return 'folders', get_icon('folder')

	def get_quality_and_path(self, quality):
		try: return quality, self.info_quality_dict[quality]
		except: return 'sd', get_icon('flag_sd')

	def filter_action(self, action):
		if action == self.right_action or action in self.closing_actions:
			self.select_item(self.filter_window_id, 0)
			self.setFocusId(self.window_id)
		if action in self.selection_actions:
			chosen_listitem = self.get_listitem(self.filter_window_id)
			filter_type, filter_value = chosen_listitem.getProperty('filter_type'), chosen_listitem.getProperty('filter_value')
			if filter_type in ('quality', 'provider'):
				if filter_value == self.prerelease_key: filtered_list = [i for i in self.item_list if i.getProperty(filter_type) in self.prerelease_values]
				else: filtered_list = [i for i in self.item_list if i.getProperty(filter_type) == filter_value]
			elif filter_type == 'special':
				if filter_value == 'title':
					keywords = kodi_dialog().input('Enter Keyword (Comma Separated for Multiple)')
					if not keywords: return
					keywords.replace(' ', '')
					keywords = keywords.split(',')
					choice = [i.upper() for i in keywords]
					filtered_list = [i for i in self.item_list if all(x in i.getProperty('name') for x in choice)]
				elif filter_value == 'extraInfo':
					filters = source_filters()
					list_items = [{'line1': item[0], 'icon': self.poster} for item in filters]
					kwargs = {'items': json.dumps(list_items), 'heading': 'Filter Results', 'multi_choice': 'true'}
					choice = select_dialog(filters, **kwargs)
					if choice == None: return
					choice = [i[1] for i in choice]
					filtered_list = [i for i in self.item_list if all(x in i.getProperty('extraInfo') for x in choice)]
				elif filter_value == 'showuncached': filtered_list = self.make_items(self.uncached_results)
				else: #cache_check_rescrape
					self.selected = ('cache_change_rescrape', 'false' if self.external_cache_check else 'true')
					return self.close()
			if not filtered_list: return ok_dialog(text='No Results')
			self.set_filter(filtered_list)

	def onAction(self, action):
		if self.get_visibility('Control.HasFocus(%s)' % self.filter_window_id): return self.filter_action(action)
		focus_id = self.getFocusId()
		if focus_id in self._PILL_IDS:   # LOCAL PATCH 2026-10-02: quick-filter pills, see make_pills
			if action in self.selection_actions: return self.toggle_pill(focus_id)
			if action == self.down_action: return self.setFocusId(self.window_id)
			if action not in self.closing_actions: return
		chosen_listitem = self.get_listitem(self.window_id)
		if action in self.closing_actions:
			if self.filter_applied: return self.clear_filter()
			self.selected = (None, '')
			return self.close()
		if action == self.info_action:
			self.open_window(('windows.sources', 'SourcesInfo'), 'sources_info.xml', item=chosen_listitem)
		elif action in self.selection_actions:
			if self.prescrape and chosen_listitem.getProperty('perform_full_search') == 'true':
				self.selected = ('perform_full_search', '')
				return self.close()
			chosen_source = json.loads(chosen_listitem.getProperty('source'))
			if 'Uncached' in chosen_source.get('cache_provider', ''):
				from modules.debrid import manual_add_magnet_to_cloud
				return manual_add_magnet_to_cloud({'mode': 'manual_add_magnet_to_cloud', 'provider': chosen_source['debrid'], 'magnet_url': chosen_source['url']})
			self.selected = ('play', chosen_source)
			return self.close()
		elif action in self.context_actions:
			source = json.loads(chosen_listitem.getProperty('source'))
			choice = self.context_menu(source)
			if choice:
				if isinstance(choice, dict): return self.execute_code('RunPlugin(%s)' % self.build_url(choice))
				if choice == 'results_info': return self.open_window(('windows.sources', 'SourcesInfo'), 'sources_info.xml', item=chosen_listitem)
				if choice == 'rd_cloud_delete':
					from apis.real_debrid_api import RealDebridAPI
					rd_api = RealDebridAPI()
					function = rd_api.delete_torrent if source['cache_type'] == 'torrent' else rd_api.delete_download
					result = function(source['folder_id'])
					if result.status_code in (401, 403, 404): return notification('Error', 1200)
					rd_api.clear_cache()
					self.delete_single_source(source)

	def delete_single_source(self, single_source):
		self.results.remove(single_source)
		self.make_items()
		self.total_results = str(len(self.item_list))
		self._reset_results()
		self.add_items(self.window_id, self.item_list)
		self.setFocusId(self.window_id)
		self.set_properties()

	def _set_chips(self, listitem, chip_names):
		# LOCAL PATCH 2026-10-02: the cards layout shows only its two lines -- drawing the one-line strip as well was a
		# third strip per new tag combination, for nothing
		if self.window_format == 'rows':
			_chips = ''
			_line_a, _line_b = _card_chip_lines(chip_names)
			listitem.setProperties({'chips_a': _line_a, 'chips_b': _line_b})
		else: _chips = chip_strip(chip_names)
		listitem.setProperty('chips', _chips)
		# LOCAL PATCH 2026-10-01: the list row's site . group label (2026-10-06: scraper first, bold) takes what the chips leave of line 2 -- the
		# widest of _SITE_SLOTS that fits (sources_results.xml has one label per slot), so it is cut only beside a full strip.
		_free = _CHIP_LINE - (strip_width(_chips, 36) + 20 if _chips else 0)
		listitem.setProperty('site_slot', str(max([0] + [n for n, w in enumerate(_SITE_SLOTS) if w <= _free])))

	def make_items(self, filtered_list=None):
		def builder(count, item):
			try:
				get = item.get
				_t = time.perf_counter()
				listitem = self.make_listitem()
				set_properties = listitem.setProperties
				scrape_provider, source, quality, name = get('scrape_provider'), get('source'), get('quality', 'SD'), get('display_name')
				basic_quality, quality_icon = self.get_quality_and_path(quality.lower())
				pack = get('package', 'false') in ('true', 'show', 'season')
				extraInfo = get('extraInfo', '')
				extraInfo = extraInfo.rstrip('| ')
				if pack: extraInfo = '[B]%s PACK[/B] | %s' % (get('package'), extraInfo)
				if self.episode_group_label: extraInfo = '%s | %s' % (self.episode_group_label, extraInfo)
				if not extraInfo: extraInfo = 'N/A'
				if scrape_provider == 'external':
					source_site = provider_display_name(get('provider'))   # LOCAL PATCH 2026-09-29: APIBAY shows as PIRATEBAY
					provider = get('debrid', source_site).replace('.me', '').upper()
					# LOCAL PATCH 2026-10-02: a hash several scrapers listed (external.py _process_duplicates): 'COMET +2' on
					# the row, every name in the List panel / Cards sidebar, and each one counted by the site filters.
					# 2026-10-06: the row shows the first scraper only, no '+N' (user's call); the rest stay in source_site_full / sites
					_sites = [provider_display_name(p) for p in (get('providers') or [])] or [source_site]
					source_site = _sites[0]
					set_properties({'source_site_full': _WRAP_SEP.join(_sites), 'sites': '|%s|' % '|'.join(s.upper() for s in _sites)})
					provider_lower = provider.lower()
					provider_icon = self.get_provider_and_path(provider_lower)[1]
					if 'Uncached' in item['cache_provider']:
						if 'seeders' in item: set_properties({'source_type': 'UNCACHED (%d SEEDERS)' % get('seeders', 0)})
						else: set_properties({'source_type': 'UNCACHED'})
						set_properties({'highlight': 'FF7C7C7C'})
					else:
						if provider in ('REAL-DEBRID', 'ALLDEBRID'):
							if self.external_cache_check: cache_flag = '[B]CACHED[/B]'
							else: cache_flag = 'UNCHECKED'
						else: cache_flag = '[B]CACHED[/B]'
						if highlight_type == 0: key = provider_lower
						else: key = basic_quality
						# LOCAL PATCH 2026-10-03: .get -- a CAM/SCR/TELE row under 'by quality' raised KeyError into the except
						# below and the row silently vanished (an in-cinemas movie, all CAM, came up empty)
						set_properties({'highlight': self.info_highlights_dict.get(key) or self.info_highlights_dict.get('sd', '')})
						if pack: set_properties({'source_type': '%s [B]PACK[/B]' % cache_flag})
						else: set_properties({'source_type': '%s' % cache_flag})
					set_properties({'provider': provider})
				else:
					source_site = _SHORT_LABEL.get(source.upper(), source.upper())
					set_properties({'source_site_full': source_site, 'sites': '|%s|' % source_site})
					provider, provider_icon = self.get_provider_and_path(source.lower())
					if highlight_type == 0: key = provider
					else: key = basic_quality
					# LOCAL PATCH: http_streams exposes a per-stream `hoster` field (PixelDrain,
					# FSL-V2, HubCloud, etc., derived from URL via _identify_host_from_url).
					# When present, surface it in the Hoster column instead of the generic 'DIRECT'.
					hoster_label = (get('hoster') or '').upper().strip() or 'DIRECT'
					set_properties({'highlight': self.info_highlights_dict.get(key) or self.info_highlights_dict.get('sd', ''), 'source_type': hoster_label, 'provider': provider.upper()})   # LOCAL PATCH 2026-10-03: .get, as above
				# LOCAL PATCH 2026-09-22: release group, shown beside Site in the picker.
				# Providers that clean the name before handing it over destroy the fansub tag
				# (magneto's clean_name deletes the leading bracket outright), so animetosho
				# passes `release_group` explicitly. Everything else -- aiostreams, http_streams,
				# cloud, folders -- keeps a raw-enough name for the same extractor to read a
				# scene-style trailing -GROUP off it, so fall back to that rather than show
				# nothing. Blank is a normal answer: ~15% of live anime names carry no group.
				release_group = (get('release_group') or '').strip()
				if not release_group: release_group = _release_group(get('name') or '')
				# LOCAL PATCH 2026-09-26: no group -> no Group field at all, rather than 'Group: N/A'.
				# The whole segment is built here because the skin cannot hide it: $INFO's prefix
				# form cannot hold the nested $INFO[...(highlight)] colour the label uses.
				release_group = release_group.upper()
				set_properties({'release_group_display': group_display(release_group)})
				group_segment = ('     [COLOR %s][B]Group: [/B][/COLOR]%s' % (listitem.getProperty('highlight'), release_group)) if release_group else ''
				set_properties({'release_group': release_group, 'group_segment': group_segment})
				# LOCAL PATCH 2026-09-26: widelist's flags (see _flag_columns) and studio logo (see _studio_flag).
				# Since 2026-10-01 the list and rows layouts show them too.
				# Tags with no flag are not shown at all -- the row carries the flags and nothing else.
				_t = _tick('1 start..group', _t)
				_langs = _name_languages(name)
				columns, flagless = _flag_columns(' | '.join([extraInfo] + _langs) if _langs else extraInfo)
				set_properties(columns)
				set_properties({'studio_flag': _studio_flag(name, flagless)})
				# LOCAL PATCH 2026-10-01: the list layout's detail panel lists every tag, the flagless ones too (HEVC, REMUX).
				_t = _tick('2 flags+studio', _t)
				set_properties({'tags_line': resolve_tags_line(extraInfo, name), 'name_display': name})
				_groups = tag_groups(extraInfo, name)
				set_properties(_groups)
				# the cards sidebar's last line: language and other in one, so an empty language leaves no leading dot
				set_properties({'tags_lang_other': _WRAP_SEP.join(filter(None, (_groups['tags_lang'], _groups['tags_other'])))})
				_t = _tick('3 tag lines', _t)
				set_properties({'bitrate': bitrate_label(get('size_label'), self.meta_get('ep_duration') or self.meta_get('duration'), pack)})
				# LOCAL PATCH 2026-10-01: the same tags as text chips, one strip image (modules/chips.py); '' -> the skin shows the flags.
				_chip_names = [columns[k].rsplit('/', 1)[-1][:-4] for k in _LEFT_FLAGS if columns.get(k)]
				# LOCAL PATCH 2026-10-05: a profile 7 release gets a P7 chip right after its Dolby Vision chip, which stays as it
				# was. 2026-10-06: only when the NAME says P7 / FEL / MEL (source_utils.dv_profile_named) -- no remux guess
				if 'dolbyvision' in _chip_names:
					_dvp = dv_profile_named(name)
					if _dvp and _dvp.startswith('p7'):
						_at = _chip_names.index('dolbyvision') + 1
						_chip_names = _chip_names[:_at] + ['dv_' + _dvp] + _chip_names[_at:]
				_q = quality.upper()
				set_properties({'quality_head': '%s  ·  %d result%s' % (_q, _facts['counts'].get(_q, 0), '' if _facts['counts'].get(_q, 0) == 1 else 's'),
					'name_lines': str(text_lines(name, 668))})
				_t = _tick('4 name lines', _t)
				# 2026-10-06: the TOP PICK chip (2026-10-04, modules/top_pick.py) is removed -- it named the wrong file too often (user's call)
				self._set_chips(listitem, _chip_names)
				_t = _tick('5 chips', _t)
				_prov = listitem.getProperty('provider')
				set_properties({'provider_label': _SHORT_PROVIDER.get(_prov, _prov)})
				set_properties({'name': name.upper(), 'source_site': source_site, 'provider_icon': provider_icon, 'quality_icon': quality_icon, 'count': '%02d.' % count,
						'size_label': get('size_label', 'N/A'), 'extraInfo': extraInfo, 'quality': quality.upper(), 'hash': get('hash', 'N/A'), 'source': json.dumps(item)})	
				_tick('6 rest', _t)
				item_list.append((listitem, count))
			except: pass
		try:
			item_list = []
			highlight_type = self.info_highlights_dict['highlight_type']
			_facts = _list_facts(filtered_list or self.results)
			if filtered_list:
				threads = TaskPool().tasks_enumerate(builder, filtered_list, _build_threads(len(filtered_list)))
				[i.join() for i in threads]
				item_list.sort(key=lambda k: k[1])
				item_list = [i[0] for i in item_list]
				return item_list
			threads = TaskPool().tasks_enumerate(builder, self.results, _build_threads(len(self.results)))
			[i.join() for i in threads]
			item_list.sort(key=lambda k: k[1])
			self.item_list = [i[0] for i in item_list]
			if self.prescrape:
				prescrape_listitem = self.make_listitem()
				prescrape_listitem.setProperty('perform_full_search', 'true')
			self.total_results = str(len(self.item_list))
			if self.prescrape: self.item_list.append(prescrape_listitem)
		except: pass

	def make_filter_items(self):
		def builder(count, item):
			listitem = self.make_listitem()
			listitem.setProperties({'label': item[0], 'filter_type': item[1], 'filter_value': item[2]})
			self.filter_list.append((listitem, count))
		duplicates = set()
		qualities = [i.getProperty('quality') for i in self.item_list \
							if not (i.getProperty('quality') in duplicates or duplicates.add(i.getProperty('quality'))) \
							and not i.getProperty('quality') == '']
		if any(i in self.prerelease_values for i in qualities): qualities = [i for i in qualities if not i in self.prerelease_values] + [self.prerelease_key]
		_q_order = ('4K', '1080P', '720P', 'SD', 'CAM/SCR/TELE')   # LOCAL PATCH 2026-10-03: an unlisted value sorts last instead of raising
		qualities.sort(key=lambda v: _q_order.index(v) if v in _q_order else len(_q_order))
		quality_totals = {i: len([x for x in self.item_list if x.getProperty('quality') == i]) for i in qualities}
		if 'CAM/SCR/TELE' in qualities: quality_totals['CAM/SCR/TELE'] = len([i for i in self.item_list if i.getProperty('quality') in self.prerelease_values])
		duplicates = set()
		providers = [i.getProperty('provider') for i in self.item_list \
							if not (i.getProperty('provider') in duplicates or duplicates.add(i.getProperty('provider'))) \
							and not i.getProperty('provider') == '']
		provider_totals = {i: len([x for x in self.item_list if x.getProperty('provider') == i]) for i in providers}
		sort_ranks = provider_sort_ranks()
		cache_functions_debrid = debrid_for_ext_cache_check()
		sort_ranks['premiumize'] = sort_ranks.pop('premiumize.me')
		provider_choices = sorted(sort_ranks.keys(), key=sort_ranks.get)
		provider_choices = [i.upper() for i in provider_choices]
		providers.sort(key=lambda v: provider_choices.index(v) if v in provider_choices else len(provider_choices))   # LOCAL PATCH 2026-10-03: as above
		qualities = [('Show [B]%s[/B] Only | [B]%d[/B] Results' % (i, quality_totals[i]), 'quality', i) for i in qualities]
		providers = [('Show [B]%s[/B] Only | [B]%d[/B] Results' % (provider_display_name(i), provider_totals[i]), 'provider', i) for i in providers]
		# LOCAL PATCH 2026-10-09: the per-scraper entries ('Show from torrentio | N Results', added 2026-10-02) are gone (user):
		# appended after the last provider they read as that provider's own list -- every scraper under 'Direct Streams'.
		data = []
		if cache_functions_debrid: data.append(('Rescrape with External Cache Check [B]%s[/B]' % ('OFF' if self.external_cache_check else 'ON'), 'special', 'cache_check_rescrape'))
		if self.uncached_results: data.append(('Show [B]Uncached[/B] Only | [B]%d[/B] Results' % len(self.uncached_results), 'special', 'showuncached'))
		data.extend(qualities)
		data.extend(providers)
		data.extend([('Filter by [B]Title[/B]...', 'special', 'title'), ('Filter by [B]Info[/B]...', 'special', 'extraInfo')])
		self.filter_list = []
		threads = TaskPool().tasks_enumerate(builder, data, _build_threads(len(data)))
		[i.join() for i in threads]
		self.filter_list.sort(key=lambda k: k[1])
		self.filter_list = [i[0] for i in self.filter_list]

	def set_properties(self):
		self.set_home_property('window_theme.sources', self.get_home_property('window_theme'))
		self.setProperty('window_format', self.window_format)
		self.setProperty('fanart', self.meta_get('fanart') or self.addon_fanart)
		self.setProperty('clearlogo', self.meta_get('clearlogo') or '')
		self.setProperty('title', self.meta_get('title'))
		# LOCAL PATCH 2026-10-01: the cards layout's sidebar (sources_results.xml Rows 2001)
		self.setProperty('poster', self.poster)
		self.setProperty('year', str(self.meta_get('year') or ''))
		self.setProperty('total_results', self.total_results)
		self.setProperty('filters_ignored', '| Filters Ignored' if self.filters_ignored else '')

	def set_poster(self):
		if self.window_id == 2000: self.set_image(200, self.poster)

	def context_menu(self, item):
		down_file_params, down_pack_params, browse_pack_params, add_magnet_to_cloud_params, uncached_download = None, None, None, None, None
		item_get = item.get
		item_id, name, magnet_url, info_hash = item_get('id', None), item_get('name'), item_get('url', 'None'), item_get('hash', 'None')
		provider_source, scrape_provider, cache_provider = item_get('source'), item_get('scrape_provider'), item_get('cache_provider', 'None')
		uncached = 'Uncached' in cache_provider
		source, meta_json = json.dumps(item), json.dumps(self.meta)
		choices = []
		choices_append = choices.append
		if not uncached and scrape_provider != 'folders':
			down_file_params = {'mode': 'downloader.runner', 'action': 'meta.single', 'name': self.meta.get('rootname', ''), 'source': source,
								'url': None, 'provider': scrape_provider, 'meta': meta_json}
		if 'package' in item and not uncached:
			down_pack_params = {'mode': 'downloader.runner', 'action': 'meta.pack', 'name': self.meta.get('rootname', ''), 'source': source, 'url': None,
								'provider': cache_provider, 'meta': meta_json, 'magnet_url': magnet_url, 'info_hash': info_hash}
		if provider_source == 'torrent':
			browse_pack_params = {'mode': 'debrid.browse_packs', 'provider': cache_provider, 'name': name,
								'magnet_url': magnet_url, 'info_hash': info_hash}
			# LOCAL PATCH 2026-10-03: the debrid service, not the cache label -- on an uncached row cache_provider is
			# 'Uncached TorBox', which manual_add_magnet_to_cloud could not look up (IndexError, spinner left up).
			add_magnet_to_cloud_params = {'mode': 'manual_add_magnet_to_cloud', 'provider': item_get('debrid') or cache_provider.replace('Uncached ', ''), 'magnet_url': magnet_url}
		choices_append(('Info', 'results_info'))
		if add_magnet_to_cloud_params: choices_append(('Add to Cloud', add_magnet_to_cloud_params))
		if browse_pack_params: choices_append(('Browse', browse_pack_params))
		if down_pack_params: choices_append(('Download Pack', down_pack_params))
		if down_file_params: choices_append(('Download File', down_file_params))
		if provider_source == 'rd_cloud': choices_append(('Delete from RD Cloud', 'rd_cloud_delete'))
		list_items = [{'line1': i[0], 'icon': self.poster} for i in choices]
		kwargs = {'items': json.dumps(list_items)}
		choice = select_dialog([i[1] for i in choices], **kwargs)
		return choice

	def set_filter(self, filtered_list):
		if getattr(self, 'pill_active', None):   # a slide-out filter replaces the pills' selection
			self.pill_active = set()
			self.paint_pills()
		self.filter_applied = True
		self._set_quality_heads(filtered_list)
		self._reset_results()
		self.add_items(self.window_id, filtered_list)
		self.setFocusId(self.window_id)
		self.setProperty('total_results', str(len(filtered_list)))
		self.setProperty('filter_applied', 'true')
		self.setProperty('filter_info', '| Press [B]BACK[/B] to Cancel')

	# LOCAL PATCH 2026-10-02: quick-filter pills (sources_results.xml grouplist 2200, buttons 2201-2206) above the results.
	# Each toggles; qualities are OR-ed with each other, the rest AND-ed. A pill that would change nothing is not shown
	# (one quality only; every row cached / HDR / HQ audio, or none). They filter the full list, like the slide-out
	# filters, and Back clears both.
	_PILL_IDS = (2201, 2202, 2203, 2204, 2205, 2206)
	_PILL_SPOT = {'list': (1290, 52), 'rows': (1271, 92), 'widelist': (1290, 50)}   # grouplist 600 wide, right-aligned
	_HQ_AUDIO = ('ATMOS', 'TRUEHD', 'DTS-HD MA', 'DTS-X', 'FLAC')

	def _pill_match(self, listitem, key):
		if key.startswith('q:'): return listitem.getProperty('quality') == key[2:]
		info = listitem.getProperty('extraInfo')
		if key == 'cached': return 'UNCACHED' not in listitem.getProperty('source_type').upper()
		if key == 'hdr': return '[B]HDR[/B]' in info or '[B]D/VISION[/B]' in info
		if key == 'audio': return any(t in info for t in self._HQ_AUDIO)
		return True

	def make_pills(self):
		items, keys = self.item_list or [], []
		qualities = [q for q in ('4K', '1080P', '720P') if any(i.getProperty('quality') == q for i in items)]
		if len(qualities) > 1: keys.extend(('q:%s' % q, q) for q in qualities)
		for key, label in (('cached', 'CACHED'), ('hdr', 'HDR · DV'), ('audio', 'HQ AUDIO')):
			hits = sum(1 for i in items if self._pill_match(i, key))
			if 0 < hits < len(items): keys.append((key, label))
		self.pill_keys = dict(zip(self._PILL_IDS, keys))
		self.pill_active = set()
		for control_id in self._PILL_IDS:
			self.setProperty('pill_%d_label' % control_id, self.pill_keys[control_id][1] if control_id in self.pill_keys else '')
		self.paint_pills()

	def paint_pills(self):
		for control_id, (key, _label) in self.pill_keys.items():
			on = key in self.pill_active
			self.setProperty('pill_%d_bg' % control_id, 'FF4CD8D0' if on else 'FF262B33')
			self.setProperty('pill_%d_focus' % control_id, 'FF8BE8E2' if on else 'FF465062')
			self.setProperty('pill_%d_fg' % control_id, 'FF0F1316' if on else 'FFE8EDF4')

	def place_pills(self):
		# group 2199, not the grouplist 2200 inside it: getControl raises 'Unknown control type' on a grouplist
		try: self.getControl(2199).setPosition(*self._PILL_SPOT.get(self.window_format, self._PILL_SPOT['list']))
		except Exception as e:
			from modules.kodi_utils import logger
			logger('SourcesResults pills', 'place failed: %s' % e)

	def _reset_results(self):
		"""Empty the results list for a new item set, cursor first. The fixedlists (focusposition 3) keep their cursor
		slot through a reset, so after scrolling a 2-row filter result was drawn from slot 3, half way down the screen
		(screenshot 118). Selecting item 0 of the OLD list first brings the cursor back to the top."""
		try: self.select_item(self.window_id, 0)
		except Exception: pass
		self.reset_window(self.window_id)

	def _set_quality_heads(self, items):
		"""The sticky '1080P  ·  46 results' header counts what is SHOWN: make_items wrote the full list's counts on
		every row, so a filter left '46 results' over 15 (screenshot 117). Rewritten for each filter and on clear."""
		counts = {}
		for i in items: counts[i.getProperty('quality')] = counts.get(i.getProperty('quality'), 0) + 1
		for i in items:
			q = i.getProperty('quality')
			i.setProperty('quality_head', '%s  ·  %d result%s' % (q, counts[q], '' if counts[q] == 1 else 's'))

	def toggle_pill(self, control_id):
		key = self.pill_keys.get(control_id)
		if not key: return
		self.pill_active ^= {key[0]}
		self.paint_pills()
		if not self.pill_active: return self.clear_filter(keep_focus=True)
		quality_keys = [k for k in self.pill_active if k.startswith('q:')]
		other_keys = [k for k in self.pill_active if not k.startswith('q:')]
		filtered = [i for i in self.item_list if (not quality_keys or any(self._pill_match(i, k) for k in quality_keys))
					and all(self._pill_match(i, k) for k in other_keys)]
		self.filter_applied = True
		self._set_quality_heads(filtered)
		self._reset_results()
		self.add_items(self.window_id, filtered)
		self.setProperty('total_results', str(len(filtered)))
		self.setProperty('filter_applied', 'true')
		self.setProperty('filter_info', '| Press [B]BACK[/B] to Cancel' if filtered else '| No Results  ·  Press [B]BACK[/B] to Cancel')

	def clear_filter(self, keep_focus=False):
		if getattr(self, 'pill_active', None) and not keep_focus:
			self.pill_active = set()
			self.paint_pills()
		self.filter_applied = False
		self._set_quality_heads(self.item_list)
		self._reset_results()
		self.add_items(self.window_id, self.item_list)
		if not keep_focus: self.setFocusId(self.window_id)
		self.select_item(self.filter_window_id, 0)
		self.setProperty('total_results', self.total_results)
		self.setProperty('filter_applied', 'false')
		self.setProperty('filter_info', '')

# LOCAL PATCH 2026-09-27: Kodi reads colordiffuse 00000000 as 'no colour' and draws white (screenshot 75: the 0% square
# stayed white after the transparent-start fix). Alpha 1 of 255 is invisible without being zero.
_BAR_HIDDEN = '01000000'

def _display_season_episode(meta):
	"""LOCAL PATCH 2026-10-03: (season, episode) as anime is actually numbered, for the two labels below. TMDb files The
	Apothecary Diaries as ONE season of 49, so the resolver said '01x49 - Locusts' for what the release, the episode
	list and the widgets all call S03E01. metadata.cour_display_numbers is what those already use; labels only --
	play, watched state and the scrape keep TMDb's pair. Non-anime and unmapped shows come back unchanged."""
	season, episode = int(meta.get('season')), int(meta.get('episode'))
	try:
		from modules.metadata import cour_display_numbers
		return cour_display_numbers(meta, season, episode)
	except Exception: return season, episode


class SourcesPlayback(BaseDialog):
	def __init__(self, *args, **kwargs):
		from modules.kodi_utils import logger
		logger('DialogFlash SourcesPlayback.__init__', 'new instance')
		BaseDialog.__init__(self, *args)
		self.meta = kwargs.get('meta')
		self.is_canceled, self.skip_resolve, self.resume_choice = False, False, None
		self.meta_get = self.meta.get
		self.addon_fanart = addon_fanart()
		self.enable_scraper()

	def run(self):
		self.doModal()
		self.clearProperties()
		self.clear_modals()

	def onClick(self, controlID):
		self.resume_choice = {10: 'resume', 11: 'start_over', 12: 'cancel'}[controlID]

	def onAction(self, action):
		if action in self.closing_actions: self.is_canceled = True
		elif action == self.right_action and self.window_mode == 'resolver': self.skip_resolve = True

	def iscanceled(self):
		return self.is_canceled

	def skip_resolved(self):
		status = self.skip_resolve
		self.skip_resolve = False
		return status

	def reset_is_cancelled(self):
		self.is_canceled = False

	def enable_scraper(self):
		self.window_mode = 'scraper'
		self.set_scraper_properties()

	def enable_resolver(self):
		from modules.kodi_utils import logger
		logger('DialogFlash SourcesPlayback.enable_resolver', 'fired')
		self.window_mode = 'resolver'
		self.set_resolver_properties()

	def enable_resume(self, percent):
		self.window_mode = 'resume'
		self.set_resume_properties(percent)

	def busy_spinner(self, toggle='true'):
		self.setProperty('enable_busy_spinner', toggle)

	def _bar_hidden_until_set(self):
		# LOCAL PATCH 2026-09-27: until _set_bar first runs, bar_colour is unset and Kodi draws the 0% fill square in
		# its default white (screenshot 71, a SmartPlay pack-play resolve). Start it transparent.
		if not self.getProperty('bar_colour'): self.setProperty('bar_colour', _BAR_HIDDEN)

	def set_scraper_properties(self):
		self._bar_hidden_until_set()
		title, genre = self.meta_get('title'), self.meta_get('genre', '')
		fanart, clearlogo = self.meta_get('fanart') or self.addon_fanart, self.meta_get('clearlogo') or ''
		self.setProperty('window_mode', self.window_mode)
		self.setProperty('fanart', fanart)
		self.setProperty('clearlogo', clearlogo)
		self.setProperty('title', title)
		self.setProperty('genre', ', '.join(genre))
		# LOCAL PATCH 2026-09-27: say which episode is being searched for (the scraper view showed only the show).
		# 2026-10-03: anime display numbering, as the episode list shows it (_display_season_episode).
		if self.meta_get('media_type') == 'episode':
			try: ep_line = 'S%02dE%02d' % _display_season_episode(self.meta)
			except: ep_line = ''
			ep_name = self.meta_get('ep_name') or ''
			if ep_line and ep_name: ep_line = '%s  ·  %s' % (ep_line, ep_name)
			self.setProperty('episode_line', ep_line)

	def set_resolver_properties(self):
		self._bar_hidden_until_set()
		if self.meta_get('media_type') == 'movie': self.text = self.meta_get('plot')
		else:
			if avoid_episode_spoilers() and int(self.meta_get('playcount', '0')) == 0: plot = self.meta_get('tvshow_plot') or '* Hidden to Prevent Spoilers *'
			else: plot = self.meta_get('plot', '') or self.meta_get('tvshow_plot', '')
			# LOCAL PATCH 2026-09-29: the episode title as TMDb writes it ('Breaking & Entering'), not upper-cased
			try: _ds, _de = _display_season_episode(self.meta)   # LOCAL PATCH 2026-10-03: anime display numbering
			except Exception: _ds, _de = self.meta_get('season'), self.meta_get('episode')
			self.text = '[B]%02dx%02d - %s[/B][CR][CR]%s' % (_ds, _de, self.meta_get('ep_name', 'N/A'), plot)
		self.setProperty('window_mode', self.window_mode)
		self.setProperty('text', self.text)

	def set_resume_properties(self, percent):
		self.setProperty('window_mode', self.window_mode)
		self.setProperty('resume_percent', percent)
		self.setFocusId(10)
		self.update_resumer()

	def update_scraper(self, results_sd, results_720p, results_1080p, results_4k, results_total, content='', percent=0,
						providers=None, phase=None, detail=None, time_pct=None, late=False, hidden=None):
		self.setProperty('results_4k', str(results_4k))
		self.setProperty('results_1080p', str(results_1080p))
		self.setProperty('results_720p', str(results_720p))
		self.setProperty('results_sd', str(results_sd))
		self.setProperty('results_total', str(results_total))
		self.setProperty('percent', str(percent))
		# LOCAL PATCH 2026-09-30: `content` (the old comma list of provider names, textbox 2001) is no longer shown or
		# written -- the provider rows replaced it. The argument stays so the callers need not change shape.
		if hidden is not None and self.getProperty('hidden_line') != hidden: self.setProperty('hidden_line', hidden)
		# LOCAL PATCH 2026-09-27: loading window redesign -- phase heading, one smooth bar + time line, provider rows
		if phase is not None: self.set_phase(phase, detail)
		self._set_bar(percent, time_pct, late)
		if providers is not None: self._set_providers(providers)

	def update_resolver(self, text='', percent=0, detail=None):
		try: self.setProperty('percent', str(percent))
		except: pass
		if detail is not None: self.set_phase('Resolving', detail)
		self._set_bar(percent, None, False, ease=False)
		if text: self.set_text(2002, text)

	# LOCAL PATCH 2026-09-27: the pieces of the redesigned loading window. Every one swallows its own errors: the
	# scrape loops that call update_scraper treat an exception as fatal (sources.scrapers_dialog kills the window).
	_BAR_BLUE, _BAR_AMBER, _TIME_GREY = 'FF4F7CC1', 'FFE0AA46', 'FF787C84'

	def set_phase(self, phase, detail=None):
		try:
			self.setProperty('phase', phase or '')
			self.setProperty('phase_detail', detail or '')
		except: pass

	def set_notice(self, text):
		# LOCAL PATCH 2026-09-30: an amber line under the heading, e.g. 'In cinemas  ·  digital release 6 Oct  ·  ...'
		try: self.setProperty('notice', text or '')
		except: pass

	def set_smartplay(self, text):
		try: self.setProperty('smartplay', text or '')
		except: pass

	def _set_bar(self, percent, time_pct=None, late=False, ease=True):
		try:
			target = max(0.0, min(100.0, float(percent or 0)))
			shown = getattr(self, '_bar_shown', 0.0)
			# glide toward the target (~0.3 s at the 50 ms poll); jump when it falls (a new phase starts over)
			shown = target if (not ease or target < shown) else shown + (target - shown) * 0.35
			if abs(target - shown) < 0.5: shown = target
			self._bar_shown = shown
			self.getControl(3001).setPercent(shown)
			# Kodi still draws a small square of the fill at 0% -- keep it invisible until something is done
			self.setProperty('bar_colour', _BAR_HIDDEN if shown < 1 else (self._BAR_AMBER if late else self._BAR_BLUE))
			if time_pct is None: self.setProperty('show_timeline', 'false')
			else:
				self.getControl(3002).setPercent(max(0.0, min(100.0, float(time_pct))))
				self.setProperty('time_colour', self._BAR_AMBER if late else self._TIME_GREY)
				self.setProperty('show_timeline', 'true')
		except: pass

	def _set_providers(self, rows):
		"""rows: [(key, label, state, count)]; state in running / checking / done / none / timeout / failed. Items are
		kept and only their properties change, so the 50 ms poll does not rebuild the list."""
		try:
			import xbmcgui
			# LOCAL PATCH 2026-09-30: 'checking' is a debrid row in the cache-check phase -- 'running' everywhere below and
			# in the skin (its spinner), only the label says 'checking' rather than 'searching'
			checking = set(r[0] for r in rows if r[2] == 'checking')
			if checking: rows = [(r[0], r[1], 'running' if r[0] in checking else r[2], r[3]) for r in rows]
			# one row goes to the centred single list (2004); the two-column panel (2003) cannot centre it
			# LOCAL PATCH 2026-09-28: past 10 rows (2 x 5) the panel silently dropped the rest -- Direct Streams first,
			# since internal scrapers are listed last. Over 10 uses the three-column panel 2005 (3 x 5 = 15), and rows
			# sort found / searching / timed out / none / down, keeping their own order inside a group, so anything
			# still cut is a provider that found nothing. The list is rebuilt only when that order changes.
			layout = 'single' if len(rows) == 1 else ('grid' if len(rows) <= 10 else 'grid3')
			control = self.getControl({'single': 2004, 'grid': 2003, 'grid3': 2005}[layout])
			# LOCAL PATCH 2026-09-29: the order is FROZEN while any provider is still searching -- re-sorting on every
			# answer moved rows under the eye. Once the last one answers it sorts once, and that order stays up through
			# the cache-check phase that follows.
			def _n(count):
				try: return int(count)
				except: return 0
			if any(r[2] == 'running' for r in rows):
				frozen = getattr(self, '_provider_order', None)
				if frozen and set(frozen) == set(r[0] for r in rows):
					pos = dict((k, i) for i, k in enumerate(frozen))
					rows = sorted(rows, key=lambda r: pos[r[0]])
			else:
				# LOCAL PATCH 2026-09-29: found rows most results first, so the count bars read as a descending chart
				rank = {'done': 0, 'running': 1, 'timeout': 2, 'none': 3, 'failed': 4}
				rows = [r for _, r in sorted(enumerate(rows), key=lambda p: (rank.get(p[1][2], 3),
					-_n(p[1][3]) if p[1][2] == 'done' else 0, p[0]))]
			# LOCAL PATCH 2026-09-29: count bar, each provider's results against the best one's, in 5 % steps
			# (skins/Default/media/deadlight_common/bar/bar_005..100.png, stretched to the row). No bar for one row.
			best = max([_n(r[3]) for r in rows if r[2] == 'done'] or [0]) if len(rows) > 1 else 0
			items = getattr(self, '_provider_items', None)
			keys = [r[0] for r in rows]
			if (items is None or layout != getattr(self, '_provider_layout', None) or any(k not in keys for k in items)
					or keys != getattr(self, '_provider_order', None)):
				control.reset()   # first call, a new phase's set, or the other list
				items = self._provider_items = {}
				self._provider_layout = layout
				self._provider_order = keys
				self.setProperty('provider_layout', layout)
			for key, label, state, count in rows:
				item = items.get(key)
				if item is None:
					# three columns leave 180 px for the name: ~11 capitals at font10 bold (screenshot 09-28 12:19 cut
					# MEDIAFUSI... / DIRECT STR... / TORRENTD... at 166). The two long ones get short forms there.
					if layout == 'grid3': label = {'http_streams': 'Direct', 'torrentdownload': 'TorrentDL', 'torrentscsv': 'TorrentsCSV',
						'tb_cloud': 'TB Cloud', 'folders': 'Folders'}.get(key, label)
					# LOCAL PATCH 2026-09-30: shown in capitals (user preferred them to the 09-29 mixed case); the names
					# themselves stay mixed case in source_utils.provider_panel_name, which the resolve heading also reads
					item = items[key] = xbmcgui.ListItem(label.upper())
					control.addItem(item)
				if state == 'done':
					text = '[COLOR FF7FA7DB][B]✓[/B][/COLOR]  [B]%s[/B]' % count if count else '[COLOR FF7FA7DB][B]✓[/B][/COLOR]'
				elif state == 'running': text = '[COLOR FFA8A8A8]%s[/COLOR]' % ('checking' if key in checking else 'searching')
				elif state == 'timeout': text = '[COLOR FFE0AA46]timed out[/COLOR]'
				# LOCAL PATCH 2026-09-27: switched on but did not answer (external._scrape) -- not the same as 'none'
				elif state == 'failed': text = '[COLOR FFE06C6C]down[/COLOR]'
				else: text = '[COLOR FF6E6E6E]none[/COLOR]'
				if item.getProperty('state_label') != text:
					item.setProperty('state', state)
					item.setProperty('state_label', text)
				n = _n(count) if state == 'done' else 0
				bar = 'deadlight_common/bar/bar_%03d.png' % max(5, int(round(20.0 * n / best)) * 5) if best and n else ''
				if item.getProperty('bar') != bar: item.setProperty('bar', bar)
		except: pass

	def update_resumer(self):
		from modules.kodi_utils import kodi_player
		player = kodi_player()
		initial_playing = player.isPlayingVideo()
		count = 0
		while self.resume_choice is None:
			if self.is_canceled:
				self.resume_choice = 'cancel'
				break
			if initial_playing and not player.isPlayingVideo():
				self.resume_choice = 'cancel'
				break
			percent = int((float(count)/10000)*100)
			if percent >= 100: self.resume_choice = 'resume'
			self.setProperty('percent', str(percent))
			self._set_bar(percent, None, False, ease=False)   # LOCAL PATCH 2026-09-27: the squares are gone
			count += 100
			self.sleep(100)

class SourcesInfo(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.item = kwargs['item']
		self.item_get_property = self.item.getProperty
		self.set_properties()

	def run(self):
		self.doModal()

	def onAction(self, action):
		self.close()

	def set_properties(self):
		self.setProperty('name', self.item_get_property('name'))
		self.setProperty('source_type', self.item_get_property('source_type'))
		self.setProperty('source_site', self.item_get_property('source_site'))
		self.setProperty('size_label', self.item_get_property('size_label'))
		self.setProperty('extraInfo', self.item_get_property('extraInfo'))
		self.setProperty('highlight', self.item_get_property('highlight'))
		self.setProperty('hash', self.item_get_property('hash'))
		self.setProperty('provider', self.item_get_property('provider').lower())
		self.setProperty('quality', self.item_get_property('quality').lower())
		self.setProperty('provider_icon', self.item_get_property('provider_icon'))
		self.setProperty('quality_icon', self.item_get_property('quality_icon'))
