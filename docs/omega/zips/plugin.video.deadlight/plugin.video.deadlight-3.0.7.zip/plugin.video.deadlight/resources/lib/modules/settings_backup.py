# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-10-09: settings Import & Export and Default Settings, after Red Light 2.8.2's settings_backup.

A backup is a zip: manifest.json plus the databases that hold settings rather than data (settings, menus, personal lists,
discover, episode groups) -- watched history and the caches stay out. Import copies the rows table by table into the live
databases instead of swapping the files: the service and widget calls keep them open, and Windows will not replace an
open file. Default Settings puts every setting on the settings screen back to its default and keeps accounts, keys,
logins, URLs and folder sources; internal state (tokens, SmartPlay pins, refresh stamps) is never on that screen, so it
is never touched.
"""
import json
import os
import re
import sqlite3
import tempfile
from datetime import datetime
from zipfile import ZipFile, ZIP_DEFLATED
from caches.base_cache import database_locations, locations, close_all_connections
from caches.settings_cache import get_setting, set_setting, sync_settings, default_setting_values
from modules import kodi_utils

BACKUP_TYPE = 'deadlight_settings'
BACKUP_FORMAT = 1
BACKUP_DATABASES = ('settings_db', 'navigator_db', 'personal_lists_db', 'discover_db', 'episode_groups_db')
# Kept by Default Settings: what identifies the user's accounts and sources, not how DeadLight behaves
_KEEP = re.compile(r'(?:^|[._])(?:enabled|token|user|username|password|client|client_id|secret|account_id|manifest|manifest_url|[a-z]*_url|api)$'
				   r'|^folder\d\.|^easynews_', re.I)


def _backup_folder():
	folder = get_setting('deadlight.import_export_directory', '') or 'special://profile/addon_data/plugin.video.deadlight/backups/'
	return folder if folder.endswith(('/', '\\')) else folder + '/'


def export_settings(params=None):
	folder = kodi_utils.kodi_dialog().browse(3, 'Choose export folder', '', defaultt=_backup_folder())
	if not folder: return
	present = [k for k in BACKUP_DATABASES if os.path.isfile(database_locations(k))]
	if not present: return kodi_utils.ok_dialog(heading='Export Settings', text='Nothing to export on this device.')
	filename = 'deadlight-settings-%s.zip' % datetime.now().strftime('%Y%m%d-%H%M%S')
	text = 'Export to [B]%s[/B]?[CR][CR]Includes: %s.[CR][CR]The backup holds your API keys and account tokens -- keep it private.' \
		% (filename, ', '.join(locations()[k] for k in present))
	if not kodi_utils.confirm_dialog(heading='Export Settings', text=text, ok_label='Export', cancel_label='Cancel', default_control=10): return
	try:
		target_dir = kodi_utils.translate_path(folder)
		kodi_utils.make_directories(target_dir)
		manifest = {'type': BACKUP_TYPE, 'format': BACKUP_FORMAT, 'addon_version': kodi_utils.addon_info('version'),
					'exported': datetime.now().strftime('%Y-%m-%dT%H:%M:%S'), 'databases': [locations()[k] for k in present]}
		with ZipFile(os.path.join(target_dir, filename), 'w', ZIP_DEFLATED) as archive:
			archive.writestr('manifest.json', json.dumps(manifest, indent=2))
			for key in present:
				# a consistent snapshot even while another call writes: SQLite's backup API, not a file copy
				snapshot = os.path.join(tempfile.mkdtemp(), locations()[key])
				src, dst = sqlite3.connect(database_locations(key), timeout=20), sqlite3.connect(snapshot)
				try: src.backup(dst)
				finally: src.close(); dst.close()
				archive.write(snapshot, 'databases/%s' % locations()[key])
				os.remove(snapshot)
	except Exception as e:
		return kodi_utils.ok_dialog(heading='Export Failed', text=str(e))
	if folder != _backup_folder() and kodi_utils.confirm_dialog(heading='Export Settings', text='Exported %s.[CR][CR]Use this folder for future backups?' % filename,
																 ok_label='Yes', cancel_label='No', default_control=11):
		set_setting('import_export_directory', folder)
	kodi_utils.notification('Settings exported: %s' % filename, 6500)


def import_settings(params=None):
	path = kodi_utils.kodi_dialog().browse(1, 'Choose a DeadLight settings backup', '', '.zip', defaultt=_backup_folder())
	if not path: return
	path = kodi_utils.translate_path(path)
	try:
		with ZipFile(path, 'r') as archive:
			manifest = json.loads(archive.read('manifest.json').decode('utf-8'))
			if manifest.get('type') != BACKUP_TYPE: raise ValueError('This zip is not a DeadLight settings backup.')
			names = [n for n in archive.namelist() if n.startswith('databases/') and n.endswith('.db')]
			wanted = {locations()[k]: k for k in BACKUP_DATABASES}
			found = [(wanted[n.split('/', 1)[1]], n) for n in names if n.split('/', 1)[1] in wanted]
			if not found: raise ValueError('The backup holds no settings databases.')
			text = 'Import the backup from [B]%s[/B] (DeadLight %s)?[CR][CR]It replaces: %s.[CR][CR]Watched history and caches are not touched.' \
				% (manifest.get('exported', '?').replace('T', ' '), manifest.get('addon_version', '?'), ', '.join(n.split('/', 1)[1] for _k, n in found))
			if not kodi_utils.confirm_dialog(heading='Import Settings', text=text, ok_label='Import', cancel_label='Cancel', default_control=11): return
			workdir = tempfile.mkdtemp()
			for key, member in found:
				archive.extract(member, workdir)
				_copy_tables(os.path.join(workdir, member), database_locations(key))
	except Exception as e:
		return kodi_utils.ok_dialog(heading='Import Failed', text=str(e))
	close_all_connections()
	sync_settings()   # memory properties, _name rows and defaults for anything newer than the backup
	kodi_utils.ok_dialog(heading='Import Complete', text='Settings imported. Restart Kodi so every part of DeadLight picks them up.')


def _copy_tables(source_path, target_path):
	"""Every table the two databases share: the backup's rows replace the live ones. Tables only one side has are left
	alone, so a backup from an older version restores what it holds and sync_settings fills in the rest."""
	dbcon = sqlite3.connect(target_path, timeout=20, isolation_level=None)
	try:
		dbcon.execute('ATTACH DATABASE ? AS backup', (source_path,))
		live = {r[0] for r in dbcon.execute("SELECT name FROM main.sqlite_master WHERE type='table'")}
		saved = {r[0] for r in dbcon.execute("SELECT name FROM backup.sqlite_master WHERE type='table'")}
		dbcon.execute('BEGIN')
		for table in sorted((live & saved) - {'sqlite_sequence'}):
			cols = [r[1] for r in dbcon.execute('PRAGMA backup.table_info("%s")' % table)]
			live_cols = {r[1] for r in dbcon.execute('PRAGMA main.table_info("%s")' % table)}
			cols = [c for c in cols if c in live_cols]
			if not cols: continue
			col_list = ', '.join('"%s"' % c for c in cols)
			dbcon.execute('DELETE FROM main."%s"' % table)
			dbcon.execute('INSERT INTO main."%s" (%s) SELECT %s FROM backup."%s"' % (table, col_list, col_list, table))
		dbcon.execute('COMMIT')
		dbcon.execute('DETACH DATABASE backup')
	finally: dbcon.close()


def reset_settings(params=None):
	from modules.kodi_settings_spec import UI
	reset = [sid for sid, kind in UI.items() if kind != 'secret' and not _KEEP.search(sid) and default_setting_values(sid)]
	text = 'Put %d settings back to their defaults?[CR][CR]Kept: accounts, API keys, logins, URLs and folder sources. ' \
		'Watched history, lists and SmartPlay pins are not touched.' % len(reset)
	if not kodi_utils.confirm_dialog(heading='Default DeadLight Settings', text=text, ok_label='Continue', cancel_label='Cancel', default_control=11): return
	if not kodi_utils.confirm_dialog(heading='Default DeadLight Settings', text='Are you sure? Only a settings backup can undo this.',
									 ok_label='Reset Settings', cancel_label='Cancel', default_control=11): return
	changed = 0
	for sid in reset:
		default = default_setting_values(sid)['setting_default']
		if get_setting('deadlight.%s' % sid, None) != default:
			set_setting(sid, default)
			changed += 1
	kodi_utils.notification('%d settings back to default' % changed, 6500)
