# created by kodifitzwell for Fenomscrapers
"""
	Fenomscrapers Project
"""

from json import loads as jsloads
import re, time
from threading import Lock, Thread
from magneto.modules import client
from magneto.modules import source_utils
from magneto.modules.control import setting as getSetting
from magneto.modules import anime_utils


class source(source_utils.SourceRegistry):
	timeout = 10
	priority = 1
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	# LOCAL PATCH 2026-10-06: one future per search (source_utils.SourceRegistry), not the class-wide queue
	_lock = Lock()
	_cache = {}
	_GRACE = 1.5   # LOCAL PATCH 2026-10-07: see the Kitsu + IMDb request in sources()
	def __init__(self):
		self.language = ['en']
		self.base_link = (
			"https://comet.stremio.ru",
			"https://comet.feels.legal",
			"https://cometfortheweebs.midnightignite.me"
		)[int(getSetting('comet.url', '0'))]
		self.movieSearch_link = '/stream/movie/%s.json'
		self.tvSearch_link = '/stream/series/%s:%s:%s.json'
		# LOCAL PATCH 2026-08-27: Kitsu endpoint for anime. Comet answers the TMDb
		# coordinate poorly because nobody names anime that way -- measured on Frieren
		# S1E30 (cour 2 episode 2): imdb tt22248376:1:30 returned 2 streams, while
		# kitsu:49240:2 returned 556.
		self.tvSearch_link_kitsu = '/stream/series/kitsu:%s:%s.json'
		self.min_seeders = 0

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		future = self.start_future(data)
		sources_append = sources.append
		try:
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
			aliases = data['aliases']
			episode_title = data['title'] if 'tvshowtitle' in data else None
			year = data['year']
			imdb = data['imdb']
			kitsu_film = False   # LOCAL PATCH 2026-10-06, set below for a film with no IMDb id
			if 'tvshowtitle' in data:
				season = data['season']
				episode = data['episode']
				hdlr = 'S%02dE%02d' % (int(season), int(episode))
				# DeadLight fills these in for anime only (scrapers/external.py), from the
				# Fribb cour mapping; anime_utils.comet_kitsu_reject reads the rest of them.
				kitsu_id = data.get('kitsu_id')
				cour_episode = data.get('cour_episode')
				kitsu_mode = bool(kitsu_id) and cour_episode is not None
				if kitsu_mode:
					url = '%s%s' % (self.base_link, self.tvSearch_link_kitsu % (kitsu_id, cour_episode))
				else:
					url = '%s%s' % (self.base_link, self.tvSearch_link % (imdb, season, episode))
			else:
				hdlr = year
				kitsu_mode = False
				# LOCAL PATCH 2026-10-06: an anime film with no IMDb id is asked for by its Kitsu id (kitsu:937 On Your Mark --
				# 10 rows, none before); judged by the title only below. With an IMDb id the query is unchanged.
				kitsu_film = bool(data.get('kitsu_id')) and not anime_utils.real_imdb(imdb)
				url = '%s%s' % (self.base_link, self.movieSearch_link % ('kitsu:%s' % data['kitsu_id'] if kitsu_film else imdb))
			# log_utils.log('url = %s' % url)
			try:
				# LOCAL PATCH 2026-10-06: on anime ask by Kitsu AND by IMDb at the release season, at the same time (a Stremio
				# request takes one id). comet's Kitsu index lags new seasons -- kitsu:49752:1 (Blue Box Season 2) and
				# kitsu:51005:1 (Reborn as a Space Mercenary) gave 0 streams while tt32639706:2:1 gave 25 and tt41298100:1:1
				# gave 2. The answers are merged by hash and every row is judged like a Kitsu row below (title_guard +
				# comet_kitsu_reject). One side failing leaves the other; both failing is the old failure.
				imdb_url = None
				if kitsu_mode and anime_utils.real_imdb(imdb) and data.get('cour_season') is not None:
					imdb_ep = data.get('season_episode') or cour_episode
					imdb_url = '%s%s' % (self.base_link, self.tvSearch_link % (imdb, data['cour_season'], imdb_ep))
				if imdb_url:
					answers, took = {}, {}
					def _fetch(key, u):
						_t0 = time.time()
						try: answers[key] = jsloads(client.request(u, timeout=self.timeout))['streams']
						except Exception: pass
						took[key] = time.time() - _t0
					# Once one side has rows the other gets _GRACE more seconds, not the full timeout: an EMPTY Kitsu answer
					# takes 4.7-5.2 s (live 2026-10-07: kitsu:49752:1, kitsu:51005:1 -- comet searches upstream and finds
					# nothing) while the IMDb side had its rows in 0.5-0.7 s; a Kitsu answer WITH rows took 0.6-1.3 s.
					_threads = [Thread(target=_fetch, args=(k, u), daemon=True) for k, u in (('kitsu', url), ('imdb', imdb_url))]
					for _t in _threads: _t.start()
					_deadline, _grace_end = time.time() + self.timeout + 1, None
					while any(_t.is_alive() for _t in _threads) and time.time() < _deadline:
						if _grace_end is None and any(list(answers.values())): _grace_end = time.time() + self._GRACE
						if _grace_end and time.time() >= _grace_end: break
						time.sleep(0.05)
					got = dict(answers)   # a side still running past the grace is left out (snapshot: a late thread still writes to answers)
					if not got: raise Exception('comet: kitsu and imdb requests both failed')
					files, seen = [], set()
					for _f in (got.get('kitsu') or []) + (got.get('imdb') or []):
						_h = (_f.get('infoHash') or '').lower()
						if _h in seen: continue
						seen.add(_h)
						files.append(_f)
					try:
						import xbmc as _x
						_x.log('COMET: kitsu:%s:%s %s (%.1f s) + %s:%s:%s %s (%.1f s) -> %d unique' % (kitsu_id, cour_episode,
							len(got['kitsu']) if 'kitsu' in got else ('FAILED' if 'kitsu' in took else 'LATE'), took.get('kitsu', 0), imdb,
							data['cour_season'], imdb_ep, len(got['imdb']) if 'imdb' in got else ('FAILED' if 'imdb' in took else 'LATE'),
							took.get('imdb', 0), len(files)), _x.LOGINFO)
					except Exception: pass
				else:
					results = client.request(url, timeout=self.timeout)
					files = jsloads(results)['streams']
			except:
				files = []
				raise
			finally:
				source_utils.set_future(future, files)
			_INFO = re.compile(r'💾.*')
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.set_future(future, [])
			source_utils.scraper_error('COMET')
			return sources

		for file in files:
			try:
				hash = file['infoHash']
				file_title = (file.get('title') or file['description']).split('\n')
				file_info = [x for x in file_title if _INFO.search(x)][0]

				name = source_utils.clean_name(file_title[0])

				# LOCAL PATCH 2026-08-27: check_title requires the SxxExx token in the release
				# name, which anime releases do not carry -- that alone discarded nearly every
				# anime result regardless of what the query returned.
				#
				# Unlike torrentio's kitsu path we do NOT skip validation entirely. Torrentio's
				# kitsu endpoint is genuinely cour-scoped; comet's is not -- a cour 2 episode 2
				# query also returns '[aL] Sousou no Frieren (2023) - 02', which is cour ONE
				# episode 2. Dropping the check would import the wrong episode.
				if kitsu_mode:
					# LOCAL PATCH 2026-08-27: check the SHOW before the episode. comet's kitsu
					# endpoint leaks unrelated series -- kitsu:11:159 (Naruto) returned
					# '11.22.63.S01.2160p.HULU.WEB-DL' -- and cour_match cannot catch that,
					# because those rows carry a perfectly plausible episode number. Measured:
					# this drops 267 of 536 Naruto rows and 119 of 381 Frieren rows, all noise.
					if not anime_utils.title_guard(name, title, anime_utils.alias_titles(data)): continue
					# LOCAL PATCH 2026-10-05: judged like nyaa's title search, with no trust in a lower season claim --
					# Black Clover's 2nd Season id returned only Season 1 episode 1. See anime_utils.comet_kitsu_reject.
					if anime_utils.comet_kitsu_reject(name, data): continue
				elif kitsu_film:
					if not anime_utils.title_guard(name, title, anime_utils.alias_titles(data)): continue
				elif not source_utils.check_title(title, aliases, name.replace('.(Archie.Bunker', ''), hdlr, year): continue
				# LOCAL PATCH 2026-10-05: on anime, `name` is the file comet picked -- drop archives, art, music, scans and Chinese
				# names of another episode (anime_utils.stremio_junk / cjk_episode), on the IMDb path too.
				if data.get('is_anime'):
					if anime_utils.stremio_junk(name, [title] + anime_utils.alias_titles(data)): continue
					if anime_utils.other_show_year(name, data): continue   # 'ONE.PIECE.2023.S01...NF' for One Piece (1999)
					if not kitsu_mode and episode_title is not None:
						_cjk = anime_utils.cjk_episode(name)
						if _cjk is not None and _cjk not in (int(episode), data.get('absolute_episode')): continue
				name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)

				try:
					seeders = int(re.search(r'👤\s*(\d+)', file_info).group(1))
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				try:
					size = re.search(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', file_info).group(0)
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)

				item = {
					'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True,
					'provider': 'comet', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
					'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders
				}
				# LOCAL PATCH 2026-10-03: a kitsu-mode batch said nothing about being one, so playback took the single-file
				# path. Tagged like nyaa's (anime_utils.batch_fields); true_size because comet's size is the episode
				# file's (live: always equal to behaviorHints.videoSize), so DeadLight must not divide it.
				if kitsu_mode:
					_m = anime_utils._extract_meta(anime_utils._clean_for_extract(name))
					_fields = anime_utils.batch_fields(name, _m[1], _m[3], data.get('season_length'))
					if _fields: item.update(_fields, true_size=True)
				sources_append(item)
			except:
				source_utils.scraper_error('COMET')
		return sources

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		sources = []
		if not data: return sources
		sources_append = sources.append
		try:
			title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
			aliases = data['aliases']
			imdb = data['imdb']
			year = data['year']
			season = data['season']
			url = '%s%s' % (self.base_link, self.tvSearch_link % (imdb, season, data['episode']))
			files = self.wait_future(data, self.timeout + 1)
			_INFO = re.compile(r'💾.*')
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('COMET')
			return sources

		for file in files:
			try:
				hash = file['infoHash']
				file_title = (file.get('title') or file['description']).split('\n')
				file_info = [x for x in file_title if _INFO.search(x)][0]

				name = source_utils.clean_name(file_title[0])

				episode_start, episode_end = 0, 0
				if not search_series:
					if not bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, season, name.replace('.(Archie.Bunker', ''))
						if not valid: continue
					package = 'season'

				elif search_series:
					if not bypass_filter:
						valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season, name.replace('.(Archie.Bunker', ''), total_seasons)
						if not valid: continue
					else: last_season = total_seasons
					package = 'show'

				# LOCAL PATCH 2026-10-05: on anime, a pack named for a LATER season is not this one (anime_utils.later_season_reject)
				if data.get('is_anime') and package == 'season' and anime_utils.later_season_reject([name], data): continue
				if data.get('is_anime') and anime_utils.foreign_cour_marked(name, data): continue   # 'act II' packs under Ace S2
				if data.get('is_anime') and anime_utils.other_show_year(name, data): continue   # 'One.Piece.Season.1&2.(2023-2026)'
				name_info = source_utils.info_from_name(name, title, year, season=season, pack=package)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
				try:
					seeders = int(re.search(r'👤\s*(\d+)', file_info).group(1))
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				try:
					size = re.search(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', file_info).group(0)
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)

				# LOCAL PATCH 2026-10-03: true_size -- comet's size is the episode file's, not the pack's (live 2026-10-03:
				# 'Reacher.S02E01...mkv' 17 GB inside a 113 GB torrent), so DeadLight must not divide it again.
				item = {
					'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True, 'true_size': True,
					'provider': 'comet', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
					'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders, 'package': package
				}
				if search_series: item.update({'last_season': last_season})
				elif episode_start: item.update(source_utils.pack_range_fields(episode_start, episode_end))   # LOCAL PATCH 2026-10-03: + pack_episodes for the size; # for partial season packs
				sources_append(item)
			except:
				source_utils.scraper_error('COMET')
		return sources
