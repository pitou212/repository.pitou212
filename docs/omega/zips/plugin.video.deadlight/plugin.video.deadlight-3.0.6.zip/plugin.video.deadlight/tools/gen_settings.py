"""One-off generator: DeadLight's custom settings window -> Kodi's native settings dialog.

Reads resources/skins/Default/1080i/settings_manager.xml (+ settings_manager_folders.xml) and the default
rows in resources/lib/caches/settings_cache.py, and writes:
  resources/settings.xml                                   (Kodi settings, <settings version="1">)
  resources/language/resource.language.en_gb/strings.po    (labels / help text)
  resources/lib/modules/kodi_settings_spec.py              (what modules/kodi_settings.py syncs)
then prints a coverage report. Run from anywhere: python tools/gen_settings.py
After the switch settings.xml is maintained by hand; this script documents how it was derived.
Its two input XMLs were deleted in the same change: to re-run it, check them out from commit 8ffabd7
(git checkout 8ffabd7 -- resources/skins/Default/1080i/settings_manager.xml ...settings_manager_folders.xml).
"""
import os, re, sys, types
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, 'resources')
SKIN = os.environ.get('DL_OLD_SKIN') or os.path.join(RES, 'skins', 'Default', '1080i')   # folder holding the old XMLs
ADDON_ID = 'plugin.video.deadlight'

# ---- import default_settings() with throw-away Kodi stubs --------------------------------------
def _stub(name, **kw):
	m = types.ModuleType(name)
	for k, v in kw.items(): setattr(m, k, v)
	m.__getattr__ = lambda attr: (lambda *a, **k: None)
	sys.modules[name] = m
class _W:
	def __init__(self, *a): pass
	def getProperty(self, k): return ''
	def setProperty(self, k, v): pass
class _A:
	def __init__(self, *a): pass
	def getAddonInfo(self, k): return {'path': ROOT, 'profile': ROOT, 'id': ADDON_ID}.get(k, '')
for _n in ('xbmc', 'xbmcvfs', 'xbmcplugin'): _stub(_n, translatePath=lambda p: p)
_stub('xbmcgui', Window=_W)
_stub('xbmcaddon', Addon=_A)
sys.path.insert(0, os.path.join(RES, 'lib'))
from caches.settings_cache import default_settings
DEFAULTS = {i['setting_id']: i for i in default_settings()}
FANART_DEFAULT = DEFAULTS['default_addon_fanart']['setting_default']

# ---- strings.po ---------------------------------------------------------------------------------
STR, STR_IDS = [], {}
def sid_for(text):
	text = text.strip()
	if text not in STR_IDS:
		STR_IDS[text] = 30000 + len(STR)
		STR.append(text)
	return STR_IDS[text]

def clean_label(s):
	return re.sub(r'^\s*-\s*', '', s or '').strip()

# ---- condition parsing (Kodi InfoBool subset used by the old window) ----------------------------
PROP = r'Window\(10000\)\.Property\(deadlight\.([^)]+)\)'
TOKEN = re.compile(r'\s*(\[|\]|\||\+|!|String\.IsEqual\(' + PROP + r',([^)]*)\)|String\.IsEmpty\(' + PROP + r'\)|String\.EndsWith\(' + PROP + r',' + PROP + r'\))')

def tokenize(s):
	pos, out = 0, []
	s = s.strip()
	while pos < len(s):
		m = TOKEN.match(s, pos)
		if not m: raise ValueError('cannot parse condition at %r' % s[pos:])
		t = m.group(1)
		if t.startswith('String.IsEqual'): out.append(('atom', m.group(2), 'is', m.group(3)))
		elif t.startswith('String.IsEmpty'): out.append(('atom', m.group(4), 'is', 'empty_setting'))
		elif t.startswith('String.EndsWith'): out.append(('true',))
		else: out.append(t)
		pos = m.end()
	return out

def parse(tokens):
	# precedence: ! > + > |
	def p_or(i):
		node, i = p_and(i)
		kids = [node]
		while i < len(tokens) and tokens[i] == '|':
			n, i = p_and(i + 1); kids.append(n)
		return (('or', kids) if len(kids) > 1 else node), i
	def p_and(i):
		node, i = p_not(i)
		kids = [node]
		while i < len(tokens) and tokens[i] == '+':
			n, i = p_not(i + 1); kids.append(n)
		return (('and', kids) if len(kids) > 1 else node), i
	def p_not(i):
		if tokens[i] == '!':
			n, i = p_not(i + 1)
			return ('not', n), i
		if tokens[i] == '[':
			n, i = p_or(i + 1)
			assert tokens[i] == ']'
			return n, i + 1
		return tokens[i], i + 1
	node, i = p_or(0)
	assert i == len(tokens)
	return node

def push_not(node, neg=False):
	kind = node[0]
	if kind == 'not': return push_not(node[1], not neg)
	if kind == 'true': return None if not neg else ('false',)
	if kind == 'atom':
		_, sid, op, val = node
		if neg: op = '!is' if op == 'is' else 'is'
		return ('atom', sid, op, val)
	kids = [push_not(k, neg) for k in node[1]]
	if kind == 'and': kind = 'or' if neg else 'and'
	else: kind = 'and' if neg else 'or'
	kids = [k for k in kids if k is not None]
	if not kids: return None
	return (kind, kids) if len(kids) > 1 else kids[0]

# ---- model ------------------------------------------------------------------------------------
CATS = [(10, 'General'), (20, 'Features'), (30, 'Content'), (40, 'Interface'), (50, 'Accounts'),
	(60, 'Debrid'), (90, 'Scrapers'), (100, 'Direct Providers'), (70, 'Results'), (80, 'Playback')]
CAT_KEYS = {10: 'general', 20: 'features', 30: 'content', 40: 'interface', 50: 'accounts', 60: 'debrid',
	90: 'external_scrapers', 100: 'direct_providers', 70: 'results', 80: 'playback'}
SECRET = re.compile(r'(secret|password|_api$|\.client$|client_id$)')
# rows the old window always showed that belong to a switch (user request 2026-09-26: AIOStreams URL only when enabled)
EXTRA_VISIBLE = {'aiostreams.manifest_url': ('atom', 'provider.aiostreams', 'is', 'true')}
# NOTE 2026-09-27: settings.xml was then hand-edited to put provider.aiostreams ABOVE the URL (a row
# should follow the switch that reveals it). The old window's order puts the URL first, so a re-run
# undoes that swap -- redo it by hand.
# NOTE 2026-09-27: settings.xml then had each greyed value row + its 'Change' action row merged into ONE
# string setting with <control type="button" format="action"><data>..</data> (Kodi shows the string value on
# the button and runs the control's data). This script still emits the pairs; a re-run needs that redone.
NEVER_MIRROR = re.compile(r'(token|secret|password|\.refresh$)')

UI, MIRROR, DERIVED, TYPES, report = {}, set(), {}, {}, {'modes': {}, 'rows': 0, 'dropped_conditions': [], 'unmapped': []}
categories = {c: [] for c, _ in CATS}   # cat -> [group]; group = {'label': str, 'settings': [xml]}
act_ids = set()

def mode_of(onclick):
	m = re.search(r'mode=([^&)]+)', onclick or '')
	return m.group(1) if m else None
def param(onclick, key):
	m = re.search(r'[?&]' + key + r'=([^&)]+)', (onclick or '').replace('&amp;', '&'))
	return m.group(1) if m else None

def need_condition_setting(sid, val):
	"""Map a (setting, value) atom onto a Kodi setting id and value."""
	if val == 'empty_setting':
		d = '_ui.%s_set' % sid
		DERIVED[d] = sid
		return d, None
	if sid not in UI and sid not in DERIVED:
		MIRROR.add(sid)
	return sid, val

def cond_xml(node, indent):
	pad = '\t' * indent
	if node[0] == 'atom':
		_, sid, op, val = node
		kid, kval = need_condition_setting(sid, val)
		if kval is None:   # empty_setting comparison -> derived boolean
			kval = 'false' if op == 'is' else 'true'
			op = 'is'
		return '%s<condition setting="%s" operator="%s">%s</condition>\n' % (pad, kid, op, escape(kval))
	if node[0] == 'false':
		return '%s<condition on="property" name="InfoBool">false</condition>\n' % pad
	tag = node[0]
	inner = ''.join(cond_xml(k, indent + 1) for k in node[1])
	return '%s<%s>\n%s%s</%s>\n' % (pad, tag, inner, pad, tag)

def deps_xml(conds, indent, readonly=False):
	if not conds and not readonly: return ''
	pad = '\t' * indent
	body = ''
	if conds:
		node = conds[0] if len(conds) == 1 else ('and', conds)
		if node[0] == 'atom':
			# Kodi's one-line form. A bare <condition> directly inside <dependency> is NOT read by Kodi
			# (the row simply always shows); conditions must sit in <and>/<or> or use these attributes.
			_, sid, op, val = node
			kid, kval = need_condition_setting(sid, val)
			if kval is None: kval, op = ('false' if op == 'is' else 'true'), 'is'
			body += '%s<dependency type="visible" setting="%s" operator="%s">%s</dependency>\n' % (pad + '\t', kid, op, escape(kval))
		else:
			body += '%s<dependency type="visible">\n%s%s</dependency>\n' % (pad + '\t', cond_xml(node, indent + 2), pad + '\t')
	if readonly:   # shown, never editable: its value comes from settings.db
		body += '%s<dependency type="enable">\n%s<and>\n%s<condition on="property" name="InfoBool">false</condition>\n%s</and>\n%s</dependency>\n' % (
			pad + '\t', pad + '\t\t', pad + '\t\t\t', pad + '\t\t', pad + '\t')
	return '%s<dependencies>\n%s%s</dependencies>\n' % (pad, body, pad)

def kodi_default(sid):
	d = DEFAULTS[sid]['setting_default']
	if sid == 'default_addon_fanart' or d in ('empty_setting', 'None'): return ''
	return d

def setting_xml(sid, typ, label, help_text, conds, extra=None):
	"""typ: boolean | options | integer | string | secret | path | image | color | action | readonly"""
	e = extra or {}
	L, H = sid_for(label), (sid_for(help_text) if help_text else None)
	attrs = 'id="%s" type="%s" label="%d"' % (sid, {'boolean': 'boolean', 'options': 'string', 'integer': 'integer',
		'string': 'string', 'secret': 'string', 'path': 'path', 'image': 'path', 'color': 'string', 'action': 'action',
		'readonly': 'string'}[typ], L)
	if H: attrs += ' help="%d"' % H
	if e.get('parent'): attrs += ' parent="%s"' % e['parent']
	x = '\t\t\t\t<setting %s>\n\t\t\t\t\t<level>0</level>\n' % attrs
	if typ == 'action':
		x += '\t\t\t\t\t<data>%s</data>\n' % escape(e['data'])
		x += '\t\t\t\t\t<constraints><allowempty>true</allowempty></constraints>\n'
		x += deps_xml(conds, 5)
		x += '\t\t\t\t\t<control type="button" format="action"><close>true</close></control>\n'
	elif typ == 'readonly':
		x += '\t\t\t\t\t<default></default>\n\t\t\t\t\t<constraints><allowempty>true</allowempty></constraints>\n'
		x += deps_xml(conds, 5, readonly=True)
		x += '\t\t\t\t\t<control type="edit" format="string"><heading>%d</heading></control>\n' % L
	else:
		x += '\t\t\t\t\t<default>%s</default>\n' % escape(kodi_default(sid))
		if typ == 'options':
			opts = DEFAULTS[sid]['settings_options']
			x += '\t\t\t\t\t<constraints>\n\t\t\t\t\t\t<options>\n'
			for k, v in opts.items(): x += '\t\t\t\t\t\t\t<option label="%d">%s</option>\n' % (sid_for(v), escape(k))
			x += '\t\t\t\t\t\t</options>\n\t\t\t\t\t</constraints>\n'
		elif typ == 'integer':
			d = DEFAULTS[sid]
			lo = int(e.get('min', d.get('min_value', 0)))
			hi = int(d.get('max_value', 999999))
			dv = int(d['setting_default'])
			lo, hi = min(lo, dv), max(hi, dv)
			x += '\t\t\t\t\t<constraints><minimum>%d</minimum><step>1</step><maximum>%d</maximum></constraints>\n' % (lo, hi)
		elif typ in ('string', 'secret', 'path', 'image'):
			x += '\t\t\t\t\t<constraints><allowempty>true</allowempty></constraints>\n'
		x += deps_xml(conds, 5)
		x += {
			'boolean': '\t\t\t\t\t<control type="toggle"/>\n',
			'options': '\t\t\t\t\t<control type="spinner" format="string"/>\n',
			'integer': '\t\t\t\t\t<control type="edit" format="integer"><heading>%d</heading></control>\n' % L,
			'string': '\t\t\t\t\t<control type="edit" format="string"><heading>%d</heading></control>\n' % L,
			'secret': '\t\t\t\t\t<control type="edit" format="string"><heading>%d</heading><hidden>true</hidden></control>\n' % L,
			'path': '\t\t\t\t\t<control type="button" format="path"><heading>%d</heading></control>\n' % L,
			'image': '\t\t\t\t\t<control type="button" format="image"><heading>%d</heading></control>\n' % L,
			'color': '\t\t\t\t\t<control type="colorbutton"/>\n',
		}[typ]
	return x + '\t\t\t\t</setting>\n'

def add_ui(sid, kind):
	UI[sid] = kind
	TYPES[sid] = kind

def unique_act(name):
	base = re.sub(r'[^a-z0-9_.]+', '_', name.lower())
	i, n = 1, base
	while n in act_ids: i += 1; n = '%s_%d' % (base, i)
	act_ids.add(n)
	return '_act.' + n

def parse_items(path, list_id):
	root = ET.parse(path).getroot()
	lst = [c for c in root.iter('control') if c.get('id') == list_id][0]
	for it in lst.find('content').findall('item'):
		vis = [v.text or '' for v in it.findall('visible')]
		props = {}
		for p in it.findall('property'):
			props.setdefault(p.get('name'), []).append(p.text or '')
		yield vis, props, (it.findtext('onclick') or '')

def build_main():
	current = {c: None for c, _ in CATS}
	last_parent = {c: None for c, _ in CATS}
	for vis, props, onclick in parse_items(os.path.join(SKIN, 'settings_manager.xml'), '2100'):
		cat = int(re.search(r'HasFocus\((\d+)\)', vis[0]).group(1))
		label_raw = (props.get('setting_label') or [''])[0]
		is_child = bool(re.match(r'^\s*-\s', label_raw))
		label = clean_label(label_raw)
		stype = (props.get('setting_type') or [''])[0]
		desc = (props.get('setting_description') or [''])[0]
		conds = [push_not(parse(tokenize(v))) for v in vis[1:]]
		conds = [c for c in conds if c is not None]
		if stype == 'separator':
			current[cat] = {'label': label, 'settings': []}
			categories[cat].append(current[cat])
			last_parent[cat] = None
			continue
		if current[cat] is None:
			current[cat] = {'label': dict(CATS)[cat], 'settings': []}
			categories[cat].append(current[cat])
		report['rows'] += 1
		mode = mode_of(onclick)
		report['modes'][mode] = report['modes'].get(mode, 0) + 1
		sid = param(onclick, 'setting_id')
		if sid in EXTRA_VISIBLE: conds = conds + [EXTRA_VISIBLE[sid]]
		values = props.get('setting_value') or []
		shown = [re.search(PROP, v).group(1) for v in values if re.search(PROP, v)]
		parent = last_parent[cat] if is_child else None
		out = []
		if mode == 'settings_manager.set_boolean': add_ui(sid, 'boolean'); out.append(setting_xml(sid, 'boolean', label, desc, conds, {'parent': parent}))
		elif mode == 'settings_manager.set_from_list': add_ui(sid, 'options'); out.append(setting_xml(sid, 'options', label, desc, conds, {'parent': parent}))
		elif mode == 'settings_manager.set_numeric':
			add_ui(sid, 'integer'); out.append(setting_xml(sid, 'integer', label, desc, conds, {'parent': parent, 'min': param(onclick, 'min_value') or DEFAULTS[sid].get('min_value', 0)}))
		elif mode == 'settings_manager.set_string':
			kind = 'secret' if SECRET.search(sid) else 'string'
			add_ui(sid, kind); out.append(setting_xml(sid, kind, label, desc, conds, {'parent': parent}))
		elif mode == 'settings_manager.set_path':
			kind = 'image' if sid == 'default_addon_fanart' else 'path'
			add_ui(sid, kind); out.append(setting_xml(sid, kind, label, desc, conds, {'parent': parent}))
		elif mode in ('scraper_color_choice', 'personal_list_unseen_color_choice'):
			sid = sid or 'personal_list.unseen_highlight'
			add_ui(sid, 'color'); out.append(setting_xml(sid, 'color', label, desc, conds, {'parent': parent}))
		elif mode is None:   # onclick 'noop': the two RPDb info rows
			if stype == 'info':
				rid = unique_act('info_' + label)
				out.append(setting_xml(rid, 'readonly', label, desc, conds))
			else:
				report['unmapped'].append((label, mode))
		elif mode == 'sources_folders_choice':
			pass   # replaced by the folder groups appended to Direct Providers
		else:
			# action rows: auth/revoke, *_choice dialogs, restore, utilities
			if mode == 'settings_manager.restore_setting_default': conds = []   # fanart EndsWith / always offer restore
			data = onclick.replace('&amp;', '&')
			data = data[:-1] + '&reopen_settings=%s)' % CAT_KEYS[cat] if data.endswith(')') else data
			# never copy a secret into Kodi's settings file (the old TorBox row displayed tb.token itself)
			display = [s for s in shown if s not in (sid,) and not NEVER_MIRROR.search(s)]
			if display:   # the old row showed a value next to the action: a read-only row with it
				for s in display:
					if s not in UI:
						MIRROR.add(s)
						TYPES[s] = 'readonly'
					out.append(setting_xml(s, 'readonly', label if 'revoke' not in (mode or '') else 'Account', '', conds))
			# with a value row above it, the button itself reads 'Change ...' so the two rows don't look duplicated
			btn = 'Change' if display and 'revoke' not in (mode or '') else label
			out.append(setting_xml(unique_act(mode or label), 'action', btn, desc, conds, {'data': data}))
		if not is_child and sid and sid in UI and UI[sid] != 'action': last_parent[cat] = sid
		current[cat]['settings'].extend(out)

def build_folders():
	# the old "Set Folder Scrapers" row showed only with Local Media Folders on; the groups follow it
	on = [('atom', 'provider.folders', 'is', 'true')]
	groups = {}
	for vis, props, onclick in parse_items(os.path.join(SKIN, 'settings_manager_folders.xml'), '2101'):
		n = int(re.search(r'HasFocus\((\d+)\)', vis[0]).group(1)) // 10
		g = groups.setdefault(n, {'label': 'Folder %d' % n, 'settings': []})
		label = clean_label((props.get('setting_label') or [''])[0])
		mode, sid = mode_of(onclick), param(onclick, 'setting_id')
		report['rows'] += 1
		report['modes'][mode] = report['modes'].get(mode, 0) + 1
		if mode == 'settings_manager.set_string': add_ui(sid, 'string'); g['settings'].append(setting_xml(sid, 'string', label, '', on))
		elif mode == 'settings_manager.set_source_folder_path': add_ui(sid, 'path'); g['settings'].append(setting_xml(sid, 'path', label, '', on))
		else:
			data = onclick.replace('&amp;', '&')
			data = data[:-1] + '&reopen_settings=direct_providers)'
			g['settings'].append(setting_xml(unique_act('%s_%d' % (mode, n)), 'action', label, '', on, {'data': data}))
	for n in sorted(groups): categories[100].append(groups[n])

build_main()
build_folders()

# hidden settings used only by visibility conditions (derived booleans, mirrored account names)
hidden = []
for d in sorted(DERIVED):
	TYPES[d] = 'derived'
	hidden.append('\t\t\t\t<setting id="%s" type="boolean" label="%d">\n\t\t\t\t\t<level>0</level>\n\t\t\t\t\t<default>false</default>\n\t\t\t\t\t<visible>false</visible>\n\t\t\t\t\t<control type="toggle"/>\n\t\t\t\t</setting>\n' % (d, sid_for(d)))
for m in sorted(MIRROR):
	if TYPES.get(m) == 'readonly' or m in UI: continue   # already a visible read-only row / a real setting (forward reference)
	TYPES[m] = 'mirror'
	hidden.append('\t\t\t\t<setting id="%s" type="string" label="%d">\n\t\t\t\t\t<level>0</level>\n\t\t\t\t\t<default></default>\n\t\t\t\t\t<constraints><allowempty>true</allowempty></constraints>\n\t\t\t\t\t<visible>false</visible>\n\t\t\t\t\t<control type="edit" format="string"><heading>%d</heading></control>\n\t\t\t\t</setting>\n' % (m, sid_for(m), sid_for(m)))
categories[10].append({'label': 'Internal', 'settings': hidden, 'hidden': True})

# ---- merge groups whose rows are ALL conditional ----------------------------------------------
# Kodi builds the dialog once when it opens and skips a group whose rows are all hidden at that moment;
# ticking the switch that would show them cannot bring the group back until the dialog is reopened.
# Rows inside an existing group do show/hide live, so such a group is folded into its neighbour under a
# read-only heading row that carries the first row's visibility.
VIS = re.compile(r'\t*<dependency type="visible".*?(?:</dependency>\n|/>\n)', re.S)
def all_conditional(g):
	return bool(g['settings']) and all('<dependency type="visible"' in s for s in g['settings'])
ATOM = re.compile(r'setting="([^"]+)" operator="(\w+)"[^>]*>([^<]*)<')
def heading_visibility(rows):
	deps = [VIS.search(s) for s in rows]
	deps = [m.group(0) if m else '' for m in deps]
	atoms = [frozenset(ATOM.findall(d)) for d in deps]
	i = min(range(len(atoms)), key=lambda k: len(atoms[k]))
	if atoms[i] and all(atoms[i] <= a for a in atoms): return deps[i]
	return ''
def heading_row(g, n):
	# 2026-09-27: was the FIRST row's visibility, which hid SIMKL/AniList/TMDb/PM/AD/TB headings once
	# logged in (first row = Authorize, shown only when logged out). The heading must show whenever ANY
	# row under it does: use the simplest row's condition when every other row's includes it (Torrent
	# Providers: provider.external, some rows add their own switch), otherwise always show.
	vis = heading_visibility(g['settings'])
	deps = ('\t\t\t\t\t<dependencies>\n' + vis +
		'\t\t\t\t\t\t<dependency type="enable">\n\t\t\t\t\t\t\t<and>\n'
		'\t\t\t\t\t\t\t\t<condition on="property" name="InfoBool">false</condition>\n'
		'\t\t\t\t\t\t\t</and>\n\t\t\t\t\t\t</dependency>\n\t\t\t\t\t</dependencies>\n')
	return ('\t\t\t\t<setting id="_hdr.%d" type="string" label="%d">\n\t\t\t\t\t<level>0</level>\n\t\t\t\t\t<default></default>\n'
		'\t\t\t\t\t<constraints><allowempty>true</allowempty></constraints>\n%s'
		'\t\t\t\t\t<control type="edit" format="string"><heading>%d</heading></control>\n\t\t\t\t</setting>\n') % (
		n, sid_for('[B]%s[/B]' % g['label']), deps, sid_for(g['label']))
merged, hdr_n = [], 0
for cat, _ in CATS:
	out_groups = []
	for g in [g for g in categories[cat] if g['settings']]:
		# a category's first group is never folded (nothing before it); Real Debrid, the only one this
		# hits, always shows one of its complementary Authorize / Revoke rows, so Kodi always builds it
		# 2026-09-27: nor is a group without one shared master condition (heading_visibility ''): its rows
		# are complementary (Authorize when logged out / Revoke when in; key-missing info row / the rows the
		# key enables), so one always shows and Kodi builds it. Folding those gave SIMKL/AniList/etc. a big
		# bold row heading next to Kodi's small group titles.
		if g.get('hidden') or not out_groups or not all_conditional(g) or not heading_visibility(g['settings']):
			out_groups.append(g); continue
		hdr_n += 1
		out_groups[-1]['settings'].extend([heading_row(g, hdr_n)] + g['settings'])
		merged.append('%s > %s' % (dict(CATS)[cat], g['label']))
	categories[cat] = out_groups

# ---- write settings.xml -----------------------------------------------------------------------
out = ['<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n',
	'<!-- Generated by tools/gen_settings.py from the old DeadLight settings window (2026-09-26). Maintained by hand from here on. -->\n',
	'<settings version="1">\n\t<section id="%s">\n' % ADDON_ID]
for cat, name in CATS:
	out.append('\t\t<category id="%s" label="%d">\n' % (CAT_KEYS[cat], sid_for(name)))
	for gi, g in enumerate(categories[cat], 1):
		if not g['settings']: continue
		if g.get('hidden'): out.append('\t\t\t<group id="%d">\n' % gi)
		else: out.append('\t\t\t<group id="%d" label="%d">\n' % (gi, sid_for(g['label'])))
		out.extend(g['settings'])
		out.append('\t\t\t</group>\n')
	out.append('\t\t</category>\n')
out.append('\t</section>\n</settings>\n')
xml_text = ''.join(out)
ET.fromstring(xml_text.encode('utf-8'))
open(os.path.join(RES, 'settings.xml'), 'w', encoding='utf-8', newline='\n').write(xml_text)

# ---- write strings.po -------------------------------------------------------------------------
po_dir = os.path.join(RES, 'language', 'resource.language.en_gb')
os.makedirs(po_dir, exist_ok=True)
def po_escape(s): return s.replace('\\', '\\\\').replace('"', '\\"')
po = ['# DeadLight - settings strings (generated by tools/gen_settings.py)\n', 'msgid ""\n', 'msgstr ""\n',
	'"Content-Type: text/plain; charset=UTF-8\\n"\n', '"Content-Transfer-Encoding: 8bit\\n"\n', '"Language: en_GB\\n"\n', '\n']
for i, text in enumerate(STR):
	po.append('msgctxt "#%d"\nmsgid "%s"\nmsgstr ""\n\n' % (30000 + i, po_escape(text)))
open(os.path.join(po_dir, 'strings.po'), 'w', encoding='utf-8', newline='\n').write(''.join(po))

# ---- write the spec the sync layer uses -------------------------------------------------------
spec = ['# -*- coding: utf-8 -*-\n# Generated by tools/gen_settings.py - what modules/kodi_settings.py syncs.\n',
	'# UI: Kodi <-> settings.db (the user edits these in Kodi). MIRROR: settings.db -> Kodi only (read-only / hidden).\n',
	'# DERIVED: hidden booleans, true when the source setting is not empty (tokens never reach Kodi).\n',
	'UI = %r\n' % dict(sorted(UI.items())),
	'MIRROR = %r\n' % sorted(m for m in MIRROR if m not in UI),
	'DERIVED = %r\n' % dict(sorted(DERIVED.items())),
	'CATEGORIES = %r\n' % [CAT_KEYS[c] for c, _ in CATS]]
open(os.path.join(RES, 'lib', 'modules', 'kodi_settings_spec.py'), 'w', encoding='utf-8', newline='\n').write(''.join(spec))

# ---- report ------------------------------------------------------------------------------------
missing_defaults = sorted(s for s in list(UI) + list(MIRROR) + list(DERIVED.values()) if s not in DEFAULTS)
print('rows mapped      :', report['rows'])
print('modes            :', dict(sorted(report['modes'].items(), key=lambda x: -x[1])))
print('ui settings      :', len(UI), dict((k, list(UI.values()).count(k)) for k in sorted(set(UI.values()))))
print('mirrored (ro/hid):', len([m for m in MIRROR if m not in UI]), sorted(m for m in MIRROR if m not in UI))
print('derived booleans :', len(DERIVED), sorted(DERIVED))
print('unmapped rows    :', report['unmapped'] or 'none')
print('ids w/o default  :', missing_defaults or 'none')
print('merged groups    :', len(merged), merged)
print('strings          :', len(STR), '(ids 30000-%d)' % (30000 + len(STR) - 1))
