# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-01: DeadLight updates from its own Kodi repository (repository.pitou212 on GitHub Pages), the
# same place Kodi's add-on manager installs it from. The updater inherited from Fen Light read
# github.com/<update.username>/<update.location>/raw/main/packages -- FenlightAnonyMouse's, where no DeadLight exists --
# so Check For Updates, Rollback and the changelog all failed; those two settings are gone. The repository keeps the
# two newest zips (tools/repo_build.py --keep 2), so a rollback can go one version back; its index is addons.xml, and
# the build extracts each add-on's changelog.txt beside its zips.
import json
import re
import requests
import shutil
from os import path
from caches.settings_cache import set_setting
from modules.utils import unzip
from modules import kodi_utils
logger = kodi_utils.logger

ADDON_ID = 'plugin.video.deadlight'
REPO = 'https://pitou212.github.io/repository.pitou212/omega/zips/'
REPO_FILES = 'https://api.github.com/repos/pitou212/repository.pitou212/contents/docs/omega/zips/%s' % ADDON_ID
TIMEOUT = 15

def get_location(insert=''):
	return '%s%s/%s' % (REPO, ADDON_ID, insert)

def get_versions():
	try:
		result = requests.get(REPO + 'addons.xml', timeout=TIMEOUT)
		if result.status_code != 200: return None, None
		match = re.search(r'<addon\s[^>]*id="%s"[^>]*>' % re.escape(ADDON_ID), result.text)
		online_version = re.search(r'version="([^"]+)"', match.group(0)).group(1) if match else None
		if not online_version: return None, None
		return kodi_utils.addon_version(), online_version
	except: return None, None

def get_changes(online_version=None):
	try:
		if not online_version:
			current_version, online_version = get_versions()
			if not newer(current_version, online_version): return kodi_utils.ok_dialog(heading='DeadLight Updater',
				text='You are running the current version of DeadLight.[CR][CR]There is no new version changelog to view.')
		kodi_utils.show_busy_dialog()
		result = requests.get(get_location('changelog.txt'), timeout=TIMEOUT)
		kodi_utils.hide_busy_dialog()
		if result.status_code != 200: return kodi_utils.notification('Error', icon=kodi_utils.get_icon('downloads'))
		result.encoding = 'utf-8'
		return kodi_utils.show_text('New Online Release (v.%s) Changelog' % online_version, text=result.text, font_size='large')
	except:
		kodi_utils.hide_busy_dialog()
		return kodi_utils.notification('Error', icon=kodi_utils.get_icon('downloads'))

def _num(version):
	"""'3.0.10' -> (3, 0, 10): part by part, so 3.1.0 ranks above 3.0.10 (joined digits would not)."""
	return tuple(int(p) for p in re.findall(r'\d+', version or ''))

def newer(current_version, online_version):
	"""True only when the repository has a HIGHER version -- a newer local build must never be offered the older one."""
	if not current_version or not online_version: return False
	return _num(online_version) > _num(current_version)

def version_check(current_version, online_version):
	return newer(current_version, online_version)

def update_check(action=4):
	if action == 3: return
	current_version, online_version = get_versions()
	if not current_version:
		if action == 4: kodi_utils.ok_dialog(heading='DeadLight Updater', text='Could not reach the DeadLight repository.[CR]Please try again later.')
		return
	show_after_action = True
	if not newer(current_version, online_version):
		if action == 4: return kodi_utils.ok_dialog(heading='DeadLight Updater', text='Installed Version: [B]%s[/B][CR]Online Version: [B]%s[/B][CR][CR] %s' \
			% (current_version, online_version, '[B]No Update Available[/B]'))
		return
	if action in (0, 4):
		if not kodi_utils.confirm_dialog(heading='DeadLight Updater', text='Installed Version: [B]%s[/B][CR]Online Version: [B]%s[/B][CR][CR] %s' \
			% (current_version, online_version, '[B]An Update is Available[/B][CR]Perform Update?'), ok_label='Yes', cancel_label='No'): return
		if kodi_utils.confirm_dialog(heading='DeadLight Updater', text='Do you want to view the changelog for the new release before installing?', ok_label='Yes', cancel_label='No'):
			get_changes(online_version)
			if not kodi_utils.confirm_dialog(heading='DeadLight Updater', text='Continue with Update After Viewing Changes?', ok_label='Yes', cancel_label='No'): return
			show_after_action = False
	if action == 1: kodi_utils.notification('DeadLight Update Occurring', icon=kodi_utils.get_icon('downloads'))
	elif action == 2: return kodi_utils.notification('DeadLight Update Available', icon=kodi_utils.get_icon('downloads'))
	return update_addon(online_version, action, show_after_action)

def rollback_check():
	current_version = kodi_utils.addon_version()
	kodi_utils.show_busy_dialog()
	try: results = requests.get(REPO_FILES, timeout=TIMEOUT)
	except: results = None
	kodi_utils.hide_busy_dialog()
	if results is None or results.status_code != 200:
		return kodi_utils.ok_dialog(heading='DeadLight Updater', text='Error rolling back.[CR]Please install rollback manually')
	pattern = re.compile(r'%s-(.+)\.zip$' % re.escape(ADDON_ID))
	results = [m.group(1) for m in (pattern.match(i.get('name', '')) for i in results.json()) if m and m.group(1) != current_version]
	if not results: return kodi_utils.ok_dialog(heading='DeadLight Updater', text='No previous versions found.[CR]Please install rollback manually')
	results.sort(key=_num, reverse=True)
	list_items = [{'line1': item, 'icon': kodi_utils.get_icon('downloads')} for item in results]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Choose Rollback Version'}
	rollback_version = kodi_utils.select_dialog(results, **kwargs)
	if rollback_version == None: return
	if not kodi_utils.confirm_dialog(heading='DeadLight Updater',
		text='Are you sure?[CR]Version [B]%s[/B] will overwrite your current installed version.[CR]DeadLight will set your update action to [B]OFF[/B] if rollback is successful' \
		% rollback_version): return
	update_addon(rollback_version, 5)

def update_addon(new_version, action, show_after_action=True):
	kodi_utils.close_all_dialog()
	kodi_utils.execute_builtin('ActivateWindow(Home)', True)
	kodi_utils.notification('DeadLight Performing Rollback' if action == 5 else 'DeadLight Performing Update', icon=kodi_utils.get_icon('downloads'))
	zip_name = '%s-%s.zip' % (ADDON_ID, new_version)
	kodi_utils.show_busy_dialog()
	try: result = requests.get(get_location(zip_name), stream=True, timeout=TIMEOUT)
	except: result = None
	kodi_utils.hide_busy_dialog()
	if result is None or result.status_code != 200: return kodi_utils.ok_dialog(heading='DeadLight Updater', text='Error Updating.[CR]Please install new update manually')
	zip_location = path.join(kodi_utils.translate_path('special://home/addons/packages/'), zip_name)
	with open(zip_location, 'wb') as f: shutil.copyfileobj(result.raw, f)
	# check the download BEFORE the installed copy is removed: a truncated or wrong zip must leave DeadLight in place
	try:
		import zipfile
		with zipfile.ZipFile(zip_location) as z:
			if z.testzip() is not None or '%s/addon.xml' % ADDON_ID not in z.namelist(): raise ValueError('bad zip')
	except Exception:
		kodi_utils.delete_file(zip_location)
		return kodi_utils.ok_dialog(heading='DeadLight Updater', text='Error Updating.[CR]The download was incomplete. Please try again.')
	shutil.rmtree(path.join(kodi_utils.translate_path('special://home/addons/'), ADDON_ID))
	success = unzip(zip_location, kodi_utils.translate_path('special://home/addons/'), kodi_utils.translate_path('special://home/addons/%s/' % ADDON_ID))
	kodi_utils.delete_file(zip_location)
	if not success: return kodi_utils.ok_dialog(heading='DeadLight Updater', text='Error Updating.[CR]Please install new update manually')
	if action == 5:
		set_setting('update.action', '3')
		kodi_utils.ok_dialog(heading='DeadLight Updater', text='[CR]Success.[CR]DeadLight rolled back to version [B]%s[/B]' % new_version)
	elif action in (0, 4):
		if show_after_action:
			if kodi_utils.confirm_dialog(heading='DeadLight Updater', text='[CR]Success.[CR]DeadLight updated to version [B]%s[/B]' % new_version,
										ok_label='Changelog', cancel_label='Exit', default_control=10) is True:   # Back (None) no longer opens it
				kodi_utils.show_text('Changelog', file=kodi_utils.translate_path('special://home/addons/%s/resources/text/changelog.txt' % ADDON_ID), font_size='large')
		else:
			kodi_utils.ok_dialog(heading='DeadLight Updater', text='[CR]Success.[CR]DeadLight updated to version [B]%s[/B]' % new_version)
	kodi_utils.update_local_addons()
	kodi_utils.disable_enable_addon()
	kodi_utils.update_kodi_addons_db()
	kodi_utils.refresh_widgets()
