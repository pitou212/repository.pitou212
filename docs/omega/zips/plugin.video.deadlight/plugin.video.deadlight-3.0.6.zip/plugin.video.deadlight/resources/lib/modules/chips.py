# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-01: the results list's tags as outlined text chips (mock-up A) instead of flag logos.
# A Kodi list row has no box that sizes itself to its text, so each row's chips are drawn here as ONE strip
# image, packed from the left, and the skin shows that image. Strips are cached by their tag combination
# (a results list repeats a handful of combinations), so each is drawn once and then only looked up.
# Pillow 6.2 (Kodi 21 on Windows) has no rounded_rectangle and no textbbox, so both are done by hand.
import os
import hashlib
import threading
from modules.kodi_utils import translate_path, addon_profile, make_directory

STRIP_H = 88                   # px; shown at 36 in the rows and 42 in the detail panel, so drawn at 2x the larger
STRIP_MAX_W = 1650             # the row strip's 675 x 36 box at this height; chips past it are left out
_SCALE = 3                     # drawn this much larger and scaled down, for smooth corners and text
_VERSION = '10'                 # bump to redraw every cached strip after a change to the look

# flag file names (windows/sources.py _FLAG_COLUMNS) -> the chip's text
# LOCAL PATCH 2026-10-02: 'hdr10' (the flag for get_info's generic HDR tag) reads HDR -- the name often does not say HDR10,
# and the detail lines already said HDR. _VERSION 9 redraws the strips that said HDR10.
LABELS = {'dolbyvision': 'Dolby Vision', 'hdr10plus': 'HDR10+', 'hdr10': 'HDR',
		  'remux': 'Remux', 'web': 'WEB', 'bluray': 'Blu-ray', 'hdtv': 'HDTV', 'dvd': 'DVD', 'sdtv': 'SDTV',
		  'atmos': 'Atmos', 'truehd': 'TrueHD', 'dtsx': 'DTS:X', 'dtshd_ma': 'DTS-HD MA', 'dtshd_hra': 'DTS-HD', 'dts': 'DTS',
		  'eac3': 'DD+', 'ac3': 'DD', 'aac': 'AAC', 'opus': 'Opus', 'flac': 'FLAC', 'mp3': 'MP3',
		  'ch2': '2.0', 'ch6': '5.1', 'ch7': '6.1', 'ch8': '7.1', 'lang_multi': 'MULTI'}

_TEXT = (232, 237, 244, 255)
_BORDER = (232, 237, 244, 120)
_font = None
# One strip drawn at a time: Pillow's FreeType font is not safe to share between threads, and the rows are built
# on several. 2026-10-01: unlocked, a few rows of a 238-result list lost their chips and fell back to flags.
_lock = threading.Lock()
# LOCAL PATCH 2026-10-02: in-memory lookups for the life of this process. A results list asks for the same handful of
# strips hundreds of times (and the cards layout measures each chip alone besides): every call hashed the names and hit
# the disk for os.path.exists, and every width opened the PNG. A strip's file name hashes its content, so a path's size
# never changes. Only successful strips are kept; plain dict reads and writes, safe across the row builder's threads.
_strip_memo = {}
_size_memo = {}


def _font_path():
	"""The active skin's bold face (AF3: Inter-Bold), else any of its fonts, else Kodi's own Arial."""
	folder = translate_path('special://skin/fonts/')
	try: files = [f for f in os.listdir(folder) if f.lower().endswith(('.ttf', '.otf'))]
	except Exception: files = []
	for want in ('semibold', 'medium', 'bold', 'regular'):
		hit = [f for f in files if want in f.lower() and 'italic' not in f.lower()]
		if hit: return os.path.join(folder, sorted(hit)[0])
	if files: return os.path.join(folder, sorted(files)[0])
	return translate_path('special://xbmc/media/Fonts/arial.ttf')


def _get_font():
	global _font
	if _font is None:
		from PIL import ImageFont
		path = _font_path()
		_font = (path, ImageFont.truetype(path, int(STRIP_H * _SCALE * 0.48)))
	return _font


def _measure(font, text):
	"""(width, height, x offset, y offset) of the ink, on Pillow 6 and on 8+."""
	if hasattr(font, 'getbbox'):
		left, top, right, bottom = font.getbbox(text)
		return right - left, bottom - top, left, top
	width, height = font.getsize(text)
	ox, oy = font.getoffset(text)
	return width - ox, height - oy, ox, oy


def _rounded(draw, box, radius, fill):
	x0, y0, x1, y1 = box
	draw.rectangle((x0 + radius, y0, x1 - radius, y1), fill=fill)
	draw.rectangle((x0, y0 + radius, x1, y1 - radius), fill=fill)
	d = radius * 2
	draw.pieslice((x0, y0, x0 + d, y0 + d), 180, 270, fill=fill)
	draw.pieslice((x1 - d, y0, x1, y0 + d), 270, 360, fill=fill)
	draw.pieslice((x0, y1 - d, x0 + d, y1), 90, 180, fill=fill)
	draw.pieslice((x1 - d, y1 - d, x1, y1), 0, 90, fill=fill)


def strip_width(path, height):
	"""Width a strip shows at in a box `height` px tall (keep aspect), read from the PNG header; 0 if none."""
	if not path: return 0
	size = _size_memo.get(path)
	if size is None:
		try:
			with open(path, 'rb') as f: header = f.read(24)
			size = int.from_bytes(header[16:20], 'big'), int.from_bytes(header[20:24], 'big')
		except Exception: return 0
		_size_memo[path] = size
	w, h = size
	return int(w * height / float(h)) if h else 0


# LOCAL PATCH 2026-10-02: how many lines a text wraps to in a box `width` px wide, measured with the skin's REGULAR face
# at `size` px (font12 = Inter-Regular 24 in AF3). The List detail panel reserves 4 lines for the release name and slides
# what follows up by the lines left unused. Measured 6% narrow on purpose: one line too many leaves a small gap, one
# too few would slide the chips over the name.
_text_fonts, _char_widths, _text_lock = {}, {}, threading.Lock()


def _char_width(size, ch):
	"""Advance width of one character at `size` px, measured once and cached (a short lock only on a first sight)."""
	widths = _char_widths.setdefault(size, {})
	w = widths.get(ch)
	if w is None:
		with _text_lock:
			font = _text_fonts.get(size)
			if font is None:
				from PIL import ImageFont
				folder = translate_path('special://skin/fonts/')
				try: files = sorted(f for f in os.listdir(folder) if 'regular' in f.lower() and f.lower().endswith(('.ttf', '.otf')))
				except Exception: files = []
				font = _text_fonts[size] = ImageFont.truetype(os.path.join(folder, files[0]) if files else _font_path(), size)
			w = widths[ch] = font.getlength(ch) if hasattr(font, 'getlength') else font.getsize(ch)[0]
	return w


def text_lines(text, width, size=24, most=4):
	# 2026-10-02, second version: summed per-character widths instead of Pillow per word under the strip lock. The first
	# version held chips' _lock for every word of every row, so the row builder's threads queued behind it: 56 s of summed
	# thread time and 3.5 s wall for 243 rows (10:15:33). Kerning is ignored; the 6% margin below absorbs it.
	if not text: return 1
	try:
		limit, lines, used = width * 0.94, 1, 0.0
		space = _char_width(size, ' ')
		for word in text.split():
			w = sum(_char_width(size, ch) for ch in word)
			need = w if not used else used + space + w
			if need <= limit or not used: used = need
			else: lines, used = lines + 1, w
		return min(lines, most)
	except Exception: return most


def chip_label(name):
	"""lang_eng -> ENG; a known flag name -> its text."""
	if name in LABELS: return LABELS[name]
	if name.startswith('lang_'): return name[5:].upper()
	return name.upper()


def chip_strip(names):
	"""Path of a PNG strip of chips for these flag names, in order, or '' (no names, or drawing failed)."""
	if not names: return ''
	memo_key = tuple(names)
	path = _strip_memo.get(memo_key)
	if path: return path
	try:
		with _lock: font_path, font = _get_font()
		key = hashlib.md5(('%s|%s|%s' % (_VERSION, font_path, '|'.join(names))).encode('utf-8')).hexdigest()
		folder = os.path.join(addon_profile(), 'chips')
		path = os.path.join(folder, '%s.png' % key)
		if not os.path.exists(path):
			# one builder per strip: rows sharing a tag combination asked for the same file at once, and on Windows the
			# second os.replace onto it fails (PermissionError 13, 12:25:25 -- those rows fell back to the flag logos)
			with _key_lock(key):
				if not os.path.exists(path): path = _compose(names, font, font_path, folder, path)
		if path: _strip_memo[memo_key] = path
		return path
	except Exception as e:
		from modules.kodi_utils import logger
		logger('chips', 'strip %s failed: %r' % ('|'.join(names), e))
		return ''


# LOCAL PATCH 2026-10-02: strips are COMPOSED from one tile per chip. Each tile is drawn once ever (supersampled 3x, BOX-
# reduced, kept in memory and in chips/tiles/), so a new tag combination only pastes ready tiles and saves a PNG -- no text
# rendering, no 3x canvas, no resize, and no font lock, so the row builder's threads compose in parallel. Before: ~20-35 ms
# a strip under the lock, and a new title's strips held the results window for ~1 s (12:19:31, 164 rows). A tile's 3x width
# is rounded up to a multiple of 3 so its reduction stays exact (at most 1 px wider than a chip drawn inside a strip was).
_tile_memo = {}
_key_locks, _key_guard = {}, threading.Lock()


def _key_lock(key):
	with _key_guard: return _key_locks.setdefault(key, threading.Lock())


def _publish(tmp, path):
	"""Move a finished temp file into place; if Windows refuses because the file is already there, keep that one."""
	try: os.replace(tmp, path)
	except OSError:
		try: os.remove(tmp)
		except OSError: pass
		if not os.path.exists(path): raise


def _tile(name, font, font_path, folder):
	tile = _tile_memo.get(name)
	if tile is not None: return tile
	from PIL import Image, ImageDraw
	key = hashlib.md5(('%s|%s|%s' % (_VERSION, font_path, name)).encode('utf-8')).hexdigest()
	tiles = os.path.join(folder, 'tiles')
	cached = os.path.join(tiles, '%s.png' % key)
	if os.path.exists(cached):
		try:
			tile = Image.open(cached); tile.load()
			_tile_memo[name] = tile
			return tile
		except Exception: pass
	with _lock:
		tile = _tile_memo.get(name)
		if tile is not None: return tile
		s, h = _SCALE, STRIP_H * _SCALE
		pad, line, radius = int(h * 0.27), max(2, int(h * 0.05)), int(h * 0.22)
		# every label centred on the CAPITAL height, so they share a baseline -- centring each on its own ink put
		# 'Blu-ray' (a descender) higher than 'HDR10' beside it
		_cw, cap_h, _cx, cap_top = _measure(font, 'H')
		text = chip_label(name)
		tw, _th, ox, _oy = _measure(font, text)
		w = -(-(tw + pad * 2) // s) * s
		canvas = Image.new('RGBA', (w, h), (0, 0, 0, 0))
		draw = ImageDraw.Draw(canvas)
		_rounded(draw, (0, 0, w - 1, h - 1), radius, _BORDER)
		_rounded(draw, (line, line, w - 1 - line, h - 1 - line), max(1, radius - line), (0, 0, 0, 0))
		draw.text(((w - tw) // 2 - ox, (h - cap_h) // 2 - cap_top), text, font=font, fill=_TEXT)
		tile = canvas.resize((w // s, STRIP_H), Image.BOX)
		try:
			if not os.path.isdir(tiles): make_directory(tiles)
			tmp = '%s.%d.tmp' % (cached, threading.get_ident())
			tile.save(tmp, 'PNG', compress_level=1)
			_publish(tmp, cached)
		except Exception: pass
		_tile_memo[name] = tile
		return tile


def _compose(names, font, font_path, folder, path):
	from PIL import Image
	gap = int(round(int(STRIP_H * _SCALE * 0.18) / float(_SCALE)))
	placed, x = [], 0
	for name in names:
		tile = _tile(name, font, font_path, folder)
		if x + tile.size[0] > STRIP_MAX_W: break
		placed.append((x, tile))
		x += tile.size[0] + gap
	if not placed: return ''
	width = placed[-1][0] + placed[-1][1].size[0]
	strip = Image.new('RGBA', (width, STRIP_H), (0, 0, 0, 0))
	for x, tile in placed: strip.paste(tile, (x, 0))
	if not os.path.isdir(folder): make_directory(folder)
	tmp = '%s.%d.tmp' % (path, threading.get_ident())   # the rows are built on several threads at once
	strip.save(tmp, 'PNG', compress_level=1)
	_publish(tmp, path)
	return path
