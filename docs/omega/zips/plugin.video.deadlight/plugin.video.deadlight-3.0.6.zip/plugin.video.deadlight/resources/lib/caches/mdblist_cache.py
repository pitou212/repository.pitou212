# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-23: MDBList cache module ported from POV's mdbl_cache.py.
# Mirrors caches/trakt_cache.py 1:1 in shape — same table layout (mdbl_data KV
# blob + watched + progress + watched_status), same set_bulk_* signatures so
# watched_status.py dispatch can call either interchangeably based on
# watched_indicators setting (1=Trakt, 2=MDBList).
import time
from threading import Thread
from caches.base_cache import connect_database, kv_encode, kv_decode, replace_watched_rows, replace_progress_rows
from modules.kodi_utils import confirm_dialog


class MDBLCache:
	def get(self, string):
		result = None
		try:
			dbcon = connect_database('mdblist_db')
			cache_data = dbcon.execute('SELECT data FROM mdbl_data WHERE id = ?', (string,)).fetchone()
			if cache_data: result = kv_decode(cache_data[0])   # LOCAL PATCH 2026-10-02, see base_cache.kv_encode
		except: pass
		return result

	def set(self, string, data):
		try:
			dbcon = connect_database('mdblist_db')
			dbcon.execute('INSERT OR REPLACE INTO mdbl_data (id, data) VALUES (?, ?)', (string, kv_encode(data)))
		except: return None

	def delete(self, string):
		try:
			dbcon = connect_database('mdblist_db')
			dbcon.execute('DELETE FROM mdbl_data WHERE id = ?', (string,))
		except: pass

	# ─── Bulk setters (called from mdbl_indicators_* / mdbl_progress_*) ────
	# Signatures mirror TraktWatched so watched_status dispatch is drop-in
	# swappable. Same empty-list guard from trakt_cache.py:47 — never wipe
	# the local watched/progress table if the sync returned empty (API may
	# have failed; keep old data until the next successful sync).
	def set_bulk_movie_watched(self, insert_list, since=None):
		if not insert_list: return
		# LOCAL PATCH 2026-10-03: keeps marks made while the sync was downloading (base_cache.replace_watched_rows)
		replace_watched_rows(connect_database('mdblist_db'), 'movie', insert_list, since)

	def set_bulk_tvshow_watched(self, insert_list, since=None):
		if not insert_list: return
		# LOCAL PATCH 2026-10-03: keeps marks made while the sync was downloading (base_cache.replace_watched_rows)
		replace_watched_rows(connect_database('mdblist_db'), 'episode', insert_list, since)

	def set_bulk_movie_progress(self, insert_list, since=None):
		if not insert_list: return
		# LOCAL PATCH 2026-10-03 (Batch 2, base_cache.replace_progress_rows): keeps resume points saved while the sync was downloading.
		replace_progress_rows(connect_database('mdblist_db'), 'movie', insert_list, since)

	def set_bulk_tvshow_progress(self, insert_list, since=None):
		if not insert_list: return
		# LOCAL PATCH 2026-10-03 (Batch 2, base_cache.replace_progress_rows): keeps resume points saved while the sync was downloading.
		replace_progress_rows(connect_database('mdblist_db'), 'episode', insert_list, since)

	def _executemany(self, command, insert_list):
		dbcon = connect_database('mdblist_db')
		dbcon.executemany(command, insert_list)

	def _delete(self, command, args):
		# LOCAL PATCH 2026-08-10 (Red Light 2.2.1 port): VACUUM removed from the sync
		# hot path — see the matching comment in caches/trakt_cache.py. (simkl_cache
		# never had it.) Space is still reclaimed by clear_all_mdbl_cache_data().
		dbcon = connect_database('mdblist_db')
		dbcon.execute(command, args)


mdbl_cache = MDBLCache()


def cache_mdbl_object(function, string, url, max_age_hours=None):
	# LOCAL PATCH 2026-10-03 (3.0.8): max_age_hours for rows no activity stamp covers -- the contents of a list someone
	# ELSE owns (a liked list) change without this account's list_updated_at moving, so they were never re-read. The
	# write time sits in a sibling row, so rows written before this patch count as expired once and gain one.
	stamp_key = '%s_ts' % string
	cache = mdbl_cache.get(string)
	if cache is not None:
		if not max_age_hours: return cache
		try:
			if time.time() - float(mdbl_cache.get(stamp_key) or 0) < max_age_hours * 3600: return cache
		except (TypeError, ValueError): pass
	result = function(url)
	if result is not None and max_age_hours: mdbl_cache.set(stamp_key, int(time.time()))
	# LOCAL PATCH 2026-09-15: only a real result is stored. A None here means the fetch
	# FAILED (call_mdblist returns None on 429 / timeout / HTTP error); caching it is a
	# pointless write, and it is the same rule apis/tvdb_api._cached documents. Rows in
	# mdbl_data carry no expiry, so anything stored here lives until the sync sees
	# list_updated_at move or the cache is cleared outright.
	if result is not None: mdbl_cache.set(string, result)
	return result


# ═══════════════════════════════════════════════════════════════════════════
#  Activity pivot — the master sync in mdblist_api reads/writes this record.
# ═══════════════════════════════════════════════════════════════════════════

def get_activity():
	"""LOCAL PATCH 2026-10-03 (3.0.8): the stored activity snapshot, read-only (None when there is none)."""
	try: return mdbl_cache.get('mdbl_get_activity')
	except Exception: return None


def reset_activity(latest_activities):
	string = 'mdbl_get_activity'
	try:
		dbcon = connect_database('mdblist_db')
		data = dbcon.execute('SELECT data FROM mdbl_data WHERE id = ?', (string,)).fetchone()
		if data: cached_data = kv_decode(data[0])
		else: cached_data = default_activities()
		dbcon.execute('DELETE FROM mdbl_data WHERE id=?', (string,))
		mdbl_cache.set(string, latest_activities)
	except: cached_data = default_activities()
	return cached_data


# ═══════════════════════════════════════════════════════════════════════════
#  Cache invalidation — each write op or sync activity change calls these.
# ═══════════════════════════════════════════════════════════════════════════

def clear_mdbl_collection_watchlist_data(list_type):
	# list_type = 'collection' | 'watchlist'
	string = 'mdbl_%s' % list_type
	try:
		dbcon = connect_database('mdblist_db')
		dbcon.execute('DELETE FROM mdbl_data WHERE id=?', (string,))
	except: pass


def clear_mdbl_list_data(list_type):
	# list_type = 'my_lists' | 'external' | 'hidden_items_dropped'
	string = 'mdbl_%s' % list_type
	try:
		dbcon = connect_database('mdblist_db')
		dbcon.execute('DELETE FROM mdbl_data WHERE id=?', (string,))
	except: pass


def clear_mdbl_list_contents_data(list_type):
	string = 'mdbl_list_contents_' + list_type + '_%'
	try:
		dbcon = connect_database('mdblist_db')
		dbcon.execute('DELETE FROM mdbl_data WHERE id LIKE "%s"' % string)
	except: pass


def clear_all_mdbl_cache_data(silent=False, refresh=True):
	try:
		start = silent or confirm_dialog()
		if not start: return False
		dbcon = connect_database('mdblist_db')
		# LOCAL PATCH 2026-09-24: carry queued progress saves across the wipe -- they exist
		# nowhere else (see mdblist_api._PENDING_KEY).
		pending = dbcon.execute('SELECT data FROM mdbl_data WHERE id = ?', ('mdbl_pending_progress',)).fetchone()
		for table in ('progress', 'watched', 'watched_status'):
			dbcon.execute('DELETE FROM %s' % table)
		dbcon.execute('DELETE FROM mdbl_data')
		if pending: dbcon.execute('INSERT OR REPLACE INTO mdbl_data (id, data) VALUES (?, ?)', ('mdbl_pending_progress', pending[0]))
		dbcon.execute('VACUUM')
		# LOCAL PATCH 2026-10-03 (Batch 3): the calendar is cached in maincache, not here, and survived the wipe
		try:
			from caches.main_cache import main_cache
			main_cache.delete_like('mdbl_get_my_calendar_%')
		except Exception: pass
		if refresh:
			from apis.mdblist_api import mdbl_sync_activities
			Thread(target=mdbl_sync_activities).start()
		return True
	except: return False


def default_activities():
	# MDBList's sync/last_activities response shape. Any field the server may
	# emit is present here at epoch so first-time diffs always trigger a rebuild.
	return {
		'collected_at':       '2020-01-01T00:00:01.000Z',
		'watchlisted_at':     '2020-01-01T00:00:01.000Z',
		'dropped_at':         '2020-01-01T00:00:01.000Z',
		'list_updated_at':    '2020-01-01T00:00:01.000Z',
		'watched_at':         '2020-01-01T00:00:01.000Z',
		'episode_watched_at': '2020-01-01T00:00:01.000Z',
		'paused_at':          '2020-01-01T00:00:01.000Z',
		'episode_paused_at':  '2020-01-01T00:00:01.000Z',
	}
