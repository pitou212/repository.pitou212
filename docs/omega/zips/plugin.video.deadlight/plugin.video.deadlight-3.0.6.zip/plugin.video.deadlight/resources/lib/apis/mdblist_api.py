# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-23 / OAuth port 2026-08-07: MDBList integration ported from POV.
# MDBList (mdblist.com) is a metadata + lists service like Trakt.
#
# Auth modes (DUAL — detected at call time via `mdblist.refresh` setting):
#   - OAuth device-code (POV 6.07+): user provides own client_id, does device-code
#     flow via /oauth/device-authorization/, receives access_token + refresh_token.
#     call_mdblist sends `Authorization: Bearer` header. mdbl_expires() refreshes
#     proactively before expiry via /oauth/token/.
#   - Legacy API-key (pre-6.07): user pastes raw API key. call_mdblist sends
#     `?apikey=...` query param. No refresh needed.
# Existing installs continue on API-key mode until user re-authorizes via OAuth.
#
# Key differences from POV's mdblist_api.py:
#   - Uses DeadLight's `kodi_utils.make_session` for pooled HTTP (per the Trakt
#     patch idiom), not a bare `requests.Session()`.
#   - Imports adapted to DeadLight module paths (`caches.mdblist_cache` not
#     `caches.mdbl_cache`; `caches.settings_cache.get_setting`; `modules.settings`
#     accessors named per DeadLight conventions).
#   - TMDb external-id helpers used to normalise mixed-id MDBList responses come
#     from DeadLight's `apis.tmdb_api` (movie_external_id / tvshow_external_id).

from threading import Thread, Lock
import random as _random
import time
from operator import itemgetter
from urllib.parse import quote
from caches import mdblist_cache
from caches.base_cache import sync_since
from caches.main_cache import cache_object
from caches.settings_cache import get_setting, set_setting
from modules import kodi_utils, settings
from modules.utils import sort_for_article, jsondate_to_datetime, get_datetime, TaskPool

EXPIRES_1_HOURS = 1
MAX_LIST_ITEMS = 250_000
BASE_URL = 'https://api.mdblist.com/%s'
TIMEOUT = 5.05

logger = kodi_utils.logger

# Pooled HTTP session — same pattern as apis/trakt_api.py:13.
session = kodi_utils.make_session('https://api.mdblist.com/')

# LOCAL PATCH 2026-09-14: rate-limit circuit breaker, mirroring apis/omdb_api.py.
#
# call_mdblist funnelled every failure through `except Exception: return None`, so an HTTP 429
# was indistinguishable from "this title has no data". Observed after a metacache clear:
# 268 x 429 across 248 shows in 37 seconds, and because mdblist_ratings_info returned {} for
# each, metadata._backfill_mdblist stamped mdblist_backfill_ts on all 248 and deferred their
# retry by 24 hours -- for a throttle that clears in minutes.
#
# Detect anywhere. A 429 from any caller trips the breaker (the limit is per key). It was built
# for the per-row ratings path, removed 2026-09-29 (TMDbHelper supplies title ratings). Still read
# by progress sync (watched_status) and the pending drop-list flush (mdbl_flush_pending), which
# stand down while it is open, and by the lists indexer, whose 'rate limited' toast names the
# wait -- list browsing and edits are user actions that must fail visibly, not vanish.
#
# Window property, not module state: reuselanguageinvoker=false wipes globals per invocation.
# MDBList's throttle is a burst limit rather than OMDb's daily quota, so the window is short.
# Retry-After wins when the response carries one.
_COOLDOWN_PROP = 'deadlight.mdblist_cooldown_until'
_COOLDOWN_DEFAULT = 300
_COOLDOWN_MIN, _COOLDOWN_MAX = 60, 3600


# LOCAL PATCH 2026-09-16: pace calls so a parallel meta build cannot spend MDBList's
# BURST allowance in one go. This is a different limit from the daily quota the breaker
# above reacts to, and confusing the two cost a whole library's ratings:
#
# On 2026-09-16 a bulk build of 364 TV metas ran across 28 threads inside a 2.2s window.
# 25 titles got ratings, 13 took an HTTP 429, and the breaker those 429s opened silently
# skipped the remaining ~326 -- each then cached with no extra_ratings block and a TTL of
# up to six months. The account had 874 of its 1000 daily calls still unused. Nothing was
# short of budget; 28-way concurrency simply asked too fast (~11 req/s at the point it
# tripped), and the breaker correctly turned one 429 into a minute of silence for everyone.
#
# The pacing state must be CROSS-INVOCATION, for the same reason the breaker's cooldown is.
# reuselanguageinvoker=false gives every plugin invocation its own module namespace, and Kodi
# runs several concurrently (widgets, containers, background builds). A module-level lock
# alone paces only the threads inside ONE invocation -- measured on 2026-09-16 after trying
# exactly that: successes still landed 2ms apart and the 429s continued, because seven
# invocations each politely doing 4/s is still 28/s at the key.
#
# So the last-call timestamp lives in a window property, which every invocation shares, and
# the module Lock stays to serialise the threads within each one. The read-then-write is not
# atomic across invocations, so two can occasionally slip through together; a small jitter
# keeps them from re-synchronising, and the breaker above still catches whatever gets past.
_PACE_PROP = 'deadlight.mdblist_last_call'
_MIN_CALL_INTERVAL = 0.25
_throttle_lock = Lock()


def _throttle():
	"""Block until at least _MIN_CALL_INTERVAL has passed since the last call by ANY invocation."""
	try:
		with _throttle_lock:
			for _ in range(40):   # bounded: never stall a request longer than ~10s
				try: last = float(kodi_utils.get_property(_PACE_PROP) or 0)
				except (TypeError, ValueError): last = 0
				wait = _MIN_CALL_INTERVAL - (time.time() - last)
				if wait <= 0: break
				time.sleep(min(wait, 0.25) + _random.uniform(0, 0.05))
			kodi_utils.set_property(_PACE_PROP, str(time.time()))
	except Exception:
		pass


def mdblist_cooldown_minutes():
	"""Whole minutes left on the cooldown, 0 when none. For user-facing messages."""
	try:
		until = float(kodi_utils.get_property(_COOLDOWN_PROP) or 0)
		return max(0, int((until - time.time()) // 60))
	except Exception:
		return 0


def mdblist_on_cooldown():
	"""True while MDBList is known rate-limited (see the breaker at the top of this module)."""
	try:
		until = kodi_utils.get_property(_COOLDOWN_PROP)
		return bool(until) and time.time() < float(until)
	except Exception:
		return False


def _start_cooldown(retry_after=None, reason='HTTP 429'):
	try:
		try: secs = int(float(retry_after))
		except (TypeError, ValueError): secs = _COOLDOWN_DEFAULT
		secs = max(_COOLDOWN_MIN, min(secs, _COOLDOWN_MAX))
		kodi_utils.set_property(_COOLDOWN_PROP, str(time.time() + secs))
		logger('MDBList', 'rate limited (%s) - skipping MDBList ratings for %d min' % (reason, secs // 60))
	except Exception: pass


# ═══════════════════════════════════════════════════════════════════════════
#  Authorize / Revoke
#
#  LOCAL PATCH 2026-08-07 (POV 6.07 OAuth port): device-code flow replaces the
#  legacy API-key paste dialog. User must register their own MDBList "app" (at
#  mdblist.com preferences → Applications) to get a client_id.
#
#  Flow:
#   1. POST /oauth/device-authorization/ with {client_id, scope='write'} →
#      returns {device_code, user_code, verification_uri, expires_in, interval}
#   2. Show user_code + URL, poll /oauth/token/ every `interval` seconds
#   3. On success: {access_token, refresh_token, expires_in} → store all three
#   4. GET /user with Bearer → username
#
#  Legacy API-key mode still works — call_mdblist auto-detects: if mdblist.refresh
#  is set → Bearer; else → apikey query param. Old installs stay on API-key mode
#  until they re-Authorize via OAuth.
# ═══════════════════════════════════════════════════════════════════════════

_DEVICE_CODE_URL = BASE_URL % 'oauth/device-authorization/'
_TOKEN_URL = BASE_URL % 'oauth/token/'
_DEVICE_GRANT = 'urn:ietf:params:oauth:grant-type:device_code'


def _mdbl_client_id():
	v = (get_setting('deadlight.mdblist.client_id', '') or '').strip()
	return v if v and v != 'empty_setting' else ''


def mdbl_refresh():
	"""Trade refresh_token for a new access_token. Called by mdbl_expires() before
	expiry, and also proactively from MDBListMonitor. Silent on failure."""
	import time as _t, requests as _rq
	try:
		client_id = _mdbl_client_id()
		refresh_tok = get_setting('deadlight.mdblist.refresh', '')
		if not client_id or not refresh_tok or refresh_tok == 'empty_setting': return False
		created_at = _t.time()
		data = {'grant_type': 'refresh_token', 'refresh_token': refresh_tok, 'client_id': client_id}
		r = _rq.post(_TOKEN_URL, data=data, timeout=TIMEOUT)
		if not r.ok:
			logger('mdbl_refresh error', 'HTTP %s: %s' % (r.status_code, r.text[:200]))
			return False
		response = r.json()
		new_token = response.get('access_token')
		new_refresh = response.get('refresh_token') or refresh_tok
		expires_in = int(response.get('expires_in') or 0)
		if not new_token or not expires_in: return False
		set_setting('mdblist.token', new_token)
		set_setting('mdblist.refresh', new_refresh)
		set_setting('mdblist.expires', str(int(created_at) + expires_in))
		return True
	except Exception as e:
		logger('mdbl_refresh error', str(e))
		return False


def mdbl_expires():
	"""Refresh access_token if it will expire within the next sync interval.
	Called by MDBListMonitor before every sync tick. No-op when in API-key mode."""
	try:
		refresh_tok = get_setting('deadlight.mdblist.refresh', '')
		if not refresh_tok or refresh_tok == 'empty_setting': return
		from datetime import datetime, timezone
		try: interval_sec = int(settings.mdblist_sync_interval()[1] or 3600)
		except Exception: interval_sec = 3600
		current = int(datetime.now(timezone.utc).timestamp())
		try: expires = int(get_setting('deadlight.mdblist.expires', '0') or 0)
		except (TypeError, ValueError): expires = 0
		if interval_sec + current >= expires: mdbl_refresh()
	except Exception: pass


def mdblist_authenticate(dummy=''):
	"""OAuth device-code flow (POV 6.07 port). Falls back to API-key paste when
	client_id is not configured (backward compatibility for existing setups)."""
	import time as _t, requests as _rq
	client_id = _mdbl_client_id()
	if not client_id:
		# Prompt for client_id, then continue into OAuth. Cancel = falls through
		# to legacy API-key paste for users who prefer that.
		client_id = kodi_utils.kodi_dialog().input('MDBList Client ID (register at mdblist.com preferences)') or ''
		client_id = client_id.strip()
		if client_id:
			set_setting('mdblist.client_id', client_id)
		else:
			# No client_id → legacy API-key path
			return _mdblist_authenticate_apikey()

	# OAuth device-code flow
	try:
		r = _rq.post(_DEVICE_CODE_URL, data={'client_id': client_id, 'scope': 'write'}, timeout=TIMEOUT)
		if not r.ok:
			kodi_utils.ok_dialog('MDBList Authorize', 'Device authorization failed: HTTP %s\n%s' % (r.status_code, r.text[:200]))
			return False
		device_data = r.json()
	except Exception as e:
		kodi_utils.ok_dialog('MDBList Authorize', 'Device authorization request failed:\n%s' % str(e)[:200])
		return False

	device_code = device_data['device_code']
	user_code = device_data['user_code']
	verification_uri = device_data['verification_uri']
	expires_in = int(device_data.get('expires_in', 900))
	interval = int(device_data.get('interval', 5))

	# Copy code to clipboard for easy paste
	try:
		from modules.utils import copy2clip
		copy2clip(user_code)
	except Exception: pass

	# Poll for token
	# LOCAL PATCH 2026-09-30: a QR code beside the code (kodi_utils.qr_dialog), and BACK cancels -- the old wait had
	# no way out for its 30 minutes. MDBList's verification_uri_complete carries the code already
	# (https://mdblist.com/oauth/device/?user_code=...), so scanning it leaves only the sign-in.
	poll_data = {'device_code': device_code, 'client_id': client_id, 'grant_type': _DEVICE_GRANT}
	def _poll():
		pr = _rq.post(_TOKEN_URL, data=poll_data, timeout=TIMEOUT)
		if pr.ok:
			token_resp = pr.json()
			if token_resp.get('access_token'): return token_resp
	token_resp = kodi_utils.qr_dialog('MDBList Authorize', device_data.get('verification_uri_complete') or verification_uri,
		'Scan the [B]QR code[/B] -- the code is filled in -- and sign in.[CR]Or open [B]%s[/B] and enter:   '
		'[COLOR gold][B]%s[/B][/COLOR][CR]DeadLight carries on once you confirm. [B]Back[/B] cancels.' % (verification_uri, user_code),
		wait=expires_in, poll=_poll, interval=interval) or {}
	access_token = token_resp.get('access_token')
	refresh_token = token_resp.get('refresh_token', '')
	token_expires_in = int(token_resp.get('expires_in') or 0)

	if not access_token:
		kodi_utils.notification('MDBList Authorize cancelled or timed out', 5000)
		return False

	# Fetch username via authorized /user endpoint
	created_at = int(_t.time())
	try:
		r = _rq.get(BASE_URL % 'user', headers={'Authorization': 'Bearer %s' % access_token}, timeout=TIMEOUT)
		username = str(r.json().get('username') or 'MDBList User')
	except Exception:
		username = 'MDBList User'

	set_setting('mdblist.token', access_token)
	set_setting('mdblist.refresh', refresh_token)
	set_setting('mdblist.expires', str(created_at + token_expires_in) if token_expires_in else '')
	set_setting('mdblist.user', username)
	set_setting('watched_indicators', '2')
	kodi_utils.notification('MDBList Authorized as %s' % username, 4000)
	try: mdbl_sync_activities(force_update=True)
	except Exception: pass
	return True


def _mdblist_authenticate_apikey():
	"""Legacy API-key authorize path — retained for users who prefer the old flow
	OR don't want to register an OAuth app. Wipes any OAuth artifacts on success
	so call_mdblist reverts to apikey mode."""
	existing = (get_setting('deadlight.mdblist.token', '') or '').strip()
	if existing and existing != 'empty_setting':
		token = existing
	else:
		token = kodi_utils.kodi_dialog().input('MDBList API Key (from mdblist.com/preferences)')
		if not token: return False
	set_setting('mdblist.token', token)
	# Wipe OAuth artifacts so call_mdblist uses apikey query param.
	set_setting('mdblist.refresh', 'empty_setting')
	set_setting('mdblist.expires', 'empty_setting')
	try:
		user_info = call_mdblist('user')
		if not user_info or not user_info.get('username'):
			raise ValueError('missing username')
		username = str(user_info['username'])
	except Exception as e:
		logger('mdblist auth error', str(e))
		set_setting('mdblist.token', 'empty_setting')
		kodi_utils.notification('MDBList Error Authorizing', 3000)
		return False
	set_setting('mdblist.user', username)
	set_setting('watched_indicators', '2')
	kodi_utils.notification('MDBList Account Authorized (API key mode)', 3500)
	try: mdbl_sync_activities(force_update=True)
	except Exception: pass
	return True


def mdblist_revoke_authentication(dummy=''):
	set_setting('mdblist.user', 'empty_setting')
	set_setting('mdblist.token', 'empty_setting')
	set_setting('mdblist.refresh', 'empty_setting')
	set_setting('mdblist.expires', 'empty_setting')
	set_setting('watched_indicators', '0')
	try:
		mdblist_cache.clear_all_mdbl_cache_data(silent=True, refresh=False)
	except: pass
	kodi_utils.notification('MDBList Account Authorization Reset', 3000)


# ═══════════════════════════════════════════════════════════════════════════
#  Low-level HTTP + pagination
# ═══════════════════════════════════════════════════════════════════════════

def call_mdblist(path, params=None, json=None, method=None):
	"""Single entry-point for MDBList HTTP calls. Dual-mode auth:
	  - OAuth (POV 6.07+): if `mdblist.refresh` set → `Authorization: Bearer <token>`
	  - Legacy API key: else → `?apikey=<token>` query param
	Cursor-based pagination via `X-Has-More` + `X-Next-Cursor` response headers.

	LOCAL PATCH 2026-08-06: single retry on ConnectionError/ConnectionResetError.
	`session` is a pooled requests.Session — TCP connections stay open across
	sync ticks. After device sleep/wake the sockets in the pool go stale;
	the first request gets WinError 10054 ('An existing connection was forcibly
	closed'). One retry gets a fresh socket + succeeds."""
	import requests as _rq
	params = dict(params or {})
	# LOCAL PATCH 2026-08-07: OAuth-vs-apikey mode detection.
	refresh_tok = get_setting('deadlight.mdblist.refresh', '')
	oauth_mode = bool(refresh_tok) and refresh_tok != 'empty_setting'
	headers = None
	if oauth_mode:
		headers = {'Authorization': 'Bearer %s' % get_setting('deadlight.mdblist.token')}
	else:
		params['apikey'] = get_setting('deadlight.mdblist.token')
	url = BASE_URL % path
	for attempt in (1, 2):
		try:
			_throttle()   # LOCAL PATCH 2026-09-16
			response = session.request(method or 'get', url, params=params, json=json, headers=headers, timeout=TIMEOUT)
			result = response.json() if 'json' in response.headers.get('Content-Type', '') else response.text
			if not response.ok: response.raise_for_status()
			if isinstance(result, list):
				result = {'items': result, 'pagination': {'has_more': response.headers.get('X-Has-More') == 'true'}}
				nxt = response.headers.get('X-Next-Cursor')
				if nxt: result['pagination']['next_cursor'] = nxt
			return result
		except (_rq.exceptions.ConnectionError, ConnectionResetError, ConnectionAbortedError) as e:
			if attempt == 1:
				logger('mdblist retry', 'stale-conn %s — retrying once' % str(e)[:120])
				continue
			logger('mdblist error', 'connection failed after retry: %s' % str(e)[:200])
			return None
		except _rq.exceptions.HTTPError as e:
			# LOCAL PATCH 2026-09-14: a 429 is a KEY-level condition, not a per-title miss. Trip the
			# breaker above; every other HTTP status keeps its previous meaning (404 = no data).
			resp = getattr(e, 'response', None)
			if resp is not None and resp.status_code == 429:
				_start_cooldown(resp.headers.get('Retry-After'))
			logger('mdblist error', str(e))
			return None
		except Exception as e:
			logger('mdblist error', str(e))
			return None


def _get_mdbl_paginated_list(url):
	"""Walk MDBList cursor pagination for endpoints that return list-typed
	payloads. Buckets by media key so `sync/watched` (returns movies+episodes)
	and `sync/collection` (movies+shows) both fill correctly."""
	params = {'limit': 1000}
	items = {'movies': [], 'shows': [], 'episodes': [], 'items': []}
	fetched_any = False
	try:
		for _ in range(MAX_LIST_ITEMS // params['limit']):
			result = call_mdblist(url, params=params)
			if not isinstance(result, dict): break
			fetched_any = True
			for k in items:
				if k in result and isinstance(result[k], list):
					items[k].extend(result[k])
			if not result.get('pagination', {}).get('has_more'): break
			params['cursor'] = result['pagination']['next_cursor']
	except: pass
	# LOCAL PATCH 2026-09-15: a fetch that never got a page is a FAILURE, not an empty list.
	# Returning the empty bucket dict here made a 429 / timeout indistinguishable from a
	# list with no items, and cache_mdbl_object then stored it with no expiry -- observed
	# 2026-09-15 07:09: two of three user lists cached as {'items': []} during a quota
	# exhaustion, and they would have stayed empty until the user next edited a list.
	# A later page failing still returns the partial result, as before.
	if not fetched_any: return None
	return items


# ═══════════════════════════════════════════════════════════════════════════
#  List browse — top / search / user
# ═══════════════════════════════════════════════════════════════════════════

# LOCAL PATCH 2026-09-26: json=False on both. call_mdblist already returns a parsed dict, and
# cache_object's default json=True called .json() on it -- an AttributeError that
# get_mdblist_top_lists' bare except turned into an empty page. Top User Lists had never
# shown anything since the POV port (nothing was ever cached for it); the search page below
# was unreachable as well, so the same bug hid in both.
def mdbl_top_lists():
	string = 'mdbl_top_lists'
	url = 'lists/top'
	return cache_object(call_mdblist, string, url, json=False)['items']


def mdbl_search_lists(query):
	query = quote(query)
	string = 'mdbl_search_lists_%s' % query
	url = 'lists/search?query=%s' % query
	return cache_object(call_mdblist, string, url, json=False, expiration=EXPIRES_1_HOURS)['items']


def mdbl_get_lists(list_type):
	"""list_type='external' → lists the user has liked on MDBList ; else → user's own lists.
	LOCAL PATCH 2026-07-31: `external/lists/user` returns [] on current MDBList API —
	the endpoint for lists the user liked/starred is `lists/liked`, which returns
	{'lists': [...], 'pagination': {}} (not the raw-list shape call_mdblist wraps
	into 'items'). Handle both keys."""
	if list_type == 'external':
		string, url = 'mdbl_external', 'lists/liked'
	else:
		string, url = 'mdbl_my_lists', 'lists/user'
	response = mdblist_cache.cache_mdbl_object(call_mdblist, string, url)
	if response is None: return None   # LOCAL PATCH 2026-09-15: failed fetch, not an empty account
	return response.get('lists') or response.get('items') or []


def get_mdbl_list_contents(list_type, list_id):
	"""LOCAL PATCH 2026-07-31: `external/lists/{id}/items` is for user-imported RSS/
	Trakt sources — returns 403 for lists the user merely liked. Fetch liked-list
	contents (list_type='external') via the same public `lists/{id}/items` path
	used for the user's own lists — the endpoint accepts any public list by id."""
	string = 'mdbl_list_contents_%s_%s' % (list_type, list_id)
	url = 'lists/%s/items?unified=true' % list_id
	# LOCAL PATCH 2026-09-15: None means the fetch failed (see _get_mdbl_paginated_list); the
	# indexer tells the user instead of drawing an empty list. [] is a genuinely empty list.
	# LOCAL PATCH 2026-10-03 (3.0.8): a liked list is someone else's -- re-read daily (see cache_mdbl_object)
	response = mdblist_cache.cache_mdbl_object(_get_mdbl_paginated_list, string, url, max_age_hours=24 if list_type == 'external' else None)
	if response is None: return None
	return response.get('items') or []


# ═══════════════════════════════════════════════════════════════════════════
#  Personal lists — collection / watchlist / dropped
# ═══════════════════════════════════════════════════════════════════════════

def mdblist_collection(mediatype, page_no):
	string = 'mdbl_collection'
	url = 'sync/collection'
	original_list = mdbl_collection_watchlist_items(string, url)
	if mediatype == 'all':
		original_list = original_list['movies'] + original_list['shows']
		for i in original_list:
			i.update({'id': i['movie' if 'movie' in i else 'show']['ids']['tmdb']})
		return original_list
	original_list = original_list[mediatype]
	key = 'movie' if mediatype in ('movie', 'movies') else 'show'
	for i in original_list:
		i.update({
			'id': i[key]['ids']['tmdb'], 'imdb_id': i[key]['ids'].get('imdb', ''),
			'title': i[key]['title'], 'year': i[key].get('year', 0)
		})
	sort_key = settings.lists_sort_order('collection')
	if sort_key == 2:
		original_list.sort(key=itemgetter('year'), reverse=True)
	elif sort_key == 1:
		original_list.sort(key=itemgetter('collected_at'), reverse=True)
	else:
		original_list = sort_for_article(original_list, 'title', settings.ignore_articles())
	if settings.paginate(False):
		from modules.utils import paginate_list
		return paginate_list(original_list, page_no, settings.page_limit(False))
	return original_list, 1


def mdblist_watchlist(mediatype, page_no):
	def first_aired(item):
		if not item.get('release_date'): return False
		return jsondate_to_datetime(item['release_date']).astimezone().date() <= current_date
	string = 'mdbl_watchlist'
	url = 'watchlist/items'
	original_list = mdbl_collection_watchlist_items(string, url)
	if mediatype == 'all':
		return original_list['movies'] + original_list['shows']
	original_list = original_list[mediatype]
	if not settings.show_unaired_watchlist():
		current_date = get_datetime()
		original_list = [i for i in original_list if first_aired(i)]
	sort_key = settings.lists_sort_order('watchlist')
	if sort_key == 2:
		original_list.sort(key=lambda x: x.get('release_date') or '', reverse=True)
	elif sort_key == 1:
		original_list.sort(key=itemgetter('watchlist_at'), reverse=True)
	else:
		original_list = sort_for_article(original_list, 'title', settings.ignore_articles())
	if settings.paginate(False):
		from modules.utils import paginate_list
		return paginate_list(original_list, page_no, settings.page_limit(False))
	return original_list, 1


def mdbl_collection_watchlist_items(string, url):
	return mdblist_cache.cache_mdbl_object(_get_mdbl_paginated_list, string, url)


def mdblist_droplist(mediatype, page_no):
	results = mdbl_get_hidden_items('dropped')
	return [{'imdb_id': '', 'id': i} for i in results], 1


# LOCAL PATCH 2026-08-05 (POV 6.08 P2 port): MDBList Calendar. Uses
# /calendar/events?start=...&end=... which returns per-episode airings for
# shows the user has in their Watchlist/Watching/Collection. Same shape family
# as Trakt calendar so episodes.py can render with the shared calendar path.
def _mdbl_calendar_days(recently_aired, current_date):
	from datetime import timedelta
	if recently_aired:
		return (current_date - timedelta(days=14)).strftime('%Y-%m-%d'), current_date.strftime('%Y-%m-%d')
	previous_days = int(get_setting('deadlight.trakt.calendar_previous_days', '0') or '0')
	future_days = int(get_setting('deadlight.trakt.calendar_future_days', '7') or '7')
	start = (current_date - timedelta(days=previous_days)).strftime('%Y-%m-%d')
	finish = (current_date + timedelta(days=future_days)).strftime('%Y-%m-%d')
	return start, finish


def _mdbl_calendar_data(url):
	result = []
	seen = set()
	try:
		resp = call_mdblist(url) or {}
		# MDBList calendar returns either {'events': [...]} or a bare list — accept both.
		events = resp.get('events') if isinstance(resp, dict) else resp
		for i in (events or []):
			try:
				if i.get('type') and i.get('type') != 'episode': continue
				if i.get('season_number', 0) <= 0: continue
				tmdb_id = i.get('show_tmdb') or i.get('show_id') or ''
				if not tmdb_id: continue
				season, episode = i['season_number'], i['episode_number']
				show_title = i.get('show_title') or i.get('title') or ''
				sort_title = '%s s%02d e%02d' % (show_title, int(season), int(episode))
				if sort_title in seen: continue
				seen.add(sort_title)
				result.append({
					'sort_title': sort_title,
					'first_aired': i.get('start') or i.get('air_date') or '',
					'media_ids': {'tmdb': tmdb_id},
					'season': int(season), 'episode': int(episode),
				})
			except Exception: continue
	except Exception: pass
	return result


def mdbl_get_my_calendar(recently_aired, current_date):
	start, finish = _mdbl_calendar_days(recently_aired, current_date)
	string = 'mdbl_get_my_calendar_%s_%s' % (start, finish)
	url = 'calendar/events?limit=1000&start=%s&end=%s' % (start, finish)
	# LOCAL PATCH 2026-08-06: cache_object with json=False — _mdbl_calendar_data already
	# does the JSON parse + event normalization internally and returns a plain list.
	# Default json=True would call .json() on the list and crash with AttributeError.
	return cache_object(_mdbl_calendar_data, string, url, json=False)


def mdbl_get_hidden_items(list_type):
	def _get_mdbl_ids(item):
		tmdb_id = get_mdbl_tvshow_id(item['show']['ids'])
		if tmdb_id: results_append(tmdb_id)
	def _process(url):
		hidden_data = [(i,) for i in call_mdblist(url)['shows']]
		for i in TaskPool().tasks(_get_mdbl_ids, hidden_data, 10): i.join()   # LOCAL PATCH 2026-10-02: was Thread (the class) -> int() failed -> 1 thread
		return results
	results = []
	results_append = results.append
	string = 'mdbl_hidden_items_%s' % list_type
	url = 'sync/dropped'
	return mdblist_cache.cache_mdbl_object(_process, string, url)


def hide_unhide_mdbl_items(action, mediatype, media_id, list_type):
	"""Add/remove a show from MDBList's dropped list (hide-from-discovery)."""
	if action not in ('hide', 'unhide'):
		try:
			hidden_data = mdbl_get_hidden_items('dropped')
			action = 'unhide' if int(action) in hidden_data else 'hide'
		except: return kodi_utils.notification('MDBList update failed')
	mediatype = 'movies' if mediatype in ('movie', 'movies') else 'shows'
	# LOCAL PATCH 2026-09-20: the id key follows the id we were actually handed instead
	# of assuming imdb for every show. POV's single caller passes params['imdb_id'], so the
	# hardcoded 'imdb' was correct there; all three DeadLight callers pass a TMDb id (the
	# context menu via tvshows.py, watched_status.update_hidden_progress, and dialogs), so
	# every drop posted {'ids': {'imdb': <a tmdb id>}}, matched nothing on MDBList's side,
	# and the discarded response let drop_show notify 'Show Dropped' regardless.
	#
	# MDBList's sync endpoints do take tmdb for shows: dialogs.py's own add/remove path
	# falls back to it and mdbl_watched_unwatched defaults to it.
	key = 'imdb' if str(media_id).startswith('tt') else 'tmdb'
	url = 'sync/dropped' if action == 'hide' else 'sync/dropped/remove'
	data = {mediatype: [{'ids': {key: media_id}}]}
	# LOCAL PATCH 2026-09-20: the response was thrown away, so a request that matched
	# nothing was indistinguishable from one that worked and every caller reported
	# success. Returns True/False so they can say what actually happened. The body is
	# logged once per call because the exact shape of sync/dropped's reply has never
	# been observed here -- confirm it against ###MDBList drop### before tightening
	# this to an 'updated' count the way add_to_collection does.
	result = call_mdblist(url, json=data, method='post')
	try:
		from modules.kodi_utils import logger
		logger('###MDBList drop###', '%s %s=%s -> %s' % (url, key, media_id, repr(result)[:300]))
	except Exception: pass
	mdbl_sync_activities()
	kodi_utils.container_refresh()
	return bool(result)


# ═══════════════════════════════════════════════════════════════════════════
#  Write ops — collection / list add & remove / list CRUD
# ═══════════════════════════════════════════════════════════════════════════

def add_to_collection(data):
	result = call_mdblist('sync/collection', json=data, method='post')
	if not result or result['updated']['movies'] + result['updated']['shows'] == 0:
		return kodi_utils.notification('MDBList update failed')
	kodi_utils.notification('MDBList updated')
	mdbl_sync_activities()
	return result


def remove_from_collection(data):
	result = call_mdblist('sync/collection/remove', json=data, method='post')
	if not result or result['removed']['movies'] + result['removed']['shows'] == 0:
		return kodi_utils.notification('MDBList update failed')
	kodi_utils.notification('MDBList updated')
	mdbl_sync_activities()
	kodi_utils.container_refresh()
	return result


def add_to_list(list_id, data):
	url = 'watchlist/items/add' if list_id == 'watchlist' else 'lists/%s/items/add' % list_id
	result = call_mdblist(url, json=data, method='post')
	if not result or result['added']['movies'] + result['added']['shows'] == 0:
		return kodi_utils.notification('MDBList update failed')
	kodi_utils.notification('MDBList updated')
	mdbl_sync_activities()
	return result


def remove_from_list(list_id, data):
	url = 'watchlist/items/remove' if list_id == 'watchlist' else 'lists/%s/items/remove' % list_id
	result = call_mdblist(url, json=data, method='post')
	if not result or result['removed']['movies'] + result['removed']['shows'] == 0:
		return kodi_utils.notification('MDBList update failed')
	kodi_utils.notification('MDBList updated')
	mdbl_sync_activities()
	kodi_utils.container_refresh()
	return result


def make_new_mdbl_list(params):
	from urllib.parse import unquote
	list_title = kodi_utils.kodi_dialog().input(kodi_utils.addon_name())   # LOCAL PATCH 2026-09-07: rebrand
	if not list_title: return
	list_name = unquote(list_title)
	data = {'name': list_name, 'private': False}
	result = call_mdblist('lists/user/add', json=data, method='post')
	if result is None: return kodi_utils.notification('MDBList update failed')
	mdblist_cache.clear_mdbl_list_data('my_lists')
	kodi_utils.notification('MDBList updated')
	kodi_utils.container_refresh()


def delete_mdbl_list(params):
	if not kodi_utils.confirm_dialog(): return
	list_id = params['list_id']
	url = 'lists/%s' % list_id
	result = call_mdblist(url, method='delete')
	if result is None: return kodi_utils.notification('MDBList update failed')
	mdblist_cache.clear_mdbl_list_data('my_lists')
	kodi_utils.notification('MDBList updated')
	kodi_utils.container_refresh()


# ═══════════════════════════════════════════════════════════════════════════
#  ID normalisation — MDBList responses carry mixed imdb/tmdb/tvdb per row.
# ═══════════════════════════════════════════════════════════════════════════

def get_mdbl_movie_id(item):
	if item.get('tmdb'): return item['tmdb']
	from apis.tmdb_api import movie_external_id
	for k, v in (('imdb_id', 'imdb'),):
		try:
			if item.get(v):
				res = movie_external_id(k, item[v])
				if res: return res['id']
		except: pass


def get_mdbl_tvshow_id(item):
	if item.get('tmdb'): return item['tmdb']
	from apis.tmdb_api import tvshow_external_id
	for k, v in (('imdb_id', 'imdb'), ('tvdb_id', 'tvdb')):
		try:
			if item.get(v):
				res = tvshow_external_id(k, item[v])
				if res: return res['id']
		except: pass


# ═══════════════════════════════════════════════════════════════════════════
#  Watched / scrobble — enables watched_indicators == 2 (MDBList as SoT)
# ═══════════════════════════════════════════════════════════════════════════

def _mdbl_regular_season_numbers(tmdb_id):
	"""Regular (non-special) season numbers for a show.

	MDBList marks a season's EPISODES; a bare show id updates nothing, which is what made
	'mark show as watched' report an error and write no tick. Season 0 is excluded --
	specials are not part of a normal completion."""
	try:
		from modules import metadata
		meta = metadata.tvshow_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(),
					settings.mpaa_region(), get_datetime())
	except Exception: meta = None
	nums, seen = [], set()
	for item in (meta or {}).get('season_data') or []:
		try: n = int(item.get('season_number'))
		except Exception: continue
		if n > 0 and n not in seen:
			seen.add(n)
			nums.append(n)
	return nums


def _mdbl_mark_counted(result, *keys):
	"""True when MDBList recorded the mark under EITHER bucket.

	LOCAL PATCH 2026-09-23 (Red Light 2.6.8 port): a FIRST watch is counted under `added`;
	only a REPEAT watch lands in `updated`. Reading `updated` alone therefore scored every
	first mark as a failure, which fell through to the tvdb retry and returned False -- so
	the local tick was never written and the caller showed 'Error'."""
	total = 0
	for name in ('added', 'updated'):
		bucket = (result or {}).get(name) or {}
		if not isinstance(bucket, dict): continue
		for key in keys:
			try: total += int(bucket.get(key) or 0)
			except Exception: pass
	return total > 0


def _mdbl_not_found(result):
	"""True when MDBList could not match the id at all -- the one real failure mode."""
	nf = (result or {}).get('not_found') or {}
	if not isinstance(nf, dict): return bool(nf)
	for val in nf.values():
		if isinstance(val, list) and val: return True
		try:
			if int(val or 0) > 0: return True
		except Exception: pass
	return False


def mdbl_watched_unwatched(action, media, media_id, tvdb_id=0, season=None, episode=None, key='tmdb', episodes=None, season_numbers=None):
	"""Mark or unmark a movie/show/season/episode as watched on MDBList.
	Falls back to tvdb key when tmdb lookup returns no changes and a tvdb id
	is available (matches POV's behavior — some MDBList records only have
	tvdb ids from the mapping tables)."""
	if action == 'mark_as_watched':
		url, result_key = 'sync/watched', 'updated'
	else:
		url, result_key = 'sync/watched/remove', 'removed'
	try: media_id = int(media_id)
	except: pass
	if media == 'movies':
		success_key = 'movies'
		data = {'movies': [{'ids': {key: media_id}}]}
	else:
		success_key = 'episodes'
		if media == 'episodes' and episodes:
			# LOCAL PATCH 2026-08-29: a LIST of episode numbers in one call, for anime cours.
			# A cour is a slice of a TMDb season, so the season payload would take its
			# siblings with it.
			seasons = [{'number': int(season), 'episodes': [{'number': int(e)} for e in episodes]}]
			data = {'shows': [{'ids': {key: media_id}, 'seasons': seasons}]}
		elif media == 'episode':
			seasons = [{'number': int(season), 'episodes': [{'number': int(episode)}]}]
			data = {'shows': [{'ids': {key: media_id}, 'seasons': seasons}]}
		elif media == 'shows':
			# LOCAL PATCH 2026-09-23 (Red Light 2.6.8 port): send every regular season, the same
			# shape Mark Season already uses. MDBList marks a season's EPISODES, so a bare show
			# id changed nothing at all and the mark was silently lost.
			if season_numbers is None and key == 'tmdb':
				season_numbers = _mdbl_regular_season_numbers(media_id)
			_show = {'ids': {key: media_id}}
			if season_numbers: _show['seasons'] = [{'number': int(n)} for n in season_numbers]
			data = {'shows': [_show]}
		else:
			data = {'shows': [{'ids': {key: media_id}, 'seasons': [{'number': int(season)}]}]}  # season
	result = call_mdblist(url, json=data, method='post')
	if not isinstance(result, dict): return False
	# LOCAL PATCH 2026-09-23 (Red Light 2.6.8 port): see _mdbl_mark_counted -- `updated`
	# alone missed every first watch. 'seasons' counts too, for the season/show payloads.
	if action == 'mark_as_watched':
		success = _mdbl_mark_counted(result, 'movies' if media == 'movies' else 'episodes', 'seasons')
	else:
		bucket = result.get(result_key) or {}
		success = bucket.get(success_key, 0) > 0 if isinstance(bucket, dict) else False
	if not success and media != 'movies' and tvdb_id != 0 and key != 'tvdb':
		return mdbl_watched_unwatched(action, media, tvdb_id, 0, season, episode, 'tvdb', episodes, season_numbers)
	# Already watched there: added and updated are both 0 because nothing NEEDED to change,
	# and the id was matched. That is a success -- treating it as failure is what made a
	# re-mark from Next Episodes report an error. A bare show id is the exception, since
	# that reply legitimately updates nothing.
	if not success and action == 'mark_as_watched' and not _mdbl_not_found(result):
		if media != 'shows' or season_numbers: return True
	# Remove with 0 removed: already unwatched, likewise not a failure.
	if not success and action != 'mark_as_watched': return True
	if not success:
		logger('MDBList', 'mark %s %s id=%s: %s' % (action, media, media_id, result))
	return success


def mdbl_progress(action, media, media_id, percent, season=None, episode=None, resume_id=None, refresh_mdb=False):
	"""Push playback progress to MDBList (scrobble/pause endpoint) or clear it
	(scrobble/clear). Called from watched_status.set_bookmark / erase_bookmark
	when watched_indicators == 2."""
	if action == 'clear_progress':
		data = {'id': resume_id}
		url = 'scrobble/clear'
	else:
		try: media_id = int(media_id)
		except: pass
		if media in ('movie', 'movies'):
			data = {'movie': {'ids': {'tmdb': media_id}}, 'progress': float(percent)}
		else:
			data = {'show': {'ids': {'tmdb': media_id}, 'season': {'number': int(season), 'episode': {'number': int(episode)}}}, 'progress': float(percent)}
		url = 'scrobble/pause'
	# LOCAL PATCH 2026-09-24: report whether MDBList took it. call_mdblist returns None on ANY
	# failure (429, network), and the result used to be dropped, so a refused save vanished.
	ok = call_mdblist(url, json=data, method='post') is not None
	if refresh_mdb and ok: mdbl_sync_activities()
	return ok


# LOCAL PATCH 2026-09-24: progress saves MDBList did not accept, kept and re-sent.
#
# A resume point used to be ONE scrobble/pause call whose result was ignored, with nothing kept
# locally. On 2026-09-24 the daily quota was spent, every call answered 429 with an hour's
# Retry-After, and stopping Brothers S01E02 at 570s of 1696 saved nothing -- replayed four minutes
# later, it started from the beginning. watched_status.set_bookmark now writes the local row
# first (so resume works at once) and queues the save here when MDBList refuses it.
#
# The queue lives in mdbl_data so it outlives Kodi. Two things would otherwise lose it: the
# bulk sync REBUILDS the local progress table from MDBList, which has never seen a queued save
# (_pending_reapply puts those rows back), and clear_all_mdbl_cache_data wipes mdbl_data (which
# carries the queue across). Marking watched or clearing a resume point drops its entry, so a
# stale position is never re-sent over a finished episode.
_PENDING_KEY = 'mdbl_pending_progress'


def _pending_key(media, media_id, season, episode):
	if media in ('movie', 'movies'): return 'movie|%s||' % media_id
	return 'episode|%s|%s|%s' % (media_id, int(season), int(episode))


def mdbl_pending_progress():
	pending = mdblist_cache.MDBLCache().get(_PENDING_KEY)
	return pending if isinstance(pending, dict) else {}


def _pending_store(pending):
	mdblist_cache.MDBLCache().set(_PENDING_KEY, pending)


def mdbl_queue_progress(media, media_id, percent, season, episode, curr_time, title):
	try:
		pending = mdbl_pending_progress()
		pending[_pending_key(media, media_id, season, episode)] = {
			'media': 'movie' if media in ('movie', 'movies') else 'episode', 'media_id': str(media_id),
			'percent': float(percent), 'season': season, 'episode': episode,
			'curr_time': str(curr_time), 'title': title, 'queued_at': time.strftime('%Y-%m-%dT%H:%M:%S.000Z', time.gmtime())}
		_pending_store(pending)
		logger('MDBList', 'progress not accepted -- queued %s (%d waiting)' % (_pending_key(media, media_id, season, episode), len(pending)))
	except Exception as e:
		logger('MDBList', 'progress queue failed: %s' % str(e)[:120])


def mdbl_pending_drop(media, media_id, season='', episode=''):
	try:
		pending = mdbl_pending_progress()
		if pending.pop(_pending_key(media, media_id, season, episode), None) is not None: _pending_store(pending)
	except Exception: pass


def mdbl_flush_pending():
	"""Re-send queued saves while MDBList is not refusing calls. Stops at the first refusal:
	the rest would only spend more of an exhausted quota."""
	pending = mdbl_pending_progress()
	if not pending: return
	sent = []
	for key, item in list(pending.items()):
		if mdblist_on_cooldown(): break
		if not mdbl_progress('set_progress', item['media'], item['media_id'], item['percent'], item['season'], item['episode']): break
		sent.append(key)
	if sent:
		pending = mdbl_pending_progress()   # re-read: a save may have queued meanwhile
		for key in sent: pending.pop(key, None)
		_pending_store(pending)
		logger('MDBList', 'sent %d queued progress save(s), %d still waiting' % (len(sent), len(pending)))


def _pending_reapply():
	"""Queued saves back into the local progress table, after a bulk sync rebuilt it."""
	pending = mdbl_pending_progress()
	if not pending: return
	try:
		from caches.base_cache import connect_database
		dbcon = connect_database('mdblist_db')
		for item in pending.values():
			movie = item['media'] == 'movie'
			season, episode = ('', '') if movie else (item['season'], item['episode'])
			dbcon.execute('INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
				(item['media'], item['media_id'], season, episode, str(item['percent']), item['curr_time'], item['queued_at'], 0, item['title']))
	except Exception as e:
		logger('MDBList', 'progress queue reapply failed: %s' % str(e)[:120])


# ═══════════════════════════════════════════════════════════════════════════
#  Indicator bulk builders — populate local mdbl_db watched/progress tables
#  from MDBList sync endpoints. Called from mdbl_sync_activities.
# ═══════════════════════════════════════════════════════════════════════════

def mdbl_indicators_movies(watched_info, since=None):
	def _process(item):
		tmdb_id = get_mdbl_movie_id(item['movie']['ids'])
		if not tmdb_id: return
		insert_append((
			'movie', str(tmdb_id), '', '', item['last_watched_at'], item['movie']['title']
		))
	insert_list = []
	insert_append = insert_list.append
	watched_items = [(i,) for i in watched_info['movies']]
	if not watched_items:
		return mdblist_cache.MDBLCache().set_bulk_movie_watched(insert_list, since)
	for i in TaskPool().tasks(_process, watched_items, 10): i.join()   # LOCAL PATCH 2026-10-02: was Thread (the class) -> int() failed -> 1 thread
	mdblist_cache.MDBLCache().set_bulk_movie_watched(insert_list, since)


def mdbl_indicators_tv(watched_info, since=None):
	def _process(item):
		tmdb_id = get_mdbl_tvshow_id(item['episode']['show']['ids'])
		if not tmdb_id: return
		season, episode = item['episode']['season'], item['episode']['number']
		insert_append((
			'episode', str(tmdb_id), season, episode, item['last_watched_at'], item['episode']['show']['title']
		))
	insert_list = []
	insert_append = insert_list.append
	watched_items = [(i,) for i in watched_info['episodes']]
	if not watched_items:
		return mdblist_cache.MDBLCache().set_bulk_tvshow_watched(insert_list, since)
	for i in TaskPool().tasks(_process, watched_items, 10): i.join()   # LOCAL PATCH 2026-10-02: was Thread (the class) -> int() failed -> 1 thread
	mdblist_cache.MDBLCache().set_bulk_tvshow_watched(insert_list, since)


def mdbl_progress_movies(progress_info, since=None):
	def _process(item):
		tmdb_id = get_mdbl_movie_id(item['movie']['ids'])
		if not tmdb_id: return
		insert_append((
			'movie', str(tmdb_id), '', '', str(round(float(item['progress']), 1)),
			0, item['paused_at'], item['id'], item['movie']['title']
		))
	insert_list = []
	insert_append = insert_list.append
	progress_items = [(i,) for i in progress_info if i['type'] == 'movie' and float(i['progress']) > 1]
	if not progress_items:
		return mdblist_cache.MDBLCache().set_bulk_movie_progress(insert_list, since)
	for i in TaskPool().tasks(_process, progress_items, 10): i.join()   # LOCAL PATCH 2026-10-02: was Thread (the class) -> int() failed -> 1 thread
	mdblist_cache.MDBLCache().set_bulk_movie_progress(insert_list, since)
	_pending_reapply()   # LOCAL PATCH 2026-09-24


def mdbl_progress_tv(progress_info, since=None):
	def _process(item):
		tmdb_id = get_mdbl_tvshow_id(item['show']['ids'])
		if not tmdb_id: return
		season, episode = item['episode']['season'], item['episode']['number']
		if season > 0:
			insert_append((
				'episode', str(tmdb_id), season, episode, str(round(float(item['progress']), 1)),
				0, item['paused_at'], item['id'], item['show']['title']
			))
	insert_list = []
	insert_append = insert_list.append
	progress_items = [(i,) for i in progress_info if i['type'] == 'episode' and float(i['progress']) > 1]
	if not progress_items:
		return mdblist_cache.MDBLCache().set_bulk_tvshow_progress(insert_list, since)
	for i in TaskPool().tasks(_process, progress_items, 10): i.join()   # LOCAL PATCH 2026-10-02: was Thread (the class) -> int() failed -> 1 thread
	mdblist_cache.MDBLCache().set_bulk_tvshow_progress(insert_list, since)
	_pending_reapply()   # LOCAL PATCH 2026-09-24


def mdbl_playback_progress():
	return call_mdblist('sync/playback')


def mdbl_get_activity():
	return call_mdblist('sync/last_activities')


# LOCAL PATCH 2026-10-03 (3.0.8): a mark made here moves MDBList's episode_watched_at, the next sync sees the stamp
# move, and re-downloads the whole watched history -- 9,010 rows, 4.5-8.3 s, then a second widget reload -- to learn
# about the one mark it just made and already wrote locally. mdbl_acked_write brackets the write with two activity
# polls: when nothing had moved beforehand (the stored snapshot matches) and only the keys this write is expected to
# move have moved afterwards, the new stamps are recorded as already seen, and the sync that follows says 'not
# needed'. Anything else -- a key moved before the write, an unexpected key moved, a poll failed, a cooldown -- is a
# plain write with the snapshot left alone, so the sync downloads exactly as before.
# The blind spot is a change made elsewhere to the same key between the two polls (~0.5 s). _ACK_AUDIT_KEY records
# the first unaudited acknowledgement; a sync more than a day later downloads the watched history once regardless.
_ACK_AUDIT_KEY = 'mdbl_ack_audit'
_ACK_AUDIT_SECONDS = 24 * 3600

def mdbl_acked_write(write, moves):
	if mdblist_on_cooldown(): return write()
	try:
		from caches.mdblist_cache import default_activities
		keys = list(default_activities())
		stored, before = mdblist_cache.get_activity(), mdbl_get_activity()
		quiet = isinstance(stored, dict) and isinstance(before, dict) and all(before.get(k) == stored.get(k) for k in keys)
	except Exception: quiet = False
	result = write()
	if not (result and quiet): return result
	try:
		after = mdbl_get_activity()
		if not isinstance(after, dict): return result
		moved = [k for k in keys if after.get(k) != before.get(k)]
		if moved and set(moved) <= set(moves):
			mdblist_cache.reset_activity(after)
			if not mdblist_cache.mdbl_cache.get(_ACK_AUDIT_KEY): mdblist_cache.mdbl_cache.set(_ACK_AUDIT_KEY, int(time.time()))
			logger('MDBList', 'own write acknowledged (%s): no re-download' % ', '.join(moved))
	except Exception: pass
	return result


# ═══════════════════════════════════════════════════════════════════════════
#  Master sync — activity-pivot driven cache invalidation + selective rebuild
# ═══════════════════════════════════════════════════════════════════════════


def mdbl_sync_activities(force_update=False, monitor=None):
	"""Poll MDBList `sync/last_activities`, diff timestamps against the local
	cached snapshot, and selectively invalidate + rebuild caches. Called
	on-demand after write ops AND by the background MDBListMonitor service."""
	def _compare(latest, cached):
		try: return (latest or '') > (cached or '')
		except: return True
	if not get_setting('deadlight.mdblist.user', ''):
		return 'no account'
	if monitor and monitor.abortRequested():
		return
	if force_update:
		# LOCAL PATCH 2026-07-28: DeadLight doesn't have modules.cache — the DB
		# creation helper lives in caches.base_cache.make_databases.
		from caches.base_cache import make_databases
		make_databases()
		mdblist_cache.clear_all_mdbl_cache_data(silent=True, refresh=False)
	# LOCAL PATCH 2026-09-24: queued progress first, so the playback list fetched below has it.
	try: mdbl_flush_pending()
	except Exception: pass
	# LOCAL PATCH 2026-10-03 (Batch 2): stamped before the poll; local marks at or after it survive the rewrite (base_cache.sync_since)
	since = sync_since()
	latest = mdbl_get_activity()
	if latest is None:
		# LOCAL PATCH 2026-09-07: a failed poll used to WIPE the whole MDbList cache -- progress,
		# watched, watched_status, every list -- and, because this was the one call site that
		# forgot silent=True, it did so through an 'Are you sure?' confirm raised from the
		# background MDBListMonitor thread. kodi.log 2026-09-07 19:21:30: Kodi had been up 14s,
		# the network was not, all four sync services failed with 'Max retries exceeded', and
		# only this one answered with a dialog. A poll that could not reach the server says
		# nothing about whether the cache is stale; Trakt, SIMKL and AniList simply report
		# 'Update Failed' and retry in 60 minutes, which is what the service does anyway.
		# Do the same. force_update above still clears (silently) when the user asks for it.
		return 'failed'
	cached = mdblist_cache.reset_activity(latest)
	success = 'not needed'
	if _compare(latest.get('collected_at'), cached.get('collected_at')):
		success = 'success'
		mdblist_cache.clear_mdbl_collection_watchlist_data('collection')
	if _compare(latest.get('watchlisted_at'), cached.get('watchlisted_at')):
		success = 'success'
		mdblist_cache.clear_mdbl_collection_watchlist_data('watchlist')
	if _compare(latest.get('dropped_at'), cached.get('dropped_at')):
		success = 'success'
		mdblist_cache.clear_mdbl_list_data('hidden_items_dropped')
	if _compare(latest.get('list_updated_at'), cached.get('list_updated_at')):
		success = 'success'
		for i in ('external', 'my_lists'):
			mdblist_cache.clear_mdbl_list_data(i)
			mdblist_cache.clear_mdbl_list_contents_data(i)
	# LOCAL PATCH 2026-10-03 (3.0.8): the once-a-day audit of acknowledged writes (mdbl_acked_write)
	audit = False
	try:
		acked_at = mdblist_cache.mdbl_cache.get(_ACK_AUDIT_KEY)
		audit = bool(acked_at) and time.time() - int(acked_at) > _ACK_AUDIT_SECONDS
	except Exception: pass
	refresh_movies_watched = audit or _compare(latest.get('watched_at'), cached.get('watched_at'))
	refresh_episodes_watched = audit or _compare(latest.get('episode_watched_at'), cached.get('episode_watched_at'))
	if audit:
		logger('MDBList', 'audit of acknowledged writes: watched history downloaded once')
		mdblist_cache.mdbl_cache.delete(_ACK_AUDIT_KEY)
	refresh_movies_paused = _compare(latest.get('paused_at'), cached.get('paused_at'))
	refresh_episodes_paused = _compare(latest.get('episode_paused_at'), cached.get('episode_paused_at'))
	if refresh_movies_watched or refresh_episodes_watched:
		success = 'success'
		watched_info = _get_mdbl_paginated_list('sync/watched')
		if refresh_movies_watched: mdbl_indicators_movies(watched_info, since)
		if refresh_episodes_watched: mdbl_indicators_tv(watched_info, since)
	if refresh_movies_paused or refresh_episodes_paused:
		success = 'success'
		progress_info = (mdbl_playback_progress() or {}).get('items', [])
		if refresh_movies_paused: mdbl_progress_movies(progress_info, since)
		if refresh_episodes_paused: mdbl_progress_tv(progress_info, since)
	return success
