# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-02: MyAnimeList lists (Watching / Plan to Watch / Completed / On Hold / Dropped).
#
# The entries come from MAL; the tiles are drawn by the AniList list renderer (indexers/anilist_lists._render), fed
# AniList's media for the same MAL ids. MAL's API returns little art and none of the cour metadata the renderer uses
# (format, start date, per-cour cover), and AniList holds it for every MAL id -- so a MAL list looks and resolves
# exactly like the matching AniList list: same TMDb resolution, same cour labels, same posters.
from modules import kodi_utils

STATUSES = {
	'watching':      'Watching',
	'plan_to_watch': 'Plan to Watch',
	'completed':     'Completed',
	'on_hold':       'On Hold',
	'dropped':       'Dropped',
}


def build_mal_watchlist(params):
	"""Router entry: params carry `status` (a MAL status: watching, plan_to_watch, ...)."""
	from apis.mal_api import mal_user_active, mal_user_list
	from apis.anilist_api import anilist_media_by_mal
	from caches.lists_cache import lists_cache_object
	from indexers.anilist_lists import _render
	if not mal_user_active(): return kodi_utils.notification('MyAnimeList not authorized', 4000)
	status = params.get('status', 'watching')
	if status not in STATUSES: status = 'watching'
	entries = mal_user_list(status)
	mal_ids = [e['mal_id'] for e in entries]
	# The AniList media for a list rarely changes (titles, art, format), so it is cached on the exact id set: the same
	# list re-renders from cache, and any change to the list asks again.
	key = 'mal_wl_media_%s_%s' % (status, abs(hash(tuple(mal_ids))))
	media = lists_cache_object(lambda _ids: {str(k): v for k, v in anilist_media_by_mal(_ids).items()}, key, [mal_ids], expiration=24) or {}
	items, missing = [], []
	for e in entries:
		m = media.get(str(e['mal_id']))
		if not m: missing.append(e.get('title') or e['mal_id']); continue
		item = dict(m)
		item['progress'], item['score'] = e.get('num_episodes_watched') or 0, e.get('score') or 0
		items.append(item)
	if missing: kodi_utils.logger('MAL lists', '%s: %d entr%s not on AniList, not shown: %s'
		% (status, len(missing), 'y' if len(missing) == 1 else 'ies', ', '.join(str(x) for x in missing[:10])))
	_render(items, 'MyAnimeList: %s' % STATUSES[status],
			mode_for_next='mal.list.build_mal_watchlist',
			params={'mode': 'mal.list.build_mal_watchlist', 'status': status},
			page_no=1, has_next=False)
