# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-02: warm the next page of a catalogue list after this one is on screen.
#
# Next Page on a TMDb / Trakt catalogue cost ~1.2 s: one list call plus ~20 cold TMDb detail calls, all before the
# directory could be delivered. A page whose list response and metas are already cached builds in ~50 ms. So while a
# page is built, fetch_list records how to get the NEXT page's ids (queue); deadlight.py calls run() once routing() has
# returned -- endOfDirectory has already delivered the list, as with the rating backfills -- and run() makes the same
# list call (filling the lists cache) and the same tvshow_meta / movie_meta calls (filling the meta cache).
#
# Only in-addon browsing: never on a widget call (widgets load in bursts, see metadata.flush_rating_backfills), never for
# searches (their art is deferred for the whole process) or random lists. Rating backfills the warm-up would trigger are
# queued and dropped, not run: the metas keep their stale stamps, so the backfills queue again when the page is
# actually opened -- a page nobody opens spends no OMDb / AniList quota.
_PENDING = None

def queue(media_type, id_type, fetch_ids, **meta_kwargs):
	"""fetch_ids() -> the next page's ids, exactly as fetch_list would build self.list for it."""
	global _PENDING
	_PENDING = (media_type, id_type, fetch_ids, meta_kwargs)

def run():
	global _PENDING
	pending, _PENDING = _PENDING, None
	if not pending: return
	import time
	from modules import kodi_utils, settings
	if kodi_utils.external(): return
	media_type, id_type, fetch_ids, meta_kwargs = pending
	monitor = kodi_utils.kodi_monitor()
	if monitor.abortRequested(): return
	from modules import metadata
	from modules.utils import get_datetime, get_current_timestamp, TaskPool
	start = time.time()
	metadata._DEFERRED = []   # swallow the rating backfills; see the note above
	try:
		ids = [i for i in (fetch_ids() or []) if i]
		if not ids: return
		function = metadata.tvshow_meta if media_type == 'tvshow' else metadata.movie_meta
		api_key, mpaa_region = settings.tmdb_api_key(), settings.mpaa_region()
		current_date, current_time = get_datetime(), get_current_timestamp()
		def _warm(_id):
			if monitor.abortRequested(): return
			function(id_type, _id, api_key, mpaa_region, current_date, current_time, **meta_kwargs)
		[i.join() for i in TaskPool().tasks(_warm, ids, min(len(ids), 6))]
		kodi_utils.logger('page prefetch', '%s: %d titles in %.2f s' % (media_type, len(ids), time.time() - start))
	except Exception as e: kodi_utils.logger('page prefetch', 'failed: %s' % e)
	finally: metadata._DEFERRED = None
