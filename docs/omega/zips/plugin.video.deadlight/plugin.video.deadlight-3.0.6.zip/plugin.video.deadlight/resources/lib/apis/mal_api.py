# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-02: MyAnimeList account -- progress push after playback and on season marks.
#
# Mirrors the AniList push (apis/anilist_api.anilist_set_progress, player._anilist_scrobble). The cour and the
# cour-relative episode come from caches.fribb_mappings.find_cour_by_tmdb_coords, which returns the MAL id beside
# the AniList one, so MAL needs no mapping of its own.
#
# Auth: OAuth2 with PKCE against a client the USER registers at myanimelist.net/apiconfig (type "other", which has
# no secret; Redirect URL exactly http://localhost). MAL only supports the "plain" PKCE method, so the challenge IS
# the verifier. MAL has no PIN page and no device code: after approving, the browser is sent to
# http://localhost/?code=...&state=... and shows an error page -- the user copies that address back into Kodi.
# Access and refresh tokens both live 31 days (expires_in is honoured rather than assumed).
#
# Docs: https://myanimelist.net/blog.php?eid=835707 (OAuth), https://myanimelist.net/apiconfig/references/api/v2

import secrets
import time
from urllib.parse import urlparse, parse_qs, urlencode

from caches.lists_cache import lists_cache_object
from caches.settings_cache import get_setting, set_setting
from modules.kodi_utils import make_session, logger, notification, kodi_dialog, qr_dialog

_API_URL = 'https://api.myanimelist.net/v2/%s'
_AUTHORIZE_URL = 'https://myanimelist.net/v1/oauth2/authorize'
_TOKEN_URL = 'https://myanimelist.net/v1/oauth2/token'
_REDIRECT_URI = 'http://localhost'
_APP_REGISTER_URL = 'https://myanimelist.net/apiconfig'
_REFRESH_BEFORE = 3 * 86400       # refresh when fewer than 3 days are left
_EPISODE_COUNT_CACHE_HOURS = 720
STATUSES = ('watching', 'completed', 'on_hold', 'dropped', 'plan_to_watch')

session = make_session('https://api.myanimelist.net')


def _setting(name):
	val = (get_setting('deadlight.mal.%s' % name, '') or '').strip()
	return val if val and val != 'empty_setting' else ''


def mal_user_active():
	return bool(_setting('token'))


def _store_tokens(tokens, created_at):
	set_setting('mal.token', tokens['access_token'])
	if tokens.get('refresh_token'): set_setting('mal.refresh', tokens['refresh_token'])
	try: set_setting('mal.expires', str(int(created_at) + int(tokens.get('expires_in') or 0)))
	except (TypeError, ValueError): pass


def _token_request(data):
	"""POST to the token endpoint (form-encoded, per MAL). Returns the token dict or None."""
	try:
		r = session.post(_TOKEN_URL, data=data, timeout=20)
		body = r.json() if 'json' in r.headers.get('Content-Type', '') else {}
		if r.status_code != 200 or 'access_token' not in body:
			# MAL's own wording: 'invalid_grant' = code stale / already spent or verifier mismatch,
			# 'invalid_client' = wrong Client ID, 'invalid_request' often = redirect_uri differs.
			logger('MAL: token request failed', '%s %s' % (r.status_code, str(body or r.text)[:200]))
			return None
		return body
	except Exception as e:
		logger('MAL: token request error', str(e))
		return None


def mal_refresh():
	"""Trade the refresh token for a new pair. Silent on failure; False leaves the old token in place."""
	client_id, refresh_tok = _setting('client_id'), _setting('refresh')
	if not client_id or not refresh_tok: return False
	created_at = time.time()
	tokens = _token_request({'client_id': client_id, 'grant_type': 'refresh_token', 'refresh_token': refresh_tok})
	if not tokens: return False
	_store_tokens(tokens, created_at)
	logger('MAL', 'token refreshed')
	return True


def _ensure_fresh():
	try: expires = float(_setting('expires') or 0)
	except ValueError: expires = 0
	if expires and expires - time.time() < _REFRESH_BEFORE: mal_refresh()


def call_mal(path, method='get', params=None, data=None, auth=True):
	"""One MAL API call. Returns the parsed JSON, or None. A 401 gets one refresh and one retry."""
	if auth:
		if not mal_user_active(): return None
		_ensure_fresh()
	for attempt in (1, 2):
		headers = {'Authorization': 'Bearer %s' % _setting('token')} if auth else {'X-MAL-CLIENT-ID': _setting('client_id')}
		try:
			r = session.request(method, _API_URL % path, params=params, data=data, headers=headers, timeout=20)
		except Exception as e:
			logger('MAL %s %s' % (method.upper(), path), str(e)); return None
		if r.status_code == 401 and auth and attempt == 1 and mal_refresh(): continue
		if not r.ok:
			logger('MAL %s %s' % (method.upper(), path), 'HTTP %s: %s' % (r.status_code, r.text[:200]))
			return None
		try: return r.json()
		except Exception: return {}
	return None


def mal_episode_count(mal_id):
	"""Total episodes of a MAL entry, or None. 0 from MAL means 'unknown / still airing' and is returned as None."""
	try: mal_id = int(mal_id)
	except (TypeError, ValueError): return None
	def _fetch(_dummy):
		res = call_mal('anime/%d' % mal_id, params={'fields': 'num_episodes'})
		if res is None: return {}   # LOCAL PATCH 2026-10-03 (Batch 3): see anilist_episode_count
		return {'episodes': res.get('num_episodes') or None}
	try:
		return (lists_cache_object(_fetch, 'mal_epcount_%s' % mal_id, 1, expiration=_EPISODE_COUNT_CACHE_HOURS) or {}).get('episodes')
	except Exception:
		return None


def mal_list_status(mal_id):
	"""This user's entry for one anime: {'status', 'num_episodes_watched', ...} or {} when not on the list. None on error."""
	res = call_mal('anime/%d' % int(mal_id), params={'fields': 'my_list_status,num_episodes'})
	if res is None: return None
	return res.get('my_list_status') or {}


def mal_set_progress(mal_id, progress, status=None, raise_only=False):
	"""Set the watched-episode count on a MAL entry. Returns True on success (or when nothing needed changing).

	status=None picks it like anilist_set_progress: completed once progress reaches the entry's episode count,
	watching otherwise, plan_to_watch for 0. An unknown count (airing) stays watching -- understating progress is
	recoverable, marking a show complete early is not.

	raise_only=True (playback): read the entry first and skip when it already has this many episodes or more, so
	rewatching episode 3 of a finished cour does not drop it to 'watching 3/12'. Season marks pass False.
	"""
	if not mal_user_active(): return False
	try: mal_id, progress = int(mal_id), int(progress)
	except (TypeError, ValueError): return False
	if progress < 0: return False
	total = mal_episode_count(mal_id) if progress else None
	# A cour-relative episode past the entry's own length means the cour mapping is wrong, not that MAL is short:
	# Bungou Stray Dogs S1E30 lands in the 12-episode 2nd Season as 'episode 18', because Fribb has no boundaries for
	# seasons 3-5 inside TMDb's one flat season. Writing it would claim episodes of the wrong entry.
	if total and progress > int(total):
		logger('MAL progress', 'anime %s: ep %s is past its %s episodes - cour mapping off, not sent' % (mal_id, progress, total))
		return False
	if raise_only:
		current = mal_list_status(mal_id)
		if current is None: return False
		if (current.get('num_episodes_watched') or 0) >= progress:
			logger('MAL progress', 'anime %s: already at ep %s (%s), not lowering to %s'
					% (mal_id, current.get('num_episodes_watched'), current.get('status'), progress))
			return True
	if status is None:
		if progress == 0: status = 'plan_to_watch'
		else: status = 'completed' if (total and progress >= int(total)) else 'watching'
	res = call_mal('anime/%d/my_list_status' % mal_id, method='patch', data={'status': status, 'num_watched_episodes': progress})
	if res is not None:
		logger('MAL progress', 'anime %s -> ep %s (%s)' % (mal_id, res.get('num_episodes_watched', progress), res.get('status', status)))
		clear_mal_lists_cache()
	return res is not None


# ---- lists and the list manager -------------------------------------------------------------------------------
# MAL has no activity endpoint to poll (AniListMonitor's Viewer.updatedAt has no MAL twin), so list reads are cached
# for 30 minutes and dropped at once after any change made here; edits on the MAL site show within half an hour.
_LIST_PREFIX = 'mal_wl_'
_LIST_CACHE_HOURS = 0.5


def clear_mal_lists_cache():
	try:
		from caches.base_cache import connect_database
		dbcon = connect_database('lists_db')
		dbcon.execute("DELETE FROM lists WHERE id LIKE '%s%%'" % _LIST_PREFIX)
	except Exception as e: logger('MAL', 'list cache clear failed: %s' % e)


def mal_user_list(status):
	"""[{'mal_id', 'status', 'num_episodes_watched', 'score', 'updated_at'}] for one status, most recently updated
	first. Follows MAL's paging (up to 1000 per page)."""
	if status not in STATUSES or not mal_user_active(): return []
	def _fetch(_status):
		out, offset = [], 0
		while True:
			res = call_mal('users/@me/animelist', params={'status': _status, 'fields': 'list_status', 'sort': 'list_updated_at',
				'limit': 1000, 'offset': offset, 'nsfw': 'true'})
			if res is None: return None
			for row in res.get('data') or []:
				node, ls = row.get('node') or {}, row.get('list_status') or {}
				if node.get('id'): out.append({'mal_id': node['id'], 'title': node.get('title'), 'status': ls.get('status'),
					'num_episodes_watched': ls.get('num_episodes_watched') or 0, 'score': ls.get('score') or 0})
			if not (res.get('paging') or {}).get('next'): return out
			offset += 1000
	return lists_cache_object(_fetch, _LIST_PREFIX + status, status, expiration=_LIST_CACHE_HOURS) or []


def mal_set_status(mal_id, status, rewatching=False):
	"""status in STATUSES. MAL has no 'rewatching' status: it is completed plus is_rewatching, so rewatching=True sends
	that. Completed also fills in the episode count when MAL knows it, so the entry does not read 'completed, 0 eps'."""
	if status not in STATUSES or not mal_user_active(): return False
	data = {'status': status, 'is_rewatching': 'true' if rewatching else 'false'}
	if status == 'completed':
		total = mal_episode_count(mal_id)
		if total: data['num_watched_episodes'] = int(total)
	res = call_mal('anime/%d/my_list_status' % int(mal_id), method='patch', data=data)
	if res is not None: clear_mal_lists_cache()
	return res is not None


def mal_set_score(mal_id, score):
	"""score 1-10, or 0 to remove it."""
	if not mal_user_active(): return False
	res = call_mal('anime/%d/my_list_status' % int(mal_id), method='patch', data={'score': max(0, min(10, int(score)))})
	if res is not None: clear_mal_lists_cache()
	return res is not None


def mal_delete_entry(mal_id):
	"""Remove the anime from the list. The manager only offers this for an entry that is on the list."""
	if not mal_user_active(): return False
	res = call_mal('anime/%d/my_list_status' % int(mal_id), method='delete')
	clear_mal_lists_cache()
	return res is not None


def _code_from_paste(pasted, expected_state):
	"""The authorization code from whatever was pasted: the full redirected address, or just the code."""
	pasted = (pasted or '').strip()
	if not pasted: return None, 'nothing pasted'
	if '://' in pasted or pasted.startswith('localhost') or 'code=' in pasted:
		query = parse_qs(urlparse(pasted if '://' in pasted else 'http://' + pasted.lstrip('?')).query)
		if 'error' in query: return None, 'MAL said: %s' % query['error'][0]
		if query.get('state', [expected_state])[0] != expected_state: return None, 'that address is from an older login attempt'
		code = (query.get('code') or [''])[0]
		return (code, None) if code else (None, 'no code in that address')
	return pasted, None


def mal_authenticate(dummy=''):
	"""Authorise against the user's own MAL client. Called from the settings Authorize row."""
	client_id = _setting('client_id')
	if not client_id:
		qr_dialog('MAL Authorize', _APP_REGISTER_URL,
			'[B]Step 1:[/B] Scan the [B]QR code[/B] or open [B]%s[/B] and create an ID (App Type: [B]other[/B]).[CR]'
			'[B]Step 2:[/B] Set its [B]App Redirect URL[/B] to exactly:   [COLOR gold]%s[/COLOR][CR]'
			'[B]Step 3:[/B] Press [B]Back[/B], then enter its Client ID.' % (_APP_REGISTER_URL, _REDIRECT_URI))
		client_id = (kodi_dialog().input('MAL Client ID') or '').strip()
		if not client_id: return notification('MAL Authorize Cancelled - no Client ID', 4000)
		set_setting('mal.client_id', client_id)
	# PKCE 'plain': the challenge is the verifier itself (43-128 unreserved characters).
	verifier, state = secrets.token_urlsafe(96)[:128], secrets.token_urlsafe(12)
	auth_url = '%s?%s' % (_AUTHORIZE_URL, urlencode({'response_type': 'code', 'client_id': client_id, 'state': state,
		'redirect_uri': _REDIRECT_URI, 'code_challenge': verifier, 'code_challenge_method': 'plain'}))
	try:
		from modules.utils import copy2clip
		copy2clip(auth_url)
	except Exception: pass
	if not qr_dialog('MAL Authorize', auth_url,
		'[B]Step 1:[/B] Scan the [B]QR code[/B], or open the link (copied to your clipboard).[CR]'
		'[B]Step 2:[/B] Approve access. Your browser then opens [COLOR gold]%s/?code=...[/COLOR] and shows an error page - that is expected.[CR]'
		'[B]Step 3:[/B] Copy that page\'s [B]whole address[/B], press [B]Back[/B], and paste it.' % _REDIRECT_URI):
		return notification('MAL Authorize timed out', 4000)
	code, why = _code_from_paste(kodi_dialog().input('Paste the address MAL sent you to'), state)
	if not code: return notification('MAL Authorize Cancelled - %s' % why, 5000)
	created_at = time.time()
	tokens = _token_request({'client_id': client_id, 'grant_type': 'authorization_code', 'code': code,
		'code_verifier': verifier, 'redirect_uri': _REDIRECT_URI})
	if not tokens:
		return notification('MAL Authorize Failed - check the Client ID and that the Redirect URL is exactly %s' % _REDIRECT_URI, 7000)
	_store_tokens(tokens, created_at)
	# Verify rather than trust the exchange -- confirms the token reaches the API.
	me = call_mal('users/@me') or {}
	if not me.get('name'):
		for name in ('token', 'refresh', 'expires'): set_setting('mal.%s' % name, 'empty_setting')
		return notification('MAL Authorize Failed - token did not authenticate.', 6000)
	set_setting('mal.user', me['name'])
	notification('MAL Authorized as %s' % me['name'], 5000)
	return True


def mal_revoke_authentication(dummy=''):
	"""Signs this install out. The Client ID is kept, so signing in again skips the app step."""
	for name in ('token', 'refresh', 'expires', 'user'):
		set_setting('mal.%s' % name, 'empty_setting')
	notification('MAL Authorization Revoked', 4000)
	return True
