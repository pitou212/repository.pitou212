# -*- coding: utf-8 -*-
from windows.base_window import BaseDialog
# from modules.kodi_utils import logger

# LOCAL PATCH 2026-09-26: open straight on a category. Positions in the category list (control 2000)
# of settings_manager.xml, whose items carry no visibility conditions, so a position never shifts.
# Keep in step with that list's order if a category is added or moved.
# LOCAL PATCH 2026-10-01: every category, by the category ids of resources/settings.xml -- the window is DeadLight's
# settings screen again, and callers name a category the way they did for Kodi's dialog.
CATEGORY_POSITIONS = {'general': 0, 'features': 1, 'content': 2, 'interface': 3, 'accounts': 4, 'debrid': 5,
					  'external_scrapers': 6, 'direct_providers': 7, 'results': 8, 'playback': 9}
# LOCAL PATCH 2026-10-01: dividers are headings, not settings -- a Kodi list cannot make one item unfocusable, so the
# highlight is stepped past them in the direction it was going (up / down, page up / down, mouse wheel).
SETTINGS_LIST = 2100
MOVE_UP, MOVE_DOWN = (3, 5, 104), (4, 6, 105)

class SettingsManager(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.control_id = None
		self.start_position = CATEGORY_POSITIONS.get(kwargs.get('category'))

	def onInit(self):
		# Runs after the XML's <onload>SetFocus(2000,0,absolute)</onload>, so this wins.
		if self.start_position is not None: self.execute_code('SetFocus(2000,%d,absolute)' % self.start_position)

	def run(self):
		self.doModal()
		self.clearProperties()

	def onAction(self, action):
		if action in self.closing_actions: return self.close()
		if self.getFocusId() != SETTINGS_LIST: return
		if action in MOVE_UP: self.skip_separator(-1)
		elif action in MOVE_DOWN: self.skip_separator(1)

	def skip_separator(self, step):
		# Kodi has already moved the list when this runs. Turn back at either end (every category opens on a divider);
		# a few tries in case rows hidden by their own conditions leave two dividers touching.
		for _ in range(3):
			if self.get_infolabel('Container(%d).ListItem.Property(setting_type)' % SETTINGS_LIST) != 'separator': return
			try: position, total = int(self.get_infolabel('Container(%d).CurrentItem' % SETTINGS_LIST)), int(self.get_infolabel('Container(%d).NumItems' % SETTINGS_LIST))
			except ValueError: return
			if not 1 <= position + step <= total: step = -step
			self.execute_code('Control.Move(%d,%d)' % (SETTINGS_LIST, step), True)

class SettingsManagerFolders(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)

	def run(self):
		self.doModal()
		self.clearProperties()
