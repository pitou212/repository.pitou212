# -*- coding: utf-8 -*-
import sys
import json
import random
from datetime import date
from modules.sources import Sources
from modules.settings import date_offset, watched_indicators, ignore_articles, playback_key, max_threads
from modules.metadata import episodes_meta, all_episodes_meta
from modules.watched_status import get_watched_status_episode, get_next_episodes, get_hidden_progress_items, watched_info_episode, get_next
from modules.utils import adjust_premiered_date, adjust_premiered_datetime, get_datetime, title_key, TaskPool
from modules import kodi_utils
# logger = kodi_utils.logger

def _grace(dt):
	"""Air datetime plus the user's grace period. See settings.air_grace_hours.

	Trakt reports the real drop time, which for Paramount+ / Netflix can be the small hours
	local -- long before anything is findable. This shifts only the AIRED decision; the
	displayed air date is untouched.
	"""
	try:
		from modules.settings import air_grace_hours
		hours = air_grace_hours()
		if not hours or not dt: return dt
		from datetime import timedelta
		return dt + timedelta(hours=hours)
	except Exception: return dt


# LOCAL PATCH 2026-09-26: a next episode from the SAME DROP as the one playing is out.
#
# The aired test below assumes 20:00 + offset + grace for a date-only TMDb premiere, which
# suits a weekly evening broadcast and not a season released at once. Bakaiti S2 (all six
# episodes dated 2026-09-25) was being watched at 08:50 on 09-26 while S02E02 counted as
# unaired until 12:00 -- 20:00 + 10h offset + 6h grace -- so no next episode was offered.
# An episode dated on or before the one already playing cannot still be unaired, so the
# guard stands down for it. Raw 'YYYY-MM-DD' strings, compared before any offset: two
# episodes of one drop share the raw date whatever the timezone. A weekly show's next
# episode carries a LATER date and keeps the guard exactly as it was.
def _same_drop(meta, current_season, current_episode, next_premiered):
	try:
		if not next_premiered: return False
		current = next((i for i in (episodes_meta(current_season, meta) or []) if i['episode'] == current_episode), None)
		current_premiered = (current or {}).get('premiered') or ''
		return bool(current_premiered) and next_premiered[:10] <= current_premiered[:10]
	except Exception: return False


# LOCAL PATCH 2026-08-25: side-effect-free "is there a next episode to play?" probe.
# EpisodeTools.next_episode_info() answers the same question but MUTATES self.meta
# (it rewrites season/episode/plot/rootname for the upcoming episode), so it cannot
# be called speculatively just to look. This mirrors its three no-next-episode exits:
#   * the next season has no episode data      -> past the last season
#   * the episode isn't in that season's data  -> series finale
#   * the episode hasn't aired yet             -> next-not-yet-aired
# Used by DeadLightPlayer._check_skip_segments to decide whether to stop at credits.
# Fails OPEN (returns True) so any error leaves playback untouched.
def next_episode_available(meta):
	try:
		season_data = meta.get('season_data')
		current_season, current_episode = int(meta.get('season')), int(meta.get('episode'))
		watched_info = watched_info_episode(meta.get('tmdb_id'))
		season, episode = get_next(current_season, current_episode, watched_info, season_data, 0)
		if not season or not episode: return False
		ep_data = episodes_meta(season, meta)
		if not ep_data: return False
		ep_data = next((i for i in ep_data if i['episode'] == episode), None)
		if not ep_data: return False
		adjust_hours, current_date = date_offset(), get_datetime()
		episode_date, _premiered = adjust_premiered_date(ep_data['premiered'], adjust_hours)
		episode_datetime = adjust_premiered_datetime(ep_data['premiered'], adjust_hours)
		current_datetime = get_datetime(dt=True)
		if _same_drop(meta, current_season, current_episode, ep_data['premiered']): return True
		if not episode_date or current_date < episode_date or (episode_datetime and current_datetime < _grace(episode_datetime)):
			return False
		return True
	except Exception:
		return True


class EpisodeTools:
	def __init__(self, meta, nextep_settings=None):
		self.meta = meta
		self.meta_get = self.meta.get
		self.nextep_settings = nextep_settings

	def next_episode_info(self):
		try:
			play_type = self.nextep_settings['play_type']
			season_data = self.meta_get('season_data')
			watch_count = self.meta_get('watch_count')
			current_season, current_episode = int(self.meta_get('season')), int(self.meta_get('episode'))
			watched_info = watched_info_episode(self.meta_get('tmdb_id'))
			season, episode = get_next(current_season, current_episode, watched_info, season_data, 0)
			if not season or not episode: return 'no_next_episode'   # LOCAL PATCH 2026-10-03: get_next now stops at the last listed season
			playcount = get_watched_status_episode(watched_info, (season, episode))
			ep_data = episodes_meta(season, self.meta)
			if not ep_data: return 'no_next_episode'
			ep_data = next((i for i in ep_data if i['episode'] == episode), None)
			if not ep_data: return 'no_next_episode'
			adjust_hours, current_date = date_offset(), get_datetime()
			episode_date, premiered = adjust_premiered_date(ep_data['premiered'], adjust_hours)
			# LOCAL PATCH 2026-07-02: same-day airtime precision — autoplay-next-ep must
			# not fire for a same-day episode until wall-clock passes its assumed airtime.
			episode_datetime = adjust_premiered_datetime(ep_data['premiered'], adjust_hours)
			current_datetime = get_datetime(dt=True)
			# LOCAL PATCH 2026-09-26: see _same_drop.
			if not _same_drop(self.meta, current_season, current_episode, ep_data['premiered']):
				if not episode_date or current_date < episode_date or (episode_datetime and current_datetime < _grace(episode_datetime)): return 'no_next_episode'
			custom_title = self.meta_get('custom_title', None)
			title = custom_title or self.meta_get('title')
			display_name = '%s - %dx%.2d' % (title, int(season), int(episode))
			self.meta.update({'media_type': 'episode', 'rootname': display_name, 'season': season, 'ep_name': ep_data['title'], 'ep_thumb': ep_data.get('thumb', None),
							'episode': episode, 'premiered': premiered, 'plot': ep_data['plot'],
							'episode_type': ep_data.get('episode_type', ''), 'ep_duration': ep_data.get('duration', 0)})
			url_params = {'media_type': 'episode', 'tmdb_id': self.meta_get('tmdb_id'), 'tvshowtitle': self.meta_get('rootname'), 'season': season, 'playcount': playcount,
						'episode': episode, 'background': 'true', 'nextep_settings': self.nextep_settings, 'play_type': play_type, 'watch_count': watch_count,
						'_prefetched_meta': self.meta}
			if play_type == 'autoscrape_nextep': url_params['prescrape'] = 'false'
			if custom_title: url_params['custom_title'] = custom_title
			if 'custom_year' in self.meta: url_params['custom_year'] = self.meta_get('custom_year')
		except: url_params = 'error'
		return self.add_playback_key(url_params)

	def get_random_episode(self, continual=False, first_run=True):
		try:
			adjust_hours, current_date = date_offset(), get_datetime()
			tmdb_id = self.meta_get('tmdb_id')
			tmdb_key = str(tmdb_id)
			ep_meta = all_episodes_meta(self.meta)
			episodes_data = [i for i in ep_meta if i['premiered'] and adjust_premiered_date(i['premiered'], adjust_hours)[0] <= current_date]
			if continual:
				episode_list = []
				try:
					episode_history = json.loads(kodi_utils.get_property('deadlight.random_episode_history'))
					if tmdb_key in episode_history: episode_list = episode_history[tmdb_key]
					else: kodi_utils.set_property('deadlight.random_episode_history', '')
				except: kodi_utils.set_property('deadlight.random_episode_history', '')
				episodes_data = [i for i in episodes_data if not i in episode_list]
				if not episodes_data:
					kodi_utils.set_property('deadlight.random_episode_history', '')
					return self.get_random_episode(continual=True)
			chosen_episode = random.choice(episodes_data)
			if continual:
				episode_list.append(chosen_episode)
				episode_history = {tmdb_key: episode_list}
				kodi_utils.set_property('deadlight.random_episode_history', json.dumps(episode_history))
			title, season, episode = self.meta['title'], int(chosen_episode['season']), int(chosen_episode['episode'])
			watched_info = watched_info_episode(tmdb_id)
			playcount = get_watched_status_episode(watched_info, (season, episode))
			query = title + ' S%.2dE%.2d' % (season, episode)
			display_name = '%s - %dx%.2d' % (title, season, episode)
			ep_name, plot = chosen_episode['title'], chosen_episode['plot']
			ep_thumb = chosen_episode.get('thumb', None)
			try: premiered = adjust_premiered_date(chosen_episode['premiered'], adjust_hours)[1]
			except: premiered = chosen_episode['premiered']
			self.meta.update({'media_type': 'episode', 'rootname': display_name, 'season': season, 'ep_name': ep_name, 'ep_thumb': ep_thumb,
							'episode': episode, 'premiered': premiered, 'plot': plot, 'ep_duration': chosen_episode.get('duration', 0)})
			url_params = {'media_type': 'episode', 'tmdb_id': tmdb_id, 'tvshowtitle': self.meta_get('rootname'), 'season': season, 'episode': episode,
						'playcount': playcount, 'autoplay': 'true'}
			if continual: url_params['random_continual'] = 'true'
			else: url_params['random'] = 'true'
			if not first_run:
				url_params['background'] = 'true'
				url_params['play_type'] = 'random_continual'
		except: url_params = 'error'
		return self.add_playback_key(url_params)

	def play_random(self):
		url_params = self.get_random_episode()
		if url_params == 'error': return kodi_utils.notification('Single Random Play Error', 3000)
		return Sources().playback_prep(url_params)

	def play_random_continual(self, first_run=True):
		url_params = self.get_random_episode(continual=True, first_run=first_run)
		if url_params == 'error': return kodi_utils.notification('Continual Random Play Error', 3000)
		return Sources().playback_prep(url_params)

	def auto_nextep(self):
		# LOCAL PATCH 2026-09-12: report whether an episode actually followed. The result was
		# discarded before, so monitor() broke its playback loop even when nothing was handed
		# off -- see player.run_next_ep. 'error' reports False alongside 'no_next_episode':
		# the notification already tells the user, and keeping the loop alive lets
		# skipsegment.stop_at_credits_no_next still stop at the credits rather than having
		# them run out in silence.
		url_params = self.next_episode_info()
		if url_params == 'error':
			kodi_utils.notification('Next Episode Error', 3000)
			return False
		elif url_params == 'no_next_episode': return False
		Sources().playback_prep(url_params)
		return True

	def add_playback_key(self, url_params):
		_key = playback_key()
		url_params[_key] = _key
		return url_params

def build_next_episode_manager():
	def _process(item):
		try:
			listitem = make_listitem()
			tmdb_id, title = item['media_ids']['tmdb'], item['title']
			if int(tmdb_id) in hidden_list: display, action = 'Undrop [B]%s[/B] [COLOR=red][DROPPED][/COLOR]' % title, 'undrop'
			else: display, action = 'Drop [B]%s[/B]' % title, 'drop'
			url_params = {'mode': mode, 'action': action, 'media_type': 'shows', 'media_id': tmdb_id, 'section': 'dropped'}
			url = build_url(url_params)
			listitem.setLabel(display)
			listitem.setArt({'poster': icon, 'fanart': addon_fanart, 'icon': icon})
			info_tag = listitem.getVideoInfoTag(True)
			info_tag.setPlot(' ')
			append({'listitem': (url, listitem, False), 'sort_title': title})
		except: pass
	handle = int(sys.argv[1])
	make_listitem, build_url, addon_fanart = kodi_utils.make_listitem, kodi_utils.build_url, kodi_utils.get_addon_fanart()
	list_items = []
	append = list_items.append
	indicators = watched_indicators()
	show_list = get_next_episodes(0)
	hidden_list = get_hidden_progress_items(indicators)
	if indicators == 0: icon, mode = kodi_utils.get_icon('folder'), 'hide_unhide_progress_items'
	else: icon, mode = kodi_utils.get_icon('trakt'), 'trakt.hide_unhide_progress_items'
	threads = TaskPool().tasks(_process, show_list, min(len(show_list), max_threads()))
	[i.join() for i in threads]
	item_list = sorted(list_items, key=lambda k: (title_key(k['sort_title'], ignore_articles())), reverse=False)
	item_list = [i['listitem'] for i in item_list]
	kodi_utils.add_items(handle, item_list)
	kodi_utils.set_content(handle, '')
	kodi_utils.end_directory(handle, cacheToDisc=False)
	kodi_utils.set_view_mode('view.main', '')

def single_last_watched_episodes(data):
	seen = set()
	seen_add = seen.add
	return sorted([i for i in sorted(data, key=lambda x: (x['last_played'], x['media_ids']['tmdb'], x['season'], x['episode']), reverse=True)
				if not (i['media_ids']['tmdb'] in seen or seen_add(i['media_ids']['tmdb']))],
				key=lambda x: (x['last_played'], x['media_ids']['tmdb'], x['season'], x['episode']), reverse=True)
