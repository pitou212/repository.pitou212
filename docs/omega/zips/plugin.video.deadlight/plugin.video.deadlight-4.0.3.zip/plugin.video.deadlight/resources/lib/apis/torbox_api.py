# -*- coding: utf-8 -*-
from threading import Thread
from urllib.parse import urlencode
from caches.settings_cache import get_setting, set_setting
from caches.main_cache import cache_object, main_cache
from modules.source_utils import supported_video_extensions, seas_ep_filter, extras, pick_episode_files, split_disc
from modules.kodi_utils import make_session, kodi_dialog, ok_dialog, notification, confirm_dialog
# from modules.kodi_utils import logger

session = make_session('https://api.torbox.app/v1/api/')

class TorBoxAPI:
	def __init__(self):
		self.token = get_setting('deadlight.tb.token')

	def _get(self, url, data={}):
		if self.token in ('empty_setting', ''): return None
		headers = {'Authorization': 'Bearer %s' % self.token}
		url = 'https://api.torbox.app/v1/api/' + url
		response = session.get(url, params=data, headers=headers, timeout=20)
		try: return response.json()
		except ValueError: return None

	def _post(self, url, params=None, json=None, data=None):
		if self.token in ('empty_setting', '') and not 'token' in url: return None
		headers = {'Authorization': 'Bearer %s' % self.token}
		url = 'https://api.torbox.app/v1/api/' + url
		response = session.post(url, params=params, json=json, data=data, headers=headers, timeout=20)
		try: return response.json()
		except ValueError: return None

	def add_headers_to_url(self, url):
		return url + '|' + urlencode({'User-Agent': 'Mozilla/5.0'})

	def account_info(self):
		return self._get('user/me')

	def user_cloud(self):
		string = 'tb_user_cloud'
		url = 'torrents/mylist'
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_usenet(self):
		string = 'tb_user_cloud_usenet'
		url = 'usenet/mylist'
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_info(self, request_id=''):
		string = 'tb_user_cloud_%s' % request_id
		url = 'torrents/mylist?id=%s' % request_id
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_info_usenet(self, request_id=''):
		string = 'tb_user_cloud_usenet_%s' % request_id
		url = 'usenet/mylist?id=%s' % request_id
		return cache_object(self._get, string, url, False, 0.03)


	def torrent_info(self, request_id=''):
		url = 'torrents/mylist?id=%s' % request_id
		return self._get(url)

	def delete_torrent(self, request_id=''):
		# LOCAL PATCH 2026-08-31: the id must go out as an INTEGER. Internal callers hand it
		# straight from TorBox's own json and work; the context-menu path arrives through the
		# plugin url, where every value is a string, and the delete then silently did nothing.
		# browse_tb_cloud already does int(folder_id) for exactly this reason.
		try: request_id = int(request_id)
		except (TypeError, ValueError): pass
		data = {'torrent_id': request_id, 'operation': 'delete'}
		return self._post('torrents/controltorrent', json=data)

	def delete_usenet(self, request_id=''):
		# LOCAL PATCH 2026-08-31: the id must go out as an INTEGER. Internal callers hand it
		# straight from TorBox's own json and work; the context-menu path arrives through the
		# plugin url, where every value is a string, and the delete then silently did nothing.
		# browse_tb_cloud already does int(folder_id) for exactly this reason.
		try: request_id = int(request_id)
		except (TypeError, ValueError): pass
		data = {'usenet_id': request_id, 'operation': 'delete'}
		return self._post('usenet/controlusenetdownload', json=data)

	def unrestrict_link(self, file_id):
		torrent_id, file_id = file_id.split(',')
		data = {'token': self.token, 'torrent_id': torrent_id, 'file_id': file_id}
		try: return self._get('torrents/requestdl', data=data)['data']
		except: return None

	def unrestrict_usenet(self, file_id):
		usenet_id, file_id = file_id.split(',')
		params = {'token': self.token, 'usenet_id': usenet_id, 'file_id': file_id, 'user_ip': True}
		try: return self._get('usenet/requestdl', data=params)['data']
		except: return None

	def add_magnet(self, magnet):
		data = {'magnet': magnet, 'seed': 3, 'allow_zip': False}
		return self._post('torrents/createtorrent', data=data)

	def check_cache_single(self, _hash):
		return self._get('torrents/checkcached', data={'hash': _hash, 'format': 'list'})

	def check_cache(self, hashlist):
		# LOCAL PATCH 2026-09-22: list_files=true adds a `files` array to every CACHED entry --
		# per-file id, name, short_name and real size. Without it an entry is only
		# {name, size, hash}, where size is the TORRENT total, which is the number the
		# provider already published, so the check told us nothing new about a pack's contents.
		# Measured 2026-09-22 over a 60-hash batch (9 cached): 0.43s/1.9KB without, 0.45s/103KB
		# with, describing 317 files. The latency difference is inside the noise; it is payload,
		# not time. Uncached hashes are absent from the response either way.
		data = {'hashes': hashlist}
		return self._post('torrents/checkcached', params={'format': 'list', 'list_files': 'true'}, json=data)

	def create_transfer(self, magnet_url):
		result = self.add_magnet(magnet_url)
		if not result or not result.get('success'): return ''
		return result['data'].get('torrent_id', '')

	# LOCAL PATCH 2026-08-27: ep_candidates carries the alternate numberings an anime
	# release may use for this episode (see source_utils.anime_episode_candidates).
	# Empty/None for everything else, so non-anime resolution is byte-for-byte as before.
	def resolve_magnet(self, magnet_url, info_hash, store_to_cloud, title, season, episode, ep_candidates=None):
		# LOCAL PATCH 2026-10-15: say why a resolve gave up, as Real-Debrid's does (2026-10-11). Every exit below returned
		# None silently -- and with RD premium gone TorBox carries every play.
		def _why(reason):
			try:
				from modules.kodi_utils import logger
				logger('TorBox resolve', '%s S%sE%s %s: %s' % (info_hash, season, episode, title, reason))
				from modules.kodi_utils import set_property   # LOCAL PATCH 2026-10-15: shown on screen (sources.RESOLVE_REASON_PROP)
				set_property('deadlight.resolve_reason', 'TorBox: %s' % reason)
			except Exception: pass
		try:
			file_url, match, torrent_id = None, False, None
			extensions = supported_video_extensions()
			extras_filter = extras()
			extras_filtering_list = tuple(i for i in extras_filter if not i in title.lower())
			torrent = self.add_magnet(magnet_url)
			if not torrent['success']:
				_why('add failed: %s' % (torrent.get('error') or torrent.get('detail')))
				return None
			torrent_id = torrent['data']['torrent_id']
			torrent_files = self.torrent_info(torrent_id)
			files = torrent_files['data']['files']
			selected_files = [{'url': '%d,%d' % (torrent_id, item['id']), 'filename': item['short_name'], 'size': item['size']} \
							for item in files if item['short_name'].lower().endswith(tuple(extensions))]
			if not selected_files:
				_why('no video files among %d' % len(files))
				return None
			if season:
				selected_files, _matched = pick_episode_files(selected_files, season, episode, 'filename', ep_candidates, title)
			else:
				if self._m2ts_check(selected_files):
					_why('disc release split over streams')
					return None
				selected_files = [i for i in selected_files if not any(x in i['filename'] for x in extras_filtering_list)]
				selected_files.sort(key=lambda k: k['size'], reverse=True)
			if not selected_files:
				_why('no file for this episode' if season else 'only extras left')
				return None
			file_key = selected_files[0]['url']
			file_url = self.unrestrict_link(file_key)
			if not store_to_cloud: Thread(target=self.delete_torrent, args=(torrent_id,)).start()
			return file_url
		except Exception as e:
			_why('failed: %r' % e)
			if torrent_id: self.delete_torrent(torrent_id)
			return None

	def display_magnet_pack(self, magnet_url, info_hash):
		from modules.source_utils import supported_video_extensions
		try:
			torrent_id = None
			extensions = supported_video_extensions()
			torrent = self.add_magnet(magnet_url)
			if not torrent['success']: return None
			torrent_id = torrent['data']['torrent_id']
			torrent_files = self.torrent_info(torrent_id)
			files = torrent_files['data']['files']
			torrent_files = [{'link': '%d,%d' % (torrent_id, item['id']), 'filename': item['short_name'], 'size': item['size']} \
							for item in files if item['short_name'].lower().endswith(tuple(extensions))]
			Thread(target=self.delete_torrent, args=(torrent_id,)).start()
			return torrent_files or None
		except Exception:
			if torrent_id: self.delete_torrent(torrent_id)
			return None

	def _m2ts_check(self, folder_items):
		# LOCAL PATCH 2026-09-29: refuse only a disc whose film may be split over streams (source_utils.split_disc)
		return split_disc([(item['filename'], item['size']) for item in folder_items])

	def auth(self):
		# LOCAL PATCH 2026-09-30: a QR code of TorBox's settings page, where the API key is, before the keyboard
		from modules.kodi_utils import qr_dialog
		if not qr_dialog('TorBox Authorize', 'https://torbox.app/settings',
			'Scan the [B]QR code[/B] or open [B]torbox.app/settings[/B] and copy your [B]API Key[/B].[CR]'
			'Press [B]Back[/B], then enter it.'): return
		api_key = kodi_dialog().input('TorBox API Key:')
		if not api_key: return
		try:
			self.token = api_key
			r = self.account_info()
			customer = r['data']['customer']
			set_setting('tb.token', api_key)
			set_setting('tb.enabled', 'true')
			message = 'Success'
		except: message = 'An Error Occurred'
		ok_dialog(text=message)

	def revoke(self):
		if not confirm_dialog(): return
		set_setting('tb.token', 'empty_setting')
		set_setting('tb.enabled', 'false')
		notification('TorBox Authorization Reset', 3000)

	def refresh_cloud(self):
		"""Repoint the local cache at TorBox's CURRENT list after a delete.

		LOCAL PATCH 2026-08-31: TWO caches sit between a delete and the listing -- this
		addon's maincache row (108s) and TorBox's own server-side list cache. Clearing only
		the first still refetches a possibly stale list, so items you just deleted kept
		showing for up to two minutes. Verified after a bulk delete: the local row still
		held all 8 entries and simply aged out rather than being replaced.

		bypass_cache=true asks TorBox for the real list rather than its cached one. Writing
		the answer straight into the cache leaves the listing correct on the very next draw
		instead of merely empty until the next fetch.
		"""
		self.clear_cache(clear_hashes=False)
		ok = True
		for key, url in (('tb_user_cloud', 'torrents/mylist?bypass_cache=true'),
						('tb_user_cloud_usenet', 'usenet/mylist?bypass_cache=true')):
			try: main_cache.set(key, self._get(url), expiration=0.03)
			except Exception: ok = False
		return ok

	def clear_cache(self, clear_hashes=True):
		try:
			from caches.debrid_cache import debrid_cache
			from caches.base_cache import connect_database
			dbcon = connect_database('maincache_db')
			# USER CLOUD
			try:
				dbcon.execute("""DELETE FROM maincache WHERE id=?""", ('tb_user_cloud',))
				dbcon.execute("""DELETE FROM maincache WHERE id LIKE ?""", ('tb_user_cloud%',))
				user_cloud_success = True
			except: user_cloud_success = False
			# HASH CACHED STATUS
			if clear_hashes:
				try:
					debrid_cache.clear_debrid_results('tb')
					hash_cache_status_success = True
				except: hash_cache_status_success = False
			else: hash_cache_status_success = True
		except: return False
		if False in (user_cloud_success, hash_cache_status_success): return False
		return True

TorBox = TorBoxAPI()

