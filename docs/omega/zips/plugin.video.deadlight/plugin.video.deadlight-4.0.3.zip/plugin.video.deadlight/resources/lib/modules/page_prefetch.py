# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-02: warm the next page of a catalogue list after this one is on screen.
#
# Next Page on a TMDb / Trakt catalogue cost ~1.2 s: one list call plus ~20 cold TMDb detail calls, all before the
# directory could be delivered. A page whose list response and metas are already cached builds in ~50 ms. So while a
# page is built, fetch_list records how to get the NEXT page's ids (queue); deadlight.py calls run() once routing() has
# returned -- endOfDirectory has already delivered the list, as with the rating backfills -- and run() makes the same
# list call (filling the lists cache) and the same tvshow_meta / movie_meta calls (filling the meta cache).
#
# Only in-addon browsing: never on a widget call (widgets load in bursts, see metadata.flush_rating_backfills), never for
# searches (their art is deferred for the whole process) or random lists. Rating backfills the warm-up would trigger are
# queued and dropped, not run: the metas keep their stale stamps, so the backfills queue again when the page is
# actually opened -- a page nobody opens spends no OMDb / AniList quota.
_PENDING = None
_BUSY_PROP = 'deadlight.page_prefetch_busy'   # LOCAL PATCH 2026-10-16: '<start time>' while a prefetch runs, in any process
PROCESS_START = None

def queue(media_type, id_type, fetch_ids, **meta_kwargs):
	"""fetch_ids() -> the next page's ids, exactly as fetch_list would build self.list for it. LOCAL PATCH 2026-10-16:
	media_type 'mixed' (AniList lists: shows and films on one page) -> fetch_ids() gives (media_type, ids) pairs."""
	global _PENDING
	_PENDING = (media_type, id_type, fetch_ids, meta_kwargs)

def run():
	global _PENDING
	pending, _PENDING = _PENDING, None
	if not pending: return
	import time
	from modules import kodi_utils, settings
	if kodi_utils.external(): return
	media_type, id_type, fetch_ids, meta_kwargs = pending
	monitor = kodi_utils.kodi_monitor()
	if monitor.abortRequested(): return
	from modules import metadata
	from modules.utils import get_datetime, get_current_timestamp, TaskPool
	start = time.time()
	kodi_utils.set_property(_BUSY_PROP, '%.3f' % start)
	metadata._DEFERRED = []   # swallow the rating backfills; see the note above
	try:
		ids = [i for i in (fetch_ids() or []) if i]
		if not ids: return
		pairs = ids if media_type == 'mixed' else [(media_type, i) for i in ids]
		if media_type == 'mixed': meta_kwargs = {}   # movie_meta takes no is_anime_list
		api_key, mpaa_region = settings.tmdb_api_key(), settings.mpaa_region()
		current_date, current_time = get_datetime(), get_current_timestamp()
		# LOCAL PATCH 2026-10-16: and the status chip of shows being / been watched -- their full chip asks TVmaze while the
		# row is built (metadata._tv_renewal, two requests a show), which a warm page still waited on: 2.1 s on three of six
		# Trakt pages (log 2026-10-16 21:23). Unwatched shows get the request-free light chip and need nothing here.
		watched = {}
		if any(mt == 'tvshow' for mt, _i in pairs):
			from modules import watched_status
			watched = watched_status.watched_info_tvshow(watched_status.get_database(settings.watched_indicators())) or {}
		def _warm(mt, _id):   # TaskPool unpacks each (media_type, id) pair into the arguments
			if monitor.abortRequested(): return
			function = metadata.tvshow_meta if mt == 'tvshow' else metadata.movie_meta
			meta = function(id_type, _id, api_key, mpaa_region, current_date, current_time, **meta_kwargs)
			# LOCAL PATCH 2026-10-16: unwatched ones too -- their light chip queues a TVmaze lookup (metadata._queue_tvmaze),
			# run below with the other prefetch work instead of being swallowed with the rating backfills
			if mt == 'tvshow' and isinstance(meta, dict): metadata.show_status_props(meta, light=str(meta.get('tmdb_id')) not in watched)
		[i.join() for i in TaskPool().tasks(_warm, pairs, min(len(pairs), 6))]
		tvmaze = [item[0] for item in (metadata._DEFERRED or []) if item[3] == (metadata._tvmaze_backfill,)]
		if tvmaze and not monitor.abortRequested(): [i.join() for i in TaskPool().tasks(metadata._tvmaze_backfill, tvmaze, min(len(tvmaze), 4))]
		kodi_utils.logger('page prefetch', '%s: %d titles in %.2f s' % (media_type, len(ids), time.time() - start))
	except Exception as e: kodi_utils.logger('page prefetch', 'failed: %s' % e)
	finally:
		metadata._DEFERRED = None
		kodi_utils.clear_property(_BUSY_PROP)


# LOCAL PATCH 2026-10-16: one ###page timing### line per catalogue page browsed in the addon, to see where the wait goes:
# from this process's start (Kodi's own interpreter start-up is before it and not counted), the list request, the rows,
# how many titles came from the meta cache (a prefetched page: all of them) and whether a prefetch was still running
# in another process when this page started -- Next clicked before the previous page's prefetch was done.
def mark_start():
	global PROCESS_START
	import time
	PROCESS_START = time.time()

def page_marks():
	"""(now, prefetch busy since or None, meta counts) at the start of a page build."""
	import time
	from modules import kodi_utils
	from modules.metadata import META_COUNTS
	try: busy = float(kodi_utils.get_property(_BUSY_PROP) or 0) or None
	except ValueError: busy = None
	return time.time(), busy, dict(META_COUNTS)

def log_page(media_type, action, page_no, rows, marks, rows_start):
	import time
	from modules import kodi_utils
	from modules.metadata import META_COUNTS
	try:
		t0, busy, counts = marks
		now = time.time()
		cached, fetched = META_COUNTS['cached'] - counts['cached'], META_COUNTS['fetched'] - counts['fetched']
		startup = (' (+%.2f s start-up)' % (t0 - PROCESS_START)) if PROCESS_START else ''
		prefetch = (', a prefetch was still running (%.1f s in)' % (t0 - busy)) if busy else ''
		kodi_utils.logger('page timing', '%s %s p%s: %.2f s%s -- list %.2f s, rows %.2f s; %d rows, %d titles cached / %d from TMDb%s'
			% (media_type, action, page_no, now - t0, startup, (rows_start or now) - t0, now - (rows_start or now), rows, cached, fetched, prefetch))
	except Exception: pass
