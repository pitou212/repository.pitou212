# -*- coding: utf-8 -*-
"""IntroDB API client. Fetches intro/outro/recap segments by IMDb id + season + episode
(TV mode) or IMDb id alone (movie mode — theintrodb.org only).

Two upstream providers walked in priority order, per POV 6.06's port to DeadLight on
2026-07-09:

  1. api.introdb.app       — richer: gives intro start+end AND outro start+end.
                             This is what the autoplay-nextep timing precision patch
                             (Plan B, cc333cd) relies on for the alert-at-outro-END
                             transition. When it has data, we prefer it.
                             TV-EPISODE-ONLY (400 on movie queries).
  2. api.theintrodb.org/v4  — sparser: gives intro start+end but only outro START (v3 until 2026-10-18)
                             (outro end_ms is typically null in this dataset).
                             Used ONLY as fallback when introdb.app returns 404/no
                             segments — better than nothing for the ~15-25% of shows
                             introdb.app doesn't cover. **Also supports movies**
                             (LOCAL PATCH 2026-08-05) — same response shape but
                             without season/episode params.

Return shape (unchanged from before the dual-provider change so callers stay stable):
  {segment_type: [(start_sec, end_sec_or_None), ...]}
segment_type ∈ {'intro', 'outro', 'recap'}. Recap comes mostly from introdb.app; theintrodb.org's
is read when present. Cache stores merged result; MISS sentinel written only when BOTH
providers returned nothing (a single successful provider populates the cache regardless
of whether the other one had data).
"""
import json
import threading
import time
from modules.kodi_utils import get_property, set_property, logger, make_session
# LOCAL PATCH 2026-10-19: DeadLight's lazy session -- its shared SSL context loads the CA bundle once per process,
# where a bare requests.get reloaded it for every connection (~0.9 s CPU each with Kodi's requests 2.31 / urllib3 2.2)
_session = make_session()
from caches.settings_cache import get_setting

_INTRODB_APP = 'https://api.introdb.app/segments'
# LOCAL PATCH 2026-10-18: v4, TheIntroDB's current API (v2 / v3 are frozen: they still answer GET /media but are no
# longer extended; theintrodb.org/docs/migration-v4 deprecates them on 18 Jan 2027). Same intro / credits / preview lists;
# responses are keyed by tvdb_id now. Which id is sent with which numbering: _lookup_ident.
_INTRODB_ORG = 'https://api.theintrodb.org/v4/media'
_SEGMENT_KEYS = ('intro', 'outro', 'recap')
_CACHE_PROP_PREFIX = 'deadlight.introdb.cache.'
# How far apart two providers may place the same boundary and still count as agreeing.
# 5s is comfortably wider than the observed spread on segments that genuinely match
# (Ace of Diamond S01E43: 64 vs 63 start, 154 vs 154.6 end) and far tighter than the
# gap between a real segment and a wrong one.
_CORROBORATE_SECONDS = 5

# LOCAL PATCH 2026-08-27: provider 3, anime only. api.aniskip.com is the anime-specific
# equivalent of the two above, keyed on MAL id + the episode number WITHIN that MAL entry.
#
# The two IntroDB providers do cover a lot of anime and address it correctly -- they use
# the same TMDb-style numbering DeadLight passes, so Bleach's Thousand-Year Blood War is
# reachable as S02E01 (its IMDb S17E01 form is not, and is not used). The gap they have is
# coverage, not addressing: Re:ZERO S01E26/E50 and Saga of Tanya S01E01 return nothing from
# either, while AniSkip has Re:ZERO. So this is an extra source for the gaps, not a
# replacement -- see the ordering note in fetch_segments.
_ANISKIP = 'https://api.aniskip.com/v2/skip-times/%s/%s'

# User-toggleable, OFF by default: Settings > Playback > Skip Segments > 'Also use
# AniSkip (anime)'. With it off the two IntroDB providers behave exactly as they did
# before AniSkip existed, for anime and everything else alike.
def _aniskip_enabled():
	try: return get_setting('deadlight.skipsegment.aniskip') == 'true'
	except Exception: return False

# AniSkip skipType -> DeadLight segment type. The `mixed-*` forms are deliberately second
# choice: they describe an opening that runs UNDER episode content, which is a different
# and overlapping window from the plain one. Frieren episode 1 reports op 3-93 AND
# mixed-op 59-149; Re:ZERO episode 1 reports op 139-229 and mixed-op 181-251. Preferring
# the mixed window would seek the viewer past the start of the episode proper.
_ANISKIP_TYPES = (('intro', ('op', 'mixed-op')),
				('outro', ('ed', 'mixed-ed')),
				('recap', ('recap',)))


def _cache_key(imdb_id, season, episode):
	# LOCAL PATCH 2026-08-05: 'movie' sentinel for movie queries (season+episode both None).
	if season is None and episode is None:
		return '%s%s_movie' % (_CACHE_PROP_PREFIX, imdb_id)
	# LOCAL PATCH 2026-10-03: the AniSkip toggle is part of the key -- the answer depends on it. Ace of the Diamond S2E04
	# was looked up with AniSkip off (17:34, both IntroDB providers empty -> 'MISS'), AniSkip was switched on, and the
	# 17:40 playback read the cached MISS until Kodi restarted: no AniSkip request, no skip, nothing in the log.
	return '%s%s_%s_%s%s' % (_CACHE_PROP_PREFIX, imdb_id, season, episode, '_as' if _aniskip_enabled() else '')


# LOCAL PATCH 2026-08-26: per-type minimum durations, mirroring the guards the
# consumers already apply (player._check_skip_segments since the Red Light 1.6.7
# port, and player.info_next_ep since 2bfbc15). Validating HERE additionally lets
# the provider fallback do its job: a segment that is present but bogus used to
# block the second service, because the merge below only asked it for segment
# types that were entirely ABSENT. That is how a 5s "outro" from introdb.app
# suppressed theintrodb.org's data for the same episode.
_MIN_SEGMENT_SECONDS = {'intro': 15, 'outro': 15, 'recap': 8}


def _plausible(stype, segs):
	"""True when the segment list looks like real data. Duration-only -- this layer
	has no runtime, so checks relative to total_time stay with the consumers."""
	try:
		if not segs: return False
		start, end = segs[0][0], segs[0][1] if len(segs[0]) > 1 else None
		if start is None or start < 0: return False
		if end is None: return True          # open-ended (theintrodb.org credits) -- can't judge
		if end <= start: return False
		return (end - start) >= _MIN_SEGMENT_SECONDS.get(stype, 15)
	except Exception:
		return False


def _corroborated(a, b):
	"""True when two providers describe the same segment. Used only to decide whether an
	IntroDB segment may fill a type AniSkip omitted -- see the note in fetch_segments.
	An open end (theintrodb.org credits carry start_ms only) is judged on the start alone,
	since there is nothing on the other side to compare."""
	try:
		a0, b0 = a[0], b[0]
		if abs(a0[0] - b0[0]) > _CORROBORATE_SECONDS: return False
		a1 = a0[1] if len(a0) > 1 else None
		b1 = b0[1] if len(b0) > 1 else None
		if a1 is None or b1 is None: return True
		return abs(a1 - b1) <= _CORROBORATE_SECONDS
	except Exception:
		return False

def _fetch_introdb_app(params):
	"""Provider 1 (rich): api.introdb.app. Returns dict in canonical shape or {} on miss/error."""
	# LOCAL PATCH 2026-09-26: `requests` is imported inside the three fetchers so a cached
	# episode (window property hit in fetch_segments) never pays its ~0.4 s import.
	try:
		r = _session.get(_INTRODB_APP, params=params, timeout=8)
		if r.status_code == 404: return {}
		# LOCAL PATCH 2026-10-03 (Batch 3): no answer is None, not {} -- see fetch_segments' _ask
		if r.status_code != 200:
			logger('IntroDB.app: non-200', '%s for %s' % (r.status_code, params))
			return None
		data = r.json()
	except Exception as e:
		logger('IntroDB.app: fetch error', str(e))
		return None
	out = {}
	for stype in _SEGMENT_KEYS:
		seg = data.get(stype)
		if not isinstance(seg, dict): continue
		try:
			start = seg.get('start_sec')
			end = seg.get('end_sec')
			if start is None: continue
			start = float(start)
			end = float(end) if end is not None else None
			out[stype] = [(start, end)]
		except: continue
	return out


def _fetch_aniskip(mal_id, episode):
	"""Provider 3 (anime): api.aniskip.com. Canonical shape, or {} on miss/error.

	episodeLength=0 asks AniSkip not to filter by recorded runtime -- with a real length it
	only returns entries submitted against that exact duration, which throws away good data
	when our runtime differs slightly from the submitter's.
	"""
	# LOCAL PATCH 2026-08-27: ask for the three PLAIN types only -- they never carry
	# anything unique. Across two samples a mixed-* type did not once appear without its
	# plain counterpart, and _ANISKIP_TYPES prefers the plain one anyway, so requesting
	# them only widens the response for nothing.
	#
	# The retry is the important part. AniSkip RATE LIMITS, and answers a burst with HTTP
	# 500 rather than 429: hammering it during testing made 4 of 5 episodes look like
	# misses, and the same four returned data after a 45s pause. Real playback asks about
	# one episode at a time so this should rarely bite, but a single retry costs nothing
	# and turns a transient limit into a hit.
	#
	# episodeLength MUST stay 0 -- a real runtime (tried 24 and 1440) returns HTTP 500.
	data = None
	for _attempt in (1, 2):
		try:
			r = _session.get(_ANISKIP % (mal_id, episode),
							params=[('types[]', t) for t in ('op', 'ed', 'recap')]
									+ [('episodeLength', '0')], timeout=8)
			# 404 is how AniSkip says "nothing submitted for this episode" -- a clean
			# miss, and unlike a 500 it will not change on a retry.
			if r.status_code == 404: return {}
			if r.status_code == 200:
				data = r.json()
				break
			if _attempt == 2:
				logger('AniSkip: non-200', '%s for mal=%s ep=%s' % (r.status_code, mal_id, episode))
		except Exception as e:
			if _attempt == 2: logger('AniSkip: fetch error', str(e))
	if data is None: return None   # LOCAL PATCH 2026-10-03 (Batch 3): no answer, not a miss
	found = {}
	for item in (data.get('results') or []):
		try:
			iv = item.get('interval') or {}
			start, end = iv.get('startTime'), iv.get('endTime')
			if start is None: continue
			found[item.get('skipType')] = (float(start), float(end) if end is not None else None)
		except Exception: continue
	out = {}
	for stype, keys in _ANISKIP_TYPES:
		for k in keys:                     # plain type wins; see _ANISKIP_TYPES
			if k in found:
				out[stype] = [found[k]]
				break
	return out


def _fetch_theintrodb_org(params):
	"""Provider 2 (sparse fallback): api.theintrodb.org/v3. Returns dict in canonical
	shape or {} on miss/error. Handles ms→sec conversion and list-first extraction.
	Uses 'credits' response key which maps to DeadLight's 'outro' segment. Note that
	theintrodb.org's credits[0].end_ms is typically null — outro_end will be None in
	the returned tuple, which is fine (Plan B falls back to outro_start in that case)."""
	try:
		r = _session.get(_INTRODB_ORG, params=params, timeout=6)
		if r.status_code == 404: return {}
		if r.status_code != 200:
			logger('IntroDB.org: non-200', '%s for %s' % (r.status_code, params))
			return None   # LOCAL PATCH 2026-10-03 (Batch 3)
		data = r.json()
	except Exception as e:
		logger('IntroDB.org: fetch error', str(e))
		return None
	out = {}
	# LOCAL PATCH 2026-10-18: a null start_ms on an intro or recap means 'from the start of the file' (Frieren S1E30: intro
	# null-90037) -- those intros were dropped. A null credits start cannot be placed and is still skipped; a null end is
	# open-ended as before. 'preview' (after the credits) is not used.
	for key, stype, open_start in (('intro', 'intro', True), ('recap', 'recap', True), ('credits', 'outro', False)):
		try:
			seg = (data.get(key) or [None])[0] or {}
			start_ms, end_ms = seg.get('start_ms'), seg.get('end_ms')
			if start_ms is None:
				if not open_start or end_ms is None: continue
				start_ms = 0
			out[stype] = [(float(start_ms) / 1000.0, float(end_ms) / 1000.0 if end_ms is not None else None)]
		except Exception: pass
	return out


# LOCAL PATCH 2026-10-03 (Batch 3): a MISS is remembered for 3 hours, not for the life of the Kodi session. A
# segment submitted after the first lookup was never seen until Kodi restarted. A bare 'MISS' (written before
# this patch) counts as expired.
_MISS_TTL = 3 * 3600

def _cached_segments(key):
	"""The window-property cache: segments dict, {} for a recorded MISS, None when not cached."""
	cached = get_property(key)
	if not cached: return None
	if cached.startswith('MISS'):
		try: return {} if time.time() - int(cached.split(':', 1)[1]) < _MISS_TTL else None
		except (IndexError, ValueError): return None
	try: return {k: [tuple(s) for s in v] for k, v in json.loads(cached).items()}
	except: return None

# LOCAL PATCH 2026-09-26: prefetch. The player looked segments up synchronously just before
# play(), and kodi.log put that at 0.8-3 s of the 0.9-3.6 s between picking a source and
# VideoPlayer opening it (3.0 of 3.6 s on one auto-next handoff). Sources.playback_prep now
# starts the lookup as soon as it has the meta, so it runs alongside the scrape; the player's
# own fetch_segments call then finds the cache warm, or waits on the in-flight one above.
# The cache is a window property, so it is shared across processes -- a background next-
# episode prescrape warms it for the playback process too. _INFLIGHT only dedupes in-process.
_INFLIGHT = {}   # cache key -> (Event, Thread)

def prefetch_segments(meta):
	try:
		if get_setting('deadlight.skipsegment.enabled') != 'true': return
		imdb_id, tvdb_id, media_type = meta.get('imdb_id'), meta.get('tvdb_id'), meta.get('media_type')
		ident = _lookup_ident(imdb_id, meta.get('tmdb_id'), tvdb_id)[0]
		if not ident: return
		# Same arguments as DeadLightPlayer._init_skip_segments, or the keys will not match.
		if media_type == 'episode':
			season, episode = meta.get('season'), meta.get('episode')
			if season is None or episode is None: return
		elif media_type == 'movie': season, episode = None, None
		else: return
		key = _cache_key(ident, season, episode)
		if key in _INFLIGHT or _cached_segments(key) is not None: return
		done = threading.Event()
		def _run():
			try: fetch_segments(imdb_id, season, episode, meta.get('tmdb_id'), tvdb_id)
			except Exception as e: logger('IntroDB prefetch error', str(e))
			finally: done.set()
		# daemon: a cancelled scrape must not keep the plugin process alive for the timeouts.
		thread = threading.Thread(target=_run, daemon=True)
		_INFLIGHT[key] = (done, thread)
		thread.start()
	except Exception: pass

def _int_id(value):
	try: value = int(value or 0)
	except (TypeError, ValueError): return 0
	return value if value > 0 else 0


def _lookup_ident(imdb_id, tmdb_id, tvdb_id):
	"""LOCAL PATCH 2026-10-18: (cache ident, theintrodb.org id params, ids for a TVDB-numbered retry), or (None, None, None).

	TheIntroDB v4 converts season / episode from the numbering of the id it is given (openapi.yaml: tmdb_id and imdb_id are
	'resolved server-side, including a season/episode mapping from that provider's numbering'). DeadLight's numbers are
	TMDb's, so tmdb_id goes with them -- 12 sample episodes answered exactly as imdb_id did. tvdb_id is never sent with
	TMDb's numbers: Bleach TMDb S2E1 (Thousand-Year Blood War) by tvdb_id answered for TVDB's S2E1, a 2005 episode.
	The TVDB-numbered retry (Fribb's pair) goes by imdb_id: Monogatari OFF & MONSTER S6E1 is found that way only (IMDb
	numbers it season 6 too; tmdb_id and tvdb_id both miss), by tvdb_id when there is no IMDb id. The cache ident stays
	the IMDb id where there is one, so earlier keys still match."""
	imdb_id = str(imdb_id or '')
	imdb_id = imdb_id if imdb_id.startswith('tt') else ''
	tmdb_id, tvdb_id = _int_id(tmdb_id), _int_id(tvdb_id)
	if tmdb_id: ids = {'tmdb_id': str(tmdb_id)}
	elif imdb_id: ids = {'imdb_id': imdb_id}
	else: return None, None, None
	retry = {'imdb_id': imdb_id} if imdb_id else ({'tvdb_id': str(tvdb_id)} if tvdb_id else None)
	return imdb_id or 'tmdb%d' % tmdb_id, ids, retry


def fetch_segments(imdb_id, season, episode, tmdb_id=None, tvdb_id=None):
	"""Returns dict {segment_type: [(start_sec, end_sec_or_None), ...]} or empty dict on miss/error.
	imdb_id like 'tt0944947'. theintrodb.org is asked by tmdb_id (2026-10-18, see _lookup_ident); with no IMDb id only it
	is asked (introdb.app takes IMDb ids only).
	  - Episode mode: pass season + episode (both required, both ints).
	  - Movie mode:   pass season=None + episode=None. Only theintrodb.org is
	    queried (introdb.app is TV-only and 400s on movie queries).
	Walks introdb.app first (TV only), then theintrodb.org for missing segment types."""
	ident, org_ids, retry_ids = _lookup_ident(imdb_id, tmdb_id, tvdb_id)
	if not ident: return {}
	imdb_id = imdb_id if str(imdb_id or '').startswith('tt') else None
	# LOCAL PATCH 2026-08-05: allow movie-mode (both season+episode None).
	is_movie = (season is None and episode is None)
	if not is_movie and (season is None or episode is None): return {}
	key = _cache_key(ident, season, episode)
	cached = _cached_segments(key)
	if cached is not None: return cached
	# LOCAL PATCH 2026-09-26: a prefetch for this key is already running in this process (see
	# prefetch_segments) -- wait for its answer rather than sending the same requests twice.
	inflight = _INFLIGHT.get(key)
	if inflight and inflight[1] is not threading.current_thread():
		inflight[0].wait(30)
		cached = _cached_segments(key)
		if cached is not None: return cached
	# LOCAL PATCH 2026-10-03 (Batch 3): every provider call goes through _ask, which notes the ones that did not
	# answer (timeout, 5xx). A lookup with a non-answer is used for this playback but not cached: it used to be
	# written as a MISS, so one AniSkip rate-limit meant no skip for that episode until Kodi restarted.
	failed = []
	def _ask(fetch, *args):
		result = fetch(*args)
		if result is None:
			failed.append(fetch.__name__.replace('_fetch_', ''))
			return {}
		return result
	if is_movie:
		# Movie: only theintrodb.org accepts the {imdb_id} shape.
		merged = _ask(_fetch_theintrodb_org, dict(org_ids))
		for stype in list(merged):   # LOCAL PATCH 2026-08-26
			if not _plausible(stype, merged[stype]):
				logger('IntroDB.org: implausible %s' % stype, '%s -> discarded' % (merged[stype],))
				del merged[stype]
	else:
		params = {'imdb_id': imdb_id, 'season': str(season), 'episode': str(episode)}
		org_params = dict(org_ids, season=str(season), episode=str(episode))
		# LOCAL PATCH 2026-10-18: the Fribb entry, read once -- AniSkip and the TVDB retry below both need it. A miss is
		# not anime (the index holds only anime): regular TV pays one offline dict lookup.
		cour = {}
		if tmdb_id:
			try:
				from caches import fribb_mappings
				cour = fribb_mappings.find_cour_by_tmdb_coords(tmdb_id, season, episode) or {}
			except Exception as e: logger('IntroDB: Fribb lookup error', str(e))
		def _app():
			return _ask(_fetch_introdb_app, params) if imdb_id else {}   # introdb.app takes IMDb ids only
		# LOCAL PATCH 2026-10-18: theintrodb.org stores TVDB's numbering (v4). For anime TMDb's often differs, so a miss
		# under TMDb's pair is asked again under Fribb's TVDB one: Monogatari OFF & MONSTER is TMDb S5E1, TVDB S6E1.
		def _org():
			found = _ask(_fetch_theintrodb_org, org_params)
			try: tvdb_pair = (int(cour['cour_season']), int(cour['season_ep']))
			except (KeyError, TypeError, ValueError): tvdb_pair = None
			if not found and retry_ids and tvdb_pair and tvdb_pair != (int(season), int(episode)):
				found = _ask(_fetch_theintrodb_org, dict(retry_ids, season=str(tvdb_pair[0]), episode=str(tvdb_pair[1])))
				logger('IntroDB.org', '%s S%sE%s missed; TVDB S%sE%s: %s' % (ident, season, episode, tvdb_pair[0], tvdb_pair[1],
						list(found) if found else 'nothing'))
			return found
		# LOCAL PATCH 2026-08-27: anime goes to AniSkip first, then falls through the two
		# IntroDB providers below for whatever it did not supply. AniSkip is the anime-
		# specific authority and is keyed on the numbering anime actually uses, so where it
		# has data it is the better answer; where it has none the existing chain is unchanged.
		#
		# A Fribb hit IS the anime test -- the index contains only anime -- so regular TV does
		# no extra work beyond one offline dict lookup. It also hands back the two things
		# AniSkip needs: the MAL id, and cour_ep, the episode number WITHIN that MAL entry.
		# cour_ep is the important half: a cour-2 entry counts from 1 again, so passing TMDb's
		# episode number would ask AniSkip about a completely different episode.
		merged, aniskip_answered = {}, False
		if cour and _aniskip_enabled():
			try:
				mal_id, cour_ep = cour.get('mal'), cour.get('cour_ep')
				if mal_id and cour_ep is not None:
					merged = _ask(_fetch_aniskip, int(mal_id), int(cour_ep))
					for stype in list(merged):
						if not _plausible(stype, merged[stype]):
							logger('AniSkip: implausible %s' % stype, '%s -> discarded' % (merged[stype],))
							del merged[stype]
					if merged: logger('AniSkip segments', '%s for mal=%s ep=%s' % (list(merged), mal_id, cour_ep))
				aniskip_answered = bool(merged)
			except Exception as e:
				logger('AniSkip lookup error', str(e))
				merged = {}
		# LOCAL PATCH 2026-08-27, revised 2026-08-29: AniSkip owns every segment type it
		# answered -- the IntroDB providers never override one. For a type AniSkip OMITTED
		# it is treated as authoritative only when nothing corroborates the alternative:
		# IntroDB may fill the gap, but solely when BOTH providers report that type and
		# agree to within _CORROBORATE_SECONDS at each end.
		#
		# Two real episodes, each with an AniSkip ED and no OP, forced this shape. Submission
		# count does NOT separate them -- both intros are single-submission:
		#   Saga of Tanya S01E01  introdb.app 84-180, theintrodb.org has no intro at all
		#                         -> uncorroborated, rejected; that skip cut 96s of episode.
		#   Ace of Diamond S01E43 introdb.app 64-154, theintrodb.org 63-154.6
		#                         -> agree within ~1s, accepted; a real 90s opening.
		# Cross-provider agreement is the signal that tells the two apart.
		#
		# AniSkip having NOTHING for the episode is not an answer -- the full IntroDB chain
		# then runs exactly as it always did, single-provider segments included.
		if aniskip_answered:
			# Only an intro/outro gap is worth two extra requests. recap is absent from
			# nearly every source, so counting it here would drag the corroboration pair
			# onto every anime episode -- including the ideal case where AniSkip already
			# returned both an OP and an ED. It is still filled below, for free, whenever
			# something else opened the payloads.
			missing = [s for s in _SEGMENT_KEYS if s not in merged]
			if [s for s in missing if s != 'recap']:
				app_segs = _app()
				org_segs = _org()
				for stype in missing:
					a, b = app_segs.get(stype), org_segs.get(stype)
					if not a or not b:
						if a or b: logger('AniSkip gap %s' % stype, 'only one provider has it -> not corroborated, skipped')
						continue
					if not _corroborated(a, b):
						logger('AniSkip gap %s' % stype, '%s vs %s disagree -> skipped' % (a[0], b[0]))
						continue
					if _plausible(stype, a):
						merged[stype] = a
						logger('AniSkip gap %s' % stype, 'filled from IntroDB %s (corroborated by %s)' % (a[0], b[0]))
		else:
			# Provider 1 (rich).
			if not all(k in merged for k in ('intro', 'outro')):
				for stype, segs in _app().items():
					if stype not in merged: merged[stype] = segs
			# LOCAL PATCH 2026-08-26: discard implausible segments BEFORE deciding whether to
			# consult provider 2, so bad data falls back instead of blocking the fallback.
			for stype in list(merged):
				if not _plausible(stype, merged[stype]):
					logger('IntroDB.app: implausible %s' % stype, '%s -> discarded, trying theintrodb.org' % (merged[stype],))
					del merged[stype]
			# Provider 2 (sparse fallback) — fires when introdb.app is missing a segment type
			# or had one rejected above. Its own segments are validated the same way.
			if not merged or not all(k in merged for k in ('intro', 'outro')):
				fallback = _org()
				for stype in _SEGMENT_KEYS:
					if stype in merged or stype not in fallback: continue
					if _plausible(stype, fallback[stype]): merged[stype] = fallback[stype]
					else: logger('IntroDB.org: implausible %s' % stype, '%s -> discarded' % (fallback[stype],))
	if failed:
		logger('IntroDB', 'not cached: %s did not answer (%s)' % (', '.join(failed), key))
		return merged
	try:
		set_property(key, json.dumps(merged) if merged else 'MISS:%d' % int(time.time()))
	except: pass
	return merged
