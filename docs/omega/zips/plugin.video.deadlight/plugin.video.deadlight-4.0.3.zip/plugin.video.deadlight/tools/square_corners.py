"""Make square- and soft-cornered copies of rounded textures (panels, outlines, shadows, artwork masks).

square(): each corner is rebuilt from the straight edges next to it -- a pixel at (x, y) inside a corner box takes the
value the nearest edge has at the same depth (the same row just past the box, or the same column). That squares a
filled panel, a 1 px outline, a two-tone border and a blurred shadow alike, with no per-shape code.

reround(): the same idea in polar form, on a square copy. A corner pixel's depth below the new arc picks the straight
edge's pixel at that depth, so a fill, an outline's stroke and a border all follow the curve; the arc itself is
anti-aliased by its coverage. Radius 0 is Square; Soft is SOFT_RADIUS.

	python square_corners.py deadlight            # media/deadlight_corners/square/ and .../soft/
	python square_corners.py af3 <af3-src>        # <af3-src>/media/Square.xbt and Soft.xbt (Kodi skin themes), etc.
Needs Pillow, and python-lzo for the .xbt files (pip install python-lzo).
"""
import math, os, sys, struct
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
DEADLIGHT_MEDIA = os.path.join(HERE, '..', 'resources', 'skins', 'Default', 'media')
SOFT_RADIUS = 8
STYLES = (('square', 0), ('soft', SOFT_RADIUS))

# DeadLight's rounded textures. circle.png / left-circle.png are true circles (avatars, round buttons) and stay round.
DEADLIGHT_FILES = ['deadlight_common/rounded-16.png', 'deadlight_common/rounded-10.png', 'deadlight_common/left-rounded-16.png',
				   'deadlight_common/panel-256-box.png', 'deadlight_common/dialog.png', 'deadlight_common/shadow-16.png',
				   'deadlight_common/outline-16.png',
				   'deadlight_diffuse/poster-50.png', 'deadlight_diffuse/poster_w217_h320.png', 'deadlight_diffuse/poster_large_w217_h320.png',
				   'deadlight_diffuse/landscape.png', 'deadlight_diffuse/landscape_w284_h160.png']

# AF3's rounded panels, outlines and artwork masks. Left round on purpose: circles (avatars, discs, provider logos),
# pill-shaped bars (progress, slider, scroll -- radius = half the height), flixart's shaped mask, icons, genre art and
# dialog_overlay_curved_v (a concave scoop, unused by any window, that has no square form).
AF3_FILES = ['common/box.png', 'common/box-outline.png', 'common/dialog.png', 'common/dialog-outline.png',
			 'common/menu.png', 'common/menu_x.png', 'common/menu-outline.png', 'common/menu-outlined.png',
			 'common/menu-outlined-x.png', 'common/selectbox_thin.png', 'common/selectbox_thin_border.png',
			 'common/dialog_overlay.png', 'common/dialog_overlay_v.png',
			 'common/widget_text.png', 'common/slice-end.png', 'common/slice-outline-end.png',
			 'diffuse/banner_w1640_h310.png', 'diffuse/card_w731_h310.png', 'diffuse/medialist_expanded_combined.png',
			 'diffuse/tall_w320_h720.png'] + \
			['diffuse/%s_w%d_h%d.png' % s for s in (
				('landscape', 1040, 585), ('landscape', 1140, 680), ('landscape', 1160, 820), ('landscape', 237, 133),
				('landscape', 249, 140), ('landscape', 356, 200), ('landscape', 391, 220), ('landscape', 410, 231),
				('landscape', 480, 270), ('landscape', 560, 310), ('landscape', 570, 320),
				('poster', 217, 310), ('poster', 410, 585), ('poster', 480, 720), ('poster', 560, 820),
				('square', 120, 120), ('square', 217, 217), ('square', 460, 460), ('square', 480, 480),
				('square', 560, 560), ('square', 585, 585), ('square', 600, 600))]

SHADOWS = {'deadlight_common/shadow-16.png'}

def _radius(im):
	"""How far the rounding reaches: along each edge, the distance from the corner to the first pixel at half the
	edge's own middle alpha. An edge that is empty at its middle (a half-piece's open side) says nothing."""
	a, (w, h) = im.getchannel('A').load(), im.size
	found = []
	for row in (0, h - 1):
		mid = a[w // 2, row]
		if mid < 32: continue
		for xs in (range(w // 2), range(w - 1, w // 2, -1)):
			found.append(next((abs(x - xs[0]) for x in xs if a[x, row] >= mid / 2), 0))
	for col in (0, w - 1):
		mid = a[col, h // 2]
		if mid < 32: continue
		for ys in (range(h // 2), range(h - 1, h // 2, -1)):
			found.append(next((abs(y - ys[0]) for y in ys if a[col, y] >= mid / 2), 0))
	return max(found or [0])

def square(im, shadow=False):
	im = im.convert('RGBA')
	w, h = im.size
	src, out = im.load(), im.copy()
	dst = out.load()
	# the corner box: past the rounding's anti-aliased tail (an arc fades out over about half its radius beyond where
	# _radius() finds it), never past halfway so the boxes on one side never meet
	if shadow: kx, ky = w // 2, h // 2
	else: kx = ky = int(_radius(im) * 1.5) + 2
	kx, ky = min(kx, w // 2), min(ky, h // 2)
	for x in range(w):
		near_x = min(x, w - 1 - x)
		if near_x >= kx: continue
		xo = kx if x < w // 2 else w - 1 - kx          # the column just outside this corner's box
		for y in range(h):
			near_y = min(y, h - 1 - y)
			if near_y >= ky: continue
			yo = ky if y < h // 2 else h - 1 - ky
			if shadow:
				# a blurred rectangle is separable: a(x, y) = a(x, yo) * a(xo, y) / a(xo, yo)
				ref = src[xo, yo][3]
				alpha = 0 if not ref else min(255, src[x, yo][3] * src[xo, y][3] // ref)
				dst[x, y] = src[xo, yo][:3] + (alpha,)
			# otherwise depth from the nearer edge decides: the same row past the box, or the same column past it
			elif near_y <= near_x: dst[x, y] = src[xo, y]
			else: dst[x, y] = src[x, yo]
	return out

def reround(sq, radius):
	"""Round a square-cornered image's four corners to `radius` px. sq: the output of square()."""
	w, h = sq.size
	r = min(radius, w // 2, h // 2)
	if r < 1: return sq
	src, out = sq.load(), sq.copy()
	dst = out.load()
	for x in range(w):
		near_x = min(x, w - 1 - x)
		if near_x >= r: continue
		for y in range(h):
			near_y = min(y, h - 1 - y)
			if near_y >= r: continue
			# distance from the arc's centre, in pixel centres; depth = how far inside the arc this pixel lies
			dist = math.hypot(r - near_x - 0.5, r - near_y - 0.5)
			depth = r - dist
			cover = max(0.0, min(1.0, depth + 0.5))
			if cover <= 0: dst[x, y] = src[x, y][:3] + (0,); continue
			d = min(int(max(0.0, depth)), r)
			# the straight edge's pixel at that depth: the top / bottom edge for the steeper half of the arc, else the side
			xe = r if x < w // 2 else w - 1 - r
			ye = r if y < h // 2 else h - 1 - r
			if near_y <= near_x: px = src[xe, d if y < h // 2 else h - 1 - d]
			else: px = src[d if x < w // 2 else w - 1 - d, ye]
			dst[x, y] = px[:3] + (int(round(px[3] * cover)),)
	return out

def styled(im, radius, shadow=False):
	sq = square(im, shadow)
	# a blurred shadow under a lightly rounded panel is indistinguishable from the square one
	return sq if shadow or not radius else reround(sq, radius)

def build_deadlight():
	for style, radius in STYLES:
		dest = os.path.join(DEADLIGHT_MEDIA, 'deadlight_corners', style)
		os.makedirs(dest, exist_ok=True)
		for rel in DEADLIGHT_FILES:
			styled(Image.open(os.path.join(DEADLIGHT_MEDIA, rel)), radius, rel in SHADOWS).save(os.path.join(dest, os.path.basename(rel)), optimize=True)
		print('wrote', os.path.relpath(dest, DEADLIGHT_MEDIA), len(DEADLIGHT_FILES), 'files')

def write_xbt(path, images):
	"""A Kodi XBTF v2 bundle of BGRA frames, LZO1X-compressed as Kodi's TexturePacker writes them (Kodi decompresses a
	frame whose packed size differs from its unpacked size; one that would not shrink is stored raw).
	images: [(name, PIL RGBA image)]."""
	import lzo
	header = 4 + 1 + 4 + len(images) * (256 + 8 + 40)
	blobs, entries, offset = [], [], header
	for name, im in images:
		w, h = im.size
		r, g, b, a = im.split()
		data = Image.merge('RGBA', (b, g, r, a)).tobytes()   # XB_FMT_A8R8G8B8 is BGRA in memory
		packed = lzo.compress(data, 9, False)
		if len(packed) >= len(data): packed = data
		opaque = a.getextrema()[0] == 255
		fmt = 16 | (0x10000 if opaque else 0)                # XB_FMT_A8R8G8B8, plus XB_FMT_OPAQUE
		entries.append(name.encode('utf-8').ljust(256, b'\0') + struct.pack('<II', 0, 1) +
					   struct.pack('<IIIQQIQ', w, h, fmt, len(packed), len(data), 0, offset))
		blobs.append(packed)
		offset += len(packed)
	with open(path, 'wb') as f:
		f.write(b'XBTF' + b'2' + struct.pack('<I', len(images)))
		for e in entries: f.write(e)
		for b in blobs: f.write(b)

SELECTBOX_THIN, SELECTBOX_RADIUS, SELECTBOX_STROKE = 'common/selectbox_thin_3px.png', 16, 3

def ring(size, radius, stroke):
	"""A white rounded-rectangle outline on transparent, anti-aliased by drawing at 4x and scaling down."""
	from PIL import ImageDraw
	k = 4
	big = Image.new('RGBA', (size * k, size * k), (255, 255, 255, 0))
	ImageDraw.Draw(big).rounded_rectangle((0, 0, size * k - 1, size * k - 1), radius=max(radius, 0) * k, outline=(255, 255, 255, 255), width=stroke * k)
	return big.resize((size, size), Image.LANCZOS)

def build_af3(af3_src):
	media = os.path.join(af3_src, 'media')
	# The thin focus frame (Texture_SelectBox_Thin), 3 px instead of selectbox_thin.png's 6. A new name, so it ships as a
	# loose file in media/ for the rounded look (a name Textures.xbt does not hold is read from media/) and each theme
	# carries its own.
	ring(256, SELECTBOX_RADIUS, SELECTBOX_STROKE).save(os.path.join(media, SELECTBOX_THIN), optimize=True)
	dialogs = os.path.join(af3_src, 'extras', 'backgrounds', 'dialogs')
	for style, radius in STYLES:
		images = []
		for rel in AF3_FILES:
			out = styled(Image.open(os.path.join(media, rel)), radius)
			# A square artwork mask is solid white at any size, so store it at 16 x 16: Kodi stretches a diffuse over
			# the control. Only its 1 px anti-aliased rim (alpha 239) is short of opaque, and a square edge needs none.
			# A soft mask keeps its size, since its corner must stay SOFT_RADIUS px on screen. Panels keep their size
			# because their <texture border="..."> insets are in source pixels.
			if not radius and rel.startswith('diffuse/') and out.getchannel('A').getextrema()[0] >= 230:
				out = Image.new('RGBA', (16, 16), (255, 255, 255, 255))
			images.append((rel, out))
		images.append((SELECTBOX_THIN, ring(256, radius, SELECTBOX_STROKE)))
		path = os.path.join(media, style.capitalize() + '.xbt')
		write_xbt(path, images)
		print('wrote %s: %d textures, %d KB' % (path, len(images), os.path.getsize(path) // 1024))
		# The dialog backgrounds (Image_SimpleDialogBackground) are given by full special://skin/ paths, which a theme
		# cannot override -- Kodi looks a theme up only for names relative to media/. Copies sit beside them and the
		# variable picks them by theme. Square ones are opaque, so JPEG; soft ones need alpha at the corners, so PNG,
		# drawn at 240 px: they are blurs, and border="20" keeps the corners 1:1 whatever the size.
		os.makedirs(os.path.join(dialogs, style), exist_ok=True)
		for name in sorted(os.listdir(dialogs)):
			if not name.endswith('.png'): continue
			im = square(Image.open(os.path.join(dialogs, name)))
			if radius:
				reround(im.resize((240, 240), Image.LANCZOS), radius).save(os.path.join(dialogs, style, name), optimize=True)
			else: im.convert('RGB').save(os.path.join(dialogs, style, name[:-4] + '.jpg'), quality=92, optimize=True)
		print('wrote %s dialog backgrounds in %s' % (style, os.path.join(dialogs, style)))

if __name__ == '__main__':
	if sys.argv[1:2] == ['deadlight']: build_deadlight()
	elif sys.argv[1:2] == ['af3'] and len(sys.argv) > 2: build_af3(sys.argv[2])
	else: sys.exit(__doc__)
