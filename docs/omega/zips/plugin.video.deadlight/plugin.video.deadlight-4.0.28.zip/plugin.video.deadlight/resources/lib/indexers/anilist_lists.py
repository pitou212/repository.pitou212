# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-28: AniList browse renderer.
# AniList gives `id`, `idMal`, `title` and `format` but NO IMDb/TMDb ids, so each item is resolved to a TMDb id
# (cached at the meta_cache layer; unresolved items are skipped and logged). Same rendering tail as
# indexers/mdblist_lists.py:_render_content -- `{'list': [(order, media_ids)], 'id_type': 'trakt_dict'}` handed to
# Movies/TVShows.worker() in parallel threads.

import re
import sys
import time

from apis import anilist_api
from apis.tmdb_api import tmdb_tv_search, tmdb_movies_search
from caches import fribb_mappings
from caches.meta_cache import meta_cache
from indexers.media_list_base import render_mixed, finish_dir
from modules import kodi_utils
from modules.settings import max_threads
from modules.utils import TaskPool
from modules.settings import widget_hide_next_page

# AniList returns per-SEASON entries ("Sousou no Frieren 2nd Season") while TMDb groups all seasons under one show.
# Strip season/part/cour/movie/OVA suffixes before hitting TMDb so they all resolve to the same show, then dedupe.
# Order matters: longer / more-specific patterns first.
_SEASON_SUFFIX_RE = re.compile(
	r'\s*[:\-]?\s*(?:'
	r'\d+(?:st|nd|rd|th)\s+season'
	r'|season\s+\d+'
	r'|part\s+\d+'
	r'|cour\s+\d+'
	r'|movie\s+\d+'
	r'|the\s+movie'
	r'|special\s+\d*'
	r'|ova\s*\d*'
	r'|ona\s*\d*'
	r'|final\s+season'
	r')\s*$',
	re.IGNORECASE,
)


def _strip_season_suffix(title):
	"""Trim trailing 'Season 2' / '2nd Season' / 'Part 3' / etc so title matches
	the parent show's TMDb entry."""
	if not title: return title
	prev = None
	# Loop because titles like "Frieren S2 Part 2" have layered suffixes.
	while prev != title:
		prev = title
		title = _SEASON_SUFFIX_RE.sub('', title).strip()
	return title


# AniList `format` enum categorisation.
_TV_FORMATS = {'TV', 'TV_SHORT', 'ONA', 'OVA', 'SPECIAL'}
_MOVIE_FORMATS = {'MOVIE'}
# 'MUSIC' is out of scope — DeadLight has no music-video routing.


def _classify(fmt):
	if fmt in _MOVIE_FORMATS: return 'movie'
	if fmt in _TV_FORMATS: return 'tvshow'
	return None


def _title_for_search(item):
	"""Prefer English title if present, else romaji, else native.
	Strips season/part suffixes so 'Frieren S2' → 'Frieren' → matches TMDb."""
	t = item.get('title') or {}
	raw = t.get('english') or t.get('romaji') or t.get('native') or ''
	return _strip_season_suffix(raw)


# LOCAL PATCH 2026-08-26: cour identity. TMDb and the anime DBs disagree about what a "season" is (Apothecary
# Diaries is ONE TMDb season of 49 episodes, three shows on AniList/Simkl). _resolve_ids() collapses to the PARENT
# tmdb id -- right for browsing, but an upcoming cour then shows the first cour's poster, year and plot. So carry the
# source's own title alongside the id; only the displayed label changes (_display_label() in indexers/tvshows.py).

def _raw_source_title(item):
	"""Unstripped source title, e.g. 'The Apothecary Diaries Season 3'.
	Deliberately NOT _title_for_search(), which strips the season suffix in order
	to match the parent show on TMDb -- here the suffix is the whole point."""
	t = item.get('title') or {}
	return t.get('english') or t.get('romaji') or t.get('native') or ''


def _cour_suffix(raw_title):
	"""The trailing season marker alone, e.g. 'Season 3' out of 'The Apothecary Diaries Season 3'. Reuses
	_strip_season_suffix, so whatever that removes is exactly what we hand back (including 'Season 3 Part 2').

	Used only when the source title and the TMDb title are in different naming languages (AniList falls back to
	romaji), so the tile reads 'TMDb Title - Season 3' rather than all romaji. See _display_label() in indexers/tvshows.py."""
	if not raw_title: return ''
	stripped = _strip_season_suffix(raw_title)
	if stripped and len(stripped) < len(raw_title):
		return raw_title[len(stripped):].strip(' :-–—')
	return ''


_YOUTUBE_PLAY_URL = 'plugin://plugin.video.youtube/play/?video_id=%s'


def _cour_trailer(item):
	"""AniList trailer for THIS cour as a Kodi-playable URL, or '' .

	tvshow_meta() picks one trailer off the TMDb SHOW, so every cour would inherit season 1's; AniList entries ARE
	cours. Only 'youtube' is honoured -- AniList also serves dailymotion, which DeadLight has no player route for."""
	t = item.get('trailer') or {}
	try:
		if (t.get('site') or '').lower() != 'youtube': return ''
		# AniList occasionally returns ids with trailing whitespace/tabs.
		vid = (t.get('id') or '').strip()
		return _YOUTUBE_PLAY_URL % vid if vid else ''
	except Exception:
		return ''


def _is_later_cour(row):
	"""True when this Fribb row is a cour other than the show's first.

	The discriminator is the PAIR (season.tmdb, episode_offset.tmdb), not either alone: Apothecary splits purely by
	offset (S1 off 0/24/48); Attack on Titan has real TMDb seasons AND offset splits inside them (S3 off 0 and 12)."""
	if not row: return False
	try:
		season = (row.get('season') or {}).get('tmdb')
		offset = (row.get('episode_offset') or {}).get('tmdb') or 0
		return (int(season or 1) > 1) or (int(offset) > 0)
	except Exception:
		return False


# ═══════════════════════════════════════════════════════════════════════════
#  TMDb resolution (title + year → TMDb ID)
# ═══════════════════════════════════════════════════════════════════════════

def _search_tmdb(media_type, title, year, adult=False):
	"""TMDb search by title + year: a year match first, then the top result. Returns the TMDb id (str) or None.
	LOCAL PATCH 2026-11-16: an adult title searches TMDb's adult titles too and takes a year match only -- the top result
	of a short title is often another show ('euphoria', a 2011 OVA -> HBO's Euphoria)."""
	try:
		search, date_key = (tmdb_movies_search, 'release_date') if media_type == 'movie' else (tmdb_tv_search, 'first_air_date')
		res = search(title, 1, include_adult='true' if adult else None) or {}
		results = (res.get('results') if isinstance(res, dict) else res) or []
		if not results: return None
		if year:
			for r in results:
				if (r.get(date_key) or '').startswith(str(year)):
					return str(r.get('id') or '')
		if adult: return None
		return str((results[0] or {}).get('id') or '')
	except Exception:
		return None


# LOCAL PATCH 2026-10-04: a resolved TMDb id can stop existing (TMDb listed Black Clover's second season as its own
# show, then deleted it and folded it into the parent; SIMKL still answers the old id). The blank meta is skipped by
# the list builder, so the tile vanished. A gone id is treated as no answer and the next resolver runs -- here the
# title search, which strips 'Season 2' and lands on the parent show.
def _tmdb_gone(media_type, tmdb_id, fetch=False):
	"""True when TMDb says this id does not exist (its meta is a blank entry). fetch=True asks TMDb when the meta is
	not cached -- the list builder would fetch it next anyway, so this only moves the request earlier."""
	if not tmdb_id: return False
	db_type = 'movie' if media_type == 'movie' else 'tvshow'
	try:
		meta = meta_cache.get(db_type, 'tmdb_id', str(tmdb_id))
		if meta is None and fetch:
			from modules import metadata, settings
			from modules.utils import get_datetime
			builder = metadata.movie_meta if db_type == 'movie' else metadata.tvshow_meta
			meta = builder('tmdb_id', str(tmdb_id), settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
		return bool(isinstance(meta, dict) and meta.get('blank_entry'))
	except Exception: return False


def _resolve_ids(item):
	"""Return (media_type, {'imdb': '', 'tmdb': tmdb_id, 'tvdb': ''}) or (None, None)."""
	media_type = _classify(item.get('format'))
	if not media_type: return None, None
	# LOCAL PATCH 2026-07-29: try the offline anime-mappings DB FIRST (precise AniList/MAL -> TMDb); fall back to TMDb
	# title+year search for anime not in the mappings (newer / niche).
	anilist_id = item.get('id')
	mal_id = item.get('idMal')
	# LOCAL PATCH 2026-08-26: key _v2 since cour_label/cour_trailer were added -- a cache hit returns early, so older
	# entries (168 h TTL) would suppress the new keys.
	# LOCAL PATCH 2026-10-21: a backup row (apis/anime_backup.py) can carry a MAL id and no AniList one; MAL and AniList
	# ids are different numbers for different shows, so it is keyed 'mal<id>' -- an AniList row is keyed as before.
	cache_key = 'anilist_tmdb_v2_%s_%s' % (anilist_id or ('mal%s' % mal_id if mal_id else ''), media_type)
	cached = None
	try: cached = meta_cache.get_function(cache_key)
	except Exception: cached = None
	# LOCAL PATCH 2026-10-27: a film cached as its series' TMDb TV id (fribb_mappings._row_tmdb used to fall back to it:
	# the Naruto films as 'Chilly Dogs') is resolved again, not served for the rest of its week
	if cached and not cached.get('miss') and media_type == 'movie':
		try:
			_row = fribb_mappings.anilist_to_fribb(anilist_id) or fribb_mappings.mal_to_fribb(mal_id) or {}
			if str(cached.get('tmdb')) == str((_row.get('themoviedb_id') or {}).get('tv')): cached = None
		except Exception: pass
	if cached:
		# LOCAL PATCH 2026-08-26: misses are cached too (see below), so distinguish them.
		if cached.get('miss'): return None, None
		if not _tmdb_gone(media_type, cached.get('tmdb')): return media_type, cached
		kodi_utils.logger('anilist resolve', 'anilist %s: cached tmdb %s no longer exists on TMDb, resolving again' % (anilist_id, cached.get('tmdb')))
	gone = str(cached.get('tmdb')) if cached and not cached.get('miss') else None
	# LOCAL PATCH 2026-08-10: Fribb anime-lists is the sole exact-ID mapping source (Goldenfreddy's anime_mappings froze
	# upstream and resolved far fewer current-season items). Fribb's `themoviedb_id.tv` is the PARENT show id (the cour's
	# season lives in `season.tmdb`), which is what catalogs want.
	tmdb_id = None
	# LOCAL PATCH 2026-08-26: fetch the row ONCE here; the Simkl tier (simkl_id) and the cour check both need it.
	fribb_row = None
	try: fribb_row = fribb_mappings.anilist_to_fribb(anilist_id) or fribb_mappings.mal_to_fribb(mal_id)
	except Exception: fribb_row = None
	try:
		if fribb_mappings.is_available():
			tmdb_id = fribb_mappings.fribb_tmdb_for(anilist_id=anilist_id, mal_id=mal_id, media_type=media_type)
	except Exception: pass
	# LOCAL PATCH 2026-10-04: Fribb can hold the deleted id too -- Cyberpunk: Edgerunners 2 (AniList 195539) is
	# 326788 there, TMDb 404, now Season 2 of 105248. Only the id just proven gone is dropped; no request is made.
	if tmdb_id and str(tmdb_id) == gone:
		kodi_utils.logger('anilist resolve', 'anilist %s: Fribb says tmdb %s, which TMDb no longer has; trying SIMKL' % (anilist_id, tmdb_id))
		tmdb_id = None
	# LOCAL PATCH 2026-08-26: Simkl as tier 2, ahead of the title search, which rarely resolves what Fribb misses (Simkl
	# has exact curated mappings). Fribb's own simkl_id is used when present (1 request), else Simkl's AniList/MAL lookup
	# (2 requests). Needs only the api-key, so it works with no Simkl account signed in.
	if not tmdb_id:
		try:
			from apis.simkl_api import simkl_tmdb_for
			simkl_id = (fribb_row or {}).get('simkl_id')
			tmdb_id = simkl_tmdb_for(simkl_id=simkl_id, anilist_id=anilist_id, mal_id=mal_id)
		except Exception: pass
		# LOCAL PATCH 2026-10-04: SIMKL keeps ids TMDb has since deleted (see _tmdb_gone)
		if tmdb_id and (str(tmdb_id) == gone or _tmdb_gone(media_type, tmdb_id, fetch=True)):
			kodi_utils.logger('anilist resolve', 'anilist %s: SIMKL says tmdb %s, which TMDb no longer has; trying a title search' % (anilist_id, tmdb_id))
			tmdb_id = None
	if not tmdb_id:
		# Both exact sources missed → last-resort fuzzy title+year TMDb search.
		title = _title_for_search(item)
		if not title: return None, None
		year = (item.get('startDate') or {}).get('year')
		tmdb_id = _search_tmdb(media_type, title, year, adult=bool(item.get('isAdult')))
	if not tmdb_id:
		# LOCAL PATCH 2026-08-26: cache the failure, or unresolvable items (about a third of a page) are re-searched on
		# every load. Short TTL (24 h vs 168 h for hits) so newly-added mappings get picked up promptly.
		try: meta_cache.set_function(cache_key, {'miss': True}, expiration=24)
		except Exception: pass
		return None, None
	ids = {'imdb': '', 'tmdb': tmdb_id, 'tvdb': ''}
	# LOCAL PATCH 2026-08-26: tag later cours with the source's own title so the tile can name them. Movies have no
	# cours. tvshow_meta() reads only tmdb/imdb/tvdb off a trakt_dict, so the extra key rides along unused.
	if media_type == 'tvshow' and _is_later_cour(fribb_row):
		cour_label = _raw_source_title(item)
		if cour_label:
			ids['cour_label'] = cour_label
			suffix = _cour_suffix(cour_label)
			if suffix: ids['cour_suffix'] = suffix
		cour_trailer = _cour_trailer(item)
		if cour_trailer: ids['cour_trailer'] = cour_trailer
	try: meta_cache.set_function(cache_key, ids, expiration=168)
	except Exception: pass
	return media_type, ids


# ═══════════════════════════════════════════════════════════════════════════
#  Rendering
# ═══════════════════════════════════════════════════════════════════════════

def _start_date(start):
	"""LOCAL PATCH 2026-10-25: AniList's startDate {year, month, day} as 'YYYY-MM-DD' when the day is known, else 'YYYY' (or '')."""
	try:
		year, month, day = (start or {}).get('year'), (start or {}).get('month'), (start or {}).get('day')
		if not year: return ''
		if month and day: return '%04d-%02d-%02d' % (int(year), int(month), int(day))
		return '%04d' % int(year)
	except (TypeError, ValueError): return ''


# LOCAL PATCH 2026-11-06: the browse lists whose tiles are specials / OVAs (Anime > Specials, OVAs)
_SPECIAL_BROWSE = ('anime_specials', 'anime_ovas')

def _special_open(it, ids):
	"""LOCAL PATCH 2026-11-06: ids with 'open_url' (the TV builder opens it instead of the show, indexers/tvshows.py) and the
	special's own title as 'cour_label', when the AniList special / OVA `it` is a run of the show's TMDb season 0. Fribb maps a
	special to its PARENT show, so the tile would open that show's seasons (unreachable with Anime Specials hidden). Uses the
	Watch Order's matching (_season0_run), not _special_place's TMDb film search, which would cost a request per tile for a
	result a show tile cannot use. ids unchanged when nothing matches."""
	try:
		start = it.get('startDate') or {}
		if not (start.get('year') and start.get('month') and start.get('day')): return ids
		title = it.get('title') or {}
		cover = it.get('coverImage') or {}
		step = {'date': [start['year'], start['month'], start['day']], 'duration': it.get('duration'), 'episodes': it.get('episodes'),
				'title': title.get('english') or title.get('romaji') or '', 'cover': cover.get('extraLarge') or cover.get('large') or ''}
		show = str(ids.get('tmdb') or '')
		span = _season0_run(show, step) if show else None
		if not span: return ids
		first, last = span
		url = kodi_utils.build_url({'mode': 'build_episode_list', 'tmdb_id': show, 'season': 0, 'cour_offset': first - 1,
			'cour_len': last - first + 1, 'cour_title': step['title'], 'cour_poster': step['cover']})
		return dict(ids, open_url=url, cour_label=step['title'])
	except Exception: return ids


def _render(items, list_name, mode_for_next, params, page_no, has_next):
	handle = int(sys.argv[1])
	is_external = kodi_utils.external()
	# LOCAL PATCH 2026-07-29: dedupe by TMDb ID so several AniList "seasons" of one show collapse to a single row.
	# LOCAL PATCH 2026-08-26: resolve IDs in parallel -- _resolve_ids does a BLOCKING TMDb search whenever Fribb misses.
	# TaskPool carries the CoreELEC thread-cap guard and drains inline if threads cannot start. Results are keyed by
	# position so the ranked catalog order is preserved exactly.
	resolved = {}
	specials = (params or {}).get('browse_type') in _SPECIAL_BROWSE
	# LOCAL PATCH 2026-08-29: keep each entry's AniList cover alongside its resolved ids. AniList art is PER COUR, but
	# _resolve_ids returns the PARENT TMDb show id, so the cover is put back on the listitem after the builder runs.
	# LOCAL PATCH 2026-09-05: carry AniList's averageScore through too (already in the response; TMDb's anime rating is
	# thin, and AniList's is what these rows are ranked by).
	# LOCAL PATCH 2026-10-18: kept per position and applied after the dedupe below, which keeps the FIRST cour of a
	# show. Not setdefault from the worker threads: that kept whichever cour FINISHED first, so a 'Season 2' tile could
	# carry Season 1's cover, tags and score.
	extras = {}
	def _resolve_worker(position, it):
		try:
			mtype, ids = _resolve_ids(it)
			if not ids: return
			# LOCAL PATCH 2026-10-25: AniList's start date rides along (on a copy: ids is the 168 h resolve cache, and a premiere
			# date moves). TMDb often has no first-air date for an anime that has not started; the builders use it only then.
			ids = dict(ids, anilist_start=_start_date(it.get('startDate')))
			if specials and mtype == 'tvshow': ids = _special_open(it, ids)   # LOCAL PATCH 2026-11-06
			resolved[position] = (mtype, ids)
			art = it.get('coverImage') or {}
			cover = art.get('extraLarge') or art.get('large')
			names = anilist_api.anilist_tag_names(it)
			score_str = None
			# averageScore is 0-100 on AniList; anilist.co and MAL present it out of 10, so divide. `is not None`, not
			# truthiness: only None (unrated/unaired) should be skipped.
			score = it.get('averageScore')
			if score is not None:
				try: score_str = '%.1f' % (float(score) / 10.0)
				except Exception: pass
			extras[position] = ('%s_%s' % (mtype, ids.get('tmdb', '')), cover, names, score_str)
		except Exception: kodi_utils.log_row_error('anilist.resolve')
	if items:
		threads = TaskPool().tasks_enumerate(_resolve_worker, items, min(len(items), max_threads()))
		[t.join() for t in threads]

	# LOCAL PATCH 2026-11-01 (cleanup): each kept entry's extras ride beside its ids (show_extras / movie_extras) instead of
	# being copied into covers / tags / scores dicts keyed 'tvshow_<tmdb>'; still taken after the dedupe (the 10-18 rule).
	movies, shows, movie_extras, show_extras = [], [], [], []
	seen_tmdb = {'movie': set(), 'tvshow': set()}
	for position in sorted(resolved):
		mtype, ids = resolved[position]
		# LOCAL PATCH 2026-11-06: a special that opens its own episodes is its own tile, not a duplicate of its show
		tmdb = (ids.get('tmdb', ''), ids.get('open_url') or '') if ids.get('open_url') else ids.get('tmdb', '')
		if tmdb and tmdb in seen_tmdb.get(mtype, set()): continue
		extra = extras.get(position, (None, None, None, None))
		if mtype == 'movie':
			movies.append(ids); movie_extras.append(extra); seen_tmdb['movie'].add(tmdb)
		elif mtype == 'tvshow':
			shows.append(ids); show_extras.append(extra); seen_tmdb['tvshow'].add(tmdb)

	# LOCAL PATCH 2026-10-27: the search row keeps watched titles; the browse widgets still follow widget_hide_watched.
	show_watched = 'true' if params.get('mode') == 'anilist.list.build_anilist_search' else 'false'
	tv_list = {'list': [(i, ids) for i, ids in enumerate(shows)], 'id_type': 'trakt_dict', 'custom_order': 'true', 'show_watched': show_watched}
	mv_list = {'list': [(i + len(shows), ids) for i, ids in enumerate(movies)], 'id_type': 'trakt_dict', 'custom_order': 'true', 'show_watched': show_watched}
	item_list = render_mixed(mv_list, tv_list)
	# position -> (key 'tvshow_<tmdb>' / 'movie_<tmdb>', cover, tags, score) of the AniList entry. Both builders key their
	# results on the position handed to them, so this is the only link back from a rendered listitem to its AniList entry.
	by_position = dict(enumerate(show_extras))
	by_position.update((i + len(shows), extra) for i, extra in enumerate(movie_extras))
	from modules.settings import anime_provider
	genre_choice, score_choice = anime_provider('genre'), anime_provider('score')
	for entry, position in item_list:
		key, cover, names, score = by_position.get(position) or (None, None, None, None)
		if not key: continue
		listitem = entry[1]
		# LOCAL PATCH 2026-08-29: swap the TMDb show poster for the AniList cour cover. Only poster/thumb are touched; fanart and
		# clearlogo stay TMDb/fanart.tv, which carry better art than AniList's bannerImage.
		# LOCAL PATCH 2026-09-14: tvshow.poster is not set here, see the note at _art in indexers/episodes.py.
		if cover:
			try: listitem.setArt({'poster': cover, 'thumb': cover})
			except Exception: pass
		# LOCAL PATCH 2026-08-29: append AniList tags to the row's genres (TMDb's anime genres are near-useless). Genres, not
		# a custom property, because every skin already displays it.
		# LOCAL PATCH 2026-10-18: only as the Anime Genres setting says. MAL chosen: the tags stand in only for a show with no
		# MAL genres cached; TMDb chosen: never.
		if names and genre_choice != 'tmdb':
			has_mal_genres = False
			if genre_choice == 'mal' and key.startswith('tvshow_'):
				try: cached = meta_cache.get('tvshow', 'tmdb_id', key[7:]) or {}
				except Exception: cached = {}
				has_mal_genres = bool((cached.get('mal_info') or {}).get('genres'))   # the builder already set them
			if not has_mal_genres:
				try:
					# LOCAL PATCH 2026-10-07: the tags alone, as metadata.display_genres shows them everywhere else
					listitem.getVideoInfoTag().setGenres(list(names))
				except Exception: pass
		# LOCAL PATCH 2026-09-05: the AniList score as a listitem property for the skin (the AF3 AniList chip), not
		# setRating(): the TMDb rating already set drives sorting and the other rating chips. Named to match the
		# extra_*_rating convention in modules/utils.extra_rating_props.
		if score:
			try:
				# LOCAL PATCH 2026-10-18: Anime Score = MyAnimeList keeps the MAL chip alone where it has one
				# (metadata.anime_choice_props took the AniList one off; this put it back)
				if not (score_choice == 'mal' and listitem.getProperty('extra_mal_rating')): listitem.setProperty('extra_anilist_rating', score)
			except Exception: pass
	kodi_utils.add_items(handle, [i[0] for i in item_list])

	if mode_for_next and has_next and not (is_external and widget_hide_next_page()):
		new_page = str(page_no + 1)
		p = dict(params or {})
		p['new_page'] = new_page
		kodi_utils.add_dir(handle, p, 'Next Page (%s) >>' % new_page, 'nextpage', kodi_utils.get_icon('nextpage_landscape'))

	content = 'tvshows' if len(shows) >= len(movies) else 'movies'
	# LOCAL PATCH 2026-09-04: same cacheToDisc policy as every other builder (False for widgets), and pass `content` and
	# `is_external` -- set_view_mode BLOCKS until container_content() == content, so without them it waited out its ~3 s
	# timeout on every browse and never applied the viewtype. (Both now in media_list_base.finish_dir.)
	finish_dir(handle, content, list_name, is_external, view='view.main')
	return len(item_list)


# ═══════════════════════════════════════════════════════════════════════════
#  Router entry points — one per menu button
# ═══════════════════════════════════════════════════════════════════════════

_BROWSE_METHODS = {
	'airing_this_season':   (anilist_api.anilist_airing_this_season,  'Airing This Season'),
	'airing_next_season':   (anilist_api.anilist_airing_next_season,  'Airing Next Season'),
	'airing_last_season':   (anilist_api.anilist_airing_last_season,  'Airing Last Season'),
	'trending_this_season': (anilist_api.anilist_trending_this_season,'Trending This Season'),
	'trending_this_year':   (anilist_api.anilist_trending_this_year,  'Trending This Year'),
	'trending_all_time':    (anilist_api.anilist_trending_all_time,   'All Time Trending'),
	'popular_this_season':  (anilist_api.anilist_popular_this_season, 'Popular This Season'),
	'popular_this_year':    (anilist_api.anilist_popular_this_year,   'Popular This Year'),
	'popular_all_time':     (anilist_api.anilist_popular_all_time,    'All Time Popular'),
	'top_100':              (anilist_api.anilist_top_100,             'Top 100 Anime'),
	'favourites_all_time':  (anilist_api.anilist_favourites_all_time, 'Most Favorited'),
	# LOCAL PATCH 2026-09-04: periods the engine already had, plus format browse.
	'popular_last_year':    (anilist_api.anilist_popular_last_year,    'Popular Last Year'),
	'trending_last_season': (anilist_api.anilist_trending_last_season, 'Trending Last Season'),
	'anime_movies':         (anilist_api.anilist_movies,               'Anime Movies'),
	'anime_tv_shorts':      (anilist_api.anilist_tv_shorts,            'TV Shorts'),
	'anime_ovas':           (anilist_api.anilist_ovas,                 'OVAs'),
	'anime_onas':           (anilist_api.anilist_onas,                 'ONAs'),
	'anime_specials':       (anilist_api.anilist_specials,             'Specials'),
}


def browse_fetcher(browse_type, genre=None):
	"""(fetcher, list name) for a browse_type. LOCAL PATCH 2026-10-27: browse_type 'genre' + genre is Anime > Genres
	(anilist_api.anilist_genres(): Hentai only with Include Adult Anime on); the page prefetch asks here too, so a genre
	widget's next page warms like the others."""
	if browse_type == 'genre' and genre in anilist_api.anilist_genres():
		return (lambda page_no: anilist_api.anilist_genre(genre, page_no)), genre
	return _BROWSE_METHODS.get(browse_type, _BROWSE_METHODS['airing_this_season'])


def build_anilist_browse(params):
	"""Router entry: params carry `browse_type` (e.g. 'airing_this_season') + `new_page`.
	Falls back to airing_this_season if browse_type unknown."""
	browse_type = params.get('browse_type', 'airing_this_season')
	page_no = int(params.get('new_page', params.get('page', 1)))
	genre = params.get('genre') if browse_type == 'genre' else None
	fetcher, list_name = browse_fetcher(browse_type, genre)
	page_params = {'mode': 'anilist.list.build_anilist_browse', 'browse_type': browse_type}
	if genre: page_params['genre'] = genre
	# LOCAL PATCH 2026-10-20: new titles build their artwork from TMDb alone and get fanart.tv / TVDB's after the list is
	# shown (metadata._ArtBackfill), as the search lists do -- the serial fanart.tv / TVDB calls held up the whole page.
	# The tile poster is AniList's cover anyway.
	from modules.metadata import defer_artwork
	defer_artwork()
	from modules.page_prefetch import page_marks, log_page   # LOCAL PATCH 2026-10-16: ###page timing###
	marks = page_marks()
	try:
		data = fetcher(page_no)
	except Exception:
		data = {'items': [], 'has_next': False, 'page': page_no}
	rows_start = time.time()
	rows = _render(data.get('items') or [], list_name,
			mode_for_next='anilist.list.build_anilist_browse',
			params=page_params,
			page_no=page_no,
			has_next=bool(data.get('has_next')))
	if kodi_utils.external():
		# LOCAL PATCH 2026-10-25 (4.0.5): a widget records its next page for the service to warm later (page_prefetch) --
		# only when the widget shows Next Page at all (Widgets: Hide Next Page off)
		if data.get('has_next') and not widget_hide_next_page():
			from modules.page_prefetch import note_widget_page
			note_widget_page('anilist_browse', dict({'browse_type': browse_type, 'page': page_no + 1}, **({'genre': genre} if genre else {})))
		return
	log_page('anime', 'genre %s' % genre if genre else browse_type, page_no, rows or 0, marks, rows_start)
	# LOCAL PATCH 2026-10-16: warm the next page once this one is on screen, as the TMDb / Trakt catalogues do
	# (modules/page_prefetch.py): a cold AniList page took 5.7-7.1 s, a warm one 0.3-0.5 s
	if data.get('has_next'):
		from modules.page_prefetch import queue
		queue('mixed', 'trakt_dict', lambda: _next_page_ids(fetcher, page_no + 1))


def _next_page_ids(fetcher, page_no):
	"""LOCAL PATCH 2026-10-16: the page prefetch's half of _render -- the AniList page (cached by _cached_page) and each
	entry's TMDb id (cached by _resolve_ids) -- as (media_type, ids) pairs for page_prefetch.run to build the metas of.
	Nothing while AniList has us backing off: one more request then is one more 429."""
	from modules.settings import anime_catalogue_provider
	# LOCAL PATCH 2026-10-22: only when the lists come from AniList (Anime Catalogues) -- MyAnimeList / Kitsu do not care
	if anime_catalogue_provider() == 'anilist' and anilist_api.anilist_score_on_cooldown(): return []
	items = (fetcher(page_no) or {}).get('items') or []
	pairs = {}
	def _one(position, it):
		try:
			mtype, ids = _resolve_ids(it)
			if ids: pairs[position] = (mtype, ids)
		except Exception: pass
	if items: [t.join() for t in TaskPool().tasks_enumerate(_one, items, min(len(items), max_threads()))]
	return [pairs[p] for p in sorted(pairs)]


def build_anilist_search(params):
	"""Wraps anilist_api.anilist_search. Called by the search router when
	media_type=anime_anilist is invoked."""
	query = params.get('query') or params.get('search_query') or ''
	if not query: return
	page_no = int(params.get('new_page', 1))
	# LOCAL PATCH 2026-10-07: AF3's AniList search row asks on every key. AniList allows 30 requests a minute, so a row from
	# the skin waits like the TMDb rows (tmdb_api.search_superseded: empty once the box has moved on) and does not search
	# under SEARCH_MIN_CHARS characters -- 'f', 'fr' would spend two requests on lists nobody reads.
	if kodi_utils.external():
		from apis.tmdb_api import search_superseded, SEARCH_MIN_CHARS
		if len(query.strip()) < SEARCH_MIN_CHARS or search_superseded(query, True):
			return _render([], 'AniList Search: %s' % query, mode_for_next='anilist.list.build_anilist_search',
					params={'mode': 'anilist.list.build_anilist_search', 'query': query}, page_no=page_no, has_next=False)
	try:
		data = anilist_api.anilist_search(query, page_no)
	except Exception:
		data = {'items': [], 'has_next': False, 'page': page_no}
	_render(data.get('items') or [], 'AniList Search: %s' % query,
			mode_for_next='anilist.list.build_anilist_search',
			params={'mode': 'anilist.list.build_anilist_search', 'query': query},
			page_no=page_no,
			has_next=bool(data.get('has_next')))


# ═══════════════════════════════════════════════════════════════════════════
#  Watchlist (LOCAL PATCH 2026-08-29)
#
#  Lives here so it reuses _render / _resolve_ids / _SEASON_SUFFIX_RE; a second copy of that per-cour resolver
#  would drift. MediaListCollection returns the whole list in one response, so page is always 1 and has_next False.
# ═══════════════════════════════════════════════════════════════════════════

_WATCHLIST_STATUSES = {
	'watching':   ('CURRENT',   'Watching'),
	'planning':   ('PLANNING',  'Plan to Watch'),
	'completed':  ('COMPLETED', 'Completed'),
	'paused':     ('PAUSED',    'On Hold'),
	'dropped':    ('DROPPED',   'Dropped'),
	'repeating':  ('REPEATING', 'Rewatching'),
}


def build_anilist_watchlist(params):
	"""Router entry: params carry `status` ('watching', 'planning', ...)."""
	from apis.anilist_api import anilist_media_list, anilist_user_active
	from caches.anilist_cache import anilist_cache_object
	if not anilist_user_active():
		return kodi_utils.notification('AniList not authorized', 4000)
	status_key = params.get('status', 'watching')
	api_status, list_name = _WATCHLIST_STATUSES.get(status_key, _WATCHLIST_STATUSES['watching'])
	try:
		items = anilist_cache_object(anilist_media_list, status_key, api_status) or []
	except Exception:
		items = []
	_render(items, 'AniList: %s' % list_name,
			mode_for_next='anilist.list.build_anilist_watchlist',
			params={'mode': 'anilist.list.build_anilist_watchlist', 'status': status_key},
			page_no=1,
			has_next=False)


# ═══════════════════════════════════════════════════════════════════════════
#  Watch order (LOCAL PATCH 2026-10-27)
#
#  The 'Watch Order' context-menu entry on an anime show: anilist_api.anilist_watch_order's steps for the franchise,
#  numbered, with what is optional / recap / side story / the film version / not out yet marked. A TV step opens its
#  TMDb season (Fribb), a film plays like any movie, an entry Fribb has no TMDb id for is listed for reference.
# ═══════════════════════════════════════════════════════════════════════════

_WO_FORMAT_NAMES = {'TV': 'TV', 'TV_SHORT': 'Short', 'MOVIE': 'Film', 'OVA': 'OVA', 'ONA': 'ONA', 'SPECIAL': 'Special'}
_WO_KIND_NOTES = {'alternative': 'or watch this instead', 'recap': 'recap, skippable', 'side story': 'side story, optional',
				'optional': 'optional', 'upcoming': 'not released yet'}


def _watch_order_seed(tmdb_id):
	"""The AniList id to walk from for a TMDb show: its first season's Fribb row."""
	rows = [r for r in fribb_mappings.tmdb_tv_to_fribb_rows(tmdb_id) if r.get('anilist_id')]
	if not rows: return None
	season = lambda r: (r.get('season') or {}).get('tmdb')
	return min(rows, key=lambda r: (season(r) if isinstance(season(r), int) and season(r) > 0 else 99, r['anilist_id']))['anilist_id']


def _watch_order_film_seed(tmdb_id, imdb_id=None):
	"""LOCAL PATCH 2026-10-31: the AniList id of an anime FILM: its Fribb row, else ani.zip by the row's AniDB id (Fribb's film
	rows often carry no anilist_id -- the scraper recovers it the same way, scrapers/external.py)."""
	if not tmdb_id: return None
	ids = fribb_mappings.query_ids_for_tmdb_movie(tmdb_id, imdb_id if str(imdb_id or '').startswith('tt') else None) or {}
	if ids.get('anilist_id'): return ids['anilist_id']
	if ids.get('anidb_id'):
		try:
			from caches.anizip_mappings import anizip_episode_ids
			found = (anizip_episode_ids(None, cour_episode=1, anidb_id=ids['anidb_id']) or {}).get('anilist')
			if found: return found
		except Exception: pass
	return _watch_order_film_by_title(tmdb_id)

_WO_FILM_QUERY = 'query ($q: String) { Page(perPage: 10) { media(search: $q, type: ANIME, format: MOVIE) { id startDate { year month day } } } }'

def _watch_order_film_by_title(tmdb_id):
	"""LOCAL PATCH 2026-10-31: a film Fribb has no row for yet -- AniList MOVIE entries found by TMDb's title, then the
	original. Taken only when ONE candidate starts in TMDb's release year (+-1), or when several do, the one starting
	within 45 days of it; anything else is no answer, so a franchise's other films never stand in. Cached 24 h, the miss too."""
	from caches.main_cache import main_cache
	key = 'anilist_wo_film_%s' % tmdb_id
	cached = main_cache.get(key)
	if cached is not None: return cached or None
	from modules.metadata import cached_meta, movie_meta
	from modules.settings import tmdb_api_key, mpaa_region
	from modules.utils import get_datetime
	meta = cached_meta('movie', tmdb_id)
	if not meta:
		try: meta = movie_meta('tmdb_id', tmdb_id, tmdb_api_key(), mpaa_region(), get_datetime())
		except Exception: meta = None
	# Not strptime: Kodi's embedded Python breaks it on worker threads (see anilist_api.anilist_for_tmdb_season)
	import datetime
	try: tmdb_day = datetime.date(*(int(p) for p in str((meta or {}).get('premiered') or '')[:10].split('-')))
	except Exception: return None
	found = None
	for title in dict.fromkeys(t for t in ((meta or {}).get('title'), (meta or {}).get('original_title')) if t):
		res = anilist_api._post_anilist(_WO_FILM_QUERY, {'q': title})
		if res is None: return None   # no answer: not cached
		cands = [m for m in res.get('media') or [] if (m.get('startDate') or {}).get('year') and abs(m['startDate']['year'] - tmdb_day.year) <= 1]
		if len(cands) > 1:
			def days(m):
				d = m['startDate']
				try: return abs((datetime.date(d['year'], d.get('month') or 1, d.get('day') or 1) - tmdb_day).days)
				except Exception: return 9999
			cands = [m for m in cands if days(m) <= 45]
		if len(cands) == 1:
			found = cands[0]['id']
			break
	main_cache.set(key, found or 0, expiration=24)
	return found

# LOCAL PATCH 2026-11-01: the steps as plain rows, shared by the Watch Order window (windows/watch_order.py, opened by
# dialogs.watch_order_choice from the context menu) and the folder below (kept for any saved link to the old mode).
# AniList list status per step rides along when an AniList account is signed in (one request, anilist_media_list_all).
_WO_STATUS = {'COMPLETED': 'done', 'CURRENT': 'partial', 'REPEATING': 'partial', 'PAUSED': 'partial', 'PLANNING': 'planned',
			'DROPPED': 'dropped'}

def _cour_place(tmdb_id, season, anilist_id, episodes, step_ids=(), started=False):
	"""(TMDb season, (first, last) episode or None) where this AniList entry really sits, from fribb_mappings' REPAIRED cour
	rows: corrected starts, and an entry Fribb files under a season TMDb does not have is found where the repair placed it
	(JUJUTSU KAISEN Season 2 = TMDb Season 1 e25-47). The span only for a season holding more than one cour; Fribb's season
	is tried first, then the show's other TMDb seasons. (season, False) when the entry is in none of them: a season
	announced but not aired -- the caller lists it as announced instead of opening the whole of Fribb's season."""
	try: seasons = fribb_mappings._tmdb_season_numbers(int(tmdb_id)) or set()
	except Exception: seasons = set()
	order = [season] + sorted(x for x in seasons if x and x != season)
	for s in order:
		if seasons and s not in seasons: continue
		try: cours = fribb_mappings._season_cour_rows(int(tmdb_id), int(s))
		except Exception: continue
		for i, (offset, row) in enumerate(cours):
			if str(row.get('anilist_id')) != str(anilist_id): continue
			if len(cours) < 2: return s, None
			# ends where the next cour starts: AniList counts an episode 0 that TMDb files under Specials, which overlapped the
			# next step by one. Only a cour that is ANOTHER STEP ends this one: TMDb / MAL can split one AniList entry into two
			# cours (STONE OCEAN Part 2), and stopping there left the later episodes unreachable
			following = next((o for o, r in cours[i + 1:] if str(r.get('anilist_id')) in step_ids), None) if step_ids else 				(cours[i + 1][0] if i + 1 < len(cours) else None)
			end = offset + int(episodes) if episodes else following
			if end and following: end = min(end, following)
			# LOCAL PATCH 2026-11-04: a cour that is AIRING has no AniList episode count either (RELEASING, episodes null) -- the
			# last cour of a season that has started ends at TMDb's own episode count; one not started yet keeps the rule below
			if not end and started: end = fribb_mappings._tmdb_episode_count(int(tmdb_id), int(s))
			# no end: the last cour with no episode count -- Fribb files an announced season after TMDb's last episode
			# (Frieren 3rd Season at e39 of 38); opening the whole season would be wrong, so it counts as not placed
			return s, ((offset + 1, end) if end and end > offset else False)
	return season, False

def _wo_date(value):
	import datetime
	try: return datetime.date(*(int(p) for p in str(value)[:10].split('-')))
	except Exception: return None

def _season0_run(show, step):
	"""(first, last) of the TMDb season-0 episodes that are this step, or None: the episodes aired within 3 days of its
	AniList start, its episode count from the first; one under half AniList's length is passed over (Re:ZERO's 3-minute
	'Manner Movie' clips aired the day of its hour-long OVAs). Shared by the Watch Order window (_special_place) and the
	player's AniList / MAL push for a special (special_entry_for_episode)."""
	import datetime
	try: start = datetime.date(*(int(x) for x in step['date'][:3]))
	except Exception: return None
	from modules.metadata import tvshow_meta, episodes_meta
	from modules import settings
	try:
		meta = tvshow_meta('tmdb_id', show, settings.tmdb_api_key(), settings.mpaa_region(), datetime.date.today().isoformat())
		eps = sorted((e for e in (episodes_meta(0, meta) or []) if e.get('episode')), key=lambda e: e['episode'])
	except Exception: return None
	al_seconds = (step.get('duration') or 0) * 60
	def fits(e):
		aired = _wo_date(e.get('premiered'))
		if not aired or abs((aired - start).days) > 3: return False
		return not (al_seconds and e.get('duration') and e['duration'] < al_seconds / 2)
	hits = [i for i, e in enumerate(eps) if fits(e)]
	if not hits: return None
	# LOCAL PATCH 2026-11-06: of the episodes that day, the one closest to AniList's length; and the run stops at an episode
	# under half of it (a 2-minute epilogue aired the same day as a 24-minute special must not take its place).
	first = hits[0]
	if al_seconds and all(eps[i].get('duration') for i in hits):
		first = min(hits, key=lambda i: (abs(eps[i]['duration'] - al_seconds), i))
	run = [eps[first]]
	for e in eps[first + 1:first + max(1, int(step.get('episodes') or 1))]:
		if al_seconds and e.get('duration') and e['duration'] < al_seconds / 2: break
		run.append(e)
	return run[0]['episode'], run[-1]['episode']


def special_entry_for_episode(tmdb_id, episode):
	"""LOCAL PATCH 2026-11-01: {'anilist', 'mal', 'cour_ep', 'via'} for a TMDb SPECIAL (season 0) just watched, or {}. Fribb
	maps no special to AniList, so a finished special never reached AniList / MAL otherwise. The Watch Order's own mapping
	in reverse: the franchise's OVA / ONA / special / short step whose season-0 run holds this episode (_season0_run), and
	the episode's place in it. TV and film steps are not asked: a season premiere can air the day a special does."""
	try: episode = int(episode)
	except (TypeError, ValueError): return {}
	seed = _watch_order_seed(tmdb_id)
	if not seed: return {}
	for step in anilist_api.anilist_watch_order(seed) or []:
		if step.get('format') not in ('OVA', 'ONA', 'SPECIAL', 'TV_SHORT') or step.get('kind') == 'upcoming': continue
		span = _season0_run(tmdb_id, step)
		if span and span[0] <= episode <= span[1]:
			mal = (fribb_mappings.anilist_to_fribb(step['id']) or {}).get('mal_id')
			return {'anilist': step['id'], 'mal': mal, 'cour_ep': episode - span[0] + 1, 'via': 'watch order special'}
	return {}


_WO_MONTHS = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')

def _expected(date):
	"""'expected Oct 2027' / 'expected 2027' / 'date not announced' from AniList's [year, month, day]."""
	year, month = (list(date or []) + [None, None])[:2]
	if not year: return 'date not announced'
	return 'expected %s%s' % ('%s ' % _WO_MONTHS[month - 1] if month and 1 <= month <= 12 else '', year)

def _special_place(shows, step, key):
	"""LOCAL PATCH 2026-11-01: (url, action, where, open label) for a special / OVA / short / recap film step that Fribb maps
	to TMDb's whole Specials list or not at all. By AniList's start date, the one fact AniList, TMDb and Fribb agree on:
	  A. season 0 of the franchise's TMDb show(s): the episodes aired within 3 days of it, the step's episode count from the
	     first (Attack on Titan OVA = Specials 7-9). An episode under half AniList's length is passed over (short clips
	     aired the day of hour-long OVAs).
	  B. a TMDb FILM by the step's title, released within 45 days (Attack on Titan's recap films).
	None when neither: the step stays as it was. Probe: harness/watch_order_specials_probe.py."""
	import datetime
	try: start = datetime.date(*(int(x) for x in step['date'][:3]))
	except Exception: return None
	for show in shows:
		span = _season0_run(show, step)
		if not span: continue
		first, last = span
		url = kodi_utils.build_url({'mode': 'build_episode_list', 'tmdb_id': show, 'season': 0, 'cour_offset': first - 1,
			'cour_len': last - first + 1, 'cour_title': step['title'], 'cour_poster': step.get('cover') or ''})
		where = 'Special %d' % first if first == last else 'Specials %d–%d' % (first, last)
		return url, 'folder', where, 'Open ' + where
	for title in dict.fromkeys(t for t in (step.get('title'), step.get('english'), step.get('romaji')) if t):
		try: results = (tmdb_movies_search(title, 1) or {}).get('results') or []
		except Exception: continue
		near = [(abs((_wo_date(m.get('release_date')) - start).days), m) for m in results if _wo_date(m.get('release_date'))]
		near = sorted((d, m['id']) for d, m in near if d <= 45)
		if near:
			film = near[0][1]
			return kodi_utils.build_url({'mode': 'playback.%s' % key, 'media_type': 'movie', 'tmdb_id': film, key: key}), 'play', 'TMDb film', None
	return None

def watch_order_rows(params):
	"""(seed AniList id, [row]) for params tmdb_id / media_type / imdb_id / anilist_id. A row: number, title, kind, note,
	facts, where, url (a plugin url), action ('folder' / 'play' / 'search'), anilist_id, mal_id, cover, fanart, landscape,
	clearlogo, status ('done' / 'partial' / 'planned' / 'dropped' / '' = not on the list / None = no account), progress."""
	tmdb_id = params.get('tmdb_id')
	if params.get('media_type') == 'movie': seed = _watch_order_film_seed(tmdb_id, params.get('imdb_id'))   # LOCAL PATCH 2026-10-31
	else: seed = _watch_order_seed(tmdb_id) if tmdb_id else None
	anilist_id = params.get('anilist_id') or seed
	steps = anilist_api.anilist_watch_order(anilist_id) if anilist_id else []
	if not steps:
		kodi_utils.notification('No watch order found' if anilist_id else 'Not on AniList (no Fribb mapping)', 3000)
		return anilist_id, []
	from modules.settings import playback_key
	from modules.metadata import cached_meta
	key = playback_key()
	on_list = None
	if anilist_api.anilist_user_active():
		try: on_list = anilist_api.anilist_media_list_all() or {}
		except Exception: on_list = None
	rows, step_ids, shows = [], {str(x['id']) for x in steps}, [str(tmdb_id)] if tmdb_id and params.get('media_type') != 'movie' else []
	for s in steps:
		open_label = None
		row = fribb_mappings.anilist_to_fribb(s['id'])
		is_movie = s['format'] == 'MOVIE'
		tmdb = fribb_mappings._row_tmdb(row, want_movie=is_movie) if row else None
		# LOCAL PATCH 2026-10-31: opened from a film Fribb has no row for, that film's own step is the TMDb film we came from
		if not tmdb and is_movie and params.get('media_type') == 'movie' and str(s['id']) == str(anilist_id): tmdb = tmdb_id
		season = (row.get('season') or {}).get('tmdb') if row and not is_movie else None
		span = None
		started = s.get('status') not in (None, 'NOT_YET_RELEASED')
		# LOCAL PATCH 2026-11-01: a series step Fribb gives no TMDb id (STEEL BALL RUN 2nd & 3rd STAGE: MAL 61469 is shared with
		# 1st STAGE, so its row has none) -- looked for in the franchise's own show(s), where the repair may have placed it
		if not tmdb and not is_movie:
			for show in shows:
				place, place_span = _cour_place(show, None, s['id'], s['episodes'], step_ids, started)
				if place is not None and place_span is not False: tmdb, season, span = show, place, place_span; break
		elif tmdb and isinstance(season, int) and season > 0:
			season, span = _cour_place(tmdb, season, s['id'], s['episodes'], step_ids, started)
			if span is False: tmdb = None   # announced, not placed in any TMDb season yet: listed below as announced
		if tmdb and not is_movie and str(tmdb) not in shows: shows.append(str(tmdb))
		if tmdb and is_movie:
			url, action, where = kodi_utils.build_url({'mode': 'playback.%s' % key, 'media_type': 'movie', 'tmdb_id': tmdb, key: key}), 'play', 'TMDb film'
		elif tmdb and isinstance(season, int):
			# LOCAL PATCH 2026-11-01: the season and episodes this step REALLY is (_cour_place above: repaired cour rows) -- one
			# TMDb season holding several cours read 'Season 1' on every step, and a season TMDb lacks opened an empty list
			url, action = kodi_utils.build_url({'mode': 'build_episode_list', 'tmdb_id': tmdb, 'season': season}), 'folder'
			where = 'Season %s' % season if season else 'Specials'
			if span:
				where, open_label = '%s · eps %d–%d' % (where, span[0], span[1]), 'Open Episodes %d–%d' % span
				# the cour's own slice of the season, as the season list's cour rows link it (seasons.py): only these
				# episodes, titled after the step, so the list's first-unwatched focus lands inside this step
				url = kodi_utils.build_url({'mode': 'build_episode_list', 'tmdb_id': tmdb, 'season': season, 'cour_offset': span[0] - 1,
					'cour_len': span[1] - span[0] + 1, 'cour_title': s['title'], 'cour_poster': s.get('cover') or ''})
		elif tmdb:
			url, action, where = kodi_utils.build_url({'mode': 'build_season_list', 'tmdb_id': tmdb}), 'folder', 'all seasons'
		else:
			url, action = kodi_utils.build_url({'mode': 'anilist.list.build_anilist_search', 'query': s['title']}), 'search'
			where = 'announced' if s['kind'] == 'upcoming' or span is False else 'not on TMDb yet'   # LOCAL PATCH 2026-10-31 / 11-01
		# LOCAL PATCH 2026-11-01: a special that would open the whole Specials list or an AniList search: its own specials or film
		if s['kind'] != 'upcoming' and span is not False and (action == 'search' or (action == 'folder' and season == 0)):
			found = _special_place(shows, s, key)
			if found: url, action, where, open_label = found
		# LOCAL PATCH 2026-11-01: announced, nothing to open yet -- 'plan' (the window's Plan to Watch puts it on the list) and
		# the date AniList expects, instead of a search that only found the show. The url stays the search (folder view).
		if action == 'search' and (s['kind'] == 'upcoming' or span is False):
			action, where = 'plan', _expected(s['date'])
		year = s['date'][0] or 'TBA'
		fmt = _WO_FORMAT_NAMES.get(s['format'], s['format'])
		eps = '%s eps' % s['episodes'] if s['episodes'] and s['format'] != 'MOVIE' else None
		facts = ' · '.join(str(x) for x in (fmt, eps, year, where) if x)
		# LOCAL PATCH 2026-10-31: TMDb's fanart / landscape when the show or film is in the meta cache (no request), else
		# AniList's banner; an entry with neither (a sequel just announced) takes the franchise's, filled in after the loop.
		meta = cached_meta('movie' if is_movie else 'tvshow', tmdb) if tmdb else None
		wide = (meta or {}).get('fanart') or s.get('banner') or ''
		entry = (on_list or {}).get(int(s['id'])) if on_list is not None else None
		status = None if on_list is None else _WO_STATUS.get((entry or {}).get('status'), '')
		rows.append({'number': s['number'], 'title': s['title'], 'kind': s['kind'], 'note': _WO_KIND_NOTES.get(s['kind']) or '',
			'facts': facts, 'short_facts': ' · '.join(str(x) for x in (fmt, eps, year) if x), 'where': where, 'url': url, 'action': action,
			'anilist_id': s['id'], 'mal_id': (row or {}).get('mal_id'), 'cover': s.get('cover') or '', 'fanart': wide,
			'landscape': (meta or {}).get('landscape') or wide, 'clearlogo': (meta or {}).get('clearlogo') or '',
			'status': status, 'progress': (entry or {}).get('progress') or 0, 'episodes': s['episodes'] or 0, 'open_label': open_label})
	franchise = next((r for r in rows if r['fanart']), None)
	if franchise:
		for r in rows:
			if not r['fanart']: r['fanart'], r['landscape'] = franchise['fanart'], franchise['landscape']
			if not r['clearlogo']: r['clearlogo'] = franchise['clearlogo']
	return anilist_id, rows


def next_step_index(rows):
	"""The row the Watch Order window opens on: where the user should carry on.

	rows are in watch order; each has 'kind' ('main', 'alternative', 'recap', 'side story', 'optional', 'upcoming'),
	'number' (0 for an alternative), 'status' ('done' / 'partial' / 'planned' / 'dropped' / '' not on the list /
	None when no AniList account is signed in), 'progress' (episodes watched) and 'episodes' (0 = unknown).
	Return an index into rows (0 when there is nothing better)."""
	# TODO(user): decide what "next to watch" means.
	return 0


