# -*- coding: utf-8 -*-
import re
import sys
import json
import time
from modules.metadata import tvshow_meta, is_anime_check, light_meta, cached_meta, display_genres, show_status_props, shown_season_count, release_label
from modules.utils import get_datetime, get_current_timestamp, manual_function_import, extra_rating_props
from modules import kodi_utils, settings, watched_status
from indexers.media_list_base import MediaListBase

# LOCAL PATCH 2026-08-26: cour identity for anime catalog tiles. anilist_lists tags a later cour's ids dict with
# 'cour_label' (e.g. "The Apothecary Diaries Season 3"); otherwise every cour of a one-season TMDb show renders alike.
# Only the visible label changes: `title` (favourites / list URLs, context menu, setTvShowTitle) stays the parent show.

def _norm_title(text):
	return re.sub(r'[^a-z0-9]+', '', (text or '').lower())


def _display_label(tmdb_title, cour_label, cour_suffix=''):
	"""Which name to show on a later-cour tile.

	tmdb_title  -- the SHOW's name; authoritative and always present.
	cour_label  -- the catalog source's own name for this cour; AniList falls back to ROMAJI when it has no
	               English title.
	cour_suffix -- just the season marker out of cour_label ("Season 3").

	Rule: if cour_label starts with the show title (same naming language) it wins -- it handles subtitled cours.
	Otherwise keep the TMDb name and graft the marker on, so the English name leads. If neither works, change nothing.
	"""
	if not cour_label: return tmdb_title
	if not tmdb_title: return cour_label
	if _norm_title(cour_label).startswith(_norm_title(tmdb_title)): return cour_label
	if cour_suffix: return '%s - %s' % (tmdb_title, cour_suffix)
	return tmdb_title


# LOCAL PATCH 2026-10-19: see the Anime List Manager entry in build_tvshow_content
def _fribb_rows(tmdb_id):
	from caches.fribb_mappings import tmdb_tv_to_fribb_rows
	return tmdb_tv_to_fribb_rows(tmdb_id)

class TVShows(MediaListBase):   # LOCAL PATCH 2026-10-19: context_menu, paginate_list, _size_pool_for_cold_page
	# LOCAL PATCH 2026-08-05 (POV 6.08 P1 port): tmdb_tv_trending added as Trakt-independent trending source
	main = ('tmdb_tv_popular', 'tmdb_tv_popular_today', 'tmdb_tv_trending', 'tmdb_tv_premieres', 'tmdb_tv_airing_today','tmdb_tv_on_the_air', 'tmdb_tv_upcoming',
	'tmdb_anime_popular', 'tmdb_anime_popular_recent', 'tmdb_anime_premieres', 'tmdb_anime_upcoming', 'tmdb_anime_on_the_air')
	special = ('tmdb_tv_languages', 'tmdb_tv_networks', 'tmdb_tv_providers', 'tmdb_tv_year', 'tmdb_tv_decade', 'tmdb_tv_recommendations', 'tmdb_tv_genres',
	'tmdb_tv_search', 'tmdb_tv_keyword_results', 'tmdb_tv_keyword_results_direct', 'tmdb_anime_year', 'tmdb_anime_decade', 'tmdb_anime_genres',
	'tmdb_anime_providers', 'ai_similar', 'anilist_recommended')
	personal = {'in_progress_tvshows': ('modules.watched_status', 'get_in_progress_tvshows'),
	'watched_tvshows': ('modules.watched_status', 'get_watched_items'),
	'recent_watched_tvshows': ('modules.watched_status', 'get_recently_watched'),
	'favorites_tvshows': ('modules.favorites', 'get_favorites'),
	'favorites_anime': ('modules.favorites', 'get_favorites'),
	'dropped_tvshows': ('modules.watched_status', 'get_dropped_items')}   # LOCAL PATCH 2026-10-06
	trakt_main = ('trakt_tv_trending', 'trakt_tv_trending_recent', 'trakt_tv_most_watched', 'trakt_tv_most_favorited',
	'trakt_anime_trending', 'trakt_anime_trending_recent', 'trakt_anime_most_watched', 'trakt_anime_most_favorited')
	trakt_special = ('trakt_tv_certifications', 'trakt_anime_certifications')
	trakt_personal = ('trakt_collection', 'trakt_watchlist', 'trakt_collection_lists', 'trakt_watchlist_lists', 'trakt_favorites')
	
	def __init__(self, params):
		self.params = params
		self.params_get = self.params.get
		self.category_name = self.params_get('category_name', None) or self.params_get('name', None) or 'TV Shows'
		self.id_type, self.list, self.action = self.params_get('id_type', 'tmdb_id'), self.params_get('list', []), self.params_get('action', None)
		self.tmdb_api_key = settings.tmdb_api_key()
		self.items, self.new_page, self.total_pages, self.is_external = [], {}, None, kodi_utils.external()
		self.is_anime()
		if self.is_external:
			self.widget_hide_next_page = settings.widget_hide_next_page()
			# LOCAL PATCH 2026-10-27: searches keep watched titles (AF3's search rows are widgets, so the setting hid them);
			# show_watched is the AniList search row (anilist_lists._render).
			self.widget_hide_watched = self.action not in ('watched_tvshows', 'recent_watched_tvshows', 'tmdb_tv_search') \
				and self.params_get('show_watched') != 'true' and settings.widget_hide_watched()
		else: self.widget_hide_next_page, self.widget_hide_watched = False, False
		self.custom_order = self.params_get('custom_order', 'false') == 'true'
		self.paginate_start = int(self.params_get('paginate_start', '0'))
		self.append = self.items.append

	# LOCAL PATCH 2026-10-19: the TV catalogues keep anime out (anime only in the anime catalogues), same switch as the
	# personal lists, 'Include anime in TV lists'. Not a search, Recommended, keyword or AI Similar list: asked for by
	# title, and filtering would empty them when that title is anime.
	_ANIME_FREE_EXEMPT = ('tmdb_tv_search', 'tmdb_tv_recommendations', 'tmdb_tv_keyword_results', 'tmdb_tv_keyword_results_direct',
		'ai_similar', 'anilist_recommended')

	def _is_tv_catalogue(self):
		action = self.action or ''
		if 'anime' in action or action in self._ANIME_FREE_EXEMPT: return False
		return action in self.main or action in self.special or action in self.trakt_main or action in self.trakt_special

	def is_anime(self):
		if 'is_anime_list' in self.params: self.is_anime_list = self.params['is_anime_list'] == 'true'
		elif self.action in self.personal or self._is_tv_catalogue():
			if settings.include_anime_tvshow(): self.is_anime_list = None
			else: self.is_anime_list = False
		else: self.is_anime_list = None

	def fetch_list(self):
		handle = int(sys.argv[1])
		from modules.page_prefetch import page_marks, log_page   # LOCAL PATCH 2026-10-16: ###page timing###
		_marks, _rows_start = page_marks(), None
		try:
			is_random = self.params_get('random', 'false') == 'true'
			try: page_no = int(self.params_get('new_page', '1'))
			except: page_no = self.params_get('new_page')
			if page_no == 1 and not self.is_external:
				folder_path = kodi_utils.folder_path()
				if not any([x in folder_path for x in ('build_season_list', 'build_episode_list')]): kodi_utils.set_property('deadlight.exit_params', folder_path)
			if self.action in self.personal: var_module, import_function = self.personal[self.action]
			else: var_module, import_function = 'apis.%s_api' % self.action.split('_')[0], self.action
			try: function = manual_function_import(var_module, import_function)
			except: pass
			# LOCAL PATCH 2026-10-02: search results show TMDb art at once; TVDB / fanart.tv fill in afterwards
			if self.action == 'tmdb_tv_search':
				from modules.metadata import defer_artwork
				from apis.tmdb_api import SEARCH_POOL
				defer_artwork()
				self.search_pool = SEARCH_POOL   # see tmdb_api.SEARCH_POOL
			# LOCAL PATCH 2026-11-15: every in-addon list too, for TMDb-first artwork (metadata.defer_artwork); widgets keep it inline
			if not self.is_external:
				from modules.metadata import defer_artwork
				defer_artwork(tmdb_first_only=True)
			if self.action in self.main:
				data = function(page_no)
				self._size_pool_for_cold_page()   # LOCAL PATCH 2026-10-03 (3.0.8)
				results = data['results']
				self.list = [i['id'] for i in results]
				if not is_random and data['total_pages'] > page_no: self.new_page = {'new_page': str(page_no + 1)}
				self._prefetch(lambda: [i['id'] for i in function(page_no + 1)['results']])
			elif self.action in self.special:
				key_id = self.params_get('key_id') or self.params_get('query')
				if not key_id: return
				short = False
				if self.action in ('tmdb_movies_search', 'tmdb_tv_search'):   # LOCAL PATCH 2026-10-06: tmdb_api.search_superseded / short_search_filter
					from apis.tmdb_api import search_superseded, short_search_filter
					from time import perf_counter
					_t0 = perf_counter()
					if search_superseded(key_id, self.is_external): data, short = {'results': [], 'total_pages': 1, 'page': 1}, True
					else:
						_t1 = perf_counter()
						data, short = short_search_filter(key_id, function(key_id, page_no))
						# LOCAL PATCH 2026-10-06: timed for the 'search.rows' line logged once the rows are built
						self._search_log, self._light_hits = {'query': key_id, 't0': _t0, 'wait': _t1 - _t0, 'search': perf_counter() - _t1}, []
					# LOCAL PATCH 2026-10-06: a skin search row is built from the search answer (metadata.light_meta)
					if self.is_external: self.light_rows = {i['id']: light_meta('tvshow', i) for i in data.get('results') or []}
				else: data = function(key_id, page_no)
				self._size_pool_for_cold_page()   # LOCAL PATCH 2026-10-03 (3.0.8)
				results = data['results']
				self.list = [i['id'] for i in results]
				if not is_random and data['total_pages'] > page_no: self.new_page = {'new_page': str(page_no + 1), 'key_id': key_id}
				if not short: self._prefetch(lambda: [i['id'] for i in function(key_id, page_no + 1)['results']])
			elif self.action in self.personal:
				full = function('tvshow', page_no)
				data, total_pages = self.paginate_list(full, page_no)
				self.list = [i['media_id'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}
				self._prefetch(lambda: [i['media_id'] for i in self.paginate_list(full, page_no + 1)[0]])   # LOCAL PATCH 2026-10-25: local lists too
			elif self.action in self.trakt_main:
				self.id_type = 'trakt_dict'
				data = function(page_no)
				try: self.list = [i['show']['ids'] for i in data]
				except: self.list = [i['ids'] for i in data]
				if not is_random and self.action != 'trakt_recommendations': self.new_page = {'new_page': str(page_no + 1)}
				self._prefetch(lambda: [i['show']['ids'] if 'show' in i else i['ids'] for i in function(page_no + 1)])
			elif self.action in self.trakt_special:
				key_id = self.params_get('key_id', None) or self.params_get('query')
				if not key_id: return
				self.id_type = 'trakt_dict'
				data = function(key_id, page_no)
				self.list = [i['show']['ids'] for i in data]
				if not is_random: self.new_page = {'new_page': str(page_no + 1), 'key_id': key_id}
				self._prefetch(lambda: [i['show']['ids'] for i in function(key_id, page_no + 1)])
			elif self.action in self.trakt_personal:
				self.id_type = 'trakt_dict'
				full = data = function('shows', page_no)
				if self.action in ('trakt_collection_lists', 'trakt_watchlist_lists', 'trakt_favorites'): total_pages = 1
				else: data, total_pages = self.paginate_list(data, page_no)
				self.list = [i['media_ids'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}
				except: pass
				self._prefetch(lambda: [i['media_ids'] for i in self.paginate_list(full, page_no + 1)[0]])   # LOCAL PATCH 2026-10-25
			elif self.action == 'trakt_recommendations':
				self.id_type = 'trakt_dict'
				full = function('shows')
				data, total_pages = self.paginate_list(full, page_no)
				self.list = [i['ids'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}
				except: pass
				self._prefetch(lambda: [i['ids'] for i in self.paginate_list(full, page_no + 1)[0]])   # LOCAL PATCH 2026-10-25
			elif self.action == 'tmdb_tv_discover':
				url = self.params_get('url')
				data = function(url, page_no)
				results = data['results']
				self.list = [i['id'] for i in results]
				if data['total_pages'] > page_no: self.new_page = {'url': url, 'new_page': str(data['page'] + 1)}
				self._prefetch(lambda: [i['id'] for i in function(url, page_no + 1)['results']])
			elif self.action == 'trakt_dropped':
				from apis.trakt_api import trakt_get_hidden_items
				self.list = [i for i in (trakt_get_hidden_items('dropped') or []) if i]
			elif self.action == 'trakt_tv_related':
				self.id_type = 'trakt_dict'
				key_id = self.params_get('key_id')
				if not key_id.startswith('tt'): key_id = tvshow_meta('tmdb_id', key_id, self.tmdb_api_key, settings.mpaa_region(), get_datetime())['imdb_id']
				data = function(key_id)
				self.list = [i['ids'] for i in data]
			elif self.action == 'imdb_more_like_this':
				from apis.imdb_api import imdb_more_like_this
				self.id_type = 'imdb_id'
				key_id = self.params_get('key_id')
				if self.params_get('get_imdb'):
					key_id = tvshow_meta('tmdb_id', key_id, self.tmdb_api_key, settings.mpaa_region(), get_datetime(), get_current_timestamp())['imdb_id']
				self.list = imdb_more_like_this(key_id)
			self._maybe_filter_dropped()
			_rows_start = time.time()
			kodi_utils.add_items(handle, self.worker())
			if getattr(self, '_search_log', None):   # LOCAL PATCH 2026-10-06: one line per search row
				from time import perf_counter
				_sl = self._search_log
				kodi_utils.logger('search.rows', 'tv %r: %d rows (%d light) -- wait %.2fs, search %.2fs, total %.2fs' % (_sl['query'], len(self.items),
					len(getattr(self, '_light_hits', [])), _sl['wait'], _sl['search'], perf_counter() - _sl['t0']))
			if self.total_pages and self.total_pages > 2 and settings.jump_to_enabled() and not self.is_external:
				url_params = json.dumps({**self.new_page, **{'mode': 'build_tvshow_list', 'action': self.action, 'category_name': self.category_name}})
				kodi_utils.add_dir(handle, {'mode': 'navigate_to_page_choice', 'current_page': page_no, 'total_pages': self.total_pages, 'url_params': url_params},
											'Jump To...', 'item_jump', kodi_utils.get_icon('item_jump_landscape'), isFolder=False)
			if self.new_page and not self.widget_hide_next_page:
				self.new_page.update({'mode': 'build_tvshow_list', 'action': self.action, 'category_name': self.category_name})
				if self.is_anime_list is not None: self.new_page['is_anime_list'] = {True: 'true', False: 'false'}[self.is_anime_list]   # LOCAL PATCH 2026-10-03: was '==', so Next Page dropped it
				kodi_utils.add_dir(handle, self.new_page, 'Next Page (%s) >>' % self.new_page['new_page'], 'nextpage', kodi_utils.get_icon('nextpage_landscape'))
		except: pass
		kodi_utils.set_content(handle, 'tvshows')
		kodi_utils.set_category(handle, self.category_name)
		kodi_utils.end_directory(handle, cacheToDisc=False if self.is_external else True)
		if not self.is_external:
			log_page('tvshow', self.action, self.params_get('new_page', '1'), len(getattr(self, 'items', None) or []), _marks, _rows_start)
			kodi_utils.set_view_mode('view.tvshows', 'tvshows', self.is_external, refreshed=self.params_get('refreshed') == 'true')

	def _prefetch(self, fetch_ids):
		# LOCAL PATCH 2026-10-02: warm the next page once this one is on screen; see modules/page_prefetch.py
		if not self.new_page or self.is_external or self.action == 'tmdb_tv_search': return
		from modules.page_prefetch import queue
		queue('tvshow', self.id_type, fetch_ids, is_anime_list=self.is_anime_list)

	def build_tvshow_content(self, _position, _id):
		try:
			# LOCAL PATCH 2026-10-06: see metadata.light_meta -- not for a show with watch history, whose progress needs its episode counts
			_lr = getattr(self, 'light_rows', None)   # search rows only; most lists' ids are dicts (see movies.py)
			light = _lr.get(_id) if _lr and not isinstance(_id, dict) else None
			if light and str(_id) not in self.watched_info:
				meta = cached_meta('tvshow', _id, self.current_time) or light
				if meta is light: getattr(self, '_light_hits', []).append(_id)
			else: meta = tvshow_meta(self.id_type, _id, self.tmdb_api_key, self.mpaa_region, self.current_date, self.current_time, self.is_anime_list)
			if not meta or 'blank_entry' in meta: return
			cm = []
			cm_append = cm.append
			listitem = self.make_listitem()
			set_properties = listitem.setProperties
			meta_get = meta.get
			premiered = meta_get('premiered')
			# LOCAL PATCH 2026-10-25: no year until it is released ('' -- setYear only for a real one). Not a stand-in like
			# '2050': AF3 shows it as the year.
			trailer, title, year = meta_get('trailer'), meta_get('title'), meta_get('year') or ''
			# LOCAL PATCH 2026-08-26: cour identity -- display only. `_id` is a dict solely
			# on the trakt_dict path (anime catalogs); every other caller passes a bare id.
			# LOCAL PATCH 2026-08-26: an airing show advertises its CURRENT season's trailer (ended shows keep the show's).
			# max() picks the highest season that HAS one (the newest is often unaired). Runs BEFORE the cour override
			# below, which is finer grained and must win.
			if meta_get('status') in ('Returning Series', 'In Production'):
				_season_trailers = meta_get('season_trailers') or {}
				if _season_trailers: trailer = _season_trailers[max(_season_trailers, key=lambda k: int(k))] or trailer
			label = title
			if isinstance(_id, dict):
				# LOCAL PATCH 2026-10-25: an anime TMDb has no date for yet takes AniList's start (anilist_lists._start_date)
				_start = _id.get('anilist_start') or ''
				if _start and not year: year = _start[:4]
				if len(_start) == 10 and not premiered: premiered = _start
				_cour = _id.get('cour_label')
				if _cour: label = _display_label(title, _cour, _id.get('cour_suffix', '')) or title
				# Season-correct trailer. meta['trailer'] is picked off the TMDb SHOW and
				# cached per tmdb_id, so every cour would otherwise share season 1's.
				_cour_trailer = _id.get('cour_trailer')
				if _cour_trailer: trailer = _cour_trailer
			tvdb_id, imdb_id = meta_get('tvdb_id'), meta_get('imdb_id')
			if self.rpdb_api_key:
				try: poster = meta_get('rpdb_poster') % self.rpdb_api_key + self.rpdb_format
				except: poster = meta_get('poster') or self.poster_empty
			else: poster = meta_get('poster') or self.poster_empty
			fanart = meta_get('fanart') or self.fanart_empty
			clearlogo, landscape = meta_get('clearlogo') or '', meta_get('landscape') or ''
			thumb = poster or landscape or fanart
			tmdb_id, total_seasons, total_aired_eps = meta_get('tmdb_id'), meta_get('total_seasons'), meta_get('total_aired_eps')
			unaired = total_aired_eps == 0
			if unaired: progress, playcount, total_watched, total_unwatched = 0, 0, 0, total_aired_eps
			else:
				playcount, total_watched, total_unwatched = watched_status.get_watched_status_tvshow(self.watched_info.get(str(tmdb_id), None), total_aired_eps)
				if total_watched: progress = watched_status.get_progress_status_tvshow(total_watched, total_aired_eps)
				else: progress = 0
			# LOCAL PATCH 2026-09-04: visible_progress on BOTH branches: set_properties() reads it unconditionally, and a
			# NameError for an unaired show would silently drop the row (the bare except).
			visible_progress = '0' if progress == 100 else progress
			# LOCAL PATCH 2026-09-04: bail before building the urls and context menu (as in indexers/movies.py).
			if playcount and self.widget_hide_watched: return
			extras_params = self.build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'tvshow', 'is_external': self.is_external})
			options_params = self.build_url({'mode': 'options_menu_choice', 'content': 'tvshow', 'tmdb_id': tmdb_id, 'poster': poster,
										'is_external': self.is_external})
			if self.all_episodes:
				if self.all_episodes == 1 and (total_seasons > 1 or meta_get('light_meta')): url_params = self.build_url({'mode': 'build_season_list', 'tmdb_id': tmdb_id})
				else: url_params = self.build_url({'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': 'all'})
			else: url_params = self.build_url({'mode': 'build_season_list', 'tmdb_id': tmdb_id})
			# LOCAL PATCH 2026-11-06: an AniList special opens its own season-0 episodes (anilist_lists._special_open), not the show
			if isinstance(_id, dict) and _id.get('open_url'): url_params = _id['open_url']
			if self.open_extras:
				cm_append(['extras', ('[B]Browse[/B]', 'Container.Update(%s)' % url_params)])
				url_params = extras_params
			else: cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
			cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
			if str(tmdb_id) in self.pinned: cm_append(['playback_options', ('[B]Clear SmartPlay Pin[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'clear_smartplay_pin_choice', 'tmdb_id': tmdb_id}))])
			# LOCAL PATCH 2026-11-01 (cleanup): Browse Recommended .. Reload Widgets are MediaListBase._shared_cm (shared with
			# Movies); the two TV-only entries below go in after trakt_manager and simkl_manager.
			after_trakt, after_simkl = [], []
			# LOCAL PATCH 2026-08-29: AniList list manager, gated on an authorized account and a Fribb hit.
			# LOCAL PATCH 2026-09-04: is_anime_check() (TMDb keywords already in meta) first, so non-anime never loads the
			# Fribb index. Trade-off: anime TMDb has not tagged with keyword 210024 lose this entry; if it bites, widen the
			# gate to a cached anime-tmdb-id set, not back to loading the index unconditionally.
			# LOCAL PATCH 2026-10-19: fribb_mappings imported here, behind the two cheap checks, not at the top (~11 ms per call)
			if self.anilist_cm_active and is_anime_check(meta) and _fribb_rows(tmdb_id):
				# LOCAL PATCH 2026-10-02: one manager for AniList AND MyAnimeList (indexers/dialogs.anilist_manager_choice);
				# the key stays 'anilist_manager' so saved context-menu orders keep working.
				after_trakt.append(['anilist_manager', ('[B]Anime List Manager[/B]', 'RunPlugin(%s)' % self.build_url(
					{'mode': 'anilist_manager_choice', 'tmdb_id': tmdb_id, 'title': title,
					'media_type': 'tvshow', 'icon': poster}))])
			try: _is_dropped = int(tmdb_id) in self.dropped_set
			except: _is_dropped = False
			_drop_action = 'undrop' if _is_dropped else 'drop'
			_drop_label = '[B]Undrop Show[/B]' if _is_dropped else '[B]Drop Show[/B]'
			_drop_url = self.build_url({'mode': 'trakt_drop_show', 'action': _drop_action, 'media_id': tmdb_id})
			after_simkl.append(['drop_show', (_drop_label, 'RunPlugin(%s)' % _drop_url)])
			mark_entries = []
			if not playcount and not unaired:
				mark_entries.append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'watched_status.mark_tvshow', 'action': 'mark_as_watched',
																			'title': title,'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id}))])
			if progress:
				mark_entries.append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'watched_status.mark_tvshow', 'action': 'mark_as_unwatched',
																			'title': title, 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id}))])
			shared_props = self._shared_cm(cm, meta, 'tvshow', title, tmdb_id, imdb_id, tvdb_id, poster, premiered,
										after={'trakt_manager': after_trakt, 'simkl_manager': after_simkl}, mark_entries=mark_entries,
										exit_label='[B]Exit TV Show List[/B]')
			_counts = lambda n: '' if meta_get('light_meta') else str(n)   # a light row does not know its episode counts
			set_properties({'watchedepisodes': str(total_watched), 'unwatchedepisodes': _counts(total_unwatched)})
			# LOCAL PATCH 2026-10-24: totalseasons counted as the lists count (cours for anime: The Apothecary Diaries 3, not TMDb's 1)
			set_properties({'watchedprogress': visible_progress, 'totalepisodes': _counts(total_aired_eps), 'totalseasons': _counts(shown_season_count(meta))})
			cm = self.context_menu(cm)
			listitem.setLabel(label)
			listitem.addContextMenuItems(cm)
			# LOCAL PATCH 2026-08-06: extra_fanart_list feeds AF3's fanart cycler (ListItem.Art(fanart1)..(fanart20)).
			# LOCAL PATCH 2026-09-15: no cap here -- metadata._EXTRA_FANART_CAP bounds the list when it is built.
			# LOCAL PATCH 2026-09-14: tvshow. art keys dropped, see the note at _art in indexers/episodes.py.
			art = {'poster': poster, 'fanart': fanart, 'clearlogo': clearlogo, 'landscape': landscape, 'thumb': thumb, 'icon': landscape}
			try:
				for _idx, _bg in enumerate(meta_get('extra_fanart_list') or [], start=1):
					art['fanart%d' % _idx] = _bg
			except Exception: pass
			listitem.setArt(art)
			info_tag = kodi_utils.video_info_tag(listitem)
			info_tag.setMediaType('tvshow'), info_tag.setTitle(label), info_tag.setTvShowTitle(title), info_tag.setOriginalTitle(meta_get('original_title'))
			info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str(tmdb_id), 'tvdb': str(tvdb_id)}), info_tag.setIMDBNumber(imdb_id)
			info_tag.setPlot(meta_get('plot')), info_tag.setPlaycount(playcount), info_tag.setGenres(display_genres(meta)), (year and info_tag.setYear(int(year)))
			info_tag.setTagLine(meta_get('tagline')), info_tag.setStudios(meta_get('studio')), info_tag.setWriters(meta_get('writer')), info_tag.setDirectors(meta_get('director'))
			info_tag.setVotes(meta_get('votes')), info_tag.setMpaa(meta_get('mpaa')), info_tag.setDuration(meta_get('duration')), info_tag.setCountries(meta_get('country'))
			info_tag.setTrailer(trailer), info_tag.setPremiered(premiered)
			info_tag.setTvShowStatus(meta_get('status')), info_tag.setRating(meta_get('rating'))
			cast = meta_get('short_cast', []) or meta_get('cast', []) or []
			info_tag.setCast([self.kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
			set_properties({
				'deadlight.extras_params': extras_params,
				'deadlight.options_params': options_params,
				**shared_props
				})
			extra_props = extra_rating_props(meta)
			# LOCAL PATCH 2026-10-13: AF3's status chip -- full for shows being / been watched; the rest get the request-free
			# light one, so TMDb Helper's stale 'Returning <date>' shows only where DeadLight knows nothing
			extra_props.update(show_status_props(meta, light=not total_watched))
			# LOCAL PATCH 2026-10-24: AF3's Anime rating slots (Skin settings > Ratings > Anime) are chosen on this
			if is_anime_check(meta): extra_props['deadlight.anime'] = 'true'
			# LOCAL PATCH 2026-10-25: AF3's facts line shows it in place of the year when the show has no status (deadlight.state
			# already says 'Premieres Saturday' for one whose next episode is its premiere)
			_release = release_label(premiered, movie=False)
			if _release: extra_props['deadlight.release'] = _release
			if extra_props: set_properties(extra_props)
			self.append(((url_params, listitem, self.is_folder), _position))
		except: kodi_utils.log_row_error('tvshows')

	def worker(self):
		self.kodi_actor, self.make_listitem, self.build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
		self.poster_empty, self.fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
		self.current_date, self.current_time = get_datetime(), get_current_timestamp()
		self.mpaa_region = settings.mpaa_region()
		self.ai_model_active = settings.ai_model_active()
		rpdb_info = settings.rpdb_info('tvshow')
		self.rpdb_api_key, self.rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
		self.all_episodes, self.open_extras = settings.default_all_episodes(), settings.media_open_action('tvshow') == 1
		self.cm_sort_order = settings.cm_sort_order()
		self.custom_cm_menu = self.cm_sort_order != settings.cm_default_order()
		from modules.smartplay_utils import pinned_ids
		self.pinned = pinned_ids()   # LOCAL PATCH 2026-09-27: Clear SmartPlay Pin on the context menu
		# LOCAL PATCH 2026-09-04: read once here, not per item; the 'anilist_manager' half skips the gate when the entry
		# is turned off.
		self.anilist_cm_active = 'anilist_manager' in self.cm_sort_order and (settings.anilist_user_active() or settings.mal_user_active())
		self.is_folder = False if self.open_extras else True
		self.watched_indicators = settings.watched_indicators()
		self.watched_info = watched_status.watched_info_tvshow(watched_status.get_database(self.watched_indicators))
		self._load_dropped_set()
		self.window_command = 'ActivateWindow(Videos,%s,return)' if self.is_external else 'Container.Update(%s)'
		return self._run_builders(self.build_tvshow_content)

	EXEMPT_FROM_DROP_FILTER = frozenset({
		'trakt_dropped', 'dropped_tvshows',
		'trakt_collection', 'trakt_collection_lists',
		'trakt_watchlist', 'trakt_watchlist_lists',
		'trakt_favorites',
		'in_progress_tvshows', 'watched_tvshows', 'recent_watched_tvshows',
		'favorites_tvshows', 'favorites_anime',
	})

	def _load_dropped_set(self):
		if hasattr(self, 'dropped_set'): return self.dropped_set
		self.dropped_set = set()
		# LOCAL PATCH 2026-07-28 / 2026-07-29: dropped set from the watched-indicator provider (Trakt 1, MDBList 2,
		# SIMKL 3); for SIMKL "hold" counts as hidden too.
		chosen = settings.watched_indicators()
		if chosen == 2 and settings.mdblist_user_active():
			try:
				from apis.mdblist_api import mdbl_get_hidden_items
				self.dropped_set = set(int(i) for i in (mdbl_get_hidden_items('dropped') or []) if i)
			except: pass
			return self.dropped_set
		if chosen == 3 and settings.simkl_user_active():
			try:
				from apis.simkl_api import simkl_list
				hidden = set()
				# LOCAL PATCH 2026-07-30: cover anime too — SIMKL splits shows vs anime.
				for list_type in ('shows', 'anime'):
					for status in ('dropped', 'hold'):
						data = simkl_list(list_type, status) or {}
						for it in (data.get(list_type) or []):
							tmdb = (it.get('show') or {}).get('ids', {}).get('tmdb')
							if tmdb: hidden.add(int(tmdb))
				self.dropped_set = hidden
			except: pass
			return self.dropped_set
		if not settings.trakt_user_active(): return self.dropped_set
		try:
			from apis.trakt_api import trakt_get_hidden_items
			self.dropped_set = set(int(i) for i in (trakt_get_hidden_items('dropped') or []) if i)
		except: pass
		return self.dropped_set

	def _maybe_filter_dropped(self):
		from caches.settings_cache import get_setting as _get_setting
		if _get_setting('deadlight.dropshow.hide_from_lists', 'true') != 'true': return
		if self.action in self.EXEMPT_FROM_DROP_FILTER: return
		dropped = self._load_dropped_set()
		if not dropped or not self.list: return
		if self.id_type == 'tmdb_id':
			self.list = [i for i in self.list if i and int(i) not in dropped]
		elif self.id_type == 'trakt_dict':
			def _ok(d):
				try: return not (d.get('tmdb') and int(d['tmdb']) in dropped)
				except: return True
			self.list = [i for i in self.list if _ok(i)]

