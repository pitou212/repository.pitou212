# -*- coding: utf-8 -*-
from operator import itemgetter
from caches.meta_cache import meta_cache
from apis.tmdb_api import movie_details, tvshow_details, season_episodes_details, movie_set_details, movie_external_id, tvshow_external_id, \
								episode_groups_data, episode_group_details
from modules.utils import jsondate_to_datetime, subtract_dates, datetime_workaround
# from modules.kodi_utils import logger

# LOCAL PATCH 2026-08-26: per-season trailers. This preference cascade was written
# inline twice (movie_meta and tvshow_meta); it is now shared so each TMDb season's
# videos can be reduced the same way the show's are.
# LOCAL PATCH 2026-08-26: prefer an English-intelligible trailer.
# TMDb already returns only the en-US locale (tvshow_details passes language=en), so
# iso_639_1 is 'en' on every row and cannot discriminate -- the signal lives in the
# NAME: "[Subtitled]", "Official Subtitled Trailer", "English Subbed", "English Dub".
# Anime shows often carry both a raw Japanese trailer and a subbed one; without this
# the pick was arbitrary (first alphabetically after the name sort). Subtitled outranks
# dubbed, and both outrank an unmarked trailer. For English-language shows nothing
# matches and the original cascade below runs untouched.
_SUB_HINTS = ('subtitled', 'subbed', 'eng sub', 'english sub', 'with subtitles')
_ENG_HINTS = ('english trailer', 'english dub', 'dub trailer', 'english')


def _name_has(video, hints):
	try: return any(h in (video.get('name') or '').lower() for h in hints)
	except Exception: return False


# LOCAL PATCH 2026-10-09: trailers newest first (were sorted by NAME, so 'Official Trailer' beat 'Official Trailer 3': Dune Part
# Two played its first trailer, 2023-05-02, not the last before release, 2023-12-12). A video published more than a week after
# `release` (the film's release date, the show's first air date, the season's air date) goes behind the rest, so an anniversary
# or 4K re-release trailer, or a later season's trailer filed under the show, never wins. The pickers' preference order is
# unchanged; this only decides which of equally good trailers comes first. YouTube videos only, as before.
def _trailer_cutoff(release):
	try:
		import datetime
		return (datetime.date(*[int(x) for x in release[:10].split('-')]) + datetime.timedelta(days=7)).isoformat() if release else ''
	except Exception: return ''

def _late(video, cutoff): return bool(cutoff and (video.get('published_at') or '')[:10] > cutoff)

def _trailers_newest_first(videos, release=''):
	cutoff = _trailer_cutoff(release)
	youtube = [i for i in (videos or []) if i.get('site') == 'YouTube']
	# LOCAL PATCH 2026-10-19: the details requests now also ask for the original-language videos (tmdb_api
	# _VIDEO_LANGUAGES) -- 22 of 120 sampled trailer-less titles had trailers only in Hindi, Japanese or Tamil (Paatal Lok,
	# Made in Abyss, Jailer 2). English or untagged ones still win outright: only when there are none do the rest count.
	english = [i for i in youtube if i.get('iso_639_1') in (None, '', 'en', 'xx')]
	if english: youtube = english
	newest = sorted(youtube, key=lambda v: v.get('published_at') or '', reverse=True)
	return sorted(newest, key=lambda v: _late(v, cutoff))   # stable: newest kept within each

def _pick_on_time(pick, videos, release=''):
	"""pick() over the videos published by the release first, then over all of them: the pickers check their preference tiers
	across the whole list, so ordering alone would still let a re-release named 'Official Trailer' beat an original named
	'Trailer 1'. A film older than YouTube has only re-release trailers, and gets the best of those."""
	cutoff = _trailer_cutoff(release)
	on_time = [v for v in videos if not _late(v, cutoff)]
	return (pick(on_time) if on_time else '') or pick(videos)


def _pick_trailer(youtube_videos, youtube_url):
	"""Best YouTube trailer from a TMDb videos list, as a playable URL, or ''.
	Order: official 'official trailer' -> official Trailer -> any Trailer ->
	anything named trailer -> anything at all."""
	if not youtube_videos: return ''
	try:
		trailers = [i for i in youtube_videos if i.get('type') == 'Trailer']
		for hints in (_SUB_HINTS, _ENG_HINTS):
			preferred = [i for i in trailers if _name_has(i, hints)]
			if preferred:
				best = next((i for i in preferred if i.get('official')), preferred[0])
				return youtube_url % best['key']
	except Exception: pass
	try:
		return \
		next((youtube_url % i['key'] for i in youtube_videos if i['official'] and i['type'] == 'Trailer' and 'official trailer' in i['name'].lower()), None) or \
		next((youtube_url % i['key'] for i in youtube_videos if i['official'] and i['type'] == 'Trailer'), None) or \
		next((youtube_url % i['key'] for i in youtube_videos if i['type'] == 'Trailer'), None) or \
		next((youtube_url % i['key'] for i in youtube_videos if 'trailer' in i['name'].lower()), None) or \
		next((youtube_url % i['key'] for i in youtube_videos), None) or ''
	except Exception:
		return ''


def _season_trailers(data_get, youtube_url):
	"""{season_number: trailer_url} from the season/N/videos blocks appended to the
	show request by apis/tmdb_api.tvshow_details. Only the chosen URL is kept -- the
	raw video arrays are discarded so meta grows ~60 bytes per season, not 2-5KB.
	Seasons the show does not have are absent from the response and simply skipped."""
	out = {}
	try: air_dates = {int(s['season_number']): s.get('air_date') or '' for s in (data_get('seasons', None) or [])}
	except Exception: air_dates = {}
	for season_no in range(1, 13):
		try:
			block = data_get('season/%d/videos' % season_no, None)
			if not block: continue
			# LOCAL PATCH 2026-10-09: only a Trailer or Teaser is a season trailer. A season TMDb gives only clips for (Reacher S1:
			# 'Epic Fight Scenes') used to play a clip and, counting as covered, never reached the fallbacks; now it has none, so
			# season_trailer_for hands season 1 the show trailer and seasons 2+ the YouTube search at play time.
			# LOCAL PATCH 2026-10-23: a Teaser published on or after the season's air date is a launch promo ('Stream Now on
			# Disney+', 'Don't Miss'), not a trailer. VisionQuest S1 lists only those -- the real trailers sit on the show -- so
			# the newest promo won. Such a season now has none and falls back like Reacher S1 above.
			air = air_dates.get(season_no, '')
			yt = [v for v in _trailers_newest_first(block.get('results'), air) if v.get('type') == 'Trailer'
				or (v.get('type') == 'Teaser' and not (air and (v.get('published_at') or '')[:10] >= air[:10]))]
			if not yt: continue
			url = _pick_on_time(lambda v: _pick_trailer(v, youtube_url), yt, air_dates.get(season_no, ''))
			if url: out[season_no] = url
		except Exception: continue
	return out


def season_trailer_for(meta, season_number, fallback=''):
	"""Trailer for one TMDb season. Callers pass season numbers as int or str
	depending on the code path, hence the cast.

	TMDb only covers ~57% of seasons. For the rest we hand back a plugin URL that
	searches YouTube AT PLAY TIME (apis/youtube_api.play_resolved_trailer) rather
	than searching now -- a search costs ~740KB/~0.7s and browsing must stay free.
	That resolver falls back to `fallback` itself, so behaviour is never worse."""
	try:
		# Key lookup is int-OR-str on purpose: the cache layer may serialise this dict
		# as JSON, which stringifies int keys. Tolerating both keeps the consumer
		# independent of the storage format, instead of a coercion table that a future
		# int-keyed dict would silently escape.
		_st = meta.get('season_trailers') or {}
		direct = _st.get(int(season_number)) or _st.get(str(int(season_number)))
		if direct: return direct
	except Exception:
		return fallback
	try:
		tmdb_id = meta.get('tmdb_id')
		# Seasons 2+ only -- see apis/youtube_api.find_season_trailer.
		if tmdb_id and int(season_number) > 1:
			from modules.kodi_utils import build_url
			return build_url({'mode': 'resolve_yt_trailer', 'tmdb_id': tmdb_id, 'season': season_number})
	except Exception: pass
	return fallback


# LOCAL PATCH 2026-05-28: inline OMDb rating fetch during meta build. When a meta dict is being
# constructed (cold cache for the item), also pull IMDb/RT/MetaCritic ratings from OMDb so the
# AF3 rating chip reads them instantly from ListItem.Property on first focus — no async lag.
# Cost: ~300-1500ms per cold item. Mitigated by indexers using TaskPool for parallel meta
# builds. After the first cache hit, OMDb data is part of meta_cache; no further OMDb calls.
def _fetch_omdb_for_meta(meta):
	try:
		from caches.settings_cache import get_setting
		if get_setting('deadlight.omdb.title_ratings', 'true') != 'true': return  # LOCAL PATCH 2026-09-28, see settings_cache
		omdb_key = get_setting('deadlight.omdb_api', '')
		if not omdb_key or omdb_key in ('empty_setting', ''):
			return
		# LOCAL PATCH 2026-10-04: 'imdb', not any block -- an AniList-only one must not stand in for OMDb's.
		if not meta.get('imdb_id') or 'imdb' in (meta.get('extra_ratings') or {}):
			return
		from apis.omdb_api import fetch_ratings_info, omdb_on_cooldown
		# LOCAL PATCH 2026-08-26 (perf): third early return -- skip entirely while the key
		# is known rate-limited or invalid. Without this, every cold item paid ~700ms for a
		# guaranteed 401; a 6-widget cold home burned ~5.5s on them.
		if omdb_on_cooldown(): return
		fetch_ratings_info(meta, omdb_key)
	except Exception: pass

# LOCAL PATCH 2026-09-07: OMDb backfill on the CACHE-HIT path. _fetch_omdb_for_meta above
# runs only while a meta is being BUILT, and movie_meta / tvshow_meta return a cached meta
# before reaching it -- so any meta cached without ratings (built before the OMDb patch,
# during a key cooldown, or while the network was down) stayed that way for its whole TTL:
# up to 4368h for ended shows and older films. metacache.db on 2026-09-07 held 1153 metas
# with an IMDb id, 118 of them (10%) with no ratings. Those are exactly the items that show
# no rating chip on first focus: no DeadLight fallback exists for them, so they depend
# entirely on TMDbHelper's per-focus fetch and inherit its timing races.
#
# This runs on a hot path, so it must be free when there is nothing to do (one dict lookup
# on extra_ratings) and bounded when there is. On success, OMDbAPI.process_result already
# persists extra_ratings to meta_cache itself -- and it always writes a populated dict, even
# when every value is N/A, so a successful lookup never repeats. Failures are the problem:
# get_result returns None for both a network blip and an IMDb id OMDb does not know (many
# of the 118 are 2025/2026 releases), and writes nothing. Without a marker each would retry
# on every render at ~700ms. So a failed attempt is stamped into the meta and retried at
# most once per _BACKFILL_RETRY_HOURS. A key cooldown does NOT burn the attempt: it lifts on
# its own and the item should be tried the moment it does.
_BACKFILL_RETRY_HOURS = 24

def _backfill_omdb(meta, current_date, current_time=None):
	try:
		if not isinstance(meta, dict) or 'imdb' in (meta.get('extra_ratings') or {}) or meta.get('blank_entry'): return
		imdb_id = meta.get('imdb_id')
		if not imdb_id or imdb_id == 'tt0000000': return
		from modules.utils import get_current_timestamp
		now = current_time or get_current_timestamp()
		if now - (meta.get('omdb_backfill_ts') or 0) < _BACKFILL_RETRY_HOURS * 3600: return
		from caches.settings_cache import get_setting
		if get_setting('deadlight.omdb.title_ratings', 'true') != 'true': return  # LOCAL PATCH 2026-09-28, see settings_cache
		omdb_key = get_setting('deadlight.omdb_api', '')
		if not omdb_key or omdb_key == 'empty_setting': return
		from apis.omdb_api import fetch_ratings_info, omdb_on_cooldown
		if omdb_on_cooldown(): return
		from modules.kodi_utils import logger
		title = (meta.get('title') or '')[:40]
		fetch_ratings_info(meta, omdb_key)
		if 'imdb' in (meta.get('extra_ratings') or {}):
			logger('OMDb backfill', 'filled %s (%s)' % (imdb_id, title))
			return
		meta['omdb_backfill_ts'] = now
		media_type = meta.get('mediatype')
		expiry_function = movie_expiry if media_type == 'movie' else tvshow_expiry
		meta_cache.set(media_type, 'tmdb_id', meta, expiry_function(current_date, meta), current_time)
		logger('OMDb backfill', 'no data for %s (%s); next try in %dh' % (imdb_id, title, _BACKFILL_RETRY_HOURS))
	except Exception: pass

# LOCAL PATCH 2026-09-15: AniList score on the GENERAL TV meta path.
#
# indexers/anilist_lists.py has set extra_anilist_rating since 2026-09-05, but only for rows
# that came OUT of an AniList browse -- there the score rides along in the page payload and
# costs nothing. Every other TV list builds its rows from TMDb, so AF3's AniList chip (one of
# the three configured for tvshows, beside IMDb and RT-User) had no source anywhere else and
# sat blank on all 119 cached anime shows.
#
# Anime only, and the gate is is_anime_check -- the same TMDb keyword 210024 test used
# everywhere else -- so a Western show never touches the Fribb index or the network.
_ANILIST_BACKFILL_RETRY_HOURS = 24


def _anilist_id_for_show(tmdb_id):
	return (_first_cour_row(tmdb_id, 'anilist_id') or {}).get('anilist_id')


def _mal_id_for_show(tmdb_id):
	"""LOCAL PATCH 2026-10-15: the MAL id for the show, picked exactly as the AniList one (MAL also lists per cour)."""
	return (_first_cour_row(tmdb_id, 'mal_id') or {}).get('mal_id')


def _first_cour_row(tmdb_id, id_key):
	"""The Fribb row standing for the SHOW: first cour of its lowest real season.

	AniList rates each cour separately while TMDb carries the whole franchise as one show,
	so there is no single "correct" id -- season 1 is the defensible, deterministic pick and
	matches what the season rows already do. Fribb files one row per cour; season 0 rows are
	specials and are pushed last. season and episode_offset arrive as {'tvdb': n, 'tmdb': n},
	as a bare number, or as null, so both shapes are normalised before sorting -- comparing
	them raw raises TypeError on the mixed rows (JoJo's ten rows are exactly this shape).
	"""
	try:
		from caches.fribb_mappings import tmdb_tv_to_fribb_rows
		rows = [r for r in (tmdb_tv_to_fribb_rows(tmdb_id) or []) if isinstance(r, dict) and r.get(id_key)]
		if not rows: return None
		def _num(v):
			if isinstance(v, dict):
				v = v.get('tvdb') if v.get('tvdb') is not None else v.get('tmdb')
			try: return int(v)
			except (TypeError, ValueError): return 0
		rows.sort(key=lambda r: (_num(r.get('season')) or 99, _num(r.get('episode_offset'))))
		return rows[0]
	except Exception:
		return None


def _anilist_needs_fields(meta):
	"""LOCAL PATCH 2026-10-15: tags (2026-10-07) or genres (2026-10-15) never fetched -- a meta cached before either asks once."""
	return 'anilist_tags' not in meta or 'anilist_genres' not in meta


def _has_anilist_score(meta):
	current = str(((meta.get('extra_ratings') or {}).get('anilist') or {}).get('rating') or '').strip()
	return bool(current) and current != 'N/A'


def display_genres(meta):
	"""LOCAL PATCH 2026-10-07: the genres a list item shows. On anime AniList's tags ('Isekai', 'Female Protagonist', ...)
	replace TMDb's genres, which say 'Animation, Action & Adventure' on nearly everything. meta['genre'] itself is left as
	TMDb's: untagged_japanese_animation reads 'Animation' in it to recognise anime. An anime AniList has no usable tags for
	(the key is there, empty) keeps TMDb's genres without 'Animation', which says nothing on an anime."""
	meta = meta or {}
	# LOCAL PATCH 2026-10-15: which list is the setting's (anime.genre_provider); the other provider, then TMDb, when it has none
	if 'anilist_tags' in meta or 'mal_info' in meta:
		from modules.settings import anime_provider
		choice = anime_provider('genre')
		mal_genres = (meta.get('mal_info') or {}).get('genres')
		if choice == 'mal' and mal_genres: return mal_genres
		if choice != 'tmdb':
			if meta.get('anilist_tags'): return meta['anilist_tags']
			if mal_genres: return mal_genres
			if meta.get('anilist_genres'): return meta['anilist_genres']
	genre = meta.get('genre') or []
	if 'anilist_tags' in meta: genre = [g for g in genre if g != 'Animation']
	return genre


def anime_choice_props(meta, props):
	"""LOCAL PATCH 2026-10-15: apply the anime metadata choices to a list item's extra properties (from
	utils.extra_rating_props). Score: keep the chosen chip -- the other one stays when the chosen has no score, and 'both'
	keeps both."""
	if not isinstance(meta, dict) or not ('mal_info' in meta or 'anilist_tags' in meta): return props
	from modules.settings import anime_provider
	score = anime_provider('score')
	if score == 'anilist' and props.get('extra_anilist_rating'): props.pop('extra_mal_rating', None)
	elif score == 'mal' and props.get('extra_mal_rating'): props.pop('extra_anilist_rating', None)
	return props


def _fetch_anilist_for_meta(meta):
	"""Build-path fetch. Mutates meta only -- tvshow_meta caches it on the next line. True when it stored a score or the
	tags (LOCAL PATCH 2026-10-07: one request brings both; 'anilist_tags' is stored even empty, so it is asked for once)."""
	try:
		if not isinstance(meta, dict) or meta.get('blank_entry'): return False
		if _has_anilist_score(meta) and not _anilist_needs_fields(meta): return False
		if not meta.get('tmdb_id') or not is_anime_check(meta): return False
		from apis.anilist_api import anilist_score_and_tags, anilist_score_on_cooldown
		if anilist_score_on_cooldown(): return False
		anilist_id = _anilist_id_for_show(meta.get('tmdb_id'))
		if not anilist_id: return False
		got = anilist_score_and_tags(anilist_id)
		if got is None: return False
		changed = _anilist_needs_fields(meta) or meta.get('anilist_tags') != got['tags']
		meta['anilist_tags'] = got['tags']
		# LOCAL PATCH 2026-10-15: genres ride along (stored even empty, so asked for once)
		meta['anilist_genres'] = got.get('genres') or []
		if got['score'] and not _has_anilist_score(meta):
			existing = dict(meta.get('extra_ratings') or {})
			existing['anilist'] = {'rating': got['score'], 'icon': 'anilist.png'}
			meta['extra_ratings'] = existing
			changed = True
		return changed
	except Exception:
		return False


def _backfill_anilist(meta, current_date, current_time=None):
	"""Cache-hit counterpart, mirroring _backfill_omdb. Its own stamp: a show AniList has no
	score for is not one OMDb has nothing for, and a shared marker would let either provider's
	miss suppress the other's retry. A rate-limit cooldown never burns the attempt."""
	try:
		if not isinstance(meta, dict) or meta.get('blank_entry'): return
		if not meta.get('tmdb_id'): return
		# LOCAL PATCH 2026-10-07: also when the tags were never fetched -- that once, whatever the retry stamp says
		need_tags = _anilist_needs_fields(meta)
		if _has_anilist_score(meta) and not need_tags: return
		from modules.utils import get_current_timestamp
		now = current_time or get_current_timestamp()
		if not need_tags and now - (meta.get('anilist_backfill_ts') or 0) < _ANILIST_BACKFILL_RETRY_HOURS * 3600: return
		from apis.anilist_api import anilist_score_on_cooldown
		if anilist_score_on_cooldown(): return
		if not is_anime_check(meta): return
		if _fetch_anilist_for_meta(meta):
			if not _has_anilist_score(meta): meta['anilist_backfill_ts'] = now   # tags in, no score: the score retries daily
			meta_cache.set('tvshow', 'tmdb_id', meta, tvshow_expiry(current_date, meta), current_time)
			from modules.kodi_utils import logger
			logger('AniList ratings', 'tmdb %s: score %s, tags %s' % (meta.get('tmdb_id'),
					(meta.get('extra_ratings') or {}).get('anilist', {}).get('rating'), ', '.join(meta.get('anilist_tags') or []) or '-'))
			return
		if anilist_score_on_cooldown(): return
		meta['anilist_backfill_ts'] = now
		meta_cache.set('tvshow', 'tmdb_id', meta, tvshow_expiry(current_date, meta), current_time)
	except Exception: pass


_MAL_BACKFILL_RETRY_HOURS = 24

def _mal_wanted():
	"""LOCAL PATCH 2026-10-15: MAL is asked only when a setting chooses it (score MAL / both, genres MAL)."""
	from modules.settings import anime_provider
	return anime_provider('score') in ('mal', 'both') or anime_provider('genre') == 'mal'


def _backfill_mal(meta, current_date, current_time=None):
	"""LOCAL PATCH 2026-10-15: MAL score / genres into meta['mal_info'], the score also into
	extra_ratings['myanimelist'] (AF3's MAL chip, utils.extra_rating_props). Its own retry stamp, as AniList's."""
	try:
		if not isinstance(meta, dict) or meta.get('blank_entry') or not meta.get('tmdb_id'): return
		if 'mal_info' in meta or not _mal_wanted(): return
		from modules.utils import get_current_timestamp
		now = current_time or get_current_timestamp()
		if now - (meta.get('mal_backfill_ts') or 0) < _MAL_BACKFILL_RETRY_HOURS * 3600: return
		from apis.mal_api import mal_metadata_available, mal_anime_info
		if not mal_metadata_available() or not is_anime_check(meta): return
		mal_id = _mal_id_for_show(meta.get('tmdb_id'))
		info = mal_anime_info(mal_id) if mal_id else {}
		if info is None: return   # MAL did not answer: asked again on the next listing, nothing stored
		if info:
			meta['mal_info'] = info
			if info.get('score'):
				existing = dict(meta.get('extra_ratings') or {})
				existing['myanimelist'] = {'rating': info['score'], 'icon': 'mal.png'}
				meta['extra_ratings'] = existing
			meta.pop('mal_backfill_ts', None)
		else: meta['mal_backfill_ts'] = now   # no MAL id / no entry: retried daily
		meta_cache.set('tvshow', 'tmdb_id', meta, tvshow_expiry(current_date, meta), current_time)
		from modules.kodi_utils import logger
		logger('MAL metadata', 'tmdb %s mal %s: %s' % (meta.get('tmdb_id'), mal_id or '-',
				'score %s, %d genres' % (info.get('score'), len(info.get('genres') or [])) if info else 'nothing'))
	except Exception: pass


# LOCAL PATCH 2026-09-26: rating backfills run AFTER a directory listing is delivered.
#
# The backfills above are network calls made while a tile is being built, and the page joins
# every worker before endOfDirectory -- so the whole list waited for them. MDBList is also
# paced at 0.25 s per call across all threads (its burst limit), which made the pacer the page's
# floor. Measured on 40 cached TV tiles: 109 ms clean, 923 / 1696 / 3336 ms with 2 / 6 / 12
# stale titles; a cold 40-tile page could not finish in under 10 s of pacing alone.
#
# In a listing process (a real plugin handle in sys.argv[1]) the calls are queued instead and
# deadlight.py runs flush_rating_backfills() once routing() has returned -- after
# endOfDirectory, so the list is already on screen and the next render picks up what the
# flush stored. The same functions run, so the stamps, the cooldown rules and the precedence
# (OMDb, then AniList) are unchanged; the chain for any one title keeps its order, titles run
# in parallel as they did during the build. Cold builds keep OMDb inline (unpaced, already
# parallel) and defer only AniList. (MDBList ratings were a third link until 2026-09-29.)
#
# Everything with no handle -- the service, RunPlugin actions, playback, windows -- keeps the
# inline behaviour: _DEFERRED stays None there.
def _listing_process():
	try:
		import sys
		return int(sys.argv[1]) >= 0
	except Exception: return False

_DEFERRED = [] if _listing_process() else None

def _backfill_or_defer(meta, current_date, current_time, chain):
	# LOCAL PATCH 2026-10-19: with no directory handle (playback, mark watched, the Extras window, RunPlugin actions) the
	# chain is dropped instead of run inline: ratings / AniList / MAL / art / air-time refreshes made those actions wait on
	# requests whose answer they cannot show. The same metas queue again on the next listing that shows them.
	if _DEFERRED is not None: _DEFERRED.append((meta, current_date, current_time, chain))

def _prime_anilist_scores(chains):
	"""LOCAL PATCH 2026-10-03 (3.0.8): one bulk AniList request for every title about to run _backfill_anilist and
	pass its cheap gates (anilist_api.anilist_scores_bulk); each backfill then reads its score from that."""
	try:
		from modules.utils import get_current_timestamp
		now, ids = get_current_timestamp(), []
		for meta, _d, current_time, chain in chains:
			if _backfill_anilist not in chain or not isinstance(meta, dict) or meta.get('blank_entry') or not meta.get('tmdb_id'): continue
			need_tags = _anilist_needs_fields(meta)   # LOCAL PATCH 2026-10-07, as in _backfill_anilist
			if _has_anilist_score(meta) and not need_tags: continue
			if not need_tags and (current_time or now) - (meta.get('anilist_backfill_ts') or 0) < _ANILIST_BACKFILL_RETRY_HOURS * 3600: continue
			if not is_anime_check(meta): continue
			anilist_id = _anilist_id_for_show(meta.get('tmdb_id'))
			if anilist_id: ids.append(anilist_id)
		if len(ids) > 1:
			from apis.anilist_api import anilist_scores_bulk
			anilist_scores_bulk(ids)
	except Exception: pass

def flush_rating_backfills():
	global _DEFERRED
	pending, _DEFERRED = _DEFERRED, None
	if not pending: return
	# LOCAL PATCH 2026-09-27: not on a home-screen widget call. Widgets load in bursts (a refresh reloads
	# every one, playback stopping triggers one), and a native dump of a hung Kodi (21:10) showed its Python
	# deadlocked tearing down one finished call while ~25 threads of the others waited on the GIL. The
	# backfill is up to 8 network threads per call at exactly that moment. The metas stay stale, so the
	# same titles queue again on the next in-addon browse and fill in there.
	try:
		from modules.kodi_utils import external, logger_debug
		if external():
			logger_debug('rating backfill', 'skipped %d title(s) on a widget call' % len(pending))   # LOCAL PATCH 2026-10-25 (4.0.5): DEBUG, every widget call
			return
	except Exception: pass
	# One chain per title: the same title can be queued twice (a list and its widget row), and
	# its second run would only find its own fresh stamps anyway.
	# LOCAL PATCH 2026-10-20: per STEP, not per whole chain. A title built in this call queues (art) and (AniList, MAL);
	# asked for again in the same call (two rows of one show, a movie on a TV page) its cache hit queues (OMDb, AniList,
	# MAL, art) -- three different chains, all run, in parallel: the 10-20 trace caught fanart.tv and TMDb /images fetched
	# twice at the same instant, and AniList / MAL would be too. Worse, each chain wrote ITS meta object back to the cache,
	# so the last to finish dropped what the others had added. Now every title-level step (anything but the per-season
	# ones, which keep their own chains and still run in parallel) goes into ONE chain per title, each step once, on one
	# meta, in queue order -- the longest chain first, so OMDb still leads AniList as before.
	chains, seen, titles = [], set(), {}
	for meta, current_date, current_time, chain in sorted(pending, key=lambda p: -len(p[3])):
		title_key = (meta.get('mediatype'), meta.get('tmdb_id'))
		season_steps = tuple(f for f in chain if isinstance(f, (_SeasonBackfill, _TvAirRedo)))
		title_steps = [f for f in chain if f not in season_steps]
		if title_steps:
			entry = titles.get(title_key)
			if entry is None: titles[title_key] = [meta, current_date, current_time, title_steps]
			else:
				if not entry[0].get('art_pending') and meta.get('art_pending'): entry[0]['art_pending'] = meta['art_pending']
				entry[3].extend(f for f in title_steps if f not in entry[3])
		if season_steps:
			key = title_key + (season_steps,)
			if key in seen: continue
			seen.add(key)
			chains.append((meta, current_date, current_time, season_steps))
	# LOCAL PATCH 2026-10-20: and per title ACROSS calls. A season list's flush was still fetching a show's AniList score and
	# MAL data when its episode list (a new call, opened a second later) read the show without them and queued the same
	# steps -- the 10-20 log has 4 of 10 anime fetched twice that way. A call claims each title in a window property while
	# its chain runs; another call that finds a claim younger than _BACKFILL_BUSY_SECONDS leaves that title alone (the
	# claiming call stores the result; a later listing that still finds it stale queues it again).
	# LOCAL PATCH 2026-10-20 (3.0.15): the claim outlives the chain -- re-stamped with the finish time, it reads "just done"
	# for _BACKFILL_BUSY_SECONDS more. An episode list that read the show a second BEFORE the season list's flush stored it
	# ran its own flush just AFTER that one released the claim, and fetched the same AniList score and MAL data again
	# (10-20 21:45:13 / :15, tmdb 286345). A call that failed leaves the same stamp; the next listing queues the title again.
	from modules.kodi_utils import get_property, set_property
	import time as _time
	now, claimed, title_chains = _time.time(), [], []
	for m, d, t, steps in titles.values():
		prop = 'deadlight.backfill_busy.%s.%s' % (m.get('mediatype'), m.get('tmdb_id'))
		try: busy = float(get_property(prop) or 0)
		except ValueError: busy = 0
		if now - busy < _BACKFILL_BUSY_SECONDS: continue
		set_property(prop, '%.3f' % now)
		claimed.append(prop)
		title_chains.append((m, d, t, tuple(steps)))
	chains = title_chains + chains
	_prime_anilist_scores(chains)
	def _run(meta, current_date, current_time, chain):
		for function in chain: function(meta, current_date, current_time)
	try:
		from modules.utils import TaskPool
		[i.join() for i in TaskPool().tasks(_run, chains, min(len(chains), 8))]
	except Exception:
		for item in chains: _run(*item)
	finally:
		done = '%.3f' % _time.time()
		for prop in claimed: set_property(prop, done)

_BACKFILL_BUSY_SECONDS = 30   # longer than any title chain runs; a call that died holding a claim blocks it no longer

# LOCAL PATCH 2026-10-03 (Batch 3): TMDb's "no such item" codes, the only refusals worth remembering. Anything
# else -- no answer at all (None) or an error body such as 25 (rate limit) or 7 (bad key) -- says nothing about
# the item, so it must not be cached as a blank entry or an empty season.
_TMDB_MISSING = (6, 34, 37)

def _tmdb_refused(data):
	if data is None: return True
	return isinstance(data, dict) and data.get('success') is False and data.get('status_code') not in _TMDB_MISSING

# LOCAL PATCH 2026-10-06: light search rows. A skin search row fetched the full details of all 20 results before it showed
# (~1.8 s of its ~2.6 s, cold connections rather than data: a details call without appends took as long). light_meta
# builds the record from the SEARCH answer itself -- title, year, plot, rating, votes, genres, poster, background -- with
# every other key the row builders read set empty, and 'light_meta' set. Never cached: the full details load as before
# when the title is opened or played. Used only by the skin's search rows (indexers/movies.py, tvshows.py), and only for
# titles whose details are not cached already (cached_meta) -- for TV only when there is no watch history to show.
_LIGHT_GENRES = {
	'movie': {28: 'Action', 12: 'Adventure', 16: 'Animation', 35: 'Comedy', 80: 'Crime', 99: 'Documentary', 18: 'Drama',
		10751: 'Family', 14: 'Fantasy', 36: 'History', 27: 'Horror', 10402: 'Music', 9648: 'Mystery', 10749: 'Romance',
		878: 'Science Fiction', 10770: 'TV Movie', 53: 'Thriller', 10752: 'War', 37: 'Western'},
	'tvshow': {10759: 'Action & Adventure', 16: 'Animation', 35: 'Comedy', 80: 'Crime', 99: 'Documentary', 18: 'Drama',
		10751: 'Family', 10762: 'Kids', 9648: 'Mystery', 10763: 'News', 10764: 'Reality', 10765: 'Sci-Fi & Fantasy',
		10766: 'Soap', 10767: 'Talk', 10768: 'War & Politics', 37: 'Western'}}

def light_meta(media_type, item):
	tmdb_image_url = 'https://image.tmdb.org/t/p/%s%s'
	movie = media_type == 'movie'
	tmdb_id = item.get('id')
	title = item.get('title' if movie else 'name') or ''
	premiered = item.get('release_date' if movie else 'first_air_date') or ''
	year = premiered.split('-')[0] if premiered else ''
	genres = _LIGHT_GENRES['movie' if movie else 'tvshow']
	meta = {'tmdb_id': tmdb_id, 'imdb_id': '', 'imdbnumber': '', 'tvdb_id': 'None', 'title': title, 'english_title': None,
		'original_title': item.get('original_title' if movie else 'original_name') or title, 'year': year, 'premiered': premiered,
		'rating': item.get('vote_average') or 0, 'votes': item.get('vote_count') or 0, 'plot': item.get('overview') or '', 'tagline': '',
		'genre': [genres[g] for g in item.get('genre_ids') or [] if g in genres], 'rootname': '%s (%s)' % (title, year),
		'poster': tmdb_image_url % ('w500', item['poster_path']) if item.get('poster_path') else '',
		'fanart': tmdb_image_url % ('original', item['backdrop_path']) if item.get('backdrop_path') else '',
		'rpdb_poster': 'https://api.ratingposterdb.com/%%s/tmdb/poster-default/%s-%s.jpg?fallback=true' % ('movie' if movie else 'series', tmdb_id),
		'landscape': '', 'clearlogo': '', 'extra_fanart_list': [], 'cast': [], 'short_cast': [], 'writer': [], 'director': [], 'studio': [],
		'country': [], 'country_codes': item.get('origin_country') or [], 'mpaa': '', 'duration': 0, 'trailer': '', 'all_trailers': [],
		'alternative_titles': [], 'keywords': {}, 'extra_info': {}, 'mediatype': 'movie' if movie else 'tvshow', 'light_meta': True}
	if not movie: meta.update({'status': '', 'total_seasons': 0, 'total_aired_eps': None, 'season_data': [], 'season_trailers': {}})
	return meta

def _region_fallback(pairs, region):
	"""LOCAL PATCH 2026-10-25 (4.0.5): [(iso_3166_1, certification)] -> the region's certification, else US's, else the first."""
	pairs = [(c, r) for c, r in pairs if r]
	for want in (region, 'US'):
		hit = next((r for c, r in pairs if c == want), None)
		if hit: return hit
	return pairs[0][1] if pairs else ''

def _region_stale(meta, mpaa_region):
	"""LOCAL PATCH 2026-10-25 (4.0.5): the certification is baked into the cached meta for the region it was built with,
	which the cache key does not carry. A meta built for another region is rebuilt. Rows from before carry no region and
	are kept (they age out) -- re-reading the whole cache on upgrade would cost one TMDb request per title shown."""
	try: return not meta.get('blank_entry') and meta.get('mpaa_region', mpaa_region) != mpaa_region
	except Exception: return False

def _overview_fallback(data_get):
	"""LOCAL PATCH 2026-10-25 (4.0.5): the original language's overview when the English one is empty -- only from
	'translations' already in the payload. NOTE: tmdb_api.movie_details / tvshow_details do not append translations
	today, so this answers '' until they do (no request is added here)."""
	try:
		lang = data_get('original_language')
		translations = (data_get('translations') or {}).get('translations') or []
		return next((i['data'].get('overview') for i in translations if i.get('iso_639_1') == lang and (i.get('data') or {}).get('overview')), '') or ''
	except Exception: return ''

def _blank_entry(id_type, media_id):
	"""The 24 h 'TMDb has no such title' entry. LOCAL PATCH 2026-10-25 (4.0.5): one looked up by IMDb / TVDB id is keyed
	'imdb:tt123' / 'tvdb:123' in the tmdb_id column -- it was '0000000', and metadata is unique on (db_type, tmdb_id), so
	each unmatched id overwrote the last and every one was asked of TMDb again on its next read."""
	if id_type == 'tmdb_id': return {'tmdb_id': media_id, 'imdb_id': 'tt0000000', 'tvdb_id': '0000000', 'blank_entry': True}
	meta = {'tmdb_id': '%s:%s' % (str(id_type).replace('_id', ''), media_id), 'imdb_id': 'tt0000000', 'tvdb_id': '0000000', 'blank_entry': True}
	meta[id_type] = media_id
	return meta

def cached_meta(media_type, tmdb_id, current_time=None):
	"""The cached full details, or None -- no network."""
	try: return meta_cache.get(media_type, 'tmdb_id', tmdb_id, current_time)
	except Exception: return None

# LOCAL PATCH 2026-10-16: titles served from the meta cache vs fetched from TMDb, for page_prefetch.log_page
META_COUNTS = {'cached': 0, 'fetched': 0}

def movie_meta(id_type, media_id, api_key, mpaa_region, current_date, current_time=None):
	if id_type == 'trakt_dict':
		if media_id.get('tmdb', None): id_type, media_id = 'tmdb_id', media_id['tmdb']
		elif media_id.get('imdb', None): id_type, media_id = 'imdb_id', media_id['imdb']
		else: id_type, media_id = None, None
	if media_id == None: return None
	meta = meta_cache.get('movie', id_type, media_id, current_time)
	if meta and _region_stale(meta, mpaa_region): meta = None   # LOCAL PATCH 2026-10-25 (4.0.5)
	META_COUNTS['cached' if meta else 'fetched'] += 1
	if meta:
		# LOCAL PATCH 2026-09-07 (OMDb); deferred in listings 2026-09-26. MDBList ratings removed 2026-09-29.
		_backfill_or_defer(meta, current_date, current_time, _with_art_backfill(meta, (_backfill_omdb,), 'movie', id_type))
		return meta
	try:
		if id_type in ('tmdb_id', 'imdb_id'): data = movie_details(media_id, api_key)
		else:
			external_result = movie_external_id(id_type, media_id, api_key)
			if not external_result: data = None
			else: data = movie_details(external_result['id'], api_key)
		if not data or _tmdb_refused(data): return None
		elif data.get('status_code') in _TMDB_MISSING:
			meta = _blank_entry(id_type, media_id)
			meta_cache.set('movie', id_type, meta, 24, current_time)
			return meta
		tmdb_image_url, youtube_url = 'https://image.tmdb.org/t/p/%s%s', 'plugin://plugin.video.youtube/play/?video_id=%s'
		data_get = data.get
		cast, short_cast, writer, director, all_trailers, country, country_codes, studio, stinger_keys = [], [], [], [], [], [], [], [], []
		mpaa, trailer = '', ''
		tmdb_id, imdb_id = data_get('id', ''), data_get('imdb_id', '')
		rating, votes = data_get('vote_average', ''), data_get('vote_count', '')
		plot, tagline, premiered = data_get('overview', ''), data_get('tagline', ''), data_get('release_date', '')
		if not plot: plot = _overview_fallback(data_get)   # LOCAL PATCH 2026-10-25 (4.0.5)
		rpdb_poster = 'https://api.ratingposterdb.com/%s/tmdb/poster-default/movie-%s.jpg?fallback=true' % ('%s', tmdb_id)
		poster_path = data_get('poster_path', '')
		if poster_path: poster = tmdb_image_url % ('w500', poster_path)
		else: poster = ''
		backdrop_path = data_get('backdrop_path', '')
		if backdrop_path: fanart = tmdb_image_url % ('original', backdrop_path)
		else: fanart = ''
		images = data_get('images', {})
		# LOCAL PATCH 2026-09-24: every piece of title artwork through _chain_art, in the order the
		# movie Artwork Provider setting gives, each falling back through the others.
		_art, _art_pending = _art_for('movie', _tmdb_art(images, tmdb_image_url, poster, fanart,
				('movie', tmdb_id, data_get('original_language'))), imdb_id=imdb_id)   # 2026-10-02
		poster, fanart, landscape, clearlogo = _art['poster'], _art['fanart'], _art['landscape'], _art['clearlogo']
		extra_fanart_list = _art['extra_fanart']
		title, original_title = data_get('title'), data_get('original_title')
		try:
			translations = data_get('translations')['translations']
			english_title = next((i['data']['title'] for i in translations if i['iso_639_1'] == 'en'), None)
		except: english_title = None
		try: year = str(data_get('release_date').split('-')[0])
		except: year = ''
		try: duration = int(data_get('runtime', '90') * 60)
		except: duration = 0
		try:
			genres = data_get('genres')
			genre = [i['name'] for i in genres]
		# LOCAL PATCH 2026-08-31: was `genre == []` -- a comparison, not an assignment, so a
		# TMDb payload with no 'genres' key left genre unbound. It is read below in the
		# meta dict, raising NameError inside the outer try, which the bare `except: pass`
		# swallowed -- losing the ENTIRE movie build. tvshow_meta always had this right.
		except: genre = []
		rootname = '%s (%s)' % (title, year)
		companies = data_get('production_companies')
		if companies:
			if len(companies) == 1: studio = ([i['name'] for i in companies][0],)
			else:
				# LOCAL PATCH 2026-08-31: a bare next() on an empty generator raises StopIteration
				# BEFORE python evaluates the `or`, so the 'no logo anywhere -> take the first'
				# fallback never actually ran; it always landed in the except and left studio [].
				# companies has 2+ entries in this branch, so indexing [0] cannot fail.
				try: studio = (next((i['name'] for i in companies if i['logo_path'] not in ('', 'None', None)), None) or companies[0]['name'],)
				except: pass
		production_countries = data_get('production_countries', None)
		if production_countries:
			country = [i['name'] for i in production_countries]
			country_codes = [i['iso_3166_1'] for i in production_countries]
		release_dates = data_get('release_dates')
		digital_release = ''
		if release_dates:
			release_results = release_dates['results']
			digital_release = digital_release_date(release_results)
			# LOCAL PATCH 2026-10-25 (4.0.5): the chosen region, then US, then any (_region_fallback)
			try: mpaa = _region_fallback([(i['iso_3166_1'], x['certification']) for i in release_results for x in i['release_dates']], mpaa_region)
			except: pass
		credits = data_get('credits')
		if credits:
			all_cast = credits.get('cast', None)
			if all_cast:
				try:
					cast = [{'name': i['name'], 'role': i['character'], 'thumbnail': tmdb_image_url % ('h632', i['profile_path'])if i['profile_path'] else ''} for i in all_cast]
					short_cast = cast[:10]
				except: pass
			crew = credits.get('crew', None)
			if crew:
				try: writer = [i['name'] for i in crew if i['job'] in ('Author', 'Writer', 'Screenplay', 'Characters')]
				except: pass
				try: director = [i['name'] for i in crew if i['job'] == 'Director']
				except: pass
		alternative_titles = data_get('alternative_titles', [])
		if alternative_titles:
			alternatives = alternative_titles['titles']
			alternative_titles = [i['title'] for i in alternatives if i['iso_3166_1'] in ('US', 'GB', 'UK', '')]
		else: alternative_titles = []
		videos = data_get('videos', None)
		if videos:
			try:
				vid_results = videos['results']
				all_trailers = _trailers_newest_first(vid_results, premiered)
				if all_trailers:
					def _movie_pick(vids):
						return \
						next((youtube_url % i['key'] for i in vids if i['official'] and i['type'] == 'Trailer' and 'official trailer' in i['name'].lower()), None) or \
						next((youtube_url % i['key'] for i in vids if i['official'] and i['type'] == 'Trailer'), None) or \
						next((youtube_url % i['key'] for i in vids if i['type'] == 'Trailer'), None) or \
						next((youtube_url % i['key'] for i in vids if 'trailer' in i['name'].lower()), None) or \
						next((youtube_url % i['key'] for i in vids), None) or ''
					trailer = _pick_on_time(_movie_pick, all_trailers, premiered)
				else: trailler = ''
			except: pass
		keywords = data_get('keywords', None)
		if keywords: stinger_keys = [i['name'] for i in keywords['keywords'] if i['name'] in ('duringcreditsstinger', 'aftercreditsstinger')]
		status, homepage = data_get('status', 'N/A'), data_get('homepage', 'N/A')
		belongs_to_collection = data_get('belongs_to_collection')
		if belongs_to_collection: ei_collection_name, ei_collection_id = belongs_to_collection['name'], belongs_to_collection['id']
		else: ei_collection_name, ei_collection_id = None, None
		try: ei_budget = '${:,}'.format(data_get('budget'))
		except: ei_budget = '$0'
		try: ei_revenue = '${:,}'.format(data_get('revenue'))
		except: ei_revenue = '$0'
		extra_info = {'status': status, 'budget': ei_budget, 'revenue': ei_revenue, 'homepage': homepage, 'collection_name': ei_collection_name, 'collection_id': ei_collection_id}
		meta = {'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'rating': rating, 'tagline': tagline, 'votes': votes, 'premiered': premiered, 'imdbnumber': imdb_id, 'trailer': trailer,
				'poster': poster, 'fanart': fanart, 'genre': genre, 'title': title, 'original_title': original_title, 'english_title': english_title, 'year': year, 'cast': cast,
				'duration': duration, 'rootname': rootname, 'country': country, 'country_codes': country_codes, 'mpaa': mpaa,'writer': writer, 'all_trailers': all_trailers,
				'director': director, 'alternative_titles': alternative_titles, 'plot': plot, 'studio': studio, 'extra_info': extra_info, 'mediatype': 'movie', 'tvdb_id': 'None',
				'clearlogo': clearlogo, 'landscape': landscape, 'keywords': keywords, 'rpdb_poster': rpdb_poster, 'short_cast': short_cast, 'stinger_keys': stinger_keys,
				'extra_fanart_list': extra_fanart_list, 'digital_release': digital_release, 'mpaa_region': mpaa_region}
		_fetch_omdb_for_meta(meta)
		if _art_pending: meta['art_pending'] = _art_pending
		meta_cache.set('movie', id_type, meta, movie_expiry(current_date, meta), current_time)
		if _art_pending: _backfill_or_defer(meta, current_date, current_time, (_ArtBackfill('movie', id_type),))
	except: pass
	return meta

# LOCAL PATCH 2026-09-24: title artwork is one chain per piece, in provider order.
#
# The Artwork Provider setting (per kind: movie, tvshow, anime) decides which source is asked
# FIRST for every piece -- poster, main backdrop, landscape, clearlogo, and the extra backdrops
# AF3 cycles -- and every piece falls back through the others, fanart.tv always last for the
# TMDb and TVDB modes:
#   0 TMDb              -> TMDb, TVDB, fanart.tv
#   2 TVDB              -> TVDB (highest rated), TMDb, fanart.tv
#   3 fanart.tv         -> fanart.tv (most liked), TMDb, TVDB
#
# Before this, "TMDb Default" took its clearlogo from fanart.tv FIRST (a 2026-08-27 patch that
# predated the setting), and a TVDB mode still took poster and landscape from TMDb. Each piece
# is resolved on its own and a source is only asked when every earlier one had nothing, so a
# title TMDb covers costs no TVDB request in mode 0. TVDB's pickers put English first (see
# apis/tvdb_api._english_first), and so does TMDb's clearlogo pick below.
_EXTRA_FANART_CAP = 20
# The extra backdrops fall back too, but only far enough to fill AF3's eight-image cycle: the
# first source may supply up to _EXTRA_FANART_CAP (the info-dialog gallery wires 20), while
# topping a long list up from a second provider would cost a request per title for images the
# cycle never reaches.
_EXTRA_FANART_FILL = 8


def _art_order(kind):
	try:
		from caches.settings_cache import get_setting
		mode = str(get_setting('deadlight.%s.artwork_provider' % kind, '0'))
	except Exception:
		mode = '0'
	# '1' (Newest Uploaded) was removed 2026-09-26; a stored '1' is migrated, and is TVDB here too.
	if mode in ('1', '2'): return ('tvdb', 'tmdb', 'fanart')
	if mode == '3': return ('fanart', 'tmdb', 'tvdb')
	# LOCAL PATCH 2026-10-19: a MOVIE in TMDb mode does not ask TVDB -- 122 TVDB id lookups + 68 full movie records in a
	# week supplied 3 landscapes, 2 clearlogos and 1 fanart over 270 movies (fanart.tv, still asked, gave more).
	if kind == 'movie': return ('tmdb', 'fanart')
	return ('tmdb', 'tvdb', 'fanart')


def _tvdb_art(kind, field, tvdb_id, imdb_id):
	from apis import tvdb_api
	if kind == 'movie':
		if field == 'poster': return tvdb_api.movie_poster(imdb_id)
		if field == 'fanart': return tvdb_api.movie_backdrop(imdb_id)
		if field == 'landscape': return tvdb_api.movie_landscape(imdb_id)
		if field == 'clearlogo': return tvdb_api.movie_clearlogo(imdb_id)
		if field == 'clearlogo_en': return tvdb_api.movie_clearlogo(imdb_id, english_only=True)
		return tvdb_api.movie_backdrops(imdb_id, cap=_EXTRA_FANART_CAP)
	if field == 'poster': return tvdb_api.series_poster(tvdb_id)
	if field == 'fanart': return tvdb_api.series_backdrop(tvdb_id)
	if field == 'landscape': return tvdb_api.series_landscape(tvdb_id)
	if field == 'clearlogo': return tvdb_api.series_clearlogo(tvdb_id)
	if field == 'clearlogo_en': return tvdb_api.series_clearlogo(tvdb_id, english_only=True)
	return tvdb_api.series_backdrops(tvdb_id, cap=_EXTRA_FANART_CAP)


def _fanart_art(kind, field, tvdb_id, imdb_id):
	# LOCAL PATCH 2026-09-26: every piece now, posters and landscapes included -- see fanart_api.
	from apis import fanart_api
	if kind == 'movie':
		if field == 'poster': return fanart_api.fanart_movie_poster(imdb_id)
		if field == 'landscape': return fanart_api.fanart_movie_landscape(imdb_id)
		if field == 'clearlogo': return fanart_api.fanart_movie_clearlogo(imdb_id)
		if field == 'clearlogo_en': return fanart_api.fanart_movie_clearlogo(imdb_id, english_only=True)
		if field in ('fanart', 'bgs'):
			bgs = fanart_api.fanart_movie_backgrounds(imdb_id, cap=_EXTRA_FANART_CAP) or []
			return bgs if field == 'bgs' else (bgs[0] if bgs else '')
		return ''
	if field == 'poster': return fanart_api.fanart_tvshow_poster(tvdb_id)
	if field == 'landscape': return fanart_api.fanart_tvshow_landscape(tvdb_id)
	if field == 'clearlogo': return fanart_api.fanart_tvshow_clearlogo(tvdb_id)
	if field == 'clearlogo_en': return fanart_api.fanart_tvshow_clearlogo(tvdb_id, english_only=True)
	if field in ('fanart', 'bgs'):
		bgs = fanart_api.fanart_tvshow_backgrounds(tvdb_id, cap=_EXTRA_FANART_CAP) or []
		return bgs if field == 'bgs' else (bgs[0] if bgs else '')
	return ''


def _tmdb_logo_url(logo, image_url='https://image.tmdb.org/t/p/%s%s'):
	if not logo: return ''
	path = logo['file_path']
	# Kodi wants a png; TMDb's CDN serves one for an svg path.
	if not path.endswith('png'): path = path.replace(path.split('.')[-1], 'png')
	# LOCAL PATCH 2026-09-26: w500, was original. AF3's largest logo box is 640x135
	# (info_title_w / info_title_logo_h), so a typical 3:1 logo draws ~405 px wide; originals
	# averaged 1072x359 in the texture cache (304 logos, 97 MB) and TMDbHelper crops each one.
	# TMDb has no w780 for logos: the sizes are w45..w500 and original.
	return image_url % ('w500', path)

def _tmdb_art(images, image_url, poster, fanart, own_logo=None):
	"""TMDb's own pick for every piece, from the payload already in hand -- no request.
	own_logo: (media_type, tmdb_id, original_language), kept for _chain_art's last-resort logo (LOCAL PATCH 2026-10-19)."""
	images = images or {}
	backdrops = images.get('backdrops') or []
	posters = images.get('posters') or []
	if not poster:
		poster = next((image_url % ('w500', i['file_path']) for i in posters if i.get('iso_639_1') == 'en'), '')
	if not fanart:
		fanart = next((image_url % ('original', i['file_path']) for i in backdrops if i.get('iso_639_1') in (None, '', 'xx')), '')
	landscape = next((image_url % ('original', i['file_path']) for i in backdrops if i.get('iso_639_1') == 'en'), '')
	# The payload is requested with include_image_language=en,null, and logos[0] was taken as
	# it came -- an UNTAGGED logo is often the original-language title, so it could beat an
	# English one. English first, untagged only when there is no English logo at all.
	logos = [l for l in (images.get('logos') or []) if l.get('file_path')]
	english = next((l for l in logos if l.get('iso_639_1') == 'en'), None)
	clearlogo_en = _tmdb_logo_url(english, image_url)
	clearlogo = clearlogo_en or _tmdb_logo_url(logos[0] if logos else None, image_url)
	# 2026-08-07: best-voted first, (vote_count, vote_average) -- TMDb's own order is not by votes.
	ranked = sorted(backdrops, key=lambda i: (int(i.get('vote_count') or 0), float(i.get('vote_average') or 0)), reverse=True)
	bgs = [image_url % ('original', i['file_path']) for i in ranked if i.get('iso_639_1') in (None, '', 'xx')]
	return {'poster': poster, 'fanart': fanart, 'landscape': landscape, 'clearlogo': clearlogo,
			'clearlogo_en': clearlogo_en, 'bgs': bgs, 'own_logo': own_logo}

def _tmdb_own_language_logo(own_logo):
	"""LOCAL PATCH 2026-10-19: the title's logo in its ORIGINAL language, for when no source had an English or untagged
	one. Only that language -- a Portuguese logo on a Spanish film is worse than the text title. English originals are
	skipped: an 'en' logo would already have been in the en,null payload."""
	try:
		media_type, tmdb_id, language = own_logo
		if not language or language == 'en': return ''
		from apis.tmdb_api import tmdb_logos
		logos = tmdb_logos(media_type, tmdb_id, language)
		return _tmdb_logo_url(logos[0] if logos else None)
	except Exception: return ''


# LOCAL PATCH 2026-10-02: search results build their artwork from TMDb alone and fill in TVDB / fanart.tv afterwards.
# A cold 20-title search spent ~4 s of its 7.5-11.5 s in the chain below (26-55 TVDB and 8-17 fanart.tv calls, one after
# another per title) before anything was shown; TMDb-only measured ~3.7 s. defer_artwork() is called by the search
# lists only, and takes effect only in a listing process (_DEFERRED), where _backfill_or_defer queues _ArtBackfill to
# run after the directory is shown (widget calls skip it; the item keeps 'art_pending' and any later read queues it
# again). An item whose TMDb art is already complete, with TMDb first in the provider order, gets no pending fill.
_DEFER_ART = False

def defer_artwork():
	global _DEFER_ART
	_DEFER_ART = True

def _art_for(kind, tmdb, tvdb_id=None, imdb_id=None):
	"""(art, pending): the _chain_art result, or TMDb's own pieces plus what a later _ArtBackfill needs."""
	if not (_DEFER_ART and _DEFERRED is not None): return _chain_art(kind, tmdb, tvdb_id, imdb_id), None
	art = _chain_art(kind, tmdb, tvdb_id, imdb_id, order=('tmdb',))
	complete = _art_order(kind)[0] == 'tmdb' and all(tmdb.get(k) for k in ('poster', 'fanart', 'landscape', 'clearlogo_en')) \
		and bool(art['extra_fanart'])   # LOCAL PATCH 2026-10-19: any -- _chain_art no longer tops up past the first source
	if complete: return art, None
	return art, {'kind': kind, 'tmdb': tmdb, 'tvdb_id': tvdb_id, 'imdb_id': imdb_id}

class _ArtBackfill:
	"""The full artwork chain for an item built with TMDb art only (meta['art_pending']); re-caches the item."""
	def __init__(self, media_type, id_type):
		self.media_type, self.id_type = media_type, id_type
	def __call__(self, meta, current_date=None, current_time=None):
		pending = meta.get('art_pending')
		if not pending: return
		art = _chain_art(pending['kind'], pending['tmdb'], tvdb_id=pending.get('tvdb_id'), imdb_id=pending.get('imdb_id'))
		meta.update({'poster': art['poster'], 'fanart': art['fanart'], 'landscape': art['landscape'], 'clearlogo': art['clearlogo'],
					 'extra_fanart_list': art['extra_fanart']})
		meta.pop('art_pending', None)
		if current_date is None:
			from modules.utils import get_datetime
			current_date = get_datetime()
		expiry = movie_expiry(current_date, meta) if self.media_type == 'movie' else tvshow_expiry(current_date, meta)
		meta_cache.set(self.media_type, self.id_type, meta, expiry, current_time)
	def __eq__(self, other):
		return isinstance(other, _ArtBackfill) and other.media_type == self.media_type
	def __hash__(self):
		return hash(('art_backfill', self.media_type))

def _with_art_backfill(meta, chain, media_type, id_type):
	return chain + (_ArtBackfill(media_type, id_type),) if meta.get('art_pending') else chain


def _chain_art(kind, tmdb, tvdb_id=None, imdb_id=None, order=None):
	"""{poster, fanart, landscape, clearlogo, extra_fanart} -- each piece from the first source
	in _art_order that has it. Any source failing is treated as that source having nothing."""
	full_chain = order is None   # not _art_for's TMDb-only first pass, whose _ArtBackfill runs this again in full
	order = order or _art_order(kind)
	def _get(src, field):
		try:
			if src == 'tmdb': return tmdb.get(field) or ([] if field == 'bgs' else '')
			if src == 'tvdb': return _tvdb_art(kind, field, tvdb_id, imdb_id) or ([] if field == 'bgs' else '')
			return _fanart_art(kind, field, tvdb_id, imdb_id) or ([] if field == 'bgs' else '')
		except Exception:
			return [] if field == 'bgs' else ''
	out = {}
	for field in ('poster', 'fanart', 'landscape'):
		out[field] = next((v for v in (_get(src, field) for src in order) if v), '')
	# LOCAL PATCH 2026-09-24: the clearlogo in TWO passes. First an explicitly English logo from ANY
	# source, in provider order; only when no source has one, each source's best in any language.
	# A TVDB-first show whose TVDB logos are all Japanese used to stop there although TMDb or
	# fanart.tv held an English one -- 36 of 253 cached shows. TMDb's UNTAGGED logos do not count
	# as English: that bucket is where the original-language logos sit.
	out['clearlogo'] = (next((v for v in (_get(src, 'clearlogo_en') for src in order) if v), '')
		or next((v for v in (_get(src, 'clearlogo') for src in order) if v), '')
		or (full_chain and _tmdb_own_language_logo(tmdb.get('own_logo'))) or '')   # LOCAL PATCH 2026-10-19: one request, only for a title with none
	merged, seen = [], {out['fanart']}
	for src in order:
		# the first source that supplies ANY backdrop gets the full allowance -- when TVDB is down
		# or lacks the title, TMDb stands in completely rather than as an eight-image top-up
		# LOCAL PATCH 2026-10-19: and the only one -- no top-up from the next source. TMDb mode asked TVDB for 315 shows'
		# artwork records mainly for this top-up (fewer than _EXTRA_FANART_CAP TMDb backdrops), while AF3's slideshow and
		# gallery, the only readers of extra_fanart, are off.
		if merged: break
		limit = _EXTRA_FANART_CAP
		for url in _get(src, 'bgs'):
			if len(merged) >= limit: break
			if url and url not in seen:
				seen.add(url); merged.append(url)
	out['extra_fanart'] = merged
	return out


def tvshow_meta(id_type, media_id, api_key, mpaa_region, current_date, current_time=None, is_anime_list=None):
	if id_type == 'trakt_dict':
		if media_id.get('tmdb', None): id_type, media_id = 'tmdb_id', media_id['tmdb']
		elif media_id.get('imdb', None): id_type, media_id = 'imdb_id', media_id['imdb']
		elif media_id.get('tvdb', None): id_type, media_id = 'tvdb_id', media_id['tvdb']
		else: id_type, media_id = None, None
	if media_id == None: return None
	meta = meta_cache.get('tvshow', id_type, media_id, current_time)
	if meta and _region_stale(meta, mpaa_region): meta = None   # LOCAL PATCH 2026-10-25 (4.0.5)
	META_COUNTS['cached' if meta else 'fetched'] += 1
	if meta:
		# LOCAL PATCH 2026-09-07 (OMDb) / 2026-09-15 (AniList); deferred in listings 2026-09-26.
		# MDBList ratings removed 2026-09-29 (TMDbHelper supplies them).
		_backfill_or_defer(meta, current_date, current_time, _with_art_backfill(meta, (_backfill_omdb, _backfill_anilist, _backfill_mal), 'tvshow', id_type))
		return meta_valid_check(meta, is_anime_list)
	try:
		if id_type == 'tmdb_id': data = tvshow_details(media_id, api_key)
		else:
			external_result = tvshow_external_id(id_type, media_id, api_key)
			# an id TMDb cannot map keeps its 24 h blank entry, as before
			if not external_result: data = {'success': False, 'status_code': 34}
			else: data = tvshow_details(external_result['id'], api_key)
		# LOCAL PATCH 2026-10-03 (Batch 3): a fetch that failed (None) or was refused used to be stored as a blank
		# entry for 24 h -- one timeout and the show vanished from every list for a day. Now nothing is stored.
		if _tmdb_refused(data): return None
		if data.get('status_code', '') in _TMDB_MISSING:
			meta = _blank_entry(id_type, media_id)
			meta_cache.set('tvshow', id_type, meta, 24, current_time)
			return meta
		tmdb_image_url, youtube_url = 'https://image.tmdb.org/t/p/%s%s', 'plugin://plugin.video.youtube/play/?video_id=%s'
		data_get = data.get
		cast, short_cast, writer, director, studio, all_trailers, country, country_codes = [], [], [], [], [], [], [], []
		mpaa, trailer = '', ''
		external_ids = data_get('external_ids')
		tmdb_id, imdb_id, tvdb_id = data_get('id', ''), external_ids.get('imdb_id', ''), external_ids.get('tvdb_id', 'None')
		rating, votes = data_get('vote_average', ''), data_get('vote_count', '')
		plot, tagline, premiered = data_get('overview', ''), data_get('tagline', ''), data_get('first_air_date', '')
		if not plot: plot = _overview_fallback(data_get)   # LOCAL PATCH 2026-10-25 (4.0.5)
		season_data, total_seasons = data_get('seasons'), data_get('number_of_seasons')
		rpdb_poster = 'https://api.ratingposterdb.com/%s/tmdb/poster-default/series-%s.jpg?fallback=true' % ('%s', tmdb_id)
		poster_path = data_get('poster_path', '')
		if poster_path: poster = tmdb_image_url % ('w500', poster_path)
		else: poster = ''
		backdrop_path = data_get('backdrop_path', '')
		if backdrop_path: fanart = tmdb_image_url % ('original', backdrop_path)
		else: fanart = ''
		images = data_get('images', {})
		# LOCAL PATCH 2026-09-24: every piece of title artwork through _chain_art. Anime and regular TV
		# have separate provider settings, told apart by the keywords already in this payload.
		# LOCAL PATCH 2026-10-15: the stub also carries genre, country codes and the id, read from this payload the way
		# the full meta below reads them. With keywords alone untagged_japanese_animation could never answer True here, so
		# a new Japanese show (or Suikoden: The Anime, keyworded but not 'anime') took the regular-TV artwork provider.
		try:
			_stub = {'keywords': data_get('keywords', {}), 'tmdb_id': tmdb_id,
					'genre': [i['name'] for i in (data_get('genres') or [])],
					'country_codes': [i['iso_3166_1'] for i in (data_get('production_countries') or [])]}
			_kind = 'anime' if is_anime_check(_stub) else 'tvshow'
		except Exception: _kind = 'tvshow'
		_art, _art_pending = _art_for(_kind, _tmdb_art(images, tmdb_image_url, poster, fanart,
				('tv', tmdb_id, data_get('original_language'))), tvdb_id=tvdb_id)   # 2026-10-02
		poster, fanart, landscape, clearlogo = _art['poster'], _art['fanart'], _art['landscape'], _art['clearlogo']
		extra_fanart_list = _art['extra_fanart']
		title, original_title = data_get('name'), data_get('original_name')
		try:
			translations = data_get('translations')['translations']
			english_title = [i['data']['name'] for i in translations if i['iso_639_1'] == 'en'][0]
		except: english_title = None
		try: year = str(data_get('first_air_date').split('-')[0]) or ''
		except: year = ''
		try: duration = min(data_get('episode_run_time'))*60
		except: duration = 0
		# LOCAL PATCH 2026-10-25 (4.0.5): TMDb now leaves episode_run_time empty for most shows, so duration was 0 and MDBList's
		# percent-only resume points (get_resume_seconds) resumed at 0 s. The last / next episode's own runtime, already here.
		if not duration:
			try: duration = int(next((e.get('runtime') for e in (data_get('last_episode_to_air'), data_get('next_episode_to_air')) if e and e.get('runtime')), 0) or 0) * 60
			except: duration = 0
		try:
			genres = data_get('genres')
			genre = [i['name'] for i in genres]
		except: genre = []
		rootname = '%s (%s)' % (title, year)
		networks = data_get('networks', None)
		if networks:
			if len(networks) == 1: studio = ([i['name'] for i in networks][0],)
			else:
				# LOCAL PATCH 2026-08-31: as movie_meta above, plus the fallback referenced
				# `network` (singular), which is not defined anywhere -- a NameError masked by
				# the same except. networks has 2+ entries in this branch.
				try: studio = (next((i['name'] for i in networks if i['logo_path'] not in ('', 'None', None)), None) or networks[0]['name'],)
				except: pass
		production_countries = data_get('production_countries', None)
		if production_countries:
			country = [i['name'] for i in production_countries]
			country_codes = [i['iso_3166_1'] for i in production_countries]
		content_ratings = data_get('content_ratings', None)
		if content_ratings:
			# LOCAL PATCH 2026-10-25 (4.0.5): the chosen region, then US, then any -- a show with no rating there had none at all
			try: mpaa = _region_fallback([(i['iso_3166_1'], i['rating']) for i in content_ratings['results']], mpaa_region)
			except: pass
		credits = data_get('credits')
		if credits:
			all_cast = credits.get('cast', None)
			if all_cast:
				try:
					cast = [{'name': i['name'], 'role': i['character'], 'thumbnail': tmdb_image_url % ('h632', i['profile_path']) if i['profile_path'] else ''} for i in all_cast]
					short_cast = cast[:10]
				except: pass
			crew = credits.get('crew', None)
			if crew:
				try: writer = [i['name'] for i in crew if i['job'] in ('Author', 'Writer', 'Screenplay', 'Characters')]
				except: pass
				try: director = [i['name'] for i in crew if i['job'] == 'Director']
				except: pass
		alternative_titles = data_get('alternative_titles', [])
		if alternative_titles:
			alternatives = alternative_titles['results']
			alternative_titles = [i['title'] for i in alternatives if i['iso_3166_1'] in ('US', 'GB', 'UK', '')]
		videos = data_get('videos', None)
		if videos:
			try:
				vid_results = videos['results']
				all_trailers = _trailers_newest_first(vid_results, premiered)
				if all_trailers: trailer = _pick_on_time(lambda v: _pick_trailer(v, youtube_url), all_trailers, premiered)
			except: pass
		# LOCAL PATCH 2026-08-26: per-season trailers from the season/N/videos blocks
		# appended by apis/tmdb_api.tvshow_details. Consumers fall back to `trailer`
		# for the ~46% of seasons TMDb has no video for.
		season_trailers = _season_trailers(data_get, youtube_url)
		keywords = data_get('keywords', None)
		status, _type, homepage = data_get('status', 'N/A'), data_get('type', 'N/A'), data_get('homepage', 'N/A')
		created_by = data_get('created_by', None)
		if created_by:
			try: ei_created_by = ', '.join([i['name'] for i in created_by])
			except: ei_created_by = 'N/A'
		else: ei_created_by = 'N/A'
		ei_next_ep, ei_last_ep = data_get('next_episode_to_air', None), data_get('last_episode_to_air', None)
		# LOCAL PATCH 2026-08-05 (Red Light R2 port): ended/canceled shows on TMDb
		# sometimes carry phantom placeholder seasons (announced-then-scrapped S2
		# etc.) that inflate `number_of_episodes` — leaves shows stuck In-Progress.
		# Use the seasons-before-last + ei_last_ep formula regardless of status
		# (works for ended too — last_episode_to_air is the FINAL ep for ended shows).
		# When ei_last_ep is absent, sum season_data but only for seasons whose
		# air_date is set (drops phantom placeholders).
		# LOCAL PATCH 2026-08-07: long-running anime (Naruto Shippuden, HxH, One Piece)
		# often have TMDb `last_episode_to_air.episode_number` in ABSOLUTE numbering
		# (500, 148, 1120) instead of the per-season position. The naive formula
		# `sum(before) + last_ep.episode_number` then produces wildly inflated totals
		# — e.g. Naruto Shippuden: 413 + 500 = 913 aired vs actual 500 → show stays
		# stuck in In-Progress showing 500/913 despite being fully watched.
		# Detect absolute mode by comparing last_e against the last season's own
		# episode_count; if it overflows, use the last season's count directly.
		# LOCAL PATCH 2026-10-25 (4.0.5): not when the last episode aired is a special (season 0) -- seasons_before_sum then
		# summed seasons < 0, and S00E03 on a 50-episode show made total_aired_eps 3, so the show read fully watched
		if ei_last_ep and ei_last_ep.get('season_number'):
			last_s = ei_last_ep['season_number']
			last_e = ei_last_ep['episode_number']
			seasons_before_sum = sum([i['episode_count'] for i in season_data if i['season_number'] < last_s and i['season_number'] != 0])
			last_season = next((i for i in season_data if i['season_number'] == last_s), None)
			last_season_count = (last_season or {}).get('episode_count', 0)
			if last_season_count and last_e > last_season_count:
				# Absolute-numbering case: last_e is a total-across-series index, not
				# a per-season position. Use the last season's episode_count instead.
				total_aired_eps = seasons_before_sum + last_season_count
			else:
				total_aired_eps = seasons_before_sum + last_e
		else:
			aired_seasons = [i for i in season_data if i['season_number'] != 0 and i.get('air_date') and i.get('episode_count', 0) > 0]
			total_aired_eps = sum([i['episode_count'] for i in aired_seasons]) if aired_seasons else data_get('number_of_episodes')
		extra_info = {'status': status, 'type': _type, 'homepage': homepage, 'created_by': ei_created_by, 'next_episode_to_air': ei_next_ep, 'last_episode_to_air': ei_last_ep}
		meta = {'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'imdb_id': imdb_id, 'rating': rating, 'plot': plot, 'tagline': tagline, 'votes': votes, 'premiered': premiered, 'year': year,
				'poster': poster, 'fanart': fanart, 'genre': genre, 'title': title, 'original_title': original_title, 'english_title': english_title, 'season_data': season_data,
				'alternative_titles': alternative_titles, 'duration': duration, 'rootname': rootname, 'imdbnumber': imdb_id, 'country': country, 'mpaa': mpaa, 'trailer': trailer,
				'country_codes': country_codes, 'writer': writer, 'director': director, 'all_trailers': all_trailers, 'cast': cast, 'studio': studio, 'extra_info': extra_info,
				'total_aired_eps': total_aired_eps, 'mediatype': 'tvshow', 'total_seasons': total_seasons, 'tvshowtitle': title, 'status': status, 'clearlogo': clearlogo,
				'landscape': landscape, 'keywords': keywords, 'rpdb_poster': rpdb_poster, 'short_cast': short_cast, 'extra_fanart_list': extra_fanart_list,
				'season_trailers': season_trailers, 'mpaa_region': mpaa_region}
		_fetch_omdb_for_meta(meta)
		if _DEFERRED is None: _fetch_anilist_for_meta(meta)   # LOCAL PATCH 2026-09-15
		if _art_pending: meta['art_pending'] = _art_pending
		meta_cache.set('tvshow', id_type, meta, tvshow_expiry(current_date, meta), current_time)
		if _art_pending: _backfill_or_defer(meta, current_date, current_time, (_ArtBackfill('tvshow', id_type),))
		if _DEFERRED is not None: _DEFERRED.append((meta, current_date, current_time, (_backfill_anilist, _backfill_mal)))
	except: pass
	return meta_valid_check(meta, is_anime_list)

# LOCAL PATCH 2026-09-02: TMDb serves TV episode numbers in TWO conventions and the
# scrape path needs the series-absolute number out of whichever one it was handed.
#
#   (a) per-season position -- nearly every show. Bleach S2 (Thousand-Year Blood War)
#       is numbered 1..50, so S02E46's absolute number really is 366 + 46 = 412.
#   (b) series-absolute ALREADY -- long-running weekly anime. Verified against the API:
#       One Piece S1 is 1..61, S2 is 62..77, S23 is 1156..1181; Naruto S4 is 159..220;
#       Hunter x Hunter S2 is 63..136; Naruto Shippuden's last episode is S20E500 in a
#       season holding 87 episodes.
#
# `sum(episode_count of earlier seasons) + episode` is correct only for (a). Applied to
# (b) it double-counts, and the damage is not merely a miss:
#   One Piece S23E1176 -> 1155 + 1176 = 2331  (1181-episode show; no such episode)
#   One Piece S02E62   ->   61 +   62 =  123  <- a REAL, DIFFERENT episode
#   Naruto    S02E53   ->   52 +   53 =  105  <- a REAL, DIFFERENT episode
#   Naruto    S04E159  ->  158 +  159 =  317  (220-episode show)
#   Shippuden S20E500  ->  413 +  500 =  913  (500-episode show)
#   HxH       S03E148  ->  136 +  148 =  284  (148-episode show)
# The 123 and 105 rows are the dangerous ones. absolute_episode is cour_match()'s FIRST
# early accept, and ordered_episode_candidates() tries the HIGHEST number first, so a
# complete-series pack -- how One Piece is distributed -- hands back episode 123 for a
# request for 62 and plays it. Observed live before this patch: a One Piece scrape for
# TMDb S6E157 searched absolute 277 and never searched 157, rejecting 108 of 181 results.
#
# TWO signals, OR-ed, because either alone leaves a hole:
#   1. this episode overflows its OWN season's episode_count. Same test as the
#      total_aired_eps guard in tvshow_meta above, verified there over 40 shows, and the
#      only signal available when extra_info is thin.
#      Hole: HxH S2 holds 74 episodes numbered 63..136, so S02E63..E74 do not overflow
#      74 and would still compute 62 + 63 = 125 -- a real episode again.
#   2. the SHOW numbers absolutely: last_episode_to_air overflows ITS season's
#      episode_count. That is exactly the 474-485 test, promoted from a statement about
#      one episode to a statement about the show, and safe to promote because
#      last_episode_to_air is always its season's MAXIMUM episode number. HxH is S03E148
#      against a 12-episode S03, so signal 2 covers all 74 of S2.
#      Cannot false-positive: under (a) an episode_number is by construction <= its own
#      season's episode_count. Measured -- Bleach (46 vs 50), Detective Conan (1211 vs
#      1212), Tokyo Revengers (50 vs 50) and Frieren (38 vs 38) all read as (a) and keep
#      today's numbers to the digit.
#      Remaining hole, documented rather than solved: an absolute show whose final season
#      is long and has barely started airing. None in this library.
#
# Written here rather than in source_utils because it is a fact about a TMDb payload, not
# about a release name, and because source_utils already imports this module -- the
# reverse would be a cycle, which would leave the guard above unable to ever share this.
# Red Light's sibling is source_utils.absolute_episode_from_season_data; it carries
# signal 1 only, so the HxH case is still open there.
def _tmdb_numbering_is_absolute(season_data, extra_info, season, episode):
	def _count(number):
		try: return next((int(i.get('episode_count') or 0) for i in season_data if int(i.get('season_number') or -1) == int(number)), 0)
		except (TypeError, ValueError): return 0
	own_count = _count(season)
	if own_count and episode > own_count: return True
	last = (extra_info or {}).get('last_episode_to_air') or {}
	try: last_s, last_e = int(last['season_number']), int(last['episode_number'])
	except (KeyError, TypeError, ValueError): return False
	if last_s < 1: return False
	last_count = _count(last_s)
	return bool(last_count and last_e > last_count)

def series_absolute_episode(meta, season, episode):
	"""TMDb's (season, episode) as a SERIES-ABSOLUTE episode number, or None.

	The single home for this. It was written twice WITHOUT the guard above -- in
	scrapers/external.py for data['absolute_episode'] and again in
	source_utils.anime_episode_candidates for picking a file out of a pack -- and both
	numbers reach the same magneto providers, so the two cannot be allowed to disagree.

	Returns `episode` unchanged when TMDb already numbers the show absolutely, and when
	there is no earlier season to add (season 0 and season 1 included) -- which is exactly
	what the unguarded formula produced for those, so nothing moves for them."""
	try: season, episode = int(season), int(episode)
	except (TypeError, ValueError): return None
	try:
		season_data = (meta or {}).get('season_data') or []
		prior = sum(int(i.get('episode_count') or 0) for i in season_data
				if 0 < int(i.get('season_number') or 0) < season)
	except (AttributeError, TypeError, ValueError): return None
	if not prior: return episode
	if _tmdb_numbering_is_absolute(season_data, (meta or {}).get('extra_info'), season, episode): return episode
	return prior + episode

def movieset_meta(media_id, api_key, current_time=None):
	if media_id == None: return None
	id_type = 'tmdb_id'
	meta = meta_cache.get('movie_set', id_type, media_id, current_time)
	if meta: return meta
	try:
		data = movie_set_details(media_id, api_key)
		if not data: return None
		elif 'status_code' in data and data.get('status_code') in (6, 34, 37):
			meta = {'tmdb_id': media_id, 'fanart_added': True, 'blank_entry': True}
			meta_cache.set('movie_set', id_type, meta, 24, current_time)
			return meta
		data_get = data.get
		tmdb_image_url = 'https://image.tmdb.org/t/p/%s%s'
		title, tmdb_id, plot = data_get('name'), data_get('id'), data_get('overview', '')
		poster_path = data_get('poster_path', None)
		if poster_path: poster = tmdb_image_url % ('w500', poster_path)
		else: poster = ''
		backdrop_path = data_get('backdrop_path', None)
		if backdrop_path: fanart = tmdb_image_url % ('original', backdrop_path)
		else: fanart = ''
		parts = data_get('parts')
		meta = {'tmdb_id': tmdb_id, 'title': title, 'plot': plot, 'poster': poster, 'fanart': fanart, 'parts': parts, 'imdb_id': 'None', 'tvdb_id': 'None'}
		meta_cache.set('movie_set', id_type, meta, 720, current_time)
	except: pass
	return meta

_THUMBLESS_EXPIRATION = 6
_SPLIT_COURS = None   # LOCAL PATCH 2026-10-03 (3.0.8): settings.anime_split_cours, read once per process


def _thumbless_expiration(data, expiration):
	"""Cap the season TTL while an already-aired episode is missing its still."""
	try:
		if not data or expiration <= _THUMBLESS_EXPIRATION: return expiration
		from modules.utils import get_datetime
		current_date = get_datetime()
		for ep in data:
			if ep.get('thumb'): continue
			premiered = ep.get('premiered')
			if not premiered: continue
			try: aired = jsondate_to_datetime(premiered, '%Y-%m-%d', remove_time=True)
			except Exception: continue
			# Unaired episodes legitimately have no still; only a gap on one that HAS aired
			# means TMDb has not caught up yet.
			if aired and current_date >= aired: return _THUMBLESS_EXPIRATION
	except Exception: pass
	return expiration


# LOCAL PATCH 2026-09-15: per-episode IMDb ratings on the CACHE-HIT path.
#
# episodes_meta fetches them while BUILDING a season, but a season built while OMDb was on
# cooldown -- a spent daily quota, a dead key, a network blip -- got {} from
# season_episode_ratings and pinned that empty result for the whole season TTL: 96h while
# airing, 4368h (182 days) once ended. On 2026-09-15 that was every one of 628 cached
# episodes, none carrying imdb_rating, with season expiries running to 2027-03-16. So the
# IMDb chip on an episode row stayed blank for months after OMDb itself had recovered.
#
# This is the season-level counterpart of _backfill_omdb, which fixed exactly this failure
# for show metas on 2026-09-07. Same rule: a cooldown never burns the attempt, because it
# lifts on its own and the season should be retried the moment it does.
class _SeasonBackfill:
	"""A cached season's two rating backfills as one chain link for _backfill_or_defer, which calls each link with
	(meta, current_date, current_time). Equal per season, so flush_rating_backfills' de-duplication still applies."""
	def __init__(self, data, prop_string, season):
		self.data, self.prop_string, self.season = data, prop_string, season
	def __call__(self, meta, current_date=None, current_time=None):
		_backfill_season_imdb(self.data, self.prop_string, meta, self.season)
		_backfill_season_trakt(self.data, self.prop_string, meta, self.season)
	def __eq__(self, other):
		return isinstance(other, _SeasonBackfill) and other.prop_string == self.prop_string
	def __hash__(self):
		return hash(('season_backfill', self.prop_string))


def _backfill_season_imdb(data, prop_string, meta, season, force=False):
	"""Fill imdb_rating into an already-cached season. True if it re-cached.

	LOCAL PATCH 2026-10-22: from IMDb's own API (apis.imdb_ratings), the one source: one request for the whole season,
	every episode's tt id (stored as 'imdb_id') and rating. Was OMDb's season list, which rated ~13% of episodes and
	lagged IMDb by weeks. Asked again after _imdb_refresh_hours ('_imdb_ts' on the first row); a failed request stamps
	nothing, so it is asked again next time (a refusal pauses the API for 6 h, apis.imdb_ratings)."""
	try:
		if not data or not isinstance(data, list) or not isinstance(data[0], dict): return False
		from caches.settings_cache import get_setting
		if get_setting('deadlight.omdb.episode_ratings', 'true') != 'true': return False
		imdb_id = meta.get('imdb_id')
		if not imdb_id or imdb_id == 'tt0000000': return False
		from modules.utils import get_current_timestamp
		now, first = get_current_timestamp(), data[0]
		try: last = float(first.get('_imdb_ts') or 0)
		except (TypeError, ValueError): last = 0
		if not force and now - last < _imdb_refresh_hours(data) * 3600: return False
		from apis.imdb_ratings import season_ratings
		ratings = season_ratings(imdb_id, season)
		if ratings is None: return False
		filled = 0
		for ep in data:
			if not isinstance(ep, dict): continue
			r, tt = ratings.get(ep.get('episode'), ('', ''))
			if tt: ep['imdb_id'] = tt
			if r: ep['imdb_rating'], filled = r, filled + 1
		first['_imdb_ts'] = int(now)
		expiration = _season_expiration(meta, season)   # LOCAL PATCH 2026-10-25 (4.0.5): the one rule (was a copy of the old one)
		# Reuse the 2026-08-30 shortening: a season still missing episode stills must keep
		# its short TTL, or this backfill would silently pin the thumbless rows for months.
		expiration = _thumbless_expiration(data, expiration)
		meta_cache.set_season(prop_string, data, expiration)
		from modules.kodi_utils import logger
		logger('IMDb episodes', 'backfilled %s S%s: %d of %d episodes (IMDb API)' % (imdb_id, season, filled, len(data)))
		return True
	except Exception:
		return False


def _imdb_refresh_hours(data):
	"""LOCAL PATCH 2026-10-22: a season with an episode aired in the last 45 days is re-asked daily (new episodes collect
	votes fast); an older one every 14 days."""
	try:
		from modules.utils import get_datetime
		import datetime
		cutoff = str(get_datetime() - datetime.timedelta(days=45))
		today = get_datetime(string=True)
		recent = [ep for ep in data if isinstance(ep, dict) and cutoff <= str(ep.get('premiered') or '') <= today]
		# LOCAL PATCH 2026-10-24: every 6 h while a recent episode has no IMDb rating yet (IMDb rates a new one within a day
		# or so; at 24 h a season asked just before that went a whole day without it)
		if any(not ep.get('imdb_rating') for ep in recent): return 6
		if recent: return 24
	except Exception: pass
	return 14 * 24


# LOCAL PATCH 2026-09-15: the same thing from Trakt, which actually has the data.
#
# OMDb rates 13% of this library's cached episodes (70 of 542 measured); Trakt rates 92%
# (500), and agrees with TMDb's episode titles on 500 of 500 matches. They populate
# DIFFERENT chips -- imdb_rating feeds AF3's IMDb chip, trakt_rating feeds its Trakt chip,
# which has an icon and a property mapping since 2026-09-14 and has never had a value in
# it. So this does not override or fall back to anything: each source fills its own chip
# with what it knows, and an episode can show both.
#
# Stored /10 with one decimal by trakt_season_episode_ratings, the scale TMDbHelper's show-level
# Trakt value renders at. See that function.
#
# The TTL block below is deliberately a copy of the one above rather than a shared helper:
# _backfill_season_imdb is working and unpushed, and this is four lines.
_SEASON_TRAKT_RETRY_HOURS = 24


def _trakt_episode_slot():
	"""LOCAL PATCH 2026-10-19: True when the skin shows a Trakt rating on episodes (AF3: a 'Trakt' Custom Rating slot for
	episodes). extra_trakt_rating is read nowhere else, so with no such slot the per-season Trakt request was for nothing."""
	try:
		import xbmc
		return any(xbmc.getInfoLabel('Skin.String(customrating.episodes.item%02d)' % n).lower() == 'trakt' for n in range(1, 7))
	except Exception: return False

def _backfill_season_trakt(data, prop_string, meta, season):
	"""Fill trakt_rating into an already-cached season. True if it re-cached."""
	try:
		if not data or not isinstance(data, list): return False
		if not _trakt_episode_slot(): return False
		# LOCAL PATCH 2026-09-16: "already filled" must mean filled with a value in the
		# CURRENT format, not merely non-empty. This guard shipped presence-based, and an
		# earlier build of trakt_season_episode_ratings stored whole percents ('83') before
		# it was corrected to /10 ('8.3'). Because reuselanguageinvoker=false makes an edit
		# live on the next invocation, seasons were cached from that build and then pinned:
		# 234 episodes across 16 seasons, with expiries running to 2027-03-16, showing '83'
		# beside a show-level chip reading '8.3'. Presence said filled, so they were never
		# re-asked.
		#
		# Same failure as the MDBList placeholder guard fixed on 2026-09-15 -- "already
		# filled" judged by presence rather than by the value being usable.
		#
		# '%.1f' always emits a decimal point, so a value without one is definitionally the
		# old percent format. Treating it as unfilled re-fetches that season once and costs
		# nothing afterwards.
		def _has_trakt(ep):
			v = str(ep.get('trakt_rating') or '').strip()
			return '.' in v
		# LOCAL PATCH 2026-10-25 (4.0.5): done when every AIRED episode has one, not when any does. On an airing season the
		# first fill made it "done" for good, so each week's new episode never got its Trakt rating until the season left
		# the cache (cache, 10-25: 3 airing seasons rated but for their newest episode; the rating "sometimes" showed).
		# Unaired episodes have no votes and do not count; the 24 h stamp below now follows every request, so an episode
		# Trakt has not rated yet is asked about once a day, not on every browse.
		from time import strftime
		_today = strftime('%Y-%m-%d')
		aired = [ep for ep in data if isinstance(ep, dict) and str(ep.get('premiered') or '9999')[:10] < _today]
		if not aired or all(_has_trakt(ep) for ep in aired): return False
		imdb_id = meta.get('imdb_id')
		if not imdb_id or imdb_id == 'tt0000000': return False
		from modules.kodi_utils import get_property, set_property, logger
		from modules.utils import get_current_timestamp
		stamp_prop = 'deadlight.trakt_season_ts.%s' % prop_string
		now = get_current_timestamp()
		try: last = float(get_property(stamp_prop) or 0)
		except (TypeError, ValueError): last = 0
		if now - last < _SEASON_TRAKT_RETRY_HOURS * 3600: return False
		from apis.trakt_api import trakt_season_episode_ratings
		ratings = trakt_season_episode_ratings(imdb_id, season)
		if not ratings:
			# An unaired season is the normal empty case (Trakt returns rating 0 / votes 0
			# for every episode), so stamp it and move on rather than asking every browse.
			set_property(stamp_prop, str(now))
			return False
		filled = 0
		for ep in data:
			if not isinstance(ep, dict): continue
			r = ratings.get(ep.get('episode'))
			if r:
				ep['trakt_rating'] = r
				filled += 1
		if not filled:
			set_property(stamp_prop, str(now))
			return False
		expiration = _season_expiration(meta, season)   # LOCAL PATCH 2026-10-25 (4.0.5): the one rule (was a copy of the old one)
		expiration = _thumbless_expiration(data, expiration)
		meta_cache.set_season(prop_string, data, expiration)
		set_property(stamp_prop, str(now))   # LOCAL PATCH 2026-10-25 (4.0.5): a partial answer too -- see the aired check above
		logger('Trakt episodes', 'backfilled %s S%s: %d of %d episodes' % (imdb_id, season, filled, len(data)))
		return True
	except Exception:
		return False


def episode_rating_fields(ep_data):
	"""LOCAL PATCH 2026-10-19: the EPISODE's own ratings for the playback meta -- the playing item carried the show's
	(meta['rating']), so the OSD had no episode rating to show. TMDb's from the episode row; IMDb's / Trakt's when the
	season's backfill has stored them (an episode list opened once). Nothing is requested here."""
	ep_data = ep_data or {}
	return {'ep_rating': ep_data.get('rating') or 0, 'ep_votes': ep_data.get('votes') or 0,
			'ep_imdb_rating': ep_data.get('imdb_rating') or '', 'ep_trakt_rating': ep_data.get('trakt_rating') or ''}


def playing_episode_ratings(meta, season, episode):
	"""LOCAL PATCH 2026-10-22: the playing season's IMDb / Trakt backfill, run now and returned as episode_rating_fields.
	The backfill only ran after an in-addon episode list (_backfill_or_defer drops it on playback and widget calls), so a
	show watched only from Continue Watching never got episode ratings: Mirzapur had none in any season. Called from the
	player's own thread once the video is up -- one season, nothing waits on it. None when the season is not cached."""
	try:
		season, episode = int(season), int(episode)
		prop_string = '%s_%s' % (meta['tmdb_id'], season)
		data = meta_cache.get_season(prop_string)
		if not data or not isinstance(data, list): return None
		# LOCAL PATCH 2026-10-24: the playing episode without an IMDb rating asks IMDb now, not after the season's 24 h --
		# Dark Matter 2x09 aired 10-22, the season was asked at 00:03 on 10-24 before IMDb rated it, and both the OSD and the
		# home widget then went without its 8.4 until the next day. One request per such playback.
		ep = next((e for e in data if isinstance(e, dict) and e.get('episode') == episode), None)
		_backfill_season_imdb(data, prop_string, meta, season, force=bool(ep) and not ep.get('imdb_rating'))
		_backfill_season_trakt(data, prop_string, meta, season)
		ep = next((e for e in data if isinstance(e, dict) and e.get('episode') == episode), None)
		return episode_rating_fields(ep) if ep else None
	except Exception: return None


def episodes_meta(season, meta, backfill=False):
	# LOCAL PATCH 2026-10-19: backfill=True only from the episode lists (indexers/episodes.py), the one place the episode
	# IMDb / Trakt ratings are shown. Every other caller -- status chips, Next Episodes planning, Fribb mapping, the
	# season list, mark-watched (inline there: a 10-season show made 10 serial OMDb calls), the scrape -- queued the
	# same season-ratings requests for an answer nothing on that path could show.
	def _process():
		midseason_premiere = False
		for ep_data in details:
			writer, director, guest_stars = [], [], []
			ep_data_get = ep_data.get
			title, plot, premiered = ep_data_get('name'), ep_data_get('overview'), ep_data_get('air_date')
			season, episode, episode_id = ep_data_get('season_number'), ep_data_get('episode_number'), ep_data_get('id')
			try:
				if episode == 1:
					if 'premiere' in season_type: episode_type = 'series_premiere'
					else: episode_type = 'season_premiere'
				elif midseason_premiere: episode_type, midseason_premiere = 'mid_season_premiere', False
				else:
					episode_type = ep_data_get('episode_type')
					if episode_type == 'mid_season': episode_type, midseason_premiere = 'mid_season_finale', True
					elif episode_type == 'finale':
						if 'finale' in season_type: episode_type = 'series_finale'
						else: episode_type = 'season_finale'
					else: episode_type = ''
			except: episode_type = ''
			# LOCAL PATCH 2026-10-25 (4.0.5): no runtime is 0 here, filled after the loop (_fill_runtimes) -- it was a flat
			# 30 min, so a percent resume point on a 60-min episode resumed half way back
			try: duration = int(ep_data_get('runtime') or 0)*60
			except: duration = 0
			rating, votes, still_path = ep_data_get('vote_average'), ep_data_get('vote_count'), ep_data_get('still_path', None)
			if still_path: thumb = tmdb_image_url % ('original', still_path)
			else: thumb = None
			cast = ep_data_get('guest_stars', [])
			if cast:
				try: guest_stars = [{'name': i['name'], 'role': i['character'], 'thumbnail': tmdb_image_url % ('h632', i['profile_path']) if i['profile_path'] else ''}\
									for i in cast]
				except: pass
			crew = ep_data_get('crew', None)
			if crew:
				try: writer = [i['name'] for i in crew if i['job'] in ('Author', 'Writer', 'Screenplay', 'Characters')]
				except: pass
				try: director = [i['name'] for i in crew if i['job'] == 'Director']
				except: pass
			yield {'writer': writer, 'director': director, 'mediatype': 'episode', 'episode_type': episode_type, 'episode_id': episode_id, 'title': title, 'plot': plot,
					'duration': duration, 'premiered': premiered, 'season': season, 'episode': episode, 'rating': rating, 'votes': votes, 'thumb': thumb, 'guest_stars': guest_stars}
	media_id, data = meta['tmdb_id'], None
	prop_string = '%s_%s' % (media_id, season)
	data = meta_cache.get_season(prop_string)
	# LOCAL PATCH 2026-10-25 (4.0.5): the show's details now list more episodes for this season than the cached copy had
	# when it was fetched -- new episodes stayed invisible (Next Episode: no_next_episode) for the season's 96 h. Refetched.
	if data is not None and _season_grew(meta, season, data): data = None
	if data is not None:
		# LOCAL PATCH 2026-09-15 backfills, deferred 2026-10-02 like the title ratings (_backfill_or_defer): they ran
		# inline on every cached season, so a Next Episodes widget made up to 12 OMDb (timeout 20 s) and 5 Trakt calls
		# while it was being built. Now widget calls skip them and browses run them after the directory is shown.
		if backfill: _backfill_or_defer(meta, None, None, (_SeasonBackfill(data, prop_string, season),))
		# LOCAL PATCH 2026-10-13: a season cached before AniList air times existed gets them once (see _anilist_air_times)
		# LOCAL PATCH 2026-10-15: and again whenever the 'Anime Air Times' choice differs from the one it was done with
		if data and _season_air_src(data) != airtime_source() and _anilist_air_times(meta, season, data):
			meta_cache.set_season(prop_string, data, _thumbless_expiration(data, _season_expiration(meta, season)))
		# LOCAL PATCH 2026-10-16: a TV season done with another 'TV Air Times' choice (or before it existed) is redone --
		# deferred like the backfills, so a widget never waits on TVmaze
		if data and _tv_air_choice(meta) not in (None, data[0].get('_tv_air')):
			_backfill_or_defer(meta, None, None, (_TvAirRedo(data, prop_string, season),))
		return data
	try:
		tmdb_image_url = 'https://image.tmdb.org/t/p/%s%s'
		season, tvshow_status, total_seasons = int(season), meta['status'], meta['total_seasons']
		if season == 1: season_type = 'premiere_finale' if (total_seasons == season and tvshow_status in ('Ended', 'Canceled')) else 'premiere'
		else: season_type = 'finale' if (total_seasons == season and tvshow_status in ('Ended', 'Canceled')) else ''
		expiration = _season_expiration(meta, season)
		try:
			# LOCAL PATCH 2026-10-03 (Batch 3): a refused or failed season fetch returns [] for this call and stores
			# nothing. It used to fall into the except below and cache [] for 96 h, blanking an airing season for
			# four days after one rate-limited request. A genuine "no such season" (34) still caches [].
			_over = _season_over(meta, season)   # LOCAL PATCH 2026-10-19: no air-time fetch for a season that is over
			_air_warm = [] if _over else _warm_air_times(meta, season)   # LOCAL PATCH 2026-10-19: in parallel with the TMDb fetch below
			_resp = season_episodes_details(media_id, season)
			if _tmdb_refused(_resp): return []
			# LOCAL PATCH 2026-10-25 (4.0.5): a genuine "no such season" (34) caches [] for 96 h, as before; anything else
			# that breaks the build of TMDb's answer caches [] for 1 h only (it was 96 h)
			if isinstance(_resp, dict) and _resp.get('status_code') in _TMDB_MISSING and 'episodes' not in _resp: details, expiration = [], 96
			else: details = _resp['episodes']
			total_episodes = len(details)
			data = list(_process())
			_fill_runtimes(data, meta)   # LOCAL PATCH 2026-10-25 (4.0.5)
			if data: data[0]['_ep_count'] = _season_count(meta, season)   # LOCAL PATCH 2026-10-25 (4.0.5): see _season_grew
		except Exception: data, expiration = [], 1
		# LOCAL PATCH 2026-10-25 (4.0.5): the air-time steps in their own try. They shared the TMDb one above, so a failure in
		# TVmaze / Trakt / AniList AFTER the episodes were built threw them away and cached the season EMPTY for 96 h. Now the
		# episodes are kept with whatever times were set; the season is redone by _TvAirRedo / the '_air_src' check.
		if data:
			try:
				# A TV season waits at most _AIR_WAIT_SECONDS more for its air times. Past that the list is shown with TMDb's
				# dates and cached without '_tv_air', so its next read redoes the times after the list (_TvAirRedo) from what
				# the warm threads, still running, will have cached by then. TVmaze's lookup alone took 1.6-2.0 s (Severance,
				# Better Call Saul). Anime waits for its Trakt times as before (AniList's then correct them).
				_air_late = False
				if _tv_air_choice(meta) is None:
					for _t in _air_warm: _t.join(15)
				else:
					import time as _time
					_until = _time.time() + _AIR_WAIT_SECONDS
					for _t in _air_warm: _t.join(max(0.0, _until - _time.time()))
					_air_late = any(_t.is_alive() for _t in _air_warm)
				# LOCAL PATCH 2026-08-07: enrich episodes with Trakt UTC first_aired
				# timestamps when Trakt is authorized. Gives accurate per-episode
				# air-datetime for streaming platforms (Netflix midnight-PT, Apple
				# TV+ Thu 21:00, HBO Sun 21:00 ET, anime late-night JST) — replaces
				# the "TMDb date + 20:00 local" approximation for the aired-check.
				# Silent no-op when Trakt unavailable or show/season not on Trakt.
				# LOCAL PATCH 2026-10-16: TV goes through the 'TV Air Times' choice (TVmaze first, see _tv_air_times); anime keeps
				# Trakt's here, which _anilist_air_times below then corrects
				if _over: _stamp_tv_air(meta, data)
				elif is_anime_check(meta):
					try:
						from apis.trakt_air import get_season_air_times
						airtimes = get_season_air_times(meta.get('imdb_id'), meta.get('tmdb_id'), season)
						if airtimes:
							for ep in data:
								fa = airtimes.get(ep.get('episode'))
								if fa and not _air_drifted(ep, fa): ep['first_aired_utc'] = fa   # LOCAL PATCH 2026-10-25 (4.0.5)
					except Exception: pass
				elif not _air_late: _tv_air_times(meta, season, data)
				_anilist_air_times(meta, season, data)   # LOCAL PATCH 2026-10-13: anime -- AniList's broadcast time wins
				# LOCAL PATCH 2026-10-03 (3.0.8): the IMDb (OMDb) and Trakt episode ratings are no longer fetched inline on a
				# cold season. They cost an OMDb request (timeout 20 s) and a second Trakt request on top of TMDb + the air
				# times, while the season page waited. They now go through the same deferred _SeasonBackfill the cached path
				# uses (below, after set_season): run after a browse is shown, skipped on widget calls. The Trakt one costs
				# no request when the air-time fetch above already holds the ratings (trakt_air.cached_season_ratings).
			except Exception as e:
				from modules.kodi_utils import logger
				logger('episodes_meta', 'tmdb %s S%s: air times failed, episodes kept: %s' % (media_id, season, e))
	except: data, expiration = [], 1
	# LOCAL PATCH 2026-08-30: shorten the cache while an aired episode still has no
	# still image. TMDb rarely has one the moment an episode drops -- it is uploaded
	# hours later -- so the season was cached with thumb=None and stayed blank for the
	# whole window. On an airing season that is 4 days, which is why episode thumbs
	# appeared never to refresh without clearing the cache by hand.
	#
	# Only the gap is re-checked: once every aired episode has a thumb the normal TTL
	# applies, so this costs an extra request only while something is genuinely missing.
	expiration = _thumbless_expiration(data, expiration)
	meta_cache.set_season(prop_string, data, expiration)
	if data and backfill: _backfill_or_defer(meta, None, None, (_SeasonBackfill(data, prop_string, season),))   # LOCAL PATCH 2026-10-03 (3.0.8)
	return data

_AIR_WAIT_SECONDS = 1.0

def _warm_air_times(meta, season):
	"""LOCAL PATCH 2026-10-19: start the air-time fetches a cold season will ask for, on threads, so they run while TMDb
	answers. They ran one after another after it -- The Boys S2: TMDb 1.18 s, then TVmaze lookup 0.79 + episodes 0.20,
	then Trakt slug 0.78 + season 0.37: 3.3 s before the episode list showed, against ~1.2 s overlapped. Both fetchers
	cache what they get (lists_cache / trakt_cache), so the calls below in episodes_meta read those answers. Trakt is
	warmed under 'TVmaze' too: _tv_air_times asks it for every episode TVmaze has no time for, which is every streaming
	release. Non-daemon: deadlight.py's exit wait joins them, so a cache write is never cut off."""
	try:
		from threading import Thread
		jobs, imdb_id, tmdb_id = [], meta.get('imdb_id'), meta.get('tmdb_id')
		choice = _tv_air_choice(meta)   # None for anime: Trakt's times, corrected by AniList's
		if choice in (None, 'trakt', 'tvmaze'):
			from apis.trakt_air import get_season_air_times
			jobs.append(lambda: get_season_air_times(imdb_id, tmdb_id, season))
		if choice == 'tvmaze':
			from apis.tvmaze_api import season_air_times
			jobs.append(lambda: season_air_times(meta, season))
		# LOCAL PATCH 2026-10-20: anime -- AniList's episode count and air times for the entries Fribb maps to this season,
		# so _anilist_air_times finds them cached instead of asking one after the other once TMDb has answered (a first
		# anime episode list: TMDb 0.56 s, then AniList 0.44 + 0.40 s). The RECENT schedule (anilist_recent_air_times) answers
		# whichever recent episode anilist_air_times is asked from. Fribb's rows only -- no request to find them.
		if choice is None:
			try:
				from caches import fribb_mappings
				from apis.anilist_api import anilist_recent_air_times, anilist_episode_count, anilist_score_on_cooldown
				if not anilist_score_on_cooldown():
					# LOCAL PATCH 2026-10-20: one request per entry, not two -- the recent schedule brings the entry (count,
					# titles, cover) into anilist_entries' store, so the count after it is read from there
					def _entry_job(_al):
						anilist_recent_air_times(_al)
						anilist_episode_count(_al)
					for row in fribb_mappings.tmdb_tv_to_fribb_rows(int(tmdb_id)) or []:
						if (row.get('season') or {}).get('tmdb') != int(season) or not row.get('anilist_id'): continue
						_al = int(row['anilist_id'])
						jobs.append(lambda _al=_al: _entry_job(_al))
						if len(jobs) >= 7: break
			except Exception: pass
		def _quiet(job):
			try: job()
			except Exception: pass
		threads = [Thread(target=_quiet, args=(job,), name='air_warm') for job in jobs]
		for t in threads: t.start()
		return threads
	except Exception: return []

def _tv_air_choice(meta):
	"""The 'TV Air Times' choice for a TV (not anime) show, None for anime."""
	if is_anime_check(meta): return None
	from modules.settings import tv_airtime_provider
	return _memo_setting('tv_air', tv_airtime_provider)

# LOCAL PATCH 2026-10-19: the air-time choices were read for every row (show_status_props, episodes_meta): 17 window
# property reads on a 20-row TV page. Kept 30 s, not for the process: service.py lives the whole session and must see a
# change. Cleared per call by modules/invocation.py.
_SETTING_MEMO = {}
_SETTING_MEMO_SECONDS = 30

def _memo_setting(key, read):
	import time
	hit = _SETTING_MEMO.get(key)
	now = time.time()
	if hit and now - hit[0] < _SETTING_MEMO_SECONDS: return hit[1]
	value = read()
	_SETTING_MEMO[key] = (now, value)
	return value

_TV_AIR_DRIFT_DAYS = 2

def _air_drifted(ep, utc_text):
	"""LOCAL PATCH 2026-10-25 (4.0.5): True when an exact air time ('2026-10-21T12:00:00.000Z') is dated more than
	_TV_AIR_DRIFT_DAYS from the episode's TMDb date -- another source numbering the season differently. No TMDb date: False."""
	tmdb_day, other_day = _iso_day(ep.get('premiered')), _iso_day(utc_text)
	return bool(tmdb_day and other_day and abs((other_day - tmdb_day).days) > _TV_AIR_DRIFT_DAYS)

def _tv_air_times(meta, season, data):
	"""LOCAL PATCH 2026-10-16: exact air times on a TV season's episodes, in place, by the 'TV Air Times' choice: TVmaze
	(apis/tvmaze_api, no account) with Trakt when TVmaze has nothing, Trakt alone, or TMDb's date alone. True when done
	(each episode then records the choice in '_tv_air'), False when a source did not answer -- the season is tried again.

	A TVmaze time is taken only when its date is within _TV_AIR_DRIFT_DAYS of TMDb's: TVmaze can number a season
	differently (a double episode as one, specials inside it), and its E5 must not lend its time to TMDb's E5 then.
	Slow Horses S6E6: TMDb 2026-10-21, TVmaze 2026-10-21T12:00Z (Apple TV, Wednesdays)."""
	src = _tv_air_choice(meta)
	if src is None or not data: return False
	maze, trakt = {}, {}
	if src == 'tvmaze':
		from apis.tvmaze_api import season_air_times, on_cooldown
		maze = season_air_times(meta, season)
		if not maze and on_cooldown(): return False
	# Trakt per episode where TVmaze has no time -- a streaming release has none there (tvmaze_api._all_episodes)
	if src == 'trakt' or (src == 'tvmaze' and any(ep.get('episode') not in maze for ep in data)):
		try:
			from apis.trakt_air import get_season_air_times
			trakt = get_season_air_times(meta.get('imdb_id'), meta.get('tmdb_id'), season) or {}
		except Exception: trakt = {}
	skipped = 0
	for ep in data:
		ep['_tv_air'] = src
		number, fa = ep.get('episode'), None
		if maze.get(number):
			if _air_drifted(ep, maze[number]): skipped += 1
			else: fa = maze[number]
		# LOCAL PATCH 2026-10-25 (4.0.5): Trakt's time under the same drift check -- it can number a season differently too
		if not fa and trakt.get(number):
			if _air_drifted(ep, trakt[number]): skipped += 1
			else: fa = trakt[number]
		if fa: ep['first_aired_utc'] = fa
		elif src == 'tmdb' or maze or trakt: ep.pop('first_aired_utc', None)
	if skipped:
		from modules.kodi_utils import logger
		logger('TV air times', 'tmdb %s S%s: %d TVmaze / Trakt time(s) left out, dated over %d days from TMDb'
			% (meta.get('tmdb_id'), season, skipped, _TV_AIR_DRIFT_DAYS))
	return True

class _TvAirRedo:
	"""A cached TV season's air times redone with the current 'TV Air Times' choice, as a _backfill_or_defer link."""
	def __init__(self, data, prop_string, season):
		self.data, self.prop_string, self.season = data, prop_string, season
	def __call__(self, meta, current_date=None, current_time=None):
		try:
			if _season_over(meta, self.season): done = _stamp_tv_air(meta, self.data)   # LOCAL PATCH 2026-10-19
			else: done = _tv_air_times(meta, self.season, self.data)
			if done:
				meta_cache.set_season(self.prop_string, self.data, _thumbless_expiration(self.data, _season_expiration(meta, self.season)))
		except Exception: pass
	def __eq__(self, other):
		return isinstance(other, _TvAirRedo) and other.prop_string == self.prop_string
	def __hash__(self):
		return hash(('tv_air_redo', self.prop_string))

# LOCAL PATCH 2026-10-19: exact air times only decide whether an episode has aired yet (episodes.py) and the status
# chip's next / last episode. For a season whose episodes all aired days ago neither can change, yet every cold one
# fetched them: 181 of 247 cached Trakt air-time seasons had every episode over 60 days old, each a Trakt request (plus
# TVmaze's lookup + episodes for TV) and up to a 1 s wait -- 15 s for anime, which joins Trakt. Such a season keeps
# TMDb's dates and is stamped with the current 'TV Air Times' choice, so _TvAirRedo does not come back for it.
_SEASON_OVER_DAYS = 7

def _season_over(meta, season):
	"""True when every episode of `season` aired over _SEASON_OVER_DAYS ago, by the show's last / next episode."""
	try:
		season = int(season)
		extra = meta.get('extra_info') or {}
		last, nxt = extra.get('last_episode_to_air') or {}, extra.get('next_episode_to_air') or {}
		last_season = int(last.get('season_number') or 0)
		if season < 1 or not last_season: return False
		if nxt and int(nxt.get('season_number') or 0) == season: return False
		if season < last_season: return True
		if season > last_season: return False
		import datetime
		aired = _iso_day(last.get('air_date'))
		return bool(aired) and (datetime.date.today() - aired).days > _SEASON_OVER_DAYS
	except Exception: return False

def _stamp_tv_air(meta, data):
	"""A season that is over: TMDb's dates stand; it records the current choice as done. True (there was nothing to ask)."""
	src = _tv_air_choice(meta)
	if src is not None:
		for ep in data: ep['_tv_air'] = src
	return True

def _season_expiration(meta, season):
	"""Hours a season's episode list is cached: half a year once the season is over, 4 days while it airs."""
	# LOCAL PATCH 2026-10-25 (4.0.5): an earlier season only once it is over (_season_over). TMDb's number_of_seasons counts
	# an announced next season, so 'total_seasons > season' froze the season still airing for half a year. Specials keep
	# the old rule (_season_over never calls season 0 over).
	try: season = int(season)
	except (TypeError, ValueError): return 96
	if meta.get('status') in ('Ended', 'Canceled'): return 4368
	try: later = int(meta.get('total_seasons') or 0) > season
	except (TypeError, ValueError): later = False
	if later and (season == 0 or _season_over(meta, season)): return 4368
	return 96

def _season_count(meta, season):
	"""The episode_count the show's details give `season`, 0 when unknown (LOCAL PATCH 2026-10-25, 4.0.5)."""
	try: return int(next((s.get('episode_count') for s in (meta.get('season_data') or []) if int(s.get('season_number')) == int(season)), 0) or 0)
	except Exception: return 0

def _season_grew(meta, season, data):
	"""LOCAL PATCH 2026-10-25 (4.0.5): True when the show's details count more episodes for `season` than a cached season had
	at its fetch ('_ep_count' on its first episode; rows from before carry none and use their length). Compared with the
	count at fetch time, not the length alone, so a season TMDb lists fewer episodes for than it counts is not refetched on
	every read. An empty cached season counts as grown once the details list any episode."""
	try:
		count = _season_count(meta, season)
		if not count or not isinstance(data, list): return False
		if not data: return True
		first = data[0] if isinstance(data[0], dict) else {}
		return count > max(int(first.get('_ep_count') or 0), len(data))
	except Exception: return False

def _fill_runtimes(data, meta):
	"""LOCAL PATCH 2026-10-25 (4.0.5): an episode without a runtime gets the median of the season's known ones, else the show
	duration, else stays 0 (it was a flat 30 min). Durations in seconds, in place."""
	try:
		known = sorted(ep['duration'] for ep in data if ep.get('duration'))
		if known: fill = known[len(known) // 2]
		else: fill = int(meta.get('duration') or 0)
		if not fill: return
		for ep in data:
			if not ep.get('duration'): ep['duration'] = fill
	except Exception: pass

def _iso_day(text):
	"""'YYYY-MM-DD' -> date, or None. Not strptime: Kodi's Python 3.8 breaks it on worker threads."""
	import datetime
	try: return datetime.date(*(int(part) for part in str(text)[:10].split('-')))
	except Exception: return None

def _anilist_air_times(meta, season, data):
	"""LOCAL PATCH 2026-10-13: AniList's broadcast times on an anime season's episodes, in place. True once they were
	read (each episode then carries '_al_air', so a cached season is done once), False when there was nothing to do or
	AniList did not answer.

	TMDb, Trakt and AniDB can all be a week out for an anime: Overgeared (AniList 212888) airs Saturdays from 2026-09-27
	and its Crunchyroll releases land at 14:30 UTC that day, while all three date it from 10-02, so E3 counted as unaired
	the day it was watched, and E4 would have stayed off Next Episodes / the Next Episode alert for five days. AniList's
	time replaces first_aired_utc (which the aired checks already prefer to the date), and becomes 'premiered' when the
	two dates are 2+ days apart -- a different calendar, not a time zone.

	Only RECENT episodes are touched -- dated in the last 30 days, later, or undated: an old episode's date decides
	nothing this is for, and Fribb's offsets can be stale exactly there. Tokyo Revengers and Re:ZERO are one long TMDb
	season each, still airing; read through Fribb's Tenjiku offset (36, really 37) E37 took Tenjiku ep 1's date, and
	scrapers/external._dated_cour_starts, which re-reads those offsets FROM the TMDb dates, stopped correcting them
	(snap_check 6 failed). Episodes map to AniList entries through Fribb, else the entry starting the season
	(anilist_entry_for_tmdb_episode, as the scrape and scrobble do). One AniList request per entry, cached 12 h."""
	try: season = int(season)
	except (TypeError, ValueError): return False
	if season < 1 or not data or not is_anime_check(meta): return False
	import datetime
	# LOCAL PATCH 2026-10-15: the source is the 'Anime Air Times' choice -- AniList (Japan), AnimeSchedule English Sub / Dub
	# (AniList's times shifted by the track's lag, apis/animeschedule_api), or Trakt / TMDb (nothing applied). Every episode
	# keeps the dates it had before any of this in '_air_orig', so a change of choice recomputes from those instead of
	# shifting a shifted date; '_air_src' records the choice a cached season was done with (episodes_meta redoes it on a
	# change). A season done before this existed already had AniList's dates written over TMDb's: those are its originals.
	src = airtime_source()
	def _originals():
		# applied only once the new times are in hand: a failed fetch below must leave the season as it was
		for ep in data:
			if '_air_orig' not in ep: ep['_air_orig'] = [ep.get('premiered'), ep.get('first_aired_utc')]
			else: ep['premiered'], ep['first_aired_utc'] = ep['_air_orig']
			if not ep.get('first_aired_utc'): ep.pop('first_aired_utc', None)
	if src == 'tmdb':
		_originals()
		for ep in data: ep.pop('_al_air', None); ep['_air_src'] = src
		return True
	# a dub can trail Japan by months: its episodes are looked at further back than the 30 days AniList's are
	cutoff = (datetime.date.today() - datetime.timedelta(days=120 if src == 'dub' else 30)).isoformat()
	dates = dict((int(ep['episode']), ((ep.get('_air_orig') or [ep.get('premiered')])[0] or '')[:10]) for ep in data if ep.get('episode'))
	recent = sorted(n for n, d in dates.items() if not d or d >= cutoff)
	if not recent: return False
	# LOCAL PATCH 2026-10-15: not while AniList is backing us off (429, down, unreachable -- _post_anilist starts the
	# cooldown). Returns False, so _al_air stays unset and the season is tried again once the cooldown ends.
	from apis.anilist_api import anilist_score_on_cooldown
	if anilist_score_on_cooldown(): return False
	from modules.kodi_utils import logger
	try:
		from caches import fribb_mappings
		from apis.anilist_api import anilist_entry_for_tmdb_episode, anilist_air_times, anilist_episode_count
		tmdb_id, where = int(meta.get('tmdb_id')), {}
		for n in recent:
			if anilist_score_on_cooldown(): return False   # AniList failed mid-loop: stop asking (see above)
			cour = fribb_mappings.find_cour_by_tmdb_coords(tmdb_id, season, n) or {}
			# LOCAL PATCH 2026-10-15: the guard player._anime_entry and the scrape already apply. Fribb's last row of a
			# season is open-ended, so an episode TMDb folded in after Fribb mapped it lands on the old, shorter entry
			# (A Wild Last Boss Appeared S1E13 -> the 12-episode 180523), which has no air time for it -- and the
			# air-date fallback below, the path written for exactly these new seasons, was never reached.
			try:
				if cour.get('cour_ep') and cour.get('anilist') and int(cour['cour_ep']) > 1:
					_len = anilist_episode_count(cour['anilist'])
					if _len and int(cour['cour_ep']) > int(_len): cour = {}
			except Exception: pass
			if cour.get('anilist') and cour.get('cour_ep'):
				where[n] = (int(cour['anilist']), int(cour['cour_ep']))
				continue
			got = anilist_entry_for_tmdb_episode(meta, season, n, air_dates=dates)
			if got.get('anilist') and got.get('episode'): where[n] = (int(got['anilist']), int(got['episode']))
		times = {}
		for anilist_id in set(a for a, _e in where.values()):
			got = anilist_air_times(anilist_id, min(e for a, e in where.values() if a == anilist_id))
			if got is None: return False
			times[anilist_id] = got
		if src in ('sub', 'dub'):
			from apis import animeschedule_api
			for anilist_id in list(times):
				record = animeschedule_api.record_for_anilist(anilist_id)
				if record is None: return False   # did not answer: _air_src stays unset, the season is tried again
				numbers = sorted(e for a, e in where.values() if a == anilist_id)
				track = animeschedule_api.track_times(record, src, times[anilist_id], numbers) if record else {}
				if track: times[anilist_id] = track
				else: logger('anime air times', 'tmdb %s S%s: AnimeSchedule has no %s date for anilist %s -- Japanese times kept'
							% (meta.get('tmdb_id'), season, src, anilist_id))
	except Exception as e:
		logger('anilist air times', 'tmdb %s S%s: %s' % (meta.get('tmdb_id'), season, e))
		return False
	moved = []
	_originals()
	for ep in data:
		ep['_al_air'], ep['_air_src'] = 1, src
		anilist_id, number = where.get(int(ep.get('episode') or 0), (None, None))
		stamp = times.get(anilist_id, {}).get(number)
		if not stamp: continue
		ep['first_aired_utc'] = datetime.datetime.fromtimestamp(stamp, datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.000Z')
		local, tmdb = datetime.datetime.fromtimestamp(stamp).date(), _iso_day(ep.get('premiered'))
		if not tmdb or abs((local - tmdb).days) >= 2:
			moved.append('E%s %s->%s' % (ep.get('episode'), ep.get('premiered'), local.isoformat()))
			ep['premiered'] = local.isoformat()
	if moved: logger('anilist air times', 'tmdb %s S%s (%s): %s' % (meta.get('tmdb_id'), season, src, ', '.join(moved)))
	return True

def tmdb_air_day(ep):
	"""LOCAL PATCH 2026-10-25: an episode's own TMDb air day ('YYYY-MM-DD' or ''), from before _anilist_air_times moved it.
	For cour matching, which compares TMDb's dates against AniList / ani.zip's Japanese ones within 2-3 days: with the English
	Dub choice an airing episode's 'premiered' is its dub day, typically 14 days late, and every such check failed."""
	return (((ep.get('_air_orig') or [None])[0] or ep.get('premiered')) or '')[:10]

_AIRTIME_NO_TOKEN_LOGGED = []

def airtime_source():
	"""LOCAL PATCH 2026-10-15: the 'Anime Air Times' choice in effect: 'anilist', 'sub', 'dub' or 'tmdb'. A sub / dub
	choice with no AnimeSchedule token reads as 'anilist' (its API needs the user's own token, see
	apis/animeschedule_api) -- and since cached seasons are redone whenever this changes, adding the token later
	switches them over by itself."""
	from modules.settings import anime_provider
	src = _memo_setting('anime_air', lambda: anime_provider('airtime'))
	if src in ('sub', 'dub'):
		from apis.animeschedule_api import available
		if not available():
			if not _AIRTIME_NO_TOKEN_LOGGED:
				_AIRTIME_NO_TOKEN_LOGGED.append(1)
				from modules.kodi_utils import logger
				logger('anime air times', 'English %s chosen but no AnimeSchedule token set -- using AniList (Japan)' % src)
			return 'anilist'
	return src

def _season_air_src(data):
	"""The air-time source a cached season was done with (None: never); seasons done before 2026-10-15 are AniList's."""
	first = data[0] if data else {}
	return first.get('_air_src') or ('anilist' if first.get('_al_air') else None)

# LOCAL PATCH 2026-10-16: the status chip's one format (user's spec) -- 'Label  .  detail', the dot drawn by AF3
# (Includes_Info.xml). Shows being watched: episode, exact date, air time when known ('E6 . Wed 21 Oct 09:30',
# 'Season 4 ended 16 Sep', 'returns Fri 9 Jan'). Shows not watched: the season alone, a date only on a premiere
# ('Season 6', 'Season 2 premieres . Sat 3 Jan', '5 seasons'). Dates: weekday for one ahead, none for one past, the year
# only when not this one, no zero padding ('4 Oct', not '04 Oct').
def _strf(fmt, when):
	# as TMDb Helper's get_region_date: strftime chokes on non-ASCII in a region format
	return when.strftime(fmt.encode('unicode-escape').decode()).encode().decode('unicode-escape')

def _chip_date(when, today, weekday=False, time_fmt=None):
	"""'21 Oct', 'Wed 21 Oct', 'Thu 8 Jul 2027', 'Wed 21 Oct 09:30' (time_fmt, this year only)."""
	text = '%d %s' % (when.day, _strf('%b', when))
	if weekday: text = '%s %s' % (_strf('%a', when), text)
	if when.year != today.year: return '%s %d' % (text, when.year)
	return '%s %s' % (text, _strf(time_fmt, when)) if time_fmt else text

def _season_shown(meta, anime, season, episode):
	"""A TMDb season as the lists show it -- the cour number for anime ('Season 2' for Black Clover's 2nd cour)."""
	season = int(season or 1)
	if anime:
		try: return int(cour_display_numbers(meta, season, int(episode or 1))[0])
		except Exception: pass
	return season

def _seasons_text(n):
	return '%d season%s' % (n, '' if n == 1 else 's')

def _chip_when(when, today, time_fmt=None):
	"""LOCAL PATCH 2026-10-24: an upcoming date as people say it (user's call, home Tight stack) -- 'Tonight 9:00 PM',
	'Tomorrow 6:30 AM', 'Wednesday 6:30 AM' within six days, then '12 Nov' with no time ('Thu 8 Jul 2027' another year).
	The time only for a real air time (time_fmt); a 12-hour clock loses its leading zero ('6:30 AM', not '06:30 AM')."""
	days = (when.date() - today).days
	if days < 0 or days > 6: return _chip_date(when, today)
	clock = ''
	if time_fmt:
		clock = _strf(time_fmt, when)
		if '%I' in time_fmt: clock = clock.lstrip('0')
	if days == 0: day = 'Tonight' if clock and when.hour >= 17 else 'Today'
	elif days == 1: day = 'Tomorrow'
	else: day = _strf('%A', when)
	return '%s %s' % (day, clock) if clock else day

_RELEASE_RECENT_DAYS = 30

def release_label(premiered, movie=True):
	"""LOCAL PATCH 2026-10-25: the facts line's date for a title that is not out yet or came out lately (user's call: upcoming
	and the last _RELEASE_RECENT_DAYS days) -- 'Releases Friday', 'Releases 12 Dec', 'Out today', 'Released 23 Oct' (a show:
	'Premieres' / 'Premiered'). '' otherwise, and AF3 shows the year. A Kodi skin cannot compare dates, hence a property."""
	try:
		import datetime
		# datetime_workaround: datetime.strptime raises TypeError in Kodi's sub-interpreters after the first call, and the
		# except below turned that into '' -- the label was empty in Kodi while correct in plain Python
		when = datetime_workaround(str(premiered)[:10], '%Y-%m-%d')
	except (TypeError, ValueError): return ''
	today = datetime.date.today()
	days = (when.date() - today).days
	if days == 0: return 'Out today'
	if days > 0: return '%s %s' % ('Releases' if movie else 'Premieres', _chip_when(when, today))
	if -days <= _RELEASE_RECENT_DAYS: return '%s %s' % ('Released' if movie else 'Premiered', _chip_date(when, today))
	return ''

_CINEMA_ONLY_DAYS = 90

def in_cinemas(premiered, digital):
	"""LOCAL PATCH 2026-10-25: True while a film is out but only in cinemas (user's call: the date as release_label gives it,
	plus a flag) -- opened today or within _CINEMA_ONLY_DAYS, and no digital release yet (digital_release: TMDb types 4/5,
	any country) or only a future one. A digital date on or before the cinema one is a streaming release: no flag. Past
	_CINEMA_ONLY_DAYS a missing digital date is more likely TMDb not listing it. digital=None (a meta cached before
	digital_release existed) never flags -- nothing is fetched for a list row."""
	if digital is None: return False
	import datetime
	def _day(value):
		try: return datetime_workaround(str(value)[:10], '%Y-%m-%d').date()   # not datetime.strptime: see release_label
		except (TypeError, ValueError): return None
	today, cinema, online = datetime.date.today(), _day(premiered), _day(digital)
	if not cinema or cinema > today or (today - cinema).days > _CINEMA_ONLY_DAYS: return False
	if online and (online <= today or online <= cinema): return False
	return True

def shown_season_count(meta):
	"""LOCAL PATCH 2026-10-24: the show's season count as the lists and the status number seasons -- cours for anime. TMDb
	files The Apothecary Diaries' three cours under one season, so its tile read '1 Season' beside 'Airing . S3E5'. Anime:
	the cour of the latest aired episode, never fewer than TMDb's count; everything else: TMDb's number_of_seasons."""
	try: total = int(meta.get('total_seasons') or 0)
	except (TypeError, ValueError): total = 0
	try:
		if not is_anime_check(meta): return total
		last_ep = (meta.get('extra_info') or {}).get('last_episode_to_air') or {}
		if not last_ep.get('season_number'): return total
		return max(total, _season_shown(meta, True, last_ep['season_number'], last_ep.get('episode_number')))
	except Exception: return total

_STATE_TONES = {'Ended': 'done', 'Canceled': 'cut', 'Renewed': 'soon'}

def _split_status(props):
	"""LOCAL PATCH 2026-10-24: the status for AF3's home facts line (user's calls): 'deadlight.state', a few words after the
	season count, and 'deadlight.state_tone', which colours it and its dot. The original pair stays for every other view.
	Only what a source CONFIRMS (user): a scheduled episode or premiere, an announcement, a dated return, TVmaze / TMDb's
	Renewed / Ended / Canceled. What DeadLight infers from silence says nothing: Awaiting renewal / sequel, 'Last aired'
	(nothing scheduled), a break with no return date, a season just ended (the count says it), anything unrecognised.
	  live  green  'New episode Wednesday' / 'New episode tonight' / 'Airing' (an episode scheduled, its day unknown)
	  soon  blue   'Season 3 premieres Sat 3 Jan' / 'Premieres Saturday' / 'Season 4 announced' / 'Renewed'
	  break amber  'On break · back Fri 9 Jan'
	  done  grey   'Ended'        cut  red  'Canceled'
	The season count is on the line already, so a detail that only repeats it ('Ended . 4 seasons') is dropped."""
	label, detail = props.get('deadlight.status') or '', props.get('deadlight.status_date') or ''
	if not label: return props
	bare_season = detail.startswith('Season ') and detail[7:].isdigit()
	if label in _STATE_TONES: state, tone = label, _STATE_TONES[label]
	elif label == 'Airing':
		# 'S1E5 . Wednesday 6:30 AM' -> 'New episode Wednesday': the day, not the episode or the time
		import re
		day = '' if bare_season else re.sub(r'\s+\d{1,2}:\d{2}(\s?[AaPp][Mm])?$', '', detail.split(' · ')[-1]).strip()
		if day in ('Today', 'Tonight', 'Tomorrow'): day = day.lower()
		state, tone = ('New episode %s' % day) if day else 'Airing', 'live'
	elif label == 'Mid-season break' and detail.startswith('returns '):
		state, tone = 'On break · back %s' % detail[len('returns '):], 'break'
	elif label.lower().endswith(('premieres', 'announced')): state, tone = ('%s %s' % (label, detail)).strip(), 'soon'
	# not confirmed: 'Last aired', a dateless break, 'Season N ended' (the count says it; TVmaze is asked as soon as nothing
	# is scheduled, and its Renewed / Ended replace this once it lists them), Awaiting renewal / sequel, anything else
	else: state, tone = '', ''
	props['deadlight.state'], props['deadlight.state_tone'] = state, tone
	return props

def show_status_props(meta, light=False):
	"""The status chip's properties (see _show_status_props), plus the split for the home Tight stack (_split_status)."""
	return _split_status(_show_status_props(meta, light))

def _ended_props(meta, anime, last_ep, today, light):
	"""'Ended' / 'Canceled' . '5 seasons' -- the seasons aired, for watched and not watched alike; {} with nothing aired."""
	try:
		season = last_ep.get('season_number')
		if not season: return {}
		shown = _season_shown(meta, anime, season, last_ep.get('episode_number'))
		label = 'Canceled' if meta.get('status') == 'Canceled' else 'Ended'
		# the seasons it aired, no date -- watched or not (user's call, 2026-10-16): 'Ended  .  4 seasons'
		return {'deadlight.status': label, 'deadlight.status_date': _seasons_text(shown)}
	except Exception: return {}

def _show_status_props(meta, light=False):
	"""LOCAL PATCH 2026-10-13: a show tile's status for AF3's status chip, which otherwise shows TMDb Helper's
	('Returning 2026-09-28', straight from TMDb). Two property sets:

	'deadlight.status' + 'deadlight.status_date' -- the chip's label and date, for TV and anime alike:
	  Airing            'S2E4 . Sat 18 Oct 20:00' next episode of a season in progress (the time when AniList / Trakt
	                                               gave one -- first_aired_utc -- else the day only)
	  Last aired        'S3E8 . 25 Sep'           a season's latest episode, nothing next yet (season as the lists number it)
	  Premieres         'Sat 3 Jan'               next episode is a season's first ('Season 2 premieres')
	  Mid-season break  'returns 9 Jan'           TMDb flags the last aired episode a mid-season finale, or the next
	                                               one is more than 14 days away
	  Season 4 / Part 2 '2027', 'Winter 2027'     nothing more this season, and a next one is announced -- TMDb's
	                                               upcoming season for TV, AniList's sequel for anime (TMDb says only
	                                               'Returning Series' until it has an episode date: Mushoku Tensei
	                                               III Part 2 is on AniList for 2027)
	  Ended / Canceled / nothing known: no status -- the chip shows TMDb Helper's as before.

	'deadlight.air_source' + 'deadlight.next_aired' / 'deadlight.last_aired' (+ '.long', day counts) -- anime only,
	AniList's dates in TMDb Helper's shapes, read by the chip's date and AF3's 'Next episode' panel (TMDb can be a
	week late: Overgeared's E3 read 16/10, aired 10-11; see _anilist_air_times).

	Requests: the season of TMDb's next / last episode is read through episodes_meta for a show still airing (a next
	episode announced, or the last within 30 days) -- usually cached; else one TMDb season request (+ Trakt's air times,
	+ AniList's for anime), kept for days. The AniList sequel lookup: Returning anime with nothing left to air, one
	request a day. A first version read the season cache only and most tiles got nothing (2 of 6 'Watching').

	LOCAL PATCH 2026-10-16: light=True (shows not watched, user's call) makes NO request: the same labels from the show
	details already in meta -- TMDb's next / last episode and season list. The date is the day only (TMDb's, which can
	trail AniList's for anime by days), no AniList sequel; a next episode dated in the past (stale details) says nothing,
	and the chip falls back to TMDb Helper's as before. See _light_status."""
	try:
		import datetime, time
		if meta.get('status') not in ('Returning Series', 'In Production', 'Planned', 'Ended', 'Canceled'): return {}
		anime = is_anime_check(meta)
		extra_info = meta.get('extra_info') or {}
		next_ep, last_ep = extra_info.get('next_episode_to_air') or {}, extra_info.get('last_episode_to_air') or {}
		today = datetime.date.today()
		# LOCAL PATCH 2026-10-16: an ended / canceled show has its own chip too (was TMDb Helper's bare 'Ended') -- no request
		if meta.get('status') in ('Ended', 'Canceled'): return _ended_props(meta, anime, last_ep, today, light)
		cutoff = (today - datetime.timedelta(days=30)).isoformat()
		now = time.time()
		try:
			from xbmc import getRegion
			formats = (getRegion('dateshort') or '%d/%m/%Y', getRegion('datelong') or '%A, %d %B %Y', (getRegion('time') or '%H:%M').replace(':%S', ''))
		except Exception: formats = ('%d/%m/%Y', '%A, %d %B %Y', '%H:%M')
		_fmt = _strf
		def _day(when, exact):
			# the year once it is not this one (Silo's Season 4 is 2027); a time only for a real air time
			# LOCAL PATCH 2026-10-24: said as people say it -- 'Tomorrow 6:30 AM', 'Wednesday', '12 Nov' (_chip_when)
			return _chip_when(when, today, formats[2] if exact else None)
		props, last = {}, None
		if light: return _light_status(meta, anime, next_ep, last_ep, today, cutoff, _fmt, _day)
		ref = next_ep or (last_ep if (last_ep.get('air_date') or '') >= cutoff else {})
		if ref.get('season_number'):
			data = episodes_meta(ref['season_number'], meta) or []
			from apis.trakt_air import _utc_from_iso
			timeline = []   # (stamp, exact, episode, aired_at)
			# LOCAL PATCH 2026-10-25 (4.0.5): past / future by the lists' own aired rule (aired_at) -- a date alone at 20:00 +
			# date_offset, a real time as it is, both plus air_grace (settings.with_air_grace). The chip took a date-only
			# episode as aired at 23:59:59 and an exact one with no grace, so it could call an episode the lists still hide
			# 'Last aired', or one they show 'Airing'. The stamp shown is unchanged (a date alone still shows its own day).
			from modules.utils import adjust_premiered_datetime
			from modules.settings import with_air_grace, date_offset
			_offset = date_offset()
			def _aired_at(dt):
				try: return time.mktime(with_air_grace(dt).timetuple())
				except Exception: return None
			for ep in data:
				try:
					if ep.get('first_aired_utc'):
						stamp = _utc_from_iso(ep['first_aired_utc']).timestamp()
						aired_at = _aired_at(datetime.datetime.fromtimestamp(stamp))
						timeline.append((stamp, True, ep, stamp if aired_at is None else aired_at))
					elif ep.get('premiered'):
						# a date alone: shown as its day (episodes.py's 20:00 guess is for the aired test, not a label)
						stamp = time.mktime(_iso_day(ep['premiered']).timetuple()) + 86399
						aired_at = _aired_at(adjust_premiered_datetime(ep['premiered'][:10], _offset))
						timeline.append((stamp, False, ep, stamp if aired_at is None else aired_at))
				except Exception: pass
			past, future = [t for t in timeline if t[3] <= now], [t for t in timeline if t[3] > now]
			# ties broken by episode number: a whole season released at once (Dupahiya S2, 8 episodes on 2026-10-01) is ONE
			# timestamp, and max() took E1 -- 'Last aired . E1' instead of E8's 'Season 2 ended'
			_order = lambda t: (t[0], int(t[2].get('episode') or 0))
			last, upcoming = (max(past, key=_order) if past else None), (min(future, key=_order) if future else None)
			if anime and data and data[0].get('_al_air'):
				props['deadlight.air_source'] = 'anilist'
				for name, item in (('deadlight.next_aired', upcoming), ('deadlight.last_aired', last)):
					if not item: continue
					when = datetime.datetime.fromtimestamp(item[0])
					days = abs((when.date() - today).days)
					props.update({name: _fmt(formats[0], when), name + '.long': _fmt(formats[1], when),
						name + ('.days_until_aired' if item[3] > now else '.days_from_aired'): str(days)})
			if upcoming:
				when, exact, ep = datetime.datetime.fromtimestamp(upcoming[0]), upcoming[1], upcoming[2]
				# the episode as the season numbers it: 'E3', not TMDb's 'E51' for The Apothecary Diaries' 3rd cour
				season, number = int(ep.get('season') or 1), int(ep.get('episode') or 0)
				if anime:
					try: season, number = (int(i) for i in cour_display_numbers(meta, season, number))
					except Exception: pass
				# a premiere is a season's first episode -- by that numbering, or right after a season finale: TMDb files all
				# of Shangri-La Frontier under season 1, so its 3rd season's opener (2027-01-10) is 'E51' after E50's
				# 'season_finale', and read as a 9-month 'Mid-season break'
				if number == 1 or (last and last[2].get('episode_type') == 'season_finale'):
					label = ('Premieres' if season == 1 else 'Season %d premieres' % season) if number == 1 else None
					if label is None:
						# LOCAL PATCH 2026-10-16: the season after the last one aired, counted as the lists count (cours for anime),
						# was 'New season premieres': Shangri-La's E51 follows S1E50 = cour 2, so 'Season 3'. AniList's sequel
						# name wins when it says more ('Part 2'); Fribb may not know the new season yet (E51 read '2x26')
						label = 'Season %d premieres' % (_season_shown(meta, anime, last[2].get('season'), last[2].get('episode')) + 1)
						if anime:
							sequel = _anime_sequel(meta, last_ep)
							if sequel and ' Part ' in sequel[0]: label = '%s premieres' % sequel[0]
					props.update({'deadlight.status': label, 'deadlight.status_date': _day(when, exact)})
				elif (last and last[2].get('episode_type') == 'mid_season_finale') or upcoming[0] - now > 14 * 86400:
					props.update({'deadlight.status': 'Mid-season break', 'deadlight.status_date': 'returns %s' % _chip_date(when, today, True)})
				else:
					# LOCAL PATCH 2026-10-19: with its season, 'S2E3' (was 'E3'; user's call) -- the season as the lists number it
					props.update({'deadlight.status': 'Airing', 'deadlight.status_date': 'S%sE%s · %s' % (season, number, _day(when, exact))})
			elif last and last[2].get('episode_type') == 'mid_season_finale':
				props.update({'deadlight.status': 'Mid-season break', 'deadlight.status_date': ''})
		# also over a dateless break: TMDb flags Mushoku Tensei III's E14 a mid-season finale, and its Part 2 (2027) says more
		if not props.get('deadlight.status_date') and not next_ep and meta.get('status') == 'Returning Series':
			# LOCAL PATCH 2026-10-16: anime asks AniList (usually dated), then TMDb's season list -- each knows seasons the other
			# does not (Record of Ragnarok: S4 on TMDb, no AniList sequel; Akane-banashi: AniList Jan 2027, TMDb undated)
			sequel = _anime_sequel(meta, last_ep) if anime else None
			announced = sequel or _tmdb_next_season(meta, last_ep)
			# 'Season 3 premieres . Sun 10 Jan 2027' / 'Part 2 premieres . Jan 2027' when dated, 'Season 3 announced' when not
			if announced: props.update({'deadlight.status': '%s %s' % (announced[0], 'announced' if announced[1] == 'announced' else 'premieres'),
				'deadlight.status_date': '' if announced[1] == 'announced' else announced[1]})
			elif not anime: props.update(_tv_renewal(meta, last_ep, False, _fmt, today, _day=_day))   # LOCAL PATCH 2026-10-16
			# LOCAL PATCH 2026-10-16: an anime with no sequel announced, 30+ days on -- the show's state, not the season's
			# ('Season 2 ended' said nothing about what comes next; option 3, user's call). Within 30 days 'Season N ended' below.
			elif sequel is False and (last_ep.get('air_date') or '') < cutoff: props.update(_awaiting_sequel(meta, last_ep))
		# a season just over, nothing next: say so. Left to TMDb Helper, Lanterns read 'Returning' + its finale's date --
		# TMDb Helper's own cache (ItemDetails.db) still held the finale as next_episode_to_air, kept until 2026-11-04
		if 'deadlight.status' not in props and ref.get('season_number') and last:
			when = datetime.datetime.fromtimestamp(last[0])
			# 'Season 2 ended . 23 Sep' -- 'Season finale' + a date read as a finale still to come (Saga of Tanya the Evil)
			if last[2].get('episode_type') in ('season_finale', 'series_finale'):
				ended = int(last[2].get('season') or 1)
				if anime:
					try: ended = int(cour_display_numbers(meta, ended, int(last[2].get('episode') or 1))[0])
					except Exception: pass
				props.update({'deadlight.status': 'Season %d ended' % ended, 'deadlight.status_date': _chip_date(when, today)})
			else:
				# 'Last aired . S3E8 . 25 Sep' -- the episode and its season, as on 'Airing' (LOCAL PATCH 2026-10-19: was 'E8')
				season, number = int(last[2].get('season') or 1), int(last[2].get('episode') or 0)
				if anime:
					try: season, number = (int(i) for i in cour_display_numbers(meta, season, number))
					except Exception: pass
				props.update({'deadlight.status': 'Last aired', 'deadlight.status_date': 'S%sE%s · %s' % (season, number, _chip_date(when, today))})
		return props
	except Exception: return {}

def _announced_when(year=None, month=None, day=None, season=None):
	"""'2027' / 'Winter 2027' / 'Jan 2027' / a short date -- as precise as the announcement -- or 'announced'."""
	import datetime
	try:
		# an exact premiere: weekday, no zero padding, the year only when not this one ('Thu 8 Jul 2027'), as every chip date
		if year and month and day: return _chip_date(datetime.datetime(int(year), int(month), int(day)), datetime.date.today(), True)
		if year and month: return datetime.date(int(year), int(month), 1).strftime('%b %Y')
		if year and season: return '%s %s' % (str(season).title(), year)
		if year: return str(year)
	except Exception: pass
	return 'announced'

def _light_status(meta, anime, next_ep, last_ep, today, cutoff, _fmt, _day):
	"""show_status_props(light=True), for a show not being watched: its labels from TMDb's show details alone -- no
	request -- and the season, not the episode; a date only on a premiere (user's spec, 2026-10-16). TMDb's raw
	episode_type is 'finale' / 'mid_season' / 'standard' (episodes_meta's 'season_finale' / 'mid_season_finale' are derived).
	  Airing . Season 6          Premieres . Sat 3 Jan        Season 2 premieres . Sat 3 Jan
	  Mid-season break . Season 3                             Season 4 premieres . Winter 2027 / Season 4 announced
	  Renewed . 9 seasons / Awaiting renewal . Season 1 (TVmaze, cached only)   Ended / Canceled . 4 seasons
	  Season 2 ended             Last aired . Season 3"""
	import datetime
	try:
		last_shown = _season_shown(meta, anime, last_ep.get('season_number'), last_ep.get('episode_number')) if last_ep.get('season_number') else None
		when = _iso_day(next_ep.get('air_date')) if next_ep else None
		if when and when >= today:
			season = _season_shown(meta, anime, next_ep.get('season_number'), next_ep.get('episode_number'))
			number = int(next_ep.get('episode_number') or 0)
			if anime:
				try: number = int(cour_display_numbers(meta, int(next_ep.get('season_number') or 1), number)[1])
				except Exception: pass
			if number == 1 or last_ep.get('episode_type') == 'finale':
				# after a finale with the numbering running on (Shangri-La E51): the season after the last aired, as above
				label = ('Premieres' if season == 1 else 'Season %d premieres' % season) if number == 1 \
					else 'Season %d premieres' % ((last_shown or season) + 1)
				return {'deadlight.status': label, 'deadlight.status_date': _day(_datetime_from_date(when), False)}
			if last_ep.get('episode_type') == 'mid_season' or (when - today).days > 14:
				return {'deadlight.status': 'Mid-season break', 'deadlight.status_date': 'Season %d' % season}
			return {'deadlight.status': 'Airing', 'deadlight.status_date': 'Season %d' % season}
		if next_ep:
			# dated in the past: the details are stale. With no date shown, 'Airing . Season N' still holds while that episode
			# is under two weeks old (American Horror Story's cached 'next' was a week back, and its tile said nothing);
			# older than that, say nothing rather than something wrong
			if when and (today - when).days <= 14:
				return {'deadlight.status': 'Airing', 'deadlight.status_date': 'Season %d' % _season_shown(meta, anime, next_ep.get('season_number'), next_ep.get('episode_number'))}
			return {}
		if meta.get('status') == 'Returning Series':
			# LOCAL PATCH 2026-10-16: anime -- AniList's sequel (the CACHED answer only, never a request) before TMDb's season
			# list, as the watched chip orders them: AniList usually carries the date (Akane-banashi Jan 2027, TMDb undated)
			sequel = _anime_sequel(meta, last_ep, cached_only=True) if anime else None
			announced = sequel or _tmdb_next_season(meta, last_ep)
			if announced:
				return {'deadlight.status': '%s %s' % (announced[0], 'announced' if announced[1] == 'announced' else 'premieres'),
					'deadlight.status_date': '' if announced[1] == 'announced' else announced[1]}
			# LOCAL PATCH 2026-10-16: TVmaze's renewal state -- only what is already cached here, never a request
			if not anime:
				renewal = _tv_renewal(meta, last_ep, True, _fmt, today, light=True, _day=_day)
				if renewal: return renewal
				_queue_tvmaze(meta)   # LOCAL PATCH 2026-10-16: not cached -- asked after the list is shown (user's call)
			# no sequel on AniList and none on TMDb, 30+ days on -> 'Awaiting sequel' (within 30 days 'Season N ended' below)
			elif sequel is False and (last_ep.get('air_date') or '') < cutoff: return _awaiting_sequel(meta, last_ep)
		if last_shown and (last_ep.get('air_date') or '') >= cutoff:
			if last_ep.get('episode_type') == 'finale': return {'deadlight.status': 'Season %d ended' % last_shown, 'deadlight.status_date': ''}
			if last_ep.get('episode_type') == 'mid_season': return {'deadlight.status': 'Mid-season break', 'deadlight.status_date': 'Season %d' % last_shown}
			return {'deadlight.status': 'Last aired', 'deadlight.status_date': 'Season %d' % last_shown}
	except Exception: pass
	return {}

_TV_RENEWAL_LABELS = {'Running': 'Renewed', 'To Be Determined': 'Awaiting renewal', 'In Development': 'Renewed', 'Ended': 'Ended'}

def _awaiting_sequel(meta, last_ep):
	"""LOCAL PATCH 2026-10-16: 'Awaiting sequel . 2 seasons' -- an anime TMDb calls Returning, its last season over 30+
	days, and AniList with no sequel: the show's state (as TV's 'Awaiting renewal'), the seasons counted as the lists are."""
	try:
		shown = _season_shown(meta, True, last_ep.get('season_number'), last_ep.get('episode_number'))
		return {'deadlight.status': 'Awaiting sequel', 'deadlight.status_date': _seasons_text(shown)}
	except Exception: return {}

def _tvmaze_backfill(meta, current_date=None, current_time=None):
	"""LOCAL PATCH 2026-10-16: TVmaze's state for a show the light chip could not place (unwatched, between seasons on
	TMDb). A deferred job: run after the list is delivered (flush_rating_backfills), or by the page prefetch. Two requests,
	cached 12 h / 30 d -- the chip reads them from the next view on."""
	try:
		from apis.tvmaze_api import show_info
		show_info(meta)
	except Exception: pass

def _queue_tvmaze(meta):
	"""LOCAL PATCH 2026-10-16: unwatched shows make no request while their row is built (user's spec); one TMDb leaves
	between seasons with no next episode -- the talk shows on a break, The Ark awaiting renewal -- has its TVmaze state
	fetched in the background instead (user's call), so the chip stops saying 'Last aired'. Only in a listing process."""
	try:
		if _DEFERRED is None or meta.get('blank_entry') or not meta.get('tmdb_id'): return
		from apis.tvmaze_api import show_info_known
		if not show_info_known(meta): _DEFERRED.append((meta, None, None, (_tvmaze_backfill,)))
	except Exception: pass

def _tvmaze_next(nxt, last_ep, today, light, _day):
	"""LOCAL PATCH 2026-10-16: the chip from a next episode only TVmaze lists (user's call): TMDb leaves the nightly talk
	shows without one over a break (Tonight Show: TMDb's last 8 Oct, TVmaze's next Mon 20 Oct). TVmaze numbers some seasons
	by year (S2026E122), so its episode number is shown only when its season is TMDb's. Watched: the day and time, a
	break past 14 days as 'returns'; not watched: the season, a date only on a premiere. {} when the date is past or
	unreadable -- the TMDb-based chip then stands."""
	import datetime, time
	try:
		from apis.trakt_air import _utc_from_iso
		stamp = _utc_from_iso(nxt.get('airstamp')).timestamp()
	except Exception: return {}
	if stamp < time.time() - 86400: return {}
	when = datetime.datetime.fromtimestamp(stamp)
	season = int(last_ep.get('season_number') or 0)
	premiere = int(nxt.get('number') or 0) == 1 and int(nxt.get('season') or 0) != season
	date = _day(when, True) if _day else _chip_date(when, today, True)
	if premiere: return {'deadlight.status': 'Season %d premieres' % (season + 1) if season else 'Premieres', 'deadlight.status_date': _day(when, False) if _day else date}
	if light: return {'deadlight.status': 'Airing', 'deadlight.status_date': 'Season %d' % season if season else ''}
	if stamp - time.time() > 14 * 86400: return {'deadlight.status': 'Mid-season break', 'deadlight.status_date': 'returns %s' % _chip_date(when, today, True)}
	number = int(nxt.get('number') or 0) if int(nxt.get('season') or 0) == season else 0
	# LOCAL PATCH 2026-10-19: 'S63E26', with the season, as the TMDb-based chip (was 'E26')
	return {'deadlight.status': 'Airing', 'deadlight.status_date': ('S%dE%d · %s' % (season, number, date)) if number else date}

def _tv_renewal(meta, last_ep, cached_only, _fmt, today, light=False, _day=None):
	"""LOCAL PATCH 2026-10-16: a TV show between seasons, by TVmaze's status -- TMDb says 'Returning Series' for a show
	renewed and one awaiting a decision alike. 'Renewed' (Running / In Development), 'Awaiting renewal' (To Be
	Determined), 'Ended' (TVmaze knows the end before TMDb does). Renewed / Ended: the seasons aired, no date ('Renewed .
	9 seasons'). Awaiting renewal: dated with the season's end when watched ('Season 3 ended 5 Jul 2024'), the season
	alone when not ('Season 3'). {} when TVmaze has nothing, or still lists a next episode TMDb does not."""
	try:
		from apis.tvmaze_api import show_info
		info = show_info(meta, cached_only=cached_only) or {}
		# LOCAL PATCH 2026-10-16: a next episode TVmaze lists and TMDb does not -- was {} (the chip fell back to 'Last aired')
		if info.get('next'): return _tvmaze_next(info['next'], last_ep, today, light, _day)
		label = _TV_RENEWAL_LABELS.get(info.get('status'))
		if not label: return {}
		# 'Renewed' only with the next season listed: TVmaze leaves 'Running' on shows it never updated (Dupahiya, Chamak);
		# without one the TMDb-based label stands ('Season 2 ended')
		if label == 'Renewed' and not info.get('next_season'): return {}
		season = int(last_ep.get('season_number') or 0)
		# Renewed / Ended: the seasons aired, no date, watched or not (user's call, 2026-10-16) -- 'Renewed  .  9 seasons'
		if label in ('Renewed', 'Ended'): return {'deadlight.status': label, 'deadlight.status_date': _seasons_text(season) if season else ''}
		if light: return {'deadlight.status': label, 'deadlight.status_date': 'Season %d' % season if season else ''}
		last_day = _iso_day(last_ep.get('air_date'))
		# spelled out: AF3 shows it after the label and a dot -- 'Renewed  .  Season 4 ended 16 Sep' (Includes_Info.xml)
		detail = 'Season %d ended %s' % (season, _chip_date(_datetime_from_date(last_day), today)) if last_day and season else ''
		return {'deadlight.status': label, 'deadlight.status_date': detail}
	except Exception: return {}

def _datetime_from_date(day):
	import datetime
	return datetime.datetime(day.year, day.month, day.day)

def _tmdb_next_season(meta, last_ep):
	"""('Season 4', '2027' / a date / 'announced') for a TMDb season after the last aired one, or None."""
	try:
		last_season = int(last_ep.get('season_number') or 0)
		# LOCAL PATCH 2026-10-19: only the season right after the last aired one. TMDb keeps catch-all buckets numbered out of
		# sequence -- Chibi Maruko-chan's undated 'Season 99' (59 uncategorised episodes) read 'Season 99 announced'.
		later = [s for s in (meta.get('season_data') or []) if int(s.get('season_number') or 0) == last_season + 1]
		if not later: return None
		day = _iso_day(later[0].get('air_date'))
		return ('Season %s' % later[0]['season_number'], _announced_when(day.year, day.month, day.day) if day else 'announced')
	except Exception: return None

def _anime_sequel(meta, last_ep, cached_only=False):
	"""('Season 3 Part 2' / 'Season 4', when) for AniList's announced sequel of the entry holding TMDb's last
	aired episode; False when AniList answered that there is none; None when unknown.
	LOCAL PATCH 2026-10-16: cached_only -- Fribb's local mapping and the cached AniList answer only, never a request (the
	chip of a show not being watched); an id Fribb does not map, or an answer not cached, is None."""
	import re
	try:
		season, episode = int(last_ep.get('season_number') or 0), int(last_ep.get('episode_number') or 0)
		if season < 1 or episode < 1: return None
		from caches import fribb_mappings
		cour = fribb_mappings.find_cour_by_tmdb_coords(int(meta.get('tmdb_id')), season, episode) or {}
		if cached_only:
			from caches.lists_cache import lists_cache
			anilist_id = cour.get('anilist')
			got = lists_cache.get('anilist_sequel_%s' % anilist_id) if anilist_id else None
			if not isinstance(got, dict): return None
			sequel = got.get('sequel')
		else:
			from apis.anilist_api import anilist_entry_for_tmdb_episode, anilist_sequel
			anilist_id = cour.get('anilist') or anilist_entry_for_tmdb_episode(meta, season, episode).get('anilist')
			sequel = anilist_sequel(anilist_id) if anilist_id else None
		if sequel is None: return None
		if not sequel: return False
		title = sequel.get('title') or ''
		part = re.search(r'\b(?:part|cour)\s*(\d+)\b', title, re.I)
		number = re.search(r'\bseason\s*(\d+)\b|\b(\d+)(?:st|nd|rd|th)\s+season\b', title, re.I)
		# a title with no number (MASHLE's 'Sanma Taisou Shinkakusha Saishuu Shiken-hen'): the season after the last aired,
		# counted in cours as the lists are (MASHLE S1E24 = cour 2 -> 'Season 3'); was 'New season'
		# a Part names its season too -- 'Part 2' alone left open which (user's call): 'Season 3 Part 2', the season from the title
		# ('One Punch Man Season 3 Part 2', 'Slime 4th Season Part 3') else the last aired one as the lists count it
		# (Mushoku Tensei III ... Part 2: S3E14 -> 3)
		titled = int(number.group(1) or number.group(2)) if number else None
		if part: label = 'Season %d Part %s' % (titled or _season_shown(meta, True, season, episode), part.group(1))
		else: label = 'Season %d' % (titled or _season_shown(meta, True, season, episode) + 1)
		start = sequel.get('start') or {}
		return (label, _announced_when(start.get('year') or sequel.get('season_year'), start.get('month'), start.get('day'), sequel.get('season')))
	except Exception: return None

def all_episodes_meta(meta, include_specials=False, backfill=False):
	def _get_tmdb_episodes(season):
		try: data.extend(episodes_meta(season, meta, backfill))
		except: pass
	try:
		data = []
		season_data = meta['season_data']
		seasons = [i['season_number'] for i in season_data]
		if not include_specials: seasons = [i for i in seasons if not i == 0]
		# LOCAL PATCH 2026-10-03 (3.0.8): at most 6 at once. One thread per season meant 20-30 simultaneous TMDb
		# requests for a long show (One Piece has 22 seasons), each on a cold connection, against a 40/s limit.
		if seasons:
			from modules.utils import TaskPool
			[i.join() for i in TaskPool().tasks(_get_tmdb_episodes, seasons, min(len(seasons), 6))]
	except: pass
	return data

def episode_groups(media_id):
	try: groups = episode_groups_data(media_id)['results']
	except: groups = None
	return groups or None

def group_details(group_id):
	return episode_group_details(group_id)

def group_episode_data(details, episode_id=None, season_number=None, episode_number=None):
	def _comparer(episode_item):
		if episode_id: return episode_item['id'] == int(episode_id)
		else: return episode_item['season_number'] == int(season_number) and episode_item['episode_number'] == int(episode_number)
	groups = details['groups']
	episode_data = next(({'season': item['order'], 'episode': i['order'] + 1} for item in groups for i in item['episodes'] if _comparer(i)), None)
	return episode_data

def movie_meta_external_id(external_source, external_id, api_key):
	return movie_external_id(external_source, external_id, api_key)

def tvshow_meta_external_id(external_source, external_id, api_key):
	return tvshow_external_id(external_source, external_id, api_key)

# LOCAL PATCH 2026-09-29: the first day a real copy of a film can exist -- the earliest DIGITAL (TMDb type 4) or
# PHYSICAL (type 5) release in ANY country, so an early release anywhere counts. '' when TMDb lists neither
# (common for older films). Read by sources.relabel_in_cinemas.
def digital_release_date(release_results):
	try: return min(x['release_date'][:10] for i in release_results for x in i['release_dates'] if x.get('type') in (4, 5) and x.get('release_date'))
	except ValueError: return ''

def movie_expiry(current_date, meta):
	try:
		difference = subtract_dates(current_date, jsondate_to_datetime(meta['premiered'], '%Y-%m-%d', remove_time=True))
		if difference < 0: expiration = abs(difference) + 1
		elif difference <= 14: expiration = 168
		elif difference <= 30: expiration = 336
		elif difference <= 180: expiration = 720
		else: expiration = 4368
	except: return 720
	# LOCAL PATCH 2026-10-25: out only in cinemas (in_cinemas: no digital release yet) -- re-read every 2 days, so a digital
	# date TMDb adds later reaches the meta, and AF3's CINEMA flag clears, within ~2 days rather than 7-30
	if in_cinemas(meta.get('premiered'), meta.get('digital_release')): return 48
	return max(expiration, 168)

def tvshow_expiry(current_date, meta):
	try:
		if meta['status'] in ('Ended', 'Canceled'): expiration = 4368
		else:
			# LOCAL PATCH 2026-10-03: subtract_dates() returns DAYS; the old '- 24' treated them as hours, so every show
			# with an episode due within 25 days sat on a 24 h TTL -- 255 tvshow metas (none Ended) expired within a day,
			# each taking its seasons with it. Expire when the next episode airs, refreshing at least weekly.
			# LOCAL PATCH 2026-10-04: a returning show with NO announced next episode is between seasons, and that is
			# when TMDb adds the next one. It took the 96 h fallback below, so a new season stayed invisible for up to
			# four days: Black Clover's Season 2 (S2E1 2026-10-03) sat behind a copy cached on 10-02 until 10-06. One day
			# instead -- 284 of 985 cached shows were in this state, each refetched at most daily and only when viewed.
			next_ep = (meta.get('extra_info') or {}).get('next_episode_to_air')
			if not next_ep: return 24
			days = subtract_dates(jsondate_to_datetime(next_ep['air_date'], '%Y-%m-%d', remove_time=True), current_date)
			expiration = max(24, min(days, 7) * 24)
	except: expiration = 96
	return expiration

def meta_valid_check(meta, is_anime_list):
	if is_anime_list == None: return meta
	if is_anime_check(meta) != is_anime_list: meta = {}
	return meta

def cour_display_numbers(meta, season, episode):
	"""(season, episode) the way anime is actually numbered, for DISPLAY only.

	LOCAL PATCH 2026-08-27. TMDb files multi-cour anime under one season, so its
	numbering is not what anyone recognises: Frieren S1E30 is season 2 episode 2,
	and every Re:ZERO cour is TMDb season 1. Fribb has the real boundaries offline.

	Callers must use this for LABELS ONLY. The TMDb pair remains the identity for
	play urls, watched state, bookmarks, Trakt/Simkl sync and scraping -- renumbering
	any of those would orphan existing history.

	Returns the input unchanged for non-anime, when the setting is off, or when
	Fribb has no mapping, so every non-anime caller is unaffected.
	"""
	try:
		global _SPLIT_COURS
		if _SPLIT_COURS is None:
			from modules import settings
			_SPLIT_COURS = bool(settings.anime_split_cours())
		if not _SPLIT_COURS: return season, episode
		if str(season) == '0': return season, episode   # LOCAL PATCH 2026-10-17: specials keep TMDb's S00Exx (ids come from _season0_rows)
		if not is_anime_check(meta): return season, episode
		from caches import fribb_mappings
		if not fribb_mappings.is_available(): return season, episode
		info = fribb_mappings.find_cour_by_tmdb_coords(meta.get('tmdb_id'), season, episode)
		if not info: return season, episode
		cs, se = info.get('cour_season'), info.get('season_ep')
		if cs is None or se is None: return season, episode
		alt = _mixed_display_numbers(meta, season, info, int(cs))
		if alt: return alt
		return int(cs), int(se)
	except Exception: return season, episode


_MIXED_DISPLAY = {}   # (tmdb_id, season) -> {anilist_id: the season its AniList title names} or {} -- per process

def _mixed_display_numbers(meta, season, info, tvdb_season):
	"""LOCAL PATCH 2026-10-16: (season, episode) by the AniList entry's own season for a TMDb season the mixed flat
	repair rebuilt (fribb_mappings._mixed_flat_pairs) -- Bungou Stray Dogs E60 is TVDB 'S03E24' (TVDB files Seasons 4+5 as
	its S3) but the season list (seasons._expand_anime_cours) now shows it under 'Season 5', episode 11. Only those seasons
	look further, and the titles come from the season list's own cached bulk lookup (same ids, same key). None when the
	entry's title names no season, or the same one as TVDB."""
	try:
		tmdb_id = int(meta.get('tmdb_id'))
		key = (tmdb_id, int(season))
		if key not in _MIXED_DISPLAY:
			names = {}
			from caches import fribb_mappings
			raw = fribb_mappings._season_cour_rows(tmdb_id, int(season), allow_repair=False)
			if raw and fribb_mappings._mixed_flat_pairs(tmdb_id, int(season), raw):
				count = next((s.get('episode_count') for s in (meta.get('season_data') or []) if s.get('season_number') == int(season)), 0)
				cours = fribb_mappings.cours_for_tmdb_season(tmdb_id, int(season), count or 0)
				ids = [c.get('anilist') for c in cours]
				if ids and all(ids):
					from apis.anilist_api import anilist_media_bulk_by_id
					from indexers.seasons import _title_season
					recs = anilist_media_bulk_by_id(ids) or {}
					names = dict((int(i), _title_season((recs.get(int(i)) or {}).get('title'))) for i in ids)
			_MIXED_DISPLAY[key] = names
		ts = _MIXED_DISPLAY[key].get(int(info.get('anilist') or 0))
		if ts is None or ts == tvdb_season or not info.get('cour_ep'): return None
		return ts, int(info['cour_ep'])
	except Exception: return None


# LOCAL PATCH 2026-10-13: TMDb keywords that make a title anime -- 'anime' (210024) and 'donghua' (315535). TMDb tags
# Chinese animation 'donghua' and NOT 'anime' (Link Click, Scissor Seven, The Founder of Diabolism), yet AniList / MAL / AniDB
# list them and the anime trackers carry them, so the scrape skipped AnimeTosho / SeaDex / nekoBT for them. Detection only:
# the TMDb anime catalogues (with_keywords=210024) are unchanged. Korean animation needs nothing here: what reaches the
# anime trackers (Lookism) TMDb already tags 'anime'; its 'aeni' / 'korean animation' keywords are mostly toy cartoons.
ANIME_KEYWORD_IDS = frozenset((210024, 315535))

def is_anime_check(meta=None, tmdb_id=None):
	if not meta: meta = meta_cache.get('tvshow', 'tmdb_id', tmdb_id)
	# LOCAL PATCH 2026-09-04: short-circuiting any() instead of building the full id list and
	# calling .index() on it. This is now a per-item gate in front of the Fribb index load
	# (indexers/tvshows.py), so it runs for every tile of every TV widget.
	try:
		if any(k.get('id') in ANIME_KEYWORD_IDS for k in meta.get('keywords').get('results', [])): return True
	except: pass
	return untagged_japanese_animation(meta)

def is_anime_meta(meta):
	"""TMDb's 'anime' or 'donghua' keyword (ANIME_KEYWORD_IDS; a movie keeps its keywords under 'keywords', a show
	under 'results'), or anime TMDb has not tagged yet (untagged_japanese_animation). The one test the scrape and the
	Options menu share. LOCAL PATCH 2026-10-15: lives here, not in source_utils, so the movie and TV widgets -- its only
	users on the widget path -- no longer import that 1500-line module and its ~28 regexes in every widget process."""
	try:
		keywords = (meta or {}).get('keywords') or {}
		if any((k or {}).get('id') in ANIME_KEYWORD_IDS for k in keywords.get('results') or keywords.get('keywords') or []): return True
	except Exception: return False
	return untagged_japanese_animation(meta or {})

def untagged_japanese_animation(meta):
	"""LOCAL PATCH 2026-10-05: anime TMDb has not tagged yet -- genre Animation, origin country Japan, and NO keywords at all.
	A new show has none for its first days: Magic Repo Man, Magical Explorer and SSS-Class Revival Hunter (2026-10) were
	plain TV, so the scrape skipped animetosho and nekobt. Only when TMDb has no keywords, so a show it HAS tagged without
	'anime' stays as tagged -- Golden Axe, a Sega/Comedy Central cartoon co-produced in Japan. Measured 2026-10-05: all 117
	tagged anime in the cache are Animation + JP; this adds exactly the three untagged ones. Movies too (keywords.keywords).
	LOCAL PATCH 2026-10-15: a show TMDb HAS keyworded, but without 'anime', still counts when the Fribb list maps its TMDb
	id. Suikoden: The Anime (285710) carries 7 keywords (battle, war, fantasy...) and no 'anime', yet AniList / MAL / AniDB /
	Kitsu all list it. Fribb alone is too broad (AniDB carries Voltron, Star Wars Resistance, Teen Titans Go, Ninjago), so
	only behind the Animation + JP gate, which also keeps Golden Axe out (not in Fribb). Measured on the cache: of 74 Fribb
	titles 72 were already anime; this adds Suikoden only. Fribb's index costs ~30 ms once per process, and only for the rare
	JP animation tile that has keywords but no 'anime'."""
	try:
		if 'Animation' not in (meta.get('genre') or []) or 'JP' not in (meta.get('country_codes') or []): return False
		keywords = meta.get('keywords') or {}
		if not (keywords.get('results') or keywords.get('keywords')): return True
		return _listed_by_fribb(meta)
	except Exception: return False

def _listed_by_fribb(meta):
	from caches import fribb_mappings
	if not fribb_mappings.is_available(): return False
	tmdb_id = meta.get('tmdb_id')
	if meta.get('mediatype') == 'movie': return bool(fribb_mappings.anime_ids_for_tmdb_movie(tmdb_id))
	return bool(fribb_mappings.tmdb_tv_to_fribb_rows(tmdb_id))
