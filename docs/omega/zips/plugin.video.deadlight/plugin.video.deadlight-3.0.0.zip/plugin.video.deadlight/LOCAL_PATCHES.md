# Local patches to DeadLight

This is a local-only git repo. Tracks the user's customizations to the upstream DeadLight AM fork. Companion to the memory file at `~/.claude/projects/.../memory/deadlight_aiostreams_thread_patches.md` (full Find/Replace recipes for each patch — that's the authoritative source for re-applying after an upstream wipe).

## Patches at first commit (2026-05-31)

- AIOStreams (Stremio) scraper as a first-class provider (new file `resources/lib/scrapers/aiostreams.py` + skin UI + settings).
- SmartPlay sticky-source: remembers your last-picked source for a show, auto-replays for next episodes (debrid pack-aware).
- Netflix-style countdown alert for the next-episode auto-play prompt.
- IntroDB intro/outro/recap skip segments + skip-segment window UI.
- Thread-cap guards in `modules/utils.py` for embedded Linux thread limits.
- Upstream bug fixes (TMDB None-safety in dialogs, addon.xml reuselanguageinvoker=false, etc.).
- DeadLight AM revoked Trakt/TMDb/v4 keys — user runs on their own keys (`deadlight.trakt.client`, `deadlight.trakt.secret`, `deadlight.tmdb_api`, `deadlight.tmdb.read_access_token`).
- TMDb v4 Read Access Token user-configurable (3-file patch: `tmdblist_api.py` + `caches/settings_cache.py` + `settings_manager.xml`).
- Performance: router.py `exec()` → `getattr()`, `default_settings()` module-level cache, lazy `requests` import in aiostreams, deferred CustomWindowsPrepare + DatabaseMaintenance from boot, trakt_api lazy `modules.metadata` import, trakt_cache in-process memory tier.
- Widget cold-load: inline OMDb rating fetch in `tvshow_meta` / `movie_meta` + `extra_rating_props` baked into listitem properties (covers all browse paths; covers in-progress / recently-watched at first focus too).

## Workflow

```
# See what's changed since last commit
git status
git diff

# Commit a new patch
git add <files>
git commit -m "Patch: <short description>"

# After an upstream DeadLight update (which overwrites local files):
# 1. Stash any in-progress work: `git stash`
# 2. Overwrite addon files with upstream
# 3. `git status` shows everything changed
# 4. Reset: `git reset --hard HEAD` to drop upstream + restore your patches
#    OR: commit the upstream as "upstream X.Y.Z", then cherry-pick patches back
```

## Not tracked

- `__pycache__/`, `*.pyc` — Python bytecode
- User data lives in `userdata/addon_data/plugin.video.deadlight/`, NOT this directory, so it's safe.
