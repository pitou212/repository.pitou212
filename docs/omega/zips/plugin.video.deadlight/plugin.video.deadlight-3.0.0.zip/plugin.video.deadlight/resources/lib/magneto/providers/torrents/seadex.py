# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-27: SeaDex provider -- the curated best release, by ID.
#
# WHAT SEADEX IS
# releases.moe is a small, hand-maintained index (~2,800 anime) recording which
# release of a given anime is the best one, and why. It is not a tracker and not a
# search engine: for each anime it names specific torrents, with the release group,
# the infoHash, and the full file listing. Entries are keyed on AniList id, which
# scrapers/external.py already resolves and passes in as data['anilist_id'] -- so
# unlike animetosho.py this needs no new mapping layer at all.
#
# WHY IT IS WORTH A PROVIDER
# The other anime providers answer "what exists for this episode?" and return
# everything, sorted by seeders. Seeders measure popularity, not quality. SeaDex
# answers a different question -- "which one should I actually watch?" -- and the
# answer is often a release the seeder sort buries: for Frieren it picks a PMR BD
# Remux at 7.5GB an episode, which no popularity ranking would ever surface first.
#
# Measured against this library before building it (187 anime in metacache):
#   105 shows had a SeaDex entry (56%); the rest fall through to the other providers
#   96% of the curated releases were ALREADY CACHED on TorBox (150/157)
#   99% of covered shows had at least one cached release (104/105)
# That cache rate is the whole reason this is useful rather than aspirational -- a
# curated pick that had to be downloaded first would be no use for streaming.
#
# WHY IT ONLY WORKS NOW
# SeaDex releases are cour PACKS, so playing one means picking the right file out of
# it. That happens in the debrid layer, which until the 2026-08-27 cour-numbering fix
# matched TMDb's episode number against anime filenames and failed. This provider
# would have returned sources that all failed on click before that change landed.
#
# Because the API hands over the file list, this provider does something the others
# cannot: it locates the episode's actual file up front, so it can skip a release
# that does not contain the episode (SeaDex flags some entries `incomplete`) and
# report the true size of the file that will play rather than a divided estimate.
#
# API: https://releases.moe/api/collections/entries/records?filter=alID=<id>&expand=trs
# No key, no auth.

import re

from magneto.modules import client
from magneto.modules import source_utils

try:
	import json as _json
except ImportError:
	_json = None

_API = ('https://releases.moe/api/collections/entries/records'
		'?filter=alID=%s&expand=trs&perPage=1')

# Trackers a magnet needs to be usable if a debrid service has to fetch it fresh.
# SeaDex stores only the infoHash, so the magnet is assembled here.
_TRACKERS = (
	'http://nyaa.tracker.wf:7777/announce',
	'udp://open.stealth.si:80/announce',
	'udp://tracker.opentrackr.org:1337/announce',
	'udp://exodus.desync.com:6969/announce',
	'udp://tracker.torrent.eu.org:451/announce',
)

_VIDEO = ('.mkv', '.mp4', '.avi', '.m4v', '.ts')

# In the pack but not the show: openings, endings, previews, menus, extras. Kept out
# of episode matching so an "NCOP 01" cannot answer a request for episode 1.
_NOT_AN_EPISODE = re.compile(
	r'(?:^|[^a-z0-9])(?:nc)?(?:op|ed)\d*(?:[^a-z0-9]|$)|'
	r'(?:^|[^a-z0-9])(?:menu|preview|pv|cm|extra|extras|bonus|interview|'
	r'trailer|teaser|creditless|clean|sample|logo|special|specials|'
	r'sp\d+|oad|ova|omake|recap)(?:[^a-z0-9]|$)', re.I)


# LOCAL PATCH 2026-09-24: '<show> - 681 - <title>' -- the episode a name states after a dash,
# on the space-normalised name _episode_in builds. See the bare patterns there.
_DASH_NUMBER = re.compile(r'(?:^| )- ?0*(\d{1,4})(?=[ \[(]|$)')
# LOCAL PATCH 2026-09-24: a bit-depth tag is not an episode number -- ' 10 bit' answered episode
# 10 through the bare patterns. Same rule as DeadLight's _RE_BIT_DEPTH; the corpus holds both.
_BIT_DEPTH = re.compile(r'(?<![a-z0-9])(?:8|10|12) ?bits?(?![a-z0-9])', re.I)


def _episode_in(name, season, episode, bare=True):
	"""True when `name` is episode `episode` (of `season`), on clean digit edges.

	Deliberately narrow. This runs over the files of ONE known anime, so the title is
	not in question and only the number has to be read -- which means the loose
	fallbacks a search provider needs (and which cause its false positives) are
	unnecessary here and are left out.
	"""
	n = _BIT_DEPTH.sub(' ', re.sub(r'[._]+', ' ', name))
	e2 = '%02d' % episode
	marked = (
		# LOCAL PATCH 2026-09-24: any padding, not just %02d -- KQRM's 'S001E001' / 'S004E093' and
		# '[Feibanyama] ... EP0001' were unreadable here, the gap DeadLight's matcher had until
		# 0916b7a. Found by addon_patches/anime_names (the shared corpus), which is what keeps the
		# two copies in step now. The right edge is still (?!\d), so e0*1 cannot read e10 or e101.
		# The BARE 'e' form keeps its two digits and may only gain zeros: a CRC32 tag is hex, and
		# with the zero optional '[e2ad4da5]' answered episode 2 and '[E5EC319E]' episode 5 (5
		# wrong picks in the corpus). No CRC can hold the 's' or 'p' the other two forms need.
		r'\bs0*%d ?e0*%d(?!\d)' % (season, episode),
		r'\be0*%s(?!\d)' % e2,
		r'\bep(?:isode)? ?0*%d(?!\d)' % episode,
		r'(?<!\d)- ?%s(?!\d)' % e2,          # "[Group] Show - 07"
		r'(?<!\d)- ?%d(?!\d)' % episode,     # "- 7" and "- 107"
		r'\[%s\](?!\d)' % e2,
	)
	# LOCAL PATCH 2026-09-24: BARE numbers stand down once the name states its episode after a
	# dash and that is a different number -- 'One Piece - 681 - The 500 Million Berry Man!' is
	# not episode 500, '... - 060 - The 1000 Year Legend' is not 1000, 'Mob Psycho 100 - 05' is
	# not 100. Same rule as DeadLight's seas_ep_filter (string7); the corpus holds both to it.
	dash = _DASH_NUMBER.search(n)
	# bare=False: _pick_file found this file outside its pack's dash convention, same stand-down
	if not bare or (dash and int(dash.group(1)) != int(episode)): return any(re.search(p, n, re.I) for p in marked)
	bare = (
		# LOCAL PATCH 2026-09-23: the left edge must be a SPACE, not merely a non-digit.
		#
		# A non-digit edge let this read the TAIL of an SxxExx tag: in 'One Piece S10E22
		# (0358)' the character before 22 is 'E', which passed (?<!\d), and ' (' follows --
		# so a request for S01E22 matched season 10's episode 22. SeaDex files One Piece as
		# one whole-run entry, so every season's E22 sat in the same file list and the four
		# rows returned were S07E22, S10E22, S11E22 and S13E22 -- absolute 217, 358, 403 and
		# 443. The wanted file, 'S01E22 (0022)', is matched by the sXXeYY pattern above and
		# so is unaffected by this narrowing.
		#
		# This is the same edge the bare-number patterns below were already tightened for on
		# 2026-09-22; that comment's claim that 'x264' cannot answer episode 264 held only
		# for those patterns -- here 'x264 (1080p)' matched, because 'x' is not a digit.
		r'(?:(?<= )|^)%s(?!\d)(?= ?[\[(])' % e2,  # "Show 07 [1080p]"
		# LOCAL PATCH 2026-09-22: a bare number delimited by separators, with no hyphen
		# and nothing bracketed after it -- 'Naruto.220.v4.480p.DVD...mkv'. None of the
		# patterns above can read that: there is no 'e220', no '- 220', no '[220]' and the
		# token after the number is 'v4' rather than '[' or '('. It is the usual shape for
		# older DVD batches, and it cost SeaDex every Naruto episode -- releases.moe has
		# alID=20 with a 248-file Nyaa release containing Naruto.220..., and _pick_file
		# returned None for all of them.
		#
		# Both sides must be a SPACE (dots and underscores are normalised to spaces
		# above), not merely a non-digit. That is what keeps it safe: 'v4' cannot answer
		# episode 4 because the character before the 4 is 'v', and 'x264' cannot answer
		# episode 264 because it is preceded by 'x'. A looser non-digit edge would match
		# both. Padding is allowed because a three-digit batch writes 'Naruto 007' -- and
		# (LOCAL PATCH 2026-09-24) a four-digit one 'One Piece 0500', which %03d missed.
		r'(?<= )0*%d(?= )' % episode,
	)
	return any(re.search(p, n, re.I) for p in marked + bare)


def _pick_file(files, candidates):
	"""The file dict for the requested episode, trying candidates in order.

	`candidates` is ordered highest-episode-number first for the same reason the
	debrid resolver orders that way: a pack numbered per-cour holds no file carrying
	the series-absolute number, but a pack numbered absolutely DOES hold a file whose
	number matches the cour-relative one -- and it is the wrong episode.
	"""
	usable = [f for f in files
			if isinstance(f, dict)
			and (f.get('name') or '').lower().endswith(_VIDEO)
			and not _NOT_AN_EPISODE.search(f.get('name') or '')]
	if not usable: return None
	# LOCAL PATCH 2026-09-24: the pack's naming convention -- when two thirds of its files (4 or
	# more) state their episode after a dash, one that does not ('One Piece - The World
	# Navigation 01', a recap in a 783-843 pack) answers only through an explicit marker. Same
	# rule as DeadLight's pick_episode_files; addon_patches/anime_names holds both to it.
	outside = set()
	if len(usable) >= 4:
		dashed = [bool(_DASH_NUMBER.search(re.sub(r'[._]+', ' ', f['name']))) for f in usable]
		if sum(dashed) * 3 >= len(usable) * 2: outside = set(i for i, d in enumerate(dashed) if not d)
	for season, episode in candidates:
		for i, f in enumerate(usable):
			if _episode_in(f['name'], season, episode, bare=i not in outside): return f
	# A single-file entry for a single episode needs no matching at all.
	if len(usable) == 1: return usable[0]
	return None


class source:
	priority = 5
	# Every SeaDex release is already a pack; there is no separate pack query to make,
	# and DeadLight must not ask for one (there is no sources_packs here).
	pack_capable = False
	hasMovies = False
	hasEpisodes = True

	def __init__(self):
		self.language = ['en']
		self.base_link = 'https://releases.moe'
		# SeaDex records no seeder counts. These are curated, widely-mirrored releases
		# and the point of them is the debrid cache, so seeders must gate nothing.
		self.min_seeders = 0
		# 2026-09-26: set when releases.moe did not answer, so DeadLight does not cache the
		# empty result (same contract as nekobt/animetosho). "No SeaDex entry" is a real
		# answer -- JSON with empty items -- and stays cacheable.
		self.request_failed = False

	def _candidates(self, data):
		"""(season, episode) numberings to look for, highest episode number first.

		LOCAL PATCH 2026-08-27: this used to re-derive the ordering, with a docstring
		admitting it 'mirrors' modules/source_utils.anime_episode_candidates on the Fen
		Light side. Two copies of a rule this subtle drift apart, and the two consumers
		-- this provider choosing a file, and the debrid resolver choosing a file out of
		the very same pack -- disagreeing about which numbers count is exactly the bug
		that would be hardest to see. DeadLight now publishes the list it uses, and this
		reads it.

		The local build is a fallback for being driven directly (tests, or any caller
		that did not come through scrapers/external.py).
		"""
		published = data.get('episode_candidates')
		if published:
			out = []
			for pair in published:
				try: out.append((int(pair[0]), int(pair[1])))
				except (TypeError, ValueError, IndexError): continue
			if out: return out
		def _int(key):
			try: return int(data.get(key))
			except (TypeError, ValueError): return None
		season = _int('season') or 1
		cour_season = _int('cour_season') or season
		out = []
		for number, use_season in ((_int('absolute_episode'), season),
						(_int('episode'), season),
						(_int('season_episode'), cour_season),
						(_int('cour_episode'), cour_season)):
			if number and (use_season, number) not in out: out.append((use_season, number))
		out.sort(key=lambda pair: -pair[1])
		return out

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		append = sources.append
		alid = data.get('anilist_id')
		# Without an AniList id there is nothing to look up. Shows whose Fribb row
		# carries no season (Naruto, One Piece and friends) land here and are left to
		# the other providers, which is correct -- SeaDex has no entry for them anyway.
		if not alid: return sources
		try:
			response = client.request(_API % alid, timeout=10)
			if not response:
				self.request_failed = True
				return sources
			payload = _json.loads(response)
			items = (payload or {}).get('items') or []
			if not items: return sources
			entry = items[0]
			torrents = (entry.get('expand') or {}).get('trs') or []
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('SEADEX')
			return sources

		# Public tracker only: SeaDex also indexes private trackers, whose entries
		# carry no usable infoHash and which no debrid service could fetch anyway.
		nyaa = [t for t in torrents if isinstance(t, dict) and t.get('tracker') == 'Nyaa'
				and len(t.get('infoHash') or '') == 40]
		# `isBest` is the entire point of the index -- SeaDex's verdict rather than a
		# popularity measure. Fall back to the rest only when nothing is flagged, which
		# keeps the provider's meaning simple: a SEADEX row IS the curated pick.
		best = [t for t in nyaa if t.get('isBest')] or nyaa
		if not best: return sources

		candidates = self._candidates(data)
		incomplete = bool(entry.get('incomplete'))
		seen = set()
		for torrent in best:
			try:
				info_hash = torrent['infoHash'].lower()
				if info_hash in seen: continue
				chosen = _pick_file(torrent.get('files') or [], candidates)
				# No file for this episode: either the release genuinely stops short
				# (SeaDex marks those `incomplete`) or it covers a season we are not
				# asking for. Returning it would produce a source that cannot play.
				if not chosen: continue
				name = source_utils.clean_name(chosen['name'])
				if not name: continue
				name_info = source_utils.info_from_name(
					name, data.get('tvshowtitle') or '', str(data.get('year') or ''),
					season=str(data.get('season') or ''))
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				magnet = 'magnet:?xt=urn:btih:%s&dn=%s%s' % (
					info_hash, name, ''.join('&tr=%s' % t for t in _TRACKERS))
				quality, info = source_utils.get_release_quality(name_info, magnet)
				# The size of the FILE that will play, not of the pack it sits in. Every
				# other provider can only estimate this by dividing the pack size by an
				# episode count; SeaDex gives the real per-file length.
				dsize = round(float(chosen.get('length') or 0) / 1073741824, 2)
				if dsize: info.insert(0, '%.2f GB' % dsize)
				# LOCAL PATCH 2026-08-27: label multi-episode releases as packs so they are
				# tagged and filterable like any other. Safe to do only because seadex is in
				# scrapers/external.py's no-divide list -- otherwise DeadLight would divide
				# this exact per-file size by the TMDb season's episode_count and wreck it.
				videos = [f for f in (torrent.get('files') or [])
						if isinstance(f, dict) and (f.get('name') or '').lower().endswith(_VIDEO)]
				package = 'season' if len(videos) > 1 else None
				if package:
					total = sum(float(f.get('length') or 0) for f in videos) / 1073741824
					if total: info.append('%.1f GB pack' % total)
				group = torrent.get('releaseGroup')
				if group: info.append('SEADEX %s' % group)
				if torrent.get('dualAudio'): info.append('DUAL AUDIO')
				if incomplete: info.append('INCOMPLETE RELEASE')

				seen.add(info_hash)
				item = {'provider': 'seadex', 'source': 'torrent', 'seeders': 0,
						'hash': info_hash, 'name': name, 'name_info': name_info,
						'quality': quality, 'language': 'en', 'url': magnet,
						'info': ' | '.join(info), 'direct': False, 'debridonly': True,
						'size': dsize}
				if package: item['package'] = package
				append(item)
			except Exception:
				source_utils.scraper_error('SEADEX')
				continue
		return sources
