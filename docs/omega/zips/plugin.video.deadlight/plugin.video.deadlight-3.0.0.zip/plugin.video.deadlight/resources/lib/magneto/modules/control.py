"""
	Bundled magneto -- control layer.

	LOCAL PATCH 2026-09-26: DeadLight carries its torrent providers in resources/lib/magneto (the way
	POV bundles its own copy) instead of loading script.module.magneto. Every other file in this
	package is a verbatim copy of magneto's; this one is rewritten so the same code reads DeadLight's
	settings and keeps its data under DeadLight's profile:

	  * setting('x') reads DeadLight setting 'magneto.x' (default rows in caches/settings_cache.py);
	  * cache.db / undesirables.db live in addon_data/plugin.video.deadlight/magneto/;
	  * the first time that folder has no undesirables.db, magneto's own is copied in, so the user's
	    enabled/disabled defaults and their own keywords carry over unchanged.

	Only the names the bundled modules import are defined here.
"""

import os
import shutil
import xbmc
import xbmcgui
import xbmcvfs
from caches.settings_cache import get_setting, set_setting

homeWindow = xbmcgui.Window(10000)
dialog = xbmcgui.Dialog()
existsPath = xbmcvfs.exists
makeFile = xbmcvfs.mkdir
transPath = xbmcvfs.translatePath
joinPath = os.path.join

dataPath = transPath('special://profile/addon_data/plugin.video.deadlight/magneto/')
cacheFile = joinPath(dataPath, 'cache.db')
undesirablescacheFile = joinPath(dataPath, 'undesirables.db')
_MAGNETO_UNDESIRABLES = transPath('special://profile/addon_data/script.module.magneto/undesirables.db')

def _seed_data():
	if not os.path.isabs(dataPath): return # outside Kodi (test stubs): never create a 'special:' folder
	try:
		if not os.path.isdir(dataPath): os.makedirs(dataPath)
		if not os.path.isfile(undesirablescacheFile) and os.path.isfile(_MAGNETO_UNDESIRABLES):
			shutil.copyfile(_MAGNETO_UNDESIRABLES, undesirablescacheFile)
	except Exception as e:
		xbmc.log('[ DeadLight magneto ] could not prepare %s: %s' % (dataPath, e), xbmc.LOGWARNING)

_seed_data()

def setting(id, fallback=None):
	value = get_setting('deadlight.magneto.%s' % id, '')
	if value in (None, 'None'): value = ''
	if fallback is None: return value
	if value == '': return fallback
	return value

def setSetting(id, value):
	return set_setting('magneto.%s' % id, value)

def lang(language_id):
	return str(language_id)

def addonPath():
	return transPath('special://home/addons/plugin.video.deadlight/')

def addonVersion():
	try:
		import xbmcaddon
		return xbmcaddon.Addon('plugin.video.deadlight').getAddonInfo('version')
	except: return ''

def notification(title='DeadLight', message='', icon='', time=3000, sound=False):
	dialog.notification(title, message, icon or xbmcgui.NOTIFICATION_INFO, time, sound)

def yesnoDialog(line, heading='DeadLight', nolabel='', yeslabel=''):
	return dialog.yesno(heading, line, nolabel=nolabel, yeslabel=yeslabel)

def selectDialog(list, heading='DeadLight'):
	return dialog.select(heading, list)

def multiselectDialog(list, preselect=[], heading='DeadLight'):
	return dialog.multiselect(heading, list, preselect=preselect)
