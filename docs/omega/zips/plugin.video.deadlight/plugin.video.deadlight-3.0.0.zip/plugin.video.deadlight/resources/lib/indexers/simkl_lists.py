# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-29: SIMKL personal-list renderer.
#
# Feeds SIMKL /sync/all-items/{movies|shows|anime}/{status} responses through
# DeadLight's Movies/TVShows workers via the trakt_dict id_type pattern —
# same shape as indexers/mdblist_lists.py:_render_content.
#
# SIMKL response shape (for each list_type):
#   movies:  {'movies': [{'movie': {...}, 'ids': {'tmdb': ...}, ...}]}
#   shows:   {'shows':  [{'show':  {...}, 'ids': {'tmdb': ...}, ...}]}
#   anime:   {'anime':  [{'show':  {...}, 'ids': {'mal': ...}, ...}]}   ← shows-shape for anime too
#
# Each entry carries 'user_rating' + 'last_watched_at' + 'watched_episodes_count'
# / 'total_episodes_count' fields we could surface later — for now we just pass
# the TMDb ID (or MAL id resolved via Fribb anime-lists for anime) to the worker.

import sys
from threading import Thread

from apis.simkl_api import simkl_list
from indexers.movies import Movies
from indexers.tvshows import TVShows
from modules import kodi_utils
from modules.settings import widget_hide_next_page


SIMKL_ICON = 'lists'   # bundled generic icon; no SIMKL-specific asset in DeadLight


# Status-name pretty-print for the on-screen category header.
_STATUS_LABELS = {
	'watching': 'Watching',
	'plantowatch': 'Plan to Watch',
	'hold': 'On Hold',
	'completed': 'Completed',
	'dropped': 'Dropped',
}

_TYPE_LABELS = {
	'movies': 'Movies',
	'shows': 'TV Shows',
	'anime': 'Anime',
}


def _tmdb_from_ids(ids):
	"""Extract TMDb ID from SIMKL ids block. SIMKL always populates tmdb for
	movies + shows, and increasingly for anime (though not always)."""
	if not isinstance(ids, dict): return ''
	tmdb = ids.get('tmdb')
	if tmdb: return str(tmdb)
	return ''


def _mal_from_ids(ids):
	if not isinstance(ids, dict): return None
	return ids.get('mal') or None


def _resolve_anime_tmdb(mal_id):
	"""For anime items missing a TMDb ID in SIMKL's response, resolve via the
	Fribb anime-lists mapping (caches/fribb_mappings.py).

	LOCAL PATCH 2026-08-10: was anime_mappings.mal_to_tmdb — that DB's upstream
	froze 2026-05-31 and resolved only 7 of 75 current-season items in testing,
	vs Fribb's 43. Fribb returns the parent show's TMDb id, which is what the
	list renderer wants."""
	if not mal_id: return ''
	try:
		from caches import fribb_mappings
		tmdb = fribb_mappings.fribb_tmdb_for(mal_id=int(mal_id), media_type='tvshow')
		return str(tmdb) if tmdb else ''
	except Exception: return ''


def _split_items(rows, list_type):
	"""Return two lists of media-id dicts (movies, tvshows) suitable for
	trakt_dict id_type. list_type ∈ {'movies', 'shows', 'anime'}."""
	movies, tvshows = [], []
	if not rows: return movies, tvshows

	if list_type == 'movies':
		key_inner = 'movie'
		bucket = movies
	else:
		key_inner = 'show'
		bucket = tvshows

	for row in rows:
		try:
			inner = row.get(key_inner, {}) or {}
			ids = inner.get('ids') or {}
			tmdb = _tmdb_from_ids(ids)
			if not tmdb and list_type == 'anime':
				# Fall back to Fribb mapping resolution for anime that lack tmdb
				tmdb = _resolve_anime_tmdb(_mal_from_ids(ids))
			if not tmdb: continue
			imdb = ids.get('imdb', '') or ''
			tvdb = ids.get('tvdb', '') or ''
			bucket.append({'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb})
		except Exception: continue
	return movies, tvshows


def _render_content(handle, movies, shows, list_name, is_external=False):
	"""Same shape as indexers/mdblist_lists.py:_render_content — pack IDs into
	`{'list': [(order, media_ids), ...], 'id_type': 'trakt_dict'}` and hand
	off to Movies/TVShows workers in parallel."""
	threads, item_list = [], []
	item_list_extend = item_list.extend
	movie_list = {'list': [(idx, ids) for idx, ids in enumerate(movies)], 'id_type': 'trakt_dict', 'custom_order': 'true'}
	tvshow_list = {'list': [(idx, ids) for idx, ids in enumerate(shows)], 'id_type': 'trakt_dict', 'custom_order': 'true'}

	def _process(builder, _list):
		try:
			if _list['list']: item_list_extend(builder(_list).worker())
		except Exception: pass

	if movies:
		t = Thread(target=_process, args=(Movies, movie_list))
		t.start(); threads.append(t)
	if shows:
		t = Thread(target=_process, args=(TVShows, tvshow_list))
		t.start(); threads.append(t)
	[t.join() for t in threads]
	item_list.sort(key=lambda k: k[1])
	kodi_utils.add_items(handle, [i[0] for i in item_list])

	content = 'movies' if len(movies) >= len(shows) else 'tvshows'
	kodi_utils.set_content(handle, content)
	kodi_utils.set_category(handle, list_name)
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.main')


# ═══════════════════════════════════════════════════════════════════════════
#  Router entries — invoked via mode=simkl.list.build_simkl_list
# ═══════════════════════════════════════════════════════════════════════════

def build_simkl_list(params):
	"""Renders a single SIMKL list-status browse.
	params:
	  list_type ∈ {movies, shows, anime}
	  status    ∈ {watching, plantowatch, hold, completed, dropped}
	  category_name (optional): pretty label; falls back to derived label."""
	handle = int(sys.argv[1])
	is_external = kodi_utils.external()
	list_type = params.get('list_type', 'movies')
	status = params.get('status', 'watching')
	category_name = params.get('category_name') or '%s — %s' % (_TYPE_LABELS.get(list_type, list_type), _STATUS_LABELS.get(status, status))

	# Fetch — simkl_list returns the raw response dict or None on error.
	response = simkl_list(list_type, status) or {}
	# Response key matches list_type ('movies' | 'shows' | 'anime')
	rows = response.get(list_type) or []
	movies, tvshows = _split_items(rows, list_type)
	_render_content(handle, movies, tvshows, category_name, is_external=is_external)
