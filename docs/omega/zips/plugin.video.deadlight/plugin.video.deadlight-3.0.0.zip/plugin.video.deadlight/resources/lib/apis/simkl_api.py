# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-29: SIMKL integration (ported from Otaku's WatchlistFlavor/Simkl.py).
#
# SIMKL (simkl.com) is a movie / TV / anime tracking service. Unlike MAL, SIMKL
# uses a simple PIN device-flow auth (no OAuth PKCE, no client_secret, no
# redirect_uri) — user copies a short code, enters it at simkl.com/pin,
# DeadLight polls for the access token, done. Tokens don't expire per SIMKL FAQ
# so no refresh flow either.
#
# Endpoints hit (all under https://api.simkl.com):
#   /oauth/pin                                (PIN request — public, no auth)
#   /oauth/pin/{code}                         (PIN poll — public, no auth)
#   /users/settings                           (get username after auth)
#   /sync/all-items/{type}/{status}           (user's lists — watching/completed/hold/dropped/plantowatch)
#   /sync/add-to-list                         (add movie/show to list w/ status)
#   /sync/history                             (mark watched — supports episode granularity)
#   /sync/history/remove                      (mark unwatched)
#   /sync/ratings + /sync/ratings/remove      (star rating 1-10)
#   /sync/activities                          (last-change timestamps — monitor uses this)
#
# SIMKL supports id_type in {'imdb', 'tmdb', 'tvdb', 'mal', 'anidb', 'simkl'}.
# DeadLight passes TMDb IDs (movies + shows) + MAL IDs (anime via Fribb anime-lists).

import base64
import json as _json
import time
from urllib.parse import urlencode

from caches.settings_cache import get_setting, set_setting
from modules import kodi_utils
from modules.kodi_utils import logger, notification, kodi_dialog, ok_dialog, make_session
# from modules.kodi_utils import logger


_API_BASE = 'https://api.simkl.com'
_PIN_VERIFICATION_URL = 'https://simkl.com/pin'
_APP_REGISTER_URL = 'https://simkl.com/settings/developer'


_session = make_session(_API_BASE)


# ═══════════════════════════════════════════════════════════════════════════
#  Settings accessors — strip whitespace to survive copy-paste artifacts
# ═══════════════════════════════════════════════════════════════════════════

def _client_id():
	val = (get_setting('deadlight.simkl.client_id', '') or '').strip()
	return val if val and val != 'empty_setting' else ''


def _access_token():
	val = (get_setting('deadlight.simkl.token', '') or '').strip()
	return val if val and val != 'empty_setting' else ''


def _headers(with_auth=True):
	h = {'Content-Type': 'application/json'}
	client_id = _client_id()
	if client_id: h['simkl-api-key'] = client_id
	if with_auth:
		token = _access_token()
		if token: h['Authorization'] = 'Bearer %s' % token
	return h


def simkl_user_active():
	return bool(_access_token() and get_setting('deadlight.simkl.user', 'empty_setting') not in ('empty_setting', ''))


# ═══════════════════════════════════════════════════════════════════════════
#  Core HTTP helper — GET/POST with automatic auth headers
# ═══════════════════════════════════════════════════════════════════════════

def call_simkl(path, method='get', params=None, json=None, timeout=15, with_auth=True):
	"""Wrapper around _session.get/post. Returns parsed JSON or None on error."""
	url = '%s%s' % (_API_BASE, path if path.startswith('/') else '/' + path)
	try:
		r = _session.request(method.upper(), url, params=params, json=json,
							 headers=_headers(with_auth=with_auth), timeout=timeout)
		if r.status_code >= 400:
			logger('SIMKL', 'HTTP %d %s %s | body=%r' % (r.status_code, method.upper(), path, (r.text or '')[:300]))
			return None
		if not r.text: return {}
		try: return r.json()
		except Exception: return None
	except Exception as e:
		logger('SIMKL', 'request failed: %s %s %s' % (method, path, e))
		return None


# ═══════════════════════════════════════════════════════════════════════════
#  PIN device flow — user copies a short code, enters it at simkl.com/pin
# ═══════════════════════════════════════════════════════════════════════════

def simkl_authenticate(dummy=''):
	"""Start SIMKL PIN device flow. Called from settings XML Authorize row."""
	# LOCAL PATCH 2026-07-29: credentials.py bundling means simkl.client_id
	# is usually pre-populated on boot. If it's not, prompt inline (first-run).
	client_id = _client_id()
	if not client_id:
		client_id = kodi_dialog().input('Enter your SIMKL Client ID (register at %s)' % _APP_REGISTER_URL)
		if not client_id: return notification('SIMKL Authorize Cancelled — no Client ID', 4000)
		client_id = client_id.strip()
		set_setting('simkl.client_id', client_id)

	# 1. Request PIN
	pin_data = call_simkl('/oauth/pin', params={'client_id': client_id}, with_auth=False)
	if not pin_data or not pin_data.get('user_code'):
		return notification('SIMKL Authorize Failed — could not obtain PIN. Check Client ID + Network.', 6000)

	user_code = pin_data['user_code']
	expires_in = int(pin_data.get('expires_in', 900))
	interval = int(pin_data.get('interval', 5))

	# 2. Copy PIN to clipboard + show user instructions
	try:
		from modules.utils import copy2clip
		copy2clip(user_code)
	except Exception: pass

	ok_dialog('SIMKL Authorize',
		'[B]Step 1:[/B] Open [B]%s[/B]\n'
		'[B]Step 2:[/B] Sign in and enter this code: [COLOR gold][B]%s[/B][/COLOR]\n'
		'   (already copied to your clipboard)\n'
		'[B]Step 3:[/B] Press OK below — DeadLight will wait for confirmation.'
		% (_PIN_VERIFICATION_URL, user_code))

	# 3. Poll for authorization. SIMKL returns {result: 'KO'} while waiting, {result: 'OK', access_token: X} when done.
	max_polls = max(1, expires_in // interval)
	access_token = None
	for _ in range(max_polls):
		poll = call_simkl('/oauth/pin/%s' % user_code, params={'client_id': client_id}, with_auth=False, timeout=10)
		if poll and poll.get('result') == 'OK' and poll.get('access_token'):
			access_token = poll['access_token']
			break
		time.sleep(interval)
	if not access_token:
		return notification('SIMKL Authorize Failed — timed out waiting for PIN entry.', 6000)

	# 4. Fetch username for display in settings
	set_setting('simkl.token', access_token)
	settings = call_simkl('/users/settings', method='post', json={})
	username = ''
	try: username = ((settings or {}).get('user') or {}).get('name', '') or ''
	except Exception: pass
	set_setting('simkl.user', username or 'Authorized')
	notification('SIMKL Authorized as %s' % (username or 'user'), 5000)
	return True


def simkl_revoke_authentication(dummy=''):
	"""Clear SIMKL auth state. Called from settings XML Revoke row.
	SIMKL doesn't provide a token-revocation endpoint — we just wipe local state.
	Also clears client_id so next Authorize re-prompts for it (in case user needs
	to switch to a different SIMKL app)."""
	set_setting('simkl.token', '')
	set_setting('simkl.user', 'empty_setting')
	set_setting('simkl.last_activity', 'empty_setting')
	set_setting('simkl.client_id', 'empty_setting')
	notification('SIMKL Deauthorized', 3500)


# ═══════════════════════════════════════════════════════════════════════════
#  List reads — /sync/all-items/{type}/{status}
#  type ∈ {movies, shows, anime}   status ∈ {watching, completed, hold, dropped, plantowatch}
# ═══════════════════════════════════════════════════════════════════════════

_STATUSES = ('watching', 'completed', 'hold', 'dropped', 'plantowatch')
_TYPES = ('movies', 'shows', 'anime')


# LOCAL PATCH 2026-08-26: Simkl as an ID-resolution source for the anime catalogs.
#
# Measured on a 50-item current-season AniList page: Fribb resolved 38, and of the
# 12 it missed the TMDb title-search fallback resolved ZERO while Simkl resolved 10
# (4 via a simkl_id Fribb already had, 6 via Simkl's own AniList lookup). Fuzzy title
# search is close to useless for brand-new anime -- romaji/localised titles do not
# match TMDb naming -- whereas Simkl carries real curated TMDb mappings. Coverage
# goes from ~76% to ~96%, and the lookups are exact rather than a guess.
#
# Needs only the api-key header (with_auth=False), so this works regardless of
# whether a Simkl ACCOUNT is authorised -- it is a public metadata read.

def simkl_tmdb_for(simkl_id=None, anilist_id=None, mal_id=None):
	"""Resolve an anime to a TMDb id via Simkl. Returns str id or None.

	Path A (1 request):  a known simkl_id -> /anime/{id}?extended=full
	Path B (2 requests): /search/id?anilist=|mal= to find the simkl id, then A.
	Silent on every failure -- callers fall through to their next resolver."""
	if not _client_id(): return None
	def _tmdb_from_anime(sid):
		try:
			data = call_simkl('/anime/%s' % sid, params={'extended': 'full'}, with_auth=False)
			tmdb = ((data or {}).get('ids') or {}).get('tmdb')
			return str(tmdb) if tmdb else None
		except Exception: return None
	try:
		if simkl_id:
			tmdb = _tmdb_from_anime(simkl_id)
			if tmdb: return tmdb
		for key, val in (('anilist', anilist_id), ('mal', mal_id)):
			if not val: continue
			try:
				res = call_simkl('/search/id', params={key: val}, with_auth=False)
			except Exception: continue
			if not isinstance(res, list) or not res: continue
			sid = ((res[0] or {}).get('ids') or {}).get('simkl')
			if not sid: continue
			tmdb = _tmdb_from_anime(sid)
			if tmdb: return tmdb
	except Exception as e:
		logger('SIMKL', 'simkl_tmdb_for failed: %s' % e)
	return None


def simkl_list(list_type, status, extended='full'):
	"""Return raw SIMKL response for user's list. list_type in _TYPES, status in _STATUSES.

	LOCAL PATCH 2026-08-26 (perf): read-through cached. This was hitting the network on
	EVERY call, and indexers/tvshows.py:_load_dropped_set calls it 4 times per list build
	(shows+anime x dropped+hold) whenever watched_indicators == 3 -- so four uncached HTTP
	round trips per widget/list render. modules/watched_status.py:get_hidden_progress_items
	loops it the same way. Caching here fixes every caller at once.

	No TTL by design, matching mdblist_cache.cache_mdbl_object: the entry is invalidated
	by events, not by time. clear_simkl_lists_cache() fires from simkl_sync_activities when
	/sync/activities timestamps advance, and from the write paths (dialogs.py SIMKL manager,
	trakt_drop.py), so dropping a show reflects immediately rather than after a TTL.

	Key format matches caches/simkl_cache.clear_simkl_list ('simkl_{type}_{status}') so its
	targeted clear keeps working. A non-default `extended` gets its own key -- no caller
	passes one today, but a shared key would silently serve the wrong shape if one did."""
	if not simkl_user_active(): return None
	if list_type not in _TYPES: return None
	if status not in _STATUSES: return None
	from caches.simkl_cache import simkl_cache_object
	cache_key = 'simkl_%s_%s' % (list_type, status)
	if extended != 'full': cache_key = '%s_%s' % (cache_key, extended)
	def _fetch():
		# call_simkl returns None on failure, and simkl_cache_object does not cache None,
		# so a transient error is retried rather than pinned.
		return call_simkl('/sync/all-items/%s/%s' % (list_type, status),
						  params={'extended': extended})
	return simkl_cache_object(_fetch, cache_key)


# ═══════════════════════════════════════════════════════════════════════════
#  Sync activities — monitor uses these timestamps to detect remote changes
# ═══════════════════════════════════════════════════════════════════════════

# LOCAL PATCH 2026-09-22 (Red Light 2.6.6 'Phase 2' port, adapted to this cache model).
#
# Red Light keeps local shelves and applies a /sync/all-items?date_from= delta into them.
# That does not fit here: simkl_list is already read-through cached with no TTL and is
# invalidated by events, so nothing is re-fetched until SIMKL says something changed.
# What was wasteful is the BLAST RADIUS of that invalidation -- clear_simkl_lists_cache
# does DELETE FROM simkl_data, so one watched episode discarded every cached list, and
# all four indicator/progress rebuilds ran regardless of what moved.
#
# /sync/activities already carries per-type, per-status timestamps whose names match
# _STATUSES exactly, so the answer is in the response we were already fetching and then
# collapsing to a single max. Measured on this account 2026-09-22: tv_shows.watching was
# 2026-09-21T15:48:19Z while movies.all was 5 days older and anime.dropped nearly two
# months old -- yet watching one episode threw all of them away, including the four that
# indexers/tvshows.py:_load_dropped_set re-fetches on every list build.
_SIMKL_ACTIVITY_TYPE = {'movies': 'movies', 'shows': 'tv_shows', 'anime': 'anime'}


def _simkl_advanced(current, previous):
	"""True when SIMKL's timestamp for one list moved. Absent/blank is never a change,
	so a key SIMKL stops sending cannot force a permanent rebuild."""
	cur = str(current or '').strip()
	if not cur: return False
	return cur != str(previous or '').strip()


def _simkl_stale_lists(acts, prior):
	"""(list_type, status) pairs whose own timestamp advanced."""
	stale = set()
	for list_type, act_key in _SIMKL_ACTIVITY_TYPE.items():
		current = (acts or {}).get(act_key)
		if not isinstance(current, dict): continue
		previous = (prior or {}).get(act_key)
		if not isinstance(previous, dict): previous = {}
		# A removal does not say WHICH status lost the item, so refresh them all.
		if _simkl_advanced(current.get('removed_from_list'), previous.get('removed_from_list')):
			stale.update((list_type, status) for status in _STATUSES)
			continue
		for status in _STATUSES:
			if _simkl_advanced(current.get(status), previous.get(status)):
				stale.add((list_type, status))
	return stale


def _simkl_changed_kinds(acts, prior):
	"""Which rebuilds are actually needed: 'movies', 'tv' and/or 'playback'.

	simkl_progress_movies and simkl_progress_tv both read /sync/playback, so 'playback'
	is one flag covering both rather than one per media kind."""
	kinds = set()
	for list_type, act_key in _SIMKL_ACTIVITY_TYPE.items():
		current = (acts or {}).get(act_key)
		if not isinstance(current, dict): continue
		previous = (prior or {}).get(act_key)
		if not isinstance(previous, dict): previous = {}
		if _simkl_advanced(current.get('playback'), previous.get('playback')):
			kinds.add('playback')
		for status in _STATUSES + ('removed_from_list',):
			if _simkl_advanced(current.get(status), previous.get(status)):
				kinds.add('movies' if list_type == 'movies' else 'tv')
	return kinds


def simkl_sync_activities():
	"""Called by SIMKLMonitor in service.py. Returns one of:
	  'no_auth'      — user not signed in
	  'no changes'   — remote state matches local
	  'success'      — remote changes detected + local mirror rebuilt
	  'failed'       — API error
	Compares SIMKL's /sync/activities response timestamps against a local cached
	snapshot; on any advance, rebuilds simkl_db.watched + simkl_db.progress and
	invalidates list cache. Populating watched/progress is what makes the
	In-Progress + Next-Episodes widgets work under watched_indicators==3."""
	if not simkl_user_active(): return 'no_auth'
	try:
		acts = call_simkl('/sync/activities')
		if acts is None: return 'failed'
		def _latest(d):
			if not isinstance(d, dict): return ''
			vals = [_latest(v) if isinstance(v, dict) else (v or '') for v in d.values()]
			vals = [v for v in vals if v]
			return max(vals) if vals else ''
		latest = _latest(acts)
		prior = get_setting('deadlight.simkl.last_activity', '') or ''
		# LOCAL PATCH 2026-07-29: also rebuild when local simkl_db.watched is empty
		# (fresh install, cache wipe, or previous rebuild failed). Prevents the
		# case where remote timestamps haven't advanced but local mirror is stale.
		try:
			from caches.base_cache import connect_database
			dbcon = connect_database('simkl_db')
			local_watched_count = dbcon.execute('SELECT COUNT(*) FROM watched').fetchone()[0]
		except Exception: local_watched_count = 0
		if latest and latest == prior and local_watched_count > 0: return 'no changes'
		# LOCAL PATCH 2026-09-22: rebuild only what moved. See _simkl_stale_lists above.
		#
		# The full rebuild is kept for the two cases where a delta cannot be trusted: no
		# stored snapshot (fresh install, cache wipe, or the first run after this patch
		# ships) and an empty local mirror. Both mean we do not know what we already have.
		prior_acts = None
		_raw = get_setting('deadlight.simkl.last_activities', '') or ''
		if _raw and _raw != 'empty_setting':
			try: prior_acts = _json.loads(_raw)
			except Exception: prior_acts = None
		if not isinstance(prior_acts, dict): prior_acts = None
		full_rebuild = prior_acts is None or local_watched_count == 0
		from caches.simkl_cache import clear_simkl_list, clear_simkl_lists_cache
		if full_rebuild:
			simkl_indicators_movies()
			simkl_indicators_tv()
			simkl_progress_movies()
			simkl_progress_tv()
			try: clear_simkl_lists_cache()
			except Exception: pass
			logger('###SIMKL sync###', 'full rebuild (no snapshot)' if prior_acts is None
				else 'full rebuild (local mirror empty)')
		else:
			kinds = _simkl_changed_kinds(acts, prior_acts)
			stale = _simkl_stale_lists(acts, prior_acts)
			if 'movies' in kinds: simkl_indicators_movies()
			if 'tv' in kinds: simkl_indicators_tv()
			if 'playback' in kinds:
				simkl_progress_movies()
				simkl_progress_tv()
			for list_type, status in stale:
				try: clear_simkl_list(list_type, status)
				except Exception: pass
			logger('###SIMKL sync###', 'scoped: rebuilt=%s lists_cleared=%d/%d %s'
				% (','.join(sorted(kinds)) or 'none', len(stale), len(_TYPES) * len(_STATUSES),
				','.join('%s/%s' % pair for pair in sorted(stale)) or '-'))
		try: set_setting('simkl.last_activities', _json.dumps(acts))
		except Exception: pass
		if latest:
			set_setting('simkl.last_activity', latest)
		return 'success'
	except Exception as e:
		logger('SIMKL', 'sync_activities failed: %s' % e)
		return 'failed'


# ═══════════════════════════════════════════════════════════════════════════
#  Indicator + progress builders — populate simkl_db.watched + simkl_db.progress
#  from SIMKL sync endpoints. Called from simkl_sync_activities. Match the
#  trakt_indicators_* / mdbl_indicators_* signatures + bulk-insert pattern so
#  DeadLight's In-Progress + Next-Episodes queries work drop-in when
#  watched_indicators == 3.
# ═══════════════════════════════════════════════════════════════════════════

def _js_utc_now():
	"""ISO timestamp SIMKL uses (YYYY-MM-DDTHH:MM:SS.000Z)."""
	from datetime import datetime as _dt
	return _dt.utcnow().strftime('%Y-%m-%dT%H:%M:%S.000Z')


def _normalize_ts(ts):
	"""SIMKL returns two ISO shapes: '2026-07-30T19:15:37Z' (endpoints)
	OR '2026-07-30T19:15:37.000Z' (others). DeadLight's episodes.py sorter
	parses last_played with format '%Y-%m-%dT%H:%M:%S.%fZ' which REQUIRES
	the microsecond section — the Z-only shape crashes it.
	Insert '.000' before 'Z' if missing."""
	if not ts: return _js_utc_now()
	if 'T' not in ts: return ts   # not our format, leave alone
	if ts.endswith('Z') and '.' not in ts[-8:]:
		return ts[:-1] + '.000Z'
	return ts


def _extract_tmdb(ids):
	if not isinstance(ids, dict): return None
	try: return int(ids.get('tmdb') or 0) or None
	except (TypeError, ValueError): return None


def simkl_indicators_movies():
	"""Populate simkl_db.watched with all movies the user has actually watched —
	across completed / dropped / hold statuses (any movie the user started).
	Plan-to-watch is excluded (never watched)."""
	from caches.simkl_cache import simkl_cache
	try:
		insert_list = []
		seen_tmdb = set()
		for status in ('completed', 'dropped', 'hold', 'watching'):
			data = call_simkl('/sync/all-items/movies/%s' % status, params={'extended': 'full'})
			if not data: continue
			for it in (data.get('movies') or []):
				try:
					movie = it.get('movie') or {}
					tmdb = _extract_tmdb(movie.get('ids'))
					if not tmdb or tmdb in seen_tmdb: continue
					seen_tmdb.add(tmdb)
					last = _normalize_ts(it.get('last_watched_at') or _js_utc_now())
					title = movie.get('title', '')
					insert_list.append(('movie', str(tmdb), '', '', last, title))
				except Exception: continue
		simkl_cache.set_bulk_movie_watched(insert_list)
	except Exception as e:
		logger('SIMKL', 'indicators_movies failed: %s' % e)


def simkl_indicators_tv():
	"""Fetch all watched TV episodes + populate simkl_db.watched.
	Uses /sync/all-items/shows?extended=full which returns per-show seasons/episodes
	with last_watched_at at episode granularity. Anime is folded into shows here —
	SIMKL treats anime as an episode-based media type too."""
	from caches.simkl_cache import simkl_cache
	try:
		insert_list = []
		for list_type in ('shows', 'anime'):
			data = call_simkl('/sync/all-items/%s' % list_type, params={'extended': 'full', 'episode_watched_at': 'yes'})
			if not data: continue
			for it in (data.get(list_type) or []):
				try:
					show = it.get('show') or {}
					tmdb = _extract_tmdb(show.get('ids'))
					if not tmdb: continue
					title = show.get('title', '')
					# `seasons` key contains only when extended=full is honored + user has watched episodes
					for season in (it.get('seasons') or []):
						try: s_n = int(season.get('number') or 0)
						except: continue
						if s_n == 0: continue
						for ep in (season.get('episodes') or []):
							try: e_n = int(ep.get('number') or 0)
							except: continue
							if e_n == 0: continue
							last = _normalize_ts(ep.get('watched_at') or it.get('last_watched_at') or _js_utc_now())
							insert_list.append(('episode', str(tmdb), s_n, e_n, last, title))
				except Exception: continue
		simkl_cache.set_bulk_tvshow_watched(insert_list)
	except Exception as e:
		logger('SIMKL', 'indicators_tv failed: %s' % e)


def simkl_progress_movies():
	"""Populate simkl_db.progress with paused movies (In Progress widget source).
	SIMKL /sync/playback returns items with `progress` (0-100 float) + timestamps."""
	from caches.simkl_cache import simkl_cache
	try:
		data = call_simkl('/sync/playback')
		if not data: return
		insert_list = []
		# Playback response shape can be a list of items or grouped movies/shows —
		# handle both defensively.
		items = data if isinstance(data, list) else (data.get('movies') or [])
		for it in items:
			try:
				movie = it.get('movie') or {}
				tmdb = _extract_tmdb(movie.get('ids'))
				if not tmdb: continue
				title = movie.get('title', '')
				progress = float(it.get('progress') or 0)
				if progress <= 0 or progress >= 90: continue
				paused_at = _normalize_ts(it.get('paused_at') or it.get('last_watched_at') or _js_utc_now())
				# DeadLight progress schema: (db_type, media_id, season, episode, resume_point, curr_time, last_played, resume_id, title)
				insert_list.append(('movie', str(tmdb), '', '', str(progress), '0', paused_at, 0, title))
			except Exception: continue
		simkl_cache.set_bulk_movie_progress(insert_list)
	except Exception as e:
		logger('SIMKL', 'progress_movies failed: %s' % e)


def simkl_progress_tv():
	"""Populate simkl_db.progress with paused TV episodes.
	SIMKL /sync/playback for shows: items include season+episode + progress."""
	from caches.simkl_cache import simkl_cache
	try:
		data = call_simkl('/sync/playback')
		if not data: return
		insert_list = []
		items = data if isinstance(data, list) else (data.get('shows') or [])
		for it in items:
			try:
				show = it.get('show') or {}
				tmdb = _extract_tmdb(show.get('ids'))
				if not tmdb: continue
				title = show.get('title', '')
				progress = float(it.get('progress') or 0)
				if progress <= 0 or progress >= 90: continue
				ep = it.get('episode') or {}
				s_n = int((it.get('season') or {}).get('number') or ep.get('season') or 0)
				e_n = int(ep.get('number') or 0)
				if not (s_n and e_n): continue
				paused_at = _normalize_ts(it.get('paused_at') or it.get('last_watched_at') or _js_utc_now())
				insert_list.append(('episode', str(tmdb), s_n, e_n, str(progress), '0', paused_at, 0, title))
			except Exception: continue
		simkl_cache.set_bulk_tvshow_progress(insert_list)
	except Exception as e:
		logger('SIMKL', 'progress_tv failed: %s' % e)


# ═══════════════════════════════════════════════════════════════════════════
#  Writes — add/remove from list, mark watched, rate
# ═══════════════════════════════════════════════════════════════════════════

def _id_dict(id_type, id_val):
	"""SIMKL accepts {tmdb, imdb, tvdb, mal, anidb, simkl} keys in the ids object."""
	if not id_val: return {}
	return {id_type: id_val}


def simkl_add_to_list(list_type, id_type, id_val, status):
	"""list_type in _TYPES, status in _STATUSES + 'notinteresting' (legacy).
	Returns True on success."""
	if list_type not in _TYPES: return False
	if not simkl_user_active(): return False
	key = 'shows' if list_type in ('shows', 'anime') else 'movies'
	data = {key: [{'to': status, 'ids': _id_dict(id_type, id_val)}]}
	res = call_simkl('/sync/add-to-list', method='post', json=data)
	return bool(res)


# LOCAL PATCH 2026-09-19: put the NEXT cour on Watching when this one finishes.
#
# SIMKL follows AniDB/MAL, where every cour is its own entry, while TMDb folds them into one
# season. So finishing cour 1 of a show leaves cour 2 absent from Watching entirely and it has
# to be added by hand -- the same TMDb-vs-anime-DB split the cour rows and the pack gate exist
# for.
#
# Fribb already maps TMDb coords to the cour that owns them, so "did this episode end a cour"
# is answerable without an episode count: ask which cour owns `episode` and which owns
# `episode + 1`. Different answers mean the boundary sits between them. A missing answer for
# episode + 1 means the season has no next episode, so there is nothing to advance to.
#
# Anime-gated by that lookup itself -- the Fribb index holds nothing else, so a miss means "not
# anime, do nothing" at the cost of one offline dict lookup. Same self-gating the AniList
# scrobble in player.py uses.
#
# Deliberately does NOT touch the finished cour. SIMKL marks an entry completed itself once all
# its episodes are watched, so writing that too would be a second request to say what SIMKL
# already knows.
def simkl_advance_cour(tmdb_id, season, episode):
	"""Add the next cour to SIMKL's Watching list when `episode` was the last of its cour.

	Returns True only when a next cour was actually added."""
	try:
		if not simkl_user_active(): return False
		try: tmdb_id, season, episode = int(tmdb_id), int(season), int(episode)
		except (TypeError, ValueError): return False
		from caches.fribb_mappings import find_cour_by_tmdb_coords
		current = find_cour_by_tmdb_coords(tmdb_id, season, episode)
		if not current: return False                      # not anime, or unmapped
		nxt = find_cour_by_tmdb_coords(tmdb_id, season, episode + 1)
		if not nxt: return False                          # no episode after this one
		cur_mal, nxt_mal = current.get('mal'), nxt.get('mal')
		if not nxt_mal or nxt_mal == cur_mal: return False  # still inside the same cour
		added = simkl_add_to_list('anime', 'mal', int(nxt_mal), 'watching')
		if added:
			logger('SIMKL cour', 'tmdb %s S%s E%s ended a cour; added mal %s to watching'
					% (tmdb_id, season, episode, nxt_mal))
		return bool(added)
	except Exception as e:
		try: logger('SIMKL cour error', str(e)[:160])
		except Exception: pass
		return False


def simkl_mark_watched(list_type, id_type, id_val, seasons=None):
	"""Mark a movie or show/anime as watched. For shows/anime, pass
	seasons=[{'number': N, 'episodes': [{'number': X}, ...]}] for per-episode
	granularity; omit seasons to mark the whole show."""
	if not simkl_user_active(): return False
	key = 'shows' if list_type in ('shows', 'anime') else 'movies'
	item = {'ids': _id_dict(id_type, id_val)}
	if seasons: item['seasons'] = seasons
	res = call_simkl('/sync/history', method='post', json={key: [item]})
	return bool(res)


def simkl_mark_unwatched(list_type, id_type, id_val, seasons=None):
	if not simkl_user_active(): return False
	key = 'shows' if list_type in ('shows', 'anime') else 'movies'
	item = {'ids': _id_dict(id_type, id_val)}
	if seasons: item['seasons'] = seasons
	res = call_simkl('/sync/history/remove', method='post', json={key: [item]})
	return bool(res)


def simkl_rate(list_type, id_type, id_val, score):
	"""Set / remove star rating (1-10). Passing score=0 removes the rating."""
	if not simkl_user_active(): return False
	key = 'shows' if list_type in ('shows', 'anime') else 'movies'
	item = {'rating': int(score), 'ids': _id_dict(id_type, id_val)}
	path = '/sync/ratings/remove' if int(score) == 0 else '/sync/ratings'
	res = call_simkl(path, method='post', json={key: [item]})
	return bool(res)


# ═══════════════════════════════════════════════════════════════════════════
#  Rating UI — router entry: mode=simkl.simkl_rate_dialog
#  Skin/context menu invokes this with params {list_type, tmdb_id[, imdb_id]}.
#  Shows a 0-10 picker; 0 removes the rating.
# ═══════════════════════════════════════════════════════════════════════════

def simkl_rate_dialog(params):
	"""Context-menu invocation. Opens a rating picker and pushes to SIMKL.
	params:
	  tmdb_id (required)
	  list_type ∈ {movies, shows, anime}  (defaults to media_type param mapping)
	  media_type ∈ {movie, tvshow, episode, anime}  (alt to list_type — auto-mapped)"""
	if not simkl_user_active():
		return notification('SIMKL not authorized — open Settings > Accounts > SIMKL first', 5000)
	tmdb_id = params.get('tmdb_id') or params.get('media_id')
	if not tmdb_id:
		return notification('SIMKL Rate: no TMDb ID', 3500)

	list_type = params.get('list_type')
	if not list_type:
		mt = params.get('media_type', 'movie')
		list_type = {'movie': 'movies', 'tvshow': 'shows', 'episode': 'shows', 'anime': 'anime'}.get(mt, 'movies')

	# Rating picker — 0 (remove) through 10.
	from modules.kodi_utils import select_dialog
	import json as _sel_json
	options = [('Remove Rating', 0)] + [('%s / 10' % s, s) for s in range(10, 0, -1)]
	kwargs = {'items': _sel_json.dumps([{'line1': opt[0]} for opt in options]), 'narrow_window': 'true', 'heading': 'SIMKL Rating'}
	choice = select_dialog(options, **kwargs)
	if choice is None: return
	score = int(choice[1])
	success = simkl_rate(list_type, 'tmdb', int(tmdb_id), score)
	if success:
		# Invalidate list caches so the new rating shows up on next browse.
		try:
			from caches.simkl_cache import clear_simkl_lists_cache
			clear_simkl_lists_cache()
		except Exception: pass
		notification('SIMKL: %s' % ('Rating Removed' if score == 0 else 'Rated %d/10' % score), 3500)
	else:
		notification('SIMKL Rate Failed', 4000)
