# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-07: Trakt per-episode UTC airtimes.
#
# TMDb exposes only date-precision `air_date` for TV episodes, so DeadLight's
# aired-check falls back to a hardcoded "20:00 local" assumption + a user
# `datetime.offset` shift. That approximation breaks for:
#   - Netflix/Amazon Prime (drop midnight PT — shown as unaired ~13h too long)
#   - HBO Sunday 21:00 ET (aired-check ~1h too early)
#   - Apple TV+ Thursday 21:00 EDT (occasionally 5-7h off depending on episode)
#   - Anime aired late-night JST
#
# Trakt/TVDB has UTC-precision `first_aired` for ~90% of mainstream shows. Use
# it when Trakt is authorized; fall back to TMDb + 20:00 assumption otherwise.
#
# API: get_season_air_times(imdb_id, tmdb_id, season) -> {ep_number: iso_utc_str}
#      parse_utc(iso_str) -> naive local datetime (matches DeadLight convention)
#
# Cache: slug lookups cached forever (never change); season-level airtimes
# cached 24h so upcoming reschedules pick up within a day.
#
# All failures are silent — caller falls back to TMDb behavior.

import time
from datetime import datetime, timedelta, timezone

from apis.trakt_api import call_trakt
from caches.trakt_cache import trakt_cache
from caches.settings_cache import get_setting
from modules import settings
from modules.kodi_utils import logger


_TTL_SECONDS = 24 * 3600
# LOCAL PATCH 2026-09-26: a season that has finished airing keeps its airtimes 30 days. They
# cannot change any more, but every season was refetched daily: of 220 cached seasons, 155 (70%)
# had their last episode more than 14 days back. 'Finished' means EVERY episode carries a date and
# the newest is over 14 days old, so a season with an unannounced (null) or future episode stays
# on the 24h refresh the reschedule handling above relies on.
_FINISHED_TTL_SECONDS = 30 * 24 * 3600
_FINISHED_AFTER_SECONDS = 14 * 24 * 3600


def _ttl_for(cached):
	"""TTL for a cached season row. `_n` is the season's episode count INCLUDING episodes with no
	first_aired, which the stored map leaves out -- without it an unannounced episode is invisible.
	Rows written before `_n` existed get the short TTL and gain it on their next refresh."""
	data, total = cached.get('data') or {}, cached.get('_n')
	if not data or total != len(data): return _TTL_SECONDS
	try:
		newest = max(datetime.strptime(str(v)[:19], '%Y-%m-%dT%H:%M:%S').replace(tzinfo=timezone.utc).timestamp()
				for v in data.values())
	except (TypeError, ValueError): return _TTL_SECONDS
	return _FINISHED_TTL_SECONDS if time.time() - newest > _FINISHED_AFTER_SECONDS else _TTL_SECONDS


def _slug_key(tmdb_id):
	return 'trakt_slug_tmdb_%s' % tmdb_id


def _season_air_key(show_id, season):
	return 'trakt_air_%s_S%s' % (show_id or 'x', season)


def _resolve_slug(imdb_id, tmdb_id):
	"""Cached slug lookup. Prefers tmdb-search (works ~100% for shows on Trakt);
	falls back to imdb-search when tmdb_id is missing."""
	if not tmdb_id and not imdb_id: return None
	cache_id = tmdb_id or imdb_id
	cached = trakt_cache.get(_slug_key(cache_id))
	if cached: return cached
	slug = None
	if tmdb_id:
		try:
			res = call_trakt('search/tmdb/%s' % tmdb_id, params={'type': 'show'}, with_auth=False, pagination=False)
			if res and isinstance(res, list) and res:
				slug = res[0].get('show', {}).get('ids', {}).get('slug')
		except Exception: pass
	if not slug and imdb_id:
		try:
			res = call_trakt('search/imdb/%s' % imdb_id, params={}, with_auth=False, pagination=False)
			if res and isinstance(res, list):
				for it in res:
					if it.get('type') == 'show':
						slug = it.get('show', {}).get('ids', {}).get('slug')
						if slug: break
		except Exception: pass
	if slug: trakt_cache.set(_slug_key(cache_id), slug)
	return slug


# LOCAL PATCH 2026-09-04: normalise the season map's keys to int on the way out of the cache.
#
# The map is {episode_number: iso_utc} with INT keys when freshly fetched, and
# metadata.episodes_meta looks it up with the int episode number from TMDb. JSON stringifies
# int dict keys, so once trakt_cache serialises as JSON a cached row comes back keyed '1'
# instead of 1 and every .get(int) misses -- silently, losing first_aired_utc for the whole
# season and falling back to the old "TMDb date + 20:00 local" approximation. Nothing would
# raise; the aired-check would just quietly get worse.
#
# Fixing it HERE rather than coercing in the cache layer follows the 2026-08-26 rule: make
# the consumer format-agnostic, so this works whichever serialisation the row was written
# with (and keeps working for legacy repr rows that still have real int keys).
def _int_keyed(mapping):
	if not isinstance(mapping, dict): return {}
	out = {}
	for k, v in mapping.items():
		try: out[int(k)] = v
		except (TypeError, ValueError): continue
	return out


def get_season_air_times(imdb_id, tmdb_id, season):
	"""Return {episode_number: '2026-08-07T01:00:00.000Z' (UTC)} for the season.
	Empty dict when Trakt unavailable / show not on Trakt / season not on Trakt.
	Silent — never raises."""
	try:
		if not settings.trakt_user_active(): return {}
	except Exception: return {}
	if season is None: return {}
	try: season_int = int(season)
	except (TypeError, ValueError): return {}
	if season_int <= 0: return {}
	key = _season_air_key(imdb_id or tmdb_id, season_int)
	cached = trakt_cache.get(key)
	if cached and isinstance(cached, dict):
		try:
			if time.time() - cached.get('_ts', 0) < _ttl_for(cached):
				return _int_keyed(cached.get('data'))
		except Exception: pass
	slug = _resolve_slug(imdb_id, tmdb_id)
	if not slug: return {}
	try:
		# /shows/{slug}/seasons/{n}?extended=full,episodes returns array of episode objects,
		# each with first_aired UTC. One call = whole season enriched.
		eps = call_trakt('shows/%s/seasons/%s' % (slug, season_int),
						 params={'extended': 'full,episodes'}, with_auth=False, pagination=False)
		if not isinstance(eps, list): return {}
		result = {}
		for ep in eps:
			try:
				n = int(ep.get('number') or 0)
				fa = ep.get('first_aired')
				if n and fa: result[n] = fa
			except Exception: continue
		trakt_cache.set(key, {'_ts': time.time(), 'data': result, '_n': sum(1 for ep in eps if isinstance(ep, dict) and ep.get('number'))})
		return result
	except Exception as e:
		logger('trakt_air', 'fetch failed %s S%s: %s' % (slug, season_int, str(e)[:120]))
		return {}


def parse_utc_to_local(ts):
	"""Convert Trakt ISO 8601 UTC ('2026-08-07T01:00:00.000Z') to a naive local datetime.

	LOCAL PATCH 2026-08-29: this used to add `deadlight.datetime.offset` to the UTC value,
	treating it as the UTC->local offset in hours. It is not that. settings.date_offset()
	reads the SAME setting as `value + 5` for the 20:00 airtime guess, so the two consumers
	disagree about what it means, and being an integer it cannot express a half-hour zone
	at all. On an IST (UTC+5:30) box with the setting at -4 the result was 9.5 hours early:
	Daemons of the Shadow Realm S01E21 airs 20:00 IST, was computed as 10:30, and so
	appeared in Continue Watching most of a day before airing.

	The system timezone is the correct source and needs no configuration -- it is exact,
	handles half-hour offsets, and follows DST. Kodi's convention here is naive local
	(datetime.now()), so the tzinfo is stripped on the way out.
	"""
	if not ts: return None
	try:
		s = ts[:-1] if ts.endswith('Z') else ts
		if '.' in s:
			dt = datetime.strptime(s, '%Y-%m-%dT%H:%M:%S.%f')
		else:
			dt = datetime.strptime(s, '%Y-%m-%dT%H:%M:%S')
		return dt.replace(tzinfo=timezone.utc).astimezone().replace(tzinfo=None)
	except Exception: return None
