# -*- coding: utf-8 -*-
import sys
from modules.router import routing, sys_exit_check
# from modules.kodi_utils import logger

routing(sys)
# LOCAL PATCH 2026-09-26: rating backfills a directory listing deferred (see
# modules/metadata.flush_rating_backfills). routing() has returned, so endOfDirectory has
# already delivered the list; only runs if this process loaded metadata at all.
_metadata = sys.modules.get('modules.metadata')
if _metadata is not None:
	try: _metadata.flush_rating_backfills()
	except Exception: pass
if sys_exit_check(): sys.exit(1)
