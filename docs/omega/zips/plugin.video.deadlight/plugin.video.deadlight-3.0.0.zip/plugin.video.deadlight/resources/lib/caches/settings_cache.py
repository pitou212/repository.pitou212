# -*- coding: utf-8 -*-
import json
from modules import kodi_utils
from caches.base_cache import connect_database
# logger = kodi_utils.logger

class SettingsCache:
	def get(self, setting_id):
		try:
			dbcon = connect_database('settings_db')
			setting_id = setting_id.replace('deadlight.', '')
			setting_value = dbcon.execute('SELECT setting_value from settings WHERE setting_id = ?', (setting_id,)).fetchone()[0]
			self.set_memory_cache(setting_id, setting_value)
		except: setting_value = None
		return setting_value

	def remove_setting(self, setting_id):
		dbcon = connect_database('settings_db')
		dbcon.execute('DELETE FROM settings WHERE setting_id = ?', (setting_id,))

	def get_many(self, settings_list):
		try:
			dbcon = connect_database('settings_db')
			results = dict(dbcon.execute('SELECT setting_id, setting_value FROM settings WHERE setting_id in (%s)' \
										% (', '.join('?' for _ in settings_list)), settings_list).fetchall())
			return results
		except: results = {}
		return results

	def get_all(self):
		dbcon = connect_database('settings_db')
		try: all_settings = dict(dbcon.execute('SELECT setting_id, setting_value FROM settings').fetchall())
		except: all_settings = {}
		return all_settings

	def set(self, setting_id, setting_value=None):
		dbcon = connect_database('settings_db')
		setting_info = default_setting_values(setting_id)
		# LOCAL PATCH 2026-09-26: an id with no default row used to raise TypeError here, which
		# callers' bare excepts swallowed -- the write was silently lost. Say so in the log.
		if setting_info is None:
			from modules.kodi_utils import logger
			return logger('DeadLight', 'set_setting: no default row for %r, value not saved' % setting_id)
		setting_type, setting_default = setting_info['setting_type'], setting_info['setting_default']
		if setting_value is None: setting_value = setting_default
		dbcon.execute('INSERT OR REPLACE INTO settings VALUES (?, ?, ?, ?)', (setting_id, setting_type, setting_default, setting_value))
		self.set_memory_cache(setting_id, setting_value)
		# LOCAL PATCH 2026-08-29: was `setting_type == 'action' and ...`. The companion
		# `<id>_name` row is what the settings screen displays via $INFO[...(id_name)], and
		# gating it on 'action' meant the four option-backed settings declared as 'string'
		# -- skipsegment.intro/outro/recap.mode and skipsegment.button_corner -- never got
		# one, so those rows rendered BLANK instead of showing the selected option. Note
		# sync_settings' own obsolete-row scan already keys on settings_options alone, so
		# this brings the writer in line with the reader.
		if 'settings_options' in setting_info:
			name_setting_id = '%s_name' % setting_id
			name_setting_value = setting_info['settings_options'].get(setting_value, setting_value)
			dbcon.execute('INSERT OR REPLACE INTO settings VALUES (?, ?, ?, ?)', (name_setting_id, 'name', '', name_setting_value))
			self.set_memory_cache(name_setting_id, name_setting_value)

	def set_many(self, settings_list):
		dbcon = connect_database('settings_db')
		dbcon.executemany('INSERT OR REPLACE INTO settings VALUES (?, ?, ?, ?)', settings_list)
		for item in settings_list: self.set_memory_cache(item[0], item[3] or item[2])

	def set_memory_cache(self, setting_id, setting_value):
		kodi_utils.set_property('deadlight.%s' % setting_id, setting_value)

	def setting_info(self, setting_id):
		d_settings = default_settings()
		return [i for i in d_settings if i['setting_id'] == setting_id][0]

	def clean_database(self):
		try:
			dbcon = connect_database('settings_db')
			dbcon.execute('VACUUM')
			return True
		except: return False

settings_cache = SettingsCache()

def set_setting(setting_id, value):
	settings_cache.set(setting_id, value)

def get_setting(setting_id, fallback=''):
	return kodi_utils.get_property(setting_id) or settings_cache.get(setting_id) or fallback

def get_many(settings_list):
	return settings_cache.get_many(settings_list)

def _load_bundled_credentials():
	"""LOCAL PATCH 2026-07-29: import resources/lib/credentials.py if present.
	Returns a dict of setting_id → value for the local user's bundled credentials.
	File is gitignored (see .git/info/exclude); missing file = empty dict, no error."""
	try:
		import credentials
		return {k: v for k, v in getattr(credentials, 'CREDENTIALS', {}).items() if v}
	except Exception: return {}


_ANIME_ONLY_SWITCHES = ('magneto.provider.animetosho', 'magneto.provider.seadex', 'magneto.provider.nekobt', 'magneto.provider.nyaa')

def _magneto_settings_seed():
	# script.module.magneto's saved values ({id: value}), used once to start the bundled copy's rows.
	# Empty when magneto was never configured here -- the rows then take magneto's defaults.
	try:
		import xml.etree.ElementTree as ET
		path = kodi_utils.translate_path('special://profile/addon_data/script.module.magneto/settings.xml')
		return {i.get('id'): (i.text or '') for i in ET.parse(path).getroot() if i.get('id')}
	except: return {}

def sync_settings(params={}):
	silent = params.get('silent', 'true') == 'true'
	insert_list = []
	insert_list_append = insert_list.append
	currentsettings = settings_cache.get_all()
	d_settings = default_settings()
	defaultsettings_ids = [i['setting_id'] for i in d_settings]
	defaultsettings_names = [i['setting_id'] for i in d_settings if 'settings_options' in i]
	defaultsettings_ids.extend(['%s_name' % i for i in defaultsettings_names])
	try:
		c_settings = currentsettings.items()
		obsoletesettings_ids = [k for k, v in c_settings if not k in defaultsettings_ids]
		if obsoletesettings_ids:
			for item in obsoletesettings_ids: settings_cache.remove_setting(item)
	except: pass
	if currentsettings:
		c_settings = currentsettings.items()
		for k, v  in c_settings: settings_cache.set_memory_cache(k, v)
	# LOCAL PATCH 2026-07-29: load bundled credentials (gitignored file); values
	# override setting_defaults for first-time inserts AND overwrite empty_setting
	# rows already in DB, so a fresh box install picks up all your keys automatically.
	bundled = _load_bundled_credentials()
	magneto_seed = None
	for item in d_settings:
		setting_id = item['setting_id']
		setting_type = item['setting_type']
		setting_default = bundled.get(setting_id, item['setting_default'])
		if setting_id in currentsettings:
			# LOCAL PATCH 2026-09-26: the four anime-only providers have no switch on the settings screen;
			# their ticks in scrape.anime_providers are the switch. Keep the hidden rows in step with the
			# list on every sync (the dialog also writes both at once).
			if setting_id in _ANIME_ONLY_SWITCHES and 'scrape.anime_providers' in currentsettings:
				ticked = [i.strip().lower() for i in (currentsettings['scrape.anime_providers'] or '').split(',')]
				wanted = 'true' if setting_id[len('magneto.provider.'):] in ticked else 'false'
				if currentsettings[setting_id] != wanted:
					currentsettings[setting_id] = wanted
					insert_list_append((setting_id, setting_type, item['setting_default'], wanted))
			# LOCAL PATCH 2026-09-26: a removed option. settings_aliases maps its old value to the
			# one that replaces it; the value and its _name row are both rewritten, once, here.
			alias = (item.get('settings_aliases') or {}).get(currentsettings[setting_id])
			if alias is not None:
				currentsettings[setting_id] = alias
				insert_list_append((setting_id, setting_type, item['setting_default'], alias))
				label = item['settings_options'][alias]
				currentsettings['%s_name' % setting_id] = label
				insert_list_append(('%s_name' % setting_id, 'name', label, label))
			# Overwrite existing DB row ONLY if bundled has a real value AND
			# the DB currently holds an empty placeholder (empty_setting/'').
			if setting_id in bundled and currentsettings[setting_id] in ('empty_setting', '', 'None'):
				insert_list_append((setting_id, setting_type, item['setting_default'], setting_default))
			# LOCAL PATCH 2026-08-29: backfill a missing companion _name row for a setting
			# that is ALREADY in the DB. Without this the gate fix above only helps fresh
			# installs -- an existing one keeps rendering blank until the value is changed,
			# because this branch returns before the creation code below.
			if 'settings_options' in item and ('%s_name' % setting_id) not in currentsettings:
				current_value = currentsettings[setting_id]
				label = item['settings_options'].get(current_value, current_value)
				insert_list_append(('%s_name' % setting_id, 'name', label, label))
			# LOCAL PATCH 2026-09-07: refresh a companion _name row whose label the setting can no
			# longer produce. The backfill above only creates MISSING rows, so when an option label
			# is renamed (watched_indicators '0': 'DeadLight' -> 'DeadLight') every existing install
			# kept displaying the old word until the user happened to re-choose the value.
			elif 'settings_options' in item:
				name_id = '%s_name' % setting_id
				current_value = currentsettings[setting_id]
				label = item['settings_options'].get(current_value, current_value)
				if currentsettings.get(name_id) != label and label in item['settings_options'].values():
					insert_list_append((name_id, 'name', label, label))
			continue
		# LOCAL PATCH 2026-09-26: a new magneto.* row starts from what script.module.magneto had.
		if setting_id.startswith('magneto.'):
			if magneto_seed is None: magneto_seed = _magneto_settings_seed()
			seeded = magneto_seed.get(setting_id[len('magneto.'):])
			if seeded is not None and ('settings_options' not in item or seeded in item['settings_options']):
				setting_default = seeded
		# LOCAL PATCH 2026-09-26: the anime list doubles as the switch for the four anime-only providers
		# (indexers/dialogs.anime_providers_choice), so it starts as the ones magneto has switched ON --
		# the same set that actually ran on anime before, since the old whitelist could only skip.
		elif setting_id == 'scrape.anime_providers':
			if magneto_seed is None: magneto_seed = _magneto_settings_seed()
			on = [p for p in ('animetosho', 'seadex', 'nyaa', 'nekobt')
				if magneto_seed.get('provider.%s' % p, default_setting_values('magneto.provider.%s' % p)['setting_default']) == 'true']
			if on: setting_default = ','.join(on)
		if 'settings_options' in item:
			name_default = item['settings_options'].get(setting_default, item['settings_options'][item['setting_default']])
			insert_list_append(('%s_name' % setting_id, 'name', name_default, name_default))
		insert_list_append((setting_id, setting_type, item['setting_default'], setting_default))
	if insert_list: settings_cache.set_many(insert_list)
	settings_cache.clean_database()
	if not silent: kodi_utils.notification('Settings Cache Remade')

def set_default(setting_ids):
	if not isinstance(setting_ids, list): setting_ids = [setting_ids]
	if not kodi_utils.confirm_dialog(text='Are You Sure?', ok_label='Yes', cancel_label='No', default_control=11): return
	for setting_id in setting_ids:
		try: set_setting(setting_id, default_setting_values(setting_id)['setting_default'])
		except: pass

def set_boolean(params):
	boolean_dict = {'true': 'false', 'false': 'true'}
	setting = params['setting_id']
	set_setting(setting, boolean_dict[get_setting('deadlight.%s' % setting)])

def set_string(params):
	current_value = get_setting('deadlight.%s' % params['setting_id'])
	current_value = current_value.replace('empty_setting', '')
	new_value = kodi_utils.kodi_dialog().input('', defaultt=current_value)
	# LOCAL PATCH 2026-09-26: Back on the keyboard also returns '', and the only ways out used to
	# be "Yes" (blank the setting) or "Re-Enter Value" -- so backing out of an API-key field could
	# wipe the key. Nothing to clear -> nothing to do; otherwise keeping the value is the default.
	if not new_value:
		if not current_value: return
		choice = kodi_utils.kodi_dialog().select('Blank value entered', ['Keep current value', 'Clear this setting', 'Re-enter value'])
		if choice == 2: return set_string(params)
		if choice != 1: return
	set_setting(params['setting_id'], new_value or 'empty_setting')

def set_numeric(params):
	setting_id = params['setting_id']
	setting_values = default_setting_values(setting_id)
	values_get = setting_values.get
	min_value, max_value = int(values_get('min_value', '0')), int(values_get('max_value', '100000000000000'))
	negative_included = any((n < 0 for n in [min_value, max_value]))
	if negative_included:
		multiplier_values = [('Positive(+)', 1), ('Negative(-)', -1)]
		list_items = [{'line1': item[0]} for item in multiplier_values]
		kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true', 'heading': 'Will this be a positive or negative number?'}
		multiplier = kodi_utils.select_dialog(multiplier_values, **kwargs)
	else: multiplier = None
	new_value = kodi_utils.kodi_dialog().input('Range [B]%s - %s[/B].' % (min_value, max_value), type=1)
	if not new_value: return
	if multiplier: new_value = str(int(float(new_value) * multiplier[1]))
	if int(new_value) < min_value or int(new_value) > max_value:
		kodi_utils.ok_dialog(text='Please Choose Between the Range [B]%s - %s[/B].' % (min_value, max_value))
		return set_numeric(params)
	set_setting(setting_id, new_value)

def set_path(params):
	setting_id = params['setting_id']
	browse_mode = int(default_setting_values(setting_id)['browse_mode'])
	new_value = kodi_utils.kodi_dialog().browse(browse_mode, '', '', defaultt=get_setting('deadlight.%s' % setting_id))
	set_setting(setting_id, new_value)

def set_from_list(params):
	setting_id = params['setting_id']
	settings_options = default_setting_values(setting_id)['settings_options'].items()
	settings_list = [(v, k) for k, v in settings_options]
	new_value = kodi_utils.select_dialog(settings_list, **{'items': json.dumps([{'line1': item[0]} for item in settings_list]), 'narrow_window': 'true'})
	if not new_value: return
	setting_value = new_value[1]
	set_setting(setting_id, setting_value)

def set_source_folder_path(params):
	setting_id = params['setting_id']
	current_setting = get_setting('deadlight.%s' % setting_id)
	if current_setting not in (None, 'None', ''):
		if kodi_utils.confirm_dialog(text='Enter Blank Value?', ok_label='Yes', cancel_label='Re-Enter Value', default_control=11):
			return set_setting(setting_id, 'None')
	return set_path(params)

def restore_setting_default(params):
	silent = params.get('silent', 'false') == 'true'
	if not silent and not kodi_utils.confirm_dialog(): return
	try:
		setting_id = params['setting_id']
		setting_default = default_setting_values(setting_id)['setting_default']
		set_setting(setting_id, setting_default)
	except:
		if not silent: kodi_utils.ok_dialog(text='Error restoring default setting')

def default_setting_values(setting_id):
	if 'deadlight.' in setting_id: setting_id = setting_id.replace('deadlight.', '')
	d_settings = default_settings()
	return next((i for i in d_settings if i['setting_id'] == setting_id), None)

_default_settings_cache = None
def default_settings():
	# LOCAL PATCH 2026-05-26: cache the 400+ item list at module level so repeat callers
	# (setting_info, sync_settings, get_setting_data) don't rebuild the literal each call.
	global _default_settings_cache
	if _default_settings_cache is not None:
		return _default_settings_cache
	_default_settings_cache = [
#===============================================================================#
#====================================GENERAL====================================#
#===============================================================================#
#==================== General
{'setting_id': 'auto_start_deadlight', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'addon_icon_choice', 'setting_type': 'string', 'setting_default': 'resources/media/addon_icons/deadlight_icon_09.png'},
{'setting_id': 'default_addon_fanart', 'setting_type': 'path', 'setting_default': kodi_utils.addon_fanart(), 'browse_mode': '2'},
{'setting_id': 'limit_concurrent_threads', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'max_threads', 'setting_type': 'action', 'setting_default': '60', 'min_value': '10', 'max_value': '250'},
#==================== Window Theme
{'setting_id': 'window_theme', 'setting_type': 'string', 'setting_default': 'CC1F2020'},
{'setting_id': 'window_theme_opacity', 'setting_type': 'string', 'setting_default': 'CC'},
#==================== Manage Updates
{'setting_id': 'update.action', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Prompt', '1': 'Automatic', '2': 'Notification', '3': 'Off'}},
{'setting_id': 'update.delay', 'setting_type': 'action', 'setting_default': '10', 'min_value': '10', 'max_value': '300'},
{'setting_id': 'update.username', 'setting_type': 'string', 'setting_default': 'FenlightAnonyMouse'},
{'setting_id': 'update.location', 'setting_type': 'string', 'setting_default': 'FenlightAnonyMouse.github.io'},
# LOCAL PATCH 2026-09-14: menu artwork gets its own repo pointer, separate from the
# updater's. get_icon() used to build its URLs from update.username/update.location,
# which are the UPDATER's coordinates -- so pointing the add-on at a different artwork
# host also silently repointed where it looks for its own release zips, and vice versa.
# Two unrelated things behind one pair of settings.
#
# The defaults below are live and serving; the update.* defaults above are not. The
# account FenlightAnonyMouse no longer exists, and the repo this install actually
# pointed at (TIKIPETER/Fenlight.github.io, now Tikipeter/Tikipeter.github.io) has no
# packages/media tree at all -- every icon URL returned 404. Icons still rendered only
# because Kodi had 65 of them in its local texture cache; a cache clear or a fresh
# install showed none, and any icon not already cached never appeared.
{'setting_id': 'media.username', 'setting_type': 'string', 'setting_default': 'pitou212'},
{'setting_id': 'media.location', 'setting_type': 'string', 'setting_default': 'deadlight-media'},
#==================== Watched Indicators
# LOCAL PATCH 2026-07-23: extended enum from binary (0=Fen/1=Trakt) to 3-way with MDBList.
# LOCAL PATCH 2026-07-29: added SIMKL as slot 3 (fourth provider). Existing users on
# 0/1/2 keep the same value + label.
{'setting_id': 'watched_indicators', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'DeadLight', '1': 'Trakt', '2': 'MDBList', '3': 'SIMKL'}},
# LOCAL PATCH 2026-08-05 (Red Light R4 port): exclude S0 specials from progress
# calculations. Default true — matches Red Light 2.x behavior. When true,
# watched_info_tvshow drops S0 rows from COUNT(*); progress % / playcount align
# with total_aired_eps (which already excludes S0).
{'setting_id': 'progress.exclude_specials', 'setting_type': 'boolean', 'setting_default': 'true'},
#======+============= Trakt Cache
{'setting_id': 'trakt.sync_interval', 'setting_type': 'action', 'setting_default': '60', 'min_value': '5', 'max_value': '600'},
{'setting_id': 'trakt.refresh_widgets', 'setting_type': 'boolean', 'setting_default': 'true'},
#======+============= MDBList Cache
{'setting_id': 'mdblist.sync_interval', 'setting_type': 'action', 'setting_default': '60', 'min_value': '5', 'max_value': '600'},
{'setting_id': 'mdblist.refresh_widgets', 'setting_type': 'boolean', 'setting_default': 'true'},
# LOCAL PATCH 2026-09-14: MDBList as a second ratings source beside OMDb. Default on --
# it only ever ADDS keys OMDb left empty, so turning it on cannot change a rating the
# user already sees. Gated separately from the sync settings above because a user may
# want MDBList lists without the extra per-item ratings request.
{'setting_id': 'mdblist.enable_ratings', 'setting_type': 'boolean', 'setting_default': 'true'},
#======+============= SIMKL Cache (LOCAL PATCH 2026-07-29)
{'setting_id': 'simkl.sync_interval', 'setting_type': 'action', 'setting_default': '60', 'min_value': '5', 'max_value': '600'},
{'setting_id': 'simkl.refresh_widgets', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'simkl.scrobble', 'setting_type': 'boolean', 'setting_default': 'true'},
#======+============= AniList Cache (LOCAL PATCH 2026-08-29)
{'setting_id': 'anilist.sync_interval', 'setting_type': 'action', 'setting_default': '60', 'min_value': '5', 'max_value': '600'},
{'setting_id': 'anilist.refresh_widgets', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'anilist.scrobble', 'setting_type': 'boolean', 'setting_default': 'true'},
# LOCAL PATCH 2026-07-30: auto-focus first unwatched episode when entering a season.
{'setting_id': 'episodes.autoscroll_unwatched', 'setting_type': 'boolean', 'setting_default': 'true'},
# LOCAL PATCH 2026-08-29: unaired episodes and wholly unaired seasons are dropped from the
# lists rather than shown red-italicised and unplayable. Phrased as include_* off-by-default
# to match this addon's own nextep.include_unaired and POV's show_unaired, so "on" means the
# same thing everywhere.
{'setting_id': 'episodes.include_unaired', 'setting_type': 'boolean', 'setting_default': 'false'},
#==================== UTC Time Offset
{'setting_id': 'datetime.offset', 'setting_type': 'action', 'setting_default': '0', 'min_value': '-15', 'max_value': '15'},
{'setting_id': 'episodes.air_grace', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0', 'max_value': '48'},
#==================== Subtitles (displayed under the PLAYBACK tab, not here -- the
# settings_manager.xml row for each carries HasFocus(80). These four sat under the UTC
# banner above purely because they were appended to the end of that group.)
{'setting_id': 'subtitles.auto_download', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'subtitles.language', 'setting_type': 'string', 'setting_default': 'English',
	'settings_options': {'Arabic': 'Arabic', 'Bengali': 'Bengali', 'Bulgarian': 'Bulgarian', 'Chinese': 'Chinese', 'Croatian': 'Croatian', 'Czech': 'Czech', 'Danish': 'Danish', 'Dutch': 'Dutch', 'English': 'English', 'Finnish': 'Finnish', 'French': 'French', 'German': 'German', 'Greek': 'Greek', 'Hebrew': 'Hebrew', 'Hindi': 'Hindi', 'Hungarian': 'Hungarian', 'Indonesian': 'Indonesian', 'Italian': 'Italian', 'Japanese': 'Japanese', 'Korean': 'Korean', 'Norwegian': 'Norwegian', 'Persian': 'Persian', 'Polish': 'Polish', 'Portuguese': 'Portuguese', 'Portuguese (Brazil)': 'Portuguese (Brazil)', 'Romanian': 'Romanian', 'Russian': 'Russian', 'Serbian': 'Serbian', 'Slovenian': 'Slovenian', 'Spanish': 'Spanish', 'Swedish': 'Swedish', 'Tamil': 'Tamil', 'Telugu': 'Telugu', 'Thai': 'Thai', 'Turkish': 'Turkish', 'Ukrainian': 'Ukrainian', 'Vietnamese': 'Vietnamese'}},
{'setting_id': 'subtitles.auto_enable', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'subtitles.manifest', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#==================== Downloads
{'setting_id': 'movie_download_directory', 'setting_type': 'path', 'setting_default': 'special://profile/addon_data/plugin.video.deadlight/Movies Downloads/', 'browse_mode': '0'},
{'setting_id': 'tvshow_download_directory', 'setting_type': 'path', 'setting_default': 'special://profile/addon_data/plugin.video.deadlight/TV Show Downloads/', 'browse_mode': '0'},
{'setting_id': 'premium_download_directory', 'setting_type': 'path', 'setting_default': 'special://profile/addon_data/plugin.video.deadlight/Premium Downloads/', 'browse_mode': '0'},
{'setting_id': 'image_download_directory', 'setting_type': 'path', 'setting_default': 'special://profile/addon_data/plugin.video.deadlight/Image Downloads/', 'browse_mode': '0'},


#================================================================================#
#====================================FEATURES====================================#
#================================================================================#
#==================== Extras
{'setting_id': 'extras.enable_extra_ratings', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'extras.enabled_ratings', 'setting_type': 'string', 'setting_default': 'Meta, Tom/Critic, Tom/User, IMDb, TMDb'},
{'setting_id': 'extras.enable_item_ratings', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'extras.enable_scrollbars', 'setting_type': 'boolean', 'setting_default': 'false'},
#==================== Special Open Actions
{'setting_id': 'media_open_action_movie', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Open Extras', '2': 'Open Movie Set', '3': 'Both'}},
{'setting_id': 'media_open_action_tvshow', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Open Extras'}},
#==================== AI Generated Similar Titles
{'setting_id': 'ai_model.order', 'setting_type': 'string', 'setting_default': 'gemini-2.5-flash-lite,llama-3.3-70b-versatile,gemma-3-27b-it,llama-3.1-8b-instant'},
{'setting_id': 'ai_model.limit', 'setting_type': 'action', 'setting_default': '15', 'min_value': '1', 'max_value': '25'},


#==================================================================================#
#====================================CONTENT=======================================#
#==================================================================================#
#==================== General
{'setting_id': 'paginate.lists', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Off', '1': 'Within Addon Only', '2': 'Widgets Only', '3': 'Both'}},
{'setting_id': 'paginate.limit_addon', 'setting_type': 'action', 'setting_default': '20'},
{'setting_id': 'paginate.limit_widgets', 'setting_type': 'action', 'setting_default': '20'},
{'setting_id': 'paginate.jump_to', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'ignore_articles', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'recommend_service', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Recommended (TMDb)', '1': 'More Like This (IMDb)',
'2': 'Similar (AI)', '3': 'Related (Trakt)'}},
{'setting_id': 'recommend_seed', 'setting_type': 'action', 'setting_default': '5', 'settings_options': {'1': 'Last Watched Only', '2': 'Last 2 Watched',
'3': 'Last 3 Watched', '4': 'Last 4 Watched', '5': 'Last 5 Watched', '6': 'Last 6 Watched', '7': 'Last 7 Watched', '8': 'Last 8 Watched',
'9': 'Last 9 Watched', '10': 'Last 10 Watched'}},
{'setting_id': 'mpaa_region', 'setting_type': 'string', 'setting_default': 'US'},
{'setting_id': 'lists_cache_duraton', 'setting_type': 'string', 'setting_default': '24'},
{'setting_id': 'tv_progress_location', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Watched', '1': 'In Progress', '2': 'Both'}},
{'setting_id': 'show_specials', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'use_season_name', 'setting_type': 'boolean', 'setting_default': 'false'},
# LOCAL PATCH 2026-08-27: show anime cours as separate season rows. TMDb bundles
# multi-cour anime into one season (Frieren = one 38-episode season, really 28+10);
# Fribb's offsets split it back apart. Display only -- (season, episode) stays TMDb's.
{'setting_id': 'anime.split_cours', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'default_all_episodes', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Never', '1': 'If Only One Season', '2': 'Always'}},
{'setting_id': 'avoid_episode_spoilers', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'include_anime_tvshow', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'show_unaired_watchlist', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'dropshow.hide_from_lists', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'meta_filter', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'use_viewtypes', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'manual_viewtypes', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'view.main', 'setting_type': 'string', 'setting_default': '55'},
{'setting_id': 'view.movies', 'setting_type': 'string', 'setting_default': '500'},
{'setting_id': 'view.tvshows', 'setting_type': 'string', 'setting_default': '500'},
{'setting_id': 'view.seasons', 'setting_type': 'string', 'setting_default': '55'},
{'setting_id': 'view.episodes', 'setting_type': 'string', 'setting_default': '55'},
{'setting_id': 'view.episodes_single', 'setting_type': 'string', 'setting_default': '55'},
{'setting_id': 'view.premium', 'setting_type': 'string', 'setting_default': '55'},
#==================== Contents Sort Order For Watched Progress
{'setting_id': 'sort.progress', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Title', '1': 'Recently Watched'}},
{'setting_id': 'sort.watched', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Title', '1': 'Recently Watched'}},
#==================== Contents Sort Order For Trakt Lists
{'setting_id': 'sort.collection', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Title', '1': 'Date Added', '2': 'Release Date'}},
{'setting_id': 'sort.watchlist', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Title', '1': 'Date Added', '2': 'Release Date'}},
#==================== Contents Sort Order For TMDb Lists
{'setting_id': 'tmdbsort.watchlist', 'setting_type': 'action', 'setting_default': '4', 'settings_options': {'0': 'Title', '1': 'Release Date (asc)', '2': 'Release Date (desc)',
'3': 'Shuffle', '4': 'Default from TMDb (None)'}},
{'setting_id': 'tmdbsort.favorites', 'setting_type': 'action', 'setting_default': '4', 'settings_options': {'0': 'Title', '1': 'Release Date (asc)', '2': 'Release Date (desc)',
'3': 'Shuffle', '4': 'Default from TMDb (None)'}},
#==================== Personal Lists
{'setting_id': 'personal_list.sort_unseen_to_top', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'personal_list.highlight_unseen', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'personal_list.unseen_highlight', 'setting_type': 'string', 'setting_default': 'FF4DDBFF'},
{'setting_id': 'personal_list.show_author', 'setting_type': 'boolean', 'setting_default': 'true'},
#==================== Widgets
{'setting_id': 'widget_refresh_timer', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'widget_refresh_notification', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'widget_hide_watched', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'widget_hide_next_page', 'setting_type': 'boolean', 'setting_default': 'false'},
#==================== RPDb Ratings Posters
{'setting_id': 'rpdb_enabled', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Movies', '2': 'TV Shows', '3': 'Both'}},
{'setting_id': 'rpdb_format', 'setting_type': 'string', 'setting_default': ''},
#==================== Context Menu
{'setting_id': 'context_menu.enabled', 'setting_type': 'string',
'setting_default': 'extras,options,playback_options,browse_movie_set,browse_seasons,browse_episodes,recommended,related,more_like_this,similar,in_trakt_list,' \
'trakt_manager,anilist_manager,drop_show,personal_manager,tmdb_manager,favorites_manager,mark_watched,unmark_previous_episode,exit,refresh,reload'},
{'setting_id': 'context_menu.order', 'setting_type': 'string',
'setting_default': 'extras,options,playback_options,browse_movie_set,browse_seasons,browse_episodes,recommended,related,more_like_this,similar,in_trakt_list,' \
'trakt_manager,anilist_manager,drop_show,personal_manager,tmdb_manager,favorites_manager,mark_watched,unmark_previous_episode,exit,refresh,reload'},


#==================================================================================#
#====================================SINGLE EPISODE LISTS==========================#
#==================================================================================#
#==================== General
{'setting_id': 'single_ep_display', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'TITLE: SxE - EPISODE', '1': 'SxE - EPISODE', '2': 'EPISODE'}},
{'setting_id': 'single_ep_display_widget', 'setting_type': 'action', 'setting_default': '1', 'settings_options': {'0': 'TITLE: SxE - EPISODE', '1': 'SxE - EPISODE', '2': 'EPISODE'}},
{'setting_id': 'single_ep_unwatched_episodes', 'setting_type': 'boolean', 'setting_default': 'false'},
#==================== Next Episodes
{'setting_id': 'nextep.method', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Last Aired', '1': 'Last Watched'}},
{'setting_id': 'nextep.sort_type', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Recently Watched', '1': 'Airdate', '2': 'Title'}},
{'setting_id': 'nextep.sort_order', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Descending', '1': 'Ascending'}},
{'setting_id': 'nextep.limit_history', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nextep.limit', 'setting_type': 'action', 'setting_default': '20', 'min_value': '1', 'max_value': '200'},
{'setting_id': 'nextep.include_unwatched', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Watchlist', '2': 'Favorites', '3': 'Both'}},
{'setting_id': 'nextep.include_airdate', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nextep.airing_today', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'nextep.include_unaired', 'setting_type': 'boolean', 'setting_default': 'false'},
#======+============= Trakt Calendar
{'setting_id': 'trakt.flatten_episodes', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'trakt.calendar_sort_order', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Descending', '1': 'Ascending'}},
{'setting_id': 'trakt.calendar_previous_days', 'setting_type': 'action', 'setting_default': '7', 'min_value': '0', 'max_value': '14'},
{'setting_id': 'trakt.calendar_future_days', 'setting_type': 'action', 'setting_default': '7', 'min_value': '0', 'max_value': '14'},


#=====================================================================================#
#====================================META ACCOUNTS====================================#
#=====================================================================================#
#==================== Trakt
{'setting_id': 'trakt.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'trakt.client', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'trakt.secret', 'setting_type': 'string', 'setting_default': 'empty_setting'},
# LOCAL PATCH 2026-07-23: MDBList — user (username shown after auth) + token (API key OR OAuth access_token)
# LOCAL PATCH 2026-08-07 (POV OAuth port): client_id + refresh + expires added for device-code OAuth flow.
# call_mdblist detects OAuth mode via `mdblist.refresh` presence: set → Bearer token, else → legacy apikey query param.
{'setting_id': 'mdblist.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'mdblist.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'mdblist.client_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'mdblist.refresh', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'mdblist.expires', 'setting_type': 'string', 'setting_default': 'empty_setting'},
# LOCAL PATCH 2026-07-29: SIMKL persistence — client_id user-supplied (registered at
# simkl.com/settings/developer), token via PIN device flow, no client_secret needed.
{'setting_id': 'simkl.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'simkl.client_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'simkl.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'simkl.last_activity', 'setting_type': 'string', 'setting_default': 'empty_setting'},
# LOCAL PATCH 2026-09-22: the FULL /sync/activities snapshot, as JSON. last_activity above
# keeps only the max timestamp, which cannot say WHICH list moved. Must be declared here:
# default_setting_values returns None for an unknown id and SettingsCache.set then raises.
{'setting_id': 'simkl.last_activities', 'setting_type': 'string', 'setting_default': 'empty_setting'},
# LOCAL PATCH 2026-08-29: AniList persistence. Authorization Code (PIN) flow -- AniList
# rejects the implicit grant, so the client_secret IS required to exchange the PIN. Both it
# and client_id belong to a client the USER registers (anilist.co/settings/developer); nothing
# revocable ships in the addon, the same choice made for simkl.client_id above.
# The token lasts ~1 year; the refresh token is stored but no refresh loop runs yet.
{'setting_id': 'anilist.user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'anilist.client_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'anilist.client_secret', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'anilist.refresh', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'anilist.expires', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'anilist.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'anilist.userid', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'anilist.last_activity', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#==================== TMDb API
{'setting_id': 'tmdb_api', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'tmdb.read_access_token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#==================== TMDb Lists
{'setting_id': 'tmdb.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'tmdb.username', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#==================== OMDb
{'setting_id': 'omdb_api', 'setting_type': 'string', 'setting_default': 'empty_setting'},
# LOCAL PATCH 2026-09-14: per-episode IMDb ratings, one OMDb request per SEASON
# (omdb_api.season_episode_ratings), folded into the season cache. Default on: it is
# one call per season per cache window, and it replaces a chip that was showing the
# SHOW's rating identically on every episode of that show.
{'setting_id': 'omdb.episode_ratings', 'setting_type': 'boolean', 'setting_default': 'true'},
# LOCAL PATCH 2026-08-06: Fanart.tv Personal API Key for curated backdrop cycling.
# Register at fanart.tv/get-an-api-key/. When set, movie_meta + tvshow_meta blend
# fanart.tv's `moviebackground` / `showbackground` results with TMDb backdrops
# for a richer AF3-fanart-cycler experience. Empty = TMDb backdrops only.
{'setting_id': 'fanarttv_api', 'setting_type': 'string', 'setting_default': 'empty_setting'},
# LOCAL PATCH 2026-08-07: master toggle for fanart.tv integration. When false, the
# fanart.tv fetch is skipped even if a key is set — extra_fanart_list falls back
# to TMDb backdrops only. Lets users flip the feature off without wiping the key.
{'setting_id': 'fanarttv.enabled', 'setting_type': 'boolean', 'setting_default': 'true'},
#==================== Backdrop provider
# LOCAL PATCH 2026-09-14: which service supplies the backdrop, chosen separately for
# movies, TV shows and anime, because a user can reasonably want a different answer
# for each and the providers differ in what they can even be asked:
#   TMDb      always available. No date on its image objects, so 'newest uploaded' is
#             not expressible there at all; ordering is by vote.
#   TVDB      shows and movies. The artwork id is a monotonic auto-increment and so a
#             real upload ordering, and includesText is a genuine textless flag. Shows
#             use the tvdb_id TMDb already provides; movies need a remoteid hop off the
#             IMDb id, costing one extra cached request.
#   fanart.tv shows and movies, ranked by likes. Already fetched here for the clearlogo
#             on the SAME cache key, so it is a hit rather than a call -- which matters,
#             personal keys allow only 30 requests per 5 minutes.
# Anime is detected per item via is_anime_check (TMDb keyword 210024) rather than by
# which list the row came from, so an anime opened from Search is still anime.
# All default to 0, so nothing changes until a provider is picked.
# 2026-09-26: 'Newest Uploaded (TVDB)' ('1') removed -- the choice is TMDb / TVDB / fanart.tv, TVDB
# always picking its highest-rated image. Keys stay 0/2/3 so no other value moves; sync_settings
# rewrites a stored '1' to '2' through settings_aliases.
{'setting_id': 'movie.artwork_provider', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'TMDb', '2': 'TVDB', '3': 'fanart.tv'}, 'settings_aliases': {'1': '2'}},
{'setting_id': 'tvshow.artwork_provider', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'TMDb', '2': 'TVDB', '3': 'fanart.tv'}, 'settings_aliases': {'1': '2'}},
{'setting_id': 'anime.artwork_provider', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'TMDb', '2': 'TVDB', '3': 'fanart.tv'}, 'settings_aliases': {'1': '2'}},
{'setting_id': 'tvdb_api', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#==================== RPDb
{'setting_id': 'rpdb_api', 'setting_type': 'string', 'setting_default': 't0-free-rpdb'},
#==================== Google API
{'setting_id': 'google_api', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#==================== GROQ API
{'setting_id': 'groq_api', 'setting_type': 'string', 'setting_default': 'empty_setting'},


#=====================================================================================#
#====================================STREAMING ACCOUNTS===============================#
#=====================================================================================#
#==================== External
{'setting_id': 'provider.external', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'external.cache_check', 'setting_type': 'boolean', 'setting_default': 'false'},
# LOCAL PATCH 2026-09-26: the bundled magneto providers (resources/lib/magneto). magneto.modules.control
# reads setting 'x' as 'magneto.x'. Defaults are magneto's own; on the first sync each row instead takes
# the value from script.module.magneto's settings.xml when that file exists (see sync_settings).
{'setting_id': 'magneto.provider.torrentio', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'magneto.provider.comet', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'magneto.comet.url', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Kuu-lection', '1': 'Goldy', '2': 'Midnightignite'}},
{'setting_id': 'magneto.provider.mediafusion', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'magneto.provider.torz', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'magneto.torz.url', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Kuu-lection', '1': 'Munif', '2': 'Midnightignite'}},
{'setting_id': 'magneto.provider.torrentsdb', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'magneto.provider.animetosho', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'magneto.provider.seadex', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'magneto.provider.nekobt', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'magneto.provider.nyaa', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'magneto.filter.undesirables', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'magneto.filter.foreign.single.audio', 'setting_type': 'boolean', 'setting_default': 'false'},
# LOCAL PATCH 2026-09-26: the anime whitelist read by scrapers/external.py (_is_not_for_anime_skipped).
# Had no row, so it could not be saved; set from the settings screen with a multi-select.
{'setting_id': 'scrape.anime_providers', 'setting_type': 'string', 'setting_default': 'animetosho,seadex,nyaa,nekobt'},
#==================== Real Debrid
{'setting_id': 'rd.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'rd.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'rd.account_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'store_resolved_to_cloud.real-debrid', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'All', '2': 'Show Packs Only'}},
{'setting_id': 'provider.rd_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'rd_cloud.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.rd_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.rd_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results.sort_rdcloud_first', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'rd.priority', 'setting_type': 'action', 'setting_default': '10', 'min_value': '1', 'max_value': '10'},
{'setting_id': 'rd.alternate_base_url', 'setting_type': 'boolean', 'setting_default': 'false'},
#==================== Premiumize
{'setting_id': 'pm.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'pm.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'pm.account_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'store_resolved_to_cloud.premiumize.me', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'All', '2': 'Show Packs Only'}},
{'setting_id': 'provider.pm_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'pm_cloud.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.pm_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.pm_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results.sort_pmcloud_first', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'pm.priority', 'setting_type': 'action', 'setting_default': '10', 'min_value': '1', 'max_value': '10'},
#==================== All Debrid
{'setting_id': 'ad.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'ad.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'ad.account_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'store_resolved_to_cloud.alldebrid', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'All', '2': 'Show Packs Only'}},
{'setting_id': 'provider.ad_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'ad_cloud.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.ad_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.ad_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results.sort_adcloud_first', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'ad.priority', 'setting_type': 'action', 'setting_default': '10', 'min_value': '1', 'max_value': '10'},
#==================== TorBox
{'setting_id': 'tb.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'tb.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'store_resolved_to_cloud.torbox', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'All', '2': 'Show Packs Only'}},
{'setting_id': 'provider.tb_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'tb_cloud.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.tb_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.tb_cloud', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results.sort_tbcloud_first', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'tb.priority', 'setting_type': 'action', 'setting_default': '10', 'min_value': '1', 'max_value': '10'},
#==================== Easynews
{'setting_id': 'provider.easynews', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'easynews_user', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'easynews_password', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'easynews.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'easynews.filter_lang', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'easynews.lang_filters', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'check.easynews', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.easynews', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'en.priority', 'setting_type': 'action', 'setting_default': '7', 'min_value': '1', 'max_value': '10'},
#=========+========== Folders
{'setting_id': 'provider.folders', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'folders.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.folders', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.folders', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results.sort_folders_first', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'results.folders_ignore_filters', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'folders.priority', 'setting_type': 'action', 'setting_default': '6', 'min_value': '1', 'max_value': '10'},
#=========+========== AIOStreams
{'setting_id': 'provider.aiostreams', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'aiostreams.title_filter', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'check.aiostreams', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.aiostreams', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'aiostreams.priority', 'setting_type': 'action', 'setting_default': '10', 'min_value': '1', 'max_value': '10'},
{'setting_id': 'provider.aiostreams_highlight', 'setting_type': 'string', 'setting_default': 'FFFF8C00'},
{'setting_id': 'aiostreams.manifest_url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#=========+========== HTTP Streams (HDHub JSON aggregator, ported from plugin.video.tmdbmovies)
{'setting_id': 'provider.http_streams', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'http_streams.hdhub', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'http_streams.sootio', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'http_streams.sootio_url', 'setting_type': 'string', 'setting_default': 'empty_setting'},
# LOCAL PATCH 2026-08-29: MoviesDrive ported from plugin.video.tmdbmovies. HDHub4u was
# ported 2026-06-12 but left unwired because the HDHub JSON aggregator already carries its
# content; exposed here as an opt-in so it can be A/B'd, off by default to avoid duplicates.
{'setting_id': 'http_streams.title_filter', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'http_streams.validate_urls', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'http_streams.validate_timeout', 'setting_type': 'action', 'setting_default': '5', 'min_value': '2', 'max_value': '15'},
{'setting_id': 'check.http_streams', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay.http_streams', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'http_streams.priority', 'setting_type': 'action', 'setting_default': '10', 'min_value': '1', 'max_value': '10'},
{'setting_id': 'provider.http_streams_highlight', 'setting_type': 'string', 'setting_default': 'FFFF8C00'},
#=========+========== SmartPlay (sticky source for next episode)
{'setting_id': 'smartplay.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'smartplay.state', 'setting_type': 'string', 'setting_default': 'empty_setting'},


#===============================================================================#
#====================================RESULTS====================================#
#===============================================================================#
#==================== Display
{'setting_id': 'results.timeout', 'setting_type': 'action', 'setting_default': '20', 'min_value': '1'},
{'setting_id': 'results.list_format', 'setting_type': 'string', 'setting_default': 'List'},
#==================== Rescrape
{'setting_id': 'rescrape.cache_ignored', 'setting_type': 'action', 'setting_default': '1', 'settings_options': {'0': 'Off', '1': 'Auto', '2': 'Prompt'}},
{'setting_id': 'rescrape.cache_ignored.order', 'setting_type': 'action', 'setting_default': '0', 'min_value': '1', 'max_value': '5'},
{'setting_id': 'rescrape.imdb_year', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Off', '1': 'Auto', '2': 'Prompt'}},
{'setting_id': 'rescrape.imdb_year.order', 'setting_type': 'action', 'setting_default': '1', 'min_value': '1', 'max_value': '5'},
{'setting_id': 'rescrape.with_all', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Off', '1': 'Auto', '2': 'Prompt'}},
{'setting_id': 'rescrape.with_all.order', 'setting_type': 'action', 'setting_default': '2', 'min_value': '1', 'max_value': '5'},
{'setting_id': 'rescrape.episode_group', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Off', '1': 'Auto', '2': 'Prompt'}},
{'setting_id': 'rescrape.episode_group.order', 'setting_type': 'action', 'setting_default': '3', 'min_value': '1', 'max_value': '5'},
{'setting_id': 'rescrape.ignore_filters', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Off', '1': 'Auto', '2': 'Prompt'}},
{'setting_id': 'rescrape.ignore_filters.order', 'setting_type': 'action', 'setting_default': '4', 'min_value': '1', 'max_value': '5'},
#==================== Sorting and Filtering
{'setting_id': 'results.sort_order_display', 'setting_type': 'string', 'setting_default': 'Quality, Size, Provider'},
{'setting_id': 'results.filter_size_method', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Off', '1': 'Use Line Speed', '2': 'Use Size'}},
{'setting_id': 'results.line_speed', 'setting_type': 'action', 'setting_default': '25', 'min_value': '1'},
{'setting_id': 'results.movie_size_max', 'setting_type': 'action', 'setting_default': '10000', 'min_value': '1'},
{'setting_id': 'results.episode_size_max', 'setting_type': 'action', 'setting_default': '3000', 'min_value': '1'},
{'setting_id': 'results.movie_size_min', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0'},
{'setting_id': 'results.episode_size_min', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0'},
{'setting_id': 'results.size_unknown', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'results.size_sort_weighted', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results.size_sort_direction', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Descending', '1': 'Ascending'}},
{'setting_id': 'results.uncached_min_seeders', 'setting_type': 'action', 'setting_default': '0', 'min_value': '0'},
{'setting_id': 'results.limit_number_quality', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'results.limit_number_total', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'filter.include_prerelease', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Include', '1': 'Exclude'}},
# LOCAL PATCH 2026-06-15: extend filter options with '2': 'Sort to Top' for HEVC/HDR/HDR10+/DV/AV1 (port from POV 5.12)
{'setting_id': 'filter.hevc', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Include', '1': 'Exclude', '2': 'Sort to Top'}},
{'setting_id': 'filter.hevc.max_quality', 'setting_type': 'action', 'setting_default': '4K', 'settings_options': {'4K': '4K', '1080p': '1080p', '720p': '720p', 'SD': 'SD'}},
{'setting_id': 'filter.hevc.max_autoplay_quality', 'setting_type': 'action', 'setting_default': '4K', 'settings_options': {'4K': '4K', '1080p': '1080p', '720p': '720p', 'SD': 'SD'}},
{'setting_id': 'filter.3d', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Include', '1': 'Exclude'}},
{'setting_id': 'filter.hdr', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Include', '1': 'Exclude', '2': 'Sort to Top'}},
{'setting_id': 'filter.hdr10plus', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Include', '1': 'Exclude', '2': 'Sort to Top'}},
{'setting_id': 'filter.dv', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Include', '1': 'Exclude', '2': 'Sort to Top'}},
{'setting_id': 'filter.av1', 'setting_type': 'action', 'setting_default': '0', 'settings_options':{'0': 'Include', '1': 'Exclude', '2': 'Sort to Top'}},
{'setting_id': 'filter.enhanced_upscaled', 'setting_type': 'action', 'setting_default': '0', 'settings_options':{'0': 'Include', '1': 'Exclude'}},
{'setting_id': 'filter.sort_to_top', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Source Select', '2': 'Autoplay', '3': 'Both'}},
{'setting_id': 'filter.preferred_filters', 'setting_type': 'string', 'setting_default': 'empty_setting'},
# LOCAL PATCH 2026-06-20: Real Debrid filename-keyword filter. Drops sources whose raw filename contains any of the comma-separated tokens (case-insensitive substring). Ships pre-populated with RD's confirmed blocked tokens (May 2026 FNEF/DSA Article 16 keyword filter); user can edit/clear.
{'setting_id': 'filter.banned_keywords', 'setting_type': 'string', 'setting_default': 'WEB-DL,WEBDL,WEB-Rip,WEBRip,AMZN,YTS,RARBG,[rartv],[rarbg],[eztv]'},
# LOCAL PATCH 2026-07-10: comma-separated list of external scraper provider names to skip entirely (e.g. "sfx,knightcrawler"). Case-insensitive exact-name match against the provider ids in script.module.magneto's registry. Skipped providers are never invoked (no scrape thread spawned), so their per-scrape timeout budget is freed for the rest. Leave blank to run all enabled providers.
{'setting_id': 'scrape.provider_blocklist', 'setting_type': 'string', 'setting_default': ''},
# LOCAL PATCH 2026-07-10: DIAG toggle. When on, external.py logs elapsed ms per provider (start + end lines tagged with provider name + result count) so slow providers can be identified from kodi.log. Off by default; log noise otherwise.
{'setting_id': 'scrape.diag_timing', 'setting_type': 'boolean', 'setting_default': 'false'},
# LOCAL PATCH 2026-09-05: foreground early exit. Stop waiting on slow providers once this many sources are already in hand AND half the scrape budget (results.timeout) has elapsed. 0 = off (wait for every provider, the behaviour before this setting existed). THIS DISCARDS whatever the remaining providers would have returned -- a straggler may hold the best release -- so it trades completeness for speed. Measured on a 3-provider setup: comet returned 111 sources in 770ms while torrentio spent 3070ms adding 18, so a threshold of 100 saves ~1.1s of a 3.1s scrape and loses those 18. Raise it to be safer, lower it to be faster.
{'setting_id': 'scrape.early_exit_sources', 'setting_type': 'integer', 'setting_default': '0'},
{'setting_id': 'filter_audio', 'setting_type': 'string', 'setting_default': 'empty_setting'},
#==================== Results Color Highlights
{'setting_id': 'highlight.type', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Provider', '1': 'Quality', '2': 'Single Color'}},
{'setting_id': 'provider.easynews_highlight', 'setting_type': 'string', 'setting_default': 'FF00B3B2'},
{'setting_id': 'provider.debrid_cloud_highlight', 'setting_type': 'string', 'setting_default': 'FF7A01CC'},
{'setting_id': 'provider.folders_highlight', 'setting_type': 'string', 'setting_default': 'FFB36B00'},
{'setting_id': 'provider.rd_highlight', 'setting_type': 'string', 'setting_default': 'FF3C9900'},
{'setting_id': 'provider.pm_highlight', 'setting_type': 'string', 'setting_default': 'FFFF3300'},
{'setting_id': 'provider.ad_highlight', 'setting_type': 'string', 'setting_default': 'FFE6B800'},
{'setting_id': 'provider.oc_highlight', 'setting_type': 'string', 'setting_default': 'FF008EB2'},
{'setting_id': 'provider.ed_highlight', 'setting_type': 'string', 'setting_default': 'FF3233FF'},
{'setting_id': 'provider.tb_highlight', 'setting_type': 'string', 'setting_default': 'FF01662A'},
{'setting_id': 'scraper_4k_highlight', 'setting_type': 'string', 'setting_default': 'FFFF00FE'},
{'setting_id': 'scraper_1080p_highlight', 'setting_type': 'string', 'setting_default': 'FFE6B800'},
{'setting_id': 'scraper_720p_highlight', 'setting_type': 'string', 'setting_default': 'FF3C9900'},
{'setting_id': 'scraper_SD_highlight', 'setting_type': 'string', 'setting_default': 'FF0166FF'},
{'setting_id': 'scraper_single_highlight', 'setting_type': 'string', 'setting_default': 'FF008EB2'},


#===============================================================================#
#===================================PLAYBACK====================================#
#===============================================================================#
#==================== Playback Movies
{'setting_id': 'auto_play_movie', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results_quality_movie', 'setting_type': 'string', 'setting_default': 'SD, 720p, 1080p, 4K'},
{'setting_id': 'autoplay_quality_movie', 'setting_type': 'string', 'setting_default': 'SD, 720p, 1080p, 4K'},
{'setting_id': 'auto_resume_movie', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Never', '1': 'Always', '2': 'Autoplay Only'}},
{'setting_id': 'stinger_alert.show', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'stinger_alert.window_percentage', 'setting_type': 'action', 'setting_default': '90', 'min_value': '1', 'max_value': '99'},
{'setting_id': 'stinger_alert.use_chapters', 'setting_type': 'boolean', 'setting_default': 'true'},
#==================== Playback Episodes
{'setting_id': 'auto_play_episode', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'results_quality_episode', 'setting_type': 'string', 'setting_default': 'SD, 720p, 1080p, 4K'},
{'setting_id': 'autoplay_quality_episode', 'setting_type': 'string', 'setting_default': 'SD, 720p, 1080p, 4K'},
{'setting_id': 'autoplay_next_episode', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoplay_alert_method', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Window', '1': 'Notification'}},
{'setting_id': 'autoplay_default_action', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Play', '1': 'Cancel', '2': 'Pause & Wait'}},
{'setting_id': 'autoplay_next_window_percentage', 'setting_type': 'action', 'setting_default': '95', 'min_value': '75', 'max_value': '99'},
{'setting_id': 'autoplay_alert_countdown_sec', 'setting_type': 'action', 'setting_default': '10', 'min_value': '0', 'max_value': '600'},
{'setting_id': 'skipsegment.enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
# LOCAL PATCH 2026-08-27: AniSkip is an ADDITIONAL segment source for anime only,
# off by default. The two IntroDB providers already cover a lot of anime; AniSkip
# fills their per-episode gaps and is the only one that can answer past a cour
# boundary, where TMDb and IMDb disagree on season structure.
{'setting_id': 'skipsegment.aniskip', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'skipsegment.intro.mode', 'setting_type': 'string', 'setting_default': 'manual',
	'settings_options': {'off': 'Off', 'manual': 'Show Skip Button', 'auto': 'Auto-Skip'}},
{'setting_id': 'skipsegment.outro.mode', 'setting_type': 'string', 'setting_default': 'autoplay_countdown',
	'settings_options': {'off': 'Off', 'autoplay_countdown': 'Show Autoplay Countdown', 'manual': 'Show Skip Button', 'auto': 'Auto-Skip'}},
{'setting_id': 'skipsegment.recap.mode', 'setting_type': 'string', 'setting_default': 'manual',
	'settings_options': {'off': 'Off', 'manual': 'Show Skip Button', 'auto': 'Auto-Skip'}},
# LOCAL PATCH 2026-08-25: when the episode is a finale (or the next one hasn't aired
# yet) there is no autoplay hand-off, so the outro segment goes unused and the credits
# just play out. With this on, playback stops at the outro start instead.
{'setting_id': 'skipsegment.stop_at_credits_no_next', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'skipsegment.button_corner', 'setting_type': 'string', 'setting_default': 'bottom-right',
	'settings_options': {'top-left': 'Top Left', 'top-right': 'Top Right', 'bottom-left': 'Bottom Left', 'bottom-right': 'Bottom Right'}},
{'setting_id': 'autoplay_use_chapters', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'autoplay_watching_check', 'setting_type': 'action', 'setting_default': '3', 'min_value': '0', 'max_value': '5'},
{'setting_id': 'autoscrape_next_episode', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'autoscrape_next_window_percentage', 'setting_type': 'action', 'setting_default': '95', 'min_value': '75', 'max_value': '99'},
{'setting_id': 'autoscrape_use_chapters', 'setting_type': 'boolean', 'setting_default': 'true'},
{'setting_id': 'autoscrape_confirm', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'auto_resume_episode', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'Never', '1': 'Always', '2': 'Autoplay Only'}},
#==================== Playback Utilities
{'setting_id': 'playback.limit_resolve', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'easynews.playback_method', 'setting_type': 'action', 'setting_default': '0', 'settings_options': {'0': 'None', '1': 'Retry', '2': 'No Seek', '3': 'Both'}},
{'setting_id': 'easynews.playback_method_retries', 'setting_type': 'action', 'setting_default': '1', 'min_value': '1', 'max_value': '4'},
{'setting_id': 'easynews.playback_method_limited', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'playback.volumecheck_enabled', 'setting_type': 'boolean', 'setting_default': 'false'},
{'setting_id': 'playback.volumecheck_percent', 'setting_type': 'action', 'setting_default': '50', 'min_value': '1', 'max_value': '100'},


#=========================================================================================#
#======================================HIDDEN=============================================#
#=========================================================================================#
{'setting_id': 'tmdb.account_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'tmdb.session_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'tmdb.account_session_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'reuse_language_invoker', 'setting_type': 'string', 'setting_default': 'true'},
{'setting_id': 'addon_icon_choice_name', 'setting_type': 'string', 'setting_default': 'deadlight_icon_09.png'},
{'setting_id': 'widget_refresh_timer_name', 'setting_type': 'string', 'setting_default': 'Off'},
{'setting_id': 'mpaa_region_display_name', 'setting_type': 'string', 'setting_default': 'United States'},
{'setting_id': 'lists_cache_duraton_display_name', 'setting_type': 'string', 'setting_default': '1 Day'},
{'setting_id': 'results.limit_number_quality_name', 'setting_type': 'string', 'setting_default': 'Off'},
{'setting_id': 'results.limit_number_total_name', 'setting_type': 'string', 'setting_default': 'Off'},
{'setting_id': 'rpdb_format_name', 'setting_type': 'string', 'setting_default': 'Default'},
{'setting_id': 'window_theme_contrast', 'setting_type': 'string', 'setting_default': 'FF4a4347'},
{'setting_id': 'window_theme_name', 'setting_type': 'string', 'setting_default': 'Dark'},
{'setting_id': 'window_theme_opacity_name', 'setting_type': 'string', 'setting_default': '80%'},
{'setting_id': 'trakt.next_daily_clear', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'trakt.expires', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'trakt.refresh', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'trakt.token', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'tmdblist.list_sort', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'tmdblist.list_sort_name', 'setting_type': 'string', 'setting_default': 'Title'},
{'setting_id': 'personal_list.list_sort', 'setting_type': 'string', 'setting_default': '0'},
{'setting_id': 'personal_list.list_sort_name', 'setting_type': 'string', 'setting_default': 'Title'},
{'setting_id': 'rd.client_id', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'rd.refresh', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'rd.secret', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'results.sort_order', 'setting_type': 'string', 'setting_default': '1'},
{'setting_id': 'folder1.display_name', 'setting_type': 'string', 'setting_default': 'Folder 1'},
{'setting_id': 'folder1.movies_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder1.tv_shows_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder2.display_name', 'setting_type': 'string', 'setting_default': 'Folder 2'},
{'setting_id': 'folder2.movies_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder2.tv_shows_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder3.display_name', 'setting_type': 'string', 'setting_default': 'Folder 3'},
{'setting_id': 'folder3.movies_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder3.tv_shows_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder4.display_name', 'setting_type': 'string', 'setting_default': 'Folder 4'},
{'setting_id': 'folder4.movies_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder4.tv_shows_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder5.display_name', 'setting_type': 'string', 'setting_default': 'Folder 5'},
{'setting_id': 'folder5.movies_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'folder5.tv_shows_directory', 'setting_type': 'path', 'setting_default': 'None', 'browse_mode': '0'},
{'setting_id': 'extras.enabled', 'setting_type': 'string', 'setting_default': '2050,2051,2052,2053,2054,2055,2056,2057,2058,2059,2060,2061,2062,2063,2064,2065,2066'},
{'setting_id': 'extras.order', 'setting_type': 'string', 'setting_default': '2050,2051,2052,2053,2054,2055,2056,2057,2058,2059,2060,2061,2062,2063,2064,2065,2066'},
{'setting_id': 'rescrape.enabled', 'setting_type': 'string', 'setting_default': 'cache_ignored,imdb_year,with_all,episode_group,ignore_filters'},
{'setting_id': 'rescrape.order', 'setting_type': 'string', 'setting_default': 'cache_ignored,imdb_year,with_all,episode_group,ignore_filters'},
{'setting_id': 'extras.tvshow.button10', 'setting_type': 'string', 'setting_default': 'tvshow_browse'},
{'setting_id': 'extras.tvshow.button11', 'setting_type': 'string', 'setting_default': 'show_trailers'},
{'setting_id': 'extras.tvshow.button12', 'setting_type': 'string', 'setting_default': 'show_keywords'},
{'setting_id': 'extras.tvshow.button13', 'setting_type': 'string', 'setting_default': 'show_images'},
{'setting_id': 'extras.tvshow.button14', 'setting_type': 'string', 'setting_default': 'show_extrainfo'},
{'setting_id': 'extras.tvshow.button15', 'setting_type': 'string', 'setting_default': 'show_genres'},
{'setting_id': 'extras.tvshow.button16', 'setting_type': 'string', 'setting_default': 'play_nextep'},
{'setting_id': 'extras.tvshow.button17', 'setting_type': 'string', 'setting_default': 'show_options'},
{'setting_id': 'extras.movie.button10', 'setting_type': 'string', 'setting_default': 'movies_play'},
{'setting_id': 'extras.movie.button11', 'setting_type': 'string', 'setting_default': 'show_trailers'},
{'setting_id': 'extras.movie.button12', 'setting_type': 'string', 'setting_default': 'show_keywords'},
{'setting_id': 'extras.movie.button13', 'setting_type': 'string', 'setting_default': 'show_images'},
{'setting_id': 'extras.movie.button14', 'setting_type': 'string', 'setting_default': 'show_extrainfo'},
{'setting_id': 'extras.movie.button15', 'setting_type': 'string', 'setting_default': 'show_genres'},
{'setting_id': 'extras.movie.button16', 'setting_type': 'string', 'setting_default': 'show_director'},
{'setting_id': 'extras.movie.button17', 'setting_type': 'string', 'setting_default': 'show_options'},
{'setting_id': 'updatechecks.refresh_addon_keys', 'setting_type': 'string', 'setting_default': 'false'},
# LOCAL PATCH 2026-09-26: ids that were written with set_setting() but had no row here, so
# SettingsCache.set() raised TypeError and nothing was stored -- the two one-shot migration
# gates below re-ran on every boot (the second never ran at all), and EasyDebrid auth could
# not save its token. sync_settings would also have deleted the rows as obsolete.
{'setting_id': 'updatechecks.register_anilist_manager_cm', 'setting_type': 'string', 'setting_default': 'false'},
{'setting_id': 'updatechecks.register_drop_show_cm', 'setting_type': 'string', 'setting_default': 'false'},
{'setting_id': 'ed.token', 'setting_type': 'string', 'setting_default': 'empty_setting'},
{'setting_id': 'ed.enabled', 'setting_type': 'boolean', 'setting_default': 'false'}
	]
	return _default_settings_cache