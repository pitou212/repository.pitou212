# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-09: Fribb anime-lists — MAL ID → TMDb coordinates lookup
# with `episode_offset` support that the existing Goldenfreddy Otaku-Mappings DB
# lacks. Powers the "SIMKL anime-only overlay" path (see plans/robust-jumping-moon.md
# 2026-08-09 entry): SIMKL exposes anime as per-cour entries with their own MAL IDs;
# Fribb tells us the correct TMDb (show_id, season, episode_offset) so multi-cour
# anime like Slime S1-S5 all collapse onto TMDb tmdb=82684 with correct S/E.
#
# Source:
#   https://raw.githubusercontent.com/Fribb/anime-lists/master/anime-list-full.json    (~7.5 MB)
#   (collections/mal_collection.json was also fetched until 2026-09-26 -- nothing read it.)
#
# JSON row shape (anime-list-full.json):
#   {"mal_id": 41487, "anidb_id": ..., "themoviedb_id": {"tv": 82684},
#    "season": {"tvdb": 3, "tmdb": 3}, "episode_offset": {"tvdb": 12, "tmdb": 12}, ...}
#   Some rows lack `season`/`episode_offset` — treat missing as {} (no offset).
#
# In-memory index built once per PROCESS -- NOT once per Kodi session. addon.xml sets
# reuselanguageinvoker=false, so every plugin invocation (including every silent widget
# refresh) is a fresh interpreter and these globals start out None again. Full file is ~43k
# rows; ~124 ms to parse plus ~30 ms to index, ~26 MB resident. That is why callers gate
# before asking, and why _load_index is locked -- see the note there.

import os
import time
import json
import threading

from modules.kodi_utils import translate_path, addon_info, logger, notification

_MAPPINGS_URL = 'https://raw.githubusercontent.com/Fribb/anime-lists/master/anime-list-full.json'
_MAPPINGS_DIR = translate_path(addon_info('profile'))
_MAPPINGS_FILE = os.path.join(_MAPPINGS_DIR, 'fribb_anime_list_full.json')
# 2026-09-26: the MAL collections file (mal_collection.json) is no longer fetched. Its only
# reader was fribb_collection_by_mal, which nothing called; it was downloaded weekly for nothing.
# Recoverable from git (2c3186f) if franchise grouping is ever wanted.
# LOCAL PATCH 2026-09-04: slim projection of the full file -- see _write_slim below.
_SLIM_FILE = os.path.join(_MAPPINGS_DIR, 'fribb_anime_list_slim.json')
# The ONLY row fields any caller reads. Verified by grepping every .get() in this module
# plus every external consumer of a raw row; `simkl_id` is the non-obvious one --
# indexers/anilist_lists.py:240 reads it for the Simkl resolve tier, and dropping it would
# silently degrade that tier into a slower TMDb title search rather than raising.
# Upstream also ships anime-planet_id, animecountdown_id, animenewsnetwork_id, anisearch_id,
# imdb_id, livechart_id, tvdb_id and type, none of which are read anywhere.
_SLIM_FIELDS = ('mal_id', 'anilist_id', 'themoviedb_id', 'kitsu_id', 'anidb_id',
				'season', 'episode_offset', 'simkl_id')
# LOCAL PATCH 2026-09-26: 7 days, was 30. Fribb publishes roughly weekly (2026-09-15, 09-23)
# and a new cour gets its MAL/AniList/Kitsu ids within days of airing -- the ids seadex and
# animetosho key on. At 30 days the 2026-09-08 copy was still missing them for 6 airing
# shows in this library (Apothecary Diaries, Chainsmoker Cat, Ranma1/2 ...) on 09-26.
_REFRESH_SECONDS = 7 * 24 * 3600

_INDEX_BY_MAL = None      # dict: mal_id (int) -> row dict
_INDEX_BY_ANILIST = None  # dict: anilist_id (int) -> row dict
_INDEX_BY_TMDB_TV = None  # dict: tmdb_tv_id (int) -> list of row dicts (one per cour)
# LOCAL PATCH 2026-08-29: reverse movie index for the AniList backfill. themoviedb_id.movie
# is a LIST upstream (one AniDB movie entry can map to several TMDb movie ids -- see the
# note on _row_tmdb below), so every id in it points at the same row.
_INDEX_BY_TMDB_MOVIE = None  # dict: tmdb_movie_id (int) -> row dict
# LOCAL PATCH 2026-09-01: memo for the flat-season repair below, keyed (tmdb_id, season).
# [] is a cached negative -- the repair is attempted at most once per show per session.
_FLAT_PAIRS_CACHE = {}
# LOCAL PATCH 2026-09-04: memo for _season_cour_rows, keyed (tmdb_id, season). See there.
_SEASON_ROWS_CACHE = {}
# LOCAL PATCH 2026-09-12: memo for _tmdb_season_numbers, keyed tmdb_id. SUCCESSES ONLY --
# see the note there on why a failed lookup must not be remembered.
_TMDB_SEASONS_CACHE = {}
# LOCAL PATCH 2026-09-04: lock for the lazy index loader -- see _load_index. (It had a
# separate collections-loader twin until that loader was removed on 2026-09-26.)
_INDEX_LOCK = threading.Lock()


# ═══════════════════════════════════════════════════════════════════════════
#  Download / refresh — sole anime mapping source (replaced anime_mappings 2026-08-10)
# ═══════════════════════════════════════════════════════════════════════════

def _needs_download(path):
	if not os.path.exists(path): return True
	try:
		age = time.time() - os.path.getmtime(path)
		return age >= _REFRESH_SECONDS
	except Exception: return True


def download_mappings(force=False, silent=True):
	"""Fetch the Fribb full mapping file. Returns True on new-fetch success."""
	need_full = force or _needs_download(_MAPPINGS_FILE)
	if not need_full: return False
	try:
		if not os.path.isdir(_MAPPINGS_DIR):
			os.makedirs(_MAPPINGS_DIR, exist_ok=True)
		tmp = _MAPPINGS_FILE + '.tmp'
		# 60s timeout — 7.5 MB should easily fit on any reasonable link.
		# LOCAL PATCH 2026-09-26: imported here -- every TV/list page imports this module
		# and urllib.request costs ~80 ms of it; only this weekly download needs it.
		import urllib.request
		with urllib.request.urlopen(_MAPPINGS_URL, timeout=60) as resp:
			with open(tmp, 'wb') as f:
				f.write(resp.read())
		os.replace(tmp, _MAPPINGS_FILE)
		# LOCAL PATCH 2026-09-04: drop the slim projection whenever the full file is
		# replaced. It is DERIVED data, so a surviving slim file would shadow the mappings
		# we just downloaded -- silently serving month-old cour boundaries with no way to
		# tell from outside. _load_index regenerates it on the next load.
		if need_full:
			try:
				if os.path.exists(_SLIM_FILE): os.remove(_SLIM_FILE)
			except Exception as e:
				logger('fribb_mappings', 'could not remove stale slim index: %s' % e)
		clear_cache()
		size_mb = os.path.getsize(_MAPPINGS_FILE) / 1024 / 1024 if os.path.exists(_MAPPINGS_FILE) else 0
		logger('fribb_mappings', 'downloaded (%.1f MB full)' % size_mb)
		if not silent: notification('Fribb anime mappings updated', 3000)
		return True
	except Exception as e:
		logger('fribb_mappings', 'download failed: %s' % e)
		try:
			if os.path.exists(_MAPPINGS_FILE + '.tmp'): os.remove(_MAPPINGS_FILE + '.tmp')
		except Exception: pass
		return False


def clear_cache():
	# LOCAL PATCH 2026-08-31: _INDEX_BY_TMDB_MOVIE was assigned below but missing here, so
	# it bound a throwaway local and never cleared the real cache.
	global _INDEX_BY_MAL, _INDEX_BY_ANILIST, _INDEX_BY_TMDB_TV, _INDEX_BY_TMDB_MOVIE
	global _IS_AVAILABLE
	_INDEX_BY_MAL = None
	_INDEX_BY_ANILIST = None
	_INDEX_BY_TMDB_TV = None
	_INDEX_BY_TMDB_MOVIE = None
	# LOCAL PATCH 2026-09-04: reset the memoised availability too -- download_mappings calls
	# clear_cache() right after replacing the file, which is exactly when it flips.
	_IS_AVAILABLE = None
	_FLAT_PAIRS_CACHE.clear()
	_SEASON_ROWS_CACHE.clear()
	_TMDB_SEASONS_CACHE.clear()


# LOCAL PATCH 2026-09-04: memoised. This is called per ITEM by the cour-numbering gate
# (metadata.cour_display_numbers) and so was doing two stat() syscalls per episode of every
# anime list. The answer cannot change within one plugin invocation unless we download the
# file ourselves, and clear_cache() -- which download_mappings already calls -- resets it.
# LOCAL PATCH 2026-09-04: accepts EITHER file. _load_index prefers the slim projection, so
# testing only the full file here would let the gate say "no mappings" while the loader would
# happily have served them (or the reverse, after someone prunes the full file by hand).
_IS_AVAILABLE = None
def is_available():
	global _IS_AVAILABLE
	if _IS_AVAILABLE is None:
		_IS_AVAILABLE = any(os.path.exists(f) and os.path.getsize(f) > 500_000
							for f in (_SLIM_FILE, _MAPPINGS_FILE))
	return _IS_AVAILABLE


# ═══════════════════════════════════════════════════════════════════════════
#  Lazy index loaders
# ═══════════════════════════════════════════════════════════════════════════

# LOCAL PATCH 2026-09-04: double-checked lock.
#
# The `if _INDEX_BY_MAL is not None: return` guard is correct single-threaded but was a
# 10.8x PESSIMISATION under a thread pool, because the globals are only assigned after the
# whole 7.5 MB parse finishes. build_tvshow_content fans out over TaskPool (20 threads at
# paginate.limit_widgets=20), so every thread saw None, sailed past the guard, and parsed
# the file itself: measured 1202 ms wall vs 111 ms single-threaded, plus a ~20x transient
# memory spike from 20 concurrent parses. The GIL does not help -- CPython's C JSON scanner
# never releases it, so they serialise.
#
# The fast path stays lock-free: once the globals are set, readers never touch the lock.
def _load_index():
	global _INDEX_BY_MAL, _INDEX_BY_ANILIST, _INDEX_BY_TMDB_TV, _INDEX_BY_TMDB_MOVIE
	if _INDEX_BY_MAL is not None: return
	with _INDEX_LOCK:
		if _INDEX_BY_MAL is not None: return
		_load_index_locked()

# LOCAL PATCH 2026-09-04: write a slim projection of the full file.
#
# Upstream ships 16 fields per row and we read 8 (_SLIM_FIELDS). Since the index is rebuilt
# in EVERY plugin process (reuselanguageinvoker=false), the unread half was being parsed 6-10
# times per home-screen refresh for nothing. Measured on the live file:
#   full: 7.16 MB / 42868 rows -> parse 124 ms + index 30 ms
#   slim: 2.12 MB / 32630 rows -> parse  23 ms + index 18 ms   (~3.7x less work)
# Index cardinalities are identical (30561 MAL / 20687 AniList / 4259 TMDb TV / 1383 movie),
# so lookups are unaffected -- rows with no usable id are the ones dropped.
#
# Written as a side effect of the first full-file load rather than only in download_mappings,
# so existing installs get the fast path on their next widget refresh instead of waiting up
# to 30 days for the next refresh cycle. Best-effort: a read-only profile just keeps using
# the full file. tmp + os.replace so a concurrent process never reads a half-written file.
def _write_slim(data):
	try:
		slim = []
		for row in data:
			d = {k: row[k] for k in _SLIM_FIELDS if row.get(k) is not None}
			if d.get('mal_id') is None and d.get('anilist_id') is None and not d.get('themoviedb_id'):
				continue
			slim.append(d)
		tmp = _SLIM_FILE + '.tmp'
		with open(tmp, 'w', encoding='utf-8') as f:
			json.dump(slim, f, separators=(',', ':'))
		os.replace(tmp, _SLIM_FILE)
		logger('fribb_mappings', 'wrote slim index (%d of %d rows, %.2f MB)'
				% (len(slim), len(data), os.path.getsize(_SLIM_FILE) / 1024 / 1024))
	except Exception as e:
		logger('fribb_mappings', 'slim write failed (harmless, full file still used): %s' % e)
		try:
			if os.path.exists(_SLIM_FILE + '.tmp'): os.remove(_SLIM_FILE + '.tmp')
		except Exception: pass


def _load_index_locked():
	global _INDEX_BY_MAL, _INDEX_BY_ANILIST, _INDEX_BY_TMDB_TV, _INDEX_BY_TMDB_MOVIE
	# Prefer the slim projection; fall back to the full file, and generate the slim one from
	# it so only the first process after a download pays the full parse.
	source, make_slim = _SLIM_FILE, False
	if not os.path.exists(_SLIM_FILE):
		source, make_slim = _MAPPINGS_FILE, True
	if not os.path.exists(source):
		_INDEX_BY_MAL = {}
		_INDEX_BY_ANILIST = {}
		_INDEX_BY_TMDB_TV = {}
		_INDEX_BY_TMDB_MOVIE = {}
		return
	try:
		with open(source, 'r', encoding='utf-8') as f:
			data = json.load(f)
		if make_slim: _write_slim(data)
		by_mal, by_ani, by_tmdb, by_movie = {}, {}, {}, {}
		for row in data:
			mal = row.get('mal_id')
			if mal is not None:
				try: by_mal[int(mal)] = row
				except (TypeError, ValueError): pass
			# LOCAL PATCH 2026-08-10: index by anilist_id too. AniList browse results
			# always carry `id` (the AniList id) but brand-new seasonal shows often
			# have `idMal: null`, so the AniList index resolves far more of them —
			# measured 42 hits vs 1 via MAL across the three seasonal catalogs.
			ani = row.get('anilist_id')
			if ani is not None:
				try: by_ani[int(ani)] = row
				except (TypeError, ValueError): pass
			tmdb = row.get('themoviedb_id') or {}
			tv = tmdb.get('tv')
			if tv is not None:
				try: by_tmdb.setdefault(int(tv), []).append(row)
				except (TypeError, ValueError): pass
			for mv in (tmdb.get('movie') or []):
				try: by_movie.setdefault(int(mv), row)
				except (TypeError, ValueError): pass
		_INDEX_BY_MAL = by_mal
		_INDEX_BY_ANILIST = by_ani
		_INDEX_BY_TMDB_TV = by_tmdb
		_INDEX_BY_TMDB_MOVIE = by_movie
		logger('fribb_mappings', 'indexed %d MAL / %d AniList rows / %d TMDb TV shows / %d TMDb movies'
				% (len(by_mal), len(by_ani), len(by_tmdb), len(by_movie)))
	except Exception as e:
		logger('fribb_mappings', 'index load failed: %s' % e)
		_INDEX_BY_MAL = {}
		_INDEX_BY_ANILIST = {}
		_INDEX_BY_TMDB_TV = {}
		_INDEX_BY_TMDB_MOVIE = {}


# ═══════════════════════════════════════════════════════════════════════════
#  Public lookup API
# ═══════════════════════════════════════════════════════════════════════════

def mal_to_fribb(mal_id):
	"""MAL ID → full Fribb row dict or None."""
	if mal_id is None: return None
	try: mal_id = int(mal_id)
	except (TypeError, ValueError): return None
	_load_index()
	return _INDEX_BY_MAL.get(mal_id)


def anilist_to_fribb(anilist_id):
	"""AniList ID → full Fribb row dict or None."""
	if anilist_id is None: return None
	try: anilist_id = int(anilist_id)
	except (TypeError, ValueError): return None
	_load_index()
	return _INDEX_BY_ANILIST.get(anilist_id)


# LOCAL PATCH 2026-08-29: the reverse of _row_tmdb(want_movie=True), for the AniList
# backfill. Films have no cours and no episode numbering, so unlike the TV path there is
# nothing to resolve beyond the id itself -- a watched anime film is simply progress 1.
def anilist_for_tmdb_movie(tmdb_id):
	"""TMDb MOVIE id -> AniList id, or None if it is not an anime film."""
	if tmdb_id is None: return None
	try: tmdb_id = int(tmdb_id)
	except (TypeError, ValueError): return None
	_load_index()
	row = _INDEX_BY_TMDB_MOVIE.get(tmdb_id)
	if not row: return None
	try: return int(row['anilist_id'])
	except (KeyError, TypeError, ValueError): return None


# LOCAL PATCH 2026-09-23: the same reverse movie index, returning BOTH ani.zip lookup keys
# rather than AniList alone.
#
# anilist_for_tmdb_movie() above exists for the watch-state backfill, which wants one int.
# The scrape path cannot use it as-is: measured over the slim list, all 1363 movie rows
# carry anidb_id and 77 of them (5.6%) carry NO anilist_id, so an AniList-keyed lookup
# would silently drop those films. This is the same gap the 2026-08-27 anidb_id fallback
# closed for TV, and it matters more here -- querying ani.zip by anidb_id also RECOVERS
# the AniList id Fribb was missing, which is what gives seadex a key for those 77.
def query_ids_for_tmdb_movie(tmdb_id):
	"""TMDb MOVIE id -> {anilist_id, anidb_id} for an anime film, else {}.

	Either value may be absent; anidb_id is the reliable one. Both are LOOKUP KEYS for
	anizip_episode_ids, not scrape data -- a film has no cours, no offsets and no episode
	numbering to resolve beyond the single entry-local episode that IS the film."""
	if tmdb_id is None: return {}
	try: tmdb_id = int(tmdb_id)
	except (TypeError, ValueError): return {}
	_load_index()
	row = _INDEX_BY_TMDB_MOVIE.get(tmdb_id)
	if not row: return {}
	out = {}
	for _key in ('anilist_id', 'anidb_id'):
		try:
			_v = row.get(_key)
			if _v is not None: out[_key] = int(_v)
		except (TypeError, ValueError): continue
	return out


def _row_tmdb(row, want_movie=False):
	"""Extract a TMDb id (str) from a Fribb row's `themoviedb_id` field.
	Shape is inconsistent upstream by design: `.tv` is a single int, `.movie`
	is a LIST of ints (a single AniDB movie entry can map to several TMDb
	movie ids). For TV we want `.tv`; for movies take the first `.movie`
	entry and fall back to `.tv` (some ONA/OVA rows only carry `.tv`)."""
	if not row: return None
	tv = row.get('themoviedb_id')
	if isinstance(tv, dict):
		if want_movie:
			mv = tv.get('movie')
			if isinstance(mv, list) and mv:
				try: return str(int(mv[0]))
				except (TypeError, ValueError): pass
			elif mv is not None:
				try: return str(int(mv))
				except (TypeError, ValueError): pass
		t = tv.get('tv')
		if t is not None:
			try: return str(int(t))
			except (TypeError, ValueError): return None
	elif tv is not None:
		try: return str(int(tv))
		except (TypeError, ValueError): return None
	return None


def fribb_tmdb_for(anilist_id=None, mal_id=None, media_type='tvshow'):
	"""Resolve an AniList/MAL id pair to a TMDb id (str) or None.

	Tries the AniList index first — AniList browse responses always carry `id`
	but brand-new seasonal titles frequently have `idMal: null`, so the AniList
	index hits far more often. Returns the PARENT show's TMDb id for TV (Fribb's
	`themoviedb_id.tv` is the parent, with the cour's season in `season.tmdb`),
	which is exactly what catalog rendering wants."""
	want_movie = (media_type == 'movie')
	row = anilist_to_fribb(anilist_id)
	tmdb = _row_tmdb(row, want_movie)
	if tmdb: return tmdb
	row = mal_to_fribb(mal_id)
	return _row_tmdb(row, want_movie)


def tmdb_tv_to_fribb_rows(tmdb_id):
	"""TMDb TV id → list of all Fribb rows mapped to that TMDb show. Multi-cour
	shows return multiple rows (one per cour). Useful for building a full
	"which cours belong to this TMDb show?" view."""
	if tmdb_id is None: return []
	try: tmdb_id = int(tmdb_id)
	except (TypeError, ValueError): return []
	_load_index()
	return list(_INDEX_BY_TMDB_TV.get(tmdb_id, []))


# ═══════════════════════════════════════════════════════════════════════════
#  Flat-season repair (LOCAL PATCH 2026-09-01)
#
#  Fribb sometimes copies season.tvdb into season.tmdb. When TMDb has kept the
#  whole show as ONE season that copy is a lie, and it hides the cour split from
#  _season_cour_rows entirely -- the rows for cours 2..n claim TMDb seasons that
#  do not exist and are filtered out, leaving one row and "not split".
#
#  Tokyo Revengers is the worked example. TMDb 105009 is a single 50-episode
#  season; Fribb files its three cours as season.tmdb 1, 2 and 3 with no
#  episode_offset on any of them. The truth is season 1 at offsets 0, 24 and 37.
#  Contrast Frieren, which Fribb records correctly (all season.tmdb 1, offsets 0
#  and 28) and which therefore never reaches this code.
#
#  The tell is structural and free to test: several rows, one per DISTINCT season
#  number, none carrying an offset. Only when that holds do we go looking for the
#  real boundaries -- first in a TMDb episode group, then in AniList episode counts.
# ═══════════════════════════════════════════════════════════════════════════

def _flat_candidate_rows(tmdb_id):
	"""[(season_number, row), ...] sorted by season for a show of the shape above, else [].

	Index-only, no network -- this is the guard that keeps the repair off the hot path
	for every normally-mapped show."""
	rows = tmdb_tv_to_fribb_rows(tmdb_id)
	if len(rows) < 2: return []
	numbered = []
	for r in rows:
		s = (r.get('season') or {}).get('tmdb')
		if s is None: return []
		try: s = int(s)
		except (TypeError, ValueError): return []
		# Any recorded offset means Fribb already describes the split properly and the
		# normal same-season path is the truth. Never second-guess it.
		if (r.get('episode_offset') or {}).get('tmdb'): return []
		numbered.append((s, r))
	# Exactly one row per season number, and at least one season past the first --
	# the signature of season.tmdb having been copied from season.tvdb.
	if len(set(s for s, _r in numbered)) != len(numbered): return []
	if max(s for s, _r in numbered) < 2: return []
	numbered.sort(key=lambda t: t[0])
	return numbered


def _episode_group_boundaries(tmdb_id, season, expected):
	"""Offsets for `expected` cours read off a TMDb episode group, or [].

	A group is accepted only when its subgroups that fall inside TMDb season `season`
	number exactly `expected` AND together tile that season from episode 1 with no gap
	and no overlap. That tiling test is what SELECTS the right group, so no group
	`type` is hardcoded. On Tokyo Revengers it accepts 'Seasons' (subgroups covering
	E1-24, E25-37, E38-50 once the 24 specials are dropped for being season 0) and
	rejects both 'Story Arcs' (37 of the 50 episodes -- a gap) and 'Japanese Blu-ray /
	DVD' (12 subgroups against 3 rows).
	"""
	try:
		from apis.tmdb_api import episode_groups_data, episode_group_details
	except Exception: return []
	try: results = (episode_groups_data(tmdb_id) or {}).get('results') or []
	except Exception: return []
	if not isinstance(results, list): return []
	# Try the closest subgroup counts first -- `expected`, or expected+1 when the group
	# carries a Specials subgroup -- so the usual case costs one details call.
	def _distance(g):
		try: return abs(int(g.get('group_count') or 0) - expected)
		except (TypeError, ValueError): return 9999
	for g in sorted([g for g in results if isinstance(g, dict)], key=_distance):
		if _distance(g) > 4: break
		gid = g.get('id')
		if not gid: continue
		try: detail = episode_group_details(gid) or {}
		except Exception: continue
		if not isinstance(detail, dict): continue
		spans = []
		for sub in (detail.get('groups') or []):
			episodes = sub.get('episodes') or []
			nums = []
			for e in episodes:
				try:
					if int(e.get('season_number')) != season: continue
					nums.append(int(e.get('episode_number')))
				except (TypeError, ValueError): continue
			if not nums: continue
			# A subgroup only PARTLY inside this season is not a clean cour boundary;
			# reject the whole group rather than guess at the remainder.
			if len(nums) != len(episodes):
				spans = None
				break
			try: order = int(sub.get('order'))
			except (TypeError, ValueError): order = len(spans)
			spans.append((order, sorted(nums)))
		if not spans or len(spans) != expected: continue
		spans.sort(key=lambda t: t[0])
		flat = [n for _o, nums in spans for n in nums]
		# Contiguous from 1 with no gap and no repeat -- the tiling test.
		if flat != list(range(1, len(flat) + 1)): continue
		offsets, running = [], 0
		for _o, nums in spans:
			offsets.append(running)
			running += len(nums)
		return offsets
	return []


def _anilist_boundaries(numbered):
	"""Offsets derived from each cour's AniList episode count, or [].

	Only the cours BEFORE the last need a count -- the last one simply runs to the end
	of the season -- which matters because a currently-airing cour reports
	`episodes: null` and that is nearly always the last one.
	"""
	try:
		from apis.anilist_api import anilist_episode_counts
	except Exception: return []
	try: counts = anilist_episode_counts([r.get('mal_id') for _s, r in numbered]) or {}
	except Exception: return []
	offsets, running = [0], 0
	for _s, r in numbered[:-1]:
		try: n = int(counts.get(int(r.get('mal_id')), 0))
		except (TypeError, ValueError): return []
		# An unknown or zero-length earlier cour makes every later offset wrong, so
		# abandon the whole repair rather than emit a partly-guessed split.
		if n <= 0: return []
		running += n
		offsets.append(running)
	return offsets


def _tmdb_season_numbers(tmdb_id):
	"""Season numbers TMDb actually has for this show, or None when unknown.

	LOCAL PATCH 2026-09-12. Successes only are memoised: a failed lookup must not be
	cached, or one network blip decides the question for the rest of the session."""
	if tmdb_id in _TMDB_SEASONS_CACHE: return set(_TMDB_SEASONS_CACHE[tmdb_id])
	try:
		from apis.tmdb_api import tvshow_seasons_light
		seasons = (tvshow_seasons_light(tmdb_id) or {}).get('seasons')
		if not seasons: return None
		out = set()
		for s in seasons:
			n = (s or {}).get('season_number')
			if n is None: continue
			try: out.add(int(n))
			except (TypeError, ValueError): continue
		if not out: return None
		_TMDB_SEASONS_CACHE[tmdb_id] = out
		return set(out)
	except Exception: return None


def _repair_is_bogus(tmdb_id, named_seasons):
	"""True when the flat-season repair must NOT run for this show.

	LOCAL PATCH 2026-09-12. _flat_candidate_rows matches on the SHAPE of Fribb's rows
	-- one per season number, none carrying an episode offset -- which it reads as
	"season.tmdb was copied from season.tvdb". But a show that genuinely has those
	seasons has exactly the same shape, so the filter cannot tell the two apart. The
	repair exists for shows whose cours Fribb scattered across seasons TMDb DOES NOT
	HAVE (BLUE LOCK, Dan Da Dan, Hell's Paradise, MASHLE: Fribb names [1,2] or
	[1,2,3], TMDb has [1]). Ask TMDb directly instead of inferring.

	Left unguarded it does real damage, not just a bad label. Blue Box has two real
	seasons; the repair paired TMDb S1's episodes 13-25 with the Fribb row for
	Blue Box SEASON 2, so that row took Season 2's AniList id (189123), its poster and
	its title -- and Mark Watched would have scrobbled a season that has not aired.
	Measured over the 855 cached shows on 2026-09-12: 37 shows matched the shape while
	TMDb had every season Fribb named, against 11 genuine flat shows.

	Unknown answer means DO NOT repair. The repair is display/sync only (the scrape
	path passes allow_repair=False), so the cost of skipping it is a plainer label,
	while the cost of running it wrongly is bad data pushed to AniList."""
	have = _tmdb_season_numbers(tmdb_id)
	if have is None: return True
	return set(named_seasons) <= have


def _flattened_cour_pairs(tmdb_id, season):
	"""[(offset, row), ...] recovered for a flattened season, or []. Memoised per session."""
	try: tmdb_id, season = int(tmdb_id), int(season)
	except (TypeError, ValueError): return []
	key = (tmdb_id, season)
	if key in _FLAT_PAIRS_CACHE: return list(_FLAT_PAIRS_CACHE[key])
	pairs = []
	numbered = _flat_candidate_rows(tmdb_id)
	# LOCAL PATCH 2026-09-12: the index-only filter above is a cheap PRE-filter; this is
	# the authoritative test. Runs only for shows that already matched the shape, and is
	# cached both here and for 168h in tmdb_api, so it stays off the hot path.
	if numbered and _repair_is_bogus(tmdb_id, [s for s, _r in numbered]):
		logger('fribb_mappings', 'tmdb %s s%s: not flattened -- TMDb has every season Fribb names; no repair'
				% (tmdb_id, season))
		numbered = []
	# The flattened season is the one TMDb kept, which is the lowest number Fribb
	# knows. Without this a caller asking for the phantom season 2 would be handed
	# season 1's split.
	if numbered and season == numbered[0][0]:
		source = 'episode group'
		offsets = _episode_group_boundaries(tmdb_id, season, len(numbered))
		if not offsets:
			source = 'anilist'
			offsets = _anilist_boundaries(numbered)
		if len(offsets) == len(numbered) and offsets[0] == 0 and offsets == sorted(set(offsets)):
			pairs = [(off, row) for off, (_s, row) in zip(offsets, numbered)]
			logger('fribb_mappings', 'tmdb %s s%s: flat-season repair via %s, offsets %s'
					% (tmdb_id, season, source, offsets))
		else:
			logger('fribb_mappings', 'tmdb %s s%s: %d mislabelled rows but no usable boundaries'
					% (tmdb_id, season, len(numbered)))
	_FLAT_PAIRS_CACHE[key] = pairs
	return list(pairs)


def _repaired_coords_for_row(tmdb_id, row):
	"""(season, offset) the flat-season repair assigns to `row`, or None.

	Identity comparison is deliberate: both sides come out of the same index, so
	`is` avoids having to decide what equality means for two Fribb rows."""
	numbered = _flat_candidate_rows(tmdb_id)
	if not numbered: return None
	season = numbered[0][0]
	for off, r in _flattened_cour_pairs(tmdb_id, season):
		if r is row: return (season, off)
	return None


def _season_cour_rows(tmdb_id, season, allow_repair=True):
	"""[(episode_offset, row), ...] for one TMDb season, sorted by offset.

	Shared by find_cour_by_tmdb_coords() and cours_for_tmdb_season() so the
	same-season filter and the offset ordering are defined in exactly one place.
	A row with no episode_offset is the season's first cour, i.e. offset 0.

	allow_repair=False returns Fribb's RAW rows, skipping the flat-season repair below.
	The scrape path passes False -- see the note on that branch in the uncached body.
	"""
	# LOCAL PATCH 2026-09-04: memoised per (tmdb_id, season). find_cour_by_tmdb_coords calls
	# this once per EPISODE, but only its `episode` argument varies -- so a 25-episode anime
	# season redid the same list() copy of the row list, the same filter loop and the same
	# sort 25 times for an identical answer. Same memo shape as _FLAT_PAIRS_CACHE below, and
	# cleared by clear_cache() along with everything else.
	#
	# LOCAL PATCH 2026-09-05: allow_repair IS PART OF THE KEY. It changes the answer, so
	# leaving it out would let whichever caller ran first in a process serve its result to
	# the other -- and that genuinely happens: modules/sources.py picks files out of a pack
	# (repair off) in the same process that renders results (repair on).
	try: season = int(season)
	except (TypeError, ValueError): return []
	memo_key = (tmdb_id, season, bool(allow_repair))
	if memo_key in _SEASON_ROWS_CACHE: return list(_SEASON_ROWS_CACHE[memo_key])
	result = _season_cour_rows_uncached(tmdb_id, season, allow_repair)
	_SEASON_ROWS_CACHE[memo_key] = result
	return list(result)


def _season_cour_rows_uncached(tmdb_id, season, allow_repair=True):
	rows = tmdb_tv_to_fribb_rows(tmdb_id)
	if not rows: return []
	out = []
	for r in rows:
		s = (r.get('season') or {}).get('tmdb')
		if s is None: continue
		try:
			if int(s) != season: continue
		except (TypeError, ValueError): continue
		off = (r.get('episode_offset') or {}).get('tmdb') or 0
		try: off = int(off)
		except (TypeError, ValueError): off = 0
		out.append((off, r))
	out.sort(key=lambda t: t[0])
	# LOCAL PATCH 2026-09-01: fewer than two rows can mean the season genuinely is not
	# split, or that Fribb scattered its cours across TMDb seasons that do not exist.
	# _flattened_cour_pairs tells the two apart and costs nothing for the former.
	#
	# LOCAL PATCH 2026-09-05: DISPLAY ONLY -- the scrape path passes allow_repair=False.
	# The repair recovers real cour boundaries from a TMDb episode group, which is right for
	# labelling an episode list but wrong for finding a release: it turns a TMDb episode
	# number into a cour-relative one plus a cour_season, and the groups releasing these
	# shows do not use that numbering. Hell's Paradise, BLUE LOCK, MASHLE, Dan Da Dan and
	# Solo Leveling are all one flat TMDb season here, so scraping ep 20 of Solo Leveling
	# was asking providers for S2E8. Scrapers now get Fribb's raw coordinates, which for a
	# flat show means TMDb's own numbers; the episode list keeps its cour split.
	if allow_repair and len(out) < 2:
		repaired = _flattened_cour_pairs(tmdb_id, season)
		if len(repaired) > 1: return repaired
	return out


def cours_for_tmdb_season(tmdb_id, season, season_episode_count):
	"""Cours making up one TMDb season, or [] when it is not split.

	LOCAL PATCH 2026-08-27. TMDb groups anime by its own season layout, which is
	often not how the show aired. Frieren is one TMDb season of 38 episodes but
	two cours of 28 and 10, so TMDb episode 30 is really cour 2 episode 2. Fribb
	already records the boundaries offline, so no extra service is needed.

	Each entry: {'index', 'offset', 'length', 'mal', 'kitsu', 'anilist'}, where
	`offset` is how many episodes of the TMDb season precede this cour, so the
	cour covers TMDb episodes offset+1 .. offset+length and its own numbering is
	tmdb_episode - offset.

	Returns [] for a single cour so unsplit seasons keep today's code path.
	"""
	try: season_episode_count = int(season_episode_count)
	except (TypeError, ValueError): return []
	if season_episode_count < 2: return []
	pairs = _season_cour_rows(tmdb_id, season)
	if len(pairs) < 2: return []
	# Drop offsets at or past the end of the season. Fribb lists a cour as soon as
	# it is announced, so an unaired one shows up with an offset equal to the
	# current episode count (Frieren has a third row at offset 38 of 38) and would
	# otherwise produce a zero-length cour.
	pairs = [(off, r) for off, r in pairs if 0 <= off < season_episode_count]
	if len(pairs) < 2: return []
	cours = []
	for i, (off, row) in enumerate(pairs):
		nxt = pairs[i + 1][0] if i + 1 < len(pairs) else season_episode_count
		length = nxt - off
		if length <= 0: continue
		cours.append({
			'index': len(cours) + 1,
			'offset': off,
			'length': length,
			'mal': row.get('mal_id'),
			'kitsu': row.get('kitsu_id'),
			'anilist': row.get('anilist_id'),
		})
	# One usable cour means the season is not actually split.
	return cours if len(cours) > 1 else []


def find_cour_by_tmdb_coords(tmdb_id, season, episode, allow_repair=True):
	"""Given TMDb (show, season, ep) coords, find which anime cour that episode
	belongs to. Returns {mal, kitsu, anilist, cour_ep, mal_title, row} or None.

	allow_repair=False skips the flat-season repair, so the answer comes only from
	coordinates Fribb actually records. The SCRAPE path passes False -- see the note on
	the repair branch in _season_cour_rows_uncached. Everything that labels or syncs an
	episode (episode/season lists, Continue Watching covers, AniList push, IntroDB) keeps
	the default and is unaffected.

	Uses episode_offset math: for each Fribb row matching tmdb+season, the
	row 'contains' episodes (offset, offset+cour_length]. We find the row
	whose offset is <= target_ep AND the NEXT row's offset (same season)
	is > target_ep (or this is the last row for the season).

	`cour_ep` is the episode number RELATIVE TO THAT COUR — used by torrentio
	API path `stream/series/kitsu:<kitsu>:<cour_ep>.json`.

	Example — Slime tmdb=82684 S2 E13:
	  Rows for S2: [{mal 39551, offset 0}, {mal 41487, offset 12}]
	  Sort by offset. E13 > 12, no next row → belongs to mal 41487.
	  cour_ep = 13 - 12 = 1.
	  Returns {mal: 41487, kitsu: 43361, cour_ep: 1, ...}"""
	if tmdb_id is None or season is None or episode is None: return None
	try:
		tmdb_id, season, episode = int(tmdb_id), int(season), int(episode)
	except (TypeError, ValueError): return None
	same_season = _season_cour_rows(tmdb_id, season, allow_repair)
	if not same_season: return None
	# Find the row whose (offset, next_offset) window contains episode.
	# Episode is 1-indexed. Row at offset O covers eps [O+1, next_O] inclusive.
	# For the last row, upper bound is infinity.
	chosen = None
	chosen_index = 0
	for i, (off, r) in enumerate(same_season):
		next_off = same_season[i + 1][0] if i + 1 < len(same_season) else float('inf')
		if off < episode <= next_off:
			chosen, chosen_index = (off, r), i; break
	if not chosen:
		# Episode below first offset — shouldn't happen for legit inputs; fall back to first row.
		chosen, chosen_index = same_season[0], 0
	off, row = chosen
	# LOCAL PATCH 2026-08-27: `cour_season` is the season number RELEASES use, which
	# is season.tvdb, not season.tmdb. TMDb regularly files several cours under one
	# season while tvdb numbers them the way fansub groups do:
	#   Re:ZERO  season.tmdb = 1 for every cour;  season.tvdb = 1, 2, 2, 3, 4
	#   Frieren  season.tmdb = 1 for every cour;  season.tvdb = 1, 2, 3
	# Scrapers need the tvdb one to read (and to trust) an "S02"/"2nd Season" marker
	# in a release name. Falls back to the tmdb season when tvdb is absent.
	season_info = row.get('season') or {}
	cour_season = season_info.get('tvdb')
	if cour_season is None: cour_season = season_info.get('tmdb')
	try: cour_season = int(cour_season)
	except (TypeError, ValueError): cour_season = None
	# LOCAL PATCH 2026-08-27: a tvdb season can span SEVERAL Fribb cours, and when
	# it does the releases keep counting across them rather than restarting at 1 for
	# each cour. Re:ZERO season 2 is two cours (offsets 26 and 38); TMDb episode 50
	# is cour_ep 12 but every group calls it '2nd Season - 24'. So `season_ep` counts
	# from the FIRST cour of this tvdb season, and that is the number to match
	# release names against. Where a season is a single cour (Frieren) they are equal.
	season_ep = None
	if cour_season is not None:
		starts = []
		for _o, _r in same_season:
			_si = _r.get('season') or {}
			_ts = _si.get('tvdb')
			if _ts is None: _ts = _si.get('tmdb')
			try: _ts = int(_ts)
			except (TypeError, ValueError): continue
			if _ts == cour_season: starts.append(_o)
		if starts: season_ep = episode - min(starts)
	# Which cour of this tvdb season we are in, and how many there are. A batch
	# labelled 'Part 1' cannot hold an episode from Part 2, and that is otherwise
	# invisible: batches carry no episode numbers, so they pass every other check.
	# Only meaningful when the season really is split, hence the count.
	cour_part = cour_part_count = None
	if cour_season is not None and starts:
		ordered = sorted(set(starts))
		cour_part_count = len(ordered)
		if off in ordered: cour_part = ordered.index(off) + 1
	return {
		'mal': row.get('mal_id'),
		'kitsu': row.get('kitsu_id'),
		'anilist': row.get('anilist_id'),
		'anidb': row.get('anidb_id'),
		'cour_ep': episode - off,
		'season_ep': season_ep,
		'cour_part': cour_part,
		'cour_part_count': cour_part_count,
		'cour_season': cour_season,
		'cour_index': chosen_index + 1,
		'row': row,
	}
