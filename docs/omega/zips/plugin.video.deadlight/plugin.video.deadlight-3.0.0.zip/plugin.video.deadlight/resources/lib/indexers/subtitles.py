# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-30: automatic subtitle download, ported from plugin.video.pov
# (resources/lib/indexers/subtitles.py).
#
# Not a scraper in the usual sense -- it is a Stremio addon client, the same shape as the
# aiostreams and Sootio providers:
#
#     GET <manifest-base>/subtitles/movie/tt0120737
#     GET <manifest-base>/subtitles/series/tt14688458:3:5
#
# Kodi can already fetch subtitles through service.subtitles.*, but only when the user opens
# the subtitle dialog and picks one. The point of this is that it happens on its own, a
# couple of seconds into playback, with no interaction.
#
# Differences from the POV original, both deliberate:
#
#   1. No fallback to an arbitrary language. POV takes the first non-toolbox subtitle when
#      the preferred language is missing. Measured against opensubtitles-v3, LOTR Fellowship
#      returns 9 subtitles in Czech, Brazilian Portuguese and Spanish and NO English -- so
#      that fallback would silently attach Czech. Subtitles you cannot read are worse than
#      none, so a miss leaves them off.
#   2. Language codes come from the table below rather than modules.meta_lists.languages(),
#      which only carries 2-letter ids ('en'). These addons answer with 3-letter codes
#      ('eng'), so the existing list would never match.
import re
import requests
from modules import kodi_utils
# DeadLight keeps get_setting in the settings cache, not kodi_utils -- that is a POV-ism.
from caches.settings_cache import get_setting
# LOCAL PATCH 2026-09-01: release-name parsing moved to source_utils so the SmartPlay
# sticky matcher can share it. Same functions, same behaviour -- only the home changed.
from modules.source_utils import release_norm as _norm, release_group as _group_of, release_source as _source_of
TIMEOUT = 20.0

# 3-letter codes as returned by the subtitle addons, keyed by the name shown in settings.
# Same mapping POV uses; its meta_languages['long'] is this value.
SUB_LANGUAGES = {
	'Arabic': 'ara', 'Bengali': 'ben', 'Bulgarian': 'bul', 'Chinese': 'chi', 'Croatian': 'hrv',
	'Czech': 'cze', 'Danish': 'dan', 'Dutch': 'dut', 'English': 'eng', 'Finnish': 'fin',
	'French': 'fre', 'German': 'ger', 'Greek': 'ell', 'Hebrew': 'heb', 'Hindi': 'hin',
	'Hungarian': 'hun', 'Indonesian': 'ind', 'Italian': 'ita', 'Japanese': 'jpn',
	'Korean': 'kor', 'Norwegian': 'nor', 'Persian': 'per', 'Polish': 'pol',
	'Portuguese': 'por', 'Portuguese (Brazil)': 'pob', 'Romanian': 'rum', 'Russian': 'rus',
	'Serbian': 'srp', 'Slovenian': 'slv', 'Spanish': 'spa', 'Swedish': 'swe', 'Tamil': 'tam',
	'Telugu': 'tel', 'Thai': 'tha', 'Turkish': 'tur', 'Ukrainian': 'ukr', 'Vietnamese': 'vie',
}

# LOCAL PATCH 2026-08-31: real ISO-639-1 codes. _wanted_tokens used self.language[:2] to
# guess the 2-letter code Kodi reports for an embedded track, which is right for 'eng'->'en'
# but wrong for several others -- 'ger'->'ge' (should be de), 'dut'->'du' (nl), 'chi'->'ch'
# (zh), 'per'->'pe' (fa). Those users failed to detect a subtitle already in the file and
# re-downloaded one every playback, defeating _video_file_subs().
SUB_LANG_ISO1 = {
	'ara': 'ar', 'ben': 'bn', 'bul': 'bg', 'chi': 'zh', 'hrv': 'hr', 'cze': 'cs', 'dan': 'da',
	'dut': 'nl', 'eng': 'en', 'fin': 'fi', 'fre': 'fr', 'ger': 'de', 'ell': 'el', 'heb': 'he',
	'hin': 'hi', 'hun': 'hu', 'ind': 'id', 'ita': 'it', 'jpn': 'ja', 'kor': 'ko', 'nor': 'no',
	'per': 'fa', 'pol': 'pl', 'por': 'pt', 'pob': 'pt', 'rum': 'ro', 'rus': 'ru', 'srp': 'sr',
	'slv': 'sl', 'spa': 'es', 'swe': 'sv', 'tam': 'ta', 'tel': 'te', 'tha': 'th', 'tur': 'tr',
	'ukr': 'uk', 'vie': 'vi',
}

DEFAULT_MANIFEST = 'https://opensubtitles-v3.strem.io'

# How far down the ranking to walk when downloads fail. Small on purpose: past a few
# places the release no longer resembles what is playing, and attaching a subtitle cut
# for something else is worse than attaching none.
DOWNLOAD_ATTEMPTS = 4

# LOCAL PATCH 2026-08-31: choose the subtitle by RELEASE, not by whatever the API listed first.
#
# The search is keyed on imdb id + season/episode alone -- nothing about the file actually
# playing goes into the request -- so the addon answers with subtitles for every release of
# that episode. The old pick was `next(i for i in subs if i['lang'] == wanted)`, i.e. first
# in the response, which is how a CAKES subtitle lands on a FLUX rip and sits a few seconds
# out for the entire runtime. Verified against the live addon: Silo S03E05 returns CAKES
# first, then FLUX.
#
# The response already carries what is needed to do better, though the FIELD NAME varies by
# addon: strem.io ships movieReleaseName / subtitleFileName / releaseGroup, opensubtitles PRO
# ships only 'title', SubSense ships releaseName / fileName, and subdl ships only id/lang/url
# with the name in 'id'. Verified live against all four. sources.py:1035 already records the
# played release as player.playing_filename, so no new plumbing is needed.
#
# Everything scored below is derived from that release name. Deliberately NOT scored:
#
#   * resolution -- 720p and 1080p from one group share timings, so it never told us
#     anything the group and source terms had not already said.
#   * fpsMilli -- the framerate gate was removed with it. It was the only signal for
#     PROGRESSIVE drift (25fps subs on 23.976 video run 4.27% fast), but neither PRO nor
#     subdl reports the field at all, so on those addons the gate was already inert. If PAL
#     drift reappears, that is the thing to restore -- see git history for the tested version.
#
# Weights reflect what actually shifts the timeline:
#
#     release group   100   implies both source and cut; the single strongest signal
#     source family    40   WEB vs BluRay vs HDTV move intros, recaps and ad breaks
#     wrong source    -10   mild, since a WEB sub often still fits a BluRay encode
#     edition         +/-   extended vs theatrical is catastrophic, not merely wrong
#

EDITION_TAGS = ('extended', 'theatrical', 'uncut', 'unrated', 'remastered', 'directors')








def _edition_of(norm_text):
	for tag in EDITION_TAGS:
		if ' %s ' % tag in norm_text: return tag
	return ''


# Characters Windows rejects in a file name, plus the path separator. Built with chr(92)
# rather than written literally so the value survives any shell layer this file is edited
# through -- an escaped backslash in a heredoc silently became a real newline once already.
_BAD_FILENAME_CHARS = frozenset('<>:"/|?*' + chr(92))


def _release_of(sub):
	"""The candidate's release name. The FIELD carrying it varies by addon.

	strem.io ships movieReleaseName / subtitleFileName, opensubtitles PRO ships 'title',
	SubSense ships releaseName / fileName (some with a leading space), and subdl ships only
	id/lang/url -- putting the name in 'id' with an index appended
	('Reacher.S01.1080p.AMZN.WEBRip.DDP5.1.x264-NTb_2'). That suffix has to go, or _group_of
	returns 'ntb_2' and the group term -- the strongest signal by far -- can never match.
	Stripped ONLY on the id path, so a real name ending in _<n> elsewhere is left alone.
	"""
	release = (sub.get('movieReleaseName') or sub.get('subtitleFileName')
		or sub.get('releaseName') or sub.get('fileName') or sub.get('title') or '')
	if not release: release = re.sub(r'_[0-9]+$', '', sub.get('id') or '')
	return release.strip()


def _subtitle_filename(sub):
	"""Save name for a downloaded subtitle: the subtitle's OWN release name.

	Kodi shows this in the subtitle track list, so the file itself records which release it
	was cut for. Sanitised by filtering rather than by regex -- no backslash literals to be
	mangled -- and capped so a 150-character release name cannot push the path past
	MAX_PATH. Windows also rejects a trailing dot or space, hence the strip.
	"""
	name = _release_of(sub)
	for ext in ('.srt', '.vtt', '.ass', '.ssa', '.sub'):
		if name.lower().endswith(ext):
			name = name[:-len(ext)]
			break
	name = ''.join(' ' if (c in _BAD_FILENAME_CHARS or ord(c) < 32) else c for c in name)
	name = ' '.join(name.split()).strip(' .')
	return '%s.srt' % (name[:120].strip(' .') or 'subtitle')


def _score_release(sub, played_norm, played_group, played_source, played_edition):
	release = _release_of(sub)
	cand_norm = _norm(release)
	score = 0
	group = (sub.get('releaseGroup') or _group_of(release) or '').lower()
	if played_group and group and group == played_group: score += 100
	cand_source = _source_of(cand_norm)
	if played_source and cand_source:
		score += 40 if cand_source == played_source else -10
	cand_edition = _edition_of(cand_norm)
	if played_edition == cand_edition:
		if played_edition: score += 30
	else: score -= 60
	return score


def _get(url, params=None, stream=False, retry=False):
	response = requests.get(url, params=params, stream=stream, timeout=TIMEOUT)
	# These addons rate-limit; one backoff and retry, as POV does.
	if retry and response.status_code in (429,):
		kodi_utils.logger('subtitles', 'rate limited, retrying')
		kodi_utils.sleep(10000)
		return _get(url, params=params, stream=stream)
	return response


def subtitles_search(url):
	try: response = _get(url, retry=True)
	except requests.RequestException as e: return str(e)
	if not response.ok: return response.reason
	try: return response.json().get('subtitles') or []
	except Exception as e: return str(e)


def subtitles_download(url):
	try: response = _get(url, stream=True, retry=True)
	except requests.RequestException as e: return str(e)
	return response if response.ok else response.reason


class SubtitleScraper:
	def __init__(self, player_object, poster=''):
		self.player = player_object
		self.poster = poster
		self.match_note = ''

	def _wanted(self, name):
		"""Does this stream name denote the wanted language?

		Kodi reports subtitle streams inconsistently -- 'eng', 'en', 'English', sometimes
		with a track title appended -- so compare against every spelling we know rather
		than the 3-letter code alone.
		"""
		n = (name or '').strip().lower()
		if not n: return False
		return n in self._wanted_tokens or n.startswith(self.language_name.lower())

	def _video_file_subs(self):
		"""The file already carries the wanted language -- nothing to fetch.

		LOCAL PATCH 2026-08-30: checks what the file CONTAINS, not what is currently
		selected. POV compares getSubtitles(), which returns the active stream, so an MKV
		carrying English subs that Kodi had not auto-selected still triggered a download on
		top of them. Direct MKVs from these providers very often ship subtitle tracks, and
		Kodi only auto-selects one when the user's language preferences say to.
		"""
		try: streams = self.player.getAvailableSubtitleStreams() or []
		except Exception: streams = []
		for index, name in enumerate(streams):
			if not self._wanted(name): continue
			try: self.player.setSubtitleStream(index)
			except Exception: pass
			if self.auto_enable: self.player.showSubtitles(True)
			return True
		# Nothing matched by name, but the active stream may still be the right language
		# on a file that reports no usable stream names at all.
		try: active = self.player.getSubtitles()
		except Exception: active = ''
		if not self._wanted(active): return False
		if self.auto_enable: self.player.showSubtitles(True)
		return True

	def _downloaded_subs(self):
		"""Reuse a subtitle downloaded on an earlier watch of this same episode.

		The cached file names ARE release names now, so picking between them is the same
		problem as picking between search candidates -- run the same scorer over the local
		names rather than inventing a second rule. Only a POSITIVE score is reused: at or
		below zero the releases could not be told apart, and searching again may turn up a
		better one than blindly re-attaching whatever happens to be on disk.
		"""
		try: files = [f for f in kodi_utils.list_dirs(self.subtitle_path)[1] if f.lower().endswith('.srt')]
		except Exception: return False
		if not files: return False
		played, _played_src = self._played_name()
		if not played: return False
		played_norm = _norm(played)
		args = (played_norm, _group_of(played), _source_of(played_norm), _edition_of(played_norm))
		best, best_score = None, 0
		for f in files:
			score = _score_release({'movieReleaseName': f[:-4]}, *args)
			if score > best_score: best, best_score = f, score
		if not best: return False
		self.player.setSubtitles('%s%s' % (self.subtitle_path, best))
		if self.auto_enable: self.player.showSubtitles(True)
		kodi_utils.logger('subtitles', 'reused cached %s (score %s)' % (best, best_score))
		return True

	def _searched_subs(self):
		subs = subtitles_search('%s/%s' % (self.manifest, self.path))
		if isinstance(subs, str): return kodi_utils.logger('subtitles', 'search error: %s' % subs)
		if not subs: return kodi_utils.logger('subtitles', 'no subtitles found')
		# Preferred language only. See the note at the top of this file: falling back to
		# whatever is available attaches a language the user cannot read.
		candidates = [i for i in subs if i.get('lang') == self.language]
		if not candidates:
			return kodi_utils.logger('subtitles', 'no %s subtitles found' % self.language_name)
		# LOCAL PATCH 2026-09-01: walk DOWN the ranking rather than giving up on the first
		# failure. A ranked release that cannot be fetched is worth no more than one that was
		# never offered, and the alternative here is no subtitle at all.
		chosen, response = None, None
		for attempt, candidate in enumerate(self._ranked_releases(candidates)[:DOWNLOAD_ATTEMPTS], 1):
			result = subtitles_download(candidate.get('url'))
			if not isinstance(result, str):
				chosen, response = candidate, result
				break
			kodi_utils.logger('subtitles', 'download %s/%s failed (%s): %s' % (
				attempt, DOWNLOAD_ATTEMPTS, result, _release_of(candidate)[:70]))
		if chosen is None:
			return kodi_utils.logger('subtitles', 'every candidate failed to download')
		self.match_note = self._match_note(chosen)
		# Named after the subtitle we chose, not after the episode: the file then says which
		# release it was cut for, and Kodi shows that in the subtitle track list.
		final_path = '%s%s' % (self.subtitle_path, _subtitle_filename(chosen))
		try: content = response.text
		except Exception: content = response.content
		try:
			with kodi_utils.open_file(final_path, 'w') as f: f.write(content)
		except Exception as e:
			return kodi_utils.logger('subtitles', 'write error: %s' % e)
		kodi_utils.sleep(1000)
		self.player.setSubtitles(final_path)
		if self.auto_enable: self.player.showSubtitles(True)
		kodi_utils.notification('Subtitles downloaded%s' % self.match_note, icon=self.poster)
		return True

	def _played_name(self):
		"""The release name to match subtitles against.

		For pack playback player.playing_filename is the PACK -- 'Reply.1988.(2015).
		Complete.2160p.UHDTV...-HThoreau' -- not the episode, so the packager's group can
		never match the per-episode subtitle groups and scoring collapses to the resolution
		tie-break. source_utils.pick_episode_files publishes the file it actually chose out
		of the pack; prefer that when it is there.

		It is re-verified rather than trusted: the property is cleared at both resolution
		entry points, but a single-file playback that never resolves a pack could still see
		a leftover, so it only counts if it really names THIS episode.
		"""
		played = getattr(self.player, 'playing_filename', '') or ''
		if getattr(self.player, 'media_type', '') != 'episode': return played, 'player'
		try: pack_file = (kodi_utils.get_property('deadlight.playing.pack_file') or '').strip()
		except Exception: return played, 'player'
		if not pack_file: return played, 'player'
		try:
			from modules.source_utils import seas_ep_filter
			if not seas_ep_filter(int(self.player.season), int(self.player.episode), pack_file):
				return played, 'player'
		except Exception: return played, 'player'
		return pack_file, 'pack'

	def _ranked_releases(self, candidates):
		"""Candidates ordered best-first, by how well their release matches what is playing.

		Falls back to the addon's own order -- the old behaviour -- when nothing scores above
		zero. A zero means the releases could not be told apart, not that the subtitle is
		wrong, so attaching one is no worse than what this replaces.

		LOCAL PATCH 2026-09-01: returns the whole ORDER rather than a single pick, so the
		caller can try the next release when a download fails. subdl indexes entries whose
		archive it cannot serve -- Reply 1988 S01E01 scored its MMR REMUX correctly at 40 and
		then 500d on every fetch, leaving no subtitle at all while a usable second candidate
		sat unused.
		"""
		played, played_src = self._played_name()
		if not played or len(candidates) == 1: return list(candidates)
		played_norm = _norm(played)
		played_group, played_source = _group_of(played), _source_of(played_norm)
		played_edition = _edition_of(played_norm)
		scored = [(_score_release(i, played_norm, played_group, played_source, played_edition), n, i)
			for n, i in enumerate(candidates)]
		# -score so the best sorts first, then n so ties keep the API's own order.
		scored.sort(key=lambda x: (-x[0], x[1]))
		best_score, _, best = scored[0]
		# LOCAL PATCH 2026-09-01: decide BEFORE logging, and log what is actually attached.
		# The fallback below returns candidates[0] whenever nothing scores above zero, but
		# the log named `best` -- the top-SCORED row -- so it advertised a release the viewer
		# never received. Observed on Reply 1988 S01E01: the log said 540p-WITH while the file
		# written was ION10, disagreeing in precisely the case worth debugging.
		fell_back = best_score <= 0
		chosen = candidates[0] if fell_back else best
		try:
			from modules.kodi_utils import logger
			logger('subtitles', 'played=%s(%s) group=%s source=%s -> %s=%s score=%s of %s' % (
				played, played_src, played_group or '-', played_source or '-',
				'fallback(api-order)' if fell_back else 'best', _release_of(chosen) or '?',
				best_score, len(candidates)))
		except Exception: pass
		if fell_back: return list(candidates)
		return [c for _score, _n, c in scored]

	def _match_note(self, sub):
		"""Release group of the subtitle actually attached, for the download notification.

		_release_of, not movieReleaseName: on subdl and SubSense that field is absent and the
		note came out empty even on a confident group match.
		"""
		group = (sub.get('releaseGroup') or _group_of(_release_of(sub)) or '').strip()
		return ' (%s)' % group[:12] if group else ''

	def run(self):
		try:
			if get_setting('deadlight.subtitles.auto_download', 'false') != 'true': return
			imdb_id = getattr(self.player, 'imdb_id', '')
			if not imdb_id: return
			self.language_name = get_setting('deadlight.subtitles.language', 'English')
			self.language = SUB_LANGUAGES.get(self.language_name, 'eng')
			self._wanted_tokens = {self.language, self.language_name.lower(),
				SUB_LANG_ISO1.get(self.language, self.language[:2])}
			self.auto_enable = get_setting('deadlight.subtitles.auto_enable', 'true') == 'true'
			manifest = (get_setting('deadlight.subtitles.manifest', '') or '').strip()
			if manifest in ('', 'empty_setting'): manifest = DEFAULT_MANIFEST
			# The configure page hands out .../manifest.json; the endpoints hang off the base.
			if manifest.endswith('/manifest.json'): manifest = manifest[:-len('/manifest.json')]
			self.manifest = manifest.rstrip('/')
			name = imdb_id
			if getattr(self.player, 'media_type', '') == 'episode':
				season, episode = self.player.season, self.player.episode
				self.path = 'subtitles/series/%s:%s:%s.json' % (imdb_id, season, episode)
				name = '%s_%s_%s' % (name, season, episode)
			else:
				self.path = 'subtitles/movie/%s.json' % imdb_id
			# LOCAL PATCH 2026-08-31: a subtitle is now saved under its OWN release name, so the
			# cache is scoped by DIRECTORY instead of by a key baked into the file name. One
			# directory per imdb id (plus season/episode): without that scope a cached S01E01
			# subtitle would score just as well against S01E02 -- same group, same source -- and
			# be reused for the wrong episode, which is worse than the mismatch the old group
			# suffix guarded against.
			self.subtitle_path = 'special://temp/DeadLightSubs/%s/' % name
			try: kodi_utils.make_directories(self.subtitle_path)
			except Exception: pass
			# Let the stream settle before touching subtitle state.
			kodi_utils.sleep(2000)
			return self._video_file_subs() or self._downloaded_subs() or self._searched_subs()
		except Exception as e:
			from modules.kodi_utils import logger
			logger('subtitles', str(e))
