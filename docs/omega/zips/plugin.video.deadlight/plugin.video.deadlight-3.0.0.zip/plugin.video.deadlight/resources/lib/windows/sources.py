# -*- coding: utf-8 -*-
import json
from windows.base_window import BaseDialog
from caches.settings_cache import set_setting
from modules.debrid import debrid_for_ext_cache_check
from modules.utils import TaskPool
from modules.source_utils import source_filters, release_group as _release_group, provider_display_name
import re as _re

# LOCAL PATCH 2026-09-26: the widelist rows show extraInfo's tags as flags, in kind order -- HDR (2),
# source, audio (2), channels, language (2); no video codec, by choice -- packed from the left, so a row missing a kind
# has no gap (fixed columns were tried first and left one). The col_* property names are just the
# nine slots in order; the XML places them at an even step. Flags are AF3's colour flags, bundled in
# skins/Default/media/deadlight_flags/source_info with their CC BY-NC-SA credit. The table covers
# every tag source_utils.get_info can emit. A tag with no faithful flag, or one past its column's
# slots, stays text on the meta line: REMUX, HYBRID, SDR, containers, and the Indian regional
# languages -- AF3's hin, tam and tel are the same Indian flag and its 'mal' is Malay, not
# Malayalam, so only Hindi is a flag.
_FLAG_PATH = 'deadlight_flags/source_info/%s.png'
_FLAG_COLUMNS = (
	('hdr', 2, (('D/VISION', 'dolbyvision'), ('HDR10+', 'hdr10plus'), ('HDR', 'hdr10'))),
	('source', 1, (('WEB', 'web'), ('BLURAY', 'bluray'), ('HDTV', 'hdtv'), ('DVD', 'dvd'), ('PDTV', 'sdtv'))),
	('audio', 2, (('ATMOS', 'atmos'), ('TRUEHD', 'truehd'), ('DTS-X', 'dtsx'), ('DTS-HD MA', 'dtshd_ma'), ('DTS-HD', 'dtshd_hra'),
				('DTS', 'dts'), ('DD+', 'eac3'), ('DD', 'ac3'), ('DD-EX', 'ac3'), ('AAC', 'aac'), ('OPUS', 'opus'), ('FLAC', 'flac'), ('MP3', 'mp3'))),
	('ch', 1, (('2CH', 'ch2'), ('6CH', 'ch6'), ('7CH', 'ch7'), ('8CH', 'ch8'))),
	('lang', 2, (('MULTI-LANG', 'lang_multi'), ('ENGLISH', 'lang_eng'), ('HINDI', 'lang_hin'), ('SPANISH', 'lang_spa'), ('FRENCH', 'lang_fre'), ('GERMAN', 'lang_ger'),
				('ITALIAN', 'lang_ita'), ('RUSSIAN', 'lang_rus'), ('JAPANESE', 'lang_jpn'), ('KOREAN', 'lang_kor'), ('CHINESE', 'lang_chi'),
				('ARABIC', 'lang_ara'), ('TURKISH', 'lang_tur'), ('DUTCH', 'lang_dut'), ('POLISH', 'lang_pol'), ('PORTUGUESE', 'lang_por'))))
_FLAG_OF = dict((tag, (column, rank, name)) for column, _, tags in _FLAG_COLUMNS for rank, (tag, name) in enumerate(tags))
_FLAG_PROPERTIES = tuple('col_%s%d' % (column, n + 1) for column, slots, _ in _FLAG_COLUMNS for n in range(slots))
_MARKUP = _re.compile(r'\[/?(?:B|I|COLOR[^\]]*)\]', _re.I)


# Streaming-service codes -> the studio logo shown on the row (resource.images.studios.coloured, the
# pack AF3 uses; file names as the pack's index lists them). Searched only from the resolution on
# ('2160p ATVP WEB-DL'), falling back to the part after SxxEyy/year: episode titles sit between the
# two, and 'Stan' / 'Hulu' there are title words.
_STUDIO_PATH = 'resource://resource.images.studios.coloured/%s.png'
# LOCAL PATCH 2026-09-26: display labels too long for the row's left block ('HTTP_STRE...'). DISPLAY ONLY,
# via provider_label and Site: -- 'provider' itself must keep the scraper's name: the filter panel sorts
# its provider list by the provider-order setting (make_filter_items), and 'DIRECT' is not in that list.
_SHORT_LABEL = {'HTTP_STREAMS': 'DIRECT'} # Direct Streams
# the left block's provider: full names, except HTTP_STREAMS (173 px at font10 bold -- wider than the
# 150 px column sized for REAL-DEBRID / AIOSTREAMS)
_SHORT_PROVIDER = {'HTTP_STREAMS': 'DIRECT'}
_SERVICES = (('atvp', 'apple tv+'), ('atv', 'apple tv+'), ('amzn', 'prime video'), ('nf', 'netflix'), ('dsnp', 'disney+'),
			 ('hmax', 'hbo max'), ('pcok', 'peacock'), ('pmtp', 'paramount+'), ('hulu', 'hulu'), ('cr', 'crunchyroll'),
			 ('stan', 'stan'), ('mubi', 'mubi'), ('stz', 'starz'), ('amcp', 'amc+'))
_SERVICE = _re.compile(r'(?i)(?<![a-z0-9])(%s)(?![a-z0-9])' % '|'.join(code for code, _ in _SERVICES))
_SERVICE_LOGO = dict(_SERVICES)
_TECH_START = _re.compile(r'(?i)(?<![a-z0-9])(?:s\d{1,2}\s?e\d{1,4}|(?:19|20)\d{2}|\d{3,4}[pi])(?![a-z0-9])')
_RESOLUTION = _re.compile(r'(?i)(?<![a-z0-9])\d{3,4}[pi](?![a-z0-9])')


def _service_split(name):
	"""(everything before the service-bearing part, the service-bearing part)."""
	name = name or ''
	m = _RESOLUTION.search(name) or _TECH_START.search(name)
	return (name[:m.start()], name[m.start():]) if m else (name, '')


# LOCAL PATCH 2026-09-26: audio languages the release NAME states, as the tags get_info would have used.
# get_info only ever tags MULTI-LANG, and full language words come from http_streams alone -- so torrent
# rows ('... Amare ed essere amato ITA ENG 2160p ...') showed no language at all. Two readers, each
# guarded against title words:
#   * 3-letter codes: UPPERCASE only between SxxEyy / year and the resolution -- episode titles live
#     there and are Title Case, so 'Eng' or 'Ita' in one cannot match; ANY case from the resolution on,
#     where no title words are left (MediaFusion writes '... REMUX Fra').
#   * full words ('Hindi', 'French') and MULTI / DUAL AUDIO, any case, from the resolution on only.
# Codes for languages with no faithful flag (TAM, TEL, MAL, KAN) are left out -- they would only be text.
_LANG_CODES = {'ENG': 'ENGLISH', 'HIN': 'HINDI', 'SPA': 'SPANISH', 'ESP': 'SPANISH', 'FRA': 'FRENCH', 'FRE': 'FRENCH',
			   'GER': 'GERMAN', 'DEU': 'GERMAN', 'ITA': 'ITALIAN', 'RUS': 'RUSSIAN', 'JPN': 'JAPANESE', 'JAP': 'JAPANESE',
			   'KOR': 'KOREAN', 'CHI': 'CHINESE', 'CHN': 'CHINESE', 'ARA': 'ARABIC', 'TUR': 'TURKISH', 'DUT': 'DUTCH',
			   'NLD': 'DUTCH', 'POL': 'POLISH', 'POR': 'PORTUGUESE'}
_LANG_CODE = _re.compile(r'(?<![A-Za-z0-9])(%s)(?![A-Za-z0-9])' % '|'.join(_LANG_CODES))
_LANG_CODE_ANYCASE = _re.compile(r'(?i)(?<![a-z0-9])(%s)(?![a-z0-9])' % '|'.join(_LANG_CODES))
_LANG_WORD = _re.compile(r'(?i)(?<![a-z])(english|hindi|spanish|french|german|italian|russian|japanese|korean|chinese|arabic|'
						 r'turkish|dutch|polish|portuguese)(?![a-z])')
_MULTI_WORD = _re.compile(r'(?i)(?<![a-z])(?:multi|dual[\s._-]?audio)(?![a-z])')


def _name_languages(name):
	"""Language tags ('ENGLISH', 'MULTI-LANG', ...) a release name states, in order, once each."""
	name = name or ''
	m = _TECH_START.search(name)
	after_marker = name[m.start():] if m else ''
	from_resolution = _service_split(name)[1]
	out = []
	codes = _LANG_CODE.findall(after_marker) + [c.upper() for c in _LANG_CODE_ANYCASE.findall(from_resolution)]
	for tag in ([_LANG_CODES[c] for c in codes] + [w.upper() for w in _LANG_WORD.findall(from_resolution)]
				+ (['MULTI-LANG'] if _MULTI_WORD.search(from_resolution) else [])):
		if tag not in out: out.append(tag)
	return out


def _studio_flag(name, tags):
	"""The studio logo for a release, or ''. The name's service code first; get_info's APPLETV+ tag after."""
	m = _SERVICE.search(_service_split(name)[1])
	if m: return _STUDIO_PATH % _SERVICE_LOGO[m.group(1).lower()]
	if 'APPLETV+' in (t.upper() for t in tags): return _STUDIO_PATH % 'apple tv+'
	return ''


def _flag_columns(extra_info):
	"""({col_<column><n>: texture path}, the tags with no flag as text) for one extraInfo."""
	found, text, seen = {}, [], set()
	for raw in (extra_info or '').split('|'):
		tag = _MARKUP.sub('', raw).strip()
		if not tag or tag == 'N/A': continue
		hit = _FLAG_OF.get(tag.upper())
		if hit is None: text.append(tag)
		elif hit[2] not in seen:
			seen.add(hit[2])
			found.setdefault(hit[0], []).append((hit[1], hit[2], tag))
	# HDR10+ rows also carry the broad HDR tag (kept for the HDR filter); one HDR flag is enough
	if 'hdr10plus' in seen: found['hdr'] = [f for f in found['hdr'] if f[1] != 'hdr10']
	# MULTI only says "more than one language" -- with two languages named it would only push one of them
	# out of the two slots ('ITA ENG' showed MULTI + UK, no Italy). One named language keeps MULTI beside it.
	named = [f for f in found.get('lang', []) if f[1] != 'lang_multi']
	if len(named) >= 2: found['lang'] = named
	# HYBRID means DV + an HDR10 layer in one file -- two flags in the HDR column already say it, and the
	# word was what pushed the meta line past its width on every DV row
	if len(found.get('hdr', [])) >= 2: text = [t for t in text if t.upper() != 'HYBRID']
	# LOCAL PATCH 2026-09-26: PACKED, not fixed columns -- a row without HDR left a gap where the HDR
	# flags would sit. Kind order and per-kind limits stay; the flags fill the slots in order.
	packed = []
	for column, slots, _ in _FLAG_COLUMNS:
		ranked = sorted(found.get(column, []))
		packed.extend(_FLAG_PATH % name for _, name, _ in ranked[:slots])
		text.extend(tag for _, _, tag in ranked[slots:])   # past the kind's limit: kept, as text
	# right-packed: the widelist strip is right-aligned on the row's first line, so the flags fill
	# the LAST slots in order and the last flag sits at the right edge
	lead = len(_FLAG_PROPERTIES) - len(packed)
	props = dict((key, packed[n - lead] if n >= lead else '') for n, key in enumerate(_FLAG_PROPERTIES))
	# LOCAL PATCH 2026-09-26: how many slots on the LEFT of the strip are empty. The details line
	# (Size / Hoster / Site / Group) sits in front of the strip and was capped at 867 px -- the
	# width left when all eight slots are used -- so a row with one or two flags still cut 'Group'
	# to 'GROU...' in front of ~450 px of blank space. sources_results.xml picks the label whose
	# max width is 867 + 76 px per empty slot.
	props['flag_lead'] = str(lead)
	return props, text
from modules.settings import provider_sort_ranks, avoid_episode_spoilers, max_threads
from modules.kodi_utils import get_icon, kodi_dialog, hide_busy_dialog, addon_fanart, select_dialog, ok_dialog, notification
# from modules.kodi_utils import logger

class SourcesResults(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.window_format = kwargs.get('window_format', 'list')
		self.window_id = kwargs.get('window_id', 2000)
		self.filter_window_id = 2100
		self.results = kwargs.get('results')
		self.uncached_results = kwargs.get('uncached_results', [])
		self.info_highlights_dict = kwargs.get('scraper_settings')
		self.episode_group_label = kwargs.get('episode_group_label', '')
		self.prescrape = kwargs.get('prescrape')
		self.meta = kwargs.get('meta')
		self.filters_ignored = kwargs.get('filters_ignored', False)
		self.meta_get = self.meta.get
		self.make_poster = self.window_format in ('list', 'medialist')
		self.empty_poster = get_icon('box_office')
		self.addon_fanart = addon_fanart()
		self.poster = self.meta_get('poster') or self.empty_poster
		self.external_cache_check = kwargs.get('external_cache_check')
		self.prerelease_values, self.prerelease_key = ('CAM', 'SCR', 'TELE'), 'CAM/SCR/TELE'
		self.info_icons_dict = {'easynews': get_icon('easynews'), 'alldebrid': get_icon('alldebrid'), 'real-debrid': get_icon('realdebrid'),
		'premiumize': get_icon('premiumize'), 'torbox': get_icon('torbox'), 'ad_cloud': get_icon('alldebrid'), 'rd_cloud': get_icon('realdebrid'),
		'pm_cloud': get_icon('premiumize'), 'tb_cloud': get_icon('torbox'), 'aiostreams': get_icon('aiostreams'), 'http_streams': get_icon('aiostreams')}
		self.info_quality_dict = {'4k': get_icon('flag_4k', 'flags'), '1080p': get_icon('flag_1080p', 'flags'), '720p': get_icon('flag_720p', 'flags'),
		'sd': get_icon('flag_sd', 'flags'), 'cam': get_icon('flag_sd', 'flags'), 'tele': get_icon('flag_sd', 'flags'), 'scr': get_icon('flag_sd', 'flags')}
		self.make_items()
		self.make_filter_items()
		self.set_properties()

	def onInit(self):
		from modules.kodi_utils import logger
		import xbmc, time
		self.filter_applied = False
		if self.make_poster: self.set_poster()
		self.setProperty('window_format', self.window_format)
		item_count = len(self.item_list) if self.item_list else 0
		filter_count = len(self.filter_list) if self.filter_list else 0
		logger('SourcesResults onInit', 'window_format=%s window_id=%s items=%d filter_items=%d' % (self.window_format, self.window_id, item_count, filter_count))
		self.add_items(self.window_id, self.item_list)
		self.add_items(self.filter_window_id, self.filter_list)
		# LOCAL PATCH 2026-09-26: poll for focus instead of fixed sleeps. The old sleep(80) + check +
		# sleep(120) + retry reported focusedId=0 at +80 ms on every open in the log and only landed
		# at +200 ms -- setFocusId is processed by the GUI thread, so an immediate getFocusId races
		# it. Now: check every 20 ms, re-issue setFocusId every 100 ms, give up at 400 ms (the old
		# path's worst case was ~200 ms, so this only waits longer where the old one fell back).
		try:
			start = time.time()
			focused = 0
			for step in range(20):
				if step % 5 == 0: self.setFocusId(self.window_id)
				xbmc.sleep(20)
				focused = self.getFocusId()
				if focused == self.window_id: break
			logger('SourcesResults onInit', 'focusedId=%s after %d ms' % (focused, int((time.time() - start) * 1000)))
			if focused != self.window_id:
				self.setFocusId(self.filter_window_id)
				logger('SourcesResults onInit', 'fallback focus to filter %s' % self.filter_window_id)
		except Exception as e:
			logger('SourcesResults onInit focus error', str(e))

	def run(self):
		self.doModal()
		self.clearProperties()
		self.clear_home_property('window_theme.sources')
		hide_busy_dialog()
		return self.selected

	def get_provider_and_path(self, provider):
		try: return provider, self.info_icons_dict[provider]
		except: return 'folders', get_icon('folder')

	def get_quality_and_path(self, quality):
		try: return quality, self.info_quality_dict[quality]
		except: return 'sd', get_icon('flag_sd')

	def filter_action(self, action):
		if action == self.right_action or action in self.closing_actions:
			self.select_item(self.filter_window_id, 0)
			self.setFocusId(self.window_id)
		if action in self.selection_actions:
			chosen_listitem = self.get_listitem(self.filter_window_id)
			filter_type, filter_value = chosen_listitem.getProperty('filter_type'), chosen_listitem.getProperty('filter_value')
			if filter_type in ('quality', 'provider'):
				if filter_value == self.prerelease_key: filtered_list = [i for i in self.item_list if i.getProperty(filter_type) in self.prerelease_values]
				else: filtered_list = [i for i in self.item_list if i.getProperty(filter_type) == filter_value]
			elif filter_type == 'special':
				if filter_value == 'title':
					keywords = kodi_dialog().input('Enter Keyword (Comma Separated for Multiple)')
					if not keywords: return
					keywords.replace(' ', '')
					keywords = keywords.split(',')
					choice = [i.upper() for i in keywords]
					filtered_list = [i for i in self.item_list if all(x in i.getProperty('name') for x in choice)]
				elif filter_value == 'extraInfo':
					filters = source_filters()
					list_items = [{'line1': item[0], 'icon': self.poster} for item in filters]
					kwargs = {'items': json.dumps(list_items), 'heading': 'Filter Results', 'multi_choice': 'true'}
					choice = select_dialog(filters, **kwargs)
					if choice == None: return
					choice = [i[1] for i in choice]
					filtered_list = [i for i in self.item_list if all(x in i.getProperty('extraInfo') for x in choice)]
				elif filter_value == 'showuncached': filtered_list = self.make_items(self.uncached_results)
				else: #cache_check_rescrape
					self.selected = ('cache_change_rescrape', 'false' if self.external_cache_check else 'true')
					return self.close()
			if not filtered_list: return ok_dialog(text='No Results')
			self.set_filter(filtered_list)

	def onAction(self, action):
		if self.get_visibility('Control.HasFocus(%s)' % self.filter_window_id): return self.filter_action(action)
		chosen_listitem = self.get_listitem(self.window_id)
		if action in self.closing_actions:
			if self.filter_applied: return self.clear_filter()
			self.selected = (None, '')
			return self.close()
		if action == self.info_action:
			self.open_window(('windows.sources', 'SourcesInfo'), 'sources_info.xml', item=chosen_listitem)
		elif action in self.selection_actions:
			if self.prescrape and chosen_listitem.getProperty('perform_full_search') == 'true':
				self.selected = ('perform_full_search', '')
				return self.close()
			chosen_source = json.loads(chosen_listitem.getProperty('source'))
			if 'Uncached' in chosen_source.get('cache_provider', ''):
				from modules.debrid import manual_add_magnet_to_cloud
				return manual_add_magnet_to_cloud({'mode': 'manual_add_magnet_to_cloud', 'provider': chosen_source['debrid'], 'magnet_url': chosen_source['url']})
			self.selected = ('play', chosen_source)
			return self.close()
		elif action in self.context_actions:
			source = json.loads(chosen_listitem.getProperty('source'))
			choice = self.context_menu(source)
			if choice:
				if isinstance(choice, dict): return self.execute_code('RunPlugin(%s)' % self.build_url(choice))
				if choice == 'results_info': return self.open_window(('windows.sources', 'SourcesInfo'), 'sources_info.xml', item=chosen_listitem)
				if choice == 'rd_cloud_delete':
					from apis.real_debrid_api import RealDebridAPI
					rd_api = RealDebridAPI()
					function = rd_api.delete_torrent if source['cache_type'] == 'torrent' else rd_api.delete_download
					result = function(source['folder_id'])
					if result.status_code in (401, 403, 404): return notification('Error', 1200)
					rd_api.clear_cache()
					self.delete_single_source(source)

	def delete_single_source(self, single_source):
		self.results.remove(single_source)
		self.make_items()
		self.total_results = str(len(self.item_list))
		self.reset_window(self.window_id)
		self.add_items(self.window_id, self.item_list)
		self.setFocusId(self.window_id)
		self.set_properties()

	def make_items(self, filtered_list=None):
		def builder(count, item):
			try:
				get = item.get
				listitem = self.make_listitem()
				set_properties = listitem.setProperties
				scrape_provider, source, quality, name = get('scrape_provider'), get('source'), get('quality', 'SD'), get('display_name')
				basic_quality, quality_icon = self.get_quality_and_path(quality.lower())
				pack = get('package', 'false') in ('true', 'show', 'season')
				extraInfo = get('extraInfo', '')
				extraInfo = extraInfo.rstrip('| ')
				if pack: extraInfo = '[B]%s PACK[/B] | %s' % (get('package'), extraInfo)
				if self.episode_group_label: extraInfo = '%s | %s' % (self.episode_group_label, extraInfo)
				if not extraInfo: extraInfo = 'N/A'
				if scrape_provider == 'external':
					source_site = get('provider').upper()
					provider = get('debrid', source_site).replace('.me', '').upper()
					provider_lower = provider.lower()
					provider_icon = self.get_provider_and_path(provider_lower)[1]
					if 'Uncached' in item['cache_provider']:
						if 'seeders' in item: set_properties({'source_type': 'UNCACHED (%d SEEDERS)' % get('seeders', 0)})
						else: set_properties({'source_type': 'UNCACHED'})
						set_properties({'highlight': 'FF7C7C7C'})
					else:
						if provider in ('REAL-DEBRID', 'ALLDEBRID'):
							if self.external_cache_check: cache_flag = '[B]CACHED[/B]'
							else: cache_flag = 'UNCHECKED'
						else: cache_flag = '[B]CACHED[/B]'
						if highlight_type == 0: key = provider_lower
						else: key = basic_quality
						set_properties({'highlight': self.info_highlights_dict[key]})
						if pack: set_properties({'source_type': '%s [B]PACK[/B]' % cache_flag})
						else: set_properties({'source_type': '%s' % cache_flag})
					set_properties({'provider': provider})
				else:
					source_site = _SHORT_LABEL.get(source.upper(), source.upper())
					provider, provider_icon = self.get_provider_and_path(source.lower())
					if highlight_type == 0: key = provider
					else: key = basic_quality
					# LOCAL PATCH: http_streams exposes a per-stream `hoster` field (PixelDrain,
					# FSL-V2, HubCloud, etc., derived from URL via _identify_host_from_url).
					# When present, surface it in the Hoster column instead of the generic 'DIRECT'.
					hoster_label = (get('hoster') or '').upper().strip() or 'DIRECT'
					set_properties({'highlight': self.info_highlights_dict[key], 'source_type': hoster_label, 'provider': provider.upper()})
				# LOCAL PATCH 2026-09-22: release group, shown beside Site in the picker.
				# Providers that clean the name before handing it over destroy the fansub tag
				# (magneto's clean_name deletes the leading bracket outright), so animetosho
				# passes `release_group` explicitly. Everything else -- aiostreams, http_streams,
				# cloud, folders -- keeps a raw-enough name for the same extractor to read a
				# scene-style trailing -GROUP off it, so fall back to that rather than show
				# nothing. Blank is a normal answer: ~15% of live anime names carry no group.
				release_group = (get('release_group') or '').strip()
				if not release_group: release_group = _release_group(get('name') or '')
				# LOCAL PATCH 2026-09-26: no group -> no Group field at all, rather than 'Group: N/A'.
				# The whole segment is built here because the skin cannot hide it: $INFO's prefix
				# form cannot hold the nested $INFO[...(highlight)] colour the label uses.
				release_group = release_group.upper()
				group_segment = ('     [COLOR %s][B]Group: [/B][/COLOR]%s' % (listitem.getProperty('highlight'), release_group)) if release_group else ''
				set_properties({'release_group': release_group, 'group_segment': group_segment})
				# LOCAL PATCH 2026-09-26: widelist's flags (see _flag_columns) and studio logo (see _studio_flag).
				# Tags with no flag are not shown at all -- the row carries the flags and nothing else.
				_langs = _name_languages(name)
				columns, flagless = _flag_columns(' | '.join([extraInfo] + _langs) if _langs else extraInfo)
				set_properties(columns)
				set_properties({'studio_flag': _studio_flag(name, flagless)})
				_prov = listitem.getProperty('provider')
				set_properties({'provider_label': _SHORT_PROVIDER.get(_prov, _prov)})
				set_properties({'name': name.upper(), 'source_site': source_site, 'provider_icon': provider_icon, 'quality_icon': quality_icon, 'count': '%02d.' % count,
						'size_label': get('size_label', 'N/A'), 'extraInfo': extraInfo, 'quality': quality.upper(), 'hash': get('hash', 'N/A'), 'source': json.dumps(item)})	
				item_list.append((listitem, count))
			except: pass
		try:
			item_list = []
			highlight_type = self.info_highlights_dict['highlight_type']
			if filtered_list:
				threads = TaskPool().tasks_enumerate(builder, filtered_list, min(len(filtered_list), max_threads()))
				[i.join() for i in threads]
				item_list.sort(key=lambda k: k[1])
				item_list = [i[0] for i in item_list]
				return item_list
			threads = TaskPool().tasks_enumerate(builder, self.results, min(len(self.results), max_threads()))
			[i.join() for i in threads]
			item_list.sort(key=lambda k: k[1])
			self.item_list = [i[0] for i in item_list]
			if self.prescrape:
				prescrape_listitem = self.make_listitem()
				prescrape_listitem.setProperty('perform_full_search', 'true')
			self.total_results = str(len(self.item_list))
			if self.prescrape: self.item_list.append(prescrape_listitem)
		except: pass

	def make_filter_items(self):
		def builder(count, item):
			listitem = self.make_listitem()
			listitem.setProperties({'label': item[0], 'filter_type': item[1], 'filter_value': item[2]})
			self.filter_list.append((listitem, count))
		duplicates = set()
		qualities = [i.getProperty('quality') for i in self.item_list \
							if not (i.getProperty('quality') in duplicates or duplicates.add(i.getProperty('quality'))) \
							and not i.getProperty('quality') == '']
		if any(i in self.prerelease_values for i in qualities): qualities = [i for i in qualities if not i in self.prerelease_values] + [self.prerelease_key]
		qualities.sort(key=('4K', '1080P', '720P', 'SD', 'CAM/SCR/TELE').index)
		quality_totals = {i: len([x for x in self.item_list if x.getProperty('quality') == i]) for i in qualities}
		if 'CAM/SCR/TELE' in qualities: quality_totals['CAM/SCR/TELE'] = len([i for i in self.item_list if i.getProperty('quality') in self.prerelease_values])
		duplicates = set()
		providers = [i.getProperty('provider') for i in self.item_list \
							if not (i.getProperty('provider') in duplicates or duplicates.add(i.getProperty('provider'))) \
							and not i.getProperty('provider') == '']
		provider_totals = {i: len([x for x in self.item_list if x.getProperty('provider') == i]) for i in providers}
		sort_ranks = provider_sort_ranks()
		cache_functions_debrid = debrid_for_ext_cache_check()
		sort_ranks['premiumize'] = sort_ranks.pop('premiumize.me')
		provider_choices = sorted(sort_ranks.keys(), key=sort_ranks.get)
		provider_choices = [i.upper() for i in provider_choices]
		providers.sort(key=provider_choices.index)
		qualities = [('Show [B]%s[/B] Only | [B]%d[/B] Results' % (i, quality_totals[i]), 'quality', i) for i in qualities]
		providers = [('Show [B]%s[/B] Only | [B]%d[/B] Results' % (provider_display_name(i), provider_totals[i]), 'provider', i) for i in providers]
		data = []
		if cache_functions_debrid: data.append(('Rescrape with External Cache Check [B]%s[/B]' % ('OFF' if self.external_cache_check else 'ON'), 'special', 'cache_check_rescrape'))
		if self.uncached_results: data.append(('Show [B]Uncached[/B] Only | [B]%d[/B] Results' % len(self.uncached_results), 'special', 'showuncached'))
		data.extend(qualities)
		data.extend(providers)
		data.extend([('Filter by [B]Title[/B]...', 'special', 'title'), ('Filter by [B]Info[/B]...', 'special', 'extraInfo')])
		self.filter_list = []
		threads = TaskPool().tasks_enumerate(builder, data, min(len(data), max_threads()))
		[i.join() for i in threads]
		self.filter_list.sort(key=lambda k: k[1])
		self.filter_list = [i[0] for i in self.filter_list]

	def set_properties(self):
		self.set_home_property('window_theme.sources', self.get_home_property('window_theme'))
		self.setProperty('window_format', self.window_format)
		self.setProperty('fanart', self.meta_get('fanart') or self.addon_fanart)
		self.setProperty('clearlogo', self.meta_get('clearlogo') or '')
		self.setProperty('title', self.meta_get('title'))
		self.setProperty('total_results', self.total_results)
		self.setProperty('filters_ignored', '| Filters Ignored' if self.filters_ignored else '')

	def set_poster(self):
		if self.window_id == 2000: self.set_image(200, self.poster)

	def context_menu(self, item):
		down_file_params, down_pack_params, browse_pack_params, add_magnet_to_cloud_params, uncached_download = None, None, None, None, None
		item_get = item.get
		item_id, name, magnet_url, info_hash = item_get('id', None), item_get('name'), item_get('url', 'None'), item_get('hash', 'None')
		provider_source, scrape_provider, cache_provider = item_get('source'), item_get('scrape_provider'), item_get('cache_provider', 'None')
		uncached = 'Uncached' in cache_provider
		source, meta_json = json.dumps(item), json.dumps(self.meta)
		choices = []
		choices_append = choices.append
		if not uncached and scrape_provider != 'folders':
			down_file_params = {'mode': 'downloader.runner', 'action': 'meta.single', 'name': self.meta.get('rootname', ''), 'source': source,
								'url': None, 'provider': scrape_provider, 'meta': meta_json}
		if 'package' in item and not uncached:
			down_pack_params = {'mode': 'downloader.runner', 'action': 'meta.pack', 'name': self.meta.get('rootname', ''), 'source': source, 'url': None,
								'provider': cache_provider, 'meta': meta_json, 'magnet_url': magnet_url, 'info_hash': info_hash}
		if provider_source == 'torrent':
			browse_pack_params = {'mode': 'debrid.browse_packs', 'provider': cache_provider, 'name': name,
								'magnet_url': magnet_url, 'info_hash': info_hash}
			add_magnet_to_cloud_params = {'mode': 'manual_add_magnet_to_cloud', 'provider': cache_provider, 'magnet_url': magnet_url}
		choices_append(('Info', 'results_info'))
		if add_magnet_to_cloud_params: choices_append(('Add to Cloud', add_magnet_to_cloud_params))
		if browse_pack_params: choices_append(('Browse', browse_pack_params))
		if down_pack_params: choices_append(('Download Pack', down_pack_params))
		if down_file_params: choices_append(('Download File', down_file_params))
		if provider_source == 'rd_cloud': choices_append(('Delete from RD Cloud', 'rd_cloud_delete'))
		list_items = [{'line1': i[0], 'icon': self.poster} for i in choices]
		kwargs = {'items': json.dumps(list_items)}
		choice = select_dialog([i[1] for i in choices], **kwargs)
		return choice

	def set_filter(self, filtered_list):
		self.filter_applied = True
		self.reset_window(self.window_id)
		self.add_items(self.window_id, filtered_list)
		self.setFocusId(self.window_id)
		self.setProperty('total_results', str(len(filtered_list)))
		self.setProperty('filter_applied', 'true')
		self.setProperty('filter_info', '| Press [B]BACK[/B] to Cancel')

	def clear_filter(self):
		self.filter_applied = False
		self.reset_window(self.window_id)
		self.add_items(self.window_id, self.item_list)
		self.setFocusId(self.window_id)
		self.select_item(self.filter_window_id, 0)
		self.setProperty('total_results', self.total_results)
		self.setProperty('filter_applied', 'false')
		self.setProperty('filter_info', '')

class SourcesPlayback(BaseDialog):
	def __init__(self, *args, **kwargs):
		from modules.kodi_utils import logger
		logger('DialogFlash SourcesPlayback.__init__', 'new instance')
		BaseDialog.__init__(self, *args)
		self.meta = kwargs.get('meta')
		self.is_canceled, self.skip_resolve, self.resume_choice = False, False, None
		self.meta_get = self.meta.get
		self.addon_fanart = addon_fanart()
		self.enable_scraper()

	def run(self):
		self.doModal()
		self.clearProperties()
		self.clear_modals()

	def onClick(self, controlID):
		self.resume_choice = {10: 'resume', 11: 'start_over', 12: 'cancel'}[controlID]

	def onAction(self, action):
		if action in self.closing_actions: self.is_canceled = True
		elif action == self.right_action and self.window_mode == 'resolver': self.skip_resolve = True

	def iscanceled(self):
		return self.is_canceled

	def skip_resolved(self):
		status = self.skip_resolve
		self.skip_resolve = False
		return status

	def reset_is_cancelled(self):
		self.is_canceled = False

	def enable_scraper(self):
		self.window_mode = 'scraper'
		self.set_scraper_properties()

	def enable_resolver(self):
		from modules.kodi_utils import logger
		logger('DialogFlash SourcesPlayback.enable_resolver', 'fired')
		self.window_mode = 'resolver'
		self.set_resolver_properties()

	def enable_resume(self, percent):
		self.window_mode = 'resume'
		self.set_resume_properties(percent)

	def busy_spinner(self, toggle='true'):
		self.setProperty('enable_busy_spinner', toggle)

	def set_scraper_properties(self):
		title, genre = self.meta_get('title'), self.meta_get('genre', '')
		fanart, clearlogo = self.meta_get('fanart') or self.addon_fanart, self.meta_get('clearlogo') or ''
		self.setProperty('window_mode', self.window_mode)
		self.setProperty('fanart', fanart)
		self.setProperty('clearlogo', clearlogo)
		self.setProperty('title', title)
		self.setProperty('genre', ', '.join(genre))

	def set_resolver_properties(self):
		if self.meta_get('media_type') == 'movie': self.text = self.meta_get('plot')
		else:
			if avoid_episode_spoilers() and int(self.meta_get('playcount', '0')) == 0: plot = self.meta_get('tvshow_plot') or '* Hidden to Prevent Spoilers *'
			else: plot = self.meta_get('plot', '') or self.meta_get('tvshow_plot', '')
			self.text = '[B]%02dx%02d - %s[/B][CR][CR]%s' % (self.meta_get('season'), self.meta_get('episode'), self.meta_get('ep_name', 'N/A').upper(), plot)
		self.setProperty('window_mode', self.window_mode)
		self.setProperty('text', self.text)

	def set_resume_properties(self, percent):
		self.setProperty('window_mode', self.window_mode)
		self.setProperty('resume_percent', percent)
		self.setFocusId(10)
		self.update_resumer()

	def update_scraper(self, results_sd, results_720p, results_1080p, results_4k, results_total, content='', percent=0):
		self.setProperty('results_4k', str(results_4k))
		self.setProperty('results_1080p', str(results_1080p))
		self.setProperty('results_720p', str(results_720p))
		self.setProperty('results_sd', str(results_sd))
		self.setProperty('results_total', str(results_total))
		self.setProperty('percent', str(percent))
		self.set_text(2001, content)

	def update_resolver(self, text='', percent=0):
		try: self.setProperty('percent', str(percent))
		except: pass
		if text: self.set_text(2002, text)

	def update_resumer(self):
		from modules.kodi_utils import kodi_player
		player = kodi_player()
		initial_playing = player.isPlayingVideo()
		count = 0
		while self.resume_choice is None:
			if self.is_canceled:
				self.resume_choice = 'cancel'
				break
			if initial_playing and not player.isPlayingVideo():
				self.resume_choice = 'cancel'
				break
			percent = int((float(count)/10000)*100)
			if percent >= 100: self.resume_choice = 'resume'
			self.setProperty('percent', str(percent))
			count += 100
			self.sleep(100)

class SourcesInfo(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.item = kwargs['item']
		self.item_get_property = self.item.getProperty
		self.set_properties()

	def run(self):
		self.doModal()

	def onAction(self, action):
		self.close()

	def set_properties(self):
		self.setProperty('name', self.item_get_property('name'))
		self.setProperty('source_type', self.item_get_property('source_type'))
		self.setProperty('source_site', self.item_get_property('source_site'))
		self.setProperty('size_label', self.item_get_property('size_label'))
		self.setProperty('extraInfo', self.item_get_property('extraInfo'))
		self.setProperty('highlight', self.item_get_property('highlight'))
		self.setProperty('hash', self.item_get_property('hash'))
		self.setProperty('provider', self.item_get_property('provider').lower())
		self.setProperty('quality', self.item_get_property('quality').lower())
		self.setProperty('provider_icon', self.item_get_property('provider_icon'))
		self.setProperty('quality_icon', self.item_get_property('quality_icon'))
