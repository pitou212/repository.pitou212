# -*- coding: utf-8 -*-
import json
from ast import literal_eval
from caches.base_cache import connect_database, get_timestamp
from modules.kodi_utils import get_property, set_property, clear_property
# from modules.kodi_utils import logger

# LOCAL PATCH 2026-08-26 (perf): JSON instead of repr()/eval() for cached blobs.
# Measured on 50 real metas (avg 7.8KB): eval() 41.8ms vs json.loads 3.1ms -- 13.4x.
# Every cache read paid the eval, so a 50-item page paid it 50 times. It also stops
# eval()-ing stored data, which is the safer outcome. Note literal_eval is not a
# substitute on the HOT path -- measured 49ms, slower than eval itself -- which is why
# JSON is the answer there and literal_eval serves only the legacy fallback below.
#
# _loads falls back to ast.literal_eval for rows written before this patch -- no
# migration needed, they age out naturally. literal_eval rather than eval: it cannot
# execute code, and the fallback only runs on legacy rows so its extra cost is
# transitional and irrelevant.
#
# SCOPE: meta_cache only -- the hot path every list render walks. trakt_cache,
# navigator_cache, mdblist_cache, simkl_cache, external_cache, personal_lists_cache,
# episode_groups_cache and base_cache.cache_function still use repr/eval and were left
# alone deliberately; they are colder, and each needs its own shape audit first.
#
# Two shape changes JSON forces, both checked against all 1560 live blobs first:
#   * int dict keys become strings. Only `season_trailers` is read today, and
#     modules.metadata.season_trailer_for now accepts either. (`season_art` also has
#     int keys but is inert -- left over from reverted work.)
#   * tuples become lists. Only `meta['studio']` is a tuple; setStudios takes either.
def _loads(text):
	if not text: return None
	try: return json.loads(text)
	except Exception:
		try: return literal_eval(text)
		except Exception: return None


def _dumps(obj):
	return json.dumps(obj, default=str)


class MetaCache:
	def get(self, media_type, id_type, media_id, current_time=None):
		meta = None
		try:
			media_id = str(media_id)
			if not current_time: current_time = get_timestamp()
			meta = self.get_memory_cache(media_type, id_type, media_id, current_time)
			if meta is None:
				dbcon = connect_database('metacache_db')
				cache_data = dbcon.execute('SELECT meta, expires FROM metadata WHERE db_type = ? AND %s = ?' % id_type, (media_type, media_id)).fetchone()
				if cache_data:
					meta, expiry = _loads(cache_data[0]), cache_data[1]
					if expiry <= current_time:
						self.delete(media_type, id_type, media_id, meta=meta)
						meta = None
					else: self.set_memory_cache(media_type, id_type, meta, expiry, media_id)
		except: pass
		return meta

	def get_season(self, prop_string):
		meta = None
		try:
			current_time = get_timestamp()
			meta = self.get_memory_cache_season(prop_string, current_time)
			if meta is None:
				dbcon = connect_database('metacache_db')
				cache_data = dbcon.execute('SELECT meta, expires FROM season_metadata WHERE tmdb_id = ?', (prop_string,)).fetchone()
				if cache_data:
					meta, expiry = _loads(cache_data[0]), cache_data[1]
					if expiry <= current_time:
						self.delete_season(prop_string)
						meta = None
					else: self.set_memory_cache_season(prop_string, meta, expiry)
		except: pass
		return meta

	def set(self, media_type, id_type, meta, expiration=168, current_time=None):
		try:
			dbcon = connect_database('metacache_db')
			meta_get = meta.get
			if current_time: expires = current_time + (expiration*3600)
			else: expires = get_timestamp(expiration)
			media_id = str(meta_get(id_type))
			dbcon.execute('INSERT OR REPLACE INTO metadata VALUES (?, ?, ?, ?, ?, ?)',
				(media_type, str(meta_get('tmdb_id')), meta_get('imdb_id'), str(meta_get('tvdb_id')), _dumps(meta), expires))
		except: return None
		self.set_memory_cache(media_type, id_type, meta, expires, media_id)

	def set_season(self, prop_string, meta, expiration=168):
		try:
			dbcon = connect_database('metacache_db')
			expires = get_timestamp(expiration)
			# LOCAL PATCH 2026-08-31: OR REPLACE, matching set() above. tmdb_id is `not null
			# unique`, so a plain INSERT over an existing row raises IntegrityError, which this
			# function's own bare except swallows -- silently dropping the write. Reachable
			# whenever two widget processes race the same cold key (reuselanguageinvoker=false
			# means every widget is its own process).
			dbcon.execute('INSERT OR REPLACE INTO season_metadata VALUES (?, ?, ?)', (prop_string, _dumps(meta), int(expires)))
		except: return None
		self.set_memory_cache_season(prop_string, meta, expires)

	def delete(self, media_type, id_type, media_id, meta=None):
		try:
			dbcon = connect_database('metacache_db')
			dbcon.execute('DELETE FROM metadata WHERE db_type = ? AND %s = ?' % id_type, (media_type, media_id))
			for item in ('tmdb_id', 'imdb_id', 'tvdb_id'): self.delete_memory_cache(media_type, item, meta[item])
			if media_type == 'tvshow': self.delete_all_seasons(media_id)
		except: return

	def delete_season(self, prop_string):
		try:
			dbcon = connect_database('metacache_db')
			dbcon.execute('DELETE FROM season_metadata WHERE tmdb_id = ?', (prop_string,))
			self.delete_memory_cache_season(prop_string)
		except: return

	def get_memory_cache(self, media_type, id_type, media_id, current_time):
		result = None
		try:
			prop_string = 'deadlight.%s_%s_%s' % (media_type, id_type, media_id)
			cachedata = _loads(get_property(prop_string))
			if cachedata[0] > current_time: result = cachedata[1]
		except: result = None
		return result

	def get_memory_cache_season(self, prop_string, current_time):
		result = None
		try:
			cachedata = _loads(get_property('deadlight.meta_season_%s' % prop_string))
			if cachedata[0] > current_time: result = cachedata[1]
		except: result = None
		return result

	def set_memory_cache(self, media_type, id_type, meta, expires, media_id):
		try:
			cachedata, prop_string = (expires, meta), 'deadlight.%s_%s_%s' % (media_type, id_type, media_id)
			set_property(prop_string, _dumps(cachedata))
		except: pass

	def set_memory_cache_season(self, prop_string, meta, expires):
		try:
			cachedata = (expires, meta)
			set_property('deadlight.meta_season_%s' % prop_string, _dumps(cachedata))
		except: pass

	def delete_memory_cache(self, media_type, id_type, media_id):
		try: clear_property('deadlight.%s_%s_%s' % (media_type, id_type, media_id))
		except: pass

	def delete_memory_cache_season(self, prop_string):
		try: clear_property('deadlight.meta_season_%s' % prop_string)
		except: pass

	def get_function(self, prop_string):
		result = None
		try:
			dbcon = connect_database('metacache_db')
			current_time = get_timestamp()
			cache_data = dbcon.execute('SELECT string_id, data, expires FROM function_cache WHERE string_id = ?', (prop_string,)).fetchone()
			if cache_data:
				if cache_data[2] >= current_time: result = _loads(cache_data[1])
				else: dbcon.execute('DELETE FROM function_cache WHERE string_id = ?', (prop_string,))
		except: pass
		return result

	def set_function(self, prop_string, result, expiration=24):
		try:
			dbcon = connect_database('metacache_db')
			expires = get_timestamp(expiration)
			# LOCAL PATCH 2026-08-31: OR REPLACE -- string_id is `not null unique`; see set_season.
			dbcon.execute('INSERT OR REPLACE INTO function_cache VALUES (?, ?, ?)', (prop_string, _dumps(result), expires))
		except: return

	def delete_all_seasons(self, media_id):
		for item in range(1,51): self.delete_season('%s_%s' % (media_id, str(item)))

	def delete_all(self):
		try:
			dbcon = connect_database('metacache_db')
			for i in dbcon.execute('SELECT db_type, tmdb_id FROM metadata'):
				try: self.delete_memory_cache(str(i[0]), 'tmdb_id', str(i[1]))
				except: pass
			for i in dbcon.execute('SELECT tmdb_id FROM season_metadata'):
				try: self.delete_memory_cache_season(str(i[0]))
				except: pass
			for i in ('metadata', 'season_metadata', 'function_cache'): dbcon.execute('DELETE FROM %s' % i)
			dbcon.execute('VACUUM')
		except: return

	def clean_database(self):
		try:
			dbcon = connect_database('metacache_db')
			for table in ('metadata', 'function_cache', 'season_metadata'):
				dbcon.execute('DELETE from %s WHERE CAST(expires AS INT) <= ?' % table, (get_timestamp(),))
			dbcon.execute('VACUUM')
			return True
		except: return False

meta_cache = MetaCache()

def cache_function(function, prop_string, url, expiration=720, json=True):
	data = meta_cache.get_function(prop_string)
	if data: return data
	if json: result = function(url).json()
	else: result = function(url)
	meta_cache.set_function(prop_string, result, expiration=expiration)
	return result

def delete_meta_cache(silent=False):
	from modules.kodi_utils import confirm_dialog
	try:
		if not silent and not confirm_dialog(): return False
		meta_cache.delete_all()
		return True
	except: return False
