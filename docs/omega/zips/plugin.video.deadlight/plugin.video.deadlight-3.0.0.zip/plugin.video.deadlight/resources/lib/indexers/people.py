# -*- coding: utf-8 -*-
from urllib.parse import unquote
from windows.base_window import open_window
from indexers.images import Images
# from modules.kodi_utils import logger

def tmdb_people(params):
	return Images().run({'mode': 'tmdb_people_list_image_results', 'action': params['action'], 'page_no': 1})

def person_search(key_id=None):
	return Images().run({'mode': 'tmdb_people_search_image_results', 'key_id': unquote(key_id), 'page_no': 1})

def favorite_people():
	return Images().run({'mode': 'favorite_people_list_image_results'})

def person_data_dialog(params):
	if 'key_id' in params: key_id = unquote(params.get('key_id'))
	elif 'query' in params: key_id = unquote(params.get('query'))
	else: key_id = None
	open_window(('windows.people', 'People'), 'people.xml', key_id=key_id, actor_name=params.get('actor_name'), actor_image=params.get('actor_image'),
				actor_id=params.get('actor_id'), reference_tmdb_id=params.get('reference_tmdb_id'), is_external=params.get('is_external', 'false'),
				starting_position=params.get('starting_position', None))



