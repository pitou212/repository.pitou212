# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-23 / bugfix 2026-07-28: MDBList directory builders.
# Ported from POV's menus/mdblist.py, but the list-content builders now use
# DeadLight's proven Trakt-list pattern (indexers/trakt_lists.py:build_trakt_list)
# — pack items into `{'list': [(order, media_ids), ...], 'id_type': 'trakt_dict',
# 'custom_order': 'true'}` and hand off to Movies/TVShows.worker(). Previous
# `_prefetched` kwarg approach didn't feed through DeadLight's indexers.
import sys
import json
import random as _random
from threading import Thread
from apis.mdblist_api import (
	mdbl_get_lists, mdbl_top_lists, mdbl_search_lists,
	get_mdbl_list_contents, mdblist_collection, mdblist_watchlist,
	mdblist_droplist, mdblist_on_cooldown, mdblist_cooldown_minutes,
)


# LOCAL PATCH 2026-09-15: a failed fetch is told to the user, not drawn as an empty screen.
# On 2026-09-15 the daily quota ran out (1000/1000, Free plan) and both list endpoints
# answered 429; the add-on rendered an empty "My MDBList Lists" with no explanation, which
# read as a broken OAuth sign-in. The fetchers now return None on failure (see
# mdblist_api.mdbl_get_lists / get_mdbl_list_contents), and this is the one place that
# turns None into a message. Logged as well, so the log and the screen agree.
#
# Toast only on a FOREGROUND browse. MDBList lists double as home widgets, and every widget
# build is its own build_mdblist_list call: on the first cut of this the user saw five toasts
# in 30 seconds after a cold start (kodi.log 2026-09-15 07:52:55-07:53:24), one per widget,
# and again on every widget refresh while the quota was out. A widget has nowhere to put a
# message and nobody asked it a question; the log line is the right record there. In the
# foreground one toast per _TOAST_GAP is enough -- browsing three lists on a dead quota
# should not read as three separate faults.
_TOAST_PROP, _TOAST_GAP = 'deadlight.mdblist_lists_toast_ts', 300

def _notify_unavailable(what):
	try:
		if mdblist_on_cooldown():
			mins = mdblist_cooldown_minutes()
			text = 'MDBList rate limited - %s unavailable, retry in %d min' % (what, mins) if mins else 'MDBList rate limited - %s unavailable' % what
		else:
			text = 'MDBList unavailable - %s could not be fetched' % what
		kodi_utils.logger('MDBList lists', text + (' (widget, no toast)' if kodi_utils.external() else ''))
		if kodi_utils.external(): return
		import time
		try: last = float(kodi_utils.get_property(_TOAST_PROP) or 0)
		except (TypeError, ValueError): last = 0
		if time.time() - last < _TOAST_GAP: return
		kodi_utils.set_property(_TOAST_PROP, str(time.time()))
		kodi_utils.notification(text, 4000)
	except Exception: pass
from caches.mdblist_cache import mdbl_cache
from indexers.movies import Movies
from indexers.tvshows import TVShows
from modules import kodi_utils
from modules.utils import paginate_list
from modules.settings import paginate, page_limit, widget_hide_next_page, jump_to_enabled


# LOCAL PATCH 2026-07-31: per-list sort order for MDBList list contents.
# Storage: mdblist_cache KV — key = 'mdbl_sort_order_{list_id}', value = str('0'..'5').
# Default (unset / '0') = MDBList's own rank order — items returned as-is.
_SORT_CHOICES = (
	('MDBList Rank (default)', '0'),
	('Title (A → Z)', '1'),
	('Title (Z → A)', '2'),
	('Release Date (Newest)', '3'),
	('Release Date (Oldest)', '4'),
	('Shuffle (Random)', '5'),
)


def _sort_key_for_item(item, sort_order):
	if sort_order == '1' or sort_order == '2':
		return (item.get('title') or '').lower()
	if sort_order == '3' or sort_order == '4':
		# Prefer release_date (YYYY-MM-DD); fall back to release_year; unknown → very old.
		rd = item.get('release_date') or ''
		if rd: return rd
		ry = item.get('release_year')
		return '%04d-01-01' % ry if ry else '0000-00-00'
	return item.get('rank') or 0


def _apply_sort(items, sort_order):
	"""Sort a raw MDBList items list by `sort_order` code. Non-destructive."""
	if not items or not sort_order or sort_order == '0': return items
	if sort_order == '5':
		out = list(items); _random.shuffle(out); return out
	reverse = sort_order in ('2', '3')
	try:
		return sorted(items, key=lambda i: _sort_key_for_item(i, sort_order), reverse=reverse)
	except Exception:
		return items


def _get_stored_sort_order(list_id):
	if not list_id: return '0'
	try: return mdbl_cache.get('mdbl_sort_order_%s' % list_id) or '0'
	except Exception: return '0'


def _sort_label(sort_order):
	for label, code in _SORT_CHOICES:
		if code == (sort_order or '0'): return label
	return _SORT_CHOICES[0][0]


def set_sort_order(params):
	"""Context-menu entry point: prompt for a sort order + persist per-list."""
	list_id = params.get('list_id')
	if not list_id: return
	choices_labels = [c[0] for c in _SORT_CHOICES]
	choices_values = [c[1] for c in _SORT_CHOICES]
	list_items = [{'line1': lbl} for lbl in choices_labels]
	kwargs = {'items': json.dumps(list_items), 'heading': 'MDBList Sort Order', 'narrow_window': 'true'}
	picked = kodi_utils.select_dialog(choices_values, **kwargs)
	if picked is None: return
	try:
		mdbl_cache.set('mdbl_sort_order_%s' % list_id, picked)
		# Invalidate cached list contents so the new order applies on next open.
		mdbl_cache.delete('mdbl_list_contents_external_%s' % list_id)
		mdbl_cache.delete('mdbl_list_contents_my_lists_%s' % list_id)
	except Exception: pass
	kodi_utils.notification('Sort: %s' % _sort_label(picked), 2500)
	kodi_utils.kodi_refresh()

# Icon key — DeadLight will resolve via its icon-resolution chain. MDBList doesn't
# have a bundled icon yet; fall back to 'lists' which exists in DeadLight's
# menu_icons directory.
MDBLIST_ICON = 'lists'


# ═══════════════════════════════════════════════════════════════════════════
#  Helpers — pack a raw MDBList item into DeadLight's Movies/TVShows shape
# ═══════════════════════════════════════════════════════════════════════════

def _media_ids(item):
	"""Extract the mixed-id dict from an MDBList item. Movies/TVShows accept
	a `trakt_dict` id_type dict shaped like {'imdb': ..., 'tmdb': ..., 'tvdb': ...}."""
	ids = (item or {}).get('ids') or {}
	return {'imdb': ids.get('imdb', ''), 'tmdb': ids.get('tmdb', ''), 'tvdb': ids.get('tvdb', '')}


def _split_items(rows):
	"""Split a mixed MDBList result into movies / tvshows for Movies/TVShows workers.
	Rows may be top-level {'movies': [...], 'shows': [...]} OR a flat list where
	each item has a nested 'movie'/'show' object OR a bare item with 'type' field.

	LOCAL PATCH 2026-08-05 (POV 6.08 P3 port): handle episode/season items too.
	MDBList's `type` field can be 'movie', 'show', 'season', or 'episode' (some
	curated lists like "Best Episodes of 2024" ship at episode granularity).
	DeadLight renders at show granularity in list views, so roll seasons/
	episodes up to their parent show (deduped) — user drills into the show
	to find the specific episode. Prevents silent data loss where 100-item
	episode lists rendered as empty."""
	movies, shows = [], []
	seen_show_tmdb = set()
	def _add_show(ids):
		tmdb = str(ids.get('tmdb') or '')
		if tmdb and tmdb in seen_show_tmdb: return
		if tmdb: seen_show_tmdb.add(tmdb)
		shows.append(ids)
	if isinstance(rows, dict):
		for m in rows.get('movies', []) or []:
			inner = m.get('movie', m)
			movies.append(_media_ids(inner))
		for s in rows.get('shows', []) or []:
			inner = s.get('show', s)
			_add_show(_media_ids(inner))
		# episode/season buckets — roll parent show IDs up
		for e in (rows.get('episodes', []) or []) + (rows.get('seasons', []) or []):
			show_inner = e.get('show') or e
			ids = _media_ids(show_inner)
			if ids.get('tmdb') or ids.get('imdb') or ids.get('tvdb'): _add_show(ids)
		return movies, shows
	if isinstance(rows, list):
		for i in rows:
			if not isinstance(i, dict): continue
			# unified=true list-contents: {'type': 'movie'|'show'|'season'|'episode', ...}
			t = i.get('type', '')
			if 'movie' in i or t == 'movie':
				movies.append(_media_ids(i.get('movie', i)))
			elif t in ('show', 'tv', 'tvshow') or 'show' in i:
				_add_show(_media_ids(i.get('show', i)))
			elif t in ('episode', 'season'):
				# Episode / season item — use its parent show's IDs for rollup.
				show_inner = i.get('show') or i
				ids = _media_ids(show_inner)
				if ids.get('tmdb') or ids.get('imdb') or ids.get('tvdb'): _add_show(ids)
			else:
				# Bare item — infer by mediatype key
				mt = i.get('mediatype') or ''
				if mt == 'show' or mt == 'tvshow':
					_add_show(_media_ids(i))
				else:
					movies.append(_media_ids(i))
	return movies, shows


def _icon_or_default(name):
	try: return kodi_utils.get_icon(name)
	except: return kodi_utils.get_icon('lists')


def _fanart():
	return kodi_utils.get_addon_fanart()


def _render_content(handle, movies, shows, list_name, mode_for_next=None, new_params=None, page_no=1, total_pages=1, is_external=False):
	"""Common tail — hand ID rows to Movies/TVShows workers, concat, add pagination.
	Mirrors indexers/trakt_lists.py:build_trakt_list lines 260-283."""
	threads, item_list = [], []
	item_list_extend = item_list.extend
	movie_list = {'list': [(idx, ids) for idx, ids in enumerate(movies)], 'id_type': 'trakt_dict', 'custom_order': 'true'}
	tvshow_list = {'list': [(idx, ids) for idx, ids in enumerate(shows)], 'id_type': 'trakt_dict', 'custom_order': 'true'}
	def _process(builder, _list):
		try:
			if _list['list']: item_list_extend(builder(_list).worker())
		except: pass
	if movies:
		t = Thread(target=_process, args=(Movies, movie_list)); t.start(); threads.append(t)
	if shows:
		t = Thread(target=_process, args=(TVShows, tvshow_list)); t.start(); threads.append(t)
	[t.join() for t in threads]
	item_list.sort(key=lambda k: k[1])
	kodi_utils.add_items(handle, [i[0] for i in item_list])
	if mode_for_next and total_pages > page_no and not (is_external and widget_hide_next_page()):
		new_page = str(page_no + 1)
		p = dict(new_params or {})
		p['new_page'] = new_page
		kodi_utils.add_dir(handle, p, 'Next Page (%s) >>' % new_page, 'nextpage', kodi_utils.get_icon('nextpage_landscape'))
	content = 'movies' if len(movies) >= len(shows) else 'tvshows'
	kodi_utils.set_content(handle, content)
	kodi_utils.set_category(handle, list_name)
	# LOCAL PATCH 2026-09-04: same two fixes as indexers/anilist_lists.py -- see the longer
	# note there. cacheToDisc=False on the widget path to match movies/tvshows/episodes, and
	# pass content + is_external to set_view_mode, which otherwise blocks waiting for
	# container_content() == 'files' while this page is 'movies'/'tvshows'. That never
	# matched, so a non-widget MDBList browse burned its ~3 s timeout and never applied the
	# viewtype. is_external is already a parameter of _render_content.
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	kodi_utils.set_view_mode('view.main', content, is_external)


# ═══════════════════════════════════════════════════════════════════════════
#  My Lists / External (liked) Lists — directory browse
# ═══════════════════════════════════════════════════════════════════════════

def get_mdblist_lists(params):
	handle = int(sys.argv[1])
	build_url, make_listitem = kodi_utils.build_url, kodi_utils.make_listitem
	icon, fanart = _icon_or_default(MDBLIST_ICON), _fanart()
	list_type = params.get('list_type', 'my_lists')
	items = []
	try: data = mdbl_get_lists(list_type)
	except: data = None
	if data is None:
		_notify_unavailable('lists')
		data = []
	for item in data:
		try:
			list_id = item.get('id') or item.get('list_id')
			if not list_id: continue
			list_name = item.get('name', 'Unnamed')
			item_count = item.get('items', item.get('item_count', 0))
			user = item.get('user_name') or item.get('user') or ''
			if list_type == 'external' and user:
				display = '%s | [I]%s (x%s)[/I]' % (list_name, user, item_count)
			else:
				display = '%s [I](x%s)[/I]' % (list_name, item_count)
			url = build_url({'mode': 'mdblist.list.build_mdblist_list', 'list_id': list_id, 'list_type': list_type,
							 'list_name': list_name, 'iconImage': MDBLIST_ICON, 'name': list_name})
			cm = []
			if list_type == 'my_lists':
				cm.append(('[B]Make New List[/B]', 'RunPlugin(%s)' % build_url({'mode': 'mdblist.make_new_mdbl_list'})))
				cm.append(('[B]Delete List[/B]', 'RunPlugin(%s)' % build_url({'mode': 'mdblist.delete_mdbl_list', 'list_id': list_id})))
			# LOCAL PATCH 2026-07-31: per-list sort order (Title / Release Date / Shuffle).
			cm.append(('[B]Change Sort Order[/B] [I](%s)[/I]' % _sort_label(_get_stored_sort_order(list_id)),
				'RunPlugin(%s)' % build_url({'mode': 'mdblist.list.set_sort_order', 'list_id': list_id})))
			cm.append(('[B]Add to Shortcut Folder[/B]', 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.shortcut_folder_add_known', 'url': url})))
			listitem = make_listitem()
			listitem.setLabel(display)
			listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': fanart})
			info_tag = listitem.getVideoInfoTag(True)
			info_tag.setPlot(' ')
			listitem.addContextMenuItems(cm)
			items.append((url, listitem, True))
		except: pass
	kodi_utils.add_items(handle, items)
	kodi_utils.set_content(handle, 'files')
	kodi_utils.set_category(handle, 'My MDBList Lists' if list_type == 'my_lists' else 'Liked Lists')
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.main')


def get_mdblist_top_lists(params):
	handle = int(sys.argv[1])
	build_url, make_listitem = kodi_utils.build_url, kodi_utils.make_listitem
	icon, fanart = _icon_or_default(MDBLIST_ICON), _fanart()
	items = []
	try: data = mdbl_top_lists() or []
	except: data = []
	for item in data:
		try:
			list_id = item.get('id') or item.get('list_id')
			if not list_id: continue
			list_name = item.get('name', 'Unnamed')
			user = item.get('user_name') or item.get('user') or ''
			item_count = item.get('items', item.get('item_count', 0))
			likes = item.get('likes', 0)
			display = '%s | [I]%s (x%s) [/I][COLOR=yellow]♥%s[/COLOR]' % (list_name, user, item_count, likes)
			url = build_url({'mode': 'mdblist.list.build_mdblist_list', 'list_id': list_id, 'list_type': 'external',
							 'list_name': list_name, 'iconImage': MDBLIST_ICON, 'name': list_name})
			cm = [
				('[B]Change Sort Order[/B] [I](%s)[/I]' % _sort_label(_get_stored_sort_order(list_id)),
					'RunPlugin(%s)' % build_url({'mode': 'mdblist.list.set_sort_order', 'list_id': list_id})),
				('[B]Add to Shortcut Folder[/B]', 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.shortcut_folder_add_known', 'url': url})),
			]
			listitem = make_listitem()
			listitem.setLabel(display)
			listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': fanart})
			info_tag = listitem.getVideoInfoTag(True)
			info_tag.setPlot(' ')
			listitem.addContextMenuItems(cm)
			items.append((url, listitem, True))
		except: pass
	kodi_utils.add_items(handle, items)
	kodi_utils.set_content(handle, 'files')
	kodi_utils.set_category(handle, 'Top MDBList Lists')
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.main')


def search_mdblist_lists(params):
	handle = int(sys.argv[1])
	build_url, make_listitem = kodi_utils.build_url, kodi_utils.make_listitem
	icon, fanart = _icon_or_default(MDBLIST_ICON), _fanart()
	query = params.get('key_id') or params.get('query') or ''
	items = []
	if query:
		try: data = mdbl_search_lists(query) or []
		except: data = []
		for item in data:
			try:
				list_id = item.get('id') or item.get('list_id')
				if not list_id: continue
				list_name = item.get('name', 'Unnamed')
				user = item.get('user_name') or item.get('user') or ''
				item_count = item.get('items', item.get('item_count', 0))
				display = '%s | [I]%s (x%s)[/I]' % (list_name, user, item_count)
				url = build_url({'mode': 'mdblist.list.build_mdblist_list', 'list_id': list_id, 'list_type': 'external',
								 'list_name': list_name, 'iconImage': MDBLIST_ICON, 'name': list_name})
				cm = [('[B]Change Sort Order[/B] [I](%s)[/I]' % _sort_label(_get_stored_sort_order(list_id)),
					'RunPlugin(%s)' % build_url({'mode': 'mdblist.list.set_sort_order', 'list_id': list_id}))]
				listitem = make_listitem()
				listitem.setLabel(display)
				listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': fanart})
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setPlot(' ')
				listitem.addContextMenuItems(cm)
				items.append((url, listitem, True))
			except: pass
	kodi_utils.add_items(handle, items)
	kodi_utils.set_content(handle, 'files')
	kodi_utils.set_category(handle, (query or 'MDBList Search').capitalize())
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.main')



# ═══════════════════════════════════════════════════════════════════════════
#  List content builders — feed Movies/TVShows workers via trakt_dict id_type
# ═══════════════════════════════════════════════════════════════════════════

def build_mdblist_list(params):
	handle = int(sys.argv[1])
	list_id = params.get('list_id')
	list_type = params.get('list_type', 'my_lists')
	list_name = params.get('list_name', 'MDBList')
	if not list_id: return
	is_external = kodi_utils.external()
	page_no = int(params.get('new_page', '1'))
	try: contents = get_mdbl_list_contents(list_type, list_id)
	except: contents = None
	if contents is None:
		_notify_unavailable('list contents')
		contents = []
	# LOCAL PATCH 2026-07-31: apply per-list sort order (context-menu configurable).
	sort_order = _get_stored_sort_order(list_id)
	if isinstance(contents, list):
		contents = _apply_sort(contents, sort_order)
	movies, shows = _split_items(contents)
	# Pagination — for now, list all in one page (MDBList already paginates the
	# fetch via cursor; splitting further would just add navigation clicks).
	total_pages = 1
	next_params = {'mode': 'mdblist.list.build_mdblist_list', 'list_id': list_id, 'list_type': list_type, 'list_name': list_name}
	_render_content(handle, movies, shows, list_name, mode_for_next='mdblist.list.build_mdblist_list',
					new_params=next_params, page_no=page_no, total_pages=total_pages, is_external=is_external)


def build_mdblist_watchlist(params):
	handle = int(sys.argv[1])
	mediatype = params.get('mediatype', 'movies')
	is_external = kodi_utils.external()
	page_no = int(params.get('new_page', '1'))
	try: data = mdblist_watchlist(mediatype, page_no)
	except: data = ([], 1)
	if isinstance(data, tuple): rows, total_pages = data[0], data[1] if len(data) > 1 else 1
	else: rows, total_pages = data, 1
	# rows here is a flat list of items with nested 'movie'/'show' object.
	movies, shows = _split_items(rows or [])
	label = 'Watchlist'
	_render_content(handle, movies, shows, label,
					mode_for_next='mdblist.list.build_mdblist_watchlist',
					new_params={'mode': 'mdblist.list.build_mdblist_watchlist', 'mediatype': mediatype},
					page_no=page_no, total_pages=total_pages, is_external=is_external)


# LOCAL PATCH 2026-07-28: MDBList dropped-shows browse. mdblist_droplist returns
# TMDb IDs from the user's `sync/dropped` list. Feed them straight to TVShows
# worker with trakt_dict id_type (only the tmdb key populated).
def build_mdblist_droplist(params):
	handle = int(sys.argv[1])
	is_external = kodi_utils.external()
	page_no = int(params.get('new_page', '1'))
	try:
		data = mdblist_droplist('shows', page_no)
		rows = data[0] if isinstance(data, tuple) else data
	except: rows = []
	# rows here is a list of {'imdb_id': '', 'id': tmdb_id} — bare TMDb IDs.
	shows = []
	for i in (rows or []):
		try:
			tmdb = i.get('id') or i.get('tmdb') or i.get('tmdb_id')
			if tmdb:
				shows.append({'imdb': i.get('imdb_id', ''), 'tmdb': tmdb, 'tvdb': ''})
		except: pass
	_render_content(handle, [], shows, 'Dropped Shows',
					mode_for_next='mdblist.list.build_mdblist_droplist',
					new_params={'mode': 'mdblist.list.build_mdblist_droplist'},
					page_no=page_no, total_pages=1, is_external=is_external)


def build_mdblist_collection(params):
	handle = int(sys.argv[1])
	mediatype = params.get('mediatype', 'movies')
	is_external = kodi_utils.external()
	page_no = int(params.get('new_page', '1'))
	try: data = mdblist_collection(mediatype, page_no)
	except: data = ([], 1)
	if isinstance(data, tuple): rows, total_pages = data[0], data[1] if len(data) > 1 else 1
	else: rows, total_pages = data, 1
	movies, shows = _split_items(rows or [])
	label = 'Collection'
	_render_content(handle, movies, shows, label,
					mode_for_next='mdblist.list.build_mdblist_collection',
					new_params={'mode': 'mdblist.list.build_mdblist_collection', 'mediatype': mediatype},
					page_no=page_no, total_pages=total_pages, is_external=is_external)
