# -*- coding: utf-8 -*-
import re
from json import loads as jsloads
from caches.settings_cache import get_setting
from modules import source_utils
from modules.utils import clean_file_name, normalize
from modules.settings import filter_by_name
from modules.kodi_utils import make_session

# LOCAL PATCH 2026-06-23 (perf): pooled HTTP session for the manifest fetch. Mounted to
# 'https://' so it covers whatever manifest host is configured.
#
# 2026-08-29: URL validation was removed from this scraper entirely, along with its
# validate_urls / validate_timeout settings. With the manifest serving cached debrid links
# there is nothing for a probe to find -- the link is minted on demand from a file the
# service already holds -- and source_utils.drop_expired_presigns still catches an expired
# pre-signed CDN URL for free, without a request. Measured before removing it: validation
# cost +11.4s across five titles and dropped 16 rows, every one of which the free gate now
# removes or which were not returned at all.
_session = make_session('https://')


class source:
	def __init__(self):
		self.scrape_provider = 'aiostreams'
		self.sources = []
		self.timeout = 10

	def results(self, info):
		# LOCAL PATCH: reuse DeadLight's ExternalCache (same store Magneto/Sootio/etc.
		# use) so repeat scrapes of the same (title, year, S/E) hit the SQLite cache
		# instead of re-fetching the AIOStreams manifest. TTL comes from
		# source_utils.get_cache_expiry baked into info['expiry_times'].
		media_type = info.get('media_type')
		tmdb_id = info.get('tmdb_id')
		title = info.get('title') or ''
		year = info.get('year', '')
		season_key = info.get('season') if media_type == 'episode' else ''
		episode_key = info.get('episode') if media_type == 'episode' else ''
		# Cache lookup
		if tmdb_id:
			try:
				from caches.external_cache import external_cache
				cached = external_cache.get('aiostreams', media_type, tmdb_id, title, year, season_key, episode_key)
				if cached is not None:
					self.sources = cached
					return self._return()
			except Exception:
				pass
		scrape_ran = False
		try:
			base_link = self._base_link()
			if not base_link:
				return self._return()
			# LOCAL PATCH 2026-08-26 (Red Light 2.3.3 port): fall back to a tmdb: id when
			# the title has no IMDb id, instead of abandoning the scrape. Stremio-protocol
			# addons accept `tmdb:12345` (and `tmdb:12345:S:E` for episodes) as well as
			# `tt1234567`. Anime is the big winner here -- plenty of entries carry a TMDb
			# id but no IMDb one, and those scrapes were silently returning zero sources.
			# IMDb stays preferred when present.
			imdb = info.get('imdb_id') or ''
			stream_id = imdb if imdb else ('tmdb:%s' % tmdb_id if tmdb_id else '')
			if not stream_id:
				return self._return()
			self.media_type = media_type
			self.title = title
			self.year = year
			# LOCAL PATCH 2026-08-29: coerce to int. These feed check_title -> seas_ep_filter,
			# which does arithmetic on them; with the strings info carries it raised
			# TypeError, and check_title swallows that as `except: return False`. Result:
			# with Filter by Name on, EVERY episode source was silently rejected while
			# movies were unaffected (they take the year branch and never call
			# seas_ep_filter). Measured on Lanterns S01E02: 29 streams in, 0 out.
			try: self.season, self.episode = int(info.get('season')), int(info.get('episode'))
			except (TypeError, ValueError): self.season, self.episode = info.get('season'), info.get('episode')
			self.aliases = source_utils.get_aliases_titles(info.get('aliases', []))
			self.filter_title = filter_by_name('aiostreams')
			if self.media_type == 'episode':
				season, episode = int(self.season), int(self.episode)
				url = '%s/stream/series/%s:%s:%s.json' % (base_link, stream_id, season, episode)
			else:
				url = '%s/stream/movie/%s.json' % (base_link, stream_id)
			try:
				response = _session.get(url, timeout=self.timeout)
			except Exception as e:
				self._warn_once('AIOStreams: Manifest Unreachable', 'connect failed: %s' % str(e))
				return self._return()
			if not response.ok:
				self._warn_once('AIOStreams: HTTP %s from manifest' % response.status_code, 'HTTP %s for %s' % (response.status_code, url))
				return self._return()
			files = self._parse_streams(response.text)
			extras = source_utils.extras()
			self.sources = [r for r in (self._make_item(item, extras) for item in files) if r]
			# LOCAL PATCH 2026-08-29: free pre-signed expiry gate, same one http_streams uses.
			# Costs no request -- an expired X-Amz signature is readable straight off the URL --
			# and it is now the only dead-link check here, URL validation having been removed
			# along with its settings. The manifest hands back the same FSL / R2 /
			# PixelDrain hosts the direct scraper sees: 8 of 9 pre-signs on Dune Part Two and
			# 7 of 7 on LOTR Fellowship were already expired, and those are exactly the rows
			# validation was spending 11s to find.
			self.sources = source_utils.drop_expired_presigns(self.sources, response.headers.get('Date'))
			scrape_ran = True
		except Exception as e:
			from modules.kodi_utils import logger
			logger('aiostreams scraper Exception', str(e))
		# Cache write — only after a real scrape attempt (skip on config-fail early returns)
		if scrape_ran and tmdb_id:
			try:
				from caches.external_cache import external_cache
				# LOCAL PATCH 2026-08-29: cap the TTL at 1 hour. get_cache_expiry is tuned for
				# torrent hashes, which stay valid for weeks -- it returns 336h (14 days) for a
				# movie released over 60 days ago, and 240h for an ended show. The URLs stored
				# here are nothing of the sort: they are pre-signed CDN links, and with a debrid
				# service attached they are short-lived signed URLs from RD/TorBox. Replaying a
				# 14-day-old link cannot work, and validation was the only thing catching it.
				# http_streams caps itself at 0.5h for the same reason; this had been missed.
				# A re-scrape measured 0.6-1.7s, so the cost of a shorter window is small.
				expiry_times = info.get('expiry_times') or (24, 0, 0)
				expiry_hours = min(1, expiry_times[0]) if self.sources else 1
				external_cache.set('aiostreams', media_type, tmdb_id, title, year, season_key, episode_key, self.sources, expiry_hours)
			except Exception:
				pass
		return self._return()

	@staticmethod
	def _warn_once(user_msg, log_msg):
		from modules.kodi_utils import logger, notification, get_property, set_property
		logger('aiostreams', log_msg)
		if get_property('deadlight.aiostreams.warned') == 'true':
			return
		set_property('deadlight.aiostreams.warned', 'true')
		notification(user_msg, 3500)

	def _return(self):
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources

	def _base_link(self):
		url = get_setting('deadlight.aiostreams.manifest_url', '').strip()
		if url in ('', 'empty_setting'): return ''
		url = url.rstrip('/')
		if url.endswith('/manifest.json'): url = url[:-len('/manifest.json')]
		if not url.startswith(('http://', 'https://')): url = 'https://%s' % url.lstrip('/')
		return url

	def _parse_streams(self, payload):
		try:
			data = jsloads(payload)
			return data.get('streams', []) if isinstance(data, dict) else []
		except:
			return []

	def _stream_url(self, item):
		url = item.get('url') or item.get('externalUrl') or ''
		if not url:
			stream = item.get('stream', {})
			if isinstance(stream, dict): url = stream.get('url') or ''
		return url

	def _stream_name(self, item):
		name = ''
		try: name = item.get('behaviorHints', {}).get('filename', '')
		except: name = ''
		if not name: name = item.get('name', '')
		if not name:
			title = item.get('title', '')
			name = title.split('\n')[0] if title else ''
		return normalize(name or '')

	def _stream_size_gb(self, item, file_info=''):
		try:
			size_bytes = float(item.get('behaviorHints', {}).get('videoSize'))
			return round(size_bytes / 1073741824.0, 2)
		except: pass
		try:
			match = re.search(r'((?:\d+,\d+\.\d+|\d+\.\d+|\d+,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', file_info)
			if not match: return 0.0
			text = match.group(0).replace(',', '').strip()
			num = float(re.match(r'[\d.]+', text).group(0))
			unit = re.search(r'[A-Za-z]+', text).group(0).lower()
			if unit.startswith('m'): num /= 1024.0
			return round(num, 2)
		except: return 0.0

	def _file_info_line(self, item):
		file_title = item.get('title', '')
		if not file_title: return ''
		for line in file_title.replace('┈➤', '\n').split('\n'):
			if '💾' in line or '👤' in line: return line
		return ''

	@staticmethod
	def _is_valid_http_url(url):
		"""Strict http/https URL validation. Rejects: empty/non-string, control chars,
		non-http(s) schemes (magnet/ftp/file/data/javascript/etc.), missing host,
		localhost / obvious placeholders, absurdly long blobs."""
		if not url or not isinstance(url, str): return False
		url = url.strip()
		if not url or len(url) > 8000: return False
		if any(c in url for c in ('\n', '\r', '\t', '\0', ' ')): return False
		lower = url.lower()
		if not (lower.startswith('http://') or lower.startswith('https://')): return False
		try:
			from urllib.parse import urlparse
			p = urlparse(url)
			if p.scheme not in ('http', 'https'): return False
			host = (p.hostname or '').lower()
			if not host: return False
			if host in ('localhost', 'example.com', 'placeholder', '0.0.0.0'): return False
			return True
		except Exception: return False

	def _make_item(self, item, extras):
		try:
			url = self._stream_url(item)
			if not url: return None
			# Split off Kodi's pipe-headers convention (https://...|User-Agent=...) before validating
			url_part = url.split('|', 1)[0]
			if not self._is_valid_http_url(url_part):
				from modules.kodi_utils import logger
				logger('aiostreams reject url', url[:120])
				return None
			name = self._stream_name(item)
			if not name: return None
			name_lower = name.lower()
			# LOCAL PATCH 2026-06-23: drop AIOStreams rows whose name contains 'download'.
			# These tend to be torrent-client download-page links (not actual stream URLs)
			# returned by some aggregator providers — they pollute the picker and never play.
			if 'download' in name_lower: return None
			# LOCAL PATCH 2026-08-29: same transcode filter http_streams uses. The manifest
			# can surface HDHub's /resolve/cj/ ladder too, and it is the same trap there:
			# an honest resolution tag over a bitrate a tenth of what it implies.
			if source_utils.is_transcode_url(url_part): return None
			if any(x in name_lower for x in extras): return None
			if self.filter_title and not source_utils.check_title(self.title, name, self.aliases, self.year, self.season, self.episode):
				return None
			size_gb = self._stream_size_gb(item, self._file_info_line(item))
			display_name = clean_file_name(name)
			video_quality, details = source_utils.get_file_info(name_info=source_utils.release_info_format(name))
			return {
				'name': name,
				'display_name': display_name,
				'quality': video_quality,
				'size': size_gb,
				'size_label': '%.2f GB' % size_gb if size_gb > 0 else '0.00 GB',
				'extraInfo': details,
				'url_dl': url,
				'id': url,
				'debrid': self.scrape_provider,
				'scrape_provider': self.scrape_provider,
				'direct': True,
				'direct_debrid_link': True,
				'local': False,
				'source': self.scrape_provider,
				'hash': item.get('infoHash', '') or item.get('hash', ''),
			}
		except:
			return None
