# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-09-25: nekoBT provider -- anime torrents, keyed on the TVDB id.
#
# WHAT NEKOBT IS
# nekobt.to is an anime tracker whose torrents are MAPPED to TVDB episodes: every torrent
# carries `media_episode_ids`, the tracker's own ids of the episodes it contains. That
# mapping is what makes this provider different from the name-reading ones -- whether a
# pack holds the episode is a lookup, not a guess from its name.
#
# PORTED FROM Otaku (plugin.video.otaku.testing/resources/lib/pages/nekobt.py), but not its
# request flow. Otaku searches /media/search by TITLE, takes the first hit when no TVDB id
# matches (a wrong show, silently), then fetches the episode list, then runs four searches.
# Here the TVDB id DeadLight already passes (data['tvdb']) replaces the title search.
#
# THE REQUEST (measured 2026-09-25, best/median of 3, no API key):
#   /torrents/search?media_id=tvdb-<id>&query=SxxEyy   1.2-1.7 s (One Piece 3.3-3.8 s)
# returns singles AND packs in one call -- Frieren S02E05 gave 28, exactly the 18 singles of
# batch=false plus the 10 packs of batch=true. Hence pack_capable = False: sources() files
# each row by its episode count, and there is no second request for packs.
#
# THREE THINGS THE MEASUREMENT FOUND, each handled below:
#   1. The hint is in TVDB numbering. One Piece TMDb S22E1100 is TVDB S22E15, and a hint
#      the tracker cannot place is IGNORED, not failed: S22E1100 returned the whole show's
#      newest 100 torrents. So the episode is mapped through the tracker's own episode list
#      first, and every row is kept only if its media_episode_ids holds the wanted episode.
#   2. Rows with NO episodes pass any hint: One Piece S22E15 came back with Film Red, Baron
#      Omatsuri and three Straw Hat Chase rips. The episode-id check drops them.
#   3. `batch` is not the pack flag: 'One Piece E0001-E1155 KOREAN' is batch=False with 1151
#      episodes. The episode count is.
#
# Also found: /media/tvdb-<id> is a 404 despite the docs; /media/resolve?id=tvdb-<id> works.
# MAL/AniList ids scope to a cour but their hint reads AniList numbering (Mushoku S2 and One
# Piece gave 0 for every form tried) -- not used. Burst limit: 429 at ~40 requests/minute,
# clears in seconds; a scrape here makes 1 request (3 on a show's first play).

import re
import threading

from magneto.modules import cache
from magneto.modules import client
from magneto.modules import source_utils

try:
	import json as _json
except ImportError:
	_json = None

_BASE = 'https://nekobt.to/api/v1'
_SEARCH = _BASE + '/torrents/search?media_id=tvdb-%s&query=%s&sort_by=seeders&limit=100' \
	'&group_secondary=true&group_parents=true&uploader_contributions=true'

_TRACKERS = (
	'https://tracker.nekobt.to/api/tracker/public/announce',
	'http://nyaa.tracker.wf:7777/announce',
	'udp://tracker.opentrackr.org:1337/announce',
	'udp://open.stealth.si:80/announce',
	'udp://tracker.torrent.eu.org:451/announce',
)

# nekoBT appends its own tag block to every title: '... [AV1] {Tags:L2;V12;C3;A=ja,en;F=en;}'.
_TAGS = re.compile(r'\s*\{Tags:[^}]*\}\s*$', re.I)


# Search timeout, 2026-09-26: 10 s let a stalled search hold the whole scrape to DeadLight's 6 s
# results.timeout (logged twice on 09-26: 0 rows, 10.4 s after dispatch; the same query gave 4
# rows earlier). 5 s clears the measured 1.2-3.5 s searches and still lands inside that window.
# The episode list keeps 10 s: it is cached a week and One Piece's alone takes 4.4 s.
_SEARCH_TIMEOUT = 5


# 2026-09-26: set when a request got NO response (timeout, connection error, 5xx), as opposed
# to an answer that says "unknown". Thread-local: episode and pack scrapes run in parallel.
_transport = threading.local()

def _get(url, timeout=10):
	response = client.request(url, timeout=timeout)
	if not response:
		_transport.failed = True
		return None
	payload = _json.loads(response)
	if not isinstance(payload, dict) or payload.get('error'): return None
	return payload.get('data')


def _episode_list(tvdb):
	"""{'media_id', 'eps': [[season, episode, id], ...]} for a TVDB series, regular episodes
	in (season, episode) order. Cached per show by the caller; None is never cached."""
	resolved = _get(_BASE + '/media/resolve?id=tvdb-%s' % tvdb) or {}
	media_id = resolved.get('media_id')
	if not media_id: return None
	media = _get(_BASE + '/media/%s' % media_id) or {}
	eps = sorted([int(e['season']), int(e['episode']), int(e['id'])]
			for e in (media.get('episodes') or [])
			if isinstance(e, dict) and e.get('season') and e.get('episode') is not None and e.get('id'))
	if not eps: return None
	return {'media_id': media_id, 'eps': eps}


def _wanted_episode(eps, data):
	"""The [season, episode, id] row of `eps` DeadLight is asking for, or None.

	Tried in order, first hit wins:
	  1. Fribb's TVDB coordinates (cour_season, season_episode) -- the numbering releases and
	     TVDB use, set when it differs from TMDb's (Re:ZERO files every cour under TMDb S1).
	  2. TMDb's own (season, episode) -- the same as TVDB's for most shows.
	  3. The series-absolute number as a position in the regular-episode list -- One Piece
	     TMDb S22E1100 is no TVDB pair, but the 1100th regular episode is TVDB S22E15.
	Only reached when 1 and 2 are not pairs the list holds, so it cannot override them.
	"""
	def _int(key):
		try: return int(data.get(key))
		except (TypeError, ValueError): return None
	by_pair = {(row[0], row[1]): row for row in eps}
	for pair in ((_int('cour_season'), _int('season_episode')), (_int('season'), _int('episode'))):
		if pair[0] and pair[1] is not None and pair in by_pair: return by_pair[pair]
	absolute = _int('absolute_episode') or _int('episode')
	if absolute and 1 <= absolute <= len(eps): return eps[absolute - 1]
	return None


class source:
	priority = 5
	# One request returns singles and packs together; see the header.
	pack_capable = False
	hasMovies = False
	hasEpisodes = True

	def __init__(self):
		self.language = ['en']
		self.base_link = 'https://nekobt.to'
		self.min_seeders = 0
		# Set when the search itself failed (timeout, 5xx, error payload) rather than found
		# nothing. DeadLight's external.py reads it and does not cache the empty result, which
		# otherwise hid the episode for an hour after a single stall.
		self.request_failed = False

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		tvdb = str(data.get('tvdb') or '').strip()
		if not tvdb.isdigit() or tvdb == '0': return sources
		_transport.failed = False
		try:
			# A week: a new episode missing from the list triggers the refetch below, so only a
			# TVDB renumbering waits it out. The list is the slow part -- One Piece's 1179
			# episodes take 4.4 s (+1.1 s resolve) against 1.2-3.5 s for the search itself.
			listing = cache.get(_episode_list, 168, tvdb)
			wanted = _wanted_episode(listing['eps'], data) if listing else None
			# A cached list predates an episode that aired since -- refetch once.
			if listing and not wanted:
				listing = cache.get(_episode_list, 0, tvdb)
				wanted = _wanted_episode(listing['eps'], data) if listing else None
			if not wanted:
				# 2026-09-26: no listing because nekoBT did not ANSWER is an outage, not "show not
				# on nekoBT" -- flag it so the empty result is not cached for an hour.
				if not listing and getattr(_transport, 'failed', False): self.request_failed = True
				import xbmc as _x
				_x.log('NEKOBT: no episode for tvdb=%s S%sE%s (abs %s) -- skipped%s'
					% (tvdb, data.get('season'), data.get('episode'), data.get('absolute_episode'),
					' (episode list FAILED, not cached)' if self.request_failed else ''), _x.LOGINFO)
				return sources
			season_of = dict((str(row[2]), row[0]) for row in listing['eps'])
			found = _get(_SEARCH % (tvdb, 'S%02dE%02d' % (wanted[0], wanted[1])), timeout=_SEARCH_TIMEOUT)
			if found is None: self.request_failed = True
			rows = (found or {}).get('results') or []
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			self.request_failed = True
			source_utils.scraper_error('NEKOBT')
			return sources

		wanted_id, seen, dropped = str(wanted[2]), set(), 0
		for row in rows:
			try:
				eids = [str(i) for i in (row.get('media_episode_ids') or [])]
				# THE check: the tracker's own mapping says this torrent holds the episode.
				if wanted_id not in eids:
					dropped += 1
					continue
				info_hash = (row.get('infohash') or '').lower()
				if len(info_hash) != 40 or info_hash in seen: continue
				package = None
				if len(eids) > 1:
					package = 'season' if len(set(season_of.get(i) for i in eids)) == 1 else 'show'
				raw = _TAGS.sub('', row.get('title') or '')
				name = source_utils.clean_name(raw)
				if not name: continue
				name_info = source_utils.info_from_name(
					name, data.get('tvshowtitle') or '', str(data.get('year') or ''),
					season=str(data.get('season') or ''), pack=package)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue
				try: seeders = max(int(row.get('seeders') or 0), 0)
				except (TypeError, ValueError): seeders = 0
				if self.min_seeders > seeders: continue
				magnet = 'magnet:?xt=urn:btih:%s&dn=%s%s' % (info_hash, name, ''.join('&tr=%s' % t for t in _TRACKERS))
				quality, info = source_utils.get_release_quality(name_info, magnet)
				# Per-episode size from the pack's OWN episode count, so nekobt is in DeadLight's
				# no-divide list (TMDb's episode_count is unrelated to what an anime pack holds).
				try: total = float(row.get('filesize') or 0) / 1073741824
				except (TypeError, ValueError): total = 0
				dsize = round(total / max(len(eids), 1), 2)
				if dsize: info.insert(0, '%.2f GB' % dsize)
				if package and total: info.append('%.1f GB pack' % total)
				seen.add(info_hash)
				item = {'provider': 'nekobt', 'source': 'torrent', 'seeders': seeders,
						'hash': info_hash, 'name': name, 'name_info': name_info, 'quality': quality,
						'language': 'en', 'url': magnet, 'info': ' | '.join(info), 'direct': False,
						'debridonly': True, 'size': dsize}
				group = source_utils.release_group(raw)
				if group: item['release_group'] = group
				if package: item['package'] = package
				sources.append(item)
			except Exception:
				source_utils.scraper_error('NEKOBT')
				continue
		try:
			import xbmc as _x
			_x.log('NEKOBT: tvdb=%s asked S%sE%s -> nekoBT S%02dE%02d (id %s): %d rows, %d not holding it, %d kept%s'
				% (tvdb, data.get('season'), data.get('episode'), wanted[0], wanted[1], wanted_id,
				len(rows), dropped, len(sources), ' (search FAILED, not cached)' if self.request_failed else ''), _x.LOGINFO)
		except Exception: pass
		return sources
