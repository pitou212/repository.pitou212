# -*- coding: utf-8 -*-
from windows.base_window import BaseDialog
# from modules.kodi_utils import logger

# LOCAL PATCH 2026-09-26: open straight on a category. Positions in the category list (control 2000)
# of settings_manager.xml, whose items carry no visibility conditions, so a position never shifts.
# Keep in step with that list's order if a category is added or moved.
CATEGORY_POSITIONS = {'external_scrapers': 6} # <item id="90">

class SettingsManager(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.control_id = None
		self.start_position = CATEGORY_POSITIONS.get(kwargs.get('category'))

	def onInit(self):
		# Runs after the XML's <onload>SetFocus(2000,0,absolute)</onload>, so this wins.
		if self.start_position is not None: self.execute_code('SetFocus(2000,%d,absolute)' % self.start_position)

	def run(self):
		self.doModal()
		self.clearProperties()

class SettingsManagerFolders(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)

	def run(self):
		self.doModal()
		self.clearProperties()
