# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-09-14: TheTVDB v4, used for artwork selection only; every picker takes TVDB's highest score (_rank).
# Facts relied on:
#   * updatedAt exists but is 0 on every artwork -- do not trust it.
#   * includesText is a real, always-populated boolean, so textless selection is not the iso_639_1-is-null guess
#     TMDb forces.
#
# Artwork type ids, from /artwork/types: 3 series/Background, 7 season/Poster, 15 movie/Background. Hardcoded to save a
# request per cold item; stable for the life of the v4 API.
import threading
import time

from caches.main_cache import main_cache
from caches.settings_cache import get_setting
from modules.kodi_utils import make_session, get_property, set_property, logger
from modules.utils import safe_err   # LOCAL PATCH 2026-10-25 (4.0.5): request errors logged without their url / query keys

_API_BASE = 'https://api4.thetvdb.com/v4'
_TIMEOUT = 10
_CACHE_HOURS = 168

_TYPE_SERIES_POSTER = 2       # LOCAL PATCH 2026-09-24: ids read from TVDB's own /artwork/types
_TYPE_MOVIE_POSTER = 14
_TYPE_SERIES_BACKGROUND = 3
_TYPE_SEASON_POSTER = 7
_TYPE_MOVIE_BACKGROUND = 15
# LOCAL PATCH 2026-09-16: ClearLogo ids, confirmed against /artwork/types. Both are SERIES/MOVIE level: TVDB has no
# season ClearLogo (season art is Banner 6, Poster 7, Background 8, Icon 10), nor has fanart.tv, so a per-season or
# per-cour logo cannot be sourced.
_TYPE_SERIES_CLEARLOGO = 23
_TYPE_MOVIE_CLEARLOGO = 25

# Bearer tokens last ~30 days. Held in a window property rather than module state because reuselanguageinvoker=false
# wipes module globals every plugin invocation.
_TOKEN_PROP = 'deadlight.tvdb_token'
_TOKEN_EXPIRY_PROP = 'deadlight.tvdb_token_expires'
_TOKEN_TTL = 20 * 24 * 3600

session = make_session(_API_BASE)


def _api_key():
	key = get_setting('deadlight.tvdb_api', '')
	return '' if key in ('empty_setting', None) else key


def _cached_token():
	try:
		cached, expires = get_property(_TOKEN_PROP), get_property(_TOKEN_EXPIRY_PROP)
		if cached and expires and time.time() < float(expires):
			return cached
	except Exception:
		pass
	return ''

# LOCAL PATCH 2026-10-20: one login at a time. A show's artworks and its season map are fetched on two threads, and with
# no token yet both would log in at once.
_LOGIN_LOCK = threading.Lock()

def _token():
	"""Cached bearer token, or '' when unavailable. A failed login is deliberately not
	cached: the key may simply be absent, and rechecking costs one request at most."""
	cached = _cached_token()
	if cached: return cached
	key = _api_key()
	if not key:
		return ''
	with _LOGIN_LOCK:
		cached = _cached_token()   # another thread logged in while this one waited
		if cached: return cached
		return _login(key)

def _login(key):
	try:
		response = session.post('%s/login' % _API_BASE, json={'apikey': key}, timeout=_TIMEOUT)
		token = ((response.json() or {}).get('data') or {}).get('token') or ''
		if not token:
			logger('TVDB', 'login returned no token (HTTP %s)' % response.status_code)
			return ''
		set_property(_TOKEN_PROP, token)
		set_property(_TOKEN_EXPIRY_PROP, str(time.time() + _TOKEN_TTL))
		return token
	except Exception as e:
		logger('TVDB login error', safe_err(e))
		return ''


def _get(path):
	"""Authorised GET returning the `data` payload, or None. A 401 drops the cached token
	so the next call re-logs in rather than spending a whole cache window on refusals."""
	token = _token()
	if not token:
		return None
	try:
		response = session.get('%s%s' % (_API_BASE, path),
							   headers={'Authorization': 'Bearer %s' % token}, timeout=_TIMEOUT)
		if response.status_code == 401:
			set_property(_TOKEN_EXPIRY_PROP, '0')
			return None
		return (response.json() or {}).get('data')
	except Exception as e:
		logger('TVDB request error', '%s: %s' % (path, safe_err(e)))
		return None


def _lookup(path):
	"""(answered, data) for a lookup whose 'not found' must be told apart from a failure. TVDB answers a search with no
	match either 200 + empty data or 404; both are an answer. No token, 401, other errors and exceptions are not."""
	token = _token()
	if not token: return False, None
	try:
		response = session.get('%s%s' % (_API_BASE, path), headers={'Authorization': 'Bearer %s' % token}, timeout=_TIMEOUT)
		if response.status_code == 401:
			set_property(_TOKEN_EXPIRY_PROP, '0')
			return False, None
		if response.status_code == 404: return True, None
		if response.status_code != 200: return False, None
		return True, (response.json() or {}).get('data')
	except Exception as e:
		logger('TVDB request error', '%s: %s' % (path, safe_err(e)))
		return False, None


# LOCAL PATCH 2026-10-03 (3.0.8): the artwork payloads through one helper (_cached_lookup):
# 1. A per-process memo. One cold show asks for its artworks up to six times (backdrop, extra backdrops, poster,
#    landscape, clearlogo, clearlogo_en), each a SELECT plus a decode of a large payload. Failures are memoed too, so a
#    dead TVDB costs one timeout per payload, not six.
# 2. An answered-but-empty result is stored as 'none' for 24 h, like _movie_id, so it is not re-asked by all six reads.
#    A failed request is never stored.
_MEMO = {}
_EMPTY = 'none'

# LOCAL PATCH 2026-10-20: one request per PATH per call, shared by the threads that ask for it. A show's artworks and its
# season map both come from /series/{id}/extended (same artworks as /artworks, plus the seasons /artworks leaves empty),
# read on two threads at once. Only an answer is shared; a failure is asked again by the next reader.
_PATH_MEMO, _PATH_LOCKS, _PATH_LOCKS_GUARD = {}, {}, threading.Lock()

def _shared_lookup(path):
	with _PATH_LOCKS_GUARD: lock = _PATH_LOCKS.setdefault(path, threading.Lock())
	with lock:
		if path in _PATH_MEMO: return _PATH_MEMO[path]
		got = _lookup(path)
		if got[0]: _PATH_MEMO[path] = got
		return got

def _cached_lookup(key, path, extract):
	if key in _MEMO: return _MEMO[key]
	result = None
	try:
		hit = main_cache.get(key)
		if hit == _EMPTY: result = extract(None)
		elif hit: result = hit
		else:
			answered, data = _shared_lookup(path)
			if answered:
				result = extract(data)
				if result: main_cache.set(key, result, expiration=_CACHE_HOURS)
				else: main_cache.set(key, _EMPTY, expiration=24)
	except Exception: result = None
	_MEMO[key] = result
	return result


def _movie_art_payload(movie_id):
	return _cached_lookup('tvdb_movieart_%s' % movie_id, '/movies/%s/extended' % movie_id,
						  lambda d: (d or {}).get('artworks') or []) or []


# Highest score, with id as the tie-break so the choice is stable when scores are equal (e.g. all season posters
# scoring 0).
def _rank(artwork):
	return (artwork.get('score') or 0, artwork.get('id') or 0)


def _pick(pool):
	return max(pool, key=_rank)


# LOCAL PATCH 2026-09-24: text-bearing art in the best language on offer -- English, then untagged, then anything else
# -- BEFORE the score picks within it; otherwise a higher-scored Japanese or Russian logo beats the English one (only
# ~2/3 of series clearlogos are 'eng'). For clearlogos, posters and season posters, which carry the title as text.
def _lang_rank(artwork):
	lang = (artwork.get('language') or '').lower()
	return 0 if lang == 'eng' else (1 if not lang else 2)


def _english_first(pool):
	if not pool:
		return pool
	best = min(_lang_rank(a) for a in pool)
	return [a for a in pool if _lang_rank(a) == best]


# LOCAL PATCH 2026-09-24: english_only -- ONLY logos tagged 'eng', or nothing. metadata._chain_art asks
# every provider for an English logo before it settles for another language anywhere.
def _logo_pool(pool, english_only=False):
	if english_only:
		return [a for a in pool if (a.get('language') or '').lower() == 'eng']
	return _english_first(pool)


# LOCAL PATCH 2026-09-15: the ranked list, not just its first entry. The artworks array is already fetched and cached
# (168h) and a well covered show carries many usable backgrounds, so N costs NO extra request; the singular accessors
# delegate here so filter and ordering have one implementation.
def _ranked_backgrounds(artworks, art_type, cap):
	backgrounds = [a for a in artworks if a.get('type') == art_type and a.get('image')]
	if not backgrounds:
		return []
	# Textless preferred; if a title has none the filter is dropped (a texted backdrop beats none). Never mixed: a texted
	# image among textless ones looks like a mistake.
	textless = [a for a in backgrounds if not a.get('includesText')]
	pool = sorted(textless or backgrounds, key=_rank, reverse=True)
	out, seen = [], set()
	for a in pool:
		url = a.get('image')
		if not url or url in seen:
			continue
		seen.add(url)
		out.append(url)
		if len(out) >= cap:
			break
	return out


def _series_artworks(tvdb_id):
	# LOCAL PATCH 2026-10-20: /extended, shared with _season_number_map (see _shared_lookup)
	return _cached_lookup('tvdb_artworks_%s' % tvdb_id, '/series/%s/extended' % tvdb_id,
						  lambda d: (d or {}).get('artworks') or []) or []


def series_backdrops(tvdb_id, cap=20):
	"""Up to `cap` TVDB series background urls, best first, or [].
	TVDB's `image` is already an absolute url."""
	if not tvdb_id or str(tvdb_id) in ('', 'None', '0'):
		return []
	try:
		return _ranked_backgrounds(_series_artworks(tvdb_id), _TYPE_SERIES_BACKGROUND, cap)
	except Exception as e:
		logger('TVDB backdrop error', safe_err(e))
		return []


def series_backdrop(tvdb_id):
	"""The single best TVDB series background url, or ''."""
	return next(iter(series_backdrops(tvdb_id, cap=1)), '')


def _season_number_map(tvdb_id):
	"""TVDB seasonId -> season number, OFFICIAL seasons only.

	Needed because artworks carry a seasonId and never a number. TVDB files several
	orderings per series -- Breaking Bad returns 13 seasons across official, dvd and
	absolute -- and only the official ones line up with the TMDb numbering used
	everywhere else here. That is also why not every season poster resolves: 86 of
	Breaking Bad's 154 belong to official seasons, the rest hang off the other orderings
	and are dropped rather than mapped to the wrong season."""
	def _extract(data):
		seasons = (data or {}).get('seasons') or []
		return {str(s['id']): s.get('number') for s in seasons
				if s.get('id') is not None and (s.get('type') or {}).get('type') == 'official'}
	# LOCAL PATCH 2026-10-20: the full /extended (not ?short=true), the SAME request _series_artworks makes (_shared_lookup),
	# so one request answers both.
	return _cached_lookup('tvdb_seasonmap_%s' % tvdb_id, '/series/%s/extended' % tvdb_id, _extract) or {}


def season_posters_cached(tvdb_id):
	"""LOCAL PATCH 2026-10-20: season_posters() when both of its payloads are already cached, else None -- never a request.
	A season list uses this and leaves a cold show's TVDB art to a job run after the list is shown (user's call)."""
	if not tvdb_id or str(tvdb_id) in ('', 'None', '0'): return {}
	try:
		for key in ('tvdb_seasonmap_%s' % tvdb_id, 'tvdb_artworks_%s' % tvdb_id):
			if key not in _MEMO and main_cache.get(key) is None: return None
	except Exception: return None
	return season_posters(tvdb_id)


def season_posters(tvdb_id):
	"""{season number: image url} from TVDB, or {}.

	Unlike backgrounds, includesText is NOT filtered on here: a season poster carries the
	season name by design and Breaking Bad's are text-bearing almost without exception, so
	filtering would return nothing at all."""
	if not tvdb_id or str(tvdb_id) in ('', 'None', '0'):
		return {}
	try:
		# LOCAL PATCH 2026-10-20: the artworks list fetched WHILE the season numbering is -- two cold sequential requests (each
		# a fresh TLS connection) were most of a first anime season list. Both are cached a week (_cached_lookup).
		from threading import Thread
		_art = {}
		_fetch = Thread(target=lambda: _art.update(rows=_series_artworks(tvdb_id)))
		_fetch.start()
		numbers = _season_number_map(tvdb_id)
		_fetch.join(_TIMEOUT * 2)   # a login plus the request, at most
		if not numbers:
			return {}
		best = {}
		for artwork in _art.get('rows') or []:
			if artwork.get('type') != _TYPE_SEASON_POSTER or not artwork.get('image'):
				continue
			number = numbers.get(str(artwork.get('seasonId')))
			if number is None:
				continue
			current = best.get(number)
			# LOCAL PATCH 2026-09-24: language first (see _english_first), then the score.
			if current is None or _lang_rank(artwork) < _lang_rank(current) or (
					_lang_rank(artwork) == _lang_rank(current) and artwork is _pick([artwork, current])):
				best[number] = artwork
		return {n: a['image'] for n, a in best.items()}
	except Exception as e:
		logger('TVDB season posters error', safe_err(e))
		return {}


def _movie_id(imdb_id):
	"""TVDB movie id for an IMDb id, or ''. Movies need this hop because TVDB is the only
	provider here not already keyed by an id the add-on holds; shows do not, since tvdb_id
	comes free from TMDb's external_ids."""
	# LOCAL PATCH 2026-10-02: remember a definite 'TVDB has no such movie' for a day, or each artwork read re-sends
	# /search/remoteid on one cold build (common for regional films). A failure is not cached; an answer without a movie is,
	# for 24 h rather than _CACHE_HOURS, so a new TVDB entry shows soon.
	key = 'tvdb_movieid_%s' % imdb_id
	if key in _MEMO: return _MEMO[key]   # LOCAL PATCH 2026-10-03 (3.0.8): see _cached_lookup
	_MEMO[key] = _movie_id_uncached(key, imdb_id)
	return _MEMO[key]


def _movie_id_uncached(key, imdb_id):
	try:
		hit = main_cache.get(key)
		if hit: return '' if hit == _NO_TVDB_MOVIE else hit
		answered, entries = _lookup('/search/remoteid/%s' % imdb_id)
		if not answered: return ''   # request failed: ask again next time
		for entry in (entries or []):
			movie = entry.get('movie')
			if movie and movie.get('id'):
				main_cache.set(key, str(movie['id']), expiration=_CACHE_HOURS)
				return str(movie['id'])
		main_cache.set(key, _NO_TVDB_MOVIE, expiration=24)
	except Exception: pass
	return ''

_NO_TVDB_MOVIE = 'none'


def movie_backdrops(imdb_id, cap=20):
	"""Up to `cap` TVDB movie background urls, best first, or []. Two cached requests on a
	cold item: the remoteid lookup, then /movies/{id}/extended -- movie artworks live there,
	as there is no /movies/{id}/artworks counterpart to the series endpoint."""
	if not imdb_id or str(imdb_id) in ('', 'None', 'tt0000000'):
		return []
	try:
		movie_id = _movie_id(imdb_id)
		if not movie_id:
			return []
		artworks = _movie_art_payload(movie_id)
		return _ranked_backgrounds(artworks, _TYPE_MOVIE_BACKGROUND, cap)
	except Exception as e:
		logger('TVDB movie backdrop error', safe_err(e))
		return []


def movie_backdrop(imdb_id):
	"""The single best TVDB movie background url, or ''."""
	return next(iter(movie_backdrops(imdb_id, cap=1)), '')


# LOCAL PATCH 2026-09-16: clearlogos follow the same provider setting as the backdrops. No extra request: the series and
# movie artworks payloads are already cached for the backdrops.
#
# includesText is deliberately not filtered, unlike backgrounds: a clearlogo IS the title rendered as artwork, so
# filtering returns nothing.
def series_clearlogo(tvdb_id, english_only=False):
	"""The best TVDB series clearlogo url, or ''."""
	if not tvdb_id or str(tvdb_id) in ('', 'None', '0'):
		return ''
	try:
		pool = _logo_pool([a for a in _series_artworks(tvdb_id)
				if a.get('type') == _TYPE_SERIES_CLEARLOGO and a.get('image')], english_only)
		return _pick(pool)['image'] if pool else ''
	except Exception as e:
		logger('TVDB series clearlogo error', safe_err(e))
		return ''


def movie_clearlogo(imdb_id, english_only=False):
	"""The best TVDB movie clearlogo url, or ''."""
	if not imdb_id or str(imdb_id) in ('', 'None', 'tt0000000'):
		return ''
	try:
		movie_id = _movie_id(imdb_id)
		if not movie_id:
			return ''
		artworks = _movie_art_payload(movie_id)
		pool = _logo_pool([a for a in artworks if a.get('type') == _TYPE_MOVIE_CLEARLOGO and a.get('image')], english_only)
		return _pick(pool)['image'] if pool else ''
	except Exception as e:
		logger('TVDB movie clearlogo error', safe_err(e))
		return ''


# LOCAL PATCH 2026-09-24: posters and landscapes, so TVDB can stand in for any title artwork in the provider chain
# (metadata._chain_art). Same cached payloads -- no extra request.
def _movie_artworks(imdb_id):
	movie_id = _movie_id(imdb_id)
	if not movie_id:
		return []
	return _movie_art_payload(movie_id)


def _best_image(artworks, art_type, english=True):
	pool = [a for a in artworks if a.get('type') == art_type and a.get('image')]
	if english:
		pool = _english_first(pool)
	return _pick(pool)['image'] if pool else ''


# TVDB has no 'landscape' (fanart.tv's thumb: a backdrop with the title on it). The nearest is a background that carries
# text, English first; '' when a title has none, and the caller's chain moves on.
def _best_landscape(artworks, art_type):
	pool = _english_first([a for a in artworks if a.get('type') == art_type and a.get('image') and a.get('includesText')])
	return _pick(pool)['image'] if pool else ''


def series_poster(tvdb_id):
	if not tvdb_id or str(tvdb_id) in ('', 'None', '0'):
		return ''
	try: return _best_image(_series_artworks(tvdb_id), _TYPE_SERIES_POSTER)
	except Exception as e:
		logger('TVDB series poster error', safe_err(e))
		return ''


def movie_poster(imdb_id):
	if not imdb_id or str(imdb_id) in ('', 'None', 'tt0000000'):
		return ''
	try: return _best_image(_movie_artworks(imdb_id), _TYPE_MOVIE_POSTER)
	except Exception as e:
		logger('TVDB movie poster error', safe_err(e))
		return ''


def series_landscape(tvdb_id):
	if not tvdb_id or str(tvdb_id) in ('', 'None', '0'):
		return ''
	try: return _best_landscape(_series_artworks(tvdb_id), _TYPE_SERIES_BACKGROUND)
	except Exception as e:
		logger('TVDB series landscape error', safe_err(e))
		return ''


def movie_landscape(imdb_id):
	if not imdb_id or str(imdb_id) in ('', 'None', 'tt0000000'):
		return ''
	try: return _best_landscape(_movie_artworks(imdb_id), _TYPE_MOVIE_BACKGROUND)
	except Exception as e:
		logger('TVDB movie landscape error', safe_err(e))
		return ''
