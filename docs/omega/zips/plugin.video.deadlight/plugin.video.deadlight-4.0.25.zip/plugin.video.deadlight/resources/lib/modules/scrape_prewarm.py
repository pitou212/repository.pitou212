# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-06: warm an anime episode's scrape ids once its episode list is on screen.
#
# Before dispatching any provider, scrapers/external.results works out the anime ids (Fribb, AniList, ani.zip); all are
# cached, but a show's first scrape waits ~1 s on them. So build_episode_list queues the episodes most likely played
# next (first aired unwatched, newest aired), deadlight.py starts run() on a thread once routing() has returned (beside
# the rating backfills), and run() executes the same results() code with warm_only set, which returns just before
# get_sources: no provider, no results cache, no dialog.
#
# Only in-addon browsing (never a widget or skin call) and only anime (metadata.is_anime_meta, the scrape's own test).
_PENDING = None

def queue(meta, episodes, anime=True, tvdb_pairs=None):
	"""episodes: [(season, episode, ep_name, premiered), ...], warmed in order; a repeat is warmed once. anime=False: Direct
	Streams only (LOCAL PATCH 2026-11-05). tvdb_pairs: [(season, episode), ...] whose TVDB episode ids to fetch (anime only;
	LOCAL PATCH 2026-11-08, see _warm_tvdb_ids)."""
	global _PENDING
	_PENDING = (meta, episodes, anime, tvdb_pairs or [])


# LOCAL PATCH 2026-11-08: TMDb's TVDB id of each episode in the list (apis.tmdb_api.episode_tvdb_id), fetched while the list is on
# screen. An anime scrape needs it before any provider starts -- the Stremio numbering for HDHub / pengu.uk (episode_card.
# stremio_pair) and the AniDB episode join (episode_card.entry_episode) -- and TMDb has no bulk form: one ~0.7 s request per
# episode. The id does not change, so it is cached a year. At most _TVDB_CAP per list, nearest the next unwatched first,
# 4 at a time.
_TVDB_CAP = 30

def _warm_tvdb_ids(show, pairs, monitor):
	import time
	from concurrent.futures import ThreadPoolExecutor
	from apis.tmdb_api import episode_tvdb_id
	from modules import kodi_utils
	tmdb_id, start = show.get('tmdb_id'), time.time()
	pairs = list(dict.fromkeys(pairs))[:_TVDB_CAP]
	def _one(pair):
		if monitor.abortRequested(): return None
		try: return episode_tvdb_id(tmdb_id, pair[0], pair[1])
		except Exception: return None
	with ThreadPoolExecutor(4) as pool: found = list(pool.map(_one, pairs))
	kodi_utils.logger('scrape prewarm', 'tmdb %s: TVDB episode ids for %d episode(s) in %.2f s (%d known)' % (tmdb_id, len(pairs),
		time.time() - start, sum(1 for f in found if f)))


# LOCAL PATCH 2026-11-05: Direct Streams (HDHub, the Stremio addon) asked for the same two episodes, any show -- HDHub answers
# an episode it has not served lately slower than the scrape waits, and fast once asked. The scrape's own search_info is
# rebuilt, so a complete answer lands in the 30-minute results cache http_streams.results reads; an incomplete one is not
# cached, and HDHub's side is warm anyway.
def _warm_direct_streams(show, season, episode, ep_name, premiered):
	import time
	start = time.time()
	try:
		from caches.settings_cache import get_setting
		if get_setting('deadlight.provider.http_streams', 'false') != 'true': return
		from modules import source_utils, kodi_utils
		from modules.utils import safe_string, remove_accents
		from scrapers.http_streams import source as http_source
		title = show.get('english_title') or show.get('title') or ''
		try: ep_name = safe_string(remove_accents(ep_name))
		except Exception: ep_name = safe_string(ep_name)
		info = {'media_type': 'episode', 'title': title, 'year': show.get('year'), 'tmdb_id': show.get('tmdb_id'), 'imdb_id': show.get('imdb_id'),
				'aliases': source_utils.make_alias_dict(show, title), 'season': int(season), 'episode': int(episode), 'tvdb_id': show.get('tvdb_id'),
				'ep_name': ep_name, 'premiered': str(premiered or '')[:10]}
		try: info['episode_candidates'] = source_utils.anime_episode_candidates(show, show.get('tmdb_id'), int(season), int(episode))
		except Exception: pass
		rows = http_source().results(info)
		kodi_utils.logger('scrape prewarm', 'tmdb %s S%sE%s Direct Streams in %.2f s: %d' % (show.get('tmdb_id'), season, episode, time.time() - start, len(rows or [])))
	except Exception as e:
		try:
			from modules import kodi_utils
			kodi_utils.logger('scrape prewarm', 'Direct Streams S%sE%s failed: %r' % (season, episode, e))
		except Exception: pass

def _warm_tosho_packs(data, done, monitor):
	"""LOCAL PATCH 2026-11-04: AnimeTosho's pack lists for the episode's AniDB ids, into the cache the provider reads
	(animetosho._aid_packs, 3 days; it helps in-addon browsing only -- a widget click scrapes at once). AnimeTosho takes ~1 s to answer a query it has not served lately and a split season asks
	once per part -- TYBW's packs landed 4.8 s into the scrape (log 14:15:42) -- so they are fetched here, on this thread, while
	the episode list is on screen. Only with AnimeTosho switched on, at most 4 ids, each once per run; a cached list costs a cache
	read. Returns the ids fetched (for the log line), or ''."""
	try:
		from magneto import enabledCheck
		if not enabledCheck('animetosho'): return ''
		aids = []
		for a in [data.get('anidb_aid')] + list(data.get('anidb_part_aids') or []):
			try:
				if a and int(a) not in aids: aids.append(int(a))
			except (TypeError, ValueError): continue
		aids = [a for a in aids[:4] if ('tosho', a) not in done]
		if not aids: return ''
		from magneto.providers.torrents.animetosho import source as tosho
		provider = tosho()
		for a in aids:
			if monitor.abortRequested(): break
			done.add(('tosho', a))
			provider._aid_packs(a)
		return ','.join(str(a) for a in aids)
	except Exception: return ''


def _warm_comet(data, season, episode):
	"""LOCAL PATCH 2026-11-06: comet's Kitsu + IMDb requests for the episode, so comet's own search is done before the click
	(see comet.source.warm). Only with comet switched on and for an episode the scrape asks by Kitsu id."""
	import time
	start = time.time()
	try:
		from magneto import enabledCheck
		if not enabledCheck('comet') or not data.get('kitsu_id') or data.get('cour_episode') is None: return
		from magneto.providers.torrents.comet import source as comet
		asked = comet().warm(data)
		from modules import kodi_utils
		kodi_utils.logger('scrape prewarm', 'S%sE%s comet: %d request(s) in %.2f s' % (season, episode, asked, time.time() - start))
	except Exception: pass


def run():
	global _PENDING
	pending, _PENDING = _PENDING, None
	if not pending: return
	import time
	from modules import kodi_utils
	monitor = kodi_utils.kodi_monitor()
	if kodi_utils.external() or monitor.abortRequested(): return
	show, episodes, anime, tvdb_pairs = pending
	import threading
	if anime and tvdb_pairs:   # LOCAL PATCH 2026-11-08: beside everything below (its own thread; deadlight.py's exit wait joins it)
		try: threading.Thread(target=_warm_tvdb_ids, args=(show, tvdb_pairs, monitor), name='prewarm_tvdb').start()
		except Exception: pass
	# LOCAL PATCH 2026-11-05: Direct Streams first, each episode on its own thread (deadlight.py's exit wait joins them): HDHub's
	# slow first answer is the long pole, and the anime id warm below must not hold it back
	import threading
	seen = set()
	for season, episode, ep_name, premiered in episodes:
		if (season, episode) in seen or not season: continue   # not specials: their scrape is renumbered (cinemeta.special_episode)
		seen.add((season, episode))
		try: threading.Thread(target=_warm_direct_streams, args=(show, season, episode, ep_name, premiered), name='prewarm_direct').start()
		except Exception: pass
	if not anime: return
	try: from scrapers.external import source
	except Exception as e: return kodi_utils.logger('scrape prewarm', 'failed: %r' % e)
	done = set()
	for season, episode, ep_name, _premiered in episodes:
		if (season, episode) in done or monitor.abortRequested(): continue
		done.add((season, episode))
		start = time.time()
		try:
			meta = dict(show, season=season, episode=episode, ep_name=ep_name, media_type='episode', background=False)
			info = {'media_type': 'episode', 'title': meta.get('title') or '', 'year': meta.get('year') or '', 'tmdb_id': meta.get('tmdb_id'),
					'imdb_id': meta.get('imdb_id'), 'tvdb_id': meta.get('tvdb_id'), 'aliases': [], 'season': season, 'episode': episode,
					'ep_name': ep_name or '', 'expiry_times': (0, 0, 0), 'total_seasons': meta.get('total_seasons', 1)}
			warm = source(meta, [('prewarm', None)], [], False, [], [], None)
			warm.warm_only = True
			data = warm.results(info) or {}
			try: threading.Thread(target=_warm_comet, args=(data, season, episode), name='prewarm_comet').start()
			except Exception: pass
			packs = _warm_tosho_packs(data, done, monitor)
			kodi_utils.logger('scrape prewarm', 'tmdb %s S%sE%s in %.2f s: kitsu %s ep %s, anidb eid %s, anilist %s%s' % (meta.get('tmdb_id'),
				season, episode, time.time() - start, data.get('kitsu_id'), data.get('cour_episode'), data.get('anidb_eid'), data.get('anilist_id'),
				', animetosho packs %s' % packs if packs else ''))
		except Exception as e: kodi_utils.logger('scrape prewarm', 'S%sE%s failed: %r' % (season, episode, e))
