# -*- coding: utf-8 -*-
from caches.base_cache import connect_database, get_timestamp, cache_ttl, single_flight
from modules.kodi_utils import get_property, set_property, clear_property

# LOCAL PATCH 2026-08-26 (perf): JSON instead of repr()/eval() for cached blobs: json.loads is ~13x faster than eval
# and never executes stored data. Not literal_eval on the hot path: slower than eval; it only reads legacy rows.
# Other caches still use repr/eval deliberately: colder, and each needs its own shape audit first.
# Shape changes JSON forces: int dict keys become strings (metadata.season_trailer_for accepts either) and tuples
# become lists (meta['studio']; setStudios takes either).
# LOCAL PATCH 2026-10-19: the two helpers are base_cache's.
from caches.base_cache import _loads, _dumps


class MetaCache:
	# LOCAL PATCH 2026-11-08: rows read in one query for a whole list (prefetch); {(db_type, tmdb_id): (meta text, expires)}.
	# Per process, so per list build: a plugin process builds one list and ends.
	_prefetched = {}

	def prefetch(self, media_type, media_ids):
		"""LOCAL PATCH 2026-11-08: read the cached metas of a list's TMDb ids in one query per 500, on the calling thread,
		before its builder pool starts, instead of one query per row on its own thread connection. get() answers TMDb-id
		reads from these; nothing is decoded until a row asks.
		Returns (cached and unexpired, asked) -- the caller sizes its thread pool by it."""
		hits, ids = 0, []
		try:
			ids = sorted(set(str(i) for i in media_ids if i not in (None, '', 'None')))
			if len(ids) < 2: return 0, len(ids)
			dbcon, now = connect_database('metacache_db'), get_timestamp()
			for start in range(0, len(ids), 500):
				chunk = ids[start:start + 500]
				for tmdb_id, meta, expires in dbcon.execute('SELECT tmdb_id, meta, expires FROM metadata WHERE db_type = ? AND tmdb_id IN (%s)'
						% ','.join('?' * len(chunk)), [media_type] + chunk).fetchall():
					self._prefetched[(media_type, tmdb_id)] = (meta, expires)
					if expires > now: hits += 1
		except Exception: pass
		return hits, len(ids)

	def get(self, media_type, id_type, media_id, current_time=None):
		meta = None
		try:
			media_id = str(media_id)
			if not current_time: current_time = get_timestamp()
			if id_type == 'tmdb_id' and self._prefetched:
				hit = self._prefetched.get((media_type, media_id))
				if hit is not None and hit[1] > current_time:
					try: return _loads(hit[0])
					except Exception: pass   # an odd row: the usual path below decides
			meta = self.get_memory_cache(media_type, id_type, media_id, current_time)
			if meta is None:
				dbcon = connect_database('metacache_db')
				cache_data = dbcon.execute('SELECT meta, expires FROM metadata WHERE db_type = ? AND %s = ?' % id_type, (media_type, media_id)).fetchone()
				if cache_data:
					meta, expiry = _loads(cache_data[0]), cache_data[1]
					if expiry <= current_time:
						self.delete(media_type, id_type, media_id, meta=meta, keep_lasting_seasons=True)
						meta = None
					else: self.set_memory_cache(media_type, id_type, meta, expiry, media_id)
		except: pass
		return meta

	def get_season(self, prop_string):
		meta = None
		try:
			current_time = get_timestamp()
			meta = self.get_memory_cache_season(prop_string, current_time)
			if meta is None:
				dbcon = connect_database('metacache_db')
				cache_data = dbcon.execute('SELECT meta, expires FROM season_metadata WHERE tmdb_id = ?', (prop_string,)).fetchone()
				if cache_data:
					meta, expiry = _loads(cache_data[0]), cache_data[1]
					if expiry <= current_time:
						self.delete_season(prop_string)
						meta = None
					else: self.set_memory_cache_season(prop_string, meta, expiry)
		except: pass
		return meta

	def set(self, media_type, id_type, meta, expiration=168, current_time=None):
		try: self._prefetched.pop((media_type, str(meta.get('tmdb_id'))), None)   # LOCAL PATCH 2026-11-08: a rewritten row is read again
		except Exception: pass
		try:
			dbcon = connect_database('metacache_db')
			meta_get = meta.get
			if current_time: expires = current_time + (expiration*3600)
			else: expires = get_timestamp(expiration)
			media_id = str(meta_get(id_type))
			dbcon.execute('INSERT OR REPLACE INTO metadata VALUES (?, ?, ?, ?, ?, ?)',
				(media_type, str(meta_get('tmdb_id')), meta_get('imdb_id'), str(meta_get('tvdb_id')), _dumps(meta), expires))
		except: return None
		self.set_memory_cache(media_type, id_type, meta, expires, media_id)
		# LOCAL PATCH 2026-10-03 (Batch 3): the same item cached under its other ids is now stale (a backfill writes
		# through the TMDb id; a stale IMDb-keyed copy re-runs the OMDb backfill on every read).
		for other in ('tmdb_id', 'imdb_id', 'tvdb_id'):
			if other != id_type and meta_get(other): self.delete_memory_cache(media_type, other, str(meta_get(other)))

	def set_season(self, prop_string, meta, expiration=168):
		try:
			dbcon = connect_database('metacache_db')
			expires = get_timestamp(expiration)
			# LOCAL PATCH 2026-08-31: OR REPLACE: tmdb_id is `not null unique`, and a plain INSERT's IntegrityError is
			# swallowed by the bare except. Two widget processes (one per widget) can race the same cold key.
			dbcon.execute('INSERT OR REPLACE INTO season_metadata VALUES (?, ?, ?)', (prop_string, _dumps(meta), int(expires)))
		except: return None
		self.set_memory_cache_season(prop_string, meta, expires)

	def delete(self, media_type, id_type, media_id, meta=None, keep_lasting_seasons=False):
		# LOCAL PATCH 2026-11-08: a deleted row is not answered from the prefetch (by another id type: drop them all, rare)
		if self._prefetched:
			if id_type == 'tmdb_id': self._prefetched.pop((media_type, str(media_id)), None)
			else: self._prefetched.clear()
		try:
			dbcon = connect_database('metacache_db')
			dbcon.execute('DELETE FROM metadata WHERE db_type = ? AND %s = ?' % id_type, (media_type, media_id))
			for item in ('tmdb_id', 'imdb_id', 'tvdb_id'): self.delete_memory_cache(media_type, item, meta[item])
			if media_type == 'tvshow':
				# LOCAL PATCH 2026-10-03: the seasons actually cached, found in one query and keyed by the TMDb id (media_id
				# may be an IMDb/TVDB id). Not season_data: a cached season can be newer than the stored list.
				self.delete_seasons(meta.get('tmdb_id') or media_id, keep_lasting_seasons)
		except: return

	# LOCAL PATCH 2026-10-15: keep_lasting_seasons -- when a show's meta merely EXPIRES, seasons cached for more than ~8
	# days more are kept: finished seasons (4368 h, metadata._season_expiration) the new show meta cannot change; dropping
	# them sends every watched show's widget tile back to TMDb daily. Airing seasons (96 h / 6 h) still go with the show;
	# a user's Refresh (base_cache.refresh_cached_data) still clears all.
	def delete_seasons(self, tmdb_id, keep_lasting_seasons=False):
		try:
			dbcon = connect_database('metacache_db')
			prefix = '%s_' % tmdb_id
			if keep_lasting_seasons:
				keys = [r[0] for r in dbcon.execute('SELECT tmdb_id FROM season_metadata WHERE substr(tmdb_id, 1, ?) = ? AND CAST(expires AS INTEGER) < ?',
					(len(prefix), prefix, get_timestamp(200))).fetchall()]
			else: keys = [r[0] for r in dbcon.execute('SELECT tmdb_id FROM season_metadata WHERE substr(tmdb_id, 1, ?) = ?', (len(prefix), prefix)).fetchall()]
			if keys: dbcon.execute('DELETE FROM season_metadata WHERE tmdb_id IN (%s)' % ','.join('?' * len(keys)), keys)
		except: return
		for key in keys:
			try: self.delete_memory_cache_season(key)
			except: pass

	def delete_season(self, prop_string):
		try:
			dbcon = connect_database('metacache_db')
			dbcon.execute('DELETE FROM season_metadata WHERE tmdb_id = ?', (prop_string,))
			self.delete_memory_cache_season(prop_string)
		except: return

	def get_memory_cache(self, media_type, id_type, media_id, current_time):
		result = None
		try:
			prop_string = 'deadlight.%s_%s_%s' % (media_type, id_type, media_id)
			cachedata = _loads(get_property(prop_string))
			if cachedata[0] > current_time: result = cachedata[1]
		except: result = None
		return result

	def get_memory_cache_season(self, prop_string, current_time):
		result = None
		try:
			cachedata = _loads(get_property('deadlight.meta_season_%s' % prop_string))
			if cachedata[0] > current_time: result = cachedata[1]
		except: result = None
		return result

	def set_memory_cache(self, media_type, id_type, meta, expires, media_id):
		try:
			cachedata, prop_string = (expires, meta), 'deadlight.%s_%s_%s' % (media_type, id_type, media_id)
			set_property(prop_string, _dumps(cachedata))
		except: pass

	def set_memory_cache_season(self, prop_string, meta, expires):
		try:
			cachedata = (expires, meta)
			set_property('deadlight.meta_season_%s' % prop_string, _dumps(cachedata))
		except: pass

	def delete_memory_cache(self, media_type, id_type, media_id):
		try: clear_property('deadlight.%s_%s_%s' % (media_type, id_type, media_id))
		except: pass

	def delete_memory_cache_season(self, prop_string):
		try: clear_property('deadlight.meta_season_%s' % prop_string)
		except: pass

	def get_function(self, prop_string):
		result = None
		try:
			dbcon = connect_database('metacache_db')
			current_time = get_timestamp()
			cache_data = dbcon.execute('SELECT string_id, data, expires FROM function_cache WHERE string_id = ?', (prop_string,)).fetchone()
			if cache_data:
				if cache_data[2] >= current_time: result = _loads(cache_data[1])
				else: dbcon.execute('DELETE FROM function_cache WHERE string_id = ?', (prop_string,))
		except: pass
		return result

	def set_function(self, prop_string, result, expiration=24):
		try:
			dbcon = connect_database('metacache_db')
			expires = get_timestamp(expiration)
			# LOCAL PATCH 2026-08-31: OR REPLACE -- string_id is `not null unique`; see set_season.
			dbcon.execute('INSERT OR REPLACE INTO function_cache VALUES (?, ?, ?)', (prop_string, _dumps(result), expires))
		except: return


	def delete_all(self):
		self._prefetched.clear()   # LOCAL PATCH 2026-11-08
		try:
			dbcon = connect_database('metacache_db')
			# LOCAL PATCH 2026-10-03 (Batch 3): all three ids, or an item read by IMDb / TVDB id keeps answering from
			# its window property.
			for i in dbcon.execute('SELECT db_type, tmdb_id, imdb_id, tvdb_id FROM metadata').fetchall():
				for id_type, value in zip(('tmdb_id', 'imdb_id', 'tvdb_id'), i[1:]):
					if value:
						try: self.delete_memory_cache(str(i[0]), id_type, str(value))
						except: pass
			for i in dbcon.execute('SELECT tmdb_id FROM season_metadata'):
				try: self.delete_memory_cache_season(str(i[0]))
				except: pass
			for i in ('metadata', 'season_metadata', 'function_cache'): dbcon.execute('DELETE FROM %s' % i)
			dbcon.execute('VACUUM')
		except: return

	def clean_database(self):
		try:
			dbcon = connect_database('metacache_db')
			for table in ('metadata', 'function_cache', 'season_metadata'):
				dbcon.execute('DELETE from %s WHERE CAST(expires AS INT) <= ?' % table, (get_timestamp(),))
			dbcon.execute('VACUUM')
			return True
		except: return False

meta_cache = MetaCache()

def cache_function(function, prop_string, url, expiration=720, json=True):
	data = meta_cache.get_function(prop_string)
	if data: return data
	with single_flight('meta:' + prop_string):   # LOCAL PATCH 2026-11-08: one fetch per key (base_cache.single_flight)
		data = meta_cache.get_function(prop_string)
		if data: return data
		if json: result = function(url).json()
		else: result = function(url)
		# LOCAL PATCH 2026-10-03 (Batch 3): base_cache.cache_ttl -- refusals are not stored, empties at most 0.3 h
		expiration = cache_ttl(result, expiration)
		if expiration: meta_cache.set_function(prop_string, result, expiration=expiration)
		return result

def delete_meta_cache(silent=False):
	from modules.kodi_utils import confirm_dialog
	try:
		if not silent and not confirm_dialog(): return False
		meta_cache.delete_all()
		return True
	except: return False
