# -*- coding: utf-8 -*-
import re
import time
import json
import random
from threading import Thread, Lock
from caches.external_cache import external_cache
from caches.settings_cache import get_setting
from modules.settings import diag_timing   # LOCAL PATCH 2026-11-02: the timing lines' switch
from modules import kodi_utils, source_utils
from modules.debrid import RD_check, PM_check, AD_check ,TB_check, query_local_cache, query_local_cache_files
from modules.source_utils import ANIME_PROVIDERS, anime_providers_to_run
from modules.metadata import is_anime_meta   # LOCAL PATCH 2026-11-01 (cleanup): source_utils forwarder removed

# LOCAL PATCH 2026-10-25 (4.0.5): base32 infohash -> 40-char lowercase hex, None when it is not one (see process_results)
def _b32_hash(_hash):
	if len(_hash) != 32: return None
	try:
		from base64 import b32decode
		return b32decode(_hash.upper()).hex()
	except Exception: return None

# LOCAL PATCH 2026-10-25 (4.0.5): per-row / per-provider traces (scrape.pack_found, fake filter, scrape.anime_gate) log
# through kodi_utils.logger_debug -- Kodi DEBUG level, out of a normal kodi.log.
def _log_trace(tag, what):
	try:
		import traceback
		kodi_utils.logger(tag, '%s: %s' % (what, traceback.format_exc()))
	except Exception: pass

# LOCAL PATCH 2026-09-24: the listing readers used by _real_pack_sizes' probe
# (listing_episode_numbers, listing_episode_pairs) live in source_utils beside the matcher.

# LOCAL PATCH 2026-10-01: '+' is a separator in the display name ('Dub.+.MVO') except where it is part of the tag:
# HDR10+, DD+, TV+ / Disney+ / Paramount+.
# LOCAL PATCH 2026-10-16: a resolution a file name states outright -- only those can contradict a row's (see _mislabelled)
_PACK_FILL_LOCK = Lock()
_RESOLUTION_TOKEN = re.compile(r'(?i)(?<![a-z0-9])(?:2160p|1080p|720p|576p|480p|4k|uhd)(?![a-z0-9])')
_PLUS_SEPARATOR = re.compile(r'(?i)(?<!hdr10)(?<!dd)(?<!tv)(?<!disney)(?<!paramount)\+')
# LOCAL PATCH 2026-10-05: an episode range in a FILE name ('S01E12-E17', 'E12~E17'), see _real_pack_sizes
_RE_FILE_RANGE = re.compile(r'(?i)(?<![a-z0-9])(?:s\d{1,2})?e(\d{1,4})(?:[-~]e?|\s*[-~]\s*e)(\d{1,4})(?!\d)')
# LOCAL PATCH 2026-10-16: the seasons a pack's file names state ('S02E01'), to call a found pack 'show' or 'season'
_RE_FILE_SEASON = re.compile(r'(?i)(?<![a-z0-9])s(\d{1,2})[ ._-]?e\d{1,4}(?!\d)')

def _info_score(item):
	"""LOCAL PATCH 2026-10-02: which copy of a hash several providers listed is kept (see _process_duplicates).
	Higher wins; equal scores keep the copy that arrived first. Every copy is the SAME torrent, so only what the
	provider says about it differs: item['extraInfo'] ('HEVC | WEB | DD+ | 6CH', the tags read from its name),
	item['name'], item['size'] (GB, float), item.get('seeders') (absent on some providers)."""
	# tags first (more read from the name = more told), then the longer name: it usually still carries the group
	tags = len([t for t in (item.get('extraInfo') or '').split(' | ') if t])
	return (tags, len(item.get('name') or ''))

class source:
	def __init__(self, meta, source_dict, active_debrid, external_cache_check, internal_scrapers, prescrape_sources, progress_dialog, disabled_ext_ignored=False,
				 count_filter=None, all_scrapers=False):
		self.monitor = kodi_utils.kodi_monitor()
		self.scrape_provider = 'external'
		self.progress_dialog = progress_dialog
		self.external_cache_check = external_cache_check
		# LOCAL PATCH 2026-10-03 (Batch 3): "Disable All Filters" scrapes neither read nor write the results cache: the
		# cache holds FILTERED rows, and an unfiltered result would be served to the next normal scrape.
		self.filterless = kodi_utils.get_property('fs_filterless_search') == 'true'
		self.meta = meta
		self.background = self.meta.get('background', False)
		self.active_debrid = active_debrid
		self.source_dict, self.host_dict = source_dict, []
		self.sources, self.all_internal_sources, self.processed_internal_scrapers = [], [], []
		self.processed_internal_scrapers_append = self.processed_internal_scrapers.append
		self.internal_scrapers, self.prescrape_sources = internal_scrapers, prescrape_sources
		self.internal_activated, self.internal_prescraped = len(self.internal_scrapers) > 0, len(self.prescrape_sources) > 0
		self.processed_prescrape, self.threads_completed = False, False
		self.provider_counts = {}   # LOCAL PATCH 2026-09-27: per-provider rows in the loading window
		self.provider_failed = set()   # LOCAL PATCH 2026-09-27: providers that came back empty because they FAILED (_scrape)
		self.timeout = 60 if disabled_ext_ignored else int(get_setting('deadlight.results.timeout', '20'))
		self.all_scrapers = all_scrapers   # LOCAL PATCH 2026-10-04: 'Rescrape With All Scrapers' only (sources.all_scrapers_retry), see _is_not_for_anime_skipped
		self.sources_total = self.sources_4k = self.sources_1080p = self.sources_720p = self.sources_sd = 0
		self.final_total = self.final_4k = self.final_1080p = self.final_720p = self.final_sd = 0
		# LOCAL PATCH 2026-09-30: the window counts each release once and only what the list will show; the search
		# phase and the cache-check phase count separately (source_utils.WindowCounter, sources._window_countable)
		self.counter, self.counter_final = source_utils.WindowCounter(count_filter), source_utils.WindowCounter(count_filter)
		self.count_tuple = (('sources_4k', '4K', self._quality_length), ('sources_1080p', '1080p', self._quality_length), ('sources_720p', '720p', self._quality_length),
							('sources_sd', '', self._quality_length_sd), ('sources_total', '', self.quality_length_final))
		self.count_tuple_final = (('final_4k', '4K', self._quality_length), ('final_1080p', '1080p', self._quality_length), ('final_720p', '720p', self._quality_length),
									('final_sd', '', self._quality_length_sd), ('final_total', '', self.quality_length_final))
		self.debrid_runners = {'Real-Debrid': ('Real-Debrid', RD_check), 'Premiumize.me': ('Premiumize.me', PM_check),
							'AllDebrid': ('AllDebrid', AD_check),'TorBox': ('TorBox', TB_check)}

	def results(self, info):
		if not self.source_dict: return
		_t_setup = time.perf_counter()   # LOCAL PATCH 2026-10-02: scrape.diag_timing, see the line before get_sources below
		try:
			self.media_type, self.tmdb_id, self.orig_title = info['media_type'], str(info['tmdb_id']), info['title']
			self.season, self.episode, self.total_seasons = info['season'], info['episode'], info['total_seasons']
			self._special_tmdb = info.get('special_tmdb')   # LOCAL PATCH 2026-11-03: see the results cache key
			self._episode_card = None   # 2026-11-07: no card left over from an earlier results() on this object (the judge reads it)
			self.title, self.year = source_utils.normalize(info['title']), info['year']
			ep_name, aliases = source_utils.normalize(info['ep_name']), info['aliases']
			self.ep_name = ep_name   # LOCAL PATCH 2026-11-07: the pack-contents check's extras guard (Red Light 3.0.1 port)
			self.single_expiry, self.season_expiry, self.show_expiry = info['expiry_times']
			self._season_counts = {}   # LOCAL PATCH 2026-10-03: set for TV below; read by process_sources for every media type
			if self.media_type == 'movie':
				self.season_divider, self.show_divider = 0, 0
				self.data = {'imdb': info['imdb_id'], 'title': self.title, 'aliases': aliases, 'year': self.year}
				# LOCAL PATCH 2026-09-23: anime FILMS are mapped too (Fribb holds TMDb MOVIE ids). ani.zip files a film as a
				# one-episode entry, so it HAS an eid, and animetosho's eid= query (every file matched to the episode, also
				# inside batches) finds more than aid=. Cached 24 h. anilist_id too: seadex's ONLY key (recovered via the
				# anidb_id when Fribb lacks it). No anidb_aid: a film has no pack query.
				try:
					from caches import fribb_mappings as _fribb
					_mk = _fribb.query_ids_for_tmdb_movie(self.tmdb_id, info.get('imdb_id'))   # LOCAL PATCH 2026-10-27: IMDb fallback
					if _mk:
						from caches.anizip_mappings import anizip_episode_ids
						# cour_episode=1: the film is the single entry-local episode of its own AniDB entry.
						_ids = anizip_episode_ids(_mk.get('anilist_id'), cour_episode=1,
							anidb_id=_mk.get('anidb_id')) or {}
						if _ids.get('eid'): self.data['anidb_eid'] = int(_ids['eid'])
						if _ids.get('anilist'): self.data['anilist_id'] = int(_ids['anilist'])
						# LOCAL PATCH 2026-10-06: torrentio and comet search a film by it when it has no IMDb id
						if _mk.get('kitsu_id'): self.data['kitsu_id'] = int(_mk['kitsu_id'])
						kodi_utils.logger_debug('scrape.anime_gate', 'movie tmdb=%s anidb=%s eid=%s anilist=%s kitsu=%s'
							% (self.tmdb_id, _mk.get('anidb_id'), self.data.get('anidb_eid'), self.data.get('anilist_id'), self.data.get('kitsu_id')))
				except Exception: pass
			else:
				try: self.season_divider = [int(x['episode_count']) for x in self.meta['season_data'] if int(x['season_number']) == int(self.meta['season'])][0]
				except: self.season_divider = 1
				self.show_divider = int(self.meta['total_aired_eps'])
				# LOCAL PATCH 2026-10-03: episodes per season, so a show pack of S01-S02 is divided by those two seasons
				# (source_utils.pack_size_divider), not by every aired episode of the show.
				try: self._season_counts = {int(x['season_number']): int(x['episode_count']) for x in self.meta['season_data'] if int(x['season_number']) != 0}
				except Exception: self._season_counts = {}
				# LOCAL PATCH 2026-06-23: total_seasons in the TV data dict: POV-style scrapers read data['total_seasons']
				# with bracket access, and a KeyError silently means zero results.
				self.data = {'imdb': info['imdb_id'], 'tvdb': info['tvdb_id'], 'tvshowtitle': self.title, 'aliases': aliases,'year': self.year,
							'title': ep_name, 'season': str(self.season), 'episode': str(self.episode),
							'total_seasons': self.total_seasons}
				# LOCAL PATCH 2026-10-24: the episode's own air date, so a provider also matches a release named by date
				# ('The.Daily.Show.2026.10.20') -- daily and talk shows (magneto source_utils.air_date_pattern)
				self.data['premiered'] = str(self.meta.get('premiered') or '')[:10]
				# and whether to SEARCH by it too: a show released by date (TMDb type Talk Show / News, a Talk or News genre,
				# or seasons numbered by year). Every other show keeps one query per provider -- a second one on every episode
				# would double the requests to sites that rate-limit.
				try:
					_type = (self.meta.get('extra_info') or {}).get('type') or ''
					_genres = self.meta.get('genre') or []
					if isinstance(_genres, str): _genres = [_genres]
					# LOCAL PATCH 2026-10-25 (4.0.5): or a DAILY show -- 100+ episodes in a season (Jeopardy! is TMDb type
					# 'Reality'); no weekly show comes near 100. Anime is left out: a long season is released by episode number,
					# never by date. The LARGEST regular season, not this one: a daily show's current season is small for months.
					_daily = max((getattr(self, '_season_counts', None) or {}).values() or [0]) >= 100 and not is_anime_meta(self.meta)
					self.data['date_search'] = bool(self.data['premiered']) and (_type in ('Talk Show', 'News')
						or any(g in ('Talk', 'News') for g in _genres) or int(self.season) >= 1900 or _daily)
				except Exception: self.data['date_search'] = False
				# LOCAL PATCH 2026-10-25 (4.0.5): and the episode in Stremio's numbering, for the id-searched providers
				# (modules/cinemeta.py: Jeopardy! 2026-10-23 is TMDb S43E30 but tt0159881:2026:177 there). Only when it differs.
				if self.data.get('date_search'):
					try:
						from modules.cinemeta import daily_episode
						_se = daily_episode(self.data.get('imdb'), self.data['premiered'])
						if _se and _se != (str(self.season), str(self.episode)):
							self.data['stremio_se'] = _se
							kodi_utils.logger('scrape.stremio_se', '%s %s: TMDb S%sE%s asked as S%sE%s' % (self.data.get('imdb'), self.data['premiered'],
								self.season, self.episode, _se[0], _se[1]))
					except Exception as e: kodi_utils.logger('scrape.stremio_se', 'lookup failed: %s' % type(e).__name__)
				# LOCAL PATCH 2026-11-07: and an anime cour TMDb files inside one long season, as http_streams does: the Cinemeta
				# pair by the episode's TVDB id, else Fribb's cour season / episode (TMDb S1E25 = tt13196080:2:1; id-searched
				# providers find nothing under 1:25). Specials keep their own pair (special_tmdb). The lookup lives in
				# modules/episode_card.stremio_pair, cached and shared with Direct Streams.
				elif not self._special_tmdb and int(self.season or 0) > 0 and self.data.get('imdb'):
					# LOCAL PATCH 2026-11-08: on a thread -- its TMDb episode request (~1.2 s cold) would run alone before the card
					# and the providers. _join_stremio_pair waits for it before anything reads stremio_se.
					def _stremio_lookup():
						try:
							_tmdb = int(self.meta.get('tmdb_id') or 0)
							if _tmdb:
								from modules.episode_card import stremio_pair
								_se, _how = stremio_pair(_tmdb, self.season, self.episode, self.data['imdb'])
								if _se and (int(_se[0]), int(_se[1])) != (int(self.season), int(self.episode)):
									self.data['stremio_se'] = (str(_se[0]), str(_se[1]))
									kodi_utils.logger('scrape.stremio_se', '%s: TMDb S%sE%s asked as S%sE%s (%s)' % (self.data['imdb'],
										self.season, self.episode, _se[0], _se[1], _how))
						except Exception as e: kodi_utils.logger('scrape.stremio_se', 'cour lookup failed: %s' % type(e).__name__)
					import threading as _threading
					self._stremio_thread = _threading.Thread(target=_stremio_lookup, daemon=True)
					self._stremio_thread.start()
				# LOCAL PATCH 2026-08-07: cross-season contamination filter data -- words of OTHER TMDb seasons' names, so a provider can
				# reject a release labelled as another season / arc (Bleach S1: 'Thousand-Year Blood War'). nyaa reads them; they are
				# folded into foreign_cour_tokens (release_judge.build_reject_words).
				# LOCAL PATCH 2026-11-04 (cleanup): built from _other_season_words, the list the judge's 'season N by its name' check
				# reads; it drops the show's own title words and a season the episode's own title names (a remapped special).
				try:
					_season_words = self._other_season_words(int(self.season))
					if _season_words: self.data['foreign_season_tokens'] = sorted(set().union(*[w for _n, w in _season_words]))
				except Exception: pass
				# LOCAL PATCH 2026-08-09: anime scoping via Fribb: the cour our (tmdb, season, episode) maps to, its MAL / Kitsu
				# ids and cour-relative episode number for the scrapers (torrentio's `kitsu:<id>:<cour_ep>` is cour-scoped at
				# the source), plus a romaji title alias for search recall.
				try:
					from modules.metadata import is_anime_check
					if is_anime_check(self.meta, self.tmdb_id):
						self.data['is_anime'] = True   # LOCAL PATCH 2026-10-05: torrentio's and comet's anime-only checks (anime_utils.stremio_junk)
						# LOCAL PATCH 2026-10-05: each TMDb season's air year, for anime_utils.other_show_year
						try:
							self.data['season_years'] = dict((int(_sn['season_number']), int(str(_sn['air_date'])[:4]))
								for _sn in (self.meta.get('season_data') or []) if _sn.get('air_date') and int(_sn.get('season_number') or 0) > 0)
						except Exception: pass
						# LOCAL PATCH 2026-10-08: the episode's own air year, for anime_utils.other_season_year
						try: self.data['episode_year'] = int(str(self.meta.get('premiered') or '')[:4])
						except (TypeError, ValueError): pass
						# LOCAL PATCH 2026-09-02 / 2026-09-22: the RAW TMDb pair, named once. meta['season']/['episode'] are the
						# route params; self.season/self.episode carry an assigned episode group's rewrite. Everything that
						# consults TMDb's season_data or Fribb's TMDb-keyed table needs the numbers TMDb files the episode under
						# (mixing them computes a real but different absolute episode). Falls back to the scrape pair for the
						# _prefetched_meta path, which may not carry season/episode.
						_raw_s = self.meta.get('season', self.season)
						_raw_e = self.meta.get('episode', self.episode)
						_pm = [('setup', time.perf_counter())]   # LOCAL PATCH 2026-10-09: scrape.prep, per-step ms of the anime id work
						# LOCAL PATCH 2026-11-04: episode card -- every id and numbering of this episode (absolute, the Fribb cour,
						# episode candidates, AniDB / AniList / Kitsu / MAL ids) from modules/episode_card.resolve. Its input is the
						# raw TMDb pair, never an episode group's.
						from modules.episode_card import resolve as _resolve_card
						from caches import fribb_mappings as _fribb
						_card = _resolve_card(self, info, prefetch=True)
						self.data.update(_card.fields)
						self._episode_card = _card
						_pm.append(('card', time.perf_counter()))
						try: kodi_utils.logger('scrape.absolute', 'tmdb=%s raw=S%sE%s scrape=S%sE%s abs=%s via %s' % (self.tmdb_id, self.meta.get('season'), self.meta.get('episode'), self.season, self.episode, self.data.get('absolute_episode'), _card.source))
						except Exception: pass
						# the words a RELEASE is judged by, from the cour's sibling titles (modules/release_judge.build_reject_words)
						try:
							from modules.release_judge import build_reject_words
							build_reject_words(self, _card)
						except Exception: pass
						# 2026-11-07 (phase 1b/c): and what the judge reads, so release_judge.context_for takes it from the card
						try:
							from modules.episode_card import attach_judge_inputs
							self._join_stremio_pair()
							attach_judge_inputs(_card, self)
						except Exception as e: kodi_utils.logger('scrape.card', 'judge inputs not attached: %s' % type(e).__name__)
						_pm.append(('ids', time.perf_counter()))
						# behind scrape.diag_timing
						if diag_timing(): kodi_utils.logger('scrape.prep', 'tmdb %s S%sE%s: %s, total %dms' % (self.tmdb_id, _raw_s, _raw_e, ', '.join('%s %dms' % (_pm[i][0],
							(_pm[i][1] - _pm[i - 1][1]) * 1000) for i in range(1, len(_pm))), (_pm[-1][1] - _t_setup) * 1000))
				except Exception: pass
		except Exception:   # LOCAL PATCH 2026-10-15: every provider came back empty with no word of why
			_log_trace('scrape.setup', 'external scrape setup failed')
			return []
		self._join_stremio_pair()   # LOCAL PATCH 2026-11-08: the providers read data['stremio_se']
		if diag_timing():
			kodi_utils.logger('scrape.timing', 'setup external ids and data: %dms' % int((time.perf_counter() - _t_setup) * 1000))
		# LOCAL PATCH 2026-10-06: modules/scrape_prewarm stops here -- the id lookups above have filled their caches, no provider runs
		if getattr(self, 'warm_only', False): return self.data
		return self.get_sources()

	def _join_stremio_pair(self):
		"""LOCAL PATCH 2026-11-08: wait (10 s at most, as long as the lookup's own requests can take) for the threaded
		Stremio-pair lookup; a no-op when none was started or it already finished."""
		t = getattr(self, '_stremio_thread', None)
		if t is not None:
			t.join(10)
			if t.is_alive(): kodi_utils.logger('scrape.stremio_se', 'cour lookup still running after 10 s; asking in TMDb numbering')
			self._stremio_thread = None

	def _prefetch_anime_ids(self, cour_info, season, episode):
		"""LOCAL PATCH 2026-10-09: start every network lookup the anime id block below may make, all at once, and wait for
		them. The block itself reads each answer from the cache its function already keeps (one after another they held the
		providers back by seconds). The Fribb row is local, so which entries to ask about is known up front. The whole-run
		and new-season fallbacks are asked for only when Fribb has no cour, or once the entry's count says the episode is
		past it -- that test runs on its own thread. Not guessed up front: that doubles the AniList requests per scrape."""
		import threading
		from apis.anilist_api import anilist_episode_count, anilist_romaji_by_ids, anilist_romaji_bulk, anilist_romaji_for_mal, \
			anilist_entry_for_tmdb_episode
		from caches.anizip_mappings import anizip_episode_ids, anizip_whole_run_ids
		from caches import fribb_mappings as _fribb
		def _run(job):
			try: job()
			except Exception: pass

		jobs = []
		al = (cour_info or {}).get('anilist')
		cep = int((cour_info or {}).get('cour_ep') or 0)

		def _new_season():
			got = anilist_entry_for_tmdb_episode(self.meta, season, episode) or {}
			if got.get('anilist'): anizip_episode_ids(got['anilist'], cour_episode=got['episode'])

		def _fallbacks():   # the whole-run and new-season lookups side by side (the block asks for them in that order)
			t = threading.Thread(target=_run, args=(_new_season,))
			t.start()
			if self.data.get('absolute_episode'): _run(lambda: anizip_whole_run_ids(self.tmdb_id, self.meta.get('total_aired_eps')))
			t.join(20)

		def _count_then_fallbacks():
			n = anilist_episode_count(al)
			if not n or cep <= int(n): return
			rep = _fribb.find_cour_by_tmdb_coords(self.tmdb_id, season, episode, allow_repair=True) or {}
			if rep.get('anilist') and rep['anilist'] != al: anilist_episode_count(rep['anilist'])
			_fallbacks()

		if cour_info:
			if al and cep > 1: jobs.append(_count_then_fallbacks)
			jobs.append(lambda: anizip_episode_ids(al, cour_info.get('cour_ep'), self.data.get('absolute_episode'), cour_info.get('anidb')))
			if al:
				siblings = [r.get('anilist_id') for r in _fribb.tmdb_tv_to_fribb_rows(self.tmdb_id) if r.get('anilist_id')]
				jobs.append(lambda: anilist_romaji_by_ids(siblings + [al]))
			elif cour_info.get('mal'):   # a cour with no AniList id is named by MAL id (Stone Ocean's part 3, S5E38)
				mal = cour_info['mal']
				mal_siblings = [r.get('mal_id') for r in _fribb.tmdb_tv_to_fribb_rows(self.tmdb_id) if r.get('mal_id')]
				def _mal_titles():
					if len(mal_siblings) > 1: anilist_romaji_bulk(mal_siblings)
					anilist_romaji_for_mal(mal)
				jobs.append(_mal_titles)
		else: jobs.append(_fallbacks)
		# LOCAL PATCH 2026-11-07 (phase 5c): TheXEM's scene map for the show (episode_card.release_pair), beside the others -- one
		# request a week per mapped show
		if cour_info and self.meta.get('tvdb_id'):
			from caches.thexem_mappings import scene_map
			_tvdb_show = self.meta.get('tvdb_id')
			jobs.append(lambda: scene_map(_tvdb_show))
		if len(jobs) < 2: return
		threads = [threading.Thread(target=_run, args=(job,)) for job in jobs]
		for t in threads: t.start()
		for t in threads: t.join(20)

	def _new_season_ids(self, season, episode):
		"""LOCAL PATCH 2026-10-04: the anime ids for an episode of a season Fribb has not mapped yet, from AniList (the entry
		that starts this TMDb season, apis.anilist_api.anilist_for_tmdb_season) and ani.zip (that entry's AniDB, Kitsu and
		MAL ids and this episode's AniDB eid). Fills what the Fribb branch would: anilist_id (seadex), anidb_aid/anidb_eid
		(animetosho), kitsu_id + cour_episode (torrentio's and comet's Kitsu paths), mal_id.

		A new season can air before Fribb has a row for it. TMDb's episode number is used as the entry's own because the match
		is by the date the season STARTS -- episode N of the season is episode N of the entry, as long as the entry is that
		long; past it (two cours as one TMDb season) is another entry, so nothing is set. cour_season is left unset, as in the
		whole-run branch, so name matching makes no strict season test. Not used: SIMKL (can file a season under a deleted
		TMDb id) and the Anime-Lists XML (a 3.5 MB download)."""
		from apis.anilist_api import anilist_entry_for_tmdb_episode
		got = anilist_entry_for_tmdb_episode(self.meta, season, episode)
		if got.get('exhausted'):
			gone = got['exhausted']
			if self._mal_episode_ids(gone.get('mal'), season, episode): mal_note = ' -- AniDB from MAL %s: aid %s eid %s' % (
				gone.get('mal'), self.data.get('anidb_aid'), self.data.get('anidb_eid'))
			else: mal_note = ' -- no ids'
			return kodi_utils.logger('scrape.new_season', 'tmdb %s S%sE%s -> AniList %s (from %s): episode past its %s, and no next entry to '
				'try%s' % (self.tmdb_id, season, episode, gone.get('anilist'), gone.get('start'), gone.get('episodes'), mal_note))
		if not got.get('anilist'): return
		raw_episode = episode
		found, offset, episode = got, got['offset'], got['episode']
		where = 'tmdb %s S%sE%s -> AniList %s (from %s)' % (self.tmdb_id, season, int(episode) + offset, found['anilist'], found.get('start'))
		if offset: where += ', ep %s there' % episode
		from caches.anizip_mappings import anizip_episode_ids, anizip_eid_air_date, air_dates_agree
		# LOCAL PATCH 2026-10-10: AniDB ids by MAL id FIRST -- matched by season/episode + air date, so they hold even when
		# the AniList entry is narrower than the AniDB one (the AniList lookup below goes by the entry-local number, right
		# only when the two entries line up). MAL's aid/eid win when found.
		mal_ids = self._mal_episode_ids(found.get('mal'), season, raw_episode)
		ids = anizip_episode_ids(found['anilist'], cour_episode=episode) or {}
		# and an AniList-path eid whose air date is not this episode's is dropped rather than scraped
		if not mal_ids and ids.get('eid'):
			from apis.anilist_api import _tmdb_episode_air_date
			if not air_dates_agree(anizip_eid_air_date(found['anilist'], ids['eid']), _tmdb_episode_air_date(self.meta, season, raw_episode)):
				where += ' (ani.zip eid %s airs on another date: dropped)' % ids['eid']
				ids = dict(ids, aid=None, eid=None)
		self.data['anilist_id'] = int(found['anilist'])
		for key, field in (('mal', 'mal_id'), ('kitsu', 'kitsu_id'), ('aid', 'anidb_aid'), ('eid', 'anidb_eid')):
			if mal_ids and key in ('aid', 'eid'): continue
			value = ids.get(key) or (found.get('mal') if key == 'mal' else None)
			if value: self.data[field] = int(value)
		if self.data.get('kitsu_id'): self.data['cour_episode'] = episode
		if mal_ids: where += ' (AniDB from MAL %s)' % found['mal']
		kodi_utils.logger('scrape.new_season', '%s: kitsu %s ep %s, anidb %s eid %s' % (where, self.data.get('kitsu_id'),
			self.data.get('cour_episode'), self.data.get('anidb_aid'), self.data.get('anidb_eid')))

	def _dated_cour_starts(self, season):
		"""LOCAL PATCH 2026-10-10: [(fribb_offset, true_offset, row), ...] for the Fribb rows of a TMDb season, the true offset
		read off air dates -- or [] when the season has one row, or the dates cannot be trusted. Cached a day per show/season.

		Fribb's TMDb offsets go stale when TMDb renumbers a long season (a cour then starts one episode off, and every later
		episode scrapes its neighbour). A row's start is the TMDb episode airing within 3 days of the row's ep 1 -- exactly one,
		and at most 3 from Fribb's -- else Fribb's stays. Nothing moves unless row 1's ep 1 airs within 2 days of TMDb's E1 (a
		show whose TMDb dates are a dub's or a later stream's fails that, so a systematic lag shifts nothing)."""
		from caches import fribb_mappings as _fribb
		from caches.lists_cache import lists_cache_object
		from caches.anizip_mappings import anizip_entry_dates, air_dates_agree
		from modules.metadata import episodes_meta, tmdb_air_day
		rows = _fribb._season_cour_rows(self.tmdb_id, season, allow_repair=False) or []
		if len(rows) < 2: return []
		def _compute(_unused):
			tmdb_dates = {}
			for item in episodes_meta(season, self.meta) or []:
				try: tmdb_dates[int(item.get('episode'))] = tmdb_air_day(item)   # LOCAL PATCH 2026-10-25: TMDb's day, not a dub-shifted one
				except (TypeError, ValueError): continue
			starts = []
			for i, (off, row) in enumerate(rows):
				first = anizip_entry_dates((row or {}).get('anilist_id'), (row or {}).get('anidb_id')).get(1)
				if i == 0:
					if not first or not tmdb_dates.get(1) or not air_dates_agree(first, tmdb_dates[1], 2): return []
					starts.append([off, off])
					continue
				hits = [n for n, d in tmdb_dates.items() if d and first and air_dates_agree(first, d, 3)]
				true = hits[0] - 1 if len(hits) == 1 and 1 <= abs(hits[0] - 1 - off) <= 3 else off
				starts.append([off, true])
			return starts
		# LOCAL PATCH 2026-11-04: Fribb's own offsets are part of the key: the answer holds [fribb_offset, dated_offset] pairs,
		# which go stale (one episode off) when Fribb corrects a row.
		_offs = '-'.join(str(off) for off, _row in rows)
		starts = lists_cache_object(_compute, 'cour_starts_%s_%s_%s' % (self.tmdb_id, season, _offs), 0, expiration=24) or []
		if len(starts) != len(rows): return []
		return [(f, t, row) for (f, t), (_o, row) in zip(starts, rows)]

	def _dated_cour(self, season, episode):
		"""LOCAL PATCH 2026-10-10: Fribb's cour for TMDb (season, episode) placed by _dated_cour_starts -- a
		find_cour_by_tmdb_coords dict -- or None when Fribb's own answer stands."""
		from caches import fribb_mappings as _fribb
		starts = self._dated_cour_starts(season)
		if not starts or all(f == t for f, t, _r in starts): return None
		episode = int(episode)
		for i, (fribb_off, true_off, row) in enumerate(starts):
			nxt = starts[i + 1][1] if i + 1 < len(starts) else float('inf')
			if not true_off < episode <= nxt: continue
			ep = episode - true_off
			fribb_next = starts[i + 1][0] if i + 1 < len(starts) else float('inf')
			if fribb_off + ep <= fribb_next:
				info = _fribb.find_cour_by_tmdb_coords(self.tmdb_id, season, fribb_off + ep, allow_repair=False)
			else:
				# past the end of Fribb's own window for this row: take the row from its first episode and count on from there
				info = dict(_fribb.find_cour_by_tmdb_coords(self.tmdb_id, season, fribb_off + 1, allow_repair=False) or {})
				if info.get('season_ep') is not None: info['season_ep'] = int(info['season_ep']) + ep - 1
				if info: info['cour_ep'] = ep
			if not info or info.get('row') is not row: return None
			# the release-season count (season_ep, season_start, season_len) from the dated starts too ('2nd Season - 14' counts
			# from the season's first part, which may be the one that moved)
			tvdb = info.get('cour_season')
			if tvdb is not None:
				def _tvdb(r):
					si = (r or {}).get('season') or {}
					return si.get('tvdb') if si.get('tvdb') is not None else si.get('tmdb')
				same = [t for _f, t, r in starts if str(_tvdb(r)) == str(tvdb)]
				later = [t for _f, t, r in starts if same and t > max(same)]
				if same:
					info = dict(info, season_ep=episode - min(same), season_start=min(same),
								season_len=(min(later) - min(same)) if later else info.get('season_len'))
			return info
		return None

	def _mal_episode_ids(self, mal_id, season, episode):
		"""LOCAL PATCH 2026-10-10: AniDB aid + eid by MAL id (caches.anizip_mappings.anizip_mal_episode_ids), for animetosho,
		when ani.zip has nothing for the AniList entry but has its MAL id. Matched by TMDb season/episode and air date, never
		by AniList's entry-local number (the entries may not line up). True when it filled them."""
		if not mal_id: return False
		from caches.anizip_mappings import anizip_mal_episode_ids
		from apis.anilist_api import _tmdb_episode_air_date
		ids = anizip_mal_episode_ids(mal_id, self.tmdb_id, season, episode, _tmdb_episode_air_date(self.meta, season, episode))
		if not ids.get('eid'): return False
		self.data['anidb_aid'], self.data['anidb_eid'] = int(ids['aid']), int(ids['eid'])
		return True

	def get_sources(self):
		# LOCAL PATCH 2026-09-26: 50 ms polls with the sleep at the TOP of the loop (a cached scrape finishes in ~30 ms). The
		# sleep must stay outside the try: update_scraper can raise before the progress window is up, and an exception
		# skipping the sleep would spin the loop.
		def _scraperDialog():
			kodi_utils.hide_busy_dialog()
			start_time = time.time()
			while not self.progress_dialog.iscanceled() and not self.monitor.abortRequested():
				kodi_utils.sleep(50)
				try:
					alive_threads = [x.getName() for x in self.threads if x.is_alive()]
					if self.internal_activated or self.internal_prescraped: alive_threads.extend(self.process_internal_results())
					percent = (max((time.time() - start_time), 0)/float(self.timeout))*100
					# LOCAL PATCH 2026-09-27: the bar shows providers DONE; the timer keeps driving the exit below
					rows = self._provider_rows()
					done = len([r for r in rows if r[2] != 'running'])
					left = max(0, int(round(self.timeout - (time.time() - start_time))))
					shown = percent if len(rows) <= 1 else (100.0 * done / len(rows) if rows else 0)
					self.progress_dialog.update_scraper(self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total, '', shown,
						providers=rows, phase='Searching Providers', detail='%d of %d done  ·  %ds left' % (done, len(rows), left) if rows else '%ds left' % left,
						time_pct=None if len(rows) <= 1 else percent, late=left <= 3, hidden=self.counter.line())
					if self.threads_completed:
						len_alive_threads = len(alive_threads)
						if len_alive_threads == 0 or percent >= 100: break
						# LOCAL PATCH 2026-09-05: stop waiting on stragglers once the result set is good (see
						# _load_scrape_extras: it DISCARDS their rows, so all three gates must hold). Off at 0.
						if self._early_exit_sources and percent >= 50:
							_have = len(self.sources)
							if _have >= self._early_exit_sources:
								kodi_utils.logger('scrape.early_exit', '%d sources at %d%% of budget, dropping: %s'
													% (_have, int(percent), ', '.join(alive_threads) or 'none'))
								break
					elif percent >= 100: break
				except: pass
			try:   # LOCAL PATCH 2026-09-27: whoever is still running when the wait ends has timed out
				rows = self._provider_rows(final=True)
				if any(r[2] == 'timeout' for r in rows):
					self.progress_dialog.update_scraper(self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total, '', 100,
						providers=rows, time_pct=100, late=True, hidden=self.counter.line())
			except: pass
			return
		# LOCAL PATCH 2026-09-26: poll at 200 ms and judge only once every provider thread has been LAUNCHED
		# (threads_completed; self.threads fills in gradually). Exit at once when every thread has finished (the cached
		# fast path); apply the straggler rules only after a 2.5 s floor from threads_completed -- with <= 5 providers
		# '<= 5 alive' is true from the first poll, and a cold scrape would return only cache hits.
		def _background():
			end_time = time.time() + self.timeout + 1.5
			floor = None
			while time.time() < end_time:
				kodi_utils.sleep(200)
				if not self.threads_completed: continue
				if floor is None: floor = time.time() + 2.5
				len_alive_threads = len([x for x in self.threads if x.is_alive()])
				if len_alive_threads == 0: return
				if time.time() < floor: continue
				if len_alive_threads <= 5: return
				if len(self.sources) >= 100 * len_alive_threads: return
		self.threads = []
		self.threads_append = self.threads.append
		self._prefetch_threads, self._prefetch_seen, self._prefetch_lock = [], set(), Lock()
		self._prefetch_pending, self._prefetch_running = [], 0
		self._prefetch_stats = {}   # LOCAL PATCH 2026-10-11: {debrid: [batches, ms]} for the scrape.wait line
		# LOCAL PATCH 2026-10-11: Real-Debrid's hash-independent lookups (Torrentio's cached page, a DMM token) start with the
		# providers, so the cache check of the last provider's hashes does not pay for them (source_utils.warm_rd_cache_check)
		if 'Real-Debrid' in self.active_debrid and self.external_cache_check and self.data.get('imdb'):
			Thread(target=source_utils.warm_rd_cache_check, args=(self.data,), name='rd warm').start()
		if self.media_type == 'movie': Thread(target=self.process_movie_threads).start()
		else:
			self.source_dict = [i for i in self.source_dict if i[1].hasEpisodes]
			self.season_packs, self.show_packs = source_utils.pack_enable_check(self.meta, self.season, self.episode)
			if self.season_packs:
				self.source_dict = [(i[0], i[1], '') for i in self.source_dict]
				pack_capable = [i for i in self.source_dict if i[1].pack_capable]
				if pack_capable:
					self.source_dict.extend([(i[0], i[1], 'Season') for i in pack_capable])
					if self.show_packs: self.source_dict.extend([(i[0], i[1], 'Show') for i in pack_capable])
					random.shuffle(self.source_dict)
					self.source_dict.sort(key=lambda k: k[2])
			Thread(target=self.process_episode_threads).start()
		if self.background: _background()
		else: _scraperDialog()
		current_results = list(self.sources)
		if current_results: return self.process_results(current_results)
		return []

	def _load_scrape_extras(self):
		# LOCAL PATCH 2026-07-10 (B+C): the blocklist + DIAG toggle read once per scrape; called from both dispatch entry
		# points so they share the same policy.
		if getattr(self, '_scrape_extras_loaded', False): return
		raw = (get_setting('deadlight.scrape.provider_blocklist', '') or '').strip()
		self._blocked_providers = {p.strip().lower() for p in raw.split(',') if p.strip()}
		self._diag_timing = diag_timing()
		# LOCAL PATCH 2026-07-23: anime-only providers, skipped entirely when the content isn't anime (they return nothing
		# for it anyway).
		anime_only_raw = (get_setting('deadlight.scrape.anime_only_providers', 'nyaa,animetosho,seadex,nekobt') or '').strip()
		self._anime_only_providers = {p.strip().lower() for p in anime_only_raw.split(',') if p.strip()}
		self._is_anime = self._detect_anime_content()
		# LOCAL PATCH 2026-09-22: the mirror image of anime_only_providers: the providers allowed on ANIME (magneto's
		# toggles are global). On anime modules/sources.external_sources loads THIS list (2026-10-05), so a tick here is the
		# provider's anime switch and magneto.provider.<id> only covers Movies & TV.
		# EXTERNAL providers only: DeadLight's internal scrapers (easynews, debrid clouds, folders, aiostreams, http_streams)
		# are dispatched by modules.sources through remove_scrapers. Empty disables the restriction.
		anime_raw = (get_setting('deadlight.scrape.anime_providers', 'animetosho,seadex,nyaa,nekobt') or '').strip()
		self._anime_providers = {p.strip().lower() for p in anime_raw.split(',') if p.strip()}
		# LOCAL PATCH 2026-09-23 / 2026-10-04: the list applies without ids too (see _is_not_for_anime_skipped);
		# _has_anime_keys is kept for the diag line only.
		_d = getattr(self, 'data', None) or {}
		self._has_anime_keys = any(_d.get(_k) for _k in ('anidb_aid', 'anidb_eid', 'anilist_id'))
		if self._anime_only_providers or self._anime_providers:
			kodi_utils.logger_debug('scrape.anime_gate', 'is_anime=%s anime_keys=%s anime_only=%s anime_providers=%s'
				% (self._is_anime, self._has_anime_keys, sorted(self._anime_only_providers), sorted(self._anime_providers) or '-'))
		# LOCAL PATCH 2026-09-05: early exit for the FOREGROUND scrape (the background path has its own), instead of waiting
		# for the slowest provider. A COMPLETENESS TRADE-OFF: the stragglers' sources are lost, so every gate must hold:
		# enough sources in hand, at least half the budget spent, and the dispatcher finished handing out work.
		# scrape.early_exit_sources = 0 disables it.
		try: self._early_exit_sources = int(get_setting('deadlight.scrape.early_exit_sources', '0') or 0)
		except (TypeError, ValueError): self._early_exit_sources = 0
		self._scrape_extras_loaded = True

	def _detect_anime_content(self):
		# LOCAL PATCH 2026-10-05: the test moved to source_utils.is_anime_meta (since 10-15 metadata.is_anime_meta), shared with modules/sources.external_sources
		# (which loads the anime list instead of the switched-on providers) and the Options menu's Anime Scrapers.
		return is_anime_meta(self.meta)

	def _is_blocked(self, provider):
		if not self._blocked_providers: return False
		if provider.lower() in self._blocked_providers:
			kodi_utils.logger('scrape.blocklist', 'skip %s (in blocklist)' % provider)
			return True
		return False

	def _is_not_for_anime_skipped(self, provider):
		# Skip a provider that may not run on anime when the content IS anime.
		if not self._is_anime: return False
		# LOCAL PATCH 2026-10-04: on anime only ANIME_PROVIDERS ever run -- the ticked ones, or all of them on 'Rescrape With All
		# Scrapers' (magneto_sources(ret_all=True)). With or without an anime id: letting every provider run when there is no
		# id brings the old numbering's same-named episodes (a new 'S02E01' that is a 2017 run's episode 52). An unmapped
		# anime shows only what these find, possibly nothing. An empty list is not "no restriction".
		# LOCAL PATCH 2026-10-05: 'all' is every anime provider but source_utils.ANIME_ALL_SKIPPED (empty since 10-31), from the menu too
		allowed = set(anime_providers_to_run(self.all_scrapers)) if self.all_scrapers else self._anime_providers & set(ANIME_PROVIDERS)
		if provider.lower() in allowed: return False
		kodi_utils.logger_debug('scrape.anime_gate', 'skip %s (%s)' % (provider,
			'not an anime provider' if provider.lower() not in ANIME_PROVIDERS else 'not on the anime provider list'))
		return True

	def _is_anime_only_skipped(self, provider):
		# Skip providers marked anime-only when the current content isn't anime.
		if not self._anime_only_providers: return False
		if provider.lower() in self._anime_only_providers and not self._is_anime:
			kodi_utils.logger_debug('scrape.anime_gate', 'skip %s (anime-only, content is not anime)' % provider)
			return True
		return False

	def process_movie_threads(self):
		self._load_scrape_extras()
		for i in self.source_dict:
			provider, module = i[0], i[1]
			if (self._is_blocked(provider) or self._is_anime_only_skipped(provider)
				or self._is_not_for_anime_skipped(provider)):
				try: self.remainingProviders.remove(provider)
				except: pass
				continue
			threaded_object = Thread(target=self.get_movie_source, args=(provider, module), name=provider)
			threaded_object.start()
			self.threads_append(threaded_object)
		self.threads_completed = True

	def process_episode_threads(self):
		self._load_scrape_extras()
		for i in self.source_dict:
			provider, module = i[0], i[1]
			try: pack_arg = i[2]
			except: pack_arg = ''
			if pack_arg: provider_display = '%s (%s)' % (i[0], i[2])
			else: provider_display = provider
			if (self._is_blocked(provider) or self._is_anime_only_skipped(provider)
				or self._is_not_for_anime_skipped(provider)):
				try: self.remainingProviders.remove(provider_display)
				except: pass
				continue
			threaded_object = Thread(target=self.get_episode_source, args=(provider, module, pack_arg), name=provider_display)
			threaded_object.start()
			self.threads_append(threaded_object)
		self.threads_completed = True

	def _has_imdb(self):
		imdb = str((getattr(self, 'data', None) or {}).get('imdb') or '').strip().lower()
		return imdb.startswith('tt') and imdb.strip('t0') != ''

	def _scrape(self, provider, scraper, method, *args, **kwargs):
		"""LOCAL PATCH 2026-09-27: run one provider call and note whether an empty answer was an OUTAGE. Two signals:
		the provider's own request_failed (animetosho / seadex / nekobt set it), or -- for every provider that fetches
		through magneto's client -- at least one request failed and none answered in this thread. A provider that
		answered with nothing stays 'none'. The episode and pack threads of one provider share the key; the row still
		shows its count when any of them found something (_provider_rows checks the count first)."""
		try:
			from magneto.modules import client as _client
			_client.reset_status()
		except Exception: _client = None
		# LOCAL PATCH 2026-11-08: a provider that RAISES is a failed provider: logged with its name, shown down, its empty answer
		# not cached.
		try: sources = method(*args, **kwargs)
		except Exception as e:
			kodi_utils.logger('scrape.provider_error', '%s: %s: %s' % (provider, type(e).__name__, str(e)[:200]))
			self.provider_failed.add(provider)
			return []
		if not sources:
			failed = getattr(scraper, 'request_failed', False)
			if not failed and _client is not None:
				ok, bad = _client.status()
				failed = bad > 0 and ok == 0
			# LOCAL PATCH 2026-09-28: with NO IMDb id a failed request is not an outage: the Stremio-style providers key their
			# query on it and given '' ask for '/stream/series/:1:1.json', which the server rejects. Any provider, no list:
			# shown as no results and cached like one.
			if failed and not self._has_imdb():
				kodi_utils.logger('scrape.provider_down', '%s: request failed, but there is no IMDb id to search by -- shown as no results, not down' % provider)
				failed = False
			if failed:
				self.provider_failed.add(provider)
				kodi_utils.logger('scrape.provider_down', '%s: no answer (request failed), empty result not cached' % provider)
		return sources

	def _usable_files(self, blob, extensions):
		"""LOCAL PATCH 2026-11-08: a TorBox listing's video files as the pack test reads them (one place, so the prefetch
		worker and _real_pack_sizes pick from identical input). None when the listing does not parse."""
		try: _files = json.loads(blob)
		except Exception: return None
		return [{'filename': f['name'], 'size': f['size']} for f in _files
			if f.get('name') and f.get('size') and str(f['name']).lower().endswith(extensions)]

	def _first_pick(self, _hash, usable, candidates):
		"""LOCAL PATCH 2026-11-08: pick_episode_files for this episode on one listing, memoised by hash -- the prefetch worker
		fills it while providers still search; _real_pack_sizes reads it. Raises as pick_episode_files does (not memoised)."""
		memo = self.__dict__.setdefault('_pick_memo', {})
		if _hash in memo: return memo[_hash]
		res = source_utils.pick_episode_files(usable, self.season, self.episode, 'filename', candidates, self.title,
			ep_name=getattr(self, 'ep_name', None))
		memo[_hash] = res
		return res

	def _prepick(self, batch):
		"""LOCAL PATCH 2026-11-08: after a prefetch batch, the first pick of every TorBox listing it brought back (episodes
		only; same conditions as _real_pack_sizes). Best-effort: anything left undone is done by the final check, as before."""
		try:
			if self.media_type != 'episode' or self.season in (None, '') or 'TorBox' not in self.active_debrid: return
			listings = query_local_cache_files(list(batch), 'tb')
			if not listings: return
			extensions = tuple(source_utils.supported_video_extensions())
			candidates = self.data.get('episode_candidates') or None
			for _hash, blob in listings.items():
				usable = self._usable_files(blob, extensions)
				if not usable: continue
				try: self._first_pick(_hash, usable, candidates)
				except Exception: pass
		except Exception: pass

	def _prefetch_debrid(self, sources):
		"""LOCAL PATCH 2026-10-02: check this provider's hashes with the debrid service NOW, while slower providers are still
		searching, instead of all of them after the last one. The checks write their verdicts to the local debrid cache, and
		process_results' own check sends only hashes that cache does not know -- so it is left with the stragglers' hashes.
		Each hash is handed out ONCE: debrid_data is unique (hash, debrid) with a plain INSERT, so a hash two threads both
		wrote would fail the whole batch, silently. AllDebrid is left to the final check (it takes more arguments)."""
		# Not a check per provider thread: up to 9 TorBox calls at once can leave one hanging for the full 10 s cap. A worker
		# sends whatever is waiting as one batch; hashes arriving meanwhile go in the next.
		try:
			hashes = set(i['hash'] for i in sources or [] if len(i.get('hash') or '') == 40)
			if not hashes: return
			# LOCAL PATCH 2026-10-11: Real-Debrid too (when its check is on), not left to the final check. Torrentio's page is
			# memoised per episode (source_utils), so the batches cost one Torrentio request; DMM is asked about each batch's
			# new hashes only.
			runners = [(item, self.debrid_runners[item][1]) for item in self.active_debrid if item not in ('Real-Debrid', 'AllDebrid')]
			if 'Real-Debrid' in self.active_debrid and self.external_cache_check:
				_rd = self.debrid_runners['Real-Debrid'][1]
				runners.append(('Real-Debrid', lambda batch, known, _rd=_rd: _rd(batch, known, self.data, self.active_debrid)))
			if not runners: return
			if not hasattr(self, '_prefetch_t0'): self._prefetch_t0 = time.perf_counter()
			with self._prefetch_lock:
				hashes -= self._prefetch_seen
				if not hashes: return
				self._prefetch_seen |= hashes
				self._prefetch_pending.extend(hashes)
				# LOCAL PATCH 2026-10-11: up to TWO batches in flight, so hashes arriving while one is out need not wait for
				# it. Not more: TB_check splits a batch into up to 4 requests, and 9 TorBox calls at once can hang one 10 s.
				if self._prefetch_running >= 2: return
				self._prefetch_running += 1
			def _worker():
				while True:
					with self._prefetch_lock:
						batch, self._prefetch_pending[:] = self._prefetch_pending[:], []
						if not batch:
							self._prefetch_running -= 1
							return
					# LOCAL PATCH 2026-10-11: each debrid in its own thread: in a row they can run past the 5 s the final check
					# waits for this worker.
					_tb0 = time.perf_counter()
					known = query_local_cache(batch)
					took = {}
					def _run(name, function):
						_t = time.perf_counter()
						try: function(batch, known)
						except Exception: pass
						took[name] = (time.perf_counter() - _t) * 1000
					_threads = [Thread(target=_run, args=(name, function)) for name, function in runners]
					[t.start() for t in _threads]
					[t.join() for t in _threads]
					self._prepick(batch)   # LOCAL PATCH 2026-11-08: the pack test's first picks, while providers still search
					with self._prefetch_lock:
						for _n, _ms in took.items():
							_st = self._prefetch_stats.setdefault(_n, [0, 0.0]); _st[0] += 1; _st[1] += _ms
					# LOCAL PATCH 2026-10-11: one line per batch (behind scrape.diag_timing; it tracked down the post-search wait)
					if self._diag_timing:
						try: kodi_utils.logger('scrape.prefetch', 'batch of %d at +%dms: %s' % (len(batch), (_tb0 - self._prefetch_t0) * 1000,
							', '.join('%s %dms' % (n, v) for n, v in sorted(took.items()))))
						except Exception: pass
			_thread = Thread(target=_worker, name='debrid prefetch')
			self._prefetch_threads.append(_thread)
			_thread.start()
		except Exception: pass

	def get_movie_source(self, provider, module):
		if self._diag_timing: _t0 = time.perf_counter()
		sources = None if self.filterless else external_cache.get(provider, self.media_type, self.tmdb_id, self.title, self.year, '', '')
		_from_cache = sources is not None
		if sources == None:
			scraper = module()
			sources = self.process_sources(provider, self._scrape(provider, scraper, scraper.sources, self.data, self.host_dict))
			if not sources: expiry_hours = 1
			else: expiry_hours = self.single_expiry
			# LOCAL PATCH 2026-09-26: see get_episode_source -- a failed request is not cached.
			if (sources or provider not in self.provider_failed) and not self.filterless:
				external_cache.set(provider, self.media_type, self.tmdb_id, self.title, self.year, '', '', sources, expiry_hours)
		sources = self._drop_not_episodes(provider, sources)   # LOCAL PATCH 2026-10-06
		if sources:
			if not self.background: self.process_quality_count(sources)
			self.sources.extend(sources)
		self.provider_counts[provider] = self.provider_counts.get(provider, 0) + len(sources or [])
		self._prefetch_debrid(sources)
		if self._diag_timing:
			# LOCAL PATCH 2026-10-02: '(cache)' -- a cache hit is not a fast provider
			kodi_utils.logger('scrape.timing', '%s: %dms (%d sources)%s' % (provider, int((time.perf_counter() - _t0) * 1000), len(sources) if sources else 0,
				' (cache)' if _from_cache else ''))
		del module

	def _fill_pack_future(self, provider, scraper):
		# LOCAL PATCH 2026-10-18: the Stremio-style providers' packs make no request of their own -- they wait (11 s) on the
		# future their sources() call fills. When the episode row came from this cache, sources() never ran, so run the
		# search once here (Season and Show share it), or the packs time out and cache [].
		if not hasattr(scraper, 'wait_future') or self.filterless: return
		with _PACK_FILL_LOCK:
			filled = self.__dict__.setdefault('_pack_filled', set())
			if provider in filled: return
			filled.add(provider)
		_ep_key = getattr(self, '_special_tmdb', None) or (self.season, self.episode)   # LOCAL PATCH 2026-11-03: the episode row's key
		if external_cache.get(provider, self.media_type, self.tmdb_id, self.title, self.year, _ep_key[0], _ep_key[1]) is None: return
		try: scraper.sources(self.data, self.host_dict)
		except Exception: pass

	def get_episode_source(self, provider, module, pack):
		if self._diag_timing: _t0 = time.perf_counter()
		if pack in ('Season', 'Show'):
			if pack == 'Show': s_check = ''
			else: s_check = self.season
			e_check = ''
			# LOCAL PATCH 2026-09-24: an ANIME pack result depends on the episode asked for, so it cannot be shared across
			# the season: the anime providers filter packs BEFORE this cache (range and foreign-cour rejects, which differ
			# per cour, and one TMDb season can hold several cours). The P prefix keeps a pack row from colliding with the
			# single-episode row.
			if getattr(self, "_is_anime", False): e_check = 'P%s' % self.episode
		else: s_check, e_check = self.season, self.episode
		# LOCAL PATCH 2026-11-03: a special searched under TVDB's number (sources.make_search_info) keeps its TMDb key, so it
		# does not share a row with the show's real episode of that number. A show pack is show-wide either way.
		_sp_key = getattr(self, '_special_tmdb', None)
		if _sp_key and pack != 'Show':
			s_check, e_check = _sp_key[0], ('P%s' % _sp_key[1]) if pack == 'Season' else _sp_key[1]
		sources = None if self.filterless else external_cache.get(provider, self.media_type, self.tmdb_id, self.title, self.year, s_check, e_check)
		_from_cache = sources is not None
		if sources == None:
			scraper = module()
			if pack in ('Season', 'Show'): self._fill_pack_future(provider, scraper)
			if pack == 'Show':
				expiry_hours = self.show_expiry
				sources = self._scrape(provider, scraper, scraper.sources_packs, self.data, self.host_dict, search_series=True, total_seasons=self.total_seasons)
			elif pack == 'Season':
				expiry_hours = self.season_expiry
				sources = self._scrape(provider, scraper, scraper.sources_packs, self.data, self.host_dict)
			else:
				expiry_hours = self.single_expiry
				sources = self._scrape(provider, scraper, scraper.sources, self.data, self.host_dict)
			sources = self.process_sources(provider, sources)
			if not sources: expiry_hours = 1
			# LOCAL PATCH 2026-09-26: a provider that FAILED (provider_failed, see _scrape) returned [] without the tracker
			# having nothing -- not cached.
			if (sources or provider not in self.provider_failed) and not self.filterless:
				external_cache.set(provider, self.media_type, self.tmdb_id, self.title, self.year, s_check, e_check, sources, expiry_hours)
		sources = self._drop_not_episodes(provider, sources)   # LOCAL PATCH 2026-10-06
		if sources:
			if pack == 'Season': sources = [i for i in sources if not 'episode_start' in i or i['episode_start'] <= self.episode <= i['episode_end']]
			elif pack == 'Show': sources = [i for i in sources if i['last_season'] >= self.season]
			if not self.background: self.process_quality_count(sources)
			self.sources.extend(sources)
		self.provider_counts[provider] = self.provider_counts.get(provider, 0) + len(sources or [])
		self._prefetch_debrid(sources)
		if self._diag_timing:
			pack_tag = ('-%s' % pack) if pack else ''
			kodi_utils.logger('scrape.timing', '%s%s: %dms (%d sources)%s' % (provider, pack_tag, int((time.perf_counter() - _t0) * 1000), len(sources) if sources else 0,
				' (cache)' if _from_cache else ''))
		del module

	def process_results(self, results):
		# LOCAL PATCH 2026-10-02: a hash several providers list is MERGED, not dropped: the kept copy is the most informative
		# (_info_score), and every provider that listed it goes on it as 'providers', kept one first ('COMET +2', filters).
		def _process_duplicates(all_results):
			unique_urls, groups, order = set(), {}, []
			for item in all_results:
				try:
					url = item['url'].lower()
					if url in unique_urls: continue
					unique_urls.add(url)
					_hash = item.get('hash')
					if _hash is None:
						order.append(item)
						continue
					if len(_hash) != 40:
						# LOCAL PATCH 2026-10-25 (4.0.5): a 32-char infohash is the base32 form (magnet btih allows both) -- the
						# same torrent, so convert it to hex (what the debrid checks key on) instead of dropping the row
						_hex = _b32_hash(_hash)
						if not _hex:
							kodi_utils.logger_debug('scrape.hash', 'drop %s from %s: not an infohash (%d chars)' % (str(_hash)[:48], item.get('provider'), len(_hash)))
							continue
						_hash = item['hash'] = _hex
					if _hash in groups: groups[_hash].append(item)
					else:
						groups[_hash] = [item]
						order.append(_hash)
				except: order.append(item)
			for entry in order:
				if not isinstance(entry, str):
					yield entry
					continue
				copies = groups[entry]
				if len(copies) == 1:
					yield copies[0]
					continue
				best = max(copies, key=_info_score)   # max keeps the FIRST of equal scores: arrival order breaks ties
				names = [best['provider']] + [c['provider'] for c in copies if c is not best]
				merged = dict(best, providers=list(dict.fromkeys(names)))
				# LOCAL PATCH 2026-10-03: the winner can be the copy that does not know the torrent is a pack (comet names a pack
				# by the episode file inside it), so another provider's pack fields go onto it and playback takes the pack path.
				# The size stays the winner's: a per-file size beats any copy's divided estimate.
				if 'package' not in merged:
					donor = next((c for c in copies if 'package' in c), None)
					if donor:
						for key in ('package', 'pack_episodes', 'episode_start', 'episode_end', 'first_season', 'last_season'):
							if key in donor: merged[key] = donor[key]
				yield merged
		# LOCAL PATCH 2026-09-22: a cached pack's REAL per-episode size. A pack row shows total_size / num_files, and
		# num_files counts subtitles, creditless OP/ED and extras (can be 10x+ low). TorBox's cache check returns a real file
		# listing for every CACHED hash. The file is chosen with pick_episode_files (as every debrid module, keyed on
		# short_name like TorBoxAPI.resolve_magnet, with episode_candidates), so the size is that of the file that will play.
		# Cached packs only: an uncached hash keeps the estimate; a single-file row already shows its true size.
		# LOCAL PATCH 2026-10-16: rows named like one episode that the listing shows are packs -> 'show' / 'season' (comet
		# names a stream by the FILE it picked), for the PACK tag and the SmartPlay pin.
		_found_packs = {}
		def _real_pack_sizes(provider, cached):
			"""({hash: real GB}, {hashes to drop}) for cached packs whose listing we hold."""
			out, drops = {}, set()
			if provider != 'TorBox' or self.media_type != 'episode' or self.season in (None, ''): return out, drops
			try:
				listings = query_local_cache_files(list(cached), 'tb')
				if not listings: return out, drops
				extensions = tuple(source_utils.supported_video_extensions())
				candidates = self.data.get('episode_candidates') or None
				for i in results:
					_hash = i.get('hash')
					if _hash not in listings: continue
					# LOCAL PATCH 2026-09-27: a torrent named like ONE episode can still be a pack (MediaFusion's DMM/Zilean rows
					# carry the first file as the title and the TOTAL size). More than one video file means a pack; the picked
					# file gives the real size. Such a row is never DROPPED here: it was not offered as a pack.
					is_pack = 'package' in i
					usable = self._usable_files(listings[_hash], extensions)   # LOCAL PATCH 2026-11-08: shared with _prepick
					if usable is None: continue
					if not usable: continue
					if not is_pack and len(usable) < 2: continue
					try: hits, _matched = self._first_pick(_hash, usable, candidates)   # LOCAL PATCH 2026-11-08: often done by _prepick
					except Exception: continue
					if hits:
						out[_hash] = float(hits[0]['size']) / 1073741824.0
						if not is_pack:
							_seasons = set(m.group(1).lstrip('0') for f in usable for m in [_RE_FILE_SEASON.search(str(f['filename']))] if m)
							_found_packs[_hash] = 'show' if len(_seasons) > 1 else 'season'
							kodi_utils.logger_debug('scrape.pack_found', '%s %s: %d videos, seasons %s' % (_hash[:10], _found_packs[_hash],
								len(usable), ','.join(sorted(_seasons, key=lambda s: int(s or 0))) or '?'))
						# LOCAL PATCH 2026-10-05: one FILE holding several episodes ('... S01E12-E17 (BD Remux).mkv') is shown per
						# episode, like a pack: its size over the range it states
						try:
							_rng = _RE_FILE_RANGE.search(str(hits[0]['filename']))
							if _rng:
								_a, _b = int(_rng.group(1)), int(_rng.group(2))
								if _a < _b and _b - _a < 60: out[_hash] /= (_b - _a + 1)
						except Exception: pass
						continue
					if not is_pack: continue
					# LOCAL PATCH 2026-09-22: the pack does not hold this episode -- drop the row (a name-declared range catches
					# only some; otherwise playback silently finds no file).
					# A MISS IS ONLY EVIDENCE IF THE MATCHER CAN READ THIS PACK: an unreadable naming convention also misses. So
					# the row is dropped only once the same matcher finds some OTHER episode in the listing. A pack it cannot
					# read is left alone (which also keeps an absolute-numbered pack from a cour-relative probe). Runs only after
					# the wanted episode missed, and stops at the first hit.
					# UNVERIFIED: this judges the checkcached listing while resolve_magnet picks from torrent_info; if they ever
					# diverge, this drops a playable row.
					_readable = False
					# LOCAL PATCH 2026-09-24: the listing prepared ONCE for every probe below -- they all pass candidates, so all
					# match strict. See source_utils.prepare_episode_files.
					try: _prep = source_utils.prepare_episode_files(usable, 'filename', self.title, strict=True)
					except Exception: _prep = None
					_listed = source_utils.listing_episode_numbers(usable)
					# LOCAL PATCH 2026-11-08: probe only the numbers the files write (a 1..60 sweep changed no decision over every
					# cached listing and cost up to ~1 s). A pack whose files write no number still gets listing_episode_pairs.
					_probes = _listed
					for _probe in _probes:
						if _probe == self.episode: continue
						try: _h, _m = source_utils.pick_episode_files(usable, self.season, _probe, 'filename', [(int(self.season), _probe)], self.title, prepared=_prep)
						except Exception: break
						if _h:
							_readable = True
							break
					# LOCAL PATCH 2026-09-24: then the pairs the files name themselves (source_utils.listing_episode_pairs): at
					# most 5 picks, only for a pack the probe above found unreadable.
					if not _readable:
						for _pair in source_utils.listing_episode_pairs(usable):
							if _pair == (int(self.season), int(self.episode)): continue
							try: _h, _m = source_utils.pick_episode_files(usable, _pair[0], _pair[1], 'filename', [_pair], self.title, prepared=_prep)
							except Exception: break
							if _h:
								_readable = True
								break
					if _readable:
						drops.add(_hash)
						kodi_utils.logger('scrape.pack_contents', 'drop %s (%d files, no episode %s)' % (_hash[:10], len(usable), self.episode))
			except Exception: pass
			return out, drops
		# LOCAL PATCH 2026-09-28: a cached torrent with NO video file in it is dropped (fakes: a film still in cinemas as a
		# lone '.exe'). The listing is the cache check's own (no extra request); the test is resolve_magnet's (short_name ends
		# with a supported video extension). Only ZERO video files counts; a stray .exe beside a real .mkv stays. A hash with
		# no listing is left alone: absence of a listing is not evidence.
		def _no_video_hashes(provider, cached):
			drops = set()
			if provider != 'TorBox' or not cached: return drops
			try:
				listings = query_local_cache_files(list(cached), 'tb')
				if not listings: return drops
				extensions = tuple(source_utils.supported_video_extensions())
				for _hash, blob in listings.items():
					try: _names = [str(f.get('name') or '') for f in json.loads(blob)]
					except Exception: continue
					if not _names or any(n.lower().endswith(extensions) for n in _names): continue
					drops.add(_hash)
					kodi_utils.logger_debug('fake filter', 'drop %s: no video file (%s)' % (_hash[:10], ', '.join(_names[:3])))
			except Exception: pass
			return drops
		# LOCAL PATCH 2026-10-16: a cached torrent whose ONE video file names another resolution than the row (a '2160p' row
		# holding a 720p file) is shown under the file's name, quality and size -- relabelled, not dropped: it is a real
		# episode. Only a single video naming a resolution counts; a pack's many files, or a bare 'Show.S01E01.mkv', say
		# nothing about the row.
		def _mislabelled(provider, cached):
			out = {}
			if provider != 'TorBox' or not cached: return out
			try:
				listings = query_local_cache_files(list(cached), 'tb')
				if not listings: return out
				extensions = tuple(source_utils.supported_video_extensions())
				for _hash, blob in listings.items():
					try: videos = [f for f in json.loads(blob) if str(f.get('name') or '').lower().endswith(extensions)]
					except Exception: continue
					if len(videos) != 1: continue
					fname = str(videos[0].get('name')).replace('\\', '/').split('/')[-1]
					if not _RESOLUTION_TOKEN.search(fname): continue
					quality, extra = source_utils.get_file_info(url=fname)
					out[_hash] = (fname, quality, extra, float(videos[0].get('size') or 0) / 1073741824.0)
			except Exception: pass
			return out
		def _process_cache_check(provider, function):
			if provider in ('Real-Debrid', 'AllDebrid'):
				if self.external_cache_check: cached = function(hash_list, cached_hashes, self.data, self.active_debrid)
				else: cached = hash_list
			else: cached = function(hash_list, cached_hashes)
			cached = set(cached or ())   # LOCAL PATCH 2026-10-25 (4.0.5): tested 3-4 times per row below -- was a list scan each time
			if self._diag_timing: _t_pack = time.perf_counter()
			_real, _drop = _real_pack_sizes(provider, cached)
			_fake = _no_video_hashes(provider, cached)
			_truth = _mislabelled(provider, cached)
			if self._diag_timing:
				kodi_utils.logger('scrape.timing', '%s pack + fake tests: %dms (%d cached, %d dropped)'
					% (provider, int((time.perf_counter() - _t_pack) * 1000), len(cached), len(_drop | _fake)))
			# LOCAL PATCH 2026-09-30: counted AFTER the listing tests, so a fake or a pack without the episode is not
			# counted as a cached source -- it never reaches the list
			if not self.background:
				self.counter_final.hide('wrong pack', len(_drop - _fake))
				self.counter_final.hide('fake', len(_fake))
				self.process_quality_count_final([i for i in results if i.get('hash') in cached and i.get('hash') not in _drop and i.get('hash') not in _fake])
			_drop = _drop | _fake
			# built locally and extended in ONE call: with several debrids enabled these run in
			# parallel threads, and a per-item append would interleave the providers' rows.
			_batch = []
			for i in results:
				# a cached pack the listing proves does not hold this episode never reaches
				# the picker -- it could only fail at playback, silently.
				if i.get('hash') in _drop: continue
				# LOCAL PATCH 2026-09-23: an UNVERIFIABLE season-only pack goes too: animetosho flags a pack whose name states a
				# season and no episodes ('Naruto Shippuden Season 3'), which nothing in the name contradicts. Uncached means no
				# listing to check and nothing playable without a download, so dropping it costs little. A cached one is judged
				# on its real contents above.
				if i.get('season_only') and i.get('hash') not in cached: continue
				_row = dict(i, **{'cache_provider': provider if i.get('hash') in cached else 'Uncached %s' % provider, 'debrid': provider})
				_size = _real.get(i.get('hash'))
				if _size is not None: _row.update({'size': round(_size, 2), 'size_label': '%.2f GB' % _size})
				if 'package' not in i and i.get('hash') in _found_packs: _row['package'] = _found_packs[i['hash']]
				_real_file = _truth.get(i.get('hash'))
				if _real_file and _real_file[1] != i.get('quality'):
					kodi_utils.logger_debug('fake filter', 'relabel %s: named %s (%s), holds %s (%s)' % (i['hash'][:10], i.get('quality'),
						(i.get('name') or '')[:60], _real_file[1], _real_file[0][:60]))
					_row.update({'name': _real_file[0], 'quality': _real_file[1], 'extraInfo': _real_file[2], 'mislabelled': True,
						'display_name': source_utils.clean_display_name(source_utils.normalize(_PLUS_SEPARATOR.sub(' ', _real_file[0]).replace('-', ' ')))})
					if _real_file[3]: _row.update({'size': round(_real_file[3], 2), 'size_label': '%.2f GB' % _real_file[3]})
				_batch.append(_row)
			final_results.extend(_batch)
		def _debrid_check_dialog():
			self.progress_dialog.reset_is_cancelled()
			start_time, timeout = time.time(), 20
			# LOCAL PATCH 2026-09-26: same shape as _scraperDialog -- 50 ms, sleep outside the try, alive-count after the sleep.
			while not self.progress_dialog.iscanceled() and not self.monitor.abortRequested():
				kodi_utils.sleep(50)
				try:
					remaining_debrids = [x.getName() for x in debrid_check_threads if x.is_alive() is True]
					current_progress = max((time.time() - start_time), 0)
					percent = int((current_progress/float(timeout))*100)
					rows = [(x.getName(), source_utils.provider_panel_name(x.getName()), 'checking' if x.is_alive() else 'done', 0) for x in debrid_check_threads]
					done = len([r for r in rows if r[2] == 'done'])
					left = max(0, int(round(timeout - current_progress)))
					shown = percent if len(rows) <= 1 else 100.0 * done / len(rows)
					# LOCAL PATCH 2026-09-30: the search phase's counts stay up until a debrid has answered (the cached counts
					# start with the internal sources alone, so they would drop and rise again).
					if done: counts, hidden = (self.final_sd, self.final_720p, self.final_1080p, self.final_4k, self.final_total), self.counter_final.line()
					else: counts, hidden = (self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total), self.counter.line()
					self.progress_dialog.update_scraper(*counts, '', shown,
						providers=rows, phase='Checking Debrid Cache', detail='%d of %d done  ·  %ds left' % (done, len(rows), left),
						time_pct=None if len(rows) <= 1 else percent, late=left <= 3, hidden=hidden)
					if len(remaining_debrids) == 0: break
					if percent >= 100: break
				except: pass
		try:
			if not self.background and self.all_internal_sources: self.process_quality_count_final(self.all_internal_sources)
			final_results = []
			results = list(_process_duplicates(results))
			hash_list = list(set([i['hash'] for i in results if i.get('hash')]))   # LOCAL PATCH 2026-10-15: a hashless row must not raise
			# LOCAL PATCH 2026-10-02: see _prefetch_debrid. Bounded: a stuck check costs at most 5 s, after which the final
			# check simply asks for whatever is still unknown (a hash still in flight is then asked twice, and the later of
			# the two cache writes fails on the unique key -- the verdicts returned are right either way).
			_t_check = time.perf_counter()
			if self._diag_timing:
				try: kodi_utils.logger('scrape.prefetch', 'providers done at +%dms' % ((_t_check - self._prefetch_t0) * 1000))
				except Exception: pass
			from apis.torbox_api import not_answering as _tb_stalled
			# LOCAL PATCH 2026-10-25 (4.0.6): no wait for an early check stuck on a stalling TorBox (see below)
			_tb_only = list(self.active_debrid) == ['TorBox']
			_deadline = time.time() + (0 if _tb_only and _tb_stalled() else 5)
			for _thread in list(getattr(self, '_prefetch_threads', [])):
				_thread.join(max(0, _deadline - time.time()))
			if self._diag_timing:
				kodi_utils.logger('scrape.timing', 'debrid prefetch wait: %dms (%d prefetched of %d hashes)'
					% (int((time.perf_counter() - _t_check) * 1000), len(getattr(self, '_prefetch_seen', ())), len(hash_list)))
			_t_waited = time.perf_counter()
			cached_hashes = query_local_cache(hash_list)
			try: _known = dict((d, set(r[0] for r in cached_hashes if r[1] == d)) for d in ('rd', 'tb'))
			except Exception: _known = {'rd': set(), 'tb': set()}
			# LOCAL PATCH 2026-10-25 (4.0.6): TorBox stalling (torbox_api.not_answering) is no cache check at all -- its rows could not
			# be played either. With no other debrid left the scrape ends here with no torrent rows; Direct Streams (another
			# scraper) are kept, and sources._process_post_results says why when nothing is left at all.
			_checks = self.active_debrid
			if 'TorBox' in _checks and _tb_stalled():
				_checks = [d for d in _checks if d != 'TorBox']
				if not _checks:
					kodi_utils.logger('scrape.tb_down', 'TorBox is not answering: %d torrent results dropped, no cache check' % len(results))
					return []
			debrid_check_threads = [Thread(target=_process_cache_check, args=self.debrid_runners[item], name=item) for item in _checks]
			[i.start() for i in debrid_check_threads]
			# LOCAL PATCH 2026-10-25 (4.0.5): the background (next-episode) wait is limited to the dialog's own 20 s. A late
			# check's rows are left out (cut at its length now: the late thread still extends the same list -- a closure cell,
			# so it must not be rebound here).
			_cut = None
			if self.background:
				_check_deadline = time.time() + 20
				for _thread in debrid_check_threads: _thread.join(max(0.0, _check_deadline - time.time()))
				_late = [t.name for t in debrid_check_threads if t.is_alive()]
				if _late:
					kodi_utils.logger('scrape.background', 'not waiting for the %s cache check (20 s)' % ', '.join(_late))
					_cut = len(final_results)
			else: _debrid_check_dialog()
			if self._diag_timing:
				kodi_utils.logger('scrape.timing', 'debrid check: %dms (%d results)' % (int((time.perf_counter() - _t_check) * 1000), len(final_results)))
			# LOCAL PATCH 2026-10-11: always one line -- where the 2-3 s between the last provider and the results go
			try: kodi_utils.logger('scrape.wait', 'providers done -> results: prefetch wait %dms, final check %dms, %d hashes (rd known %d, tb known %d '
				'before the final check), %d results; early check: %s' % ((_t_waited - _t_check) * 1000, (time.perf_counter() - _t_waited) * 1000, len(hash_list),
				len(_known['rd'] & set(hash_list)), len(_known['tb'] & set(hash_list)), len(final_results),
				', '.join('%s %d batch(es) %dms' % (n, v[0], v[1]) for n, v in sorted(getattr(self, '_prefetch_stats', {}).items())) or 'none'))
			except Exception: pass
			return final_results if _cut is None else final_results[:_cut]
		except Exception:   # LOCAL PATCH 2026-10-15: providers had answered, the panel showed their counts, then 'No results'
			_log_trace('scrape.results', 'processing the provider results failed')
			return []

	_SEASON_NAME_STOP = frozenset(('season', 'seasons', 'part', 'cour', 'series', 'the', 'and', 'first', 'second', 'third', 'fourth',
		'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth', 'final', 'last', 'saga', 'chapter', 'arc', 'final', 'specials'))

	def _other_season_words(self, target):
		"""LOCAL PATCH 2026-11-03: [(season, {words}), ...] -- each OTHER regular TMDb season whose name has words of its own: its
		name less the show's title words, generic words and words under 4 letters (Monogatari season 1: [(2,
		{'nisemonogatari'}), ...]). A season named only 'Season N' or after the show gives nothing. Once per scrape."""
		cached = getattr(self, '_other_season_words_cache', None)
		if cached is not None and cached[0] == target: return cached[1]
		out = []
		try:
			# a season the EPISODE'S OWN title names is not another one (a remapped special such as 'Owarimonogatari: Mayoi Hell (1)'
			# must not be rejected by the TMDb season named 'Owarimonogatari')
			ep_words = set(re.findall(r'[a-z0-9]+', str(self.data.get('title') or '').lower()))
			title_words = set(re.findall(r'[a-z0-9]+', (self.title or '').lower()))
			# LOCAL PATCH 2026-11-04: an alias counts as the SHOW's title only when it shares no word with another season's name:
			# TMDb lists 'Bleach: Thousand-Year Blood War' as an alias of Bleach itself, which would empty TYBW's season words.
			_season_name_words = set()
			for sn in (self.meta.get('season_data') or []):
				try:
					if int(sn.get('season_number')) > 0: _season_name_words |= set(re.findall(r'[a-z0-9]+', (sn.get('name') or '').lower()))
				except (TypeError, ValueError): continue
			_season_name_words -= title_words | self._SEASON_NAME_STOP
			_season_name_words = set(w for w in _season_name_words if len(w) >= 4 and not w.isdigit())
			for alias in (self.data.get('aliases') or []):
				try:
					_aw = set(re.findall(r'[a-z0-9]+', str(alias.get('title') if isinstance(alias, dict) else alias).lower()))
					if not (_aw & _season_name_words): title_words |= _aw
				except Exception: pass
			for sn in (self.meta.get('season_data') or []):
				try: n = int(sn.get('season_number'))
				except (TypeError, ValueError): continue
				if n <= 0 or n == target: continue
				words = set(w for w in re.findall(r'[a-z0-9]+', (sn.get('name') or '').lower())
							if len(w) >= 4 and not w.isdigit() and w not in self._SEASON_NAME_STOP and w not in title_words)
				if words and not words <= ep_words: out.append((n, words))
		except Exception: out = []
		self._other_season_words_cache = (target, out)
		return out

	def _drop_not_episodes(self, provider, sources):
		"""LOCAL PATCH 2026-10-06: anime rows that are not this episode, from every provider, after the cache (so rows cached
		before a rule are judged too). LOCAL PATCH 2026-11-04: the one release judge (modules/release_judge.judge): not an
		episode, another season by its name or year, specials only, a single whose name contradicts this episode's numbers,
		a pack naming another cour."""
		if not sources or not getattr(self, '_is_anime', False): return sources
		try:
			from modules.release_judge import context_for, judge
			ctx = context_for(self)
			if ctx is None: return sources
			kept, dropped = [], []
			for i in sources:
				keep, why = judge(i, provider, ctx)
				if keep: kept.append(i)
				else: dropped.append('%s: %s' % (why, (i.get('name') or '')[:70]))
			if dropped: kodi_utils.logger('anime.not_episode', '%s: dropped %d -- %s' % (provider, len(dropped), ' | '.join(dropped[:3])))
			return kept
		except Exception:
			# some providers leave anime rows to the judge alone -- a failure here must be seen, not swallowed
			_log_trace('anime.not_episode', '%s: the release judge failed, %d rows unjudged' % (provider, len(sources)))
			return sources

	def process_sources(self, provider, sources):
		# LOCAL PATCH 2026-10-25: the fansub group magneto's clean_name() cut off the front of the name ('[SubsPlease]'),
		# for the picker's Group column and the known-group sort (modules/release_groups.py)
		try: from magneto.modules.source_utils import stripped_group
		except Exception: stripped_group = lambda name: ''
		try:
			for i in sources:
				try:
					i_get = i.get
					if not i_get('release_group'):
						_group = stripped_group(i_get('name'))
						if _group: i['release_group'] = _group
					size, size_label, divider = 0, None, None
					if 'hash' in i:
						_hash = i_get('hash').lower()
						i['hash'] = str(_hash)
					display_name = source_utils.clean_display_name(source_utils.normalize(_PLUS_SEPARATOR.sub(' ', i['name'].replace('html', ' ')).replace('-', ' ')))
					if 'name_info' in i: quality, extraInfo = source_utils.get_file_info(name_info=i_get('name_info'))
					else: quality, extraInfo = source_utils.get_file_info(url=i_get('url'))
					try:
						size = i_get('size')
						# LOCAL PATCH 2026-08-27 / 2026-09-25 / 2026-10-03: source_utils.pack_size_divider. A TMDb season's
						# episode_count is often unrelated to what an anime pack holds; providers that report a per-episode size
						# themselves (source_utils.PER_EPISODE_PROVIDERS: animetosho, seadex, nekobt) are not divided again.
						divider = source_utils.pack_size_divider(i, provider, self.season_divider, self.show_divider,
							self._season_counts, self.data.get('season_length'), self.total_seasons)
						if divider: size = float(size) / divider
						size_label = '%.2f GB' % size
					except: pass
					i.update({'provider': provider, 'display_name': display_name, 'external': True, 'scrape_provider': self.scrape_provider, 'extraInfo': extraInfo,
							'quality': quality, 'size_label': size_label, 'size': round(size, 2)})
				except: pass
		except: pass
		return sources

	def process_quality_count(self, sources):
		sources = self.counter.keep(sources)
		for item in self.count_tuple: setattr(self, item[0], getattr(self, item[0]) + item[2](sources, item[1]))

	def process_quality_count_final(self, sources):
		sources = self.counter_final.keep(sources)
		for item in self.count_tuple_final: setattr(self, item[0], getattr(self, item[0]) + item[2](sources, item[1]))

	def _provider_rows(self, final=False):
		"""LOCAL PATCH 2026-09-27: one row per provider for the loading window -- pack threads ('comet (Season)')
		fold into their provider; internal scrapers count as done once their results were read."""
		rows, seen = [], {}
		for t in list(self.threads):
			base = t.getName().split(' (')[0]
			seen[base] = seen.get(base, False) or t.is_alive()
		for base, alive in seen.items():
			n = self.provider_counts.get(base, 0)
			state = ('timeout' if final else 'running') if alive else ('done' if n else ('failed' if base in self.provider_failed else 'none'))
			rows.append((base, source_utils.provider_panel_name(base), state, n))
		for i in self.internal_scrapers:
			done = i in self.processed_internal_scrapers
			n = self.provider_counts.get(i, 0)
			state = ('done' if n else 'none') if done else ('timeout' if final else 'running')
			rows.append((i, source_utils.provider_panel_name(i), state, n))
		return rows

	def process_internal_results(self):
		if self.internal_prescraped and not self.processed_prescrape:
			self.all_internal_sources += self.prescrape_sources
			self.process_quality_count(self.prescrape_sources)
			self.processed_prescrape = True
		for i in self.internal_scrapers:
			win_property = kodi_utils.get_property('deadlight.internal_results.%s' % i)
			if win_property in ('checked', '', None): continue
			try: internal_sources = json.loads(win_property)
			except: continue
			kodi_utils.set_property('deadlight.internal_results.%s' % i, 'checked')
			self.all_internal_sources += internal_sources
			self.processed_internal_scrapers_append(i)
			self.provider_counts[i] = len(internal_sources)
			self.process_quality_count(internal_sources)
		return [i for i in self.internal_scrapers if not i in self.processed_internal_scrapers]

	def _quality_length(self, items, quality):
		return len([i for i in items if i['quality'] == quality])

	def _quality_length_sd(self, items, dummy):
		return len([i for i in items if i['quality'] in ('SD', 'CAM', 'TELE', 'SYNC')])

	def quality_length_final(self, items, dummy):
		return len(items)