# -*- coding: utf-8 -*-
import sys
# LOCAL PATCH 2026-10-16: process start, for the ###page timing### line (modules/page_prefetch.log_page)
from modules import page_prefetch as _page_timing
_page_timing.mark_start()
from modules.router import routing, sys_exit_check

# LOCAL PATCH 2026-10-15: module state back to a fresh interpreter's -- matters only with Reuse Language Invoker on
# LOCAL PATCH 2026-11-01 (cleanup): unguarded -- begin() guards every step itself
from modules.invocation import begin as _begin
_begin()
# LOCAL PATCH 2026-11-01 (cleanup): the handle and the raw query parsed once. A later duplicate key wins; on a failure
# each use below is skipped.
try: _handle = int(sys.argv[1])
except Exception: _handle = None
try: _query = dict(p.split('=', 1) for p in sys.argv[2].lstrip('?').split('&') if '=' in p)
except Exception: _query = None
# LOCAL PATCH 2026-10-20: identical WIDGET calls one at a time. After a playback stop Kodi reloads a widget once per
# invalidating event (return to Home, library announcement, DeadLight's reload), and a superseded reload cannot stop the
# Python already running, so several ran at once, each ~10x slower. A widget call that finds the same call running waits
# for it (caches warm) instead of competing; every call still returns its full list. A claim older than
# _WIDGET_WAIT_SECONDS is a dead call and ignored. In-addon lists never wait.
_widget_claim = None
try:
	if _handle is not None and _handle >= 0:
		from modules.kodi_utils import external as _external
		if _external():
			import zlib as _zlib, time as _wtime, xbmc as _xbmc
			from modules.kodi_utils import get_property as _get_prop, set_property as _set_prop
			_WIDGET_WAIT_SECONDS = 10
			# LOCAL PATCH 2026-11-08: crc32 + adler32 instead of md5 -- hashlib loads OpenSSL (~2.7 ms per widget call); the key
			# is only a window-property name for this session
			_kb = (sys.argv[0] + sys.argv[2]).encode('utf-8')
			_claim = 'deadlight.widget_busy.%08x%08x' % (_zlib.crc32(_kb), _zlib.adler32(_kb))
			_monitor = _xbmc.Monitor()
			while True:
				try: _busy = float(_get_prop(_claim) or 0)
				except ValueError: _busy = 0
				if not 0 <= _wtime.time() - _busy < _WIDGET_WAIT_SECONDS: break
				if _monitor.waitForAbort(0.05): break
			_set_prop(_claim, '%.3f' % _wtime.time())
			_widget_claim = _claim
			_set_prop(_page_timing.WIDGET_LAST_PROP, '%.3f' % _wtime.time())   # LOCAL PATCH 2026-10-25 (4.0.5): widget burst still on?
			del _monitor   # LOCAL PATCH 2026-10-22: see the release at the end of this file
except Exception: pass
# LOCAL PATCH 2026-11-01: Kodi's spinner for a context-menu action still working after 0.4 s (modules/busy_guard.py)
_busy_guard = None
try:
	if _handle is not None and _handle < 0:
		from modules import busy_guard as _bg
		_bg_mode = _query.get('mode', '')
		if _bg.wanted(_handle, _bg_mode):
			_bg.start()
			_busy_guard = _bg
except Exception: pass
try: routing(sys)
finally:
	if _busy_guard:
		try: _busy_guard.stop()
		except Exception: pass
	if _widget_claim:
		try:
			from modules.kodi_utils import clear_property as _clear_prop
			_clear_prop(_widget_claim)
		except Exception: pass
# LOCAL PATCH 2026-10-19: one ###nav timing### line per directory call -- file start to routing()'s return (list on
# screen), then the after-work. Kodi runs every plugin call on one shared interpreter lock, so that after-work competes
# with the next page opened.
_nav_t1 = None
try:
	if _handle is not None and _handle >= 0:
		import time as _nav_time
		_nav_t1 = _nav_time.time()
		_nav_q = _query
		_nav_name = '%s %s' % (_nav_q.get('mode', ''), _nav_q.get('action') or _nav_q.get('browse_type') or _nav_q.get('list_type') or '')
		if _nav_q.get('new_page'): _nav_name += ' p%s' % _nav_q['new_page']
		# LOCAL PATCH 2026-10-25 (4.0.5): kept at INFO: one or two lines per directory call, the only timing of what a browse
		# costs on the real box.
		from modules.kodi_utils import logger as _nav_logger, external as _nav_external
		_nav_logger('nav timing', '%s%s: list %.2f s' % (_nav_name.strip(), ' (widget)' if _nav_external() else '', _nav_t1 - _page_timing.PROCESS_START))
except Exception: _nav_t1 = None
# LOCAL PATCH 2026-10-06: the scrape ids of an anime episode list's next episodes (modules/scrape_prewarm.py), on a
# thread started FIRST -- behind the rating backfills, a play clicked 2 s in raced it. The exit wait below joins it.
_prewarm = sys.modules.get('modules.scrape_prewarm')
if _prewarm is not None:
	try:
		import threading as _threading
		_threading.Thread(target=_prewarm.run, name='scrape_prewarm').start()
	except Exception: pass
# LOCAL PATCH 2026-09-26: rating backfills a directory listing deferred (metadata.flush_rating_backfills). routing() has
# returned, so the list is already delivered; only runs if this process loaded metadata.
_metadata = sys.modules.get('modules.metadata')
if _metadata is not None:
	try: _metadata.flush_rating_backfills()
	except Exception: pass
# LOCAL PATCH 2026-11-08: then the filler / recap flags an episode list could not mark yet (modules/anime_filler.py)
_filler = sys.modules.get('modules.anime_filler')
if _filler is not None:
	try: _filler.flush_pending()
	except Exception: pass
# LOCAL PATCH 2026-10-02: then warm the next page of a catalogue list (modules/page_prefetch.py).
_prefetch = sys.modules.get('modules.page_prefetch')
if _prefetch is not None:
	try: _prefetch.run()
	except Exception: pass
# LOCAL PATCH 2026-09-27: close every database handle ourselves rather than at Kodi's interpreter teardown -- see
# caches/base_cache.close_all_connections for the deadlock this avoids.
# LOCAL PATCH 2026-10-02: but first wait for this process's own worker threads: closing a handle under a live worker
# (e.g. batch_erase_bookmark's per-episode threads, widget syncs) crashed Kodi in _sqlite3.pyd. The list or action is
# already done, so waiting costs nothing visible; past the cap the close is skipped rather than risk the crash.
# LOCAL PATCH 2026-10-19: DAEMON threads too -- Kodi runs each call in a sub-interpreter, and Python 3.8 cannot end one
# while any of its threads runs, daemon or not (tmdb_api._warm_connections starts daemon threads).
import threading, time
def _ours(t):   # Kodi's own threads seen from Python (_DummyThread) cannot be joined and never end
	return t is not threading.current_thread() and not isinstance(t, threading._DummyThread)
# LOCAL PATCH 2026-10-25 (4.0.5): joined in 0.5 s slices and given up on Kodi's abort -- Kodi kills a script ~5 s after
# quit is requested.
_deadline, _aborted = time.time() + 60, False
try:
	from modules.kodi_utils import kodi_monitor as _exit_monitor
	_exit_monitor = _exit_monitor()
except Exception: _exit_monitor = None
# LOCAL PATCH 2026-11-01: re-enumerated until none is left -- a thread can start one while it is being joined, and the
# sub-interpreter ending under it crashes Kodi (python3.8.dll access violation).
_stuck = False
while not _aborted and not _stuck and time.time() < _deadline:
	_live = [_t for _t in threading.enumerate() if _ours(_t) and _t.is_alive()]
	if not _live: break
	for _t in _live:
		while _t.is_alive() and time.time() < _deadline and not _aborted:
			try: _t.join(min(0.5, max(0, _deadline - time.time())))
			except Exception: _stuck = True; break   # cannot be joined: stop waiting (no busy loop to the deadline)
			try: _aborted = _exit_monitor is not None and _exit_monitor.abortRequested()
			except Exception: pass
		if _aborted or _stuck: break
_exit_monitor = None
_still_busy = any(_t.is_alive() for _t in threading.enumerate() if _ours(_t))
_waited = 60 - (_deadline - time.time())
if _waited > 1 or _still_busy:
	try:
		from modules.kodi_utils import logger, logger_debug
		(logger if _still_busy else logger_debug)('exit wait', '%.1f s for worker threads%s%s' % (_waited,
			'; still running, databases left open' if _still_busy else '', ' (Kodi is quitting)' if _aborted else ''))
	except Exception: pass
if _nav_t1 is not None and time.time() - _nav_t1 > 0.5:
	try: _nav_logger('nav timing', '%s: after the list %.2f s (backfills / prefetch / prewarm)' % (_nav_name.strip(), time.time() - _nav_t1))
	except Exception: pass
_base_cache = sys.modules.get('caches.base_cache')
if _base_cache is not None and not _still_busy:
	try: _base_cache.close_all_connections()
	except Exception: pass
# LOCAL PATCH 2026-10-22: release the cached xbmc.Monitor (kodi_utils.kodi_monitor keeps one per process) once no worker
# can still wait on it; left alive, Kodi logs 'left several classes in memory ... XBMCAddon::xbmc::Monitor'.
if not _still_busy:
	_kodi_utils = sys.modules.get('modules.kodi_utils')
	if _kodi_utils is not None:
		try: _kodi_utils._kodi_monitor_instance = None
		except Exception: pass
if sys_exit_check(): sys.exit(1)
