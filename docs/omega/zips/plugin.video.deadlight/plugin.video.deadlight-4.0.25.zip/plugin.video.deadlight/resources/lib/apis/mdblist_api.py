# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-23 / OAuth port 2026-08-07: MDBList (mdblist.com) integration ported from POV.
# Auth is DUAL, detected per call via the `mdblist.refresh` setting:
#   - OAuth device-code (POV 6.07+, user's own client_id): `Authorization: Bearer`; mdbl_expires() refreshes
#     proactively via /oauth/token/.
#   - Legacy API key: `?apikey=...` query param, no refresh. Installs stay on it until they re-authorize.
# Differs from POV's mdblist_api.py: pooled `kodi_utils.make_session`, DeadLight module paths
# (`caches.mdblist_cache`, `caches.settings_cache.get_setting`), and `apis.tmdb_api` external-id helpers to
# normalise MDBList's mixed-id rows.

from threading import Lock
import time
from operator import itemgetter
from urllib.parse import quote
from caches import mdblist_cache
from caches.base_cache import sync_since
from caches.main_cache import cache_object
from caches.settings_cache import get_setting, set_setting
from modules import kodi_utils, settings
from modules.utils import sort_for_article, jsondate_to_datetime, get_datetime, TaskPool, safe_err

EXPIRES_1_HOURS = 1
MAX_LIST_ITEMS = 250_000
BASE_URL = 'https://api.mdblist.com/%s'
TIMEOUT = 5.05

logger = kodi_utils.logger

# Pooled HTTP session — same pattern as apis/trakt_api.py:13.
session = kodi_utils.make_session('https://api.mdblist.com/')

# LOCAL PATCH 2026-09-14: rate-limit circuit breaker, mirroring apis/omdb_api.py. A 429 must not look like "no
# data": callers would cache the gap (metadata backfill once deferred a whole library by 24 h for a throttle that
# clears in minutes). Any caller's 429 trips it (the limit is per key). Read by progress sync (watched_status) and
# the pending drop-list flush (mdbl_flush_pending), which stand down while it is open, and by the lists indexer,
# whose 'rate limited' toast names the wait -- user actions must fail visibly, not vanish.
# Window property, not module state: reuselanguageinvoker=false wipes globals per invocation. MDBList's throttle is
# a burst limit rather than OMDb's daily quota, so the window is short. Retry-After wins when the response has one.
_COOLDOWN_PROP = 'deadlight.mdblist_cooldown_until'
_COOLDOWN_DEFAULT = 300
_COOLDOWN_MIN, _COOLDOWN_MAX = 60, 3600


# LOCAL PATCH 2026-09-16: pace calls so a parallel meta build cannot spend MDBList's BURST allowance in one go --
# a different limit from the daily quota (28 threads at ~11 req/s drew 429s with most of the day's calls unused,
# and the breaker then silenced every remaining title).
# The pacing state must be CROSS-INVOCATION: reuselanguageinvoker=false gives each invocation its own module, and
# Kodi runs several at once, so a module Lock alone paces only one invocation's threads (seven invocations at 4/s
# is still 28/s at the key). The last-call timestamp lives in a window property; the Lock still serialises threads
# within an invocation. The read-then-write is not atomic across invocations; a small jitter keeps them from
# re-synchronising, and the breaker catches whatever gets past.
_PACE_PROP = 'deadlight.mdblist_last_call'
_MIN_CALL_INTERVAL = 0.25
_throttle_lock = Lock()


def _throttle():
	"""Block until at least _MIN_CALL_INTERVAL has passed since the last call by ANY invocation."""
	try:
		with _throttle_lock:
			for _ in range(40):   # bounded: never stall a request longer than ~10s
				try: last = float(kodi_utils.get_property(_PACE_PROP) or 0)
				except (TypeError, ValueError): last = 0
				wait = _MIN_CALL_INTERVAL - (time.time() - last)
				if wait <= 0: break
				import random as _random   # LOCAL PATCH 2026-11-08: only when pacing
				time.sleep(min(wait, 0.25) + _random.uniform(0, 0.05))
			kodi_utils.set_property(_PACE_PROP, str(time.time()))
	except Exception:
		pass


def mdblist_cooldown_minutes():
	"""Whole minutes left on the cooldown, 0 when none. For user-facing messages."""
	try:
		until = float(kodi_utils.get_property(_COOLDOWN_PROP) or 0)
		return max(0, int((until - time.time()) // 60))
	except Exception:
		return 0


def mdblist_on_cooldown():
	"""True while MDBList is known rate-limited (see the breaker at the top of this module)."""
	return kodi_utils.cooldown_active(_COOLDOWN_PROP)


def _start_cooldown(retry_after=None, reason='HTTP 429'):
	try:
		try: secs = int(float(retry_after))
		except (TypeError, ValueError): secs = _COOLDOWN_DEFAULT
		secs = max(_COOLDOWN_MIN, min(secs, _COOLDOWN_MAX))
		kodi_utils.start_cooldown(_COOLDOWN_PROP, secs)
		logger('MDBList', 'rate limited (%s) - skipping MDBList ratings for %d min' % (reason, secs // 60))
	except Exception: pass


# ═══════════════════════════════════════════════════════════════════════════
#  Authorize / Revoke
#
#  LOCAL PATCH 2026-08-07 (POV 6.07 OAuth port): device-code flow replaces the API-key paste dialog. The user
#  registers their own MDBList "app" (mdblist.com preferences → Applications) for a client_id.
#   1. POST /oauth/device-authorization/ {client_id, scope='write'} → device_code, user_code, verification_uri,
#      expires_in, interval
#   2. Show user_code + URL, poll /oauth/token/ every `interval` seconds
#   3. On success store access_token, refresh_token, expires_in
#   4. GET /user with Bearer → username
#  Legacy API-key mode still works (see the header).
# ═══════════════════════════════════════════════════════════════════════════

_DEVICE_CODE_URL = BASE_URL % 'oauth/device-authorization/'
_TOKEN_URL = BASE_URL % 'oauth/token/'
_DEVICE_GRANT = 'urn:ietf:params:oauth:grant-type:device_code'


def _mdbl_client_id():
	v = (get_setting('deadlight.mdblist.client_id', '') or '').strip()
	return v if v and v != 'empty_setting' else ''


def mdbl_refresh():
	"""Trade refresh_token for a new access_token. Called by mdbl_expires() before
	expiry, and also proactively from MDBListMonitor. Silent on failure."""
	import time as _t, requests as _rq
	try:
		client_id = _mdbl_client_id()
		refresh_tok = get_setting('deadlight.mdblist.refresh', '')
		if not client_id or not refresh_tok or refresh_tok == 'empty_setting': return False
		created_at = _t.time()
		data = {'grant_type': 'refresh_token', 'refresh_token': refresh_tok, 'client_id': client_id}
		r = _rq.post(_TOKEN_URL, data=data, timeout=TIMEOUT)
		if not r.ok:
			logger('mdbl_refresh error', 'HTTP %s: %s' % (r.status_code, r.text[:200]))
			return False
		response = r.json()
		new_token = response.get('access_token')
		new_refresh = response.get('refresh_token') or refresh_tok
		expires_in = int(response.get('expires_in') or 0)
		# LOCAL PATCH 2026-10-15: save the new tokens even without expires_in. Returning False there dropped them after
		# the old refresh token may already have been rotated away; an hour is assumed and the next 401 refreshes again.
		if not new_token: return False
		if not expires_in: expires_in = 3600
		set_setting('mdblist.token', new_token)
		set_setting('mdblist.refresh', new_refresh)
		set_setting('mdblist.expires', str(int(created_at) + expires_in))
		return True
	except Exception as e:
		logger('mdbl_refresh error', safe_err(e))
		return False


def mdbl_expires():
	"""Refresh access_token if it will expire within the next sync interval.
	Called by MDBListMonitor before every sync tick. No-op when in API-key mode."""
	try:
		refresh_tok = get_setting('deadlight.mdblist.refresh', '')
		if not refresh_tok or refresh_tok == 'empty_setting': return
		from datetime import datetime, timezone
		try: interval_sec = int(settings.mdblist_sync_interval()[1] or 3600)
		except Exception: interval_sec = 3600
		current = int(datetime.now(timezone.utc).timestamp())
		try: expires = int(get_setting('deadlight.mdblist.expires', '0') or 0)
		except (TypeError, ValueError): expires = 0
		if interval_sec + current >= expires: mdbl_refresh()
	except Exception: pass


def mdblist_authenticate(dummy=''):
	"""OAuth device-code flow (POV 6.07 port). Falls back to API-key paste when
	client_id is not configured (backward compatibility for existing setups)."""
	import time as _t, requests as _rq
	client_id = _mdbl_client_id()
	if not client_id:
		# Prompt for client_id, then continue into OAuth. Cancel = falls through
		# to legacy API-key paste for users who prefer that.
		client_id = kodi_utils.kodi_dialog().input('MDBList Client ID (register at mdblist.com preferences)') or ''
		client_id = client_id.strip()
		if client_id:
			set_setting('mdblist.client_id', client_id)
		else:
			# No client_id → legacy API-key path
			return _mdblist_authenticate_apikey()

	# OAuth device-code flow
	try:
		r = _rq.post(_DEVICE_CODE_URL, data={'client_id': client_id, 'scope': 'write'}, timeout=TIMEOUT)
		if not r.ok:
			kodi_utils.ok_dialog('MDBList Authorize', 'Device authorization failed: HTTP %s\n%s' % (r.status_code, r.text[:200]))
			return False
		device_data = r.json()
	except Exception as e:
		kodi_utils.ok_dialog('MDBList Authorize', 'Device authorization request failed:\n%s' % str(e)[:200])
		return False

	device_code = device_data['device_code']
	user_code = device_data['user_code']
	verification_uri = device_data['verification_uri']
	expires_in = int(device_data.get('expires_in', 900))
	interval = int(device_data.get('interval', 5))

	# Copy code to clipboard for easy paste
	try:
		from modules.utils import copy2clip
		copy2clip(user_code)
	except Exception: pass

	# Poll for token
	# LOCAL PATCH 2026-09-30: a QR code beside the code (kodi_utils.qr_dialog), and BACK cancels the 30-minute wait.
	# MDBList's verification_uri_complete already carries the code, so scanning it leaves only the sign-in.
	poll_data = {'device_code': device_code, 'client_id': client_id, 'grant_type': _DEVICE_GRANT}
	def _poll():
		pr = _rq.post(_TOKEN_URL, data=poll_data, timeout=TIMEOUT)
		if pr.ok:
			token_resp = pr.json()
			if token_resp.get('access_token'): return token_resp
	token_resp = kodi_utils.qr_dialog('MDBList Authorize', device_data.get('verification_uri_complete') or verification_uri,
		'Scan the [B]QR code[/B] -- the code is filled in -- and sign in.[CR]Or open [B]%s[/B] and enter:   '
		'[COLOR gold][B]%s[/B][/COLOR][CR]DeadLight carries on once you confirm. [B]Back[/B] cancels.' % (verification_uri, user_code),
		wait=expires_in, poll=_poll, interval=interval) or {}
	access_token = token_resp.get('access_token')
	refresh_token = token_resp.get('refresh_token', '')
	token_expires_in = int(token_resp.get('expires_in') or 0)

	if not access_token:
		kodi_utils.notification('MDBList Authorize cancelled or timed out', 5000)
		return False

	# Fetch username via authorized /user endpoint
	created_at = int(_t.time())
	try:
		r = _rq.get(BASE_URL % 'user', headers={'Authorization': 'Bearer %s' % access_token}, timeout=TIMEOUT)
		username = str(r.json().get('username') or 'MDBList User')
	except Exception:
		username = 'MDBList User'

	set_setting('mdblist.token', access_token)
	set_setting('mdblist.refresh', refresh_token)
	set_setting('mdblist.expires', str(created_at + token_expires_in) if token_expires_in else '')
	set_setting('mdblist.user', username)
	set_setting('watched_indicators', '2')
	kodi_utils.notification('MDBList Authorized as %s' % username, 4000)
	try: mdbl_sync_activities(force_update=True)
	except Exception: pass
	return True


def _mdblist_authenticate_apikey():
	"""Legacy API-key authorize path — retained for users who prefer the old flow
	OR don't want to register an OAuth app. Wipes any OAuth artifacts on success
	so call_mdblist reverts to apikey mode."""
	existing = (get_setting('deadlight.mdblist.token', '') or '').strip()
	if existing and existing != 'empty_setting':
		token = existing
	else:
		token = kodi_utils.kodi_dialog().input('MDBList API Key (from mdblist.com/preferences)')
		if not token: return False
	set_setting('mdblist.token', token)
	# Wipe OAuth artifacts so call_mdblist uses apikey query param.
	set_setting('mdblist.refresh', 'empty_setting')
	set_setting('mdblist.expires', 'empty_setting')
	try:
		user_info = call_mdblist('user')
		if not user_info or not user_info.get('username'):
			raise ValueError('missing username')
		username = str(user_info['username'])
	except Exception as e:
		logger('mdblist auth error', safe_err(e))
		set_setting('mdblist.token', 'empty_setting')
		kodi_utils.notification('MDBList Error Authorizing', 3000)
		return False
	set_setting('mdblist.user', username)
	set_setting('watched_indicators', '2')
	kodi_utils.notification('MDBList Account Authorized (API key mode)', 3500)
	try: mdbl_sync_activities(force_update=True)
	except Exception: pass
	return True


def mdblist_revoke_authentication(dummy=''):
	set_setting('mdblist.user', 'empty_setting')
	set_setting('mdblist.token', 'empty_setting')
	set_setting('mdblist.refresh', 'empty_setting')
	set_setting('mdblist.expires', 'empty_setting')
	set_setting('watched_indicators', '0')
	try:
		mdblist_cache.clear_all_mdbl_cache_data(silent=True, refresh=False)
	except: pass
	kodi_utils.notification('MDBList Account Authorization Reset', 3000)


# ═══════════════════════════════════════════════════════════════════════════
#  Low-level HTTP + pagination
# ═══════════════════════════════════════════════════════════════════════════

def call_mdblist(path, params=None, json=None, method=None):
	"""Single entry-point for MDBList HTTP calls. Dual-mode auth:
	  - OAuth (POV 6.07+): if `mdblist.refresh` set → `Authorization: Bearer <token>`
	  - Legacy API key: else → `?apikey=<token>` query param
	Cursor-based pagination via `X-Has-More` + `X-Next-Cursor` response headers.

	LOCAL PATCH 2026-08-06: single retry on ConnectionError/ConnectionResetError. After sleep/wake the pooled
	session's sockets go stale and the first request gets WinError 10054; one retry gets a fresh socket."""
	import requests as _rq
	params = dict(params or {})
	# LOCAL PATCH 2026-08-07: OAuth-vs-apikey mode detection.
	refresh_tok = get_setting('deadlight.mdblist.refresh', '')
	oauth_mode = bool(refresh_tok) and refresh_tok != 'empty_setting'
	headers = None
	if oauth_mode:
		headers = {'Authorization': 'Bearer %s' % get_setting('deadlight.mdblist.token')}
	else:
		params['apikey'] = get_setting('deadlight.mdblist.token')
	url = BASE_URL % path
	for attempt in (1, 2):
		try:
			_throttle()   # LOCAL PATCH 2026-09-16
			response = session.request(method or 'get', url, params=params, json=json, headers=headers, timeout=TIMEOUT)
			result = response.json() if 'json' in response.headers.get('Content-Type', '') else response.text
			if not response.ok: response.raise_for_status()
			if isinstance(result, list):
				result = {'items': result, 'pagination': {'has_more': response.headers.get('X-Has-More') == 'true'}}
				nxt = response.headers.get('X-Next-Cursor')
				if nxt: result['pagination']['next_cursor'] = nxt
			return result
		except (_rq.exceptions.ConnectionError, ConnectionResetError, ConnectionAbortedError) as e:
			if attempt == 1:
				logger('mdblist retry', 'stale-conn %s — retrying once' % safe_err(e))   # LOCAL PATCH 2026-10-25 (4.0.5): no url / apikey
				continue
			logger('mdblist error', 'connection failed after retry: %s' % safe_err(e))
			return None
		except _rq.exceptions.HTTPError as e:
			# LOCAL PATCH 2026-09-14: a 429 is a KEY-level condition, not a per-title miss. Trip the
			# breaker above; every other HTTP status keeps its previous meaning (404 = no data).
			resp = getattr(e, 'response', None)
			if resp is not None and resp.status_code == 429:
				_start_cooldown(resp.headers.get('Retry-After'))
			# LOCAL PATCH 2026-10-15: an expired OAuth token is refreshed and the call retried once. Only MDBListMonitor
			# refreshed it, at its next tick -- after a sleep / wake every widget and rating call got a 401 and empty rows.
			if resp is not None and resp.status_code == 401 and oauth_mode and attempt == 1 and mdbl_refresh():
				headers = {'Authorization': 'Bearer %s' % get_setting('deadlight.mdblist.token')}
				continue
			logger('mdblist error', safe_err(e, url))   # LOCAL PATCH 2026-10-25 (4.0.5): str(e) carried '?apikey=<KEY>'
			return None
		except Exception as e:
			logger('mdblist error', safe_err(e))
			return None


def _get_mdbl_paginated_list(url, strict=False):
	"""Walk MDBList cursor pagination for list-typed payloads, bucketed by media key so `sync/watched`
	(movies+episodes) and `sync/collection` (movies+shows) both fill correctly.
	LOCAL PATCH 2026-10-19: strict (the sync's full rewrites, as trakt_api._fetch_all_pages): a page that fails after the
	first makes the whole fetch None -- a partial history written as the whole one drops every mark past that page."""
	params = {'limit': 1000}
	items = {'movies': [], 'shows': [], 'episodes': [], 'items': []}
	fetched_any, broken = False, False
	try:
		for _ in range(MAX_LIST_ITEMS // params['limit']):
			result = call_mdblist(url, params=params)
			if not isinstance(result, dict):
				broken = True
				break
			fetched_any = True
			for k in items:
				if k in result and isinstance(result[k], list):
					items[k].extend(result[k])
			if not result.get('pagination', {}).get('has_more'): break
			params['cursor'] = result['pagination']['next_cursor']
	except: broken = True
	if strict and broken: return None
	# LOCAL PATCH 2026-09-15: a fetch that never got a page is a FAILURE (None), not an empty list -- cache_mdbl_object
	# would store an empty result with no expiry, so a 429 / timeout emptied lists until the next edit.
	# A later page failing still returns the partial result.
	if not fetched_any: return None
	return items


# ═══════════════════════════════════════════════════════════════════════════
#  List browse — top / search / user
# ═══════════════════════════════════════════════════════════════════════════

# LOCAL PATCH 2026-09-26: json=False on both. call_mdblist already returns a parsed dict; cache_object's default
# json=True calls .json() on it, an AttributeError the bare except turns into an empty page.
def mdbl_top_lists():
	string = 'mdbl_top_lists'
	url = 'lists/top'
	return cache_object(call_mdblist, string, url, json=False)['items']


def mdbl_search_lists(query):
	query = quote(query)
	string = 'mdbl_search_lists_%s' % query
	url = 'lists/search?query=%s' % query
	return cache_object(call_mdblist, string, url, json=False, expiration=EXPIRES_1_HOURS)['items']


def mdbl_get_lists(list_type):
	"""list_type='external' → lists the user has liked on MDBList ; else → user's own lists.
	LOCAL PATCH 2026-07-31: `external/lists/user` returns [] on the current API; liked lists come from `lists/liked`,
	which returns {'lists': [...], 'pagination': {}} (not the 'items' shape call_mdblist wraps). Handle both keys."""
	if list_type == 'external':
		string, url = 'mdbl_external', 'lists/liked'
	else:
		string, url = 'mdbl_my_lists', 'lists/user'
	response = mdblist_cache.cache_mdbl_object(call_mdblist, string, url)
	if response is None: return None   # LOCAL PATCH 2026-09-15: failed fetch, not an empty account
	return response.get('lists') or response.get('items') or []


def get_mdbl_list_contents(list_type, list_id):
	"""LOCAL PATCH 2026-07-31: `external/lists/{id}/items` is for user-imported RSS/Trakt sources and returns 403 for
	merely liked lists, so liked lists (list_type='external') use the public `lists/{id}/items` path, which accepts any
	public list by id."""
	string = 'mdbl_list_contents_%s_%s' % (list_type, list_id)
	url = 'lists/%s/items?unified=true' % list_id
	# LOCAL PATCH 2026-09-15: None means the fetch failed (see _get_mdbl_paginated_list); the
	# indexer tells the user instead of drawing an empty list. [] is a genuinely empty list.
	# LOCAL PATCH 2026-10-03 (3.0.8): a liked list is someone else's -- re-read daily (see cache_mdbl_object)
	response = mdblist_cache.cache_mdbl_object(_get_mdbl_paginated_list, string, url, max_age_hours=24 if list_type == 'external' else None)
	if response is None: return None
	return response.get('items') or []


# ═══════════════════════════════════════════════════════════════════════════
#  Personal lists — collection / watchlist / dropped
# ═══════════════════════════════════════════════════════════════════════════

def mdblist_collection(mediatype, page_no):
	string = 'mdbl_collection'
	url = 'sync/collection'
	original_list = mdbl_collection_watchlist_items(string, url)
	if mediatype == 'all':
		original_list = original_list['movies'] + original_list['shows']
		for i in original_list:
			i.update({'id': i['movie' if 'movie' in i else 'show']['ids']['tmdb']})
		return original_list
	original_list = original_list[mediatype]
	key = 'movie' if mediatype in ('movie', 'movies') else 'show'
	for i in original_list:
		i.update({
			'id': i[key]['ids']['tmdb'], 'imdb_id': i[key]['ids'].get('imdb', ''),
			'title': i[key]['title'], 'year': i[key].get('year', 0)
		})
	sort_key = settings.lists_sort_order('collection')
	if sort_key == 2:
		original_list.sort(key=itemgetter('year'), reverse=True)
	elif sort_key == 1:
		original_list.sort(key=itemgetter('collected_at'), reverse=True)
	else:
		original_list = sort_for_article(original_list, 'title', settings.ignore_articles())
	if settings.paginate(False):
		from modules.utils import paginate_list
		return paginate_list(original_list, page_no, settings.page_limit(False))
	return original_list, 1


def mdblist_watchlist(mediatype, page_no):
	def first_aired(item):
		if not item.get('release_date'): return False
		# LOCAL PATCH 2026-10-26: pass the format argument (missing since the POV port: every item raised TypeError and the
		# indexer's bare except showed an EMPTY watchlist). MDBList sends a plain 'YYYY-MM-DD'; a date it cannot read keeps
		# the item rather than hide it.
		try: return jsondate_to_datetime(item['release_date'][:10], '%Y-%m-%d', remove_time=True) <= current_date
		except (TypeError, ValueError): return True
	string = 'mdbl_watchlist'
	url = 'watchlist/items'
	original_list = mdbl_collection_watchlist_items(string, url)
	if mediatype == 'all':
		return original_list['movies'] + original_list['shows']
	original_list = original_list[mediatype]
	if not settings.show_unaired_watchlist():
		current_date = get_datetime()
		original_list = [i for i in original_list if first_aired(i)]
	sort_key = settings.lists_sort_order('watchlist')
	if sort_key == 2:
		original_list.sort(key=lambda x: x.get('release_date') or '', reverse=True)
	elif sort_key == 1:
		original_list.sort(key=itemgetter('watchlist_at'), reverse=True)
	else:
		original_list = sort_for_article(original_list, 'title', settings.ignore_articles())
	if settings.paginate(False):
		from modules.utils import paginate_list
		return paginate_list(original_list, page_no, settings.page_limit(False))
	return original_list, 1


def mdbl_collection_watchlist_items(string, url):
	return mdblist_cache.cache_mdbl_object(_get_mdbl_paginated_list, string, url)


def mdblist_droplist(mediatype, page_no):
	results = mdbl_get_hidden_items('dropped')
	return [{'imdb_id': '', 'id': i} for i in results], 1


# LOCAL PATCH 2026-08-05 (POV 6.08 P2 port): MDBList Calendar. /calendar/events?start=...&end=... returns
# per-episode airings for shows in the user's Watchlist/Watching/Collection, in the Trakt calendar's shape family,
# so episodes.py renders it with the shared calendar path.
def _mdbl_calendar_days(recently_aired, current_date):
	from datetime import timedelta
	if recently_aired:
		return (current_date - timedelta(days=14)).strftime('%Y-%m-%d'), current_date.strftime('%Y-%m-%d')
	previous_days = int(get_setting('deadlight.trakt.calendar_previous_days', '0') or '0')
	future_days = int(get_setting('deadlight.trakt.calendar_future_days', '7') or '7')
	start = (current_date - timedelta(days=previous_days)).strftime('%Y-%m-%d')
	finish = (current_date + timedelta(days=future_days)).strftime('%Y-%m-%d')
	return start, finish


def _mdbl_calendar_data(url):
	result = []
	seen = set()
	try:
		resp = call_mdblist(url) or {}
		# MDBList calendar returns either {'events': [...]} or a bare list — accept both.
		events = resp.get('events') if isinstance(resp, dict) else resp
		for i in (events or []):
			try:
				if i.get('type') and i.get('type') != 'episode': continue
				if i.get('season_number', 0) <= 0: continue
				tmdb_id = i.get('show_tmdb') or i.get('show_id') or ''
				if not tmdb_id: continue
				season, episode = i['season_number'], i['episode_number']
				show_title = i.get('show_title') or i.get('title') or ''
				sort_title = '%s s%02d e%02d' % (show_title, int(season), int(episode))
				if sort_title in seen: continue
				seen.add(sort_title)
				result.append({
					'sort_title': sort_title,
					'first_aired': i.get('start') or i.get('air_date') or '',
					'media_ids': {'tmdb': tmdb_id},
					'season': int(season), 'episode': int(episode),
				})
			except Exception: continue
	except Exception: pass
	return result


def mdbl_get_my_calendar(recently_aired, current_date):
	start, finish = _mdbl_calendar_days(recently_aired, current_date)
	string = 'mdbl_get_my_calendar_%s_%s' % (start, finish)
	url = 'calendar/events?limit=1000&start=%s&end=%s' % (start, finish)
	# LOCAL PATCH 2026-08-06: json=False -- _mdbl_calendar_data already parses and returns a plain list; the default
	# json=True would call .json() on it (AttributeError).
	return cache_object(_mdbl_calendar_data, string, url, json=False)


def mdbl_get_hidden_items(list_type):
	def _get_mdbl_ids(item):
		tmdb_id = get_mdbl_tvshow_id(item['show']['ids'])
		if tmdb_id: results_append(tmdb_id)
	def _process(url):
		hidden_data = [(i,) for i in call_mdblist(url)['shows']]
		for i in TaskPool().tasks(_get_mdbl_ids, hidden_data, 10): i.join()   # LOCAL PATCH 2026-10-02: an int thread count, not the Thread class
		return results
	results = []
	results_append = results.append
	string = 'mdbl_hidden_items_%s' % list_type
	url = 'sync/dropped'
	return mdblist_cache.cache_mdbl_object(_process, string, url)


def hide_unhide_mdbl_items(action, mediatype, media_id, list_type, refresh=True):
	"""Add/remove a show from MDBList's dropped list (hide-from-discovery)."""
	if action not in ('hide', 'unhide'):
		try:
			hidden_data = mdbl_get_hidden_items('dropped')
			action = 'unhide' if int(action) in hidden_data else 'hide'
		except: return kodi_utils.notification('MDBList update failed')
	mediatype = 'movies' if mediatype in ('movie', 'movies') else 'shows'
	# LOCAL PATCH 2026-09-20: the id key follows the id we were handed. POV's caller passed an imdb id; all DeadLight
	# callers pass a TMDb id, so a hardcoded 'imdb' matched nothing on MDBList. Its sync endpoints take tmdb for shows.
	key = 'imdb' if str(media_id).startswith('tt') else 'tmdb'
	url = 'sync/dropped' if action == 'hide' else 'sync/dropped/remove'
	data = {mediatype: [{'ids': {key: media_id}}]}
	# LOCAL PATCH 2026-09-20: return True/False from the response so callers can say what happened (a request matching
	# nothing used to report success). The body is logged once per call because sync/dropped's reply shape has never
	# been observed here -- confirm it against ###MDBList drop### before tightening this to an 'updated' count the way
	# add_to_collection does.
	result = call_mdblist(url, json=data, method='post')
	try:
		from modules.kodi_utils import logger
		logger('###MDBList drop###', '%s %s=%s -> %s' % (url, key, media_id, repr(result)[:300]))
	except Exception: pass
	mdbl_sync_activities()
	# LOCAL PATCH 2026-11-01: was container_refresh (never the Home widgets); refresh=False from Mark Watched, which reloads itself
	if refresh: kodi_utils.refresh(screen='if_listed')
	return bool(result)


# ═══════════════════════════════════════════════════════════════════════════
#  Write ops — collection / list add & remove / list CRUD
# ═══════════════════════════════════════════════════════════════════════════

def add_to_collection(data):
	result = call_mdblist('sync/collection', json=data, method='post')
	if not result or result['updated']['movies'] + result['updated']['shows'] == 0:
		return kodi_utils.notification('MDBList update failed')
	kodi_utils.notification('MDBList updated')
	mdbl_sync_activities()
	kodi_utils.refresh('mdblist_collection', screen='if_listed')   # LOCAL PATCH 2026-11-01: adds reload too
	return result


def remove_from_collection(data):
	result = call_mdblist('sync/collection/remove', json=data, method='post')
	if not result or result['removed']['movies'] + result['removed']['shows'] == 0:
		return kodi_utils.notification('MDBList update failed')
	kodi_utils.notification('MDBList updated')
	mdbl_sync_activities()
	kodi_utils.refresh('mdblist_collection', screen='if_listed')   # LOCAL PATCH 2026-11-01: was container_refresh (never the Home widgets)
	return result


def _mdbl_list_paths(list_id):   # the widgets an add / remove can change (kodi_utils.refresh_after_edit)
	return ('mdblist_watchlist',) if list_id == 'watchlist' else ('list_id=%s' % list_id,)


def add_to_list(list_id, data):
	url = 'watchlist/items/add' if list_id == 'watchlist' else 'lists/%s/items/add' % list_id
	result = call_mdblist(url, json=data, method='post')
	if not result or result['added']['movies'] + result['added']['shows'] == 0:
		return kodi_utils.notification('MDBList update failed')
	kodi_utils.notification('MDBList updated')
	mdbl_sync_activities()
	kodi_utils.refresh(*_mdbl_list_paths(list_id), screen='if_listed')   # LOCAL PATCH 2026-11-01: adds reload too
	return result


def remove_from_list(list_id, data):
	url = 'watchlist/items/remove' if list_id == 'watchlist' else 'lists/%s/items/remove' % list_id
	result = call_mdblist(url, json=data, method='post')
	if not result or result['removed']['movies'] + result['removed']['shows'] == 0:
		return kodi_utils.notification('MDBList update failed')
	kodi_utils.notification('MDBList updated')
	mdbl_sync_activities()
	kodi_utils.refresh(*_mdbl_list_paths(list_id), screen='if_listed')   # LOCAL PATCH 2026-11-01: was container_refresh (never the Home widgets)
	return result


def make_new_mdbl_list(params):
	from urllib.parse import unquote
	list_title = kodi_utils.kodi_dialog().input(kodi_utils.addon_name())   # LOCAL PATCH 2026-09-07: rebrand
	if not list_title: return
	list_name = unquote(list_title)
	data = {'name': list_name, 'private': False}
	result = call_mdblist('lists/user/add', json=data, method='post')
	if result is None: return kodi_utils.notification('MDBList update failed')
	mdblist_cache.clear_mdbl_list_data('my_lists')
	kodi_utils.notification('MDBList updated')
	kodi_utils.container_refresh()


def delete_mdbl_list(params):
	if not kodi_utils.confirm_dialog(): return
	list_id = params['list_id']
	url = 'lists/%s' % list_id
	result = call_mdblist(url, method='delete')
	if result is None: return kodi_utils.notification('MDBList update failed')
	mdblist_cache.clear_mdbl_list_data('my_lists')
	kodi_utils.notification('MDBList updated')
	kodi_utils.container_refresh()


# ═══════════════════════════════════════════════════════════════════════════
#  ID normalisation — MDBList responses carry mixed imdb/tmdb/tvdb per row.
# ═══════════════════════════════════════════════════════════════════════════

# LOCAL PATCH 2026-11-01 (cleanup): both over tmdb_api.tmdb_id_from_ids (shared with trakt_api; passes the api key,
# the 2026-10-20 fix)
def get_mdbl_movie_id(item):
	from apis.tmdb_api import tmdb_id_from_ids
	return tmdb_id_from_ids(item, 'movie')


def get_mdbl_tvshow_id(item):
	from apis.tmdb_api import tmdb_id_from_ids
	return tmdb_id_from_ids(item, 'tvshow')


# ═══════════════════════════════════════════════════════════════════════════
#  Watched / scrobble — enables watched_indicators == 2 (MDBList as SoT)
# ═══════════════════════════════════════════════════════════════════════════

def _mdbl_regular_season_numbers(tmdb_id):
	"""Regular (non-special) season numbers for a show.

	MDBList marks a season's EPISODES; a bare show id updates nothing, which is what made
	'mark show as watched' report an error and write no tick. Season 0 is excluded --
	specials are not part of a normal completion."""
	try:
		from modules import metadata
		meta = metadata.tvshow_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(),
					settings.mpaa_region(), get_datetime())
	except Exception: meta = None
	nums, seen = [], set()
	for item in (meta or {}).get('season_data') or []:
		try: n = int(item.get('season_number'))
		except Exception: continue
		if n > 0 and n not in seen:
			seen.add(n)
			nums.append(n)
	return nums


def _mdbl_mark_counted(result, *keys):
	"""True when MDBList recorded the mark under EITHER bucket.

	LOCAL PATCH 2026-09-23 (Red Light 2.6.8 port): a FIRST watch is counted under `added`; only a REPEAT watch
	lands in `updated`, so reading `updated` alone scored every first mark as a failure."""
	total = 0
	for name in ('added', 'updated'):
		bucket = (result or {}).get(name) or {}
		if not isinstance(bucket, dict): continue
		for key in keys:
			try: total += int(bucket.get(key) or 0)
			except Exception: pass
	return total > 0


def _mdbl_not_found(result):
	"""True when MDBList could not match the id at all -- the one real failure mode."""
	nf = (result or {}).get('not_found') or {}
	if not isinstance(nf, dict): return bool(nf)
	for val in nf.values():
		if isinstance(val, list) and val: return True
		try:
			if int(val or 0) > 0: return True
		except Exception: pass
	return False


def _mdbl_show_imdb(tmdb_id):
	"""LOCAL PATCH 2026-11-04 (Red Light 2.8.5): the show's IMDb id for a sync/watched write, or None. The meta cache first
	(no request), TMDb only when the show is not cached."""
	try:
		from modules.metadata import cached_meta, tvshow_meta
		meta = cached_meta('tvshow', tmdb_id)
		if not meta:
			from modules.settings import tmdb_api_key, mpaa_region
			from modules.utils import get_datetime
			meta = tvshow_meta('tmdb_id', tmdb_id, tmdb_api_key(), mpaa_region(), get_datetime())
		imdb_id = str((meta or {}).get('imdb_id') or '')
		return imdb_id if imdb_id.startswith('tt') else None
	except Exception: return None


def mdbl_watched_unwatched(action, media, media_id, tvdb_id=0, season=None, episode=None, key='tmdb', episodes=None, season_numbers=None):
	"""Mark or unmark a movie/show/season/episode as watched on MDBList.
	LOCAL PATCH 2026-11-04 (Red Light 2.8.5): a show write sends TMDb AND IMDb ids, so MDBList matches on either. No TVDB
	retry: sync/watched matches TMDb and IMDb only (a TVDB id comes back not_found). tvdb_id stays in the signature for
	the callers."""
	if action == 'mark_as_watched':
		url, result_key = 'sync/watched', 'updated'
	else:
		url, result_key = 'sync/watched/remove', 'removed'
	try: media_id = int(media_id)
	except: pass
	if media == 'movies':
		success_key = 'movies'
		data = {'movies': [{'ids': {key: media_id}}]}
	else:
		success_key = 'episodes'
		show_ids = {key: media_id}
		if key == 'tmdb':
			imdb_id = _mdbl_show_imdb(media_id)
			if imdb_id: show_ids['imdb'] = imdb_id
		if media == 'episodes' and episodes:
			# LOCAL PATCH 2026-08-29: a LIST of episode numbers in one call, for anime cours.
			# A cour is a slice of a TMDb season, so the season payload would take its
			# siblings with it.
			seasons = [{'number': int(season), 'episodes': [{'number': int(e)} for e in episodes]}]
			data = {'shows': [{'ids': show_ids,'seasons': seasons}]}
		elif media == 'episode':
			seasons = [{'number': int(season), 'episodes': [{'number': int(episode)}]}]
			data = {'shows': [{'ids': show_ids,'seasons': seasons}]}
		elif media == 'shows':
			# LOCAL PATCH 2026-09-23 (Red Light 2.6.8 port): send every regular season, the same shape Mark Season uses.
			# MDBList marks a season's EPISODES, so a bare show id changes nothing.
			if season_numbers is None and key == 'tmdb':
				season_numbers = _mdbl_regular_season_numbers(media_id)
			_show = {'ids': show_ids}
			if season_numbers: _show['seasons'] = [{'number': int(n)} for n in season_numbers]
			data = {'shows': [_show]}
		else:
			data = {'shows': [{'ids': show_ids,'seasons': [{'number': int(season)}]}]}  # season
	result = call_mdblist(url, json=data, method='post')
	if not isinstance(result, dict): return False
	# LOCAL PATCH 2026-09-23 (Red Light 2.6.8 port): see _mdbl_mark_counted -- `updated`
	# alone missed every first watch. 'seasons' counts too, for the season/show payloads.
	if action == 'mark_as_watched':
		success = _mdbl_mark_counted(result, 'movies' if media == 'movies' else 'episodes', 'seasons')
	else:
		bucket = result.get(result_key) or {}
		success = bucket.get(success_key, 0) > 0 if isinstance(bucket, dict) else False
	# Already watched there: added and updated are both 0 because nothing NEEDED to change, and the id was matched --
	# a success. A bare show id is the exception, since that reply legitimately updates nothing.
	if not success and action == 'mark_as_watched' and not _mdbl_not_found(result):
		if media != 'shows' or season_numbers: return True
	# Remove with 0 removed: already unwatched, likewise not a failure.
	if not success and action != 'mark_as_watched': return True
	if not success:
		logger('MDBList', 'mark %s %s ids=%s: %s' % (action, media, data[next(iter(data))][0]['ids'], result))
	return success


def mdbl_progress(action, media, media_id, percent, season=None, episode=None, resume_id=None, refresh_mdb=False):
	"""Push playback progress to MDBList (scrobble/pause endpoint) or clear it
	(scrobble/clear). Called from watched_status.set_bookmark / erase_bookmark
	when watched_indicators == 2."""
	if action == 'clear_progress':
		data = {'id': resume_id}
		url = 'scrobble/clear'
	else:
		try: media_id = int(media_id)
		except: pass
		if media in ('movie', 'movies'):
			data = {'movie': {'ids': {'tmdb': media_id}}, 'progress': float(percent)}
		else:
			data = {'show': {'ids': {'tmdb': media_id}, 'season': {'number': int(season), 'episode': {'number': int(episode)}}}, 'progress': float(percent)}
		url = 'scrobble/pause'
	# LOCAL PATCH 2026-09-24: report whether MDBList took it (call_mdblist returns None on ANY failure: 429,
	# network), so a refused save can be queued rather than vanish.
	ok = call_mdblist(url, json=data, method='post') is not None
	if refresh_mdb and ok: mdbl_sync_activities()
	return ok


# LOCAL PATCH 2026-09-24: progress saves MDBList did not accept, kept and re-sent. watched_status.set_bookmark writes
# the local row first (so resume works at once) and queues the save here when MDBList refuses it (e.g. 429 with an
# hour's Retry-After once the daily quota is spent).
# The queue lives in mdbl_data so it outlives Kodi. The bulk sync REBUILDS the local progress table from MDBList,
# which has never seen a queued save (_pending_reapply puts those rows back), and clear_all_mdbl_cache_data wipes
# mdbl_data (which carries the queue across). Marking watched or clearing a resume point drops its entry, so a stale
# position is never re-sent over a finished episode.
_PENDING_KEY = 'mdbl_pending_progress'


def _pending_key(media, media_id, season, episode):
	if media in ('movie', 'movies'): return 'movie|%s||' % media_id
	return 'episode|%s|%s|%s' % (media_id, int(season), int(episode))


def mdbl_pending_progress():
	pending = mdblist_cache.mdbl_cache.get(_PENDING_KEY)
	return pending if isinstance(pending, dict) else {}


def _pending_store(pending):
	mdblist_cache.mdbl_cache.set(_PENDING_KEY, pending)


def mdbl_queue_progress(media, media_id, percent, season, episode, curr_time, title):
	try:
		pending = mdbl_pending_progress()
		pending[_pending_key(media, media_id, season, episode)] = {
			'media': 'movie' if media in ('movie', 'movies') else 'episode', 'media_id': str(media_id),
			'percent': float(percent), 'season': season, 'episode': episode,
			'curr_time': str(curr_time), 'title': title, 'queued_at': time.strftime('%Y-%m-%dT%H:%M:%S.000Z', time.gmtime())}
		_pending_store(pending)
		logger('MDBList', 'progress not accepted -- queued %s (%d waiting)' % (_pending_key(media, media_id, season, episode), len(pending)))
	except Exception as e:
		logger('MDBList', 'progress queue failed: %s' % str(e)[:120])


def mdbl_pending_drop(media, media_id, season='', episode=''):
	try:
		pending = mdbl_pending_progress()
		if pending.pop(_pending_key(media, media_id, season, episode), None) is not None: _pending_store(pending)
	except Exception: pass


def mdbl_flush_pending():
	"""Re-send queued saves while MDBList is not refusing calls. Stops at the first refusal:
	the rest would only spend more of an exhausted quota."""
	pending = mdbl_pending_progress()
	if not pending: return
	sent = []
	for key, item in list(pending.items()):
		if mdblist_on_cooldown(): break
		if not mdbl_progress('set_progress', item['media'], item['media_id'], item['percent'], item['season'], item['episode']): break
		sent.append(key)
	if sent:
		pending = mdbl_pending_progress()   # re-read: a save may have queued meanwhile
		for key in sent: pending.pop(key, None)
		_pending_store(pending)
		logger('MDBList', 'sent %d queued progress save(s), %d still waiting' % (len(sent), len(pending)))


def _pending_reapply():
	"""Queued saves back into the local progress table, after a bulk sync rebuilt it."""
	pending = mdbl_pending_progress()
	if not pending: return
	try:
		from caches.base_cache import connect_database
		dbcon = connect_database('mdblist_db')
		for item in pending.values():
			movie = item['media'] == 'movie'
			season, episode = ('', '') if movie else (item['season'], item['episode'])
			dbcon.execute('INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
				(item['media'], item['media_id'], season, episode, str(item['percent']), item['curr_time'], item['queued_at'], 0, item['title']))
	except Exception as e:
		logger('MDBList', 'progress queue reapply failed: %s' % str(e)[:120])


# ═══════════════════════════════════════════════════════════════════════════
#  Indicator bulk builders — populate local mdbl_db watched/progress tables
#  from MDBList sync endpoints. Called from mdbl_sync_activities.
# ═══════════════════════════════════════════════════════════════════════════

def mdbl_indicators_movies(watched_info, since=None):
	def _process(item):
		tmdb_id = get_mdbl_movie_id(item['movie']['ids'])
		if not tmdb_id: return
		insert_append((
			'movie', str(tmdb_id), '', '', item['last_watched_at'], item['movie']['title']
		))
	# LOCAL PATCH 2026-10-19 (as trakt_indicators_*): False when the download failed (the sync marks the tables stale);
	# MDBList holding none is written as none (allow_empty), or the last mark undone stays local for ever; rows we could
	# not read keep what is stored.
	if watched_info is None: return False
	insert_list = []
	insert_append = insert_list.append
	watched_items = [(i,) for i in watched_info['movies']]
	if watched_items:
		for i in TaskPool().tasks(_process, watched_items, 10): i.join()   # LOCAL PATCH 2026-10-02: an int thread count, not the Thread class
		if not insert_list: return True
	mdblist_cache.mdbl_cache.set_bulk_movie_watched(insert_list, since, allow_empty=True)
	return True


def mdbl_indicators_tv(watched_info, since=None):
	def _process(item):
		tmdb_id = get_mdbl_tvshow_id(item['episode']['show']['ids'])
		if not tmdb_id: return
		season, episode = item['episode']['season'], item['episode']['number']
		insert_append((
			'episode', str(tmdb_id), season, episode, item['last_watched_at'], item['episode']['show']['title']
		))
	# LOCAL PATCH 2026-10-19 (as trakt_indicators_*): False when the download failed (the sync marks the tables stale);
	# MDBList holding none is written as none (allow_empty), or the last mark undone stays local for ever; rows we could
	# not read keep what is stored.
	if watched_info is None: return False
	insert_list = []
	insert_append = insert_list.append
	watched_items = [(i,) for i in watched_info['episodes']]
	if watched_items:
		for i in TaskPool().tasks(_process, watched_items, 10): i.join()   # LOCAL PATCH 2026-10-02: an int thread count, not the Thread class
		if not insert_list: return True
	mdblist_cache.mdbl_cache.set_bulk_tvshow_watched(insert_list, since, allow_empty=True)
	return True


def mdbl_progress_movies(progress_info, since=None):
	def _process(item):
		tmdb_id = get_mdbl_movie_id(item['movie']['ids'])
		if not tmdb_id: return
		insert_append((
			'movie', str(tmdb_id), '', '', str(round(float(item['progress']), 1)),
			0, item['paused_at'], item['id'], item['movie']['title']
		))
	insert_list = []
	insert_append = insert_list.append
	progress_items = [(i,) for i in progress_info if i['type'] == 'movie' and float(i['progress']) > 1]
	if progress_items:
		for i in TaskPool().tasks(_process, progress_items, 10): i.join()   # LOCAL PATCH 2026-10-02: an int thread count, not the Thread class
		if not insert_list: return
	# LOCAL PATCH 2026-10-19: none paused on MDBList is written too (the sync only gets here on a successful fetch)
	mdblist_cache.mdbl_cache.set_bulk_movie_progress(insert_list, since, allow_empty=True)
	_pending_reapply()   # LOCAL PATCH 2026-09-24


def mdbl_progress_tv(progress_info, since=None):
	def _process(item):
		tmdb_id = get_mdbl_tvshow_id(item['show']['ids'])
		if not tmdb_id: return
		season, episode = item['episode']['season'], item['episode']['number']
		if season > 0:
			insert_append((
				'episode', str(tmdb_id), season, episode, str(round(float(item['progress']), 1)),
				0, item['paused_at'], item['id'], item['show']['title']
			))
	insert_list = []
	insert_append = insert_list.append
	progress_items = [(i,) for i in progress_info if i['type'] == 'episode' and float(i['progress']) > 1]
	if progress_items:
		for i in TaskPool().tasks(_process, progress_items, 10): i.join()   # LOCAL PATCH 2026-10-02: an int thread count, not the Thread class
		if not insert_list: return
	# LOCAL PATCH 2026-10-19: none paused on MDBList is written too (the sync only gets here on a successful fetch)
	mdblist_cache.mdbl_cache.set_bulk_tvshow_progress(insert_list, since, allow_empty=True)
	_pending_reapply()   # LOCAL PATCH 2026-09-24


def mdbl_playback_progress():
	return call_mdblist('sync/playback')


# LOCAL PATCH 2026-10-05: MDBList's own Up Next (GET /upnext), for Continue Watching's next-episode rows under MDBList
# indicators (indexers/episodes.continue_watching_plan). Computing it locally listed every unfinished show however
# long ago it was watched; MDBList's rule is undocumented, so its answer is used as is.
# Cached in mdbl_data, dropped whenever sync/last_activities reports a watch, a pause or a drop (mdbl_sync_activities),
# with an hour's expiry besides. None when MDBList cannot be reached: the caller then computes the list itself.
_UPNEXT_KEY = 'mdbl_upnext'

def mdbl_upnext():
	"""[{'tmdb', 'season', 'episode', 'last_watched_at'}] in MDBList's order, or None when unreachable."""
	cached = mdblist_cache.mdbl_cache.get(_UPNEXT_KEY)
	try:
		if cached and time.time() - float(cached.get('at') or 0) < 3600: return cached['items']
	except Exception: pass
	items, offset = [], 0
	for _page in range(5):
		try: res = call_mdblist('upnext', params={'limit': 100, 'offset': offset})
		except Exception: res = None
		if not isinstance(res, dict) or not isinstance(res.get('items'), list):
			return (cached or {}).get('items')
		for it in res['items']:
			try:
				ne = it.get('next_episode') or {}
				items.append({'tmdb': int(it['show']['ids']['tmdb']), 'season': int(ne['season']), 'episode': int(ne['episode']),
					'last_watched_at': it.get('last_watched_at') or ''})
			except (KeyError, TypeError, ValueError): continue
		if not res.get('has_more'): break
		offset += len(res['items'])
	mdblist_cache.mdbl_cache.set(_UPNEXT_KEY, {'at': time.time(), 'items': items})
	return items


def mdbl_get_activity():
	return call_mdblist('sync/last_activities')


# LOCAL PATCH 2026-10-03 (3.0.8): a mark made here moves MDBList's episode_watched_at, and the next sync would
# re-download the whole watched history (seconds, plus a widget reload) for a mark already written locally.
# mdbl_acked_write brackets the write with two activity polls: when nothing had moved beforehand (the stored snapshot
# matches) and only the keys this write is expected to move have moved afterwards, the new stamps are recorded as
# seen and the next sync says 'not needed'. Anything else (a key moved before, an unexpected key, a failed poll, a
# cooldown) is a plain write with the snapshot left alone.
# The blind spot is a change made elsewhere to the same key between the two polls (~0.5 s). _ACK_AUDIT_KEY records
# the first unaudited acknowledgement; a sync more than a day later downloads the watched history once regardless.
_ACK_AUDIT_KEY = 'mdbl_ack_audit'
_STALE_KEY = 'mdbl_watched_stale'   # LOCAL PATCH 2026-10-19: see mdbl_sync_activities
_ACK_AUDIT_SECONDS = 24 * 3600

def mdbl_acked_write(write, moves):
	"""LOCAL PATCH 2026-11-08: the shared modules.acked_write (Trakt and SIMKL use it too)."""
	if mdblist_on_cooldown(): return write()
	from modules.acked_write import acked_write
	from caches.mdblist_cache import default_activities
	def _write():
		result = write()
		# LOCAL PATCH 2026-10-05: an episode mark changes MDBList's Up Next, and an acknowledged write leaves the sync nothing
		# to see, so drop mdbl_upnext here. MDBList's Up Next is current within seconds, so the next widget build refetches.
		if result and set(moves) & {'episode_watched_at', 'episode_paused_at', 'dropped_at'}:
			try: mdblist_cache.mdbl_cache.delete(_UPNEXT_KEY)
			except Exception: pass
		return result
	def _audit():
		if not mdblist_cache.mdbl_cache.get(_ACK_AUDIT_KEY): mdblist_cache.mdbl_cache.set(_ACK_AUDIT_KEY, int(time.time()))
	return acked_write(_write, moves, mdbl_get_activity, mdblist_cache.get_activity, mdblist_cache.reset_activity,
		keys=list(default_activities()), on_ack=_audit, label='MDBList')


# ═══════════════════════════════════════════════════════════════════════════
#  Master sync — activity-pivot driven cache invalidation + selective rebuild
# ═══════════════════════════════════════════════════════════════════════════


def mdbl_sync_activities(force_update=False, monitor=None):
	"""Poll MDBList `sync/last_activities`, diff timestamps against the local
	cached snapshot, and selectively invalidate + rebuild caches. Called
	on-demand after write ops AND by the background MDBListMonitor service."""
	def _compare(latest, cached):
		try: return (latest or '') > (cached or '')
		except: return True
	if not get_setting('deadlight.mdblist.user', ''):
		return 'no account'
	if monitor and monitor.abortRequested():
		return
	if force_update:
		# LOCAL PATCH 2026-07-28: DeadLight doesn't have modules.cache — the DB
		# creation helper lives in caches.base_cache.make_databases.
		from caches.base_cache import make_databases
		make_databases()
		mdblist_cache.clear_all_mdbl_cache_data(silent=True, refresh=False)
	# LOCAL PATCH 2026-09-24: queued progress first, so the playback list fetched below has it.
	try: mdbl_flush_pending()
	except Exception: pass
	# LOCAL PATCH 2026-10-03 (Batch 2): stamped before the poll; local marks at or after it survive the rewrite (base_cache.sync_since)
	since = sync_since()
	latest = mdbl_get_activity()
	if latest is None:
		# LOCAL PATCH 2026-09-07: a failed poll says nothing about whether the cache is stale, so report 'failed' and retry
		# next cycle, like Trakt, SIMKL and AniList. Not wipe the whole cache (it did so through a confirm dialog raised from
		# the background MDBListMonitor thread at startup before the network was up). force_update above still clears
		# (silently) when the user asks.
		return 'failed'
	cached = mdblist_cache.reset_activity(latest)
	success = 'not needed'
	if _compare(latest.get('collected_at'), cached.get('collected_at')):
		success = 'success'
		mdblist_cache.clear_mdbl_collection_watchlist_data('collection')
	if _compare(latest.get('watchlisted_at'), cached.get('watchlisted_at')):
		success = 'success'
		mdblist_cache.clear_mdbl_collection_watchlist_data('watchlist')
	if _compare(latest.get('dropped_at'), cached.get('dropped_at')):
		success = 'success'
		mdblist_cache.clear_mdbl_list_data('hidden_items_dropped')
	if _compare(latest.get('list_updated_at'), cached.get('list_updated_at')):
		success = 'success'
		for i in ('external', 'my_lists'):
			mdblist_cache.clear_mdbl_list_data(i)
			mdblist_cache.clear_mdbl_list_contents_data(i)
	# LOCAL PATCH 2026-10-03 (3.0.8): the once-a-day audit of acknowledged writes (mdbl_acked_write)
	audit = False
	try:
		acked_at = mdblist_cache.mdbl_cache.get(_ACK_AUDIT_KEY)
		audit = bool(acked_at) and time.time() - int(acked_at) > _ACK_AUDIT_SECONDS
	except Exception: pass
	# LOCAL PATCH 2026-10-19 (as trakt_api's trakt_watched_stale): reset_activity has already stored `latest`, so a failed
	# download would not be retried until MDBList moved again. A failure leaves _STALE_KEY; the next sync then rebuilds
	# all four tables whatever the stamps say.
	stale = mdblist_cache.mdbl_cache.get(_STALE_KEY) is not None
	failed = False
	refresh_movies_watched = stale or audit or _compare(latest.get('watched_at'), cached.get('watched_at'))
	refresh_episodes_watched = stale or audit or _compare(latest.get('episode_watched_at'), cached.get('episode_watched_at'))
	if audit:
		logger('MDBList', 'audit of acknowledged writes: watched history downloaded once')
		mdblist_cache.mdbl_cache.delete(_ACK_AUDIT_KEY)
	refresh_movies_paused = stale or _compare(latest.get('paused_at'), cached.get('paused_at'))
	refresh_episodes_paused = stale or _compare(latest.get('episode_paused_at'), cached.get('episode_paused_at'))
	# LOCAL PATCH 2026-10-05: Up Next follows the watch history, the resume points and the dropped list (mdbl_upnext)
	if refresh_episodes_watched or refresh_episodes_paused or _compare(latest.get('dropped_at'), cached.get('dropped_at')):
		mdblist_cache.mdbl_cache.delete(_UPNEXT_KEY)
	# LOCAL PATCH 2026-11-08: the watched / progress downloads count as a change only when they changed the local rows
	# (ProviderCache.rows_digest). The audit, a stale retry and a moved stamp all re-download, and 'success' reloads the
	# widgets and refreshes the list on screen (auto_kodi_refresh). A real change made elsewhere still changes rows; a
	# failed download stays 'success' (the tables are marked stale and the next sync retries).
	rows_before = mdblist_cache.mdbl_cache.rows_digest() \
		if (refresh_movies_watched or refresh_episodes_watched or refresh_movies_paused or refresh_episodes_paused) else None
	if refresh_movies_watched or refresh_episodes_watched:
		watched_info = _get_mdbl_paginated_list('sync/watched', strict=True)
		if refresh_movies_watched: failed = mdbl_indicators_movies(watched_info, since) is False or failed
		if refresh_episodes_watched: failed = mdbl_indicators_tv(watched_info, since) is False or failed
	if refresh_movies_paused or refresh_episodes_paused:
		# LOCAL PATCH 2026-10-19: a failed fetch is a failure, not 'nothing paused'; only a real answer is written
		# (empty included).
		progress = mdbl_playback_progress()
		if not isinstance(progress, dict) or not isinstance(progress.get('items'), list): failed = True
		else:
			progress_info = progress['items']
			if refresh_movies_paused: mdbl_progress_movies(progress_info, since)
			if refresh_episodes_paused: mdbl_progress_tv(progress_info, since)
	if refresh_movies_watched or refresh_episodes_watched or refresh_movies_paused or refresh_episodes_paused:
		if failed or rows_before is None or mdblist_cache.mdbl_cache.rows_digest() != rows_before: success = 'success'
		else: logger('MDBList', 'sync: watched / progress downloaded, no row changed')
	if failed: mdblist_cache.mdbl_cache.set(_STALE_KEY, 1)
	elif stale: mdblist_cache.mdbl_cache.delete(_STALE_KEY)
	return success
