# -*- coding: utf-8 -*-
import json
import re
import time
from windows.base_window import BaseDialog
from modules.debrid import debrid_for_ext_cache_check
from modules.utils import TaskPool
from modules.source_utils import source_filters, release_group as _release_group, provider_display_name, provider_panel_name, dv_profile_named, rank_provider
from modules.chips import chip_strip, strip_width, text_lines
import re as _re

# LOCAL PATCH 2026-09-26: the rows show extraInfo's tags as flags, in kind order -- HDR (2), source, audio (2), channels,
# language (2); no video codec, by choice -- packed from the left so a missing kind leaves no gap. flag<n> are the eight
# slots in order. Flags are AF3's colour flags (skins/Default/media/deadlight_flags/source_info, CC BY-NC-SA credit there).
# A tag with no faithful flag, or past its column's slots, stays text: HYBRID, SDR, containers, and Indian regional
# languages (AF3's hin, tam and tel are one Indian flag and its 'mal' is Malay), so only Hindi is a flag.
# LOCAL PATCH 2026-09-27: white logos (source_white; languages stay in colour). The colour set stays in source_info.
_FLAG_PATH = 'deadlight_flags/source_white/%s.png'
_FLAG_COLUMNS = (
	('hdr', 2, (('D/VISION', 'dolbyvision'), ('HDR10+', 'hdr10plus'), ('HDR', 'hdr10'))),
	# LOCAL PATCH 2026-10-01: + REMUX, ranked over BLURAY -- the more specific of the two, and the column has one slot (a
	# BDRemux name often carries no BLURAY tag)
	('source', 1, (('REMUX', 'remux'), ('WEB', 'web'), ('BLURAY', 'bluray'), ('HDTV', 'hdtv'), ('DVD', 'dvd'), ('PDTV', 'sdtv'))),
	('audio', 2, (('ATMOS', 'atmos'), ('TRUEHD', 'truehd'), ('DTS-X', 'dtsx'), ('DTS-HD MA', 'dtshd_ma'), ('DTS-HD', 'dtshd_hra'),
				('DTS', 'dts'), ('DD+', 'eac3'), ('DD', 'ac3'), ('DD-EX', 'ac3'), ('AAC', 'aac'), ('OPUS', 'opus'), ('FLAC', 'flac'), ('MP3', 'mp3'))),
	('ch', 1, (('2CH', 'ch2'), ('6CH', 'ch6'), ('7CH', 'ch7'), ('8CH', 'ch8'))),
	('lang', 2, (('MULTI-LANG', 'lang_multi'), ('ENGLISH', 'lang_eng'), ('HINDI', 'lang_hin'), ('SPANISH', 'lang_spa'), ('FRENCH', 'lang_fre'), ('GERMAN', 'lang_ger'),
				('ITALIAN', 'lang_ita'), ('RUSSIAN', 'lang_rus'), ('JAPANESE', 'lang_jpn'), ('KOREAN', 'lang_kor'), ('CHINESE', 'lang_chi'),
				('ARABIC', 'lang_ara'), ('TURKISH', 'lang_tur'), ('DUTCH', 'lang_dut'), ('POLISH', 'lang_pol'), ('PORTUGUESE', 'lang_por'))))
_FLAG_OF = dict((tag, (column, rank, name)) for column, _, tags in _FLAG_COLUMNS for rank, (tag, name) in enumerate(tags))
_LEFT_FLAGS = tuple('flag%d' % (n + 1) for n in range(sum(slots for _, slots, _ in _FLAG_COLUMNS)))   # flag1..flag8
_CHIP_LINE = 885                                   # list row line 2, from the chips' left edge to the row's right margin
_SITE_SLOTS = tuple(range(200, 701, 50))           # the site . group label widths sources_results.xml offers (200..700)
_MARKUP = _re.compile(r'\[/?(?:B|I|COLOR[^\]]*)\]', _re.I)


# Streaming-service codes -> the studio logo shown on the row (resource.images.studios.coloured, the
# pack AF3 uses; file names as the pack's index lists them). Searched only from the resolution on
# ('2160p ATVP WEB-DL'), falling back to the part after SxxEyy/year: episode titles sit between the
# two, and 'Stan' / 'Hulu' there are title words.
_STUDIO_PATH = 'resource://resource.images.studios.coloured/%s.png'
# LOCAL PATCH 2026-09-26: display labels too long for the row's left block. DISPLAY ONLY (provider_label, Site:, the left
# block's provider): 'provider' itself must keep the scraper's name -- the filter panel sorts by the provider-order
# setting, and 'HTTP' is not in it. HTTP_STREAMS is wider than the 150 px column.
_SHORT_LABEL = _SHORT_PROVIDER = {'HTTP_STREAMS': 'HTTP'}
_SERVICES = (('atvp', 'apple tv+'), ('atv', 'apple tv+'), ('amzn', 'prime video'), ('nf', 'netflix'), ('dsnp', 'disney+'),
			 ('hmax', 'hbo max'), ('pcok', 'peacock'), ('pmtp', 'paramount+'), ('hulu', 'hulu'), ('cr', 'crunchyroll'),
			 ('stan', 'stan'), ('mubi', 'mubi'), ('stz', 'starz'), ('amcp', 'amc+'))
_SERVICE = _re.compile(r'(?i)(?<![a-z0-9])(%s)(?![a-z0-9])' % '|'.join(code for code, _ in _SERVICES))
_SERVICE_LOGO = dict(_SERVICES)
# LOCAL PATCH 2026-09-29: + a bare season number -- a season pack ('... S01 MULTi VF2 2160p') has no SxxEyy
_TECH_START = _re.compile(r'(?i)(?<![a-z0-9])(?:s\d{1,2}\s?e\d{1,4}|s\d{1,2}|(?:19|20)\d{2}|\d{3,4}[pi])(?![a-z0-9])')
_RESOLUTION = _re.compile(r'(?i)(?<![a-z0-9])\d{3,4}[pi](?![a-z0-9])')


def _service_split(name):
	"""(everything before the service-bearing part, the service-bearing part)."""
	name = name or ''
	m = _RESOLUTION.search(name) or _TECH_START.search(name)
	return (name[:m.start()], name[m.start():]) if m else (name, '')


# LOCAL PATCH 2026-09-26: audio languages the release NAME states, as get_info tags (get_info only tags MULTI-LANG, so
# torrent rows showed no language). Two readers, guarded against title words:
#   * 3-letter codes: UPPERCASE only between SxxEyy / year and the resolution (episode titles there are Title Case);
#     ANY case from the resolution on (MediaFusion writes '... REMUX Fra').
#   * full words ('Hindi', 'French') and MULTI / DUAL AUDIO, any case, from the resolution on only.
# Codes with no faithful flag (TAM, TEL, MAL, KAN) are left out -- they would only be text.
_LANG_CODES = {'ENG': 'ENGLISH', 'HIN': 'HINDI', 'SPA': 'SPANISH', 'ESP': 'SPANISH', 'FRA': 'FRENCH', 'FRE': 'FRENCH',
			   'GER': 'GERMAN', 'DEU': 'GERMAN', 'ITA': 'ITALIAN', 'RUS': 'RUSSIAN', 'JPN': 'JAPANESE', 'JAP': 'JAPANESE',
			   'KOR': 'KOREAN', 'CHI': 'CHINESE', 'CHN': 'CHINESE', 'ARA': 'ARABIC', 'TUR': 'TURKISH', 'DUT': 'DUTCH',
			   'NLD': 'DUTCH', 'POL': 'POLISH', 'POR': 'PORTUGUESE',
			   # LOCAL PATCH 2026-09-29: French scene tags -- VF (dub), VFF (France), VFQ (Quebec), VFI (international),
			   # VF2 (both), TRUEFRENCH
			   'VF': 'FRENCH', 'VFF': 'FRENCH', 'VFQ': 'FRENCH', 'VFI': 'FRENCH', 'VF2': 'FRENCH', 'TRUEFRENCH': 'FRENCH'}
_LANG_CODE = _re.compile(r'(?<![A-Za-z0-9])(%s)(?![A-Za-z0-9])' % '|'.join(_LANG_CODES))
_LANG_CODE_ANYCASE = _re.compile(r'(?i)(?<![a-z0-9])(%s)(?![a-z0-9])' % '|'.join(_LANG_CODES))
_LANG_WORD = _re.compile(r'(?i)(?<![a-z])(english|hindi|spanish|french|german|italian|russian|japanese|korean|chinese|arabic|'
						 r'turkish|dutch|polish|portuguese)(?![a-z])')
# LOCAL PATCH 2026-10-26: 'multi' not followed by a 'sub' word, as source_utils._I_MULTI -- 'Multi-Subs' is subtitles,
# not audio
_MULTI_WORD = _re.compile(r'(?i)(?<![a-z])(?:multi(?![\s._-]?sub)|dual[\s._-]?audio)(?![a-z])')


def _name_languages(name):
	"""Language tags ('ENGLISH', 'MULTI-LANG', ...) a release name states, in order, once each."""
	name = name or ''
	m = _TECH_START.search(name)
	after_marker = name[m.start():] if m else ''
	from_resolution = _service_split(name)[1]
	out = []
	codes = _LANG_CODE.findall(after_marker) + [c.upper() for c in _LANG_CODE_ANYCASE.findall(from_resolution)]
	for tag in ([_LANG_CODES[c] for c in codes] + [w.upper() for w in _LANG_WORD.findall(from_resolution)]
				+ (['MULTI-LANG'] if _MULTI_WORD.search(from_resolution) else [])):
		if tag not in out: out.append(tag)
	return out


def _studio_flag(name, tags):
	"""The studio logo for a release, or ''. The name's service code first; get_info's APPLETV+ tag after."""
	m = _SERVICE.search(_service_split(name)[1])
	if m: return _STUDIO_PATH % _SERVICE_LOGO[m.group(1).lower()]
	if 'APPLETV+' in (t.upper() for t in tags): return _STUDIO_PATH % 'apple tv+'
	return ''


def _flag_columns(extra_info):
	"""({flag<n>: texture path}, the tags with no flag as text) for one extraInfo."""
	found, text, seen = {}, [], set()
	for raw in (extra_info or '').split('|'):
		tag = _MARKUP.sub('', raw).strip()
		if not tag or tag == 'N/A': continue
		hit = _FLAG_OF.get(tag.upper())
		if hit is None: text.append(tag)
		elif hit[2] not in seen:
			seen.add(hit[2])
			found.setdefault(hit[0], []).append((hit[1], hit[2], tag))
	# HDR10+ rows also carry the broad HDR tag (kept for the HDR filter); one HDR flag is enough
	if 'hdr10plus' in seen: found['hdr'] = [f for f in found['hdr'] if f[1] != 'hdr10']
	# MULTI only says "more than one language": with two languages named it would push one out of the two slots.
	# One named language keeps MULTI beside it.
	named = [f for f in found.get('lang', []) if f[1] != 'lang_multi']
	if len(named) >= 2: found['lang'] = named
	# HYBRID means DV + an HDR10 layer -- two flags in the HDR column already say it, and the word overflowed the meta line
	if len(found.get('hdr', [])) >= 2: text = [t for t in text if t.upper() != 'HYBRID']
	# LOCAL PATCH 2026-09-26: PACKED, not fixed columns (no gap where a missing kind would sit). Kind order and per-kind
	# limits stay.
	packed = []
	for column, slots, _ in _FLAG_COLUMNS:
		ranked = sorted(found.get(column, []))
		packed.extend(_FLAG_PATH % name for _, name, _ in ranked[:slots])
		text.extend(tag for _, _, tag in ranked[slots:])   # past the kind's limit: kept, as text
	# LOCAL PATCH 2026-10-01: left-packed flag1..flag8. Every layout shows these as text chips (modules/chips.py, fed the
	# flag names); the logos only when no strip could be drawn.
	props = dict((key, packed[n] if n < len(packed) else '') for n, key in enumerate(_LEFT_FLAGS))
	return props, text


# LOCAL PATCH 2026-09-29: the resolve screen's tag line (modules/sources.py resolve_display), read by kind like the flags
# -- HDR, codec, source, audio, channels, language, then the rest -- joined with the heading's dot. Same dedup as
# _flag_columns, plus the languages the release name states.
# LOCAL PATCH 2026-10-02: MPEG is not a codec kind -- get_info's MPEG is the .mp4 / .mpg CONTAINER, so it lands in OTHER.
_TAG_KINDS = (('D/VISION', 'HDR10+', 'HDR', 'SDR', 'HYBRID'), ('HEVC', 'AV1', 'AVC', 'XVID', 'DIVX'),
			  ('REMUX', 'BLURAY', 'WEB', 'HDTV', 'DVD', 'PDTV', 'HDRIP'),
			  ('ATMOS', 'TRUEHD', 'DTS-X', 'DTS-HD MA', 'DTS-HD', 'DTS', 'DD+', 'DD-EX', 'DD', 'AAC', 'OPUS', 'FLAC', 'MP3'),
			  ('2CH', '6CH', '7CH', '8CH'),
			  ('MULTI-LANG',) + tuple(tag for tag, _ in _FLAG_COLUMNS[4][2] if tag != 'MULTI-LANG'))
_TAG_RANK = dict((tag, (kind, rank)) for kind, tags in enumerate(_TAG_KINDS) for rank, tag in enumerate(tags))
# how each tag READS on that line: words capitalised, acronyms (HDR, HEVC, DD+, WEB) left as they are, channel
# counts as speaker layouts. Display only -- extraInfo and the filters keep get_info's tags.
_TAG_DISPLAY = {'D/VISION': 'Dolby Vision', 'HYBRID': 'Hybrid', 'REMUX': 'Remux', 'BLURAY': 'Blu-ray', 'HDRIP': 'HDRip',
				'ATMOS': 'Atmos', 'TRUEHD': 'TrueHD', 'OPUS': 'Opus', 'XVID': 'XviD', 'DIVX': 'DivX',
				'2CH': '2.0', '6CH': '5.1', '7CH': '6.1', '8CH': '7.1', 'MULTI-LANG': 'Multi-Lang', 'SUBS': 'Subs',
				'APPLETV+': 'Apple TV+', 'AI ENHANCED/UPSCALED': 'AI Upscaled',
				# LOCAL PATCH 2026-10-01: the pack tag make_items prefixes -- display only; extraInfo keeps 'PACK' uppercase for Filter
				# by Info's substring match
				'SEASON PACK': 'Season Pack', 'SHOW PACK': 'Show Pack', 'TRUE PACK': 'Pack'}
_TAG_DISPLAY.update((tag, tag.capitalize()) for tag in _TAG_KINDS[5][1:])   # ENGLISH -> English


def resolve_tags_line(extra_info, name=''):
	"""extraInfo's tags (+ the name's languages) in kind order, once each, joined with '  ·  '."""
	tags = []
	for raw in (extra_info or '').split('|') + _name_languages(name):
		tag = _MARKUP.sub('', raw).strip()
		if tag and tag != 'N/A' and tag.upper() not in (t.upper() for t in tags): tags.append(tag)
	upper = set(t.upper() for t in tags)
	drop = set()
	if 'HDR10+' in upper: drop.add('HDR')
	if 'D/VISION' in upper and ('HDR' in upper or 'HDR10+' in upper): drop.add('HYBRID')
	if len(upper & set(_TAG_KINDS[5][1:])) >= 2: drop.add('MULTI-LANG')
	other = len(_TAG_KINDS)
	ordered = sorted(enumerate(t for t in tags if t.upper() not in drop),
					 key=lambda p: _TAG_RANK.get(p[1].upper(), (other, p[0])))
	return '  ·  '.join(_TAG_DISPLAY.get(t.upper(), t) for _, t in ordered)


# LOCAL PATCH 2026-10-01: the list layout's detail panel shows the tags in rows by kind -- VIDEO, AUDIO, LANGUAGE, OTHER --
# read off resolve_tags_line's output so both say the same thing.
_DISPLAY_KIND = dict((_TAG_DISPLAY.get(tag, tag), kind) for kind, tags in enumerate(_TAG_KINDS) for tag in tags)


_SIZE_UNITS = {'KB': 1024, 'MB': 1024 ** 2, 'GB': 1024 ** 3, 'TB': 1024 ** 4}   # size_label is bytes / 1024**n


def label_bytes(size_label):
	"""'87.98 GB' -> bytes, or 0."""
	try:
		number, unit = (size_label or '').split()
		return float(number) * _SIZE_UNITS[unit.upper()]
	except (ValueError, KeyError): return 0


def shown_size(size_label):
	"""LOCAL PATCH 2026-11-16: the size as shown -- a size the provider never gave is stored as '0.00 GB' (MediaFusion's RSS-fed
	rows carry no size line and no videoSize: The Voice S29E01, 12 of 13 rows) and showed as a real size; '? GB' instead."""
	return '? GB' if (size_label or '').strip().startswith('0') and not label_bytes(size_label) else size_label


def bitrate_label(size_label, duration, pack=False):
	"""'≈ 98 Mbps' from the size and the runtime (seconds), or '' -- a pack's size covers many episodes."""
	if pack or not duration: return ''
	try: mbps = label_bytes(size_label) * 8 / float(duration) / 1000000
	except (ValueError, ZeroDivisionError): return ''
	if mbps < 0.5: return ''
	# no-break spaces: the cards sidebar wrapped '≈ 41' and 'MBPS' onto separate lines
	return '≈ %s Mbps' % ('%d' % round(mbps) if mbps >= 10 else '%.1f' % mbps)


# LOCAL PATCH 2026-10-01: the cards layout's chips, two strips (sources_results.xml chips_a, chips_b: 381 x 32 each).
# Line 1 takes chips while they fit, measured from each chip's own cached one-chip strip plus _draw's gap; the rest go to
# line 2, shrunk to fit if they must.
_CARD_CHIP_W, _CARD_CHIP_H = 381, 32


def _card_chip_lines(names):
	"""(line 1 strip, line 2 strip) for these flag names; '' for an empty line."""
	if not names: return '', ''
	gap, used, split = _CARD_CHIP_H * 0.18, 0, 0
	for name in names:
		need = strip_width(chip_strip([name]), _CARD_CHIP_H) + (gap if split else 0)
		if split and used + need > _CARD_CHIP_W: break
		used += need
		split += 1
	return chip_strip(names[:split]), chip_strip(names[split:])


# LOCAL PATCH 2026-10-02: NO-BREAK spaces after the dot: Kodi wraps a textbox at plain spaces only, so a wrapped line
# carries the dot down with its tag ('· WEB') instead of ending on '·'.
_WRAP_SEP = '  ·  '


# LOCAL PATCH 2026-10-02: known release groups, highlighted in BOLD colour (display only). From TRaSH Guides (Radarr +
# Sonarr cf JSON): GOLD = tier 01 of Remux, UHD Bluray, HD Bluray and WEB; BLUE = tiers 02-03; PINK (anime) = Anime BD
# tiers 01-03 and Anime Web tiers 01-02, plus SeaDex's frequent best groups. A group in two lists takes the higher.
# Names are matched lower-case without '@' or edge dashes ('-ZR-' -> 'zr').
# LOCAL PATCH 2026-10-25: the tier lists live in modules/release_groups.py, shared with the results sort; colours stay here.
from modules.release_groups import GROUP_TIERS as _GROUP_TIERS, group_key as _group_key
_GROUP_COLOUR = {1: 'FFE3B341', 2: 'FF9CC9FF', 3: 'FFE58FD9'}   # gold, light blue, pink (anime)

# LOCAL PATCH 2026-10-15: one row colour, three shades. The setting's deep (jewel) tone fills every row's stripe and the
# focused row's quality block ('highlight_deep'); the focused background is 30% of it mixed into the window theme
# ('highlight_focus', so it follows a theme change); labels get the same hue lightened to read at 10:1 on the theme
# ('highlight'; a pale colour stays as set). Uncached grey stays dim.
_UNCACHED_GREY = 'FF7C7C7C'
_FOCUS_MIX, _TEXT_CONTRAST = 0.30, 10.0
_shade_memo = {}

def _rgb(colour): return tuple(int(colour[-6:][i:i + 2], 16) for i in (0, 2, 4))

def _mix(a, b, t): return tuple(int(round(x * (1 - t) + y * t)) for x, y in zip(a, b))

def _luminance(rgb):
	def lin(c):
		c /= 255.0
		return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
	r, g, b = map(lin, rgb)
	return 0.2126 * r + 0.7152 * g + 0.0722 * b

def _row_shades(colour, theme):
	key = (colour, theme)
	if key in _shade_memo: return _shade_memo[key]
	try: deep, base = _rgb(colour), _rgb(theme)
	except: return {}
	base_lum = _luminance(base)
	text, step = deep, 0.0
	if colour.upper() != _UNCACHED_GREY:
		while step < 0.8 and (_luminance(text) + 0.05) / (base_lum + 0.05) < _TEXT_CONTRAST:
			step += 0.05
			text = _mix(deep, (255, 255, 255), step)
	shades = {'highlight': 'FF%02X%02X%02X' % text, 'highlight_deep': 'FF%02X%02X%02X' % deep,
			  'highlight_focus': 'FF%02X%02X%02X' % _mix(base, deep, _FOCUS_MIX)}
	_shade_memo[key] = shades
	return shades


# LOCAL PATCH 2026-10-02: scrape.diag_timing for the window build -- seconds per step, summed over the rows (threads
# overlap, so the sum can exceed the wall time).
_build_times = {}


def _tick(label, t0):
	t1 = time.perf_counter()
	_build_times[label] = _build_times.get(label, 0.0) + (t1 - t0)
	return t1


# LOCAL PATCH 2026-10-02: the window's row and filter builders use at most 4 threads (fewer on a smaller CPU): the work is
# Python plus Kodi list-item calls under the GIL, so more threads only add start-up and switching cost (worst on the
# CoreELEC box). The scrapers keep max_threads(): they wait on the network.
def _build_threads(count):
	import os
	return max(1, min(count, 4, os.cpu_count() or 4, max_threads()))


def group_display(group):
	"""The group as the skin shows it: a known group bold in its tier colour, anything else as it is ('' stays '')."""
	colour = _GROUP_COLOUR.get(_GROUP_TIERS.get(_group_key(group)))
	return '[B][COLOR %s]%s[/COLOR][/B]' % (colour, group) if colour and group else (group or '')


def tag_groups(extra_info, name='', line=None):
	"""{'tags_video', 'tags_audio', 'tags_lang', 'tags_other'}: resolve_tags_line split by kind, '' for an empty kind."""
	groups = {'tags_video': [], 'tags_audio': [], 'tags_lang': [], 'tags_other': []}
	if line is None: line = resolve_tags_line(extra_info, name)   # LOCAL PATCH 2026-10-25 (4.0.5): make_items passes the line it built
	for tag in (line.split('  ·  ') if line else []):
		kind = _DISPLAY_KIND.get(tag)
		key = 'tags_video' if kind in (0, 1, 2) else 'tags_audio' if kind in (3, 4) else 'tags_lang' if kind == 5 else 'tags_other'
		groups[key].append(tag)
	return dict((key, _WRAP_SEP.join(tags)) for key, tags in groups.items())
from modules.settings import provider_sort_ranks, avoid_episode_spoilers, max_threads, diag_timing
from modules.kodi_utils import get_icon, kodi_dialog, hide_busy_dialog, addon_fanart, select_dialog, ok_dialog, notification

class SourcesResults(BaseDialog):
	# LOCAL PATCH 2026-10-24: text on the background: the plain theme background, never the dialogs' see-through dim (the
	# rows sit over the title's fanart, which the XML darkens by a fixed amount).
	full_screen_background = True   # text on the background (base_window.set_theme)

	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.selected = (None, '')   # LOCAL PATCH 2026-10-15: a close by Dialog.Close / teardown can reach run() before it is set
		self.window_format = kwargs.get('window_format', 'list')
		self.window_id = kwargs.get('window_id', 2000)
		self.filter_window_id = 2100
		self.results = kwargs.get('results')
		self.uncached_results = kwargs.get('uncached_results', [])
		self.filtered_results = list(kwargs.get('filtered_results') or [])
		self.showing_filtered = False
		self.info_highlights_dict = kwargs.get('scraper_settings')
		self.episode_group_label = kwargs.get('episode_group_label', '')
		self.prescrape = kwargs.get('prescrape')
		self.meta = kwargs.get('meta')
		self.filters_ignored = kwargs.get('filters_ignored', False)
		self.meta_get = self.meta.get
		self.make_poster = self.window_format in ('list', 'medialist')
		self.empty_poster = get_icon('box_office')
		self.addon_fanart = addon_fanart()
		self.poster = self.meta_get('poster') or self.empty_poster
		self.external_cache_check = kwargs.get('external_cache_check')
		self.prerelease_values, self.prerelease_key = ('CAM', 'SCR', 'TELE'), 'CAM/SCR/TELE'
		self.info_icons_dict = {'easynews': get_icon('easynews'), 'alldebrid': get_icon('alldebrid'), 'real-debrid': get_icon('realdebrid'),
		'premiumize': get_icon('premiumize'), 'torbox': get_icon('torbox'), 'ad_cloud': get_icon('alldebrid'), 'rd_cloud': get_icon('realdebrid'),
		'pm_cloud': get_icon('premiumize'), 'tb_cloud': get_icon('torbox'), 'aiostreams': get_icon('aiostreams'), 'http_streams': get_icon('aiostreams'), 'stremio': get_icon('aiostreams')}
		self.info_quality_dict = {'4k': get_icon('flag_4k', 'flags'), '1080p': get_icon('flag_1080p', 'flags'), '720p': get_icon('flag_720p', 'flags'),
		'sd': get_icon('flag_sd', 'flags'), 'cam': get_icon('flag_sd', 'flags'), 'tele': get_icon('flag_sd', 'flags'), 'scr': get_icon('flag_sd', 'flags')}
		_t0 = time.perf_counter(); _build_times.clear()
		self.make_items()
		_t1 = time.perf_counter()
		self.make_filter_items()
		self.make_pills()
		_t2 = time.perf_counter()
		self.set_properties()
		# LOCAL PATCH 2026-10-02: scrape.diag_timing -- where the window build goes (see _tick)
		if diag_timing():
			from modules.kodi_utils import logger
			logger('scrape.timing', 'window build: rows %dms (%d), filters %dms, props %dms; per step (summed over threads): %s'
				% ((_t1 - _t0) * 1000, len(self.item_list or []), (_t2 - _t1) * 1000, (time.perf_counter() - _t2) * 1000,
				', '.join('%s %dms' % (k, v * 1000) for k, v in sorted(_build_times.items()))))

	def onInit(self):
		from modules.kodi_utils import logger, logger_debug   # LOCAL PATCH 2026-10-25 (4.0.5): the onInit traces at DEBUG; the focus error stays
		import xbmc, time
		_t_init = time.perf_counter()   # LOCAL PATCH 2026-11-01: window open timing, see the end of onInit
		# LOCAL PATCH 2026-11-08: the downloader (its own Python interpreter) closes this window once a download starts by
		# pressing Back on it, found by this id (downloader.close_source_list)
		import xbmcgui
		self.set_home_property('sources_window_id', str(xbmcgui.getCurrentWindowDialogId()))
		self.filter_applied = False
		if self.make_poster: self.set_poster()
		self.setProperty('window_format', self.window_format)
		item_count = len(self.item_list) if self.item_list else 0
		filter_count = len(self.filter_list) if self.filter_list else 0
		logger_debug('SourcesResults onInit', 'window_format=%s window_id=%s items=%d filter_items=%d' % (self.window_format, self.window_id, item_count, filter_count))
		self.add_items(self.window_id, self.item_list)
		self.add_items(self.filter_window_id, self.filter_list)
		self.place_pills()
		_t_items = time.perf_counter()
		# LOCAL PATCH 2026-09-26: poll for focus instead of fixed sleeps: setFocusId is processed by the GUI thread, so an
		# immediate getFocusId races it. Check every 20 ms, re-issue setFocusId every 100 ms, give up at 400 ms.
		try:
			start = time.time()
			focused = 0
			for step in range(20):
				if step % 5 == 0: self.setFocusId(self.window_id)
				xbmc.sleep(20)
				focused = self.getFocusId()
				if focused == self.window_id: break
			logger_debug('SourcesResults onInit', 'focusedId=%s after %d ms' % (focused, int((time.time() - start) * 1000)))
			if focused != self.window_id:
				self.setFocusId(self.filter_window_id)
				logger_debug('SourcesResults onInit', 'fallback focus to filter %s' % self.filter_window_id)
		except Exception as e:
			logger('SourcesResults onInit focus error', str(e))
		# LOCAL PATCH 2026-11-01: how long KODI takes to open the window, beside the row build: doModal -> onInit is Kodi loading
		# sources_results.xml and creating its controls (every layout's lists), then the rows handed over, then focus.
		try:
			if diag_timing() and getattr(self, '_t_open', None):
				_t_end = time.perf_counter()
				logger('scrape.timing', 'window open (%s, %d rows): Kodi load %dms, rows added %dms, focus %dms, total %dms'
					% (self.window_format, item_count, (_t_init - self._t_open) * 1000, (_t_items - _t_init) * 1000,
					(_t_end - _t_items) * 1000, (_t_end - self._t_open) * 1000))
		except Exception: pass

	def run(self):
		self._t_open = time.perf_counter()   # LOCAL PATCH 2026-11-01: window open timing (onInit)
		self.doModal()
		self.clear_home_property('sources_window_id'), self.clear_home_property('close_sources_on_download')
		self.clearProperties()
		self.clear_home_property('window_theme.sources')
		hide_busy_dialog()
		return self.selected

	def get_provider_and_path(self, provider):
		try: return provider, self.info_icons_dict[provider]
		except: return 'folders', get_icon('folder')

	def get_quality_and_path(self, quality):
		try: return quality, self.info_quality_dict[quality]
		except: return 'sd', get_icon('flag_sd')

	def filter_action(self, action):
		if action == self.right_action or action in self.closing_actions:
			self.select_item(self.filter_window_id, 0)
			self.setFocusId(self.window_id)
		if action in self.selection_actions:
			chosen_listitem = self.get_listitem(self.filter_window_id)
			filter_type, filter_value = chosen_listitem.getProperty('filter_type'), chosen_listitem.getProperty('filter_value')
			if filter_type in ('quality', 'provider'):
				if filter_value == self.prerelease_key: filtered_list = [i for i in self.item_list if i.getProperty(filter_type) in self.prerelease_values]
				else: filtered_list = [i for i in self.item_list if i.getProperty(filter_type) == filter_value]
			elif filter_type == 'special':
				if filter_value == 'showfiltered': return self.show_filtered_sources()
				if filter_value == 'title':
					keywords = kodi_dialog().input('Enter Keyword (Comma Separated for Multiple)')
					if not keywords: return
					choice = [i.strip().upper() for i in keywords.split(',') if i.strip()]
					filtered_list = [i for i in self.item_list if all(x in i.getProperty('name') for x in choice)]
				elif filter_value == 'extraInfo':
					filters = source_filters()
					list_items = [{'line1': item[0], 'icon': self.poster} for item in filters]
					kwargs = {'items': json.dumps(list_items), 'heading': 'Filter Results', 'multi_choice': 'true'}
					choice = select_dialog(filters, **kwargs)
					if choice == None: return
					choice = [i[1] for i in choice]
					filtered_list = [i for i in self.item_list if all(x in i.getProperty('extraInfo') for x in choice)]
				elif filter_value == 'showuncached': filtered_list = self.make_items(self.uncached_results)
				else: #cache_check_rescrape
					self.selected = ('cache_change_rescrape', 'false' if self.external_cache_check else 'true')
					return self.close()
			if not filtered_list: return ok_dialog(text='No Results')
			self.set_filter(filtered_list)

	def onAction(self, action):
		if self.get_visibility('Control.HasFocus(%s)' % self.filter_window_id): return self.filter_action(action)
		focus_id = self.getFocusId()
		if focus_id in self._PILL_IDS:   # LOCAL PATCH 2026-10-02: quick-filter pills, see make_pills
			if action in self.selection_actions: return self.toggle_pill(focus_id)
			if action == self.down_action: return self.setFocusId(self.window_id)
			if action not in self.closing_actions: return
		chosen_listitem = self.get_listitem(self.window_id)
		if action in self.closing_actions:
			if self.filter_applied: return self.clear_filter()
			self.selected = (None, '')
			return self.close()
		if action == self.info_action: return self.show_info(chosen_listitem)
		elif action in self.selection_actions: return self.play_listitem(chosen_listitem)
		elif action in self.context_actions:
			source_json = chosen_listitem.getProperty('source')
			if not source_json: return   # LOCAL PATCH 2026-11-22: a row without a 'source' property has nothing to act on
			source = json.loads(source_json)
			choice = self.context_menu(source)
			if choice:
				if isinstance(choice, dict):
					if choice.get('mode') == 'downloader.runner': self._close_when_download_starts()
					return self.execute_code('RunPlugin(%s)' % self.build_url(choice))
				if choice == 'results_info': return self.show_info(chosen_listitem)
				if choice == 'showfiltered': return self.show_filtered_sources()
				if choice == 'rd_cloud_delete':
					from apis.real_debrid_api import RealDebridAPI
					rd_api = RealDebridAPI()
					function = rd_api.delete_torrent if source['cache_type'] == 'torrent' else rd_api.delete_download
					result = function(source['folder_id'])
					if result.status_code in (401, 403, 404): return notification('Error', 1200)
					rd_api.clear_cache()
					self.delete_single_source(source)

	def _close_when_download_starts(self):
		"""LOCAL PATCH 2026-11-07: close the results once a download starts. The downloader closes this window itself, by the id
		onInit stored, the moment the download really starts (cancelled before that, the results stay). Not a polling thread
		here: that did not close it. This only arms it, so a download started anywhere else never closes a source list."""
		self.set_home_property('close_sources_on_download', 'true')

	def delete_single_source(self, single_source):
		# LOCAL PATCH 2026-11-22: a row removed while the filtered rows are shown leaves that list, not the results
		if self.showing_filtered:
			self.filtered_results.remove(single_source)
			self.make_filter_items()
			self.reset_window(self.filter_window_id)
			self.add_items(self.filter_window_id, self.filter_list)
			if self.filtered_results: return self.show_filtered_sources()
			return self.clear_filter()
		self.results.remove(single_source)
		self.make_items()
		self.total_results = str(len(self.item_list))
		self._reset_results()
		self.add_items(self.window_id, self.item_list)
		self.setFocusId(self.window_id)
		self.set_properties()

	def _set_chips(self, listitem, chip_names):
		# LOCAL PATCH 2026-10-02: the cards layout shows only its two lines -- no one-line strip as well
		if self.window_format == 'rows':
			_chips = ''
			_line_a, _line_b = _card_chip_lines(chip_names)
			listitem.setProperties({'chips_a': _line_a, 'chips_b': _line_b})
		else: _chips = chip_strip(chip_names)
		listitem.setProperty('chips', _chips)
		# LOCAL PATCH 2026-10-01: the list row's site . group label (scraper first, bold) takes what the chips leave of line 2 --
		# the widest of _SITE_SLOTS that fits (one label per slot in sources_results.xml), so it is cut only beside a full strip.
		_free = _CHIP_LINE - (strip_width(_chips, 36) + 20 if _chips else 0)
		listitem.setProperty('site_slot', str(max([0] + [n for n, w in enumerate(_SITE_SLOTS) if w <= _free])))

	def make_items(self, filtered_list=None):
		# LOCAL PATCH 2026-11-22: a Stremio slot's rows carry that add-on's name, looked up once per slot
		from scrapers.stremio_addons import addon_name
		stremio_names = {slot: addon_name(slot) for slot in {item.get('stremio_slot') for item in (filtered_list or self.results or [])} if slot}

		def builder(count, item):
			try:
				get = item.get
				_t = time.perf_counter()
				listitem = self.make_listitem()
				set_properties = listitem.setProperties
				scrape_provider, source, quality, name = get('scrape_provider'), get('source'), get('quality', 'SD'), get('display_name')
				basic_quality, quality_icon = self.get_quality_and_path(quality.lower())
				pack = get('package', 'false') in ('true', 'show', 'season')
				extraInfo = get('extraInfo', '')
				extraInfo = extraInfo.rstrip('| ')
				if pack: extraInfo = '[B]%s PACK[/B] | %s' % (get('package'), extraInfo)
				if self.episode_group_label: extraInfo = '%s | %s' % (self.episode_group_label, extraInfo)
				if not extraInfo: extraInfo = 'N/A'
				if scrape_provider == 'external':
					source_site = provider_display_name(get('provider'))   # LOCAL PATCH 2026-09-29: APIBAY shows as PIRATEBAY
					provider = get('debrid', source_site).replace('.me', '').upper()
					# LOCAL PATCH 2026-10-02: a hash several scrapers listed (external.py _process_duplicates): the row shows the first
					# scraper only (no '+N', user's call); every name in the List panel / Cards sidebar, each counted by the site filters.
					_sites = [provider_display_name(p) for p in (get('providers') or [])] or [source_site]
					source_site = _sites[0]
					set_properties({'source_site_full': _WRAP_SEP.join(_sites), 'sites': '|%s|' % '|'.join(s.upper() for s in _sites)})
					provider_lower = provider.lower()
					provider_icon = self.get_provider_and_path(provider_lower)[1]
					if 'Uncached' in item['cache_provider']:
						if 'seeders' in item: set_properties({'source_type': 'UNCACHED (%d SEEDERS)' % get('seeders', 0)})
						else: set_properties({'source_type': 'UNCACHED'})
						set_properties({'highlight': 'FF7C7C7C'})
					else:
						if provider in ('REAL-DEBRID', 'ALLDEBRID'):
							if self.external_cache_check: cache_flag = '[B]CACHED[/B]'
							else: cache_flag = 'UNCHECKED'
						else: cache_flag = '[B]CACHED[/B]'
						if highlight_type == 0: key = provider_lower
						else: key = basic_quality
						# LOCAL PATCH 2026-10-03: .get -- a CAM/SCR/TELE row under 'by quality' raised KeyError into the except below and the
						# row silently vanished
						set_properties({'highlight': self.info_highlights_dict.get(key) or self.info_highlights_dict.get('sd', '')})
						if pack: set_properties({'source_type': '%s [B]PACK[/B]' % cache_flag})
						else: set_properties({'source_type': '%s' % cache_flag})
					set_properties({'provider': provider})
				else:
					source_site = stremio_names.get(get('stremio_slot'), _SHORT_LABEL.get(source.upper(), source.upper()))
					set_properties({'source_site_full': source_site, 'sites': '|%s|' % source_site.upper()})
					# LOCAL PATCH 2026-11-23 (user): a Stremio slot row is Stremio Add-ons' own (rank_provider): its filter entry, colour, icon
					provider, provider_icon = self.get_provider_and_path(rank_provider(item) if get('stremio_slot') else source.lower())
					if highlight_type == 0: key = provider
					else: key = basic_quality
					# LOCAL PATCH: http_streams exposes a per-stream `hoster` (PixelDrain, FSL-V2, HubCloud, ...); shown in the Hoster
					# column instead of the generic 'DIRECT'.
					hoster_label = (get('hoster') or '').upper().strip() or 'DIRECT'
					set_properties({'highlight': self.info_highlights_dict.get(key) or self.info_highlights_dict.get('sd', ''), 'source_type': hoster_label, 'provider': provider.upper()})   # LOCAL PATCH 2026-10-03: .get, as above
					# LOCAL PATCH 2026-11-23 (user): a Stremio slot row playing through a debrid (http_streams 'via_debrid') reads like a
					# torrent row -- the debrid under the quality (and its icon), CACHED as the Hoster. 'provider' stays STREMIO, so the
					# panel's provider filter and the row colour keep it with Stremio Add-ons.
					via_debrid = get('via_debrid')
					if via_debrid:
						provider_icon = self.get_provider_and_path(via_debrid.lower())[1]
						set_properties({'source_type': '[B]CACHED[/B]', 'provider_label': via_debrid.upper()})
				set_properties(_row_shades(listitem.getProperty('highlight'), _theme))   # LOCAL PATCH 2026-10-15: see _row_shades
				# LOCAL PATCH 2026-09-22: release group, shown beside Site. Providers that clean the name destroy the fansub tag, so
				# animetosho passes `release_group` explicitly; for the rest a scene-style trailing -GROUP is read off the name.
				# Blank is normal (many anime names carry no group).
				release_group = (get('release_group') or '').strip()
				if not release_group: release_group = _release_group(get('name') or '')   # lru_cached (source_utils), free on repeat
				# LOCAL PATCH 2026-09-26: no group -> no Group field at all, rather than 'Group: N/A'. Built here because the skin
				# cannot hide it: $INFO's prefix form cannot hold the nested $INFO[...(highlight)] colour the label uses.
				release_group = release_group.upper()
				set_properties({'release_group_display': group_display(release_group)})
				group_segment = ('     [COLOR %s][B]Group: [/B][/COLOR]%s' % (listitem.getProperty('highlight'), release_group)) if release_group else ''
				set_properties({'release_group': release_group, 'group_segment': group_segment})
				# LOCAL PATCH 2026-09-26: the flags (see _flag_columns) and studio logo (see _studio_flag), in every layout.
				# Tags with no flag are not shown -- the row carries the flags and nothing else.
				_t = _tick('1 start..group', _t)
				_langs = _name_languages(name)
				columns, flagless = _flag_columns(' | '.join([extraInfo] + _langs) if _langs else extraInfo)
				set_properties(columns)
				set_properties({'studio_flag': _studio_flag(name, flagless)})
				# LOCAL PATCH 2026-10-01: the list layout's detail panel lists every tag, the flagless ones too (HEVC, REMUX).
				_t = _tick('2 flags+studio', _t)
				_tags_line = resolve_tags_line(extraInfo, name)
				set_properties({'tags_line': _tags_line, 'name_display': name})
				_groups = tag_groups(extraInfo, name, _tags_line)   # LOCAL PATCH 2026-10-25 (4.0.5): the line once per row, not twice
				set_properties(_groups)
				# the cards sidebar's last line: language and other in one, so an empty language leaves no leading dot
				set_properties({'tags_lang_other': _WRAP_SEP.join(filter(None, (_groups['tags_lang'], _groups['tags_other'])))})
				_t = _tick('3 tag lines', _t)
				set_properties({'bitrate': bitrate_label(get('size_label'), self.meta_get('ep_duration') or self.meta_get('duration'), pack)})
				# LOCAL PATCH 2026-10-01: the same tags as text chips, one strip image (modules/chips.py); '' -> the skin shows the flags.
				_chip_names = [columns[k].rsplit('/', 1)[-1][:-4] for k in _LEFT_FLAGS if columns.get(k)]
				# LOCAL PATCH 2026-10-05: a profile 7 release gets a P7 chip right after its Dolby Vision chip, only when the NAME says
				# P7 / FEL / MEL (source_utils.dv_profile_named) -- no remux guess
				if 'dolbyvision' in _chip_names:
					_dvp = dv_profile_named(name)
					if _dvp and _dvp.startswith('p7'):
						_at = _chip_names.index('dolbyvision') + 1
						_chip_names = _chip_names[:_at] + ['dv_' + _dvp] + _chip_names[_at:]
				# LOCAL PATCH 2026-10-19: a row kept by sources._unknown_resolution_fallback states no resolution -- UNKNOWN, not SD
				_q = 'UNKNOWN' if get('quality_unknown') else quality.upper()
				set_properties({'name_lines': str(text_lines(name, 668))})
				_t = _tick('4 name lines', _t)
				# no TOP PICK chip (modules/top_pick.py): it named the wrong file too often (user's call)
				self._set_chips(listitem, _chip_names)
				_t = _tick('5 chips', _t)
				_prov = listitem.getProperty('provider')
				if not listitem.getProperty('provider_label'): set_properties({'provider_label': _SHORT_PROVIDER.get(_prov, _prov)})
				set_properties({'name': name.upper(), 'source_site': source_site, 'provider_icon': provider_icon, 'quality_icon': quality_icon, 'count': '%02d.' % count,
						'size_label': shown_size(get('size_label', 'N/A')), 'extraInfo': extraInfo, 'quality': _q, 'hash': get('hash', 'N/A'), 'source': json.dumps(item)})	
				_tick('6 rest', _t)
				item_list.append((listitem, count))
			except: pass
		try:
			item_list = []
			highlight_type = self.info_highlights_dict['highlight_type']
			_theme = self.get_home_property('window_theme') or 'FF1F2020'
			if filtered_list:
				threads = TaskPool().tasks_enumerate(builder, filtered_list, _build_threads(len(filtered_list)))
				[i.join() for i in threads]
				item_list.sort(key=lambda k: k[1])
				item_list = [i[0] for i in item_list]
				return item_list
			threads = TaskPool().tasks_enumerate(builder, self.results, _build_threads(len(self.results)))
			[i.join() for i in threads]
			item_list.sort(key=lambda k: k[1])
			self.item_list = [i[0] for i in item_list]
			# LOCAL PATCH 2026-11-01 (cleanup): the quality header ('1080P  ·  46 results') counted once here, from the rows built.
			# A filtered list gets its own from set_filter.
			self._set_quality_heads(self.item_list)
			if self.prescrape:
				prescrape_listitem = self.make_listitem()
				prescrape_listitem.setProperty('perform_full_search', 'true')
			self.total_results = str(len(self.item_list))
			if self.prescrape: self.item_list.append(prescrape_listitem)
		except: pass

	def make_filter_items(self):
		def builder(count, item):
			listitem = self.make_listitem()
			listitem.setProperties({'label': item[0], 'filter_type': item[1], 'filter_value': item[2]})
			self.filter_list.append((listitem, count))
		duplicates = set()
		qualities = [i.getProperty('quality') for i in self.item_list \
							if not (i.getProperty('quality') in duplicates or duplicates.add(i.getProperty('quality'))) \
							and not i.getProperty('quality') == '']
		if any(i in self.prerelease_values for i in qualities): qualities = [i for i in qualities if not i in self.prerelease_values] + [self.prerelease_key]
		_q_order = ('4K', '1080P', '720P', 'SD', 'CAM/SCR/TELE')   # LOCAL PATCH 2026-10-03: an unlisted value sorts last instead of raising
		qualities.sort(key=lambda v: _q_order.index(v) if v in _q_order else len(_q_order))
		# LOCAL PATCH 2026-11-23 (user): a quality with a pill at the top (_pill_qualities) has no 'Show 4K Only' line here as well;
		# SD and CAM/SCR/TELE have no pill and keep theirs
		_pilled = set(self._pill_qualities())
		qualities = [q for q in qualities if q not in _pilled]
		quality_totals = {i: len([x for x in self.item_list if x.getProperty('quality') == i]) for i in qualities}
		if 'CAM/SCR/TELE' in qualities: quality_totals['CAM/SCR/TELE'] = len([i for i in self.item_list if i.getProperty('quality') in self.prerelease_values])
		duplicates = set()
		providers = [i.getProperty('provider') for i in self.item_list \
							if not (i.getProperty('provider') in duplicates or duplicates.add(i.getProperty('provider'))) \
							and not i.getProperty('provider') == '']
		provider_totals = {i: len([x for x in self.item_list if x.getProperty('provider') == i]) for i in providers}
		sort_ranks = provider_sort_ranks()
		cache_functions_debrid = debrid_for_ext_cache_check()
		sort_ranks['premiumize'] = sort_ranks.pop('premiumize.me')
		provider_choices = sorted(sort_ranks.keys(), key=sort_ranks.get)
		provider_choices = [i.upper() for i in provider_choices]
		providers.sort(key=lambda v: provider_choices.index(v) if v in provider_choices else len(provider_choices))   # LOCAL PATCH 2026-10-03: as above
		qualities = [('Show [B]%s[/B] Only | [B]%d[/B] Results' % (i, quality_totals[i]), 'quality', i) for i in qualities]
		providers = [('Show [B]%s[/B] Only | [B]%d[/B] Results' % (provider_display_name(i), provider_totals[i]), 'provider', i) for i in providers]
		# LOCAL PATCH 2026-10-09: no per-scraper entries ('Show from torrentio'): appended after the last provider they read as
		# that provider's own list.
		data = []
		# LOCAL PATCH 2026-11-23: worded like the panel's other entries ('Show [B]Uncached[/B] Only | [B]N[/B] Results')
		if self.filtered_results: data.append(('Show [B]Filtered[/B] Sources | [B]%d[/B] Results' % len(self.filtered_results), 'special', 'showfiltered'))
		if cache_functions_debrid: data.append(('Rescrape with External Cache Check [B]%s[/B]' % ('OFF' if self.external_cache_check else 'ON'), 'special', 'cache_check_rescrape'))
		if self.uncached_results: data.append(('Show [B]Uncached[/B] Only | [B]%d[/B] Results' % len(self.uncached_results), 'special', 'showuncached'))
		data.extend(qualities)
		data.extend(providers)
		data.extend([('Filter by [B]Title[/B]...', 'special', 'title'), ('Filter by [B]Info[/B]...', 'special', 'extraInfo')])
		self.filter_list = []
		threads = TaskPool().tasks_enumerate(builder, data, _build_threads(len(data)))
		[i.join() for i in threads]
		self.filter_list.sort(key=lambda k: k[1])
		self.filter_list = [i[0] for i in self.filter_list]

	def set_properties(self):
		self.set_home_property('window_theme.sources', self.get_home_property('window_theme'))
		self.setProperty('window_format', self.window_format)
		self.setProperty('fanart', self.meta_get('fanart') or self.addon_fanart)
		self.setProperty('clearlogo', self.meta_get('clearlogo') or '')
		self.setProperty('title', self.meta_get('title'))
		self.setProperty('episode_line', _episode_line(self.meta))
		# LOCAL PATCH 2026-10-01: the cards layout's sidebar (sources_results.xml Rows 2001)
		self.setProperty('poster', self.poster)
		self.setProperty('year', str(self.meta_get('year') or ''))
		self.setProperty('total_results', self.total_results)
		self.setProperty('filters_ignored', '| Filters Ignored' if self.filters_ignored else '')

	def set_poster(self):
		if self.window_id == 2000: self.set_image(200, self.poster)

	def play_listitem(self, chosen_listitem):
		"""OK on a row, and Play this source in the info panel."""
		if self.prescrape and chosen_listitem.getProperty('perform_full_search') == 'true':
			self.selected = ('perform_full_search', '')
			return self.close()
		chosen_source = json.loads(chosen_listitem.getProperty('source'))
		if 'Uncached' in chosen_source.get('cache_provider', ''):
			from modules.debrid import manual_add_magnet_to_cloud
			return manual_add_magnet_to_cloud({'mode': 'manual_add_magnet_to_cloud', 'provider': chosen_source['debrid'], 'magnet_url': chosen_source['url']})
		self.selected = ('play_filtered' if self.showing_filtered else 'play', chosen_source)
		return self.close()

	def show_info(self, chosen_listitem):
		"""LOCAL PATCH 2026-11-08: the source info panel; its Play this source button plays the row."""
		if chosen_listitem.getProperty('perform_full_search') == 'true': return
		if not self.open_window(('windows.sources', 'SourcesInfo'), 'sources_info.xml', item=chosen_listitem): return
		# the panel is still sliding out when open_window returns, and Kodi ignores close() on a window that is not on top:
		# the list would stay open. Wait it out.
		for _ in range(30):
			if not self.get_visibility('Window.IsVisible(sources_info.xml)'): break
			self.sleep(50)
		return self.play_listitem(chosen_listitem)

	def context_menu(self, item):
		down_file_params, down_pack_params, browse_pack_params, add_magnet_to_cloud_params = None, None, None, None
		item_get = item.get
		name, magnet_url, info_hash = item_get('name'), item_get('url', 'None'), item_get('hash', 'None')
		provider_source, scrape_provider, cache_provider = item_get('source'), item_get('scrape_provider'), item_get('cache_provider', 'None')
		uncached = 'Uncached' in cache_provider
		source, meta_json = json.dumps(item), json.dumps(self.meta)
		choices = []
		choices_append = choices.append
		if not uncached and scrape_provider != 'folders':
			down_file_params = {'mode': 'downloader.runner', 'action': 'meta.single', 'name': self.meta.get('rootname', ''), 'source': source,
								'url': None, 'provider': scrape_provider, 'meta': meta_json}
		if 'package' in item and not uncached:
			down_pack_params = {'mode': 'downloader.runner', 'action': 'meta.pack', 'name': self.meta.get('rootname', ''), 'source': source, 'url': None,
								'provider': cache_provider, 'meta': meta_json, 'magnet_url': magnet_url, 'info_hash': info_hash}
		if provider_source == 'torrent':
			browse_pack_params = {'mode': 'debrid.browse_packs', 'provider': cache_provider, 'name': name,
								'magnet_url': magnet_url, 'info_hash': info_hash}
			# LOCAL PATCH 2026-10-03: the debrid service, not the cache label -- on an uncached row cache_provider is
			# 'Uncached TorBox', which manual_add_magnet_to_cloud cannot look up.
			add_magnet_to_cloud_params = {'mode': 'manual_add_magnet_to_cloud', 'provider': item_get('debrid') or cache_provider.replace('Uncached ', ''), 'magnet_url': magnet_url}
		choices_append(('Info', 'results_info'))
		if self.filtered_results and not self.showing_filtered: choices_append((self.filtered_sources_label(), 'showfiltered'))
		if add_magnet_to_cloud_params: choices_append(('Add to Cloud', add_magnet_to_cloud_params))
		if browse_pack_params: choices_append(('Browse', browse_pack_params))
		if down_pack_params: choices_append(('Download Pack', down_pack_params))
		if down_file_params: choices_append(('Download File', down_file_params))
		if provider_source == 'rd_cloud': choices_append(('Delete from RD Cloud', 'rd_cloud_delete'))
		list_items = [{'line1': i[0], 'icon': self.poster} for i in choices]
		# LOCAL PATCH 2026-11-08: a heading naming the source ('4K  •  TorBox  •  66.30 GB'); without one the menu began with
		# an empty band
		service = (item_get('debrid') or cache_provider.replace('Uncached ', '') if cache_provider != 'None' else '') or provider_display_name(item_get('provider') or '')
		# LOCAL PATCH 2026-11-22: a Stremio slot's row is headed by that add-on's name, the site scrapers' by the panel name
		if item_get('stremio_slot'):
			from scrapers.stremio_addons import addon_name
			service = addon_name(item_get('stremio_slot'))
		elif scrape_provider == 'http_streams':
			service = provider_panel_name('http_streams')
		heading = '  •  '.join(i for i in (str(item_get('quality') or '').upper(), service, shown_size(item_get('size_label') or '')) if i and i != 'N/A')
		kwargs = {'items': json.dumps(list_items), 'heading': heading}
		choice = select_dialog([i[1] for i in choices], **kwargs)
		return choice

	# LOCAL PATCH 2026-11-22: Show Filtered Sources (Actions panel + context menu) -- the rows the scrape filters removed
	# (sources.process_results' filtered_results), listed through the window's own filter path; Back restores the results
	def filtered_sources_label(self):
		return 'Show Filtered Sources (%d)' % len(self.filtered_results)

	def show_filtered_sources(self):
		if not self.filtered_results: return
		items = self.make_items(self.filtered_results)
		if not items: return ok_dialog(text='No Results')
		return self.set_filter(items, showing_filtered=True)

	def set_filter(self, filtered_list, showing_filtered=False):
		if getattr(self, 'pill_active', None):   # a slide-out filter replaces the pills' selection
			self.pill_active = set()
			self.paint_pills()
		self.filter_applied = True
		self.showing_filtered = showing_filtered
		self._set_quality_heads(filtered_list)
		self._reset_results()
		self.add_items(self.window_id, filtered_list)
		self.setFocusId(self.window_id)
		self.setProperty('total_results', str(len(filtered_list)))
		self.setProperty('filter_applied', 'true')
		self.setProperty('showing_filtered', 'true' if showing_filtered else '')
		self.setProperty('filter_info', '| Filtered Sources · [B]BACK[/B] to Results' if showing_filtered else '| Press [B]BACK[/B] to Cancel')

	# LOCAL PATCH 2026-10-02: quick-filter pills (sources_results.xml grouplist 2200, buttons 2201-2206) above the results.
	# Each toggles; qualities are OR-ed, the rest AND-ed. A pill that would change nothing is not shown. They filter the full
	# list, like the slide-out filters, and Back clears both.
	# LOCAL PATCH 2026-11-23 (user): + an SD pill; no HQ AUDIO pill; no CACHED pill -- uncached rows live in their own list
	# (sources.process_results), so the main list is always all cached and that pill could never show. 4 qualities + HDR · DV.
	_PILL_IDS = (2201, 2202, 2203, 2204, 2205, 2206)
	_PILL_SPOT = {'list': (1290, 52), 'rows': (1271, 92), 'widelist': (1290, 50)}   # grouplist 600 wide, right-aligned

	def _pill_match(self, listitem, key):
		if key.startswith('q:'): return listitem.getProperty('quality') == key[2:]
		info = listitem.getProperty('extraInfo')
		if key == 'hdr': return '[B]HDR[/B]' in info or '[B]D/VISION[/B]' in info
		return True

	def _pill_qualities(self):
		"""The qualities that get a pill: 4K / 1080P / 720P / SD present, only when more than one is (one alone filters nothing)."""
		items = self.item_list or []
		qualities = [q for q in ('4K', '1080P', '720P', 'SD') if any(i.getProperty('quality') == q for i in items)]
		return qualities if len(qualities) > 1 else []

	def make_pills(self):
		items, keys = self.item_list or [], []
		keys.extend(('q:%s' % q, q) for q in self._pill_qualities())
		for key, label in (('hdr', 'HDR · DV'),):
			hits = sum(1 for i in items if self._pill_match(i, key))
			if 0 < hits < len(items): keys.append((key, label))
		self.pill_keys = dict(zip(self._PILL_IDS, keys))
		self.pill_active = set()
		for control_id in self._PILL_IDS:
			self.setProperty('pill_%d_label' % control_id, self.pill_keys[control_id][1] if control_id in self.pill_keys else '')
		self.paint_pills()

	def paint_pills(self):
		# LOCAL PATCH 2026-11-07: theme colours only -- on = a lit chip (accent_soft plate, accent label), off = an idle pill;
		# the focused pill is the chosen highlight in the XML, as in every other window
		soft, accent = self.get_home_property('win.accent_soft'), self.get_home_property('win.accent')
		idle = self.get_home_property('window_theme_contrast') or 'FF4a4347'
		for control_id, (key, _label) in self.pill_keys.items():
			on = key in self.pill_active
			self.set_colour_property('pill_%d_bg' % control_id, soft if on else idle)
			self.set_colour_property('pill_%d_fg' % control_id, accent if on else 'FFE8E8EA')

	def place_pills(self):
		# group 2199, not the grouplist 2200 inside it: getControl raises 'Unknown control type' on a grouplist
		try: self.getControl(2199).setPosition(*self._PILL_SPOT.get(self.window_format, self._PILL_SPOT['list']))
		except Exception as e:
			from modules.kodi_utils import logger
			logger('SourcesResults pills', 'place failed: %s' % e)

	def _reset_results(self):
		"""Empty the results list for a new item set, cursor first. The fixedlists (focusposition 3) keep their cursor
		slot through a reset (a short result was drawn half way down); selecting item 0 of the OLD list first brings it back."""
		try: self.select_item(self.window_id, 0)
		except Exception: pass
		self.reset_window(self.window_id)

	def _set_quality_heads(self, items):
		"""The sticky '1080P  ·  46 results' header counts what is SHOWN (make_items wrote the full list's counts on every
		row). Rewritten for each filter and on clear."""
		counts = {}
		for i in items: counts[i.getProperty('quality')] = counts.get(i.getProperty('quality'), 0) + 1
		for i in items:
			q = i.getProperty('quality')
			i.setProperty('quality_head', '%s  ·  %d result%s' % (q, counts[q], '' if counts[q] == 1 else 's'))

	def toggle_pill(self, control_id):
		key = self.pill_keys.get(control_id)
		if not key: return
		self.pill_active ^= {key[0]}
		self.paint_pills()
		if not self.pill_active: return self.clear_filter(keep_focus=True)
		quality_keys = [k for k in self.pill_active if k.startswith('q:')]
		other_keys = [k for k in self.pill_active if not k.startswith('q:')]
		filtered = [i for i in self.item_list if (not quality_keys or any(self._pill_match(i, k) for k in quality_keys))
					and all(self._pill_match(i, k) for k in other_keys)]
		self.filter_applied = True
		self._set_quality_heads(filtered)
		self._reset_results()
		self.add_items(self.window_id, filtered)
		self.setProperty('total_results', str(len(filtered)))
		self.setProperty('filter_applied', 'true')
		self.setProperty('filter_info', '| Press [B]BACK[/B] to Cancel' if filtered else '| No Results  ·  Press [B]BACK[/B] to Cancel')

	def clear_filter(self, keep_focus=False):
		if getattr(self, 'pill_active', None) and not keep_focus:
			self.pill_active = set()
			self.paint_pills()
		self.filter_applied = False
		self.showing_filtered = False
		self._set_quality_heads(self.item_list)
		self._reset_results()
		self.add_items(self.window_id, self.item_list)
		if not keep_focus: self.setFocusId(self.window_id)
		self.select_item(self.filter_window_id, 0)
		self.setProperty('total_results', self.total_results)
		self.setProperty('filter_applied', 'false')
		self.setProperty('showing_filtered', '')
		self.setProperty('filter_info', '')

# LOCAL PATCH 2026-09-27: Kodi reads colordiffuse 00000000 as 'no colour' and draws white. Alpha 1 of 255 is invisible
# without being zero.
_BAR_HIDDEN = '01000000'

def _display_season_episode(meta):
	"""LOCAL PATCH 2026-10-03: (season, episode) as anime is actually numbered, for the two labels below (TMDb files The
	Apothecary Diaries as ONE season of 49; releases and the episode list say S03E01). metadata.cour_display_numbers, as
	those use; labels only -- play, watched state and the scrape keep TMDb's pair. Non-anime / unmapped: unchanged."""
	season, episode = int(meta.get('season')), int(meta.get('episode'))
	try:
		from modules.metadata import cour_display_numbers
		return cour_display_numbers(meta, season, episode)
	except Exception: return season, episode


def _episode_line(meta):
	"""LOCAL PATCH 2026-09-27: say which episode is being searched for, in anime display numbering (_display_season_episode).
	LOCAL PATCH 2026-11-22: one helper for the loading window and the results window's count line ('S01E05  ·  <title>')."""
	if meta.get('media_type') != 'episode': return ''
	try: number = 'S%02dE%02d' % _display_season_episode(meta)
	except (TypeError, ValueError): number = ''
	return '  ·  '.join(part for part in (number, meta.get('ep_name') or '') if part)


class SourcesPlayback(BaseDialog):
	full_screen_background = True   # text on the background (base_window.set_theme)
	def __init__(self, *args, **kwargs):
		from modules.kodi_utils import logger_debug as logger   # LOCAL PATCH 2026-10-25 (4.0.5): DialogFlash traces at DEBUG
		logger('DialogFlash SourcesPlayback.__init__', 'new instance')
		BaseDialog.__init__(self, *args)
		self.meta = kwargs.get('meta')
		self.is_canceled, self.skip_resolve, self.resume_choice = False, False, None
		self.meta_get = self.meta.get
		self.addon_fanart = addon_fanart()
		self.enable_scraper()

	def run(self):
		self.doModal()
		self.clearProperties()
		self.clear_modals()

	def onClick(self, controlID):
		self.resume_choice = {10: 'resume', 11: 'start_over', 12: 'cancel'}[controlID]

	def onAction(self, action):
		if action in self.closing_actions: self.is_canceled = True
		elif action == self.right_action and self.window_mode == 'resolver': self.skip_resolve = True

	def iscanceled(self):
		return self.is_canceled

	def skip_resolved(self):
		status = self.skip_resolve
		self.skip_resolve = False
		return status

	def reset_is_cancelled(self):
		self.is_canceled = False

	def enable_scraper(self):
		self.window_mode = 'scraper'
		self.set_scraper_properties()

	def enable_resolver(self):
		from modules.kodi_utils import logger_debug as logger   # LOCAL PATCH 2026-10-25 (4.0.5): DialogFlash traces at DEBUG
		logger('DialogFlash SourcesPlayback.enable_resolver', 'fired')
		self.window_mode = 'resolver'
		self.set_resolver_properties()

	def enable_resume(self, percent):
		self.window_mode = 'resume'
		self.set_resume_properties(percent)

	def busy_spinner(self, toggle='true'):
		self.setProperty('enable_busy_spinner', toggle)

	def _bar_hidden_until_set(self):
		# LOCAL PATCH 2026-09-27: until _set_bar first runs, bar_colour is unset and Kodi draws the 0% fill square in white.
		# Start it transparent. (The colour is a Home copy that outlives the window, so whether THIS window set it is an attribute.)
		if not getattr(self, '_bar_coloured', False): self.set_colour_property('bar_colour', _BAR_HIDDEN)

	def set_scraper_properties(self):
		self._bar_hidden_until_set()
		title, genre = self.meta_get('title'), self.meta_get('genre', '')
		fanart, clearlogo = self.meta_get('fanart') or self.addon_fanart, self.meta_get('clearlogo') or ''
		self.setProperty('window_mode', self.window_mode)
		self.setProperty('fanart', fanart)
		self.setProperty('clearlogo', clearlogo)
		self.setProperty('title', title)
		self.setProperty('genre', ', '.join(genre))
		self.setProperty('episode_line', _episode_line(self.meta))

	def set_resolver_properties(self):
		self._bar_hidden_until_set()
		# LOCAL PATCH 2026-11-08: the box is seven font12 lines (sources_playback.xml, 240 px), ~60 characters each. Kodi cannot
		# end a textbox with '...', so a long plot ran into the source details. Cut at a word: seven lines for a film, five
		# under an episode's title and blank line.
		def _fit(text, chars):
			text = text or ''
			if len(text) <= chars: return text
			return text[:chars - 3].rsplit(' ', 1)[0].rstrip(' ,;:-.') + '...'
		if self.meta_get('media_type') == 'movie': self.text = _fit(self.meta_get('plot'), 390)
		else:
			if avoid_episode_spoilers() and int(self.meta_get('playcount', '0')) == 0: plot = self.meta_get('tvshow_plot') or '* Hidden to Prevent Spoilers *'
			else: plot = self.meta_get('plot', '') or self.meta_get('tvshow_plot', '')
			# LOCAL PATCH 2026-09-29: the episode title as TMDb writes it ('Breaking & Entering'), not upper-cased
			try: _ds, _de = _display_season_episode(self.meta)   # LOCAL PATCH 2026-10-03: anime display numbering
			except Exception: _ds, _de = self.meta_get('season'), self.meta_get('episode')
			self.text = '[B]%02dx%02d - %s[/B][CR][CR]%s' % (_ds, _de, self.meta_get('ep_name', 'N/A'), _fit(plot, 270))
		self.setProperty('window_mode', self.window_mode)
		self.setProperty('text', self.text)

	def set_resume_properties(self, percent):
		self.setProperty('window_mode', self.window_mode)
		self.setProperty('resume_percent', percent)
		self.setFocusId(10)
		self.update_resumer()

	def update_scraper(self, results_sd, results_720p, results_1080p, results_4k, results_total, content='', percent=0,
						providers=None, phase=None, detail=None, time_pct=None, late=False, hidden=None):
		self.setProperty('results_4k', str(results_4k))
		self.setProperty('results_1080p', str(results_1080p))
		self.setProperty('results_720p', str(results_720p))
		self.setProperty('results_sd', str(results_sd))
		self.setProperty('results_total', str(results_total))
		self.setProperty('percent', str(percent))
		# LOCAL PATCH 2026-09-30: `content` (textbox 2001) is no longer shown or written -- the provider rows replaced it. The
		# argument stays so the callers need not change shape.
		if hidden is not None and self.getProperty('hidden_line') != hidden: self.setProperty('hidden_line', hidden)
		# LOCAL PATCH 2026-09-27: loading window redesign -- phase heading, one smooth bar + time line, provider rows
		if phase is not None: self.set_phase(phase, detail)
		self._set_bar(percent, time_pct, late)
		if providers is not None: self._set_providers(providers)

	def update_resolver(self, text='', percent=0, detail=None):
		try:
			if percent != getattr(self, '_resolver_percent', None): self.setProperty('percent', str(percent)); self._resolver_percent = percent
		except: pass
		if detail is not None: self.set_phase('Resolving', detail)
		self._set_bar(percent, None, False, ease=False)
		if text: self.set_text(2002, text)

	# LOCAL PATCH 2026-09-27: the pieces of the loading window. Every one swallows its own errors: the scrape loops that call
	# update_scraper treat an exception as fatal (sources.scrapers_dialog kills the window).
	_BAR_BLUE, _BAR_AMBER, _TIME_GREY = 'FF4F7CC1', 'FFE0AA46', 'FF787C84'

	def set_phase(self, phase, detail=None):
		try:
			self.setProperty('phase', phase or '')
			self.setProperty('phase_detail', detail or '')
		except: pass

	def set_notice(self, text):
		# LOCAL PATCH 2026-09-30: an amber line under the heading, e.g. 'In cinemas  ·  digital release 6 Oct  ·  ...'
		try: self.setProperty('notice', text or '')
		except: pass

	def set_smartplay(self, text):
		try: self.setProperty('smartplay', text or '')
		except: pass

	def _set_bar(self, percent, time_pct=None, late=False, ease=True):
		try:
			target = max(0.0, min(100.0, float(percent or 0)))
			shown = getattr(self, '_bar_shown', 0.0)
			# glide toward the target (~0.3 s at the 50 ms poll); jump when it falls (a new phase starts over)
			shown = target if (not ease or target < shown) else shown + (target - shown) * 0.35
			if abs(target - shown) < 0.5: shown = target
			self._bar_shown = shown
			# LOCAL PATCH 2026-11-08: only a value that changed is written -- each write takes the GUI lock (a Home colour builds a new
			# Window(10000) too), and the 50 ms polls wrote them every tick.
			last = self.__dict__.setdefault('_bar_last', {})
			def _put(key, value, write):
				if last.get(key) != value: write(value); last[key] = value
			_put('bar', round(shown, 1), self.getControl(3001).setPercent)
			# Kodi still draws a small square of the fill at 0% -- keep it invisible until something is done
			self._bar_coloured = True
			_put('bar_colour', _BAR_HIDDEN if shown < 1 else (self._BAR_AMBER if late else self._BAR_BLUE), lambda v: self.set_colour_property('bar_colour', v))
			if time_pct is None: _put('show_timeline', 'false', lambda v: self.setProperty('show_timeline', v))
			else:
				_put('time', round(max(0.0, min(100.0, float(time_pct))), 1), self.getControl(3002).setPercent)
				_put('time_colour', self._BAR_AMBER if late else self._TIME_GREY, lambda v: self.set_colour_property('time_colour', v))
				_put('show_timeline', 'true', lambda v: self.setProperty('show_timeline', v))
		except: pass

	def _set_providers(self, rows):
		"""rows: [(key, label, state, count)]; state in running / checking / done / none / timeout / failed. Items are
		kept and only their properties change, so the 50 ms poll does not rebuild the list."""
		try:
			import xbmcgui
			# LOCAL PATCH 2026-09-30: 'checking' is a debrid row in the cache-check phase -- 'running' everywhere below and in the
			# skin (its spinner); only the label differs
			checking = set(r[0] for r in rows if r[2] == 'checking')
			if checking: rows = [(r[0], r[1], 'running' if r[0] in checking else r[2], r[3]) for r in rows]
			# one row goes to the centred single list (2004); the two-column panel (2003) cannot centre it
			# LOCAL PATCH 2026-09-28: the two-column panel holds 10 rows (2 x 5); over 10 use the three-column panel 2005 (15).
			# Rows sort found / searching / timed out / none / down, keeping their own order inside a group, so anything still cut
			# found nothing. The list is rebuilt only when that order changes.
			layout = 'single' if len(rows) == 1 else ('grid' if len(rows) <= 10 else 'grid3')
			control = self.getControl({'single': 2004, 'grid': 2003, 'grid3': 2005}[layout])
			# LOCAL PATCH 2026-09-29: the order is FROZEN while any provider is still searching (re-sorting moved rows under the
			# eye); once the last one answers it sorts once and stays through the cache-check phase.
			def _n(count):
				try: return int(count)
				except: return 0
			if any(r[2] == 'running' for r in rows):
				frozen = getattr(self, '_provider_order', None)
				if frozen and set(frozen) == set(r[0] for r in rows):
					pos = dict((k, i) for i, k in enumerate(frozen))
					rows = sorted(rows, key=lambda r: pos[r[0]])
			else:
				# LOCAL PATCH 2026-09-29: found rows most results first, so the count bars read as a descending chart
				rank = {'done': 0, 'running': 1, 'timeout': 2, 'none': 3, 'failed': 4}
				rows = [r for _, r in sorted(enumerate(rows), key=lambda p: (rank.get(p[1][2], 3),
					-_n(p[1][3]) if p[1][2] == 'done' else 0, p[0]))]
			# LOCAL PATCH 2026-09-29: count bar, each provider's results against the best one's, in 5 % steps
			# (skins/Default/media/deadlight_common/bar/bar_005..100.png, stretched to the row). No bar for one row.
			best = max([_n(r[3]) for r in rows if r[2] == 'done'] or [0]) if len(rows) > 1 else 0
			items = getattr(self, '_provider_items', None)
			keys = [r[0] for r in rows]
			if (items is None or layout != getattr(self, '_provider_layout', None) or any(k not in keys for k in items)
					or keys != getattr(self, '_provider_order', None)):
				control.reset()   # first call, a new phase's set, or the other list
				items = self._provider_items = {}
				self._provider_layout = layout
				self._provider_order = keys
				self.setProperty('provider_layout', layout)
			for key, label, state, count in rows:
				item = items.get(key)
				if item is None:
					# three columns leave 180 px for the name (~11 capitals at font10 bold); the two long ones get short forms there.
					if layout == 'grid3': label = {'http_streams': 'Direct', 'torrentdownload': 'TorrentDL', 'torrentdownloads': 'TD.pro', 'torrentscsv': 'TorrentsCSV',
						'tb_cloud': 'TB Cloud', 'folders': 'Folders'}.get(key, label)
					# LOCAL PATCH 2026-09-30: shown in capitals; the names stay mixed case in source_utils.provider_panel_name, which the
					# resolve heading also reads
					item = items[key] = xbmcgui.ListItem(label.upper())
					control.addItem(item)
				# LOCAL PATCH 2026-10-24: a bullet, not a check mark -- AF3's other fonts have no U+2713 (Kodi drew a box); every font
				# has U+2022
				if state == 'done':
					text = '[COLOR FF7FA7DB][B]•[/B][/COLOR]  [B]%s[/B]' % count if count else '[COLOR FF7FA7DB][B]•[/B][/COLOR]'
				elif state == 'running': text = '[COLOR FFA8A8A8]%s[/COLOR]' % ('checking' if key in checking else 'searching')
				elif state == 'timeout': text = '[COLOR FFE0AA46]timed out[/COLOR]'
				# LOCAL PATCH 2026-09-27: switched on but did not answer (external._scrape) -- not the same as 'none'
				elif state == 'failed': text = '[COLOR FFE06C6C]down[/COLOR]'
				else: text = '[COLOR FF6E6E6E]none[/COLOR]'
				if item.getProperty('state_label') != text:
					item.setProperty('state', state)
					item.setProperty('state_label', text)
				n = _n(count) if state == 'done' else 0
				bar = 'deadlight_common/bar/bar_%03d.png' % max(5, int(round(20.0 * n / best)) * 5) if best and n else ''
				if item.getProperty('bar') != bar: item.setProperty('bar', bar)
		except: pass

	def update_resumer(self):
		from modules.kodi_utils import kodi_player
		player = kodi_player()
		initial_playing = player.isPlayingVideo()
		count = 0
		while self.resume_choice is None:
			if self.is_canceled:
				self.resume_choice = 'cancel'
				break
			if initial_playing and not player.isPlayingVideo():
				self.resume_choice = 'cancel'
				break
			percent = int((float(count)/10000)*100)
			if percent >= 100: self.resume_choice = 'resume'
			self.setProperty('percent', str(percent))
			self._set_bar(percent, None, False, ease=False)   # LOCAL PATCH 2026-09-27: the squares are gone
			count += 100
			self.sleep(100)

class SourcesInfo(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.item = kwargs['item']
		self.item_get_property = self.item.getProperty
		self.play = False
		self.set_properties()

	def run(self):
		self.doModal()
		self.clearProperties()   # LOCAL PATCH 2026-10-24: re-sets the theme colours for the close fade (base_window)
		return self.play   # LOCAL PATCH 2026-11-08: True: SourcesResults plays this row (play_listitem)

	def onClick(self, controlID):
		if controlID == 10:
			self.play = True
			self.close()

	def onAction(self, action):
		# LOCAL PATCH 2026-11-08: the panel has a Play button, so only Back / Info close it
		if action in self.closing_actions or action == self.info_action: self.close()

	def set_properties(self):
		self.setProperty('name', self.item_get_property('name'))
		self.setProperty('source_type', self.item_get_property('source_type'))
		self.setProperty('source_site', self.item_get_property('source_site'))
		self.setProperty('size_label', self.item_get_property('size_label'))
		self.setProperty('extraInfo', self.item_get_property('extraInfo'))
		self.setProperty('hash', self.item_get_property('hash'))
		# LOCAL PATCH 2026-11-08: shown as words
		self.setProperty('provider', self.item_get_property('provider'))
		self.setProperty('quality', self.item_get_property('quality').upper())
		# the type carries Kodi tags ('[B]CACHED[/B] [B]PACK[/B]'); lower-casing them would print '[b]' as text
		self.setProperty('source_type', re.sub(r'\[/?[A-Za-z]+\]', '', self.item_get_property('source_type') or '').strip().capitalize())
