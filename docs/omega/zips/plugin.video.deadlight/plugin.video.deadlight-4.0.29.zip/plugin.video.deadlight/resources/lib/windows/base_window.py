# -*- coding: utf-8 -*-
import xbmcgui
import re
import json
from threading import Thread
from modules import kodi_utils, settings
from caches.settings_cache import get_setting, restore_setting_default
from modules.utils import manual_function_import

# LOCAL PATCH 2026-09-26: minidom is only needed by the font/skin-folder scans below, which run
# on a skin or font change -- not on every window open. Imported on first call.
def mdParse(source):
	from xml.dom.minidom import parse
	return parse(source)

def open_window(import_info, skin_xml, **kwargs):
	'''
	import_info: ('module', 'function')
	'''
	try:
		from modules.busy_guard import paused   # LOCAL PATCH 2026-11-01: a context action's spinner steps aside for the window
		xml_window = create_window(import_info, skin_xml, **kwargs)
		with paused(): choice = xml_window.run()
		del xml_window
		return choice
	except Exception as e:
		kodi_utils.logger('error in open_window', str(e))

def create_window(import_info, skin_xml, **kwargs):
	'''
	import_info: ('module', 'function')
	'''
	try:
		# LOCAL PATCH 2026-10-22: the windows' rounded textures live in media/deadlight_live/, built for Window Corners
		from modules.corner_style import ensure as ensure_corners
		ensure_corners()
		function = manual_function_import(*import_info)
		args = (skin_xml, kodi_utils.addon_path())
		xml_window = function(*args, **kwargs)
		return xml_window
	except Exception as e:
		kodi_utils.logger('error in create_window', str(e))
		return kodi_utils.notification('Error')

# LOCAL PATCH 2026-10-19: shared by window_manager and window_player (both runners call close()).
def _close_windows(obj):
	obj.close()
	kodi_utils.clear_property('deadlight.window_loaded')
	kodi_utils.clear_property('deadlight.window_stack')

# LOCAL PATCH 2026-11-01 (cleanup): shared by window_manager and window_player
def _monitor(obj):
	timer = 0
	while not kodi_utils.get_property('deadlight.window_loaded') == 'true' and timer <= 5:
		kodi_utils.sleep(50)
		timer += 0.05
	kodi_utils.hide_busy_dialog()
	obj.close()
	kodi_utils.clear_property('deadlight.window_loaded')

def _run(obj, params, any_mode_is_person=False):
	"""window_manager closes on a mode it does not know; window_player opens the person dialog for any other mode."""
	try:
		mode = params['mode']
		if mode == 'extras_menu_choice':
			from indexers.dialogs import extras_menu_choice
			extras_menu_choice(params)
		elif any_mode_is_person or mode == 'person_data_dialog':
			from indexers.people import person_data_dialog
			person_data_dialog(params)
		else: _close_windows(obj)
	except: _close_windows(obj)

def window_manager(obj):
	def close(): _close_windows(obj)

	def get_stack():
		try: window_stack = json.loads(kodi_utils.get_property('deadlight.window_stack'))
		except: window_stack = []
		return window_stack

	def add_to_stack(params):
		window_stack.append(params)
		kodi_utils.set_property('deadlight.window_stack', json.dumps(window_stack))

	def remove_from_stack():
		previous_params = window_stack.pop()
		kodi_utils.set_property('deadlight.window_stack', json.dumps(window_stack))
		return previous_params
	kodi_utils.show_busy_dialog()
	try:
		kodi_utils.clear_property('deadlight.window_loaded')
		current_params = obj.current_params
		new_params = obj.new_params
		window_stack = get_stack()
		if current_params: add_to_stack(current_params)
		if new_params:
			Thread(target=_monitor, args=(obj,)).start()
			_run(obj, new_params)
		elif window_stack:
			previous_params = remove_from_stack()
			if previous_params:
				Thread(target=_monitor, args=(obj,)).start()
				_run(obj, previous_params)
		else: close()
	except: close()
	kodi_utils.hide_busy_dialog()

def window_player(obj):
	try:
		window_player_url = obj.window_player_url
		if 'plugin.video.youtube' in window_player_url:
			if not kodi_utils.addon_installed('plugin.video.youtube') or not kodi_utils.addon_enabled('plugin.video.youtube'):
				return kodi_utils.notification('Youtube Plugin needed for playback')
		kodi_utils.clear_property('deadlight.window_loaded')
		current_params = obj.current_params
		player = kodi_utils.kodi_player()
		player.play(window_player_url)
		kodi_utils.sleep(2000)
		# capped: a trailer the YouTube addon cannot resolve never starts, and this spun until Kodi quit
		waited = 0
		while not player.isPlayingVideo() and waited < 30000:
			kodi_utils.sleep(100)
			waited += 100
		if not player.isPlayingVideo(): return kodi_utils.hide_busy_dialog()
		obj.close()
		while player.isPlayingVideo(): kodi_utils.sleep(100)
		kodi_utils.show_busy_dialog()
		kodi_utils.sleep(1000)
		Thread(target=_monitor, args=(obj,)).start()
		_run(obj, current_params, any_mode_is_person=True)
	except: obj.close()
	kodi_utils.hide_busy_dialog()

# LOCAL PATCH 2026-10-24: Kodi resolves a colour's $INFO (colordiffuse, textcolor, focusedcolor) against the ACTIVE window,
# not the window the control is in -- visibility conditions and image paths use the control's own window. So when one of
# Kodi's dialogs opens over a DeadLight window (number pad, keyboard, context menu), every Window.Property colour reads
# that dialog's empty property and draws white. The colours are therefore read from Home copies, deadlight.win.<name>,
# which hold the top DeadLight window's values;
# when it closes, the one under it publishes its own again (BaseDialog.clearProperties).
_THEME_STACK = []
_THEME_COLOURS = ('deadlight.background', 'deadlight.panel', 'deadlight.focus', 'deadlight.focus_text', 'deadlight.focus_text2',
				  'deadlight.focus_icon', 'deadlight.focus_fill', 'deadlight.accent', 'deadlight.accent_soft')

def _publish_theme_colours(properties):
	for k, v in properties:
		# LOCAL PATCH 2026-11-15: a dialog has no background of its own (the XML's dim shows). Publishing its empty colour
		# turned the full-screen window UNDER it (Watch Order, People, sources, viewers) white behind the dim -- that window's
		# background layer stays visible by its own window property and drew white.png uncoloured.
		if k == 'deadlight.background' and not v: continue
		if k in _THEME_COLOURS: kodi_utils.set_property(k.replace('deadlight.', 'deadlight.win.', 1), v)

class BaseDialog(xbmcgui.WindowXMLDialog):
	def __init__(self, *args):
		xbmcgui.WindowXMLDialog.__init__(self, args)
		self.args = args
		self.player = kodi_utils.kodi_player()
		self.left_action = 1
		self.right_action = 2
		self.up_action = 3
		self.down_action = 4
		self.info_action = 11
		self.selection_actions = (7, 100)
		self.closing_actions = (9, 10, 13, 92)
		self.context_actions = (101, 108, 117)
		self.set_theme()

	# LOCAL PATCH 2026-10-23, reworked 2026-11-13 (no blur), 2026-11-15 (no glass layer at all): the window's colours.
	#   deadlight.background   window property: the plain background colour of a full-screen window (text on the background:
	#                          scraping screen, People, Watch Order, viewers); empty in dialogs (their XML dims with black at
	#                          50 percent, AF3's shadow_back) and over video (no background of their own). The XML shows the
	#                          layer by this property and colours it from the Home copy.
	#   deadlight.panel        the theme colour at the Window theme opacity setting's level
	#   deadlight.focus*       the focused plate and what sits on it
	full_screen_background = False   # True on the windows with text on the background

	def set_theme(self):
		theme = kodi_utils.get_property('deadlight.window_theme') or 'CC1F2020'
		background = ''
		over_video = kodi_utils.get_visibility('Window.IsVisible(fullscreenvideo) | Window.IsVisible(visualisation) | Window.IsVisible(slideshow)')
		if self.full_screen_background and not over_video:
			try: rgb_theme = tuple(int(theme[-6:][i:i + 2], 16) for i in (0, 2, 4))
			except ValueError: rgb_theme = (0x1F, 0x20, 0x20)
			k = 0.8 * int(theme[:2], 16) / 255.0 if len(theme) == 8 else 0.8
			background = 'FF%02X%02X%02X' % tuple(int(round(c * k)) for c in rgb_theme)
		self.theme_panel = theme
		# LOCAL PATCH 2026-11-12: DeadLight's own solid focus and accent marks, whatever the skin: no reads of the skin's
		# highlight colour (Skin.String(focuscolor.name) / RevertSelectedText) -- user's call, AF3 and DeadLight
		# independent. Focus = plate, text, text2, icon, fill; accent_soft = the accent at 18 percent (chip plates).
		# Accent and plate follow DeadLight's Window Theme (kodi_utils.addon_themes); fill (the countdown over a focused
		# button) is the plate at 78 percent, as B4B5BA was to E8E8EA.
		accent, plate = kodi_utils.theme_colours(theme)
		fill = ''.join('%02X' % int(round(int(plate[i:i + 2], 16) * 0.78)) for i in (0, 2, 4))
		focus = ('FF' + plate, 'FF141517', 'FF4a4347', 'FF1F2020', 'FF' + fill)
		self.theme_properties = (('deadlight.background', background), ('deadlight.panel', theme), ('deadlight.accent', 'FF' + accent),
			('deadlight.accent_soft', '2E' + accent)) + tuple(zip(('deadlight.focus', 'deadlight.focus_text', 'deadlight.focus_text2', 'deadlight.focus_icon', 'deadlight.focus_fill'), focus))
		self._set_window_background()
		_THEME_STACK.append(self)
		_publish_theme_colours(self.theme_properties)

	# Every window clears its properties as soon as doModal() returns, while Kodi is still drawing its close fade: without
	# this the background vanished for those frames. It stays.
	def clearProperties(self):
		xbmcgui.WindowXMLDialog.clearProperties(self)
		self._set_window_background()
		# the window under this one gets its own colours back (Home copies, see _publish_theme_colours)
		if self in _THEME_STACK: _THEME_STACK.remove(self)
		if _THEME_STACK: _publish_theme_colours(_THEME_STACK[-1].theme_properties)

	def _set_window_background(self):
		self.setProperty('deadlight.background', self.theme_properties[0][1])

	def set_colour_property(self, name, value):
		"""A colour the window's XML reads: as a Home copy, deadlight.win.<name> (see _publish_theme_colours: a colour's
		$INFO follows the active window, so a window property went white under Kodi's dialogs)."""
		kodi_utils.set_property('deadlight.win.%s' % name, value)

	def get_setting(self, setting_id, setting_default=''):
		return get_setting(setting_id, setting_default)

	def restore_setting_default(self, params):
		restore_setting_default(params)

	def make_listitem(self):
		return kodi_utils.make_listitem()

	def build_url(self, params):
		return kodi_utils.build_url(params)

	def execute_code(self, command, block=False):
		return kodi_utils.execute_builtin(command, block)
	
	def get_position(self, window_id):
		return self.get_control(window_id).getSelectedPosition()

	def get_listitem(self, window_id):
		return self.get_control(window_id).getSelectedItem()

	def add_items(self, _control, _items):
		self.get_control(_control).addItems(_items)

	def select_item(self, _control, _item):
		self.get_control(_control).selectItem(_item)

	def set_image(self, _control, _image):
		self.get_control(_control).setImage(_image)

	def set_label(self, _control, _label):
		self.get_control(_control).setLabel(_label)

	def set_text(self, _control, _text):
		self.get_control(_control).setText(_text)

	def set_percent(self, _control, _percent):
		self.get_control(_control).setPercent(_percent)

	def reset_window(self, _control):
		self.get_control(_control).reset()

	def get_control(self, control_id):
		return self.getControl(control_id)


	def get_infolabel(self, label):
		return kodi_utils.get_infolabel(label)

	def get_visibility(self, command):
		return kodi_utils.get_visibility(command)
	
	def open_window(self, import_info, skin_xml, **kwargs):
		return open_window(import_info, skin_xml, **kwargs)

	# LOCAL PATCH 2026-11-08: the info panel shown while a poster row has focus (Extras, People) has two lines of the focused
	# title's plot in font12 across 1180 px: about 75-85 characters a line, so 150 keeps the '...' on line two. Kodi cannot end
	# a label with an ellipsis, so the text is cut here, at a word.
	PANEL_PLOT_CHARS = 150

	@staticmethod
	def fit_text(text, limit):
		text = ' '.join((text or '').split())
		if len(text) <= limit: return text
		return text[:limit - 3].rsplit(' ', 1)[0].rstrip(' ,;:-.') + '...'

	@classmethod
	def panel_plot(cls, text):
		return cls.fit_text(text, cls.PANEL_PLOT_CHARS)

	def track_buttons(self, buttons):
		"""LOCAL PATCH 2026-11-07: dialog buttons read their colours from Home copies deadlight.win.dlg<id>.bg / .fg (gen_dialogs.py,
		restyle_small.py). One colour only (user: a yellow 'last used' button next to the white focused one was confusing): every
		button the same grey, the focused one white (its focus texture)."""
		self._lb_buttons, self._lb_focus, self._lb_last = tuple(buttons), None, None
		self._paint_buttons()

	_lb_follow_focus = False   # True brings back the yellow 'last used' button (onFocus)

	def _paint_buttons(self):
		accent = kodi_utils.get_property('deadlight.win.focus') or 'FFE8E8EA'   # the focus plate (base_window's focus tuple)
		accent_text = kodi_utils.get_property('deadlight.win.focus_text') or 'FF141517'
		idle = kodi_utils.get_property('deadlight.window_theme_contrast') or 'FF4a4347'   # the setting's own default
		for b in self._lb_buttons:
			last = b == self._lb_last
			self.set_colour_property('dlg%d.bg' % b, accent if last else idle)
			self.set_colour_property('dlg%d.fg' % b, accent_text if last else 'FFE8E8EA')

	def onFocus(self, controlId):
		buttons = getattr(self, '_lb_buttons', None)
		if not buttons or not self._lb_follow_focus: return
		previous = self._lb_focus
		if previous in buttons and previous != controlId and self._lb_last != previous:
			self._lb_last = previous
			self._paint_buttons()
		self._lb_focus = controlId

	def start_with_tasks(self):
		"""The onInit of Extras and People: mark the window loaded, start its background tasks, focus (or return to the saved spot)."""
		self.set_home_property('window_loaded', 'true')
		for i in self.tasks: Thread(target=i).start()
		self.set_default_focus()
		if self.starting_position:
			try: self.set_returning_focus(*self.starting_position)
			except: self.set_default_focus()

	def ensure_focus(self, control_id, tries=10):
		"""LOCAL PATCH 2026-11-07: a window opened while the busy spinner is up loses its focus when the spinner closes (the
		select after Download Pack, Watch Order: Kodi log 'Control ... has been asked to focus, but it can't', the first key
		presses went nowhere). Focus again until it holds."""
		for _ in range(tries):
			self.sleep(100)
			if self.getFocusId() == control_id: return True
			try: self.setFocusId(control_id)
			except Exception: pass
		return False

	def sleep(self, time):
		kodi_utils.sleep(time)

	def get_release_year(self, release_data):
		# the year of a 'YYYY-MM-DD' date, 'N/A' when there is none (Extras and People both list titles by year)
		try:
			if release_data in ('', None): release_data = 'N/A'
			else: release_data = release_data.split('-')[0]
		except: pass
		return release_data

	def set_home_property(self, prop, value):
		kodi_utils.set_property('deadlight.%s' % prop, value)

	def get_home_property(self, prop):
		return kodi_utils.get_property('deadlight.%s' % prop)

	def clear_home_property(self, prop):
		return kodi_utils.clear_property('deadlight.%s' % prop)

	def clear_modals(self):
		try: del self.player
		except: pass

	def notification(self, text, duration=3000):
		return kodi_utils.notification(text, duration)

class FontUtils:
	def execute_custom_fonts(self, skin_files=[]):
		if not skin_files and not self.skin_change_check(): return
		replacement_values, skin_font_xml = [], ''
		replacement_values_append = replacement_values.append
		skin_folder = self.get_skin_folder()
		if skin_folder: skin_font_xml = kodi_utils.translate_path('special://skin/%s/Font.xml' % skin_folder)
		if skin_font_xml: self.skin_font_info = self.get_font_info(skin_font_xml) or self.default_font_info()
		else: self.skin_font_info = self.default_font_info()
		for item in ((21, False, 'font10'), (26, False, 'font12'), (30, False, 'font13'), (33, False, 'font14'), (38, False, 'font16'), (60, True, 'font60')):
			replacement_values_append(self.match_font(*item))
		if not skin_files:
			kodi_utils.set_property('deadlight.current_skin', self.current_skin)
			kodi_utils.set_property('deadlight.current_font', self.current_font)
		skin_files = skin_files or kodi_utils.list_dirs(kodi_utils.translate_path('special://home/addons/plugin.video.deadlight/resources/skins/Default/1080i/'))[1]
		for item in skin_files: self.replace_font(item, replacement_values)

	def get_skin_folder(self):
		folder_options = ('xml', '1080', '720', '1080p', '720p', '1080i', '720i', '16x9')
		skin_folder = None
		try:
			skin_folder = mdParse(kodi_utils.translate_path('special://skin/addon.xml')).getElementsByTagName('extension')[0].getElementsByTagName('res')[0].getAttribute('folder')
			if not skin_folder:
				s_folder = kodi_utils.list_dirs(kodi_utils.translate_path('special://skin'))[0]
				skin_folder = [i for i in s_folder if i in folder_options][0]
		except: pass
		return skin_folder

	def skin_change_check(self):
		self.current_skin, self.current_font = kodi_utils.current_skin(), kodi_utils.jsonrpc_get_system_setting('lookandfeel.font', 'Default')
		if self.current_skin != kodi_utils.get_property('deadlight.current_skin') or self.current_font != kodi_utils.get_property('deadlight.current_font'): return True
		return False

	def match_font(self, size, bold, fallback):
		font_tag = 'DEADLIGHT_%s%s' % (size, '_BOLD' if bold else '')
		size_range = range(int(size * 0.75), int(size * 1.25))
		compatibility_range = range(int(size * 0.50), int(size * 1.50))
		compatibility_fonts = [i['name'] for i in self.skin_font_info if i['name'] == fallback and i['size'] in compatibility_range]
		if compatibility_fonts: return (font_tag, compatibility_fonts[0])
		sized_fonts = [i for i in self.skin_font_info if i['size'] in size_range]
		if not sized_fonts: return fallback
		fonts = [i for i in sized_fonts if i['bold'] == bold and not i['extra_styles']] or [i for i in sized_fonts if i['bold'] == bold] \
				or [i for i in sized_fonts if not i['extra_styles']] or sized_fonts
		return (font_tag, [i['name'] for i in fonts if i['size'] == min([i['size'] for i in fonts], key=lambda k: abs(k-size))][0])

	def get_font_info(self, skin_font_xml):
		extras_keys = ('upper', 'uppercase', 'italic', 'capitalize', 'black', 'mono', 'symbol')
		results = []
		if not skin_font_xml: return results
		results_append = results.append
		try:
			all_fonts = mdParse(skin_font_xml).getElementsByTagName('fontset')
			try: fontset = [i for i in all_fonts if i.getAttribute('id').lower() == self.current_font.lower()][0]
			except: fontset = all_fonts[0]
			font_element = fontset.getElementsByTagName('font')
			for item in font_element:
				try: name = item.getElementsByTagName('name')[0].firstChild.data
				except: continue
				try: size = int(item.getElementsByTagName('size')[0].firstChild.data)
				except: continue
				try: style = item.getElementsByTagName('style')[0].firstChild.data.lower()
				except: style = ''
				name_compare = name.lower()
				bold = any('bold' in item for item in (name_compare, style))
				extra_styles = any(item in style for item in extras_keys)
				if not extra_styles: extra_styles = any(item in name_compare for item in extras_keys)
				results_append({'name': name, 'size': size, 'bold': bold, 'extra_styles': extra_styles})
		except: pass
		return results

	def replace_font(self, window, replacement_values):
		file = kodi_utils.translate_path('special://home/addons/plugin.video.deadlight/resources/skins/Default/1080i/' + window)
		with kodi_utils.open_file(file) as f: content = f.read()
		original = content
		for item in replacement_values:
			try: content = re.sub(r'<font>(.*?)</font> <\!-- %s -->' % item[0], '<font>%s</font> <!-- %s -->' % (item[1], item[0]), content)
			except: pass
		# LOCAL PATCH 2026-10-02: write only a changed file -- the service clears deadlight.current_skin, so every boot
		# looks like a skin change.
		if content == original: return
		with kodi_utils.open_file(file, 'w') as f: f.write(content)

	def default_font_info(self):
		return [{'name': 'font10', 'size': 21, 'bold': False, 'extra_styles': False},
				{'name': 'font12', 'size': 26, 'bold': False, 'extra_styles': False},
				{'name': 'font13', 'size': 30, 'bold': False, 'extra_styles': False},
				{'name': 'font14', 'size': 33, 'bold': False, 'extra_styles': False},
				{'name': 'font16', 'size': 38, 'bold': False, 'extra_styles': False},
				{'name': 'font45', 'size': 45, 'bold': False, 'extra_styles': False},
				{'name': 'font60', 'size': 60, 'bold': False, 'extra_styles': False}]


# LOCAL PATCH 2026-11-13: the Extras window generator moved to windows/extras_layout.py (Extras as one screen with tabs);
# imported here so `from windows.base_window import ExtrasUtils` (service, the row-order dialog) keeps working.
from windows.extras_layout import ExtrasUtils  # noqa: E402,F401
