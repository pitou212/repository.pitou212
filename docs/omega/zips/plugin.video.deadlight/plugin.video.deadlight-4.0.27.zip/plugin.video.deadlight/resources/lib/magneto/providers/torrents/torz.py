# created by kodifitzwell for Fenomscrapers
"""
	Fenomscrapers Project
"""

from json import loads as jsloads
from magneto.modules import client
from magneto.modules import source_utils
from magneto.modules.control import setting as getSetting
from magneto.modules.provider_base import StremioSource


# LOCAL PATCH 2026-11-01 (cleanup): the sources / sources_packs bodies are provider_base.StremioSource's; this file keeps what
# is torz's own -- the StremThru addresses, its JSON rows ({'hash', 'name', 'seeders', 'size'}), sizes that are the pack's
# (no true_size), and a title check that reads the name as it is.
class source(StremioSource):
	provider = 'torz'
	pack_true_size = False
	archie = False
	movieSearch_link = '/v0/torrents?sid=%s'
	tvSearch_link = '/v0/torrents?sid=%s:%s:%s'

	def __init__(self):
		self.base_link = (
			"https://stremthru.stremio.ru",
			"https://stremthru.13377001.xyz",
			"https://stremthrufortheweebs.midnightignite.me"
		)[int(getSetting('torz.url', '0'))]

	def _fetch(self, url, data, q):
		return jsloads(client.request(url, timeout=self.timeout))['data']['items']

	# LOCAL PATCH 2026-10-21 (from POV 6.10.17): packs are cleaned as sources() does (the shared body cleans every name) --
	# they went to the season-pack filter with their site prefixes and 【】 tags still on, and were shown that way
	def _parse(self, file):
		return file['hash'], [file['name']], file

	def _seeders(self, file):
		return file['seeders']

	def _size(self, file):
		return source_utils.convert_size(float(file['size']))
