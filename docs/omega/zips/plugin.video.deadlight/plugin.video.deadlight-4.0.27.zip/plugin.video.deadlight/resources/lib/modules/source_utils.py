# -*- coding: utf-8 -*-
import re
import json
import base64
import time
from threading import Thread
from functools import lru_cache
from urllib.parse import unquote, unquote_plus
from caches.settings_cache import get_setting
from modules.metadata import episodes_meta, series_absolute_episode, is_anime_check
from modules.settings import date_offset

# LOCAL PATCH 2026-11-08: patterns compile on first use -- every play is a fresh interpreter and uses only a few. The
# stand-in compiles when first touched and replaces itself in this module's globals, so later reads are direct.
class _LazyRe:
	__slots__ = ('_name', '_args', '_compiled')
	def __init__(self, name, *args):
		self._name, self._args, self._compiled = name, args, None
	def __getattr__(self, attr):
		p = self._compiled
		if p is None:
			p = self._compiled = re.compile(*self._args)
			if globals().get(self._name) is self: globals()[self._name] = p
		return getattr(p, attr)
from modules.kodi_utils import supported_media, set_property, notification, make_session
from modules.utils import adjust_premiered_date, get_datetime, jsondate_to_datetime, subtract_dates, chunks

# LOCAL PATCH 2026-10-04: the only providers that may run on anime (external._is_not_for_anime_skipped,
# dialogs.anime_providers_choice). The first four are anime-only; torrentio and comet ask by Kitsu id when Fribb gives one.
# LOCAL PATCH 2026-10-27: + meteor, which asks by AniList id (its Kitsu map lags new entries), else IMDb season:episode.
# LOCAL PATCH 2026-11-07: + mediafusion, which has no anime id and asks by IMDb in Cinemeta's numbering (external.stremio_se).
ANIME_ONLY_PROVIDERS = ('animetosho', 'seadex', 'nekobt', 'nyaa')
ANIME_PROVIDERS = ANIME_ONLY_PROVIDERS + ('torrentio', 'comet', 'meteor', 'mediafusion')
# LOCAL PATCH 2026-10-05: anime and Movies & TV are separate provider lists. On anime only the scrape.anime_providers ticks
# decide (magneto.provider.<id> is the Movies & TV switch); off anime the anime-only four never run.
# LOCAL PATCH 2026-10-31: 'Scrape with ALL' on anime skips nothing, Nyaa included -- it is the last resort and its
# 75-row RSS cap beats no sources.
ANIME_ALL_SKIPPED = ()

def anime_provider_list():
	"""The ticked anime providers, in ANIME_PROVIDERS order; a name outside ANIME_PROVIDERS is ignored."""
	ticked = {i.strip().lower() for i in (get_setting('deadlight.scrape.anime_providers', 'animetosho,seadex,nyaa,nekobt') or '').split(',')}
	return [i for i in ANIME_PROVIDERS if i in ticked]

def anime_providers_to_run(all_scrapers=False):
	if all_scrapers: return [i for i in ANIME_PROVIDERS if i not in ANIME_ALL_SKIPPED]
	return anime_provider_list()

# LOCAL PATCH 2026-07-10 (port of POV debrid session-pooling): pooled session for the cache-check hot path, which hits
# the same few hosts every scrape; bare requests paid a TCP + TLS handshake per call.
_debrid_cache_session = make_session('https://', headers={'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json'})

_CACHE_PAGE_MEMO = {}   # LOCAL PATCH 2026-10-11: Torrentio / MediaFusion cached-hash pages, {url: (time, hashes)}

# LOCAL PATCH 2026-10-25 (4.0.5): DMM removed -- its availability check went sponsor-only (403 on every call). RD cache
# status comes from Torrentio's [RD+] page, StremThru's hash-list check and MediaFusion's cached page.

# LOCAL PATCH 2026-10-03: what a pack row's size is divided by. Never divided: providers whose size is already
# per-episode, and rows marked true_size (meteor, torrentsdb, comet report the EPISODE FILE's size inside a pack).
PER_EPISODE_PROVIDERS = ('torrentio', 'knightcrawler', 'selfhosted', 'animetosho', 'seadex', 'nekobt')

def pack_size_divider(item, provider, season_divider, show_divider, season_counts=None, season_length=None, total_seasons=None):
	"""Episodes to divide a pack row's size by, or None when its size is already per-episode. In order: the pack's own
	count ('pack_episodes': a name range, a partial pack's episode_start-end, an anime release season's length); for a
	season pack the release season's length (anime, from Fribb) else TMDb's season count; for a show pack the episodes of
	the seasons it holds (first_season..last_season) when that is fewer than the whole show, else every aired episode."""
	if 'package' not in item: return None
	if item.get('true_size') or provider in PER_EPISODE_PROVIDERS: return None
	try:
		n = int(item.get('pack_episodes') or 0)
		if n > 0: return n
	except (TypeError, ValueError): pass
	if item.get('package') == 'season':
		try:
			if season_length and int(season_length) > 0: return int(season_length)
		except (TypeError, ValueError): pass
		return season_divider or 1
	try:
		first, last = int(item.get('first_season') or 1), int(item.get('last_season') or 0)
		if season_counts and last and (not total_seasons or last < int(total_seasons) or first > 1):
			held = sum(c for s, c in season_counts.items() if first <= s <= last)
			if held > 0: return held
	except (TypeError, ValueError): pass
	return show_divider or 1

# LOCAL PATCH 2026-10-15: `title` leaves out words the requested title contains -- callers substring-test the whole
# release name, so 'Inside Out' or 'Trailer Park Boys' lost every row.
# LOCAL PATCH 2026-11-07 (Red Light 3.0.1 port): likewise the episode title, `ep_name` ('Show.S02E05.Inside.Job.mkv').
def _title_guard(title=None, ep_name=None):
	"""The lowercased text (plain and dotted) whose words are never evidence of an extra."""
	text = ' '.join(str(t) for t in (title, ep_name) if t).lower()
	return '%s %s' % (text, re.sub(r'[\s:_-]+', '.', text)) if text else ''

def extras(title=None, ep_name=None):
	words = ('sample', 'extra', 'extras', 'deleted', 'unused', 'footage', 'inside', 'blooper', 'bloopers',
			'making.of', 'feature', 'featurette', 'behind.the.scenes', 'trailer')
	guard = _title_guard(title, ep_name)
	if not guard: return words
	return tuple(w for w in words if w not in guard)

def unwanted_tags():
	return (
'tamilrockers.com', 'www.tamilrockers.com', 'www.tamilrockers.ws', 'www.tamilrockers.pl', 'www-tamilrockers-cl', 'www.tamilrockers.cl', 'www.tamilrockers.li',
'www.tamilrockerrs.pl', 'www.tamilmv.bid', 'www.tamilmv.biz', 'www.1tamilmv.org', 'gktorrent-bz', 'gktorrent-com', 'www.torrenting.com', 'www.torrenting.org',
'www-torrenting-com', 'www-torrenting-org', 'katmoviehd.pw', 'katmoviehd-pw', 'www.torrent9.nz', 'www-torrent9-uno', 'torrent9-cz', 'torrent9.cz',
'agusiq-torrents-pl', 'oxtorrent-bz', 'oxtorrent-com', 'oxtorrent.com', 'oxtorrent-sh', 'oxtorrent-vc', 'www.movcr.tv', 'movcr-com', 'www.movcr.to', '(imax)',
'imax', 'xtorrenty.org', 'nastoletni.wilkoak', 'www.scenetime.com', 'kst-vn', 'www.movierulz.vc', 'www-movierulz-ht', 'www.2movierulz.ac', 'www.2movierulz.ms',
'www.3movierulz.com', 'www.3movierulz.tv', 'www.3movierulz.ws', 'www.3movierulz.ms', 'www.7movierulz.pw', 'www.8movierulz.ws', 'mkvcinemas.live', 'www.bludv.tv',
'ramin.djawadi', 'extramovies.casa', 'extramovies.wiki', '13+', '18+', 'taht.oyunlar', 'crazy4tv.com', 'karibu', '989pa.com', 'best-torrents-net', '1-3-3-8.com',
'ssrmovies.club', 'va:', 'zgxybbs-fdns-uk', 'www.tamilblasters.mx', 'www.1tamilmv.work', 'www.xbay.me', 'crazy4tv-com', '(es)')

def audio_filter_choices():
	return (
('DOLBY DIGITAL', 'DD'), ('DOLBY DIGITAL PLUS', 'DD+'), ('DOLBY DIGITAL EX', 'DD-EX'), ('DOLBY ATMOS', 'ATMOS'), ('DOLBY TRUEHD', 'TRUEHD'),
('DTS', 'DTS'), ('DTS-HD MASTER AUDIO', 'DTS-HD MA'), ('DTS-X', 'DTS-X'), ('DTS-HD', 'DTS-HD'), ('AAC', 'AAC'), ('OPUS', 'OPUS'), ('MP3', 'MP3'),
('8CH AUDIO', '8CH'), ('7CH AUDIO', '7CH'), ('6CH AUDIO', '6CH'), ('2CH AUDIO', '2CH'))

def source_filters():
	return (
('PACK', 'PACK'), ('DOLBY VISION', '[B]D/VISION[/B]'), ('HIGH DYNAMIC RANGE (HDR)', '[B]HDR[/B]'), ('IMAX', 'IMAX'), ('HYBRID', '[B]HYBRID[/B]'), ('AV1', '[B]AV1[/B]'),
('HEVC (X265)', '[B]HEVC[/B]'), ('REMUX', 'REMUX'), ('BLURAY', 'BLURAY'), ('AI ENHANCED/UPSCALED', '[B]AI ENHANCED/UPSCALED[/B]'), ('SDR', 'SDR'), ('3D', '[B]3D[/B]'),
('DOLBY ATMOS', 'ATMOS'), ('DOLBY TRUEHD', 'TRUEHD'), ('DOLBY DIGITAL EX', 'DD-EX'), ('DOLBY DIGITAL PLUS', 'DD+'), ('DOLBY DIGITAL', 'DD'),
('DTS-HD MASTER AUDIO', 'DTS-HD MA'), ('DTS-X', 'DTS-X'), ('DTS-HD', 'DTS-HD'), ('DTS', 'DTS'), ('AAC', 'AAC'), ('OPUS', 'OPUS'), ('MP3', 'MP3'), ('8CH AUDIO', '8CH'),
('7CH AUDIO', '7CH'), ('6CH AUDIO', '6CH'), ('2CH AUDIO', '2CH'), ('DVD SOURCE', 'DVD'), ('WEB SOURCE', 'WEB'), ('MULTIPLE LANGUAGES', 'MULTI-LANG'),
('SUBTITLES', 'SUBS'))

def include_exclude_filters():
	# LOCAL PATCH 2026-06-15: HDR10+ added as separate filter (port-extension of POV per-codec sort).
	return {'hevc': 'HEVC', '3d': '3D', 'hdr': 'HDR', 'hdr10plus': 'HDR10+', 'dv': 'D/VISION', 'av1': 'AV1', 'enhanced_upscaled': 'AI ENHANCED/UPSCALED', 'hybrid': 'HYBRID'}

def get_aliases_titles(aliases):
	try: result = [i['title'] for i in aliases]
	except: result = []
	return result

def make_alias_dict(meta, title):
	aliases = []
	alternative_titles = meta.get('alternative_titles', [])
	original_title = meta['original_title']
	cunt_codes = meta.get('country_codes', [])
	country_codes = set([i.replace('GB', 'UK') for i in cunt_codes])
	if alternative_titles: aliases = [{'title': i, 'country': ''} for i in alternative_titles]
	if original_title not in alternative_titles: aliases.append({'title': original_title, 'country': ''})
	if country_codes: aliases.extend([{'title': '%s %s' % (title, i), 'country': ''} for i in country_codes])
	return aliases

def internal_results(provider, sources):
	set_property('deadlight.internal_results.%s' % provider, json.dumps(sources))

# LOCAL PATCH 2026-09-26: names shown to the user for a scraper whose id reads badly. DISPLAY ONLY -- the
# id itself (http_streams) keys its settings, cache rows, priority/colour and the results filter.
_PROVIDER_DISPLAY = {'HTTP_STREAMS': 'DIRECT STREAMS', 'APIBAY': 'PIRATEBAY', 'TORRENTSCSV': 'TORRENTS-CSV', 'TORRENTDOWNLOADS': 'TD.PRO'}

def provider_display_name(provider):
	provider = (provider or '').upper()
	return _PROVIDER_DISPLAY.get(provider, provider)

# LOCAL PATCH 2026-09-29: the loading window names each provider as it writes itself (the Settings labels), not in
# capitals. DISPLAY ONLY, like _PROVIDER_DISPLAY. Anything unlisted is title-cased.
_PROVIDER_PANEL = {'animetosho': 'AnimeTosho', 'apibay': 'PirateBay', 'bitmagnet': 'Bitmagnet', 'knaben': 'Knaben', 'torlock': 'Torlock',
	'mediafusion': 'MediaFusion', 'nekobt': 'nekoBT', 'seadex': 'SeaDex', 'torrentdownload': 'TorrentDownload', 'torrentdownloads': 'TD.pro',
	'torrentsdb': 'TorrentsDB', 'torrentscsv': 'Torrents-CSV', 'torrentgalaxy': 'TorrentGalaxy', 'torz': 'Torz', 'easynews': 'Easynews', 'http_streams': 'Direct Streams',
	'aiostreams': 'AIOStreams', 'rd_cloud': 'RD Cloud', 'pm_cloud': 'PM Cloud', 'ad_cloud': 'AD Cloud',
	'tb_cloud': 'TorBox Cloud', 'folders': 'Local Folders', 'premiumize.me': 'Premiumize'}

def provider_panel_name(provider):
	provider = provider or ''
	name = _PROVIDER_PANEL.get(provider.lower())
	if name: return name
	return provider if any(c.isupper() for c in provider) else provider.replace('_', ' ').title()

def normalize(title):
	import unicodedata
	try:
		title = ''.join(c for c in unicodedata.normalize('NFKD', title) if unicodedata.category(c) != 'Mn')
		return str(title)
	except: return title

# LOCAL PATCH 2026-09-15: a finished COUR is pack-eligible even while a later one airs. TMDb files every cour under one
# season (Re:ZERO: one 85-episode season), so "season has an unaired episode" blocked finished cours' packs.
# Anime only (is_anime_check); cour bounds come from the Fribb index on disk, [] for an unsplit season = False.
# SHOW packs stay disabled regardless: a whole-show pack necessarily spans the airing cour.
def _cour_complete_for_pack(meta, season, episode, episodes_data, adjust_hours, current_date):
	"""True when every episode of the cour being scraped has aired."""
	try:
		if not is_anime_check(meta): return False
		try: episode = int(episode)
		except (TypeError, ValueError): return False
		from caches.fribb_mappings import cours_for_tmdb_season
		cours = cours_for_tmdb_season(meta.get('tmdb_id'), season, len(episodes_data))
		if not cours: return False
		# A cour covers TMDb episodes offset+1 .. offset+length.
		mine = next((c for c in cours if c['offset'] < episode <= c['offset'] + c['length']), None)
		if not mine: return False
		lo, hi = mine['offset'] + 1, mine['offset'] + mine['length']
		for item in episodes_data:
			try: ep_no = int(item.get('episode'))
			except (TypeError, ValueError): return False
			if not lo <= ep_no <= hi: continue
			aired = adjust_premiered_date(item.get('premiered'), adjust_hours)[0]
			if aired is None or aired > current_date: return False
		return True
	except Exception:
		return False

def pack_enable_check(meta, season, episode):
	try:
		status = meta['extra_info']['status']
		if status in ('Ended', 'Canceled'): return True, True
		adjust_hours, current_date = date_offset(), get_datetime()
		episodes_data = episodes_meta(season, meta)
		unaired_episodes = [adjust_premiered_date(i['premiered'], adjust_hours)[0] for i in episodes_data]
		if None in unaired_episodes or any(i > current_date for i in unaired_episodes):
			return _cour_complete_for_pack(meta, season, episode, episodes_data, adjust_hours, current_date), False
		else: return True, False
	except: pass
	return False, False

def clear_scrapers_cache(silent=False):
	from caches.base_cache import clear_cache
	for item in ('internal_scrapers', 'external_scrapers'): clear_cache(item, silent=True)
	if not silent: notification('Success')

# LOCAL PATCH 2026-09-29: which .m2ts torrents a MOVIE resolve refuses. A Blu-ray folder can split the film over several
# streams joined by a playlist, and a debrid link is one file. Refused only when it MAY be split: two or more .m2ts and
# the largest is under 4x the next or under 75 % of all .m2ts bytes (resolvers open the largest file).
# files: [(name, size)]. Unknown sizes (0) refuse. Names repeat in some listings, so each (name, size) counts once.
def split_disc(files):
	m2ts = sorted(set((n, s or 0) for n, s in files if (n or '').lower().endswith('.m2ts')), key=lambda f: f[1], reverse=True)
	if len(m2ts) < 2: return False
	sizes = [s for n, s in m2ts]
	return not (sizes[1] and sizes[0] >= 4 * sizes[1] and sizes[0] >= 0.75 * sum(sizes))

# LOCAL PATCH 2026-09-30: the loading window's quality counts match the list that will open, not every row sent.
class WindowCounter:
	"""Passes each release once (by hash, else url / name) and only when countable(item) returns '' -- the caller's
	own filters. What it leaves out is tallied by reason for the window's 'Hidden' line. Providers answer in
	parallel threads, hence the lock."""
	_LABELS = (('repeat', 'repeat', 'repeats'), ('cam', 'cam rip', 'cam rips'), ('fake', 'fake', 'fakes'),
			   ('other film', 'other film', 'other films'), ('wrong pack', 'pack without the episode', 'packs without the episode'),
			   ('quality', 'outside your quality settings', 'outside your quality settings'))
	def __init__(self, countable=None):
		from collections import Counter
		from threading import Lock
		self.countable, self.seen, self.hidden, self.lock = countable, set(), Counter(), Lock()

	def keep(self, sources):
		out = []
		with self.lock:
			for i in sources or []:
				key = str(i.get('hash') or i.get('url') or i.get('name') or id(i)).lower()
				if key in self.seen:
					self.hidden['repeat'] += 1
					continue
				self.seen.add(key)
				try: reason = self.countable(i) if self.countable else ''
				except Exception: reason = ''
				if reason: self.hidden[reason] += 1
				else: out.append(i)
		return out

	def hide(self, reason, n=1):
		if not n: return
		with self.lock: self.hidden[reason] += n

	def line(self):
		parts = ['%d %s' % (self.hidden[k], one if self.hidden[k] == 1 else many) for k, one, many in self._LABELS if self.hidden.get(k)]
		return 'Hidden  ·  %s' % '  ·  '.join(parts) if parts else ''

def supported_video_extensions():
	supported_video_extensions = supported_media().split('|')
	return [i for i in supported_video_extensions if not i in ('','.zip','.rar','.iso')]

# LOCAL PATCH 2026-08-31: compiled once; both run on every file the debrid-cloud scrapers examine.
_RE_TITLE_CLEAN = _LazyRe('_RE_TITLE_CLEAN', r'[^A-Za-z0-9-]+')
_RE_VERSION_SUFFIX = _LazyRe('_RE_VERSION_SUFFIX', r'(?<=\d)v\d+(?=\D|$)')

# LOCAL PATCH 2026-09-24: a candidate SEASON meaning 'whichever season the file names' -- some releases write the
# ABSOLUTE episode under their own season label ('ONE.PIECE.S01E1104' = TMDb S22E1104). Only safe above
# _ANY_SEASON_MIN, which no season-relative count reaches (longest release season seen: 197); below it a relative
# 'S21E150' would play for episode 150.
ANY_SEASON = -1
# LOCAL PATCH 2026-09-24: a candidate SEASON meaning 'this is the ABSOLUTE number' -- matched only by forms that carry
# one ('- 24', 'Episode 24', a bare '.24.'), never by an explicit SxxEyy. Not (TMDb season, absolute): in a per-season
# pack 'S02E24' is a real file (the S2 finale), not absolute 24.
ABSOLUTE_SEASON = -2
_ANY_SEASON_MIN = 200


# LOCAL PATCH 2026-09-24: the episode number a name states after a dash -- '<show> - 681 - <title>'.
# Read on the CLEANED title, where ' - ' has become '.-.'. See seas_ep_filter.
_RE_DASH_NUMBER = _LazyRe('_RE_DASH_NUMBER', r'\.-\.0*(\d{1,4})\.')
# LOCAL PATCH 2026-09-24: a bit-depth tag, '10 bit' / '10bit' / '8 bits', on the cleaned title -- string7 would read
# '[AV1 10 bit]' as episode 10. Blanked before matching, anime only (strict), like _RE_DASH_NUMBER.
_RE_BIT_DEPTH = _LazyRe('_RE_BIT_DEPTH', r'(?<![a-z0-9])(?:8|10|12)\.?bits?(?![a-z0-9])')


@lru_cache(maxsize=512)
def _seas_ep_pattern(season, episode, strict, bare=True):
	"""The compiled season/episode alternation for one (season, episode, strict).

	LOCAL PATCH 2026-08-31: memoised -- only release_title varies during a scrape, and the
	debrid-cloud scrapers call seas_ep_filter once per file.
	"""
	# LOCAL PATCH 2026-09-24: ANY_SEASON -- only the explicit SxxEyy form; an episode-only
	# pattern would add nothing the real pairs do not already try.
	if season == ANY_SEASON:
		return re.compile(r'(s\d{1,3}[.-]?e[p]?[.-]?0*%d[.-])' % int(episode))
	str_season, str_episode = str(season), str(episode)
	season_fill, episode_fill = str_season.zfill(2), str_episode.zfill(2)
	str_ep_plus_1, str_ep_minus_1 = str(episode+1), str(episode-1)
	# LOCAL PATCH 2026-09-24: any number of leading zeros on either side ('S001E001'). Still
	# anchored by the next marker, so 's0*1' cannot read 's10e..' nor 'e0*1' read 'e10.'.
	string1 = r'(s0*<<S>>[.-]?e[p]?[.-]?0*<<E>>[.-])'
	string2 = r'(season[.-]?<<S>>[.-]?episode[.-]?<<E>>[.-])'
	string3 = r'(s<<S>>e<<E1>>[.-]?e?<<E2>>[.-])'
	string4 = r'([.-]<<S>>[.-]<<E>>[.-])' if strict else r'([.-]<<S>>[.-]?<<E>>[.-])'
	# LOCAL PATCH 2026-09-24: leading zeros here too, same anchoring as string1 ('EP0001').
	string5 = r'(episode[.-]?0*<<E>>[.-])'
	string6 = r'([.-]e[p]?[.-]?0*<<E>>[.-])'
	# LOCAL PATCH 2026-08-27: the NxNN guard stands down on a season-x-episode marker ('1x04', at most 2 by 3 digits).
	# Not `\d+x\d+`: that also matched resolutions ('1920x1080') and disabled this pattern.
	string7 = r'(^(?=.*\.e?0*<<E>>\.)(?:(?!((?:s|season)[.-]?\d+[.-x]?(?:ep?|episode)[.-]?\d+)|(?<!\d)\d{1,2}x\d{1,3}(?!\d)).)*$)'
	string8 = r'([s]?<<S>>x<<E>>[.-])'
	string_list = []
	string_list_append = string_list.append
	string_list_append(string1.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string1.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string1.replace('<<S>>', season_fill).replace('<<E>>', str_episode))
	string_list_append(string1.replace('<<S>>', str_season).replace('<<E>>', str_episode))
	string_list_append(string2.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string2.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string2.replace('<<S>>', season_fill).replace('<<E>>', str_episode))
	string_list_append(string2.replace('<<S>>', str_season).replace('<<E>>', str_episode))
	string_list_append(string3.replace('<<S>>', season_fill).replace('<<E1>>', str_ep_minus_1.zfill(2)).replace('<<E2>>', episode_fill))
	string_list_append(string3.replace('<<S>>', season_fill).replace('<<E1>>', episode_fill).replace('<<E2>>', str_ep_plus_1.zfill(2)))
	string_list_append(string4.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string4.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string5.replace('<<E>>', episode_fill))
	string_list_append(string5.replace('<<E>>', str_episode))
	string_list_append(string6.replace('<<E>>', episode_fill))
	if bare: string_list_append(string7.replace('<<E>>', episode_fill))
	if season == ABSOLUTE_SEASON:
		# LOCAL PATCH 2026-09-24: season-free forms only -- see ABSOLUTE_SEASON. string6 needs a
		# separator before its 'e', so the 'e24' inside 's02e24' cannot match it either.
		string_list = [string5.replace('<<E>>', episode_fill), string5.replace('<<E>>', str_episode),
			string6.replace('<<E>>', episode_fill)]
		if bare: string_list.append(string7.replace('<<E>>', episode_fill))
	string_list_append(string8.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string8.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string8.replace('<<S>>', season_fill).replace('<<E>>', str_episode))
	string_list_append(string8.replace('<<S>>', str_season).replace('<<E>>', str_episode))
	final_string = '|'.join(string_list)
	return re.compile(final_string)


def _states_dash_number(name):
	"""True when a name states its episode after a dash, read exactly as seas_ep_filter reads it."""
	cleaned = _RE_TITLE_CLEAN.sub('.', unquote(name or '').replace('\'', '')).lower()
	return bool(_RE_DASH_NUMBER.search(_RE_VERSION_SUFFIX.sub('', cleaned)))


def seas_ep_filter(season, episode, release_title, split=False, return_match=False, strict=False, bare=None):
	"""Does `release_title` name this season/episode?

	LOCAL PATCH 2026-08-27 -- `strict` tightens string4 for ANIME ONLY. string4's optional
	separator reads '.101.' as S01E01, right for Western TV but wrong for anime, where 101
	is an absolute number. The conventions conflict, so only anime callers pass strict=True.
	'Naruto.001' matches through string7 either way.
	"""
	release_title = _RE_TITLE_CLEAN.sub('.', unquote(release_title).replace('\'', '')).lower()
	# LOCAL PATCH 2026-08-27: drop the re-release version suffix glued to an episode number ('04v3' = episode 4,
	# version 3); with it attached no pattern matches. A digit must precede the 'v', so 'AV1', 'x264' are untouched.
	release_title = _RE_VERSION_SUFFIX.sub('', release_title)
	# LOCAL PATCH 2026-11-08: the end of the name is a separator. Every pattern ends in [.-] (so e1 cannot read e10), and
	# a name ENDING on its token ('Dorohedoro S01E04') matched nothing. Only appended after a letter or digit.
	if release_title[-1:].isalnum(): release_title += '.'
	# LOCAL PATCH 2026-09-24: once a name states its episode after a dash, a bare number elsewhere is part of a TITLE
	# ('One Piece - 681 - The 500 Million Berry Man!', 'Mob Psycho 100 - 05'), so string7 stands down when the dash
	# number differs; explicit markers are unaffected. Anime only, like the rest of strict.
	# `bare=False` from the caller forces the same stand-down (pick_episode_files, for a file outside its pack's dash
	# convention). None means decide from this name alone.
	bare = bare is not False
	if strict:
		release_title = _RE_BIT_DEPTH.sub('', release_title)
		# LOCAL PATCH 2026-10-05: a name that STARTS with its episode number ('12. The Woman with the Demon Eyes.mkv')
		# has no dot before the number for string7 to anchor on.
		if release_title[:1].isdigit(): release_title = '.' + release_title
		m = _RE_DASH_NUMBER.search(release_title)
		if m and int(m.group(1)) != int(episode): bare = False
	reg_pattern = _seas_ep_pattern(season, episode, strict, bare)
	if split: return release_title.split(re.search(reg_pattern, release_title).group(), 1)[1]
	if return_match: return re.search(reg_pattern, release_title).group()
	return bool(re.search(reg_pattern, release_title))

# LOCAL PATCH 2026-08-27: anime episode numbering for file selection inside packs. Anime packs use one of three
# numberings, none necessarily TMDb's: Re:ZERO TMDb S01E50 is '- 50' (absolute), 'Season 2 - 24' (release season)
# or '2nd Season Part 2 - 12' (cour). Not OR-ed: a complete-series pack also holds a file '12'. Candidates are tried
# HIGHEST episode number first and the first that matches wins -- a narrow pack has no file with the wider number.
# TMDb's own pair gets no priority.


def anime_episode_candidates(meta, tmdb_id, season, episode):
	"""Alternate (season, episode) pairs this anime episode may be numbered as.

	Ordered widest-first, see the note above. Empty for non-anime, which leaves
	every existing caller behaving exactly as it did.
	"""
	try:
		from modules.metadata import is_anime_check
		if not is_anime_check(meta, tmdb_id): return []
	except Exception: return []
	try: season, episode = int(season), int(episode)
	except (TypeError, ValueError): return []
	# LOCAL PATCH 2026-08-27: the primary pair is included so a NON-EMPTY result means exactly 'this is anime' --
	# pick_episode_files' signal to match strictly. ordered_episode_candidates de-duplicates it.
	candidates = [(season, episode)]
	# series-absolute: from TMDb's season_data alone, so it works for shows with no Fribb cour row.
	# LOCAL PATCH 2026-09-02: shared with scrapers/external.py (data['absolute_episode']) so providers and the debrid
	# file pick cannot drift apart. Not an inlined sum of earlier seasons: wrong for shows TMDb numbers absolutely,
	# and the bogus higher number was tried first. `!= episode` only suppresses a duplicate of candidates[0].
	absolute = None
	try:
		absolute = series_absolute_episode(meta, season, episode)
		# LOCAL PATCH 2026-09-24: under ABSOLUTE_SEASON, not TMDb's season -- see there.
		if absolute and absolute != episode: candidates.append((ABSOLUTE_SEASON, absolute))
	except Exception: pass
	# LOCAL PATCH 2026-09-24: the absolute number under any season label -- see ANY_SEASON. Appended after the pair it
	# shares a number with; the sort is stable, so a file TMDb's own pair can find wins.
	_abs = absolute or episode
	if _abs > _ANY_SEASON_MIN: candidates.append((ANY_SEASON, _abs))
	try:
		from caches import fribb_mappings
		# LOCAL PATCH 2026-09-05: allow_repair=False -- matched against release FILENAMES, so only numbering releases
		# actually carry (see the repair branch in fribb_mappings).
		info = fribb_mappings.find_cour_by_tmdb_coords(tmdb_id, season, episode, allow_repair=False) or {}
		# cour_season is season.tvdb -- the season number RELEASES use; TMDb may file every cour under season 1.
		cour_season = info.get('cour_season') or season
		for number in (info.get('season_ep'), info.get('cour_ep')):
			# LOCAL PATCH 2026-10-05: no pair in TMDb's OWN season with another number -- in TMDb numbering that is a
			# different episode (Mushoku S1E12 = Part 2 ep 1, and (1, 1) found every Part 1 pack's S01E01). A part-relative
			# pack numbered from 01 is lost with it; playing the wrong episode is worse.
			if number and not (int(cour_season) == season and int(number) != episode):
				candidates.append((int(cour_season), int(number)))
		# LOCAL PATCH 2026-10-05: plus the flat-season repair's pair when it puts the episode in ANOTHER entry (MASHLE
		# TMDb S1E13 = the 'S02E01' file). Only an extra pair: a TMDb-numbered pack has no 'S02E01' to match by accident.
		rep = fribb_mappings.find_cour_by_tmdb_coords(tmdb_id, season, episode, allow_repair=True) or {}
		if rep.get('cour_season') and rep.get('anilist') and rep.get('anilist') != info.get('anilist'):
			# LOCAL PATCH 2026-10-16: the entry's own number only when it starts its TVDB season -- for a later part
			# (Bungou Stray Dogs S5 = TVDB S3 part 2) it names another episode. That pair comes from
			# metadata.cour_display_numbers instead.
			numbers = (rep.get('season_ep'),) if int(rep.get('cour_part') or 1) > 1 else (rep.get('season_ep'), rep.get('cour_ep'))
			for number in numbers:
				if number: candidates.append((int(rep['cour_season']), int(number)))
	except Exception: pass
	return candidates


# LOCAL PATCH 2026-08-27: things inside a pack that are not the show -- credit sequences, previews, menus, extras.
# They carry episode numbers ('NCOP 01'), so the episode test alone cannot tell them apart. Kept beside extras(),
# which the movie path and cloud scrapers use. magneto's seadex.py `_NOT_AN_EPISODE` is a hand-kept twin (magneto
# cannot import DeadLight) -- change one, look at the other.
_NON_EPISODE = _LazyRe('_NON_EPISODE',
	r'(?:^|[^a-z0-9])(?:nc)?(?:op|ed)\d*(?:[^a-z0-9]|$)|'
	r'(?:^|[^a-z0-9])(?:preview|pv|menu|creditless|clean|textless|sample|trailer|teaser|'
	r'promo|cm|spot|bonus|interview|omake|recap|digest|prologue|epilogue|'
	r'making\.?of|behind\.?the\.?scenes|featurette|blooper|bloopers|outtake|outtakes|'
	# LOCAL PATCH 2026-08-27: the trailing \d* matters -- promos are numbered (PV1, Preview2, CM1).
	r'commentary|karaoke|logo|scan|scans|booklet)\d*(?:[^a-z0-9]|$)', re.I)


# The credit-sequence half of _NON_EPISODE on its own: prepare_episode_files may give back an episode-sized
# file an extras word flagged, but never one of these.
_CREDIT_SEQUENCE = _LazyRe('_CREDIT_SEQUENCE', r'(?:^|[^a-z0-9])(?:nc)?(?:op|ed)\d*(?:[^a-z0-9]|$)|creditless|textless', re.I)

def non_episode_file(name, title=None, ep_name=None):
	"""True when this file is in the pack but is not an episode of the show.

	`title` is the show/episode title. A word is never used as evidence when it appears in
	the title itself -- the same guard the movie branch already applies via
	`extras_filtering_list` -- so a show actually called "Preview" is not wiped out.
	"""
	name = (name or '').lower()
	if not name: return False
	title = _title_guard(title, ep_name)   # LOCAL PATCH 2026-11-07: the episode's own title too (see extras)
	match = _NON_EPISODE.search(name)
	if match and match.group(0).strip('.-_ ') not in title: return True
	# the long-standing extras vocabulary, same title guard as the movie path
	return any(word in name for word in extras() if word not in title)


def ordered_episode_candidates(season, episode, candidates=None):
	"""Every numbering this episode may be called, highest episode number first.

	LOCAL PATCH 2026-08-27: the single home for this ordering; the scrape path publishes it
	in data['episode_candidates'] so magneto's seadex reads it instead of recomputing.

	TMDb's own pair gets no priority: pinned first, Naruto S04E01 (absolute 159) matched
	'Naruto - 001' in an absolute pack. Descending is safe: a narrow pack has no file with
	the wider number, so a high candidate finds nothing and the search falls through.
	"""
	ordered, seen = [], set()
	for pair in [(season, episode)] + list(candidates or []):
		if pair[0] is None or pair[1] is None or pair in seen: continue
		seen.add(pair)
		ordered.append(pair)
	ordered.sort(key=lambda pair: -int(pair[1]))
	return ordered


_SIZE_KEYS = ('size', 'bytes', 's', 'filesize', 'length')


def _file_size(f):
	"""Bytes for a debrid file dict, whatever the provider calls the field.

	TorBox/EasyDebrid/Premiumize use 'size', Real-Debrid 'bytes', AllDebrid 's'.
	Returns 0 when unknown, which leaves such files in their original order.
	"""
	if not isinstance(f, dict): return 0
	for k in _SIZE_KEYS:
		v = f.get(k)
		if v is None: continue
		try: return int(v)
		except (TypeError, ValueError): continue
	return 0


def _key_name(key):
	def _name(f):
		if key is None: return f
		# callable for the callers whose match text is derived, not a plain field
		# (Premiumize matches on the basename of item['path'])
		return key(f) if callable(key) else f[key]
	return _name


def prepare_episode_files(files, key=None, title=None, strict=False, ep_name=None):
	"""(usable files, indices outside the pack's naming convention) -- everything
	pick_episode_files works out about a listing BEFORE it looks at an episode number.

	LOCAL PATCH 2026-09-24: split out so a caller asking many episodes of ONE listing (external.py's
	readability probe) pays for it once. Must be built with the same `key`, `title` and `strict`
	the picks will use.
	"""
	_name = _key_name(key)
	try:
		flagged = [non_episode_file(_name(f), title, ep_name) for f in files]
		usable = [f for f, bad in zip(files, flagged) if not bad]
		# LOCAL PATCH 2026-09-27: an extras WORD can be an episode's own title ('Youjo Senki - 02v3 - Prologue'). A
		# flagged file comes back when it looks like an episode by STRUCTURE: it states its episode after a dash, is
		# episode-sized (half the median of the pack's large files -- not the plain median, which many small shorts can
		# drag down), and was flagged by a vocabulary word, never a credit sequence.
		if usable and any(flagged):
			sizes = sorted(_file_size(f) for f in usable)
			large = [s for s in sizes if s >= sizes[-1] * 0.2]
			reference = large[len(large) // 2] if large else 0
			if reference > 0:
				keep = set(i for i, (f, bad) in enumerate(zip(files, flagged)) if bad
					and _file_size(f) >= reference * 0.5 and _states_dash_number(_name(f))
					and not _CREDIT_SEQUENCE.search((_name(f) or '').lower()))
				if keep: usable = [f for i, f in enumerate(files) if not flagged[i] or i in keep]
	except Exception: usable = list(files)
	# Never let the filter empty the pack -- a release whose every file trips a keyword is
	# better matched loosely than not at all.
	if not usable: usable = list(files)
	# LOCAL PATCH 2026-08-27: and a size floor, which needs no vocabulary: drop anything under a tenth of the median
	# (per-episode promos run ~0.4 %; even a 480p episode in a mixed pack runs ~27 %).
	if len(usable) >= 4:
		sizes = sorted(_file_size(f) for f in usable)
		median = sizes[len(sizes) // 2]
		if median > 0:
			floor = median * 0.10
			big_enough = [f for f in usable if _file_size(f) >= floor]
			if big_enough: usable = big_enough
	# LOCAL PATCH 2026-09-24: the pack's own naming convention. When at least two thirds of its files (4 or more) state
	# their episode after a dash, a file that does NOT (a recap, a special) may answer only through an explicit marker,
	# never a bare number. Anime only.
	outside = set()
	if strict and len(usable) >= 4:
		try:
			dashed = [_states_dash_number(_name(f)) for f in usable]
			if sum(dashed) * 3 >= len(usable) * 2: outside = set(i for i, d in enumerate(dashed) if not d)
		except Exception: outside = set()
	return usable, outside


_RE_NOT_AN_EPISODE = _LazyRe('_RE_NOT_AN_EPISODE', r'(?<![a-z0-9])(?:movies?|gekijou?ban|the[\s._-]?movie|ova|oad|ona|specials?)(?![a-z0-9])', re.I)

def _narrow_anime_hits(hits, name_of, title):
	"""LOCAL PATCH 2026-10-05: several files of one anime pack matching the episode -- keep the episode itself.

	Largest-first alone picks wrong in franchise packs ('Bleach Movie 01.mkv' over 'Bleach 01.mkv'). Each step only when
	something is left after it: films, OVAs and specials go (unless the show's title says so), then files without the
	show's name when others carry it."""
	title_l = str(title or '').lower()
	def _words(t): return set(w for w in re.findall(r'[a-z0-9]+', str(t).lower()) if len(w) >= 3)
	episodes = [h for h in hits if not any(m.group(0).lower() not in title_l for m in _RE_NOT_AN_EPISODE.finditer(str(name_of(h))))]
	if episodes: hits = episodes
	own = _words(title) - {'the', 'and', 'season', 'part'}
	if own:
		named = [h for h in hits if _words(name_of(h)) & own]
		if named: hits = named
	return hits

def pick_episode_files(files, season, episode, key=None, candidates=None, title=None, prepared=None, ep_name=None):
	"""(matching files, the (season, episode) pair that matched them), largest first.

	Returns the pair as well because the debrid modules call seas_ep_filter a second
	time with split=True on a file they have already matched, to inspect what follows
	the episode marker. That second call must use the SAME numbering -- with split=True
	a miss is not False, it is re.search(...) returning None and .group() raising.
	It stays non-strict, which is safe: non-strict matches a superset of strict.

	LOCAL PATCH 2026-08-27 -- two defences against playing the wrong file out of a pack,
	here because all five debrid modules route through this function: credit sequences,
	previews and extras are dropped first (non_episode_file), and what still matches is
	returned LARGEST FIRST (every caller takes the first hit; torrent order is arbitrary).

	`strict` episode matching is enabled whenever candidates are supplied, which is exactly
	when the caller has told us this is anime (see anime_episode_candidates).
	"""
	_name = _key_name(key)
	strict = bool(candidates)
	# `prepared`: prepare_episode_files' result for THIS listing with the same key, title and
	# strictness -- lets a caller asking many episodes of one pack prepare it once.
	usable, outside = prepared if prepared is not None else prepare_episode_files(files, key, title, strict, ep_name)
	for pair in ordered_episode_candidates(season, episode, candidates):
		try: hits = [f for i, f in enumerate(usable) if seas_ep_filter(pair[0], pair[1], _name(f), strict=strict,
			bare=False if i in outside else None)]
		except Exception: continue
		if hits:
			if strict and len(hits) > 1: hits = _narrow_anime_hits(hits, _name, title)
			hits.sort(key=_file_size, reverse=True)
			# LOCAL PATCH 2026-08-31: publish the file chosen out of the pack -- the debrid modules return only a url
			# (TorBox's is an opaque uuid) and playing_filename is the PACK name, which blinds subtitle matching.
			# Consumers must re-verify -- see subtitles._played_name().
			try: set_property('deadlight.playing.pack_file', str(_name(hits[0])))
			except Exception: pass
			return hits, pair
	# LOCAL PATCH 2026-10-24: a release named by its air date ('The.Daily.Show.2026.10.20.1080p') has no episode number.
	# The provider already matched the torrent name to this episode's date (magneto air_date_pattern), so its one video
	# file is the episode when it is date-named too and names no episode. Not for anime (candidates).
	if not candidates and len(usable) == 1:
		_only = str(_name(usable[0]))
		if _DATED_NAME.search(_only) and not _ANY_EPISODE_MARKER.search(_only):
			try: set_property('deadlight.playing.pack_file', _only)
			except Exception: pass
			return list(usable), (season, episode)
	return [], (season, episode)

_DATED_NAME = _LazyRe('_DATED_NAME', r'(?<![0-9])(?:19|20)\d{2}[.\-_ ]?(?:0[1-9]|1[0-2])[.\-_ ]?(?:0[1-9]|[12][0-9]|3[01])(?![0-9])')
_ANY_EPISODE_MARKER = _LazyRe('_ANY_EPISODE_MARKER', r's\d{1,4}[ ._-]?e\d{1,4}|(?<![0-9])\d{1,2}x\d{2}(?![0-9])|episode[ ._-]?\d', re.I)


def pick_episode_file(files, season, episode, key=None, candidates=None, title=None, ep_name=None):
	"""LOCAL PATCH 2026-11-04 (episode card, phase 5): THE file of this episode in a pack, or None -- the first of
	pick_episode_files' hits (largest first) whose text AFTER the episode marker, the episode's own title taken out, names
	no extra ('S01E05.Featurette', 'S01E05.Deleted.Scenes').

	One rule for the four debrid modules. A hit the split re-read cannot cut (it matched by a strict anime form or by its
	air date) is kept, not raised on."""
	hits, pair = pick_episode_files(files, season, episode, key, candidates, title, ep_name=ep_name)
	if not hits: return None
	_name = _key_name(key)
	words = extras(title, ep_name)
	def _dotted(text): return re.sub(r'[^A-Za-z0-9-]+', '.', str(text or '').replace('\'', '').replace('&', 'and').replace('%', '.percent')).lower().strip('.')
	# LOCAL PATCH 2026-11-07 (Red Light 3.0.1 port): the episode's own title is taken out too
	owns = [o for o in (_dotted(title), _dotted(ep_name)) if o]
	for f in hits:
		try: tail = seas_ep_filter(pair[0], pair[1], str(_name(f)), split=True)
		except Exception: tail = None
		if tail is not None:
			for own in owns: tail = tail.replace(own, '')
			if any(w in tail for w in words): continue
		if f is not hits[0]:
			try: set_property('deadlight.playing.pack_file', str(_name(f)))
			except Exception: pass
		return f
	return None


# LOCAL PATCH 2026-09-24: numbers a pack's own filenames write, for the readability probe in external._real_pack_sizes
# (which episodes does this listing name?). Not a fixed 1-60 range: packs can start far above it. Resolutions, codecs,
# years and CRC32 tags are left out.
_LISTING_NUMBER = _LazyRe('_LISTING_NUMBER', r'(?<![a-z0-9])0*(\d{1,4})(?![0-9])(?!p\b)(?!bit)', re.I)
_LISTING_CRC = _LazyRe('_LISTING_CRC', r'\[[0-9a-f]{8}\]', re.I)
_LISTING_NOISE = frozenset((480, 576, 720, 1080, 1440, 2160, 264, 265))

def listing_episode_numbers(usable, cap=20):
	"""Distinct plausible episode numbers written in the filenames, lowest first."""
	seen = set()
	for f in usable:
		for m in _LISTING_NUMBER.finditer(_LISTING_CRC.sub(' ', f['filename'])):
			n = int(m.group(1))
			if n and n not in _LISTING_NOISE and not 1900 <= n <= 2099: seen.add(n)
	return sorted(seen)[:cap]

# Season/episode pairs: the probe asks only in the REQUESTED season, so a pack of another season could never prove
# itself readable. Probing a pair a file itself names shows the matcher understands the convention.
_LISTING_SXE = _LazyRe('_LISTING_SXE', r'(?<![a-z0-9])s(\d{1,3})[.\-_ ]?e(\d{1,4})(?!\d)', re.I)
# LOCAL PATCH 2026-10-27: and NxNN ('1x01'). No letter or digit before the season keeps '1920x1080' out; x264 / x265
# after it are codecs ('5.1x265'), not episodes.
_LISTING_NXN = _LazyRe('_LISTING_NXN', r'(?<![a-z0-9])(\d{1,2})x(\d{2,3})(?!\d)(?<!x264)(?<!x265)', re.I)

def listing_holds_episode(usable, season, episode, candidates=None, title=None):
	"""LOCAL PATCH 2026-11-09: does a debrid file listing ([{'filename', 'size'}], video files only) hold this episode?
	True: a file matches. False: none does AND the listing is readable -- the same matcher finds some OTHER episode in it
	(external.py's pack-contents rule: an unreadable naming convention also misses, so a miss alone proves nothing).
	None: cannot tell."""
	try:
		season, episode = int(season), int(episode)
		hits, _matched = pick_episode_files(usable, season, episode, 'filename', candidates, title)
		if hits: return True
		prepared = prepare_episode_files(usable, 'filename', title, strict=True)
		for probe in listing_episode_numbers(usable):
			if probe == episode: continue
			if pick_episode_files(usable, season, probe, 'filename', [(season, probe)], title, prepared=prepared)[0]: return False
		for pair in listing_episode_pairs(usable):
			if pair == (season, episode): continue
			if pick_episode_files(usable, pair[0], pair[1], 'filename', [pair], title, prepared=prepared)[0]: return False
	except Exception: pass
	return None

def listing_episode_pairs(usable, cap=5):
	"""Distinct (season, episode) pairs written as SxxEyy (or NxNN) in the filenames, lowest first."""
	seen = set()
	for f in usable:
		m = _LISTING_SXE.search(f['filename']) or _LISTING_NXN.search(f['filename'])
		if m: seen.add((int(m.group(1)), int(m.group(2))))
	return sorted(seen)[:cap]


def find_season_in_release_title(release_title):
	release_title = re.sub(r'[^A-Za-z0-9-]+', '.', unquote(release_title).replace('\'', '')).lower()
	match = None
	regex_list = [r's(\d+)', r's\.(\d+)', r'(\d+)x', r'(\d+)\.x', r'season(\d+)', r'season\.(\d+)']
	for item in regex_list:
		try:
			match = re.search(item, release_title)
			if match:
				match = int(str(match.group(1)).lstrip('0'))
				break
		except: pass
	return match

# LOCAL PATCH 2026-10-16: separators compared as one -- any run of space / dot / hyphen / underscore is one dot on both
# sides ('epic.-.first.semester' vs 'epic-first.semester').
_SEPARATORS = _LazyRe('_SEPARATORS', r'[\s._-]+')

def _one_sep(text): return _SEPARATORS.sub('.', text).strip('.')

# LOCAL PATCH 2026-10-16: films -- a year the name states must fit the requested one, and the title must stand as whole
# words ('promise' is in 'promises'). A name with no year passes. Window: one year before to three after -- TMDb dates a
# film by its first showing and releases trail it; a release dated well BEFORE the film is another film.
_NAME_YEAR = _LazyRe('_NAME_YEAR', r'(?<![0-9a-z])((?:19|20)[0-9]{2})(?![0-9a-z])', re.I)
_YEAR_BEFORE, _YEAR_AFTER = 1, 3

def year_mismatch(release_title, year):
	try: wanted = int(year)
	except: return False
	stated = [int(y) for y in _NAME_YEAR.findall(release_title)]
	return bool(stated) and not any(-_YEAR_BEFORE <= y - wanted <= _YEAR_AFTER for y in stated)

def _has_words(release_title, cleaned_titles):
	padded = '.%s.' % release_title
	return any(i and '.%s.' % i in padded for i in cleaned_titles)

# LOCAL PATCH 2026-11-10: the other spellings a release writes a show title in -- its words run together ('MARRIAGETOXIN.
# S01E01' for Marriage Toxin: HDHub, log 2026-11-10, 14 of 14 rows dropped) and without 'the' / 'a' / 'an' ('Ace.of.Diamond.
# S2' for Ace of the Diamond). An article goes only when 2+ words stay, so 'The Boys' never becomes 'Boys'.
_TITLE_ARTICLES = frozenset(('the', 'a', 'an'))

def title_spellings(text):
	"""{words joined, words joined without articles} for a title or the show part of a release name."""
	words = [w for w in re.split(r'[^a-z0-9]+', str(text or '').lower().replace('&', 'and')) if w]
	if not words: return set()
	keys = {''.join(words)}
	bare = [w for w in words if w not in _TITLE_ARTICLES]
	if len(bare) >= 2 and len(bare) < len(words): keys.add(''.join(bare))
	return keys

def check_title(title, release_title, aliases, year, season, episode, air_date=None, ep_title=None):
	# LOCAL PATCH 2026-10-24: air_date -- a talk show released by date ('Jimmy.Fallon.2026.10.22') names no SxxEyy. The
	# exact air date stands in for the episode token, and the name before it may be the host's: consecutive words of the
	# title (magneto _title_run; magneto's check_title has the same rule).
	date_hit = False
	try:
		all_titles = [title]
		if aliases: all_titles += aliases
		cleaned_titles = []
		cleaned_titles_append = cleaned_titles.append
		year = str(year)
		# LOCAL PATCH 2026-11-04 (Red Light 2.9.5, #291): '?' goes the way '!' does -- release names never carry it
		# (Windows forbids '?' in a filename)
		for i in all_titles:
			cleaned_titles_append(
				_one_sep(i.lower().replace('\'', '').replace(':', '').replace('!', '').replace('?', '').replace('(', '').replace(')', '').replace('&', 'and').replace(' ', '.').replace(year, '')))
		# LOCAL PATCH 2026-10-19: no non-ASCII strip here -- the cleaned titles above keep their accents, so a strip would
		# stop 'Pokemon' (e-acute) matching.
		release_title = release_title.lstrip('/ ').replace(' ', '.').replace(':', '.').lower()
		releasetitle_startswith = release_title.startswith
		unwanted = unwanted_tags()
		for i in unwanted:
			if releasetitle_startswith(i):
				i_startswith = i.startswith
				pattern = r'\%s' % i if i_startswith('[') or i_startswith('+') else r'%s' % i
				release_title = re.sub(r'^%s' % pattern, '', release_title, count=1, flags=re.I)
		release_title = release_title.lstrip('.-:/')
		release_title = re.sub(r'^\[.*?]', '', release_title, count=1, flags=re.I)
		release_title = release_title.lstrip('.-[](){}:/')
		# LOCAL PATCH 2026-11-08: as in seas_ep_filter -- the end of the name is a separator, so a token that ends the name
		# ('dorohedoro.s01e04') matches, and the split below at that token (which now ends in '.') finds it here too
		if release_title[-1:].isalnum(): release_title += '.'
		# season 0 (specials) is falsy: a special naming its own year (an OVA, a later movie) failed the show's year window
		if season in (None, '') and year_mismatch(release_title, year): return False
		if season:
			if season == 'pack': hdlr = ''
			else:
				try: hdlr = seas_ep_filter(season, episode, release_title, return_match=True)
				except:
					from magneto.modules.source_utils import air_date_pattern
					pattern = air_date_pattern(air_date)
					m = re.search(pattern, release_title) if pattern else None
					if not m: return False
					hdlr, date_hit = m.group(), True
		else: hdlr = year
		if hdlr:
			release_title = release_title.split(hdlr.lower())[0]
			# LOCAL PATCH 2026-11-05: ' ! ? stripped as from the titles (cleaned_titles above) -- some names keep the apostrophe
			release_title = _one_sep(release_title.replace("'", '').replace('!', '').replace('?', '').replace(year, '').replace('(', '').replace(')', '').replace('&', 'and').rstrip('.-').rstrip('.').rstrip('-').replace(':', ''))
			# LOCAL PATCH 2026-09-22 (Red Light 2.6.4 port): for an EPISODE scrape the show title must match exactly --
			# release_title is cut at the SxxExx token, so what is left is the show name. A substring test let 'Super Wings'
			# answer 'Wings'. Movies keep the substring test (hdlr is the year; extra tokens are normal). 'pack' never gets here.
			if season and season != 'pack':
				if not any(release_title == i for i in cleaned_titles):
					# LOCAL PATCH 2026-11-10: the same title in another spelling (title_spellings)
					_own = title_spellings(release_title)
					ok = bool(_own) and any(_own & title_spellings(i) for i in cleaned_titles)
					# LOCAL PATCH 2026-10-24: 'VisionQuest - Reboot (2026) S01E03' -- show plus THIS episode's title before the
					# token (PenguPlay names). Only the episode's own title is accepted, so 'Super Wings' still fails 'Wings'.
					if not ok and ep_title:
						# LOCAL PATCH 2026-11-05: a year is ignored on both sides -- PenguPlay writes the SEASON's year
						_n = lambda x: re.sub(r'[^a-z0-9]', '', re.sub(r'(?<!\d)(?:19|20)\d{2}(?!\d)', '', str(x).lower().replace('&', 'and')))
						ok = bool(_n(ep_title)) and any(_n(release_title) == _n(t) + _n(ep_title) for t in all_titles)
					if not ok and date_hit:
						from magneto.modules.source_utils import _title_run
						ok = _title_run(release_title, all_titles)
					if not ok: return False
			elif not _has_words(release_title, cleaned_titles): return False
		else:
			release_title = _one_sep(release_title.replace("'", '').replace('!', '').replace('?', '').replace(year, '').replace('(', '').replace(')', '').replace('&', 'and').rstrip('.-').rstrip('.').rstrip('-').replace(':', ''))
			if not _has_words(release_title, cleaned_titles): return False
		return True
	except: return True


# LOCAL PATCH 2026-09-26: every HDR10+ spelling ('HDR10+', 'HDR10P') as one token, BEFORE non-alphanumerics become
# dots -- after that 'HDR10+' is 'hdr10.' like HDR10. magneto's info_from_name folds the same spellings.
_HDR10_PLUS = _LazyRe('_HDR10_PLUS', r'hdr10(?:\+|p(?![a-z0-9]))')
# LOCAL PATCH 2026-10-02: 'DD+' -> 'ddp' for the same reason -- 'DD+7.1' became 'dd.7.1' and get_info tagged it DD.
_DD_PLUS = _LazyRe('_DD_PLUS', r'(?<![a-z0-9])dd\+')
# LOCAL PATCH 2026-10-02: an 'A' on a Dolby Digital token is Atmos ('DDPA5.1', 'DDP5.1A'); Atmos rides on DD+, so both
# tags. Matched on get_info's dotted form ('.ddpa.5.1.'); '+' is already 'p' by then.
_DD_ATMOS = _LazyRe('_DD_ATMOS', r'\.ddpa(?=[\d.])|\.ddp?\d(?:\.\d)?a\.')


# LOCAL PATCH 2026-10-02: the results' display names. clean_file_name blanks every '.'; a channel layout keeps its dot
# (lone digit, dot, lone digit, the LAST such pair: 'EAC3.5.1' -> 'EAC3 5.1') and so does H.264 / H.265.
# clean_file_name itself is left alone: it also names files on disk.
_KEEP_DOT = _LazyRe('_KEEP_DOT', r'(?<!\d)(\d)\.(\d)(?!\d)(?!\.\d)|(?<![A-Za-z0-9])([hH])\.(26[45])(?!\d)')
_SPACES = _LazyRe('_SPACES', r' {2,}')
_DOT_HOLD = '․'   # ONE DOT LEADER: untouched by clean_file_name's replacements, restored to '.' after

def clean_display_name(name):
	from modules.utils import clean_file_name
	held = _KEEP_DOT.sub(lambda m: _DOT_HOLD.join(g for g in m.groups() if g), name or '')
	# runs of spaces close up ('[Hindi + English]' -> 'HINDI ENGLISH')
	return _SPACES.sub(' ', clean_file_name(held).replace(_DOT_HOLD, '.'))

def release_info_format(release_title):
	try:
		# folded before url_strip, which already turns '+' into a space
		release_title = url_strip(_DD_PLUS.sub('ddp', _HDR10_PLUS.sub('hdr10plus', (release_title or '').lower())))
		release_title = release_title.lower().replace("'", "").lstrip('.').rstrip('.')
		title = '.%s.' % re.sub(r'[^a-z0-9-~]+', '.', release_title).replace('.-.', '.').replace('-.', '.').replace('.-', '.').replace('--', '.')
		return title
	except:
		return release_title.lower()

def clean_title(title):
	try:
		if not title: return
		title = title.lower()
		title = re.sub(r'&#(\d+);', '', title)
		title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
		title = title.replace('&quot;', '\"').replace('&amp;', '&')
		title = re.sub(r'\n|([\[({].+?[})\]])|([:;–\-"\',!_.?~$@])|\s', '', title)
	except: pass
	return title

def url_strip(url):
	try:
		url = unquote_plus(url)
		if 'magnet:' in url: url = url.split('&dn=')[1]
		url = url.lower().replace("'", "").lstrip('.').rstrip('.')
		title = re.sub(r'[^a-z0-9]+', ' ', url)
		if 'http' in title: return None
		if title == '': return None
		return title
	except: return None

# LOCAL PATCH 2026-08-27: a disc source with no resolution token is not SD -- disc releases often omit it. 1080p is a
# Blu-ray's floor; a 2160p disc says so and get_release_quality catches it first.
# LOCAL PATCH 2026-10-15: REMUX as a word, optionally prefixed bd / uhd / hd / dvd -- a substring test read the group
# 'RemuxDoc' (WEB-DLs) as a remux.
_REMUX = _LazyRe('_REMUX', r'(?<![a-z0-9])(?:bd|uhd|hd|dvd)?remux(?![a-z])', re.I)
_DISC_SOURCE = _LazyRe('_DISC_SOURCE', r'(?<![a-z0-9])(?:bd|uhd|hd|dvd)?remux(?![a-z])|bluray|blu\.ray|bdrip|bd\.rip|bdmv|blu-ray', re.I)
# Explicit low-resolution and DVD markers still win: "BDRip 480p" is a Blu-ray SOURCE at SD resolution.
_LOW_RES = _LazyRe('_LOW_RES', r'480p|576p|360p|240p|\bdvd|dvdrip|dvd\.rip|\bvhs', re.I)


def get_file_info(name_info=None, url=None, default_quality='SD'):
	title = None
	if name_info: title = name_info
	# LOCAL PATCH 2026-11-02: a url / filename goes through release_info_format, as name_info does -- url_strip alone
	# leaves spaces while every tag token is dot-delimited ('.ts.', '.cam.'), so a TS / CAM read as 1080p.
	elif url:
		stripped = url_strip(url)
		title = release_info_format(stripped) if stripped else None
	if not title: return 'SD', ''
	quality = get_release_quality(title)
	if not quality and _DISC_SOURCE.search(title) and not _LOW_RES.search(title):
		quality = '1080p'
	quality = quality or default_quality
	info = get_info(title)
	return quality, info

# LOCAL PATCH 2026-10-25 (4.0.5): each tag group is a module tuple tested with any(map(title.__contains__, ...)) --
# measured faster than generators and than a compiled alternation of the same literals. Token-anchored tests
# (resolutions, MULTI, OPUS) are regexes behind a cheap substring precheck.
def _toks(*tokens):
	return tokens

_Q_SCR = _toks('.scr.', 'screener', 'dvdscr', 'dvd.scr', '.r5', '.r6')
_Q_CAM = _toks('.cam.', 'camrip', 'hdcam', '.hd.cam', 'hqcam', '.hq.cam', 'cam.rip', 'dvdcam')
_Q_TELE = _toks('.tc.', '.ts.', 'tsrip', 'hdts', 'hdtc', '.hd.tc', 'dvdts', 'telesync', 'tele.sync', 'telecine', 'tele.cine')
# LOCAL PATCH 2026-10-25 (4.0.5): the resolution numbers may not touch another digit ('One Piece - 0720'), nor be a size
# ('720MB'), and 4K is tested before 1080 before 720. This result overrides magneto's (external.py), so it uses the same
# anchoring as magneto's _RES_*_RE. A stated number wins over a 4K / UHD WORD ('4K.Remaster.1080p' is 1080p).
_Q_4K = _LazyRe('_Q_4K', r'(?<![0-9])(?:2160|216o)(?![0-9])(?![ .]?mb)')
_Q_1080 = _LazyRe('_Q_1080', r'(?<![0-9])(?:1080|1o8o|108o|1o80)(?![0-9])(?![ .]?mb)')
_Q_720 = _LazyRe('_Q_720', r'(?<![0-9])(?:720|72o)(?![0-9])(?![ .]?mb)')
_Q_4K_WORD = _toks('.4k', 'hd4k', '4khd', '.uhd', 'ultrahd', 'ultra.hd')
_Q_1080_WORD = _toks('fullhd', 'full.hd')

def get_release_quality(release_info):
	c = release_info.__contains__
	if any(map(c, _Q_SCR)): return 'SCR'
	if any(map(c, _Q_CAM)): return 'CAM'
	if any(map(c, _Q_TELE)): return 'TELE'
	if _Q_4K.search(release_info): return '4K'
	if _Q_1080.search(release_info): return '1080p'
	if _Q_720.search(release_info): return '720p'
	if any(map(c, _Q_4K_WORD)): return '4K'
	if any(map(c, _Q_1080_WORD)): return '1080p'
	return None

# LOCAL PATCH 2026-10-05: the Dolby Vision profile a release NAME states, for the results chip (windows/sources.py):
# 'p7fel' / 'p7mel' (FEL / MEL exist only in profile 7) or 'p5' / 'p7' / 'p8' when written out ('DV P7', 'DoVi.P8',
# 'Profile 5'); None when the name does not say. The name must also say DV / DoVi / Dolby Vision.
# Named only, never guessed from source type: a remux converted to P8 without saying so would read P7.
_DV_NAMED = _LazyRe('_DV_NAMED', r'(?<![a-z0-9])(?:dv|dovi|dolby[ ._-]?vision)(?![a-z0-9])', re.I)
_DV_FEL_MEL = _LazyRe('_DV_FEL_MEL', r'(?<![a-z0-9])(fel|mel)(?![a-z0-9])', re.I)
_DV_PROFILE = _LazyRe('_DV_PROFILE', r'(?<![a-z0-9])(?:dv[ ._-]?)?p(?:rofile)?[ ._-]?([578])(?:\.[0-9])?(?![0-9a-z])', re.I)

def dv_profile_named(name):
	name = str(name or '')
	if not _DV_NAMED.search(name): return None
	m = _DV_FEL_MEL.search(name)
	if m: return 'p7' + m.group(1).lower()
	m = _DV_PROFILE.search(name)
	return 'p' + m.group(1) if m else None

_I_3D = _toks('.3d.', '.sbs.', '.hsbs', 'sidebyside', 'side.by.side', 'stereoscopic', '.tab.', '.htab.', 'topandbottom', 'top.and.bottom')
_I_DV = _toks('dolby.vision', 'dolbyvision', '.dovi.', '.dv.')
_I_HDR = _toks('2160p.bluray.hevc.truehd', '2160p.bluray.hevc.dts', '2160p.bluray.hevc.lpcm', '2160p.blu.ray.hevc.truehd',
	'2160p.blu.ray.hevc.dts', '2160p.uhd.bluray', '2160p.uhd.blu.ray', '2160p.us.bluray.hevc.truehd', '2160p.us.bluray.hevc.dts', '.hdr.',
	'hdr10', 'hdr.10', 'uhd.bluray.2160p', 'uhd.blu.ray.2160p')
_I_DV_HDR = _toks('.hdr.', '.hdr10.', 'hdr.10', 'hdr10plus', 'hdr10.plus', 'hybrid')
_I_HDR10P = _toks('hdr10.plus', 'hdr10plus', '.hdr10p.')
_I_AVC = _toks('avc', 'h264', 'h.264', 'x264', 'x.264')
_I_HEVC = _toks('h265', 'h.265', 'hevc', 'x265', 'x.265')
_I_IMAX = _toks('.imax.', '.(imax).', '.(.imax.).')
_I_AI = _toks('.enhanced.', '.upscaled.', '.enhance.', '.upscale.', '.ai.')
_I_XVID = _toks('xvid', '.x.vid')
_I_DIVX = _toks('divx', 'div2', 'div3', 'div4')
_I_BLURAY = _toks('bluray', 'blu.ray', 'bdrip', 'bd.rip')
_I_DVD = _toks('dvdrip', 'dvd.rip')
_I_WEB = _toks('.web.', 'webdl', 'web.dl', 'web-dl', 'webrip', 'web.rip')
_I_HDRIP = _toks('.hdrip', '.hd.rip')
_I_TRUEHD = _toks('true.hd', 'truehd')
_I_DDP = _toks('dolby.digital.plus', 'dolbydigital.plus', 'dolbydigitalplus', 'dd.plus.', 'ddplus', '.ddp.', 'ddp2', 'ddp5', 'ddp7', 'eac3', '.e.ac3')
_I_DDEX = _toks('.dd.ex.', 'ddex', 'dolby.ex.', 'dolby.digital.ex.', 'dolbydigital.ex.')
_I_DD = _toks('dd2.', 'dd5', 'dd7', 'dolby.digital', 'dolbydigital', '.ac3', '.ac.3.', '.dd.')
# LOCAL PATCH 2026-10-25 (4.0.5): OPUS as a word, either with its channels ('opus2.0') or after the resolution / year /
# codec where audio tags sit (not 'Magnum.Opus'). The bare word as the last token is a group name, not audio.
_I_OPUS_CH = _LazyRe('_I_OPUS_CH', r'(?<![a-z0-9])opus[. ]?[1-8][. ]?[01](?![0-9])')
_I_OPUS_LATE = _LazyRe('_I_OPUS_LATE', r'(?:(?<![0-9])(?:\d{3,4}p|480|576|720|1080|2160|(?:19|20)\d{2})(?![0-9])|x26[45]|h\.?26[45]|hevc|avc|av1|'
	r'10bits?|aac|flac|web|blu\.?ray|bdrip|bd|dvd|hdtv|remux|s\d{1,3}\.?e\d{1,4}).*?(?<![a-z0-9])opus(?![a-z0-9])')
_I_DTSX = _toks('.dts.x.', 'dtsx')
_I_DTSMA = _toks('hd.ma', 'hdma')
_I_DTSHD = _toks('dts.hd.', 'dtshd')
_I_8CH = _toks('ch8.', '8ch.', '7.1ch', '7.1.')
_I_7CH = _toks('ch7.', '7ch.', '6.1ch', '6.1.')
_I_6CH = _toks('ch6.', '6ch.', '5.1ch', '5.1.')
_I_2CH = _toks('ch2', '2ch', '2.0ch', '2.0.', 'audio.2.0.', 'stereo')
_I_MPEG = _toks('.mpg', '.mp2', '.mpeg', '.mpe', '.mpv', '.mp4', '.m4p', '.m4v', 'msmpeg', 'mpegurl')
_I_MKV = _toks('.mkv', 'matroska')
# LOCAL PATCH 2026-10-25 (4.0.5): MULTI as a word ('multi', 'multi.audio', 'multi-lang'), not 'Multiverse' or
# '[Multiple Subtitle]'. 'dual-audio' (release_info_format keeps the dash) joins 'dual.audio'.
# LOCAL PATCH 2026-10-26: never followed by ANY 'sub' word ('Multi.Subtitle', 'Multi.Subbed').
_I_MULTI = _LazyRe('_I_MULTI', r'hindi\.eng|ara\.eng|ces\.eng|chi\.eng|cze\.eng|dan\.eng|dut\.eng|ell\.eng|esl\.eng|esp\.eng|fin\.eng|fra\.eng|'
	r'fre\.eng|frn\.eng|gai\.eng|ger\.eng|gle\.eng|gre\.eng|gtm\.eng|heb\.eng|hin\.eng|hun\.eng|ind\.eng|iri\.eng|ita\.eng|jap\.eng|'
	r'jpn\.eng|kor\.eng|lat\.eng|lebb\.eng|lit\.eng|nor\.eng|pol\.eng|por\.eng|rus\.eng|som\.eng|spa\.eng|sve\.eng|swe\.eng|tha\.eng|'
	r'tur\.eng|uae\.eng|ukr\.eng|vie\.eng|zho\.eng|dual[. -]?audio|'
	r'(?<![a-z0-9])multi(?:[. -]?(?:audio|lang|language|languages))?(?![a-z0-9])(?![. -]?sub)')
_I_ADS = _toks('1xbet', 'betwin')
_I_SUBS = _toks('subita', 'subfrench', 'subspanish', 'subtitula', 'swesub', 'nl.subs', 'subbed')

def get_info(title):
	# thanks 123Venom and gaiaaaiaai, whom I knicked most of this code from. :)
	info = []
	info_append = info.append
	c = title.__contains__
	if any(map(c, _I_3D)):
		info_append('[B]3D[/B]')
	if '.sdr' in title:
		info_append('SDR')
	elif any(map(c, _I_DV)):
		info_append('[B]D/VISION[/B]')
	elif any(map(c, _I_HDR)):
		info_append('[B]HDR[/B]')
	elif '2160p' in title and 'remux' in title:
		info_append('[B]HDR[/B]')
	if '[B]D/VISION[/B]' in info:
		# LOCAL PATCH 2026-09-26: + hdr10plus -- 'DV HDR10PLUS' carries an HDR layer too, and the HDR10+
		# check below needs the HDR tag.
		if any(map(c, _I_DV_HDR)):
			info_append('[B]HDR[/B]')
		if '[B]HDR[/B]' in info:
			info_append('[B]HYBRID[/B]')
	# LOCAL PATCH 2026-06-15: HDR10+ by its explicit tokens ('hdr10plus', folded upstream). HDR10+ titles keep the
	# broad HDR tag too, so HDR=Exclude still filters them.
	if '[B]HDR[/B]' in info and any(map(c, _I_HDR10P)):
		info_append('[B]HDR10+[/B]')
	if any(map(c, _I_AVC)):
		info_append('AVC')
	elif '.av1.' in title:
		info_append('[B]AV1[/B]')
	elif any(map(c, _I_HEVC)):
		info_append('[B]HEVC[/B]')
	elif '[B]HDR[/B]' in info or '[B]D/VISION[/B]' in info:
		info_append('[B]HEVC[/B]')
	if any(map(c, _I_IMAX)):
		info_append('IMAX')
	elif any(map(c, _I_AI)):
		info_append('[B]AI ENHANCED/UPSCALED[/B]')
	if '.atvp' in title:
		info_append('APPLETV+')
	elif any(map(c, _I_XVID)):
		info_append('XVID')
	elif any(map(c, _I_DIVX)):
		info_append('DIVX')
	if _REMUX.search(title):
		info_append('REMUX')
	if any(map(c, _I_BLURAY)):
		info_append('BLURAY')
	elif any(map(c, _I_DVD)):
		info_append('DVD')
	elif any(map(c, _I_WEB)):
		info_append('WEB')
	elif 'hdtv' in title:
		info_append('HDTV')
	elif 'pdtv' in title:
		info_append('PDTV')
	elif any(map(c, _I_HDRIP)):
		info_append('HDRIP')
	_dd_atmos = _DD_ATMOS.search(title) is not None
	if 'atmos' in title or _dd_atmos:
		info_append('ATMOS')
	if any(map(c, _I_TRUEHD)):
		info_append('TRUEHD')
	if _dd_atmos or any(map(c, _I_DDP)):
		info_append('DD+')
	elif any(map(c, _I_DDEX)):
		info_append('DD-EX')
	elif any(map(c, _I_DD)):
		info_append('DD')
	if 'aac' in title:
		info_append('AAC')
	elif 'mp3' in title:
		info_append('MP3')
	elif '.flac.' in title:
		info_append('FLAC')
	elif 'opus' in title and (_I_OPUS_CH.search(title) or (not title.endswith('opus.') and _I_OPUS_LATE.search(title))):
		info_append('OPUS')
	if any(map(c, _I_DTSX)):
		info_append('DTS-X')
	elif any(map(c, _I_DTSMA)):
		info_append('DTS-HD MA')
	elif any(map(c, _I_DTSHD)):
		info_append('DTS-HD')
	elif '.dts' in title:
		info_append('DTS')
	# 'ddp5.1a.' -- the Atmos 'A' (see _DD_ATMOS) would hide '5.1.' from the channel tests
	ch_title = re.sub(r'(\d\.\d)a\.', r'\1.', title) if _dd_atmos else title
	cc = ch_title.__contains__
	if any(map(cc, _I_8CH)):
		info_append('8CH')
	elif any(map(cc, _I_7CH)):
		info_append('7CH')
	elif any(map(cc, _I_6CH)):
		info_append('6CH')
	elif any(map(cc, _I_2CH)):
		info_append('2CH')
	if '.wmv' in title:
		info_append('WMV')
	elif any(map(c, _I_MPEG)):
		info_append('MPEG')
	elif '.avi' in title:
		info_append('AVI')
	elif any(map(c, _I_MKV)):
		info_append('MKV')
	if ('.eng' in title or 'multi' in title or 'dual' in title) and _I_MULTI.search(title):
		info_append('MULTI-LANG')
	if any(map(c, _I_ADS)):
		info_append('ADS')
	if any(map(c, _I_SUBS)):
		info_append('SUBS')
	return ' | '.join(filter(None, info))

def get_cache_expiry(media_type, meta, season):
	try:
		current_date = get_datetime()
		if media_type == 'movie':
			premiered = jsondate_to_datetime(meta['premiered'], '%Y-%m-%d', remove_time=True)
			difference = subtract_dates(current_date, premiered)
			if difference == 0: single_expiry = 3
			elif difference <= 7: single_expiry = 24
			elif difference <= 14: single_expiry = 48
			elif difference <= 21: single_expiry = 72
			elif difference <= 30: single_expiry = 96
			elif difference <= 60: single_expiry = 168
			else: single_expiry = 336
			season_expiry, show_expiry = 0, 0
		else:
			recently_ended = False
			extra_info = meta['extra_info']
			ended = extra_info['status'] in ('Ended', 'Canceled')
			premiered = adjust_premiered_date(meta['premiered'], date_offset())[0]
			difference = subtract_dates(current_date, premiered)
			last_episode_to_air = jsondate_to_datetime(extra_info['last_episode_to_air']['air_date'], '%Y-%m-%d', remove_time=True)
			last_ep_difference = subtract_dates(current_date, last_episode_to_air)
			if ended and last_ep_difference <= 14: recently_ended = True
			if not ended or recently_ended:
				if difference == 0: single_expiry = 3
				elif difference <= 3: single_expiry = 24
				elif difference <= 7: single_expiry = 72
				else: single_expiry = 168
				if meta['total_seasons'] == season:
					if last_ep_difference <= 7: season_expiry = 72
					else: season_expiry = 240
				else: season_expiry = 720
				show_expiry = 240
			else: single_expiry, season_expiry, show_expiry = 240, 720, 720
	except: single_expiry, season_expiry, show_expiry = 72, 72, 240
	# LOCAL PATCH 2026-11-10: no scrape result is kept past _RESULTS_MAX_HOURS -- up to 10 days (singles) and 30 days (packs), a
	# better release uploaded since was not seen without a rescrape. 3 days still covers a binge: every episode of a season
	# reuses its season-pack rows.
	return tuple(min(x, _RESULTS_MAX_HOURS) for x in (single_expiry, season_expiry, show_expiry))

_RESULTS_MAX_HOURS = 72

def warm_rd_cache_check(data):
	"""LOCAL PATCH 2026-10-11: fetch what Real-Debrid's cache check needs that does not depend on any hash -- Torrentio's
	cached page for this title (and MediaFusion's, into _CACHE_PAGE_MEMO) -- while the providers are still searching; cold,
	they cost ~1 s each. Called on a thread by scrapers/external.get_sources."""
	# with no hashes the call fetches the Torrentio and MediaFusion pages (memoised); StremThru, a hash check, skips
	try: get_external_cache_status('Real-Debrid', [], data, ['Real-Debrid'])
	except Exception: pass

# LOCAL PATCH 2026-10-15: `status`, when given, gets status['complete'] = whether EVERY service answered. RD_check writes
# 'uncached' verdicts only then -- one page alone lists only a handful of hashes, and a verdict lasts 24 h.
# LOCAL PATCH 2026-10-25 (4.0.5): the episode in Stremio's numbering -- a date-released show's differs from TMDb's
# (Jeopardy! S43E30 is tt0159881:2026:177; external.py sets data['stremio_se'] from modules/cinemeta.py)
def stremio_se_of(data):
	return tuple(data.get('stremio_se') or (data['season'], data['episode']))

def get_external_cache_status(debrid, unchecked_hashes, data, active_debrid, status=None):
	failed = []
	failed_append = failed.append
	def _process(service, hashes):
		result = []
		if service in ('mediafusion', 'torrentio'):
			if service == 'mediafusion':
				base_link, name_test = 'https://mediafusion.elfhosted.com/%s=%s' % (debrid_name, token), '⚡'
				params = json.dumps({'enable_catalogs': False, 'max_streams_per_resolution': 99, 'torrent_sorting_priority':[], 'certification_filter': ['Disable'],
											'nudity_filter': ['Disable'], 'streaming_provider': {'token': token, 'service': debrid_name,
											'only_show_cached_streams': True}}).encode('utf-8')
				headers = {'encoded_user_data': base64.b64encode(params).decode('utf-8')}
			elif service == 'torrentio':
				base_link, name_test = 'https://torrentio.strem.fun/%s=%s' % (debrid_name, token), '[RD+]'
				headers = {'User-Agent': 'Mozilla/5.0'}
			try:
				if 'tvshowtitle' in data: url = '%s%s' % (base_link, '/stream/series/%s:%s:%s.json' % ((imdb_id,) + stremio_se_of(data)))   # LOCAL PATCH 2026-10-25 (4.0.5)
				else: url = '%s%s' % (base_link, '/stream/movie/%s.json' % imdb_id)
				# LOCAL PATCH 2026-10-11: one answer per episode for 2 minutes -- the page lists every cached hash for the
				# title whatever was asked, and the scrape asks once per prefetch batch plus the final check. Successes only.
				memo = _CACHE_PAGE_MEMO.get(url)
				if memo and time.time() - memo[0] < 120: result = list(memo[1])
				else:
					result = _debrid_cache_session.get(url, headers=headers, timeout=9)
					result = result.json()['streams']
					if result:
						result = [re.search(r'\b\w{40}\b', i.get('url')) for i in result if name_test in i['name']]
						result = [i.group() for i in result if i]
					_CACHE_PAGE_MEMO[url] = (time.time(), list(result or []))
			# LOCAL PATCH 2026-10-15: a failed answer is [] and RECORDED as failed -- otherwise `result` is still the
			# Response (a 503 / 429 page) and its raw bytes pass as a complete answer.
			except Exception as e:
				# LOCAL PATCH 2026-10-25 (4.0.5): log why; the URL holds the token, so only service, HTTP status and error type
				try:
					from modules.kodi_utils import logger
					logger('cache check', '%s (%s) failed: HTTP %s, %s' % (service, debrid_name, getattr(result, 'status_code', '-'), type(e).__name__))
				except Exception: pass
				result = []
				failed_append(service)
		elif service == 'stremthru':
			# LOCAL PATCH 2026-10-25 (4.0.5): StremThru's store check takes a hash LIST, so every scraped hash gets a verdict.
			# Up to 500 per call; 100 here, side by side, so the query string stays short. 'sid' feeds its crowdsourced cache --
			# RD has no cache API, so 'cached' is StremThru's shared knowledge. Hashes come back as sent.
			if not hashes: return   # the warm-up (warm_rd_cache_check) asks with none: nothing to do, not a failure
			st_headers = {'X-StremThru-Store-Name': debrid_name, 'X-StremThru-Store-Authorization': 'Bearer %s' % token}
			sid = ('%s:%s:%s' % ((imdb_id,) + stremio_se_of(data))) if 'tvshowtitle' in data else imdb_id
			def fetch(hash_chunk):
				try:
					resp = _debrid_cache_session.get('https://stremthru.13377001.xyz/v0/store/magnets/check', headers=st_headers,
						params={'magnet': ','.join(hash_chunk), 'sid': sid}, timeout=6)
					if resp.status_code != 200:
						from modules.kodi_utils import logger
						logger('StremThru', 'cache check: HTTP %s %s' % (resp.status_code, resp.text[:120].replace(token, '<token>') if token else resp.text[:120]))
						failed_append('stremthru')
						return
					items = ((resp.json() or {}).get('data') or {}).get('items') or []
					result_extend([str(i.get('hash') or '').lower() for i in items if i.get('status') in ('cached', 'downloaded')])
				except Exception: failed_append('stremthru')
			result = []
			result_extend = result.extend
			threads = [Thread(target=fetch, args=(item,)) for item in list(chunks(hashes, 100))]
			[i.start() for i in threads]
			[i.join() for i in threads]
		results.extend(result)
	try:
		results = []
		imdb_id = data['imdb']
		# LOCAL PATCH 2026-10-25 (4.0.5): Real-Debrid asks Torrentio and MediaFusion side by side; complete only when both
		# answered. StremThru is NOT listed: the public instance answers 403 even with a valid RD token. Its branch above
		# works with an instance that authorises this client; add 'stremthru' here (and point the URL at it) to use one.
		debrid_name, services, token = {'Real-Debrid': ('realdebrid', ['torrentio', 'mediafusion'], get_setting('deadlight.rd.token')),
										'AllDebrid': ('alldebrid', ['mediafusion'], get_setting('deadlight.ad.token'))}[debrid]
		threads = [Thread(target=_process, args=(item, unchecked_hashes)) for item in services]
		[i.start() for i in threads]
		[i.join() for i in threads]
		results = list(set(results))
	except Exception: failed_append('setup')
	if status is not None: status['complete'] = not failed
	return results

# LOCAL PATCH 2026-08-29: pre-signed URL expiry, shared by the http_streams and aiostreams scrapers. Pre-signed S3/R2
# links carry X-Amz-Date plus X-Amz-Expires, so an expired one is recognised with NO network call (verified against
# real fetches: no wrong drops, no wrong keeps).
PRESIGN_GRACE = 300           # 5 min: send a borderline link to a probe rather than dropping


def presign_expiry(url):
	"""Epoch at which a pre-signed URL stops working, or None if it is not pre-signed."""
	try:
		from urllib.parse import urlparse, parse_qs
		import calendar
		q = parse_qs(urlparse(url).query)
		signed_at, lifetime = q.get('X-Amz-Date', [None])[0], q.get('X-Amz-Expires', [None])[0]
		if not signed_at or not lifetime: return None
		# calendar.timegm, not mktime: the stamp is UTC.
		# LOCAL PATCH 2026-10-25 (4.0.5): parsed by hand -- time.strptime breaks inside Kodi after its first call
		m = re.match(r'^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z$', signed_at)
		if not m: return None
		return calendar.timegm(tuple(int(i) for i in m.groups()) + (0, 0, 0)) + int(lifetime)
	except Exception:
		return None


def presign_reference(server_date, urls):
	"""Reference clock for the expiry check -> (now_epoch, trustworthy).

	Prefers the provider's own Date header. A CoreELEC box with no RTC can boot with a badly
	wrong clock, and a wrong clock here would silently drop every source. With no server date
	it falls back to the local clock, but reports untrustworthy if anything was signed in the
	future -- which can only mean our clock is behind.
	"""
	import time as _time
	if server_date:
		try:
			import email.utils
			return email.utils.parsedate_to_datetime(server_date).timestamp(), True
		except Exception:
			pass
	now = _time.time()
	for u in urls:
		exp = presign_expiry(u)
		if exp is None: continue
		try:
			from urllib.parse import urlparse, parse_qs
			life = int(parse_qs(urlparse(u).query).get('X-Amz-Expires', ['0'])[0])
		except Exception:
			continue
		if exp - life > now + PRESIGN_GRACE:
			return now, False
	return now, True


def drop_expired_presigns(sources, server_date, url_of=None, mark='_presign_ok'):
	"""Drop pre-signed sources past their expiry; flag the rest as needing no probe."""
	if not sources: return sources
	get = url_of or (lambda s: (s.get('url_dl') or s.get('url') or '').split('|', 1)[0])
	now, ok = presign_reference(server_date, [get(s) for s in sources])
	if not ok:
		from modules.kodi_utils import logger
		logger('presign gate', 'skipped: local clock appears to be behind')
		return sources
	kept, dropped = [], 0
	for s in sources:
		exp = presign_expiry(get(s))
		if exp is None:
			kept.append(s); continue
		if exp < now - PRESIGN_GRACE:
			dropped += 1; continue
		s[mark] = True
		kept.append(s)
	if dropped:
		from modules.kodi_utils import logger
		logger('presign gate', 'dropped %d expired of %d' % (dropped, len(sources)))
	return kept

# LOCAL PATCH 2026-08-29: HDHub's transcoded HLS ladder, shared by both scrapers. /resolve/cj/tmdb/<id>/<res>.m3u8 rows
# are labelled by resolution but heavily compressed (a "4K" one runs ~8 Mbps). They play and report ~0 GB, so nothing
# else catches them. Matched on the endpoint, NOT '.m3u8' in general -- img1's index_NNN.m3u8 is a full-length stream.
_TRANSCODE_MARKER = '/resolve/cj/'


def is_transcode_url(url):
	"""True for HDHub's resolution-ladder HLS, which is not the release it claims to be."""
	return _TRANSCODE_MARKER in (url or '').lower()

# LOCAL PATCH 2026-09-01: release-name parsing shared by the subtitle scorer and SmartPlay's sticky matcher (here
# because modules/ must not import from indexers/). Not merged with normalize(), which strips accents instead.

def release_norm(text):
	"""Lowercase, with every release separator reduced to a single space.

	Padded with spaces at both ends so a needle like ' web ' cannot match inside a word.
	"""
	text = (text or '').lower()
	for ch in ('.', '_', '-', '[', ']', '(', ')', '+', "'", ','):
		text = text.replace(ch, ' ')
	return ' %s ' % ' '.join(text.split())


# LOCAL PATCH 2026-09-02: site tags that are legitimate release groups despite the dot.
# Deliberately a closed TLD list rather than r'\.[a-z]{2,4}$' -- the open form would also
# swallow '...-Something.2001' style title hyphens.
_SITE_TAG_RE = _LazyRe('_SITE_TAG_RE', r'^([a-z0-9]{2,})\.(com|net|org|to|me|cc|tv|io|co|info|xyz|site|link|pw|in|is|se|nu|ws|sx)$')

# LOCAL PATCH 2026-10-02: see _clean_group_token / release_group.
_NOT_GROUPS = frozenset(('dl', 'dv', 'br', 'la', 'lat', 'us', 'uk', 'hd', 'sd', 'hdr', 'sdr', 'rip', 'ma', 'x', 'ray',
	'eng', 'esp', 'spa', 'sub', 'subs', 'subbed', 'audio', 'x264', 'x265', 'h264', 'h265', 'ac3', 'eac3', 'aac',
	'hdma', 'subtitle', 'subtitles'))
# LOCAL PATCH 2026-10-15: tag words that also turn up bracketed after a hyphen ('-[1080p]', '-[MULTi]') -- not a '-[BATGirl]' group
_BRACKET_TAG_RE = _LazyRe('_BRACKET_TAG_RE', r'^(?:\d{3,4}[pi]|[248]k|uhd|multi|dual|vf[fiq2]?|vostfr|truefrench|french|ita|ger|jpn|hevc|avc|web|webrip|bluray|remux|proper|repack)$')
_TRAILING_LANG = _LazyRe('_TRAILING_LANG', r'(?:[.\s_]+(?:multi|dual|[a-z]{2,3}-(?:br|la|lat|mx|us|uk|pt|es)))+$', re.I)

# LOCAL PATCH 2026-09-03: tails that are an episode marker rather than a releaser.
_EPISODE_TOKEN_RE = _LazyRe('_EPISODE_TOKEN_RE', r'^(?:s\d{1,3}e\d{1,4}|e\d{1,4}|ep\d{1,4}|\d{1,4})(?:v\d{1,2})?$')


# LOCAL PATCH 2026-09-03: the group-token rules, shared by release_group's pipe and hyphen paths. A site tag may carry
# ONE dot plus a known TLD (stripped); anything else dotted is release metadata, not a group.
def _clean_group_token(raw):
	tok = re.split(r'[\[\](){}]', raw or '')[0].strip().lower()
	if '.' in tok:
		m = _SITE_TAG_RE.match(tok)
		if not m: return ''
		tok = m.group(1)
	if not tok or ' ' in tok or len(tok) > 20: return ''
	if tok.isdigit(): return ''
	# LOCAL PATCH 2026-09-03: an EPISODE MARKER after the final separator ('Re.Zero - S04E01v2') is not a group --
	# SmartPlay's same-release tier compares groups across episodes.
	if _EPISODE_TOKEN_RE.match(tok): return ''
	# LOCAL PATCH 2026-10-02: the second half of a hyphenated TAG, never a releaser -- 'WEB-DL', 'HDR-DV', 'PT-BR', 'DTS-HD'
	if tok in _NOT_GROUPS: return ''
	return tok

_TECH_GROUP_PAREN = _LazyRe('_TECH_GROUP_PAREN', r'^(.*?(?:[xh][ ._]?26[45]|hevc|avc|av1|xvid|web[ ._-]?dl|webrip|bluray|remux|aac[\d.]*|e?ac3|ddp?[\d.]*|flac|opus)'
	r'-[A-Za-z0-9]+)[\s._]*\([^()]*\)\s*$', re.I)

# LOCAL PATCH 2026-10-25 (4.0.5): memoised -- pure, and called for the same names again and again (the known-group sort boost
# twice per row, the picker, SmartPlay's tiers)
@lru_cache(maxsize=4096)
def release_group(name):
	"""Release group -- the token after the final '-', where scene and p2p names put it.

	Parsed from the RAW name, before _norm() would eat the hyphen. Returns '' when the name
	does not follow the convention, so a hyphen inside a title cannot masquerade as a group.
	"""
	# LOCAL PATCH 2026-10-06: stray dots after the extension too -- mediafusion lists 'H264-ENIGMA-[DUS-IcTv].mkv.'
	name = re.sub(r'\.(mkv|mp4|avi|m2ts|ts|srt|vtt|ass|ssa|sub)$', '', (name or '').strip().rstrip('.'), flags=re.I)
	# LOCAL PATCH 2026-09-03: some sources put the tag after a PIPE ('... pixeldrain | 4KHDHub'), where the hyphen rule
	# reads garbage. The LAST pipe field gives '4khdhub', the same token as '-4kHdHub.Com'. Tried first; falls through
	# when the pipe field is not a clean token.
	if '|' in name:
		_piped = _clean_group_token(name.rsplit('|', 1)[1])
		# LOCAL PATCH 2026-09-27: but the site is only the group when the name inside the decoration has none of its own
		# (http_streams wraps every 4KHDHub file alike, '...H.264-DEV1L. pixeldrain | 4KHDHub'). Strip ' <host> | <site>'
		# and the truncated extension 4KHDHub leaves, read the hyphen group of the rest. The site still wins when that is
		# empty or is the site's own name cut short ('-4kH', '-4kHd').
		_inner = re.sub(r'\s+\S+\s*\|[^|]*$', '', name)
		_inner = re.sub(r'\.(?:m|mk|mkv|mp|mp4)?$', '', _inner, flags=re.I)
		_own = _clean_group_token(_inner.rsplit('-', 1)[1]) if _inner != name and '-' in _inner else ''
		if _own and not (_piped and _piped.startswith(_own)): return _own
		if _piped: return _piped
	# LOCAL PATCH 2026-10-02: trailing language tags go first -- 'REMUX-FraMeSToR.MULTI.PT-BR' read as group 'br'.
	name = _TRAILING_LANG.sub('', name)
	# LOCAL PATCH 2026-10-06: an uploader's bracketed tag AFTER the group ('H264-ENIGMA-[DUS-IcTv]'). The group in front
	# wins when there is one; else the bracket is read, so releasers signing inside it ('[XviD-R22]') keep their group.
	_tagged = re.match(r'^(.*?)[\s._-]*\[[^\[\]]*\]\s*$', name)
	# LOCAL PATCH 2026-10-15: a ROUND-bracket list after the group too ('-VARYG.(Title,.Dual-Audio,.Multi-Subs)'). Only a
	# list (a comma inside): 'Spider-Man (2002)' must not read the group 'man'.
	if not _tagged: _tagged = re.match(r'^(.*?)[\s._-]*\([^()]*,[^()]*\)\s*$', name)
	# LOCAL PATCH 2026-11-09: and that list with its commas dropped (torrentio: 'H.264-VARYG.(Nijusseiki.Denki.Mokuroku:.Eureka
	# .Evrika.Multi-Audio.Multi-Subs)'), read only when a codec / source / audio tag stands right before '-GROUP', so
	# 'X-Men.(Extended.Cut)' and 'Spider-Man (2002)' still read no group. A missed group made SmartPlay follow a VARYG pin
	# to another releaser's copy.
	if not _tagged: _tagged = _TECH_GROUP_PAREN.match(name)
	if _tagged and '-' in _tagged.group(1):
		_before = release_group(_tagged.group(1))
		if _before: return _before
	# LOCAL PATCH 2026-10-15: the group ITSELF bracketed after the hyphen ('H265-[BATGirl].mkv') -- the token cleaner cuts
	# at the first bracket. Only with no group in front (the block above already returned those).
	_own_bracket = re.search(r'-\[([^\[\]\-]+)\]\s*$', name)   # no hyphen inside: '-[WEB-DL]' / '-[Dual-Audio]' are tags
	if _own_bracket:
		_tok = _clean_group_token(_own_bracket.group(1))
		if _tok and not _BRACKET_TAG_RE.match(_tok): return _tok
	if '-' not in name: return _leading_group(name)
	tail = name.rsplit('-', 1)[1]
	# NOT 'a hyphen inside brackets is never the group': Polish releasers sign that way ('[XviD-R22]', '[x265-AdL]',
	# '[AC3-OzW]'). The bracketed junk ('[WEB-DL]', '[ESP-ENG]', '[Dual-Audio]', '[Multi-Subs]') is all tag words,
	# which _NOT_GROUPS rejects wherever they stand.
	# A real group token is not just digits; a tail with a dot is usually a hyphen from
	# the title itself ('A-Movie-With-Hyphens.2001.1080p'), not a group.
	# LOCAL PATCH 2026-09-02: except a SITE TAG ('-4KHDHub.com'): ONE dot and a known TLD, unlike the title-hyphen case
	# ('hyphens.2001.1080p'). The TLD is stripped, so every spelling of a site normalises to one group.
	return _clean_group_token(tail) or _leading_group(name)

# LOCAL PATCH 2026-10-19: the fansub form puts the group IN FRONT ('[SubsPlease] Sousou no Frieren - 01 (1080p)'). Only a
# FALLBACK: a name whose tail names a group keeps it. Host labels http_streams puts in front ('[PixelDrain]') and
# bracketed tags ('[1080p]') are not groups.
_LEAD_GROUP_RE = _LazyRe('_LEAD_GROUP_RE', r'^\s*\[([^\[\]]{2,24})\]')
_HOST_LABELS = frozenset(('pixeldrain', 'fsl', 'fslv2', 'hubcdn', 'hubcloud', 'gdflix', 'gofile', 'buzzheavier', 'mega', 'direct'))

def _leading_group(name):
	m = _LEAD_GROUP_RE.match(name or '')
	if not m: return ''
	tok = _clean_group_token(m.group(1))
	if not tok or tok in _HOST_LABELS or _BRACKET_TAG_RE.match(tok): return ''
	return tok

# LOCAL PATCH 2026-10-19: one reading of a size's number for the scrapers, magneto's rule (source_utils._size): a comma
# followed by one or two digits, with no dot in the number, is a decimal comma; otherwise thousands.
_DECIMAL_COMMA_RE = _LazyRe('_DECIMAL_COMMA_RE', r',\d{1,2}$')

def size_number(text):
	"""'2,75' -> 2.75, '2,750' -> 2750.0, '1,234.5' -> 1234.5, '9.58' -> 9.58. Raises ValueError on garbage."""
	t = (text or '').strip()
	if '.' not in t and _DECIMAL_COMMA_RE.search(t): t = t.replace(',', '.')
	return float(t.replace(',', ''))

def same_group(a, b, min_prefix=3):
	"""release_group() results naming the same releaser. LOCAL PATCH 2026-09-27: 4KHDHub cuts names short, so
	one file lists as '-DEV1' and its twin as '-DEV1L'; a prefix of 3+ characters counts. Episode, source, quality
	and service are still checked by the caller (modules/smartplay_match.refusal) -- this only stops the group test
	rejecting a twin. A name the cut reached has no group at all there (smartplay_match.identity)."""
	if not a or not b: return False
	if a == b: return True
	short, long_ = (a, b) if len(a) < len(b) else (b, a)
	return len(short) >= min_prefix and long_.startswith(short)

# LOCAL PATCH 2026-09-27: 4KHDHub cuts the release name at 100 characters before http_streams decorates it, so a long
# title eats into the group ('-D' for DEV1L). Cut names measure exactly 100; uncut ones end in an extension.
_DECORATED_RE = _LazyRe('_DECORATED_RE', r'^(?:\[[^\]]+\]\s*)?(.*?)\s+\S+\s*\|[^|]*$')

def name_was_cut(name):
	"""True for an http_streams-DECORATED name ('<name> <host> | 4KHDHub', the form rows and pins carried before 4.0.25)
	whose release name hit 4KHDHub's 100-character cut. Today's undecorated rows: smartplay_match.was_cut (2026-11-09)."""
	m = _DECORATED_RE.match((name or '').strip())
	return bool(m) and len(m.group(1)) >= 100 and not re.search(r'\.(mkv|mp4|avi|m4v|ts)$', m.group(1), re.I)

# LOCAL PATCH 2026-10-08: HDR10 / HDR10+ / HDR10P / bare HDR; 'HdHub' is not one (no r after the d)
_HDR_NAMED = _LazyRe('_HDR_NAMED', r'(?<![a-z0-9])hdr(?:10(?:\+|p|plus)?)?(?![a-z0-9])', re.I)

def release_dynamic_range(name):
	"""LOCAL PATCH 2026-10-08: 'dv', 'hdr' or 'sdr' as the name states it, '' when it cannot say. A DV release with an
	HDR layer is 'dv'. A name 4KHDHub cut that names neither is '' rather than 'sdr': the cut usually falls right where
	DV.HDR would be. http_streams adds the site's own 'HDR DV' tags after a cut name, so a cut DV row still reads 'dv'."""
	name = str(name or '')
	if _DV_NAMED.search(name): return 'dv'
	if _HDR_NAMED.search(name): return 'hdr'
	return '' if name_was_cut(name) else 'sdr'



def release_source(norm_text):
	"""Source family, '' when the name says nothing about it.

	Order matters: the specific spellings must be tested before the generic ones, or
	'web dl' is caught by the bare 'web' test and a bdremux by 'bluray'.
	"""
	for needle, family in (
		(' bdremux ', 'remux'), (' remux ', 'remux'),
		(' bluray ', 'bluray'), (' blu ray ', 'bluray'), (' bdrip ', 'bluray'), (' brrip ', 'bluray'),
		(' web dl ', 'web'), (' webdl ', 'web'), (' webrip ', 'web'), (' web ', 'web'),
		(' uhdtv ', 'hdtv'), (' hdtv ', 'hdtv'), (' dvdrip ', 'dvd'), (' dvd ', 'dvd'), (' hdrip ', 'hdrip')):
		if needle in norm_text: return family
	return ''

def release_service(norm_text):
	"""Streaming service a WEB release came from, '' when the name does not say.

	LOCAL PATCH 2026-09-01. release_source() lumps every WEB platform together -- fine for
	subtitles, too loose for a SmartPlay pin: NF and CR WEB-DLs from one group are different
	masters, with their own encodes and intro placement.

	Tags kept unambiguous once separators become spaces. Notably ABSENT: 'ma' (the MA in
	'DTS-HD.MA') and any other two-letter token that collides with an audio or codec field.
	"""
	for tag in (' nf ', ' amzn ', ' dsnp ', ' hmax ', ' atvp ', ' hulu ', ' cr ', ' funi ',
		' hidive ', ' pcok ', ' stan ', ' crav ', ' viu ', ' tving ', ' adn ', ' starz ',
		' mubi ', ' roku ', ' itunes ', ' aniplus ', ' bilibili ', ' b global '):
		if tag in norm_text: return tag.strip()
	return ''

# LOCAL PATCH 2026-10-19: shared by aiostreams and http_streams.
def is_valid_http_url(url):
	"""Strict http/https URL validation. Rejects: empty/non-string, control chars,
	non-http(s) schemes (magnet/ftp/file/data/javascript/etc.), missing host,
	localhost / obvious placeholders, absurdly long blobs."""
	if not url or not isinstance(url, str): return False
	url = url.strip()
	if not url or len(url) > 8000: return False
	if any(c in url for c in ('\n', '\r', '\t', '\0', ' ')): return False
	lower = url.lower()
	if not (lower.startswith('http://') or lower.startswith('https://')): return False
	try:
		from urllib.parse import urlparse
		p = urlparse(url)
		if p.scheme not in ('http', 'https'): return False
		host = (p.hostname or '').lower()
		if not host: return False
		if host in ('localhost', 'example.com', 'placeholder', '0.0.0.0'): return False
		return True
	except Exception: return False


# LOCAL PATCH 2026-10-25: two shows with one title (Avatar: The Last Airbender 2005 / 2024) -- every provider, ID-searched
# ones included, returns the other show's episode under the same SxxEyy. No extra request: a clash is read from the
# results (scene names add the year only to a title that needs it), and a name is suspect when its episode title is not
# ours. Suspects are demoted and marked, never dropped (sources.demote_namesake): spellings differ from TMDb's.
_NS_STOP = _LazyRe('_NS_STOP', r'^(?:\d{3,4}[pi]|[48]k|uhd|hd|sd|web|webdl|webrip|web-dl|bluray|blu-ray|bdrip|brrip|bdremux|remux|hdtv|'
	r'dvd|dvdrip|dvd5|dvd9|x26[45]|h26[45]|hevc|avc|av1|xvid|nf|amzn|atvp|dsnp|hmax|max|hulu|pmtp|cr|stan|it|'
	r'ddp?\d*|dd|aac\d*|ac3|eac3|dts|truehd|atmos|flac|opus|\d+bit|multi|dual|repack|proper|internal|complete|season|'
	r'hdr|hdr10|dv|sdr|ita|eng|hin|hindi|rus|ger|fre|spa|esp|lat|sub|subs|esub|esubs|dubbed|mkv|mp4|avi|'
	r'french|truefrench|vf|vff|vfq|vostfr|german|spanish|italian|russian|polish|pl|castellano|latino|\w*dub|\w*sub|'
	# LOCAL PATCH 2026-10-25 (4.0.5): release tags that are not episode titles ('READNFO', '.Extended.', '.Lektor.PL.')
	r'readnfo|nfofix|dirfix|extended|uncensored|uncut|unrated|hybrid|lektor|dl|nordic|pcok|ma|ip|crav|rerip|limited|subbed|'
	r'remastered|imax)$', re.I)
_NS_SMALL = frozenset(('the', 'a', 'an', 'and', 'of', 'to', 'in', 'on', 'at', 'for', 'part'))
_NS_PLACEHOLDER = _LazyRe('_NS_PLACEHOLDER', r'^(?:episode|chapter|part|ep)\s*\d+$', re.I)


def _ns_words(text):
	return [w for w in re.split(r'[^a-z0-9]+', (text or '').lower()) if w]


def namesake_clash(names, title):
	"""True when a result names the show as '<title>.<year>.SxxEyy' -- the scene's mark of a title two shows share."""
	key = ''.join(_ns_words(title))
	if not key: return False
	for name in names or ():
		m = re.search(r'(?<![a-z0-9])s\d{1,3}\.?e\d{1,4}(?![0-9])', (name or '').lower())
		if not m: continue
		pre = ''.join(_ns_words(name[:m.start()]))
		if pre.startswith(key) and re.fullmatch(r'(?:19|20)\d{2}', pre[len(key):]): return True
	return False


def episode_title_mismatch(name, season, episode, ep_title, year=None):
	"""True when `name` carries an episode title after its SxxEyy and it is not `ep_title`; False when it matches, when
	the name has none (or only an absolute number), when ours is a placeholder ('Episode 3'), or when the name carries
	our own year before the SxxEyy ('Avatar.The.Last.Airbender.2024.S02E03.FRENCH...': the year says which show)."""
	try: s, e = int(season), int(episode)
	except (TypeError, ValueError): return False
	ours = [w for w in _ns_words(ep_title) if w not in _NS_SMALL]
	if not ours or _NS_PLACEHOLDER.match((ep_title or '').strip()): return False
	m = re.search(r'(?<![a-z0-9])(?:s0*%d\.?e0*%d|%dx0*%d)(?![0-9])' % (s, e, s, e), (name or '').lower())
	if not m: return False
	if year and str(year)[:4] in _ns_words(name[:m.start()]): return False
	theirs = []
	for word in _ns_words(name[m.end():]):
		if _NS_STOP.match(word): break
		if word.isdigit() and not theirs: continue   # an absolute number first ('S02E03.23.Return.To.Omashu')
		theirs.append(word)
	theirs = [w for w in theirs if w not in _NS_SMALL and not w.isdigit()]
	if not theirs: return False
	if ' '.join(ours) in ' '.join(theirs) or ' '.join(theirs) in ' '.join(ours): return False
	shared = len(set(ours) & set(theirs))
	return shared < max(1, min(len(ours), len(theirs)) / 2.0)


def resolve_reporter(service, info_hash, season, episode, title, redact=None):
	"""LOCAL PATCH 2026-11-08: the shared `_why` for every debrid resolve_magnet. Returns a function that says
	why a resolve gave up, in kodi.log and on screen (sources.RESOLVE_REASON_PROP). The reason is passed through `redact` first
	(default modules.utils.redact_url; Real-Debrid hands its own, which masks ?auth_token=) so no token reaches a shared log."""
	def _why(reason):
		try:
			from modules.kodi_utils import logger, set_property
			if redact is None:
				from modules.utils import redact_url as _redact
			else: _redact = redact
			reason = _redact(str(reason))
			logger('%s resolve' % service, '%s S%sE%s %s: %s' % (info_hash, season, episode, title, reason))
			set_property('deadlight.resolve_reason', '%s: %s' % (service, reason))
		except Exception: pass
	return _why
