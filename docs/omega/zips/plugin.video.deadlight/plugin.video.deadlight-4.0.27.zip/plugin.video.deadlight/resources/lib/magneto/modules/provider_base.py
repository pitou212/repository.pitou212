"""
	LOCAL PATCH 2026-11-01 (cleanup): the two provider families' shared bodies, which each provider used to carry a copy of.

	StremioSource -- the id-searched (Stremio-addon style) providers: torrentio, comet, mediafusion, meteor, torrentsdb,
	torz, bitmagnet. One request per episode / film; the season and show pack calls search nothing of their own and judge
	the answer sources() fetched (source_utils.SourceRegistry). A provider sets its links and overrides the hooks it needs:
	  _search_url(data, q)   the request (q: the search, see _query)        _fetch(url, data, q)  the rows the request gives
	  _rows(files)           iterate them                                    _parse(file)          (hash, title lines, info)
	  _seeders(info)/_size(info)  read the info (raise -> 0)                 _episode_ok / _pack_ok  title + anime checks
	  _tag(item, name, data, q)   extra row fields                           _finish(rows)          a last pass over the rows

	NameSearchSource -- the providers searched by NAME: apibay, knaben, torlock, torrentgalaxy, torrentscsv. One query per
	episode / film (two for a date-released show), two per pack kind in parallel threads; each sets its link, field names
	and _rows / _valid (and _url / _request / _prepare where they differ).
"""

import re
from json import loads as jsloads
from threading import Lock
from urllib.parse import quote
from magneto.modules import anime_utils
from magneto.modules import client
from magneto.modules import source_utils
from magneto.modules import workers

_SIZE = re.compile(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))')
_NOT_TITLE = r'[^A-Za-z0-9\s\.-]+'


def search_title(title):
	return title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')


def magnet(hash, name):
	return 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)


# LOCAL PATCH 2026-10-05: on anime, judge the FILE the provider picked (behaviorHints.filename) as well as the release
# name -- archives, art, music, scans (anime_utils.stremio_junk); a file claiming a LATER season is a mis-file even on an
# id-scoped answer (anime_utils.later_season_reject); 'act II' under Ace S2 (foreign_cour_marked); a remake /
# live-action series (other_show_year). torrentio and meteor.
def anime_file_reject(file_name, release, title, data):
	if anime_utils.stremio_junk(file_name or release, [title] + anime_utils.alias_titles(data)): return True
	if anime_utils.later_season_reject([file_name, release], data): return True
	if anime_utils.foreign_cour_marked(file_name, data) or anime_utils.foreign_cour_marked(release, data): return True
	return bool(anime_utils.other_show_year(release, data) or anime_utils.other_show_year(file_name, data))


# LOCAL PATCH 2026-10-05: on anime, a pack named for a LATER season is not this one (anime_utils.later_season_reject;
# filter_season_pack reads 'II' as nothing), nor a remake's, nor another cour's. torrentio and meteor.
def anime_pack_reject(release, file_name, package, data):
	if package == 'season' and anime_utils.later_season_reject([release, file_name], data): return True
	return bool(anime_utils.other_show_year(release, data) or anime_utils.foreign_cour_marked(release, data))


_VIDEO_END = re.compile(r'\.(?:mkv|mp4|avi|m4v|ts|wmv|webm)\W*$', re.I)   # LOCAL PATCH 2026-11-04: see tag_batch

def tag_batch(item, name, data, true_size):
	"""LOCAL PATCH 2026-10-03: an id-scoped anime batch ('[DB] Diamond no Ace [BD1080p]') said nothing about being one, so
	playback took the single-file path. Tagged like nyaa's (anime_utils.batch_fields); true_size when the provider's size
	is the episode file's, so DeadLight does not divide it (comet, meteor)."""
	_m = anime_utils._extract_meta(anime_utils._clean_for_extract(name))
	# LOCAL PATCH 2026-11-04: ONE file is no batch, though _extract_meta reads no episode in it -- a name ending in a
	# video extension ('Naruto.212.mkv'), or a number straight after the show's title ('... Stone Ocean 01 (1080p)').
	# Tagged as 'season' packs they would skip the release judge's single-episode checks.
	if not _m[1]:
		if _VIDEO_END.search(name or ''): return
		try: _titles = [t for t in [data.get('tvshowtitle')] + list(anime_utils.alias_titles(data) or []) if t]
		except Exception: _titles = []
		if _titles and anime_utils.whole_run_episode(name, _titles) is not None: return
	_fields = anime_utils.batch_fields(name, _m[1], _m[3], data.get('season_length'))
	if not true_size: item.update(_fields)
	elif _fields: item.update(_fields, true_size=True)


def _card_seasons(data, tried):
	"""LOCAL PATCH 2026-11-07 (phase 2d): the regular seasons an anime episode is known by besides those already `tried` --
	cour_season (TVDB's) and the seasons of data['episode_candidates'] (DeadLight's episode card), as strings, in that order."""
	out, skip = [], set(str(t) for t in tried if t is not None)
	for s in [data.get('cour_season')] + [c[0] for c in (data.get('episode_candidates') or []) if isinstance(c, (list, tuple)) and c]:
		try: s = int(s)
		except (TypeError, ValueError): continue
		if s > 0 and str(s) not in skip and str(s) not in out: out.append(str(s))
	return out


class StremioSource(source_utils.SourceRegistry):
	timeout = 10
	pack_capable = True
	hasMovies = True   # read by indexers/dialogs.py's provider test
	hasEpisodes = True
	provider = ''           # the rows' 'provider', and the name in the error log
	pack_true_size = True   # pack rows' size is the EPISODE file's, not the pack's: DeadLight must not divide it
	archie = True           # check_title reads the name without '.(Archie.Bunker'
	base_link = ''
	movieSearch_link = '/stream/movie/%s.json'
	tvSearch_link = '/stream/series/%s:%s:%s.json'
	_INFO = re.compile(r'💾.*')
	_SEEDERS = re.compile(r'👤\s*(\d+)')

	def __init_subclass__(cls, **kwargs):
		# LOCAL PATCH 2026-10-06: one future per search (source_utils.SourceRegistry), not the class-wide queue -- a registry
		# of its own for each provider class
		super().__init_subclass__(**kwargs)
		cls._lock, cls._cache = Lock(), {}

	# ---- hooks
	def _title(self, data):
		return search_title(data['tvshowtitle'] if 'tvshowtitle' in data else data['title'])

	def _query(self, data):
		q = {'tv': 'tvshowtitle' in data, 'title': self._title(data), 'aliases': data['aliases'], 'year': data['year'], 'imdb': data['imdb'], 'years': None}
		if q['tv']:
			q.update(season=data['season'], episode=data['episode'], episode_title=data['title'])
			q['hdlr'] = 'S%02dE%02d' % (int(q['season']), int(q['episode']))
			q['air_date'] = data.get('premiered')   # LOCAL PATCH 2026-10-24: date-named releases (source_utils.air_date_pattern)
			# LOCAL PATCH 2026-11-07: asked in Stremio's numbering (stremio_se: a cour TMDb files in one long season), the rows
			# are named in it (Tokyo Revengers TMDb S1E25 = Stremio 2:1, 'S02E01'). Both pairs pass here; the release judge keeps
			# the right ones by the episode card's own pairs.
			_se = source_utils.stremio_se(data, q['season'], q['episode'])
			q['alt_hdlr'] = 'S%02dE%02d' % (int(_se[0]), int(_se[1])) if (str(_se[0]), str(_se[1])) != (str(q['season']), str(q['episode'])) else None
			q['alt_season'] = str(_se[0]) if q['alt_hdlr'] and str(_se[0]) != str(q['season']) else None
		else: q.update(episode_title=None, hdlr=q['year'], air_date=None)
		return q

	def _search_url(self, data, q):
		if q['tv']: return '%s%s' % (self.base_link, self.tvSearch_link % ((q['imdb'],) + source_utils.stremio_se(data, q['season'], q['episode'])))   # LOCAL PATCH 2026-10-25 (4.0.5)
		return '%s%s' % (self.base_link, self.movieSearch_link % q['imdb'])

	def _fetch(self, url, data, q):
		return jsloads(client.request(url, timeout=self.timeout))['streams']

	def _rows(self, files):
		# LOCAL PATCH 2026-11-04: a stream with no infoHash is no torrent (Meteor answers an empty search with a placeholder
		# stream) -- skipped quietly. Only where the base _parse reads infoHash: torz's own _parse reads 'hash'.
		if type(self)._parse is StremioSource._parse:
			return [f for f in (files or []) if not isinstance(f, dict) or f.get('infoHash')]
		return files

	def _lines(self, file):
		return (file.get('title') or file['description']).split('\n')

	def _info_line(self, lines):
		# LOCAL PATCH 2026-11-05: '' when no line carries the size / seeders (_item reads that as 0 / unknown) -- MediaFusion's
		# RSS-feed rows have none, and an IndexError dropped a good release.
		return next((x for x in lines if self._INFO.search(x)), '')

	def _parse(self, file):
		"""(hash, the title lines -- the first is the release name --, what _seeders / _size read); raise to skip the row."""
		lines = self._lines(file)
		return file['infoHash'], lines, self._info_line(lines)

	def _seeders(self, info):
		return self._SEEDERS.search(info).group(1)

	def _size(self, info):
		return source_utils._size(_SIZE.search(info).group(0))

	def _filename(self, file, lines):
		return (file.get('behaviorHints') or {}).get('filename') or ''

	def _keep_file_name(self, item, file, lines):
		# LOCAL PATCH 2026-11-04 (release judge, phase 4b): the file the provider picked inside the torrent, on the row -- the judge
		# (modules/release_judge) reads it for torrentio's and meteor's former file checks (anime_file_reject)
		try:
			fn = self._filename(file, lines)
			if fn: item['file_name'] = fn
		except Exception: pass

	def _check_title(self, name, q):
		if self.archie: name = name.replace('.(Archie.Bunker', '')
		if source_utils.check_title(q['title'], q['aliases'], name, q['hdlr'], q['year'], q['years'], air_date=q['air_date'], id_matched=True): return True
		return bool(q.get('alt_hdlr')) and source_utils.check_title(q['title'], q['aliases'], name, q['alt_hdlr'], q['year'], q['years'],
			air_date=q['air_date'], id_matched=True)   # LOCAL PATCH 2026-11-07: Stremio's pair (see _query)

	def _episode_ok(self, file, lines, name, data, q):
		return self._check_title(name, q)

	def _pack_ok(self, file, lines, name, package, data):
		return True

	def _tag(self, item, name, data, q):
		pass

	def _finish(self, rows):
		return rows

	# ---- the shared bodies
	def _item(self, hash, name, name_info, info):
		url = magnet(hash, name)
		try: seeders = int(self._seeders(info))
		except: seeders = 0
		quality = source_utils.get_release_quality(name_info, url)[0]
		try: dsize, isize = self._size(info)
		except: dsize, isize = 0, ''
		return {'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True, 'provider': self.provider, 'hash': hash,
				'url': url, 'name': name, 'name_info': name_info, 'quality': quality, 'info': isize, 'size': dsize, 'seeders': seeders}

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		future = self.start_future(data)
		try:
			q = self._query(data)
			url = self._search_url(data, q)
			try: files = self._fetch(url, data, q)
			except:
				files = []
				raise
			finally:
				source_utils.set_future(future, files)
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.set_future(future, [])
			source_utils.scraper_error(self.provider)
			return sources

		for file in self._rows(files):
			try:
				hash, lines, info = self._parse(file)
				name = source_utils.clean_name(lines[0])
				if not self._episode_ok(file, lines, name, data, q): continue
				name_info = source_utils.info_from_name(name, q['title'], q['year'], q['hdlr'], q['episode_title'])
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue
				item = self._item(hash, name, name_info, info)
				self._keep_file_name(item, file, lines)
				self._tag(item, name, data, q)
				sources.append(item)
			except:
				source_utils.scraper_error(self.provider)
		return self._finish(sources)

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		sources = []
		if not data: return sources
		try:
			title = search_title(data['tvshowtitle'])
			aliases = data['aliases']
			imdb = data['imdb']
			year = data['year']
			season = data['season']
			# LOCAL PATCH 2026-11-07: Stremio's season too when the episode was asked in its numbering (_query's alt_season):
			# Tokyo Revengers TMDb S1E25 = Stremio 2:1, answered with 'Season 2' packs
			alt_season = self._query(data).get('alt_season')
			files = self.wait_future(data, self.timeout + 1)
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error(self.provider)
			return sources

		for file in self._rows(files):
			try:
				hash, lines, info = self._parse(file)
				name = source_utils.clean_name(lines[0])
				episode_start, episode_end = 0, 0
				if not search_series:
					if not bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, season, name.replace('.(Archie.Bunker', ''))
						if not valid and alt_season:
							valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, alt_season, name.replace('.(Archie.Bunker', ''))
						# LOCAL PATCH 2026-11-07 (anime core plan phase 2d): on anime, also the episode card's own seasons -- TVDB's
						# (cour_season) and every season among its episode candidates (the releases' numbering where it differs).
						# filter_season_pack still decides that the row IS a season pack; the release judge decides if it is ours.
						if not valid and data.get('is_anime'):
							for _alt in _card_seasons(data, (season, alt_season)):
								valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, _alt, name.replace('.(Archie.Bunker', ''))
								if valid: break
						if not valid: continue
					package = 'season'
				else:
					if not bypass_filter:
						valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season, name.replace('.(Archie.Bunker', ''), total_seasons)
						if not valid: continue
					else: last_season = total_seasons
					package = 'show'
				if not self._pack_ok(file, lines, name, package, data): continue
				name_info = source_utils.info_from_name(name, title, year, season=season, pack=package)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue
				item = self._item(hash, name, name_info, info)
				self._keep_file_name(item, file, lines)
				item['package'] = package
				if self.pack_true_size: item['true_size'] = True
				if search_series: item['last_season'] = last_season
				elif episode_start: item.update(source_utils.pack_range_fields(episode_start, episode_end))   # LOCAL PATCH 2026-10-03: + pack_episodes for the size; # for partial season packs
				sources.append(item)
			except:
				source_utils.scraper_error(self.provider)
		return self._finish(sources)


class NameSearchSource:
	pack_capable = True
	hasMovies = True   # read by indexers/dialogs.py's provider test
	hasEpisodes = True
	provider = ''
	base_link = ''
	search_link = ''
	request_timeout = 5
	movie_category = tv_category = None   # passed to _url for the providers that search per category
	# the row's fields
	name_key, hash_key, seeders_key, size_key = 'name', 'hash', 'seeders', 'size'

	# ---- hooks
	def _url(self, category, query):
		return '%s%s' % (self.base_link, self.search_link % quote(query))

	def _request(self, category, query):
		return client.request(self._url(category, query), timeout=self.request_timeout)

	def _rows(self, results):
		"""The response's rows (dicts)."""
		raise NotImplementedError

	def _valid(self, row, hash):
		return len(hash) == 40

	def _prepare(self, data):
		pass

	# ---- the shared bodies
	def _query(self, category, query):
		"""The rows for one query that pass _valid, each hash once per scrape."""
		results = self._request(category, query)
		if not results: return []
		rows = []
		for row in self._rows(results):
			hash = (row.get(self.hash_key) or '').lower()
			if not self._valid(row, hash) or hash in self.seen: continue
			self.seen.add(hash)
			rows.append(row)
		return rows

	def _item(self, row, name, name_info):
		"""The common part of an episode / movie / pack row."""
		try: seeders = int(row.get(self.seeders_key) or 0)
		except: seeders = 0
		hash = row[self.hash_key].lower()
		url = magnet(hash, name)
		quality = source_utils.get_release_quality(name_info, url)[0]
		try: dsize, isize = source_utils.convert_size(float(row.get(self.size_key) or 0), to='GB')
		except: dsize, isize = 0, ''
		return {'provider': self.provider, 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name, 'name_info': name_info,
				'quality': quality, 'language': 'en', 'url': url, 'info': isize, 'direct': False, 'debridonly': True, 'size': dsize}

	def sources(self, data, hostDict):
		self.items = []
		if not data: return self.items
		self.seen = set()
		try:
			self._prepare(data)
			self.aliases = data['aliases']
			self.year = data['year']
			if 'tvshowtitle' in data:
				self.title = search_title(data['tvshowtitle'])
				self.episode_title = data['title']
				self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
				self.air_date = data.get('premiered')   # LOCAL PATCH 2026-10-24: date-named releases (source_utils.air_date_pattern)
				category = self.tv_category
			else:
				self.title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
				self.episode_title = None
				self.hdlr = self.year
				self.air_date = None
				category = self.movie_category
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			query = re.sub(_NOT_TITLE, '', self.title)
			self.get_sources(category, '%s %s' % (query, self.hdlr))
			if data.get('date_search') and self.air_date:   # LOCAL PATCH 2026-10-24: and by air date for a date-released show (source_utils.air_date_query)
				self.get_sources(category, '%s %s' % (query, source_utils.air_date_query(self.air_date)))
			return self.items
		except:
			source_utils.scraper_error(self.provider)
			return self.items

	def get_sources(self, category, query):
		try: rows = self._query(category, query)
		except:
			source_utils.scraper_error(self.provider)
			return
		for row in rows:
			try:
				name = source_utils.clean_name(row[self.name_key])
				if not source_utils.check_title(self.title, self.aliases, name, self.hdlr, self.year, air_date=self.air_date): continue
				name_info = source_utils.info_from_name(name, self.title, self.year, self.hdlr, self.episode_title)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				if not self.episode_title: # episodes returned by a movie query
					ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
					name_lower = name.lower()
					if any(re.search(item, name_lower) for item in ep_strings): continue
				self.items.append(self._item(row, name, name_info))
			except:
				source_utils.scraper_error(self.provider)

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		self.items = []
		if not data: return self.items
		self.seen = set()
		try:
			self._prepare(data)
			self.search_series = search_series
			self.total_seasons = total_seasons
			self.bypass_filter = bypass_filter
			self.title = search_title(data['tvshowtitle'])
			self.aliases = data['aliases']
			self.show_imdb = data['imdb']
			self.year = data['year']
			self.season_x = data['season']
			self.season_xx = self.season_x.zfill(2)
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			query = re.sub(_NOT_TITLE, '', self.title)
			if search_series: queries = [query + ' Season', query + ' Complete']
			else: queries = [query + ' S%s' % self.season_xx, query + ' Season %s' % self.season_x]
			threads = [workers.Thread(self.get_sources_packs, q) for q in queries]
			[i.start() for i in threads]
			[i.join() for i in threads]
			return self.items
		except:
			source_utils.scraper_error(self.provider)
			return self.items

	def get_sources_packs(self, query):
		try: rows = self._query(self.tv_category, query)
		except:
			source_utils.scraper_error(self.provider)
			return
		for row in rows:
			try:
				name = source_utils.clean_name(row[self.name_key])
				episode_start, episode_end = 0, 0
				if not self.search_series:
					if not self.bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(self.title, self.aliases, self.year, self.season_x, name)
						if not valid: continue
					package = 'season'
				else:
					if not self.bypass_filter:
						valid, last_season = source_utils.filter_show_pack(self.title, self.aliases, self.show_imdb, self.year, self.season_x, name, self.total_seasons)
						if not valid: continue
					else: last_season = self.total_seasons
					package = 'show'
				name_info = source_utils.info_from_name(name, self.title, self.year, season=self.season_x, pack=package)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				item = self._item(row, name, name_info)
				item['package'] = package
				if self.search_series: item['last_season'] = last_season
				elif episode_start: item.update(source_utils.pack_range_fields(episode_start, episode_end))   # LOCAL PATCH 2026-10-03: + pack_episodes for the size; # partial season packs
				self.items.append(item)
			except:
				source_utils.scraper_error(self.provider)
