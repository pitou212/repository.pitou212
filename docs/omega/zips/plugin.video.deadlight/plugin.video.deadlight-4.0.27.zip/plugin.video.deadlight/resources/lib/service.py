# -*- coding: utf-8 -*-
from xbmc import Monitor, getSkinDir
import os
import json
import inspect
from time import time
from threading import Thread
from caches.settings_cache import get_setting, set_setting, sync_settings
from modules import kodi_utils

pause_services_prop = 'deadlight.pause_services'
firstrun_update_prop = 'deadlight.firstrun_update'
current_skin_prop = 'deadlight.current_skin'
trakt_service_string = 'TraktMonitor Service Update %s - %s'
trakt_success_line_dict = {'success': 'Trakt Update Performed', 'no account': '(Unauthorized) Trakt Update Performed'}
# LOCAL PATCH 2026-07-23: MDBList background sync monitor — mirrors TraktMonitor.
mdblist_service_string = 'MDBListMonitor Service Update %s - %s'
mdblist_success_line_dict = {'success': 'MDBList Update Performed', 'no account': '(Unauthorized) MDBList Update Performed'}
# LOCAL PATCH 2026-07-29: SIMKL sync monitor string constants.
simkl_service_string = 'SIMKLMonitor Service Update %s - %s'
simkl_success_line_dict = {'success': 'SIMKL Update Performed', 'no account': '(Unauthorized) SIMKL Update Performed'}
update_string = 'Next Update in %s minutes...'
anilist_service_string = 'AniListMonitor Service Update %s - %s'

# LOCAL PATCH 2026-10-02: the sync monitors keep their interval across Kodi restarts. Syncing at every service start made a
# quick restart re-run all four, and a sync's widget reload landed in the home screen's first build. The first sync waits
# until due, never sooner than _BOOT_SETTLE seconds after start (a long-off Kodi still syncs at ~45 s). The times live in
# a small file, not settings.db: set_setting refuses ids without a default row.
_BOOT_SETTLE = 45
_last_sync_lock = __import__('threading').Lock()

def _last_sync_file():
	return os.path.join(kodi_utils.translate_path(kodi_utils.addon_info('profile')), 'service_last_sync.json')

def _read_last_syncs():
	try:
		with open(_last_sync_file(), 'r', encoding='utf-8') as f: return json.load(f)
	except Exception: return {}

def _mark_synced(name):
	with _last_sync_lock:
		data = _read_last_syncs()
		data[name] = int(time())
		path = _last_sync_file()
		try:
			with open(path + '.tmp', 'w', encoding='utf-8') as f: json.dump(data, f)
			os.replace(path + '.tmp', path)
		except Exception as e: kodi_utils.logger('DeadLight', 'last sync write failed (%s): %s' % (name, e))

def _wait_until_due(name, interval, wait_for_abort):
	"""True if Kodi is closing. Waits until `name` is due again (last sync + interval), at least _BOOT_SETTLE."""
	try: last = float(_read_last_syncs().get(name) or 0)
	except Exception: last = 0.0
	delay = max(_BOOT_SETTLE, last + interval - time())
	kodi_utils.logger('DeadLight', '%s first sync in %d s' % (name, delay))
	return wait_for_abort(delay)

class SetAddonConstants:
	def run(self):
		kodi_utils.logger('DeadLight', 'SetAddonConstants Service Starting')
		import random
		# LOCAL PATCH 2026-10-02: ONE Addon object; kodi_utils.addon_info builds a new xbmcaddon.Addon() per call (slow on the
		# boot thread).
		import xbmcaddon
		info = xbmcaddon.Addon('plugin.video.deadlight').getAddonInfo
		path, icon = info('path'), kodi_utils.translate_path(info('icon'))
		addon_items = [
			('deadlight.playback_key', str(random.randint(1000, 10000))),
			('deadlight.addon_name', info('name')),
			('deadlight.addon_version', info('version')),
			('deadlight.addon_path', path),
			('deadlight.addon_profile', kodi_utils.translate_path(info('profile'))),
			('deadlight.addon_icon', icon),
			('deadlight.addon_icon_mini', os.path.join(path, 'resources', 'media', 'addon_icons', 'minis', os.path.basename(icon))),
			('deadlight.addon_fanart', kodi_utils.translate_path(info('fanart')))
					]
		for item in addon_items: kodi_utils.set_property(*item)
		return kodi_utils.logger('DeadLight', 'SetAddonConstants Service Finished')

class DatabaseMaintenance:
	def run(self):
		kodi_utils.logger('DeadLight', 'DatabaseMaintenance Service Starting')
		# LOCAL PATCH 2026-05-26: defer 15 s so PRAGMA integrity_check doesn't block Kodi's boot path.
		# LOCAL PATCH 2026-09-04: then hold while a video plays (as every sync monitor here does), not a bigger delay.
		# integrity_check reads every byte of every DB on its own connections, and a later fixed delay (90 s) lands right when the
		# user presses play, stalling the stream. Contending with a widget build only slows widgets; with a video it stutters.
		monitor = kodi_utils.kodi_monitor()
		player = kodi_utils.kodi_player()
		if monitor.waitForAbort(15):
			return kodi_utils.logger('DeadLight', 'DatabaseMaintenance Service Finished')
		while player.isPlayingVideo() or kodi_utils.get_property(pause_services_prop) == 'true':
			if monitor.waitForAbort(10):
				return kodi_utils.logger('DeadLight', 'DatabaseMaintenance Service Finished')
		# LOCAL PATCH 2026-11-08: once a day, not every start -- it reads every byte of every database on the box's flash.
		# The marker's own 24 h expiry is the schedule, as the weekly purge below does.
		try:
			from caches.main_cache import main_cache as _mc
			_due = _mc.get('deadlight_integrity_check') is None
		except Exception: _mc, _due = None, True
		if _due:
			from caches.base_cache import check_databases_integrity
			check_databases_integrity(silent=True)
			try: _mc.set('deadlight_integrity_check', 'done', expiration=24)
			except Exception: pass
		# LOCAL PATCH 2026-09-26: weekly expired-row purge (see base_cache.purge_expired_rows). The
		# marker's own 168h expiry is the schedule, so it survives restarts with no extra setting.
		try:
			from caches.base_cache import purge_expired_rows
			from caches.main_cache import main_cache
			if main_cache.get('deadlight_expired_purge') is None:
				kodi_utils.logger('DeadLight', 'purged %d expired cache rows' % purge_expired_rows())
				# LOCAL PATCH 2026-10-27: and the chip strips no list has shown for a month (modules/chips.prune)
				try:
					from modules.chips import prune
					_n, _b = prune()
					kodi_utils.logger('DeadLight', 'pruned %d unused chip images (%.1f MB)' % (_n, _b / 1048576.0))
				except Exception as e: kodi_utils.logger('DeadLight', 'chip prune failed: %s' % e)
				main_cache.set('deadlight_expired_purge', 'done', expiration=168)
		except Exception as e: kodi_utils.logger('DeadLight', 'expired purge failed: %s' % e)
		return kodi_utils.logger('DeadLight', 'DatabaseMaintenance Service Finished')

class SyncSettings:
	def run(self):
		kodi_utils.logger('DeadLight', 'SyncSettings Service Starting')
		sync_settings()
		return kodi_utils.logger('DeadLight', 'SyncSettings Service Finished')

class OnUpdateChanges:
	def run(self):
		kodi_utils.logger('DeadLight', 'OnUpdateChanges Service Starting')
		try:
			for method in list(filter(lambda x: x[0] != 'run', inspect.getmembers(OnUpdateChanges, predicate=inspect.isfunction))):
				if not get_setting('deadlight.updatechecks.%s' % method[0], 'false') == 'true':
					method[1](self)
					set_setting('updatechecks.%s' % method[0], 'true')
		except Exception as e: kodi_utils.logger('DeadLight', 'OnUpdateChanges failed: %s' % e)
		return kodi_utils.logger('DeadLight', 'OnUpdateChanges Service Finished')

	# LOCAL PATCH 2026-08-29: cm_sort_order drops any item missing from the STORED order, so a new context entry is invisible
	# on an existing install without this. Same shape as register_drop_show_cm below.
	def register_anilist_manager_cm(self):
		for key in ('context_menu.enabled', 'context_menu.order'):
			stored = get_setting('deadlight.%s' % key, '')
			if not stored or 'anilist_manager' in stored.split(','): continue
			items = stored.split(',')
			try: idx = items.index('trakt_manager') + 1
			except ValueError: idx = len(items)
			items.insert(idx, 'anilist_manager')
			set_setting(key, ','.join(items))

	def register_drop_show_cm(self):
		for key in ('context_menu.enabled', 'context_menu.order'):
			stored = get_setting('deadlight.%s' % key, '')
			if not stored or 'drop_show' in stored.split(','): continue
			items = stored.split(',')
			try: idx = items.index('trakt_manager') + 1
			except ValueError: idx = len(items)
			items.insert(idx, 'drop_show')
			set_setting(key, ','.join(items))

class CustomWindowsPrepare:
	def run(self):
		kodi_utils.logger('DeadLight', 'CustomWindowsPrepare Service Starting')
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		kodi_utils.clear_property(current_skin_prop)
		# LOCAL PATCH 2026-05-26: defer the heavy windows.base_window import + ExtrasUtils().run() 15 s, off Kodi's boot path,
		# then start the font-monitor loop.
		if wait_for_abort(15):
			return kodi_utils.logger('DeadLight', 'CustomWindowsPrepare Service Finished')
		from windows.base_window import FontUtils, ExtrasUtils
		# LOCAL PATCH 2026-10-15: guarded -- one raise (e.g. a skin XML Kodi holds open -> Errno 22) ended the font / skin-change
		# watcher for the session. The wait honours abort.
		try: ExtrasUtils().run()
		except Exception as e: kodi_utils.logger('CustomWindowsPrepare', 'extras prepare failed: %s' % e)
		font_utils = FontUtils()
		while not monitor.abortRequested():
			# LOCAL PATCH 2026-11-08: skipped while a video plays (a JSON-RPC settings read every 20 s; no skin change then)
			if is_playing():
				if wait_for_abort(20): break
				continue
			try: font_utils.execute_custom_fonts()
			except Exception as e: kodi_utils.logger('CustomWindowsPrepare', 'custom fonts failed: %s' % e)
			if wait_for_abort(20): break
		return kodi_utils.logger('DeadLight', 'CustomWindowsPrepare Service Finished')

class GlassMonitor:
	# LOCAL PATCH 2026-10-24: measures the blur AF3 is showing (its Image_Search_Backdrop order) with glass.luminance, shared
	# for DeadLight's own windows. A skin cannot measure an image. AF3 keeps its own fixed tint. Idle while a video plays.
	# LOCAL PATCH 2026-11-11: AF3 without TMDb Helper names them AF3.* (script.af3.helper); the TMDbHelper.* names stay for
	# a skin still on TMDb Helper.
	BLURS = ('Window.Property(AF3.ListItem.BlurImage)', 'Window(Home).Property(AF3.ListItem.Current.BlurImage)',
			'Window.Property(TMDbHelper.ListItem.BlurImage)', 'Window(Home).Property(TMDbHelper.ListItem.Current.BlurImage)',
			'Window(Home).Property(Search.Backdrop)', 'Window(Home).Property(AF3.SimpleBackground.BlurImage)',
			'Window(Home).Property(TMDbHelper.SimpleBackground.BlurImage)')

	def run(self):
		from modules import glass
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		kodi_utils.clear_property('deadlight.glass.dim')   # LOCAL PATCH 2026-11-08: deadlight.glass.dim is no longer published (see below)
		last = None
		while not monitor.abortRequested():
			# LOCAL PATCH 2026-10-25 (4.0.5): 0.5 s ticks (up to 4 infolabel reads each), idle while services are paused.
			if monitor.waitForAbort(0.5): break
			# LOCAL PATCH 2026-11-08: idle at 5 s ticks while a video plays (AF3 draws no glass over video)
			if player.isPlayingVideo():
				if monitor.waitForAbort(4.5): break
				continue
			if kodi_utils.get_property(pause_services_prop) == 'true': continue
			# LOCAL PATCH 2026-11-02: only AF3 draws this glass; checked per tick, so switching skins needs no restart
			if getSkinDir() != 'skin.arctic.fuse.3':
				last = None
				continue
			blur = next((b for b in (kodi_utils.get_infolabel(i) for i in self.BLURS) if b), '')
			if blur == last: continue
			last = blur
			# LOCAL PATCH 2026-11-08: measured only -- shared as glass.luminance's deadlight.glass.lum so a DeadLight window opening
			# over this blur does not import Pillow itself. Not used to darken AF3's glass: AF3 and DeadLight stay independent, and
			# a darkening landing after the artwork made every screen open bright then drop.
			try: glass.luminance(blur)
			except Exception: pass

class WidgetPageWarmer:
	# LOCAL PATCH 2026-10-25 (4.0.5): warms the next page of the widgets that recorded one (modules/page_prefetch). It only
	# DECIDES when -- every 30 s: something recorded, no widget loaded for 30 s, nothing playing, services not paused -- and
	# starts the warm as its own plugin call, so module state never mixes. After a start it waits 10 minutes.
	def run(self):
		from modules.page_prefetch import widget_pages_due
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		if monitor.waitForAbort(60): return
		while not monitor.abortRequested():
			if monitor.waitForAbort(30): break
			if player.isPlaying() or kodi_utils.get_property(pause_services_prop) == 'true': continue
			self.compact_weekly()   # LOCAL PATCH 2026-11-10
			if not widget_pages_due(): continue
			kodi_utils.execute_builtin('RunPlugin(plugin://plugin.video.deadlight/?mode=page_prefetch.warm_widget_pages)')
			if monitor.waitForAbort(600): break

	_compact_checked = False
	def compact_weekly(self):
		"""LOCAL PATCH 2026-11-10: base_cache.compact_bloated once a week (a main_cache marker), after no widget has loaded for 60 s.
		The marker is read once per session; it is set only once a run went through."""
		if self._compact_checked: return
		try:
			from modules.page_prefetch import WIDGET_LAST_PROP
			try: last = float(kodi_utils.get_property(WIDGET_LAST_PROP) or 0)
			except ValueError: last = 0
			if time() - last < 60: return
			self._compact_checked = True
			from caches.main_cache import main_cache
			if main_cache.get('deadlight_compact') is not None: return
			from caches.base_cache import compact_bloated
			done = compact_bloated()
			main_cache.set('deadlight_compact', 'done', expiration=168)
			kodi_utils.logger('DeadLight', 'compacted %s' % (', '.join('%s %.1f -> %.1f MB' % d for d in done) or 'nothing (no cache over 30% free)'))
		except Exception as e: kodi_utils.logger('DeadLight', 'compact failed: %s' % e)

# LOCAL PATCH 2026-10-03 (3.0.8): a monitor about to sync the ACTIVE provider stamps the widgets' sync guard
# (watched_status._SYNC_GUARD_PROP), so a widget render in the next minute does not start the same sync alongside it.
# Not stamped for an inactive provider: the widgets would still need theirs.
def _stamp_widget_sync_guard(provider):
	try:
		from modules.settings import watched_indicators
		if watched_indicators() == provider: kodi_utils.set_property('deadlight.provider_sync_at', '%s:%s' % (provider, int(time())))
	except Exception: pass

# LOCAL PATCH 2026-11-01 (cleanup): the shell the four sync monitors share: wait until due, hold while a video plays or
# services are paused, one tick per interval. `tick(next_update_string)` is the provider's own sync and logging.
def _sync_loop(name, interval_fn, tick, service_string):
	monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
	wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
	if _wait_until_due(name, interval_fn()[1], wait_for_abort): return   # LOCAL PATCH 2026-10-02, see _wait_until_due
	while not monitor.abortRequested():
		# LOCAL PATCH 2026-10-15: leave on abort. waitForAbort returns True at once while Kodi quits; ignoring it left this loop
		# spinning and shutdown waiting on the thread.
		while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true':
			if wait_for_abort(10): break
		if monitor.abortRequested(): break
		wait_time = 1800
		try:
			sync_interval, wait_time = interval_fn()
			tick(update_string % sync_interval)
		except Exception as e: kodi_utils.logger('DeadLight', service_string % ('Failed', 'The following Error Occured: %s' % str(e)))
		wait_for_abort(wait_time)

class TraktMonitor:
	def run(self):
		kodi_utils.logger('DeadLight', 'TraktMonitor Service Starting')
		from apis.trakt_api import trakt_sync_activities
		from modules.settings import trakt_user_active, trakt_sync_interval, watched_indicators
		def tick(next_update_string):
			# LOCAL PATCH 2026-09-12: call trakt_user_active() -- the bare function object is always truthy, so a de-authenticated
			# Trakt logged 'Success'.
			if trakt_user_active():
				_stamp_widget_sync_guard(1)
				status = trakt_sync_activities()
			else: status = 'no_auth'
			if status != 'failed': _mark_synced('trakt')
			if status == 'failed': kodi_utils.logger('DeadLight', trakt_service_string % ('Failed. Error from Trakt', next_update_string))
			elif status == 'no_auth': kodi_utils.logger('DeadLight', trakt_service_string % ('Not Run. No Current Trakt Account', next_update_string))
			else:
				if status in ('success', 'no account'):
					kodi_utils.logger('DeadLight', trakt_service_string % ('Success. %s' % trakt_success_line_dict[status], next_update_string))
				else:
					kodi_utils.logger('DeadLight', trakt_service_string % ('Success. No Changes Needed', next_update_string))# 'not needed'
				# LOCAL PATCH 2026-10-03: as SIMKL below -- only when Trakt is the watched provider (1); otherwise the reload changes
				# nothing on screen.
				if status == 'success' and watched_indicators() == 1 \
					and get_setting('deadlight.trakt.refresh_widgets', 'false') == 'true':
					kodi_utils.auto_kodi_refresh('Trakt sync')
		_sync_loop('trakt', trakt_sync_interval, tick, trakt_service_string)
		return kodi_utils.logger('DeadLight', 'TraktMonitor Service Finished')

# LOCAL PATCH 2026-07-23: MDBList background sync, same shape as TraktMonitor.
class MDBListMonitor:
	def run(self):
		kodi_utils.logger('DeadLight', 'MDBListMonitor Service Starting')
		# LOCAL PATCH 2026-08-07 (POV OAuth port): mdbl_expires refreshes the OAuth access_token before a sync tick; no-op in
		# API-key mode.
		from apis.mdblist_api import mdbl_sync_activities, mdbl_expires
		from modules.settings import mdblist_user_active, mdblist_sync_interval
		def tick(next_update_string):
			if mdblist_user_active():
				try: mdbl_expires()  # refresh access_token if close to expiry (OAuth mode only)
				except Exception: pass
				_stamp_widget_sync_guard(2)
				status = mdbl_sync_activities()
			else: status = 'no_auth'
			if status != 'failed': _mark_synced('mdblist')
			if status == 'failed': kodi_utils.logger('DeadLight', mdblist_service_string % ('Failed. Error from MDBList', next_update_string))
			elif status == 'no_auth': kodi_utils.logger('DeadLight', mdblist_service_string % ('Not Run. No Current MDBList Account', next_update_string))
			else:
				if status in ('success', 'no account'):
					kodi_utils.logger('DeadLight', mdblist_service_string % ('Success. %s' % mdblist_success_line_dict[status], next_update_string))
				else:
					kodi_utils.logger('DeadLight', mdblist_service_string % ('Success. No Changes Needed', next_update_string))
				if status == 'success' and get_setting('deadlight.mdblist.refresh_widgets', 'false') == 'true':
					kodi_utils.auto_kodi_refresh('MDBList sync')
		_sync_loop('mdblist', mdblist_sync_interval, tick, mdblist_service_string)
		return kodi_utils.logger('DeadLight', 'MDBListMonitor Service Finished')


# LOCAL PATCH 2026-07-29: SIMKL background sync, same shape as MDBListMonitor. Polls /sync/activities; when a timestamp
# advances, invalidates list caches. Widgets reload only when SIMKL is the watched provider (watched_indicators == 3).
class SIMKLMonitor:
	def run(self):
		kodi_utils.logger('DeadLight', 'SIMKLMonitor Service Starting')
		from apis.simkl_api import simkl_sync_activities
		from modules.settings import simkl_user_active, simkl_sync_interval, watched_indicators
		def tick(next_update_string):
			if simkl_user_active():
				_stamp_widget_sync_guard(3)
				status = simkl_sync_activities()
			else: status = 'no_auth'
			if status != 'failed': _mark_synced('simkl')
			if status == 'failed': kodi_utils.logger('DeadLight', simkl_service_string % ('Failed. Error from SIMKL', next_update_string))
			elif status == 'no_auth': kodi_utils.logger('DeadLight', simkl_service_string % ('Not Run. No Current SIMKL Account', next_update_string))
			else:
				if status in ('success', 'no account'):
					kodi_utils.logger('DeadLight', simkl_service_string % ('Success. %s' % simkl_success_line_dict[status], next_update_string))
				else:
					kodi_utils.logger('DeadLight', simkl_service_string % ('Success. No Changes Needed', next_update_string))
				# LOCAL PATCH 2026-10-02: only when SIMKL is the watched provider (3); otherwise the reload changes nothing on screen.
				if status == 'success' and watched_indicators() == 3 \
					and get_setting('deadlight.simkl.refresh_widgets', 'true') == 'true':
					kodi_utils.auto_kodi_refresh('SIMKL sync')
		_sync_loop('simkl', simkl_sync_interval, tick, simkl_service_string)
		return kodi_utils.logger('DeadLight', 'SIMKLMonitor Service Finished')


# LOCAL PATCH 2026-08-29: AniList watchlist invalidation. AniList has no sync endpoint and is never the watched provider,
# so this only notices list changes made elsewhere and drops the cached list pages. One cheap Viewer query per interval.
class AniListMonitor:
	def run(self):
		kodi_utils.logger('DeadLight', 'AniListMonitor Service Starting')
		from apis.anilist_api import anilist_last_activity
		from caches.anilist_cache import clear_anilist_lists_cache
		from modules.settings import anilist_user_active, anilist_sync_interval
		def tick(next_update_string):
			if not anilist_user_active():
				kodi_utils.logger('DeadLight', anilist_service_string % ('Not Run. No Current AniList Account', next_update_string))
			else:
				activity = anilist_last_activity()
				if activity is not None: _mark_synced('anilist')
				if activity is None:
					kodi_utils.logger('DeadLight', anilist_service_string % ('Failed. Error from AniList', next_update_string))
				elif activity != get_setting('deadlight.anilist.last_activity', ''):
					set_setting('anilist.last_activity', activity)
					clear_anilist_lists_cache()
					kodi_utils.logger('DeadLight', anilist_service_string % ('Success. AniList Lists Refreshed', next_update_string))
					# LOCAL PATCH 2026-10-25: default off -- DeadLight's own anime scrobble moves AniList's activity, so every anime episode
					# ended in one more reload of every widget
					if get_setting('deadlight.anilist.refresh_widgets', 'false') == 'true':
						kodi_utils.auto_kodi_refresh('AniList sync')
				else:
					kodi_utils.logger('DeadLight', anilist_service_string % ('Success. No Changes Needed', next_update_string))
		_sync_loop('anilist', anilist_sync_interval, tick, anilist_service_string)
		return kodi_utils.logger('DeadLight', 'AniListMonitor Service Finished')


# LOCAL PATCH 2026-07-29: anime-mappings bootstrap, after the boot settles.
# LOCAL PATCH 2026-08-10: Fribb anime-lists is the sole mapping download (mal/anilist -> tmdb + season + episode_offset,
# all local); Otaku-Mappings retired (upstream frozen, far lower coverage).
# LOCAL PATCH 2026-10-05: checked every hour, not once at start (a box can run for weeks). download_mappings downloads only
# when Fribb's weekly list is newer than our copy (fribb_mappings._needs_download). Not while a video plays or services
# are paused.
def _bootstrap_anime_mappings():
	try:
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		if monitor.waitForAbort(_BOOT_SETTLE): return   # LOCAL PATCH 2026-11-08: not inside the first widget build
		from caches import fribb_mappings
		while not monitor.abortRequested():
			if not player.isPlayingVideo() and kodi_utils.get_property(pause_services_prop) != 'true':
				try: fribb_mappings.download_mappings(silent=True)
				except Exception as e: kodi_utils.logger('fribb_mappings refresh', str(e))
			if monitor.waitForAbort(3600): return
	except Exception as e:
		kodi_utils.logger('fribb_mappings bootstrap', str(e))


# LOCAL PATCH 2026-10-21 (from POV 6.10.17): default undesirables added later reach an existing keyword database (only an
# empty database got the defaults). One small SQLite read per start.
class UndesirablesDefaults:
	def run(self):
		try:
			from magneto.modules import undesirables
			undesirables.Undesirables().check_database()
			added = undesirables.add_new_default_keywords()
			if added: kodi_utils.logger('DeadLight', 'Undesirables: %d new default keyword(s) added: %s' % (len(added), ', '.join(added)))
		except Exception as e: kodi_utils.logger('DeadLight', 'Undesirables defaults failed: %s' % e)


class UpdateCheck:
	def run(self):
		if kodi_utils.get_property(firstrun_update_prop) == 'true': return
		kodi_utils.logger('DeadLight', 'UpdateCheck Service Starting')
		from modules.settings import update_action, update_delay
		# LOCAL PATCH 2026-10-02: update action 3 is Off -- update_check() returns at once for it, so there is nothing to
		# wait for; skip the updater import and the delay loop.
		if update_action() == 3:
			kodi_utils.set_property(firstrun_update_prop, 'true')
			return kodi_utils.logger('DeadLight', 'UpdateCheck Service Finished (updates off)')
		from modules.updater import update_check
		end_pause = time() + update_delay()
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			# LOCAL PATCH 2026-10-15: every wait leaves on abort; otherwise the update check (download, add-on reload) ran during
			# shutdown.
			aborted = False
			while not aborted and time() < end_pause: aborted = wait_for_abort(1)
			while not aborted and (kodi_utils.get_property(pause_services_prop) == 'true' or is_playing()): aborted = wait_for_abort(1)
			if aborted or monitor.abortRequested(): break
			# LOCAL PATCH 2026-11-08: at most once a day (4-6 s of network at every start; Kodi's repository checks it too)
			try:
				from caches.main_cache import main_cache as _mc
				if _mc.get('deadlight_update_check') is not None:
					kodi_utils.logger('DeadLight', 'UpdateCheck: checked within the last 24 h')
					break
				_mc.set('deadlight_update_check', 'done', expiration=24)
			except Exception: pass
			update_check(update_action())
			break
		kodi_utils.set_property(firstrun_update_prop, 'true')
		return kodi_utils.logger('DeadLight', 'UpdateCheck Service Finished')

class WidgetRefresher:
	def run(self):
		kodi_utils.logger('DeadLight', 'WidgetRefresher Service Starting')
		from time import time
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, self.is_playing = monitor.waitForAbort, player.isPlayingVideo
		if wait_for_abort(10): return
		try: self.set_next_refresh(time())   # LOCAL PATCH 2026-10-15: a raise here ended the refresher for the session
		except Exception as e: kodi_utils.logger('WidgetRefresher', 'set_next_refresh failed: %s' % e)
		while not monitor.abortRequested():
			try:
				if wait_for_abort(10 if getattr(self, 'offset', 1) else 60): break   # LOCAL PATCH 2026-11-08: 60 s while the timer is off
				offset = int(get_setting('deadlight.widget_refresh_timer', '60'))
				if offset != self.offset:
					self.set_next_refresh(time())
					continue
				if self.condition_check(): continue
				if self.next_refresh < time():
					kodi_utils.logger('DeadLight', 'WidgetRefresher Service - Widgets Refreshed')
					kodi_utils.refresh_widgets()
					self.set_next_refresh(time())
			except: pass
		return kodi_utils.logger('DeadLight', 'WidgetRefresher Service Finished')

	def condition_check(self):
		if not self.external(): return True

		if self.next_refresh == None or self.is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': return True
		if kodi_utils.get_property('deadlight.window_loaded') == 'true': return True 
		try:
			window_stack = json.loads(kodi_utils.get_property('deadlight.window_stack'))
			if window_stack or window_stack == []: return True
		except: pass
		return False

	def set_next_refresh(self, _time):
		self.offset = int(get_setting('deadlight.widget_refresh_timer', '60'))
		if self.offset: self.next_refresh = _time + (self.offset*60)
		else: self.next_refresh = None

	def external(self):
		return 'plugin' not in kodi_utils.get_infolabel('Container.PluginName')

class TMDbHelperRatingsTidy:
	"""LOCAL PATCH 2026-10-14: every 6 hours, drop TMDb Helper's thin rating sets for new titles so it fetches them
	again (it keeps every set 7 days, complete or not). Rule and reasons in modules/tmdbh_ratings_tidy.py."""
	INTERVAL = 6 * 3600

	def run(self):
		from modules.tmdbh_ratings_tidy import TMDBH_DATA, find_db, tidy
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		if wait_for_abort(_BOOT_SETTLE): return
		while not monitor.abortRequested():
			while kodi_utils.get_property(pause_services_prop) == 'true' or is_playing():
				if wait_for_abort(30): return
			try: db_path = find_db(kodi_utils.translate_path(TMDBH_DATA))   # LOCAL PATCH 2026-10-15: unguarded, it could end the tidy for good
			except Exception as e:
				db_path = None
				kodi_utils.logger('TMDbHelper ratings tidy', 'database lookup failed: %s' % e)
			if db_path:
				deleted, error = tidy(db_path)
				if error: kodi_utils.logger('TMDbHelper ratings tidy', 'failed: %s' % error)
				elif deleted: kodi_utils.logger('TMDbHelper ratings tidy', '%d thin set(s) dropped for a refetch: %s' % (len(deleted), ', '.join(deleted)))
			if wait_for_abort(self.INTERVAL): return

class AutoStart:
	def run(self):
		kodi_utils.logger('DeadLight', 'AutoStart Service Starting')
		from modules.settings import auto_start_deadlight
		if auto_start_deadlight(): kodi_utils.run_addon()
		return kodi_utils.logger('DeadLight', 'AutoStart Service Finished')

class AddonXMLCheck:
	def run(self):
		kodi_utils.logger('DeadLight', 'AddonXMLCheck Service Starting')
		self.addon_xml = kodi_utils.translate_path('special://home/addons/plugin.video.deadlight/addon.xml')
		# LOCAL PATCH 2026-10-02: compare the two tags as text first; the minidom parse is slow on the boot thread, for a file that
		# almost never needs a change.
		try:
			import re
			with open(self.addon_xml, 'r', encoding='utf-8') as f: text = f.read()
			def _tag(name):
				m = re.search(r'<%s>([^<]*)</%s>' % (name, name), text)
				return m.group(1) if m else None
			wanted = ((get_setting('deadlight.reuse_language_invoker', None), 'reuselanguageinvoker'),
					  (get_setting('deadlight.addon_icon_choice', None), 'icon'))
			if all(value is None or _tag(tag) == value for value, tag in wanted):
				return kodi_utils.logger('DeadLight', 'AddonXMLCheck Service Finished')
		except Exception: pass   # anything odd: the full check below decides
		from xml.dom.minidom import parse as mdParse
		self.root = mdParse(self.addon_xml)
		self.change_list = []
		self.check_property('reuse_language_invoker', 'reuselanguageinvoker')
		self.check_property('addon_icon_choice', 'icon')
		self.change_xml_file()
		return kodi_utils.logger('DeadLight', 'AddonXMLCheck Service Finished')

	def check_property(self, setting, tag_name):
		current_addon_setting = get_setting('deadlight.%s' % setting, None)
		if current_addon_setting is None: return
		tag_instance = self.root.getElementsByTagName(tag_name)[0].firstChild
		current_property = tag_instance.data
		if current_property != current_addon_setting:
			tag_instance.data = current_addon_setting
			self.change_list.append(tag_name)

	def change_xml_file(self):
		if not self.change_list: return
		if 'icon' in self.change_list: self.reassign_addon_icon()
		kodi_utils.notification('Refreshing Addon XML. Restarting Addons')
		new_xml = str(self.root.toxml()).replace('<?xml version="1.0" ?>', '')
		# Explicit UTF-8: the platform codec (cp1252 on Windows) TRUNCATES addon.xml on any character outside it, and Kodi
		# would stop loading the add-on.
		import io as _io, os as _os
		# LOCAL PATCH 2026-10-15: written whole or not at all (tmp + os.replace): an in-place write truncates first, so a crash
		# left addon.xml empty.
		_tmp = self.addon_xml + '.tmp'
		with _io.open(_tmp, 'w', encoding='utf-8', newline='') as f: f.write(new_xml)
		_os.replace(_tmp, self.addon_xml)
		kodi_utils.logger('DeadLight', 'AddonXMLCheck Service - Change Detected. Restarting Addons')
		kodi_utils.execute_builtin('ActivateWindow(Home)', True)
		kodi_utils.update_local_addons()
		kodi_utils.disable_enable_addon()

	def reassign_addon_icon(self):
		from indexers.dialogs import addon_icon_choice
		# LOCAL PATCH 2026-09-05: fallback must name a file that exists (the artwork is named deadlight_*), or a fresh
		# settings.db leaves the add-on with no tile.
		addon_icon_choice({'set_icon': get_setting('addon_icon_choice_name', 'deadlight_icon_09.png')})

class DeadLightMonitor(Monitor):
	def __init__ (self):
		Monitor.__init__(self)
		self.startServices()

	# LOCAL PATCH 2026-10-09: no onSettingsChanged pull -- Kodi holds no copy of DeadLight's settings any more (settings.xml is
	# one button that opens DeadLight's window), so there is nothing to bring back into settings.db.

	# LOCAL PATCH 2026-08-31: handlers use kodi_utils.logger -- a bare logger() is not imported here, and its NameError hid the
	# real error and could take the whole service down.
	def startServices(self):
		try: SetAddonConstants().run()
		except Exception as e: kodi_utils.logger('SetAddonConstants', str(e))
		# LOCAL PATCH 2026-05-26: DatabaseMaintenance in a background thread (with its own delay inside .run()), off the boot path.
		Thread(target=DatabaseMaintenance().run).start()
		try: SyncSettings().run()
		except Exception as e: kodi_utils.logger('SyncSettings', str(e))
		try: OnUpdateChanges().run()
		except Exception as e: kodi_utils.logger('OnUpdateChanges', str(e))
		try: AddonXMLCheck().run()
		except Exception as e: kodi_utils.logger('AddonXMLCheck', str(e))
		Thread(target=CustomWindowsPrepare().run).start()
		Thread(target=GlassMonitor().run).start()   # LOCAL PATCH 2026-10-24: adaptive glass for AF3
		Thread(target=TraktMonitor().run).start()
		# LOCAL PATCH 2026-07-23: MDBList sync monitor runs alongside Trakt.
		Thread(target=MDBListMonitor().run).start()
		# LOCAL PATCH 2026-07-29: SIMKL sync monitor (4th watched-indicator provider).
		Thread(target=SIMKLMonitor().run).start()
		Thread(target=AniListMonitor().run).start()
		# LOCAL PATCH 2026-07-29: mapping bootstrap -- now the Fribb mapping file (caches/fribb_mappings), despite the function
		# name. Fetched on first run, then checked hourly.
		Thread(target=_bootstrap_anime_mappings).start()
		Thread(target=UpdateCheck().run).start()
		Thread(target=UndesirablesDefaults().run).start()
		Thread(target=WidgetRefresher().run).start()
		Thread(target=WidgetPageWarmer().run).start()   # LOCAL PATCH 2026-10-25 (4.0.5): widget Next Page, warmed when quiet
		Thread(target=TMDbHelperRatingsTidy().run).start()
		try: AutoStart().run()
		except Exception as e: kodi_utils.logger('AutoStart', str(e))

	def onNotification(self, sender, method, data):
		if method in ('GUI.OnScreensaverActivated', 'System.OnSleep'):
			kodi_utils.set_property(pause_services_prop, 'true')
			kodi_utils.logger('OnNotificationActions', 'PAUSING DeadLight Services Due to Device Sleep')
		elif method in ('GUI.OnScreensaverDeactivated', 'System.OnWake'):
			kodi_utils.clear_property(pause_services_prop)
			kodi_utils.logger('OnNotificationActions', 'UNPAUSING DeadLight Services Due to Device Awake')

kodi_utils.logger('DeadLight', 'Main Monitor Service Starting')
DeadLightMonitor().waitForAbort()
kodi_utils.logger('DeadLight', 'Main Monitor Service Finished')
