# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-11-13: Extras as one screen with tabs (addon_patches mock-up extras_mock/redesign.html, "every section as a
# tab"). Writes resources/skins/Default/1080i/extras.xml from the saved section order (settings.extras_order), as the
# old windows/base_window.ExtrasUtils did, which this replaces.
#
# Layout (1920 x 1080):
#   the fanart, right-aligned behind left / bottom scrims (dimmed while a section's content has focus)
#   the hero: logo, facts line with the rating chips, amber status, three lines of plot, the button row (grouplist 9)
#   the tab bar (grouplist 9000): Details (3099) first (user, 2026-11-13), then one togglebutton per enabled section, id
#     list id + 1000, shown only while its list has items; no counts. Focus on a tab sets the window property 'tab'.
#   the content area: each section's list (ids 2051-2067, filled by windows/extras.py as before), visible while 'tab'
#     is its id. Up from a list goes back to its tab; Down from a tab goes into its list.
# windows/extras.Extras picks the opening tab and gives it focus (pick_tab), and restores the tab when coming back
# (set_returning_focus).
import re
from modules import kodi_utils, settings

HERO_LEFT, CONTENT_TOP, TABS_TOP = 120, 664, 580   # 2026-11-13: 26 px up, the band under the buttons was empty
TAB_OFFSET = 1000   # tab button id = list id + 1000 (2051 -> 3051)
DETAILS_ID = 2099   # the Details tab's content (not a list)

# tab label: the section name and its count (the count properties windows/extras.py sets)
TABS = {
	2051: ('Cast', 'cast'), 2052: ('Recommended', 'recommended'), 2053: ('Related', 'related'),
	2054: ('More Like This', 'more_like_this'), 2055: ('Similar', 'ai_similar'), 2056: ('Reviews', 'imdb_reviews'),
	2057: ('Comments', 'trakt_comments'), 2058: ('Trivia', 'imdb_trivia'), 2059: ('Blunders', 'imdb_blunders'),
	2060: ('Parents Guide', 'imdb_parentsguide'), 2061: ('In Trakt Lists', 'trakt_in_lists'), 2062: ('Videos', 'youtube_videos'),
	2063: ('Same Year', 'more_from_year'), 2064: ('Genres', 'more_from_genres'), 2065: ('Network', 'more_from_networks'),
	2066: ('$INFO[Window.Property(more_from_collection.name)]', 'more_from_collection'), 2067: ('AniList Recommended', 'anilist_recommended')}
KIND = {2051: 'cast', 2056: 'text', 2057: 'text', 2058: 'text', 2059: 'text', 2060: 'guide', 2061: 'lists', 2062: 'videos'}   # else 'poster'


def tab_order():
	"""The sections that get a tab, in the saved order: the Plot row (2050) is the hero's plot, never a tab."""
	return [i for i in settings.extras_order() if i in TABS]


# ---- the header ------------------------------------------------------------------------------------------------------
_RATING_SLOT = '''\
                    <control type="grouplist">
                        <width max="160">auto</width>
                        <height>44</height>
                        <orientation>horizontal</orientation>
                        <itemgap>8</itemgap>
                        <visible>String.IsEqual(Window.Property(@PROP@_rating),true)</visible>
                        <control type="image" id="410@N@">
                            <width>52</width>
                            <height>44</height>
                            <aspectratio>keep</aspectratio>
                            <aligny>center</aligny>
                        </control>
                        <control type="label" id="400@N@">
                            <width max="90">auto</width>
                            <height>44</height>
                            <font>font13</font> <!-- DEADLIGHT_30 -->
                            <textcolor>FFE8E8EA</textcolor>
                            <aligny>center</aligny>
                        </control>
                    </control>
'''

# the buttons: all alike, outlined, a light fill and bright outline on focus (user 2026-11-13: no solid primary)
_BUTTON = '''\
                    <control type="button" id="@ID@">
                        <visible>!String.IsEmpty(Window.Property(button@ID@.label))</visible>
                        <ondown>SetFocus($INFO[Window.Property(tab_button)])</ondown>
                        <width min="120" max="420">auto</width>
                        <height>60</height>
                        <label>$INFO[Window.Property(button@ID@.label)]</label>
                        <textoffsetx>28</textoffsetx>
                        <font>font12</font> <!-- DEADLIGHT_26 -->
                        <align>center</align>
                        <aligny>center</aligny>
@LOOK@                    </control>
'''
_LOOK = '''\
                        <textcolor>FFE8E8EA</textcolor>
                        <focusedcolor>FFFFFFFF</focusedcolor>
                        <texturenofocus colordiffuse="4DFFFFFF" border="30">deadlight_common/pill-outline-60.png</texturenofocus>
                        <texturefocus border="30">deadlight_common/pill-ghost-60.png</texturefocus>
'''


def _buttons():
	return ''.join(_BUTTON.replace('@ID@', str(i)).replace('@LOOK@', _LOOK)
				   for i in (10, 11, 12, 13, 14, 15, 16, 17))


def _rating_slots():
	return ''.join(_RATING_SLOT.replace('@PROP@', prop).replace('@N@', str(n)) for n, prop in
				   enumerate(['metascore', 'tomatometer', 'tomatousermeter', 'imdb', 'tmdb', 'anilist', 'myanimelist'], 1))


_HEADER = '''\
<?xml version="1.0" encoding="UTF-8"?>
<!-- generated by windows/extras_layout.py (LOCAL PATCH 2026-11-13: Extras as one screen with tabs); edits here are overwritten -->
<window>
    <defaultcontrol always="true">10</defaultcontrol>
    <controls>
        <control type="group">
            <control type="image">
                <texture colordiffuse="FF06090B">deadlight_common/white.png</texture>
            </control>
            <control type="image" id="202">
                <left>360</left>
                <width>1560</width>
                <height>1080</height>
                <aspectratio>scale</aspectratio>
                <animation effect="fade" start="0" end="100" time="400">WindowOpen</animation>
                <animation effect="fade" start="100" end="45" time="300" condition="!ControlGroup(9).HasFocus + !ControlGroup(9000).HasFocus">Conditional</animation>
            </control>
            <control type="image">
                <width>1500</width>
                <height>1080</height>
                <texture>deadlight_common/scrim-left.png</texture>
            </control>
            <control type="image">
                <top>520</top>
                <height>560</height>
                <texture>deadlight_common/scrim-bottom.png</texture>
            </control>
            <control type="image" id="200">
                <visible>false</visible>
            </control>
        </control>
        <control type="group">
            <animation effect="fade" end="100" time="200" delay="300">WindowOpen</animation>
            <!-- the hero: never changes content -->
            <control type="grouplist">
                <left>@LEFT@</left>
                <top>46</top>
                <width>1500</width>
                <height>540</height>
                <orientation>vertical</orientation>
                <itemgap>18</itemgap>
                <usecontrolcoords>true</usecontrolcoords>
                <control type="group">
                    <height>150</height>
                    <control type="image" id="201">
                        <width>560</width>
                        <height>150</height>
                        <aspectratio align="left" aligny="bottom">keep</aspectratio>
                    </control>
                    <control type="label">
                        <top>50</top>
                        <width>1300</width>
                        <height>100</height>
                        <font>font60</font> <!-- DEADLIGHT_60_BOLD -->
                        <textcolor>FFE8E8EA</textcolor>
                        <aligny>bottom</aligny>
                        <label>[B]$INFO[Window.Property(title)][/B]</label>
                        <visible>String.IsEqual(Window.Property(clearlogo),false)</visible>
                    </control>
                </control>
                <control type="grouplist">
                    <!-- the ratings (slots 4001-4007) lead the facts line; one rating uses icon 203 instead -->
                    <height>44</height>
                    <orientation>horizontal</orientation>
                    <itemgap>14</itemgap>
                    <control type="image" id="203">
                        <visible>!String.IsEmpty(Window.Property(facts_icon))</visible>
                        <width>44</width>
                        <height>44</height>
                        <aspectratio>keep</aspectratio>
                        <align>center</align>
                        <aligny>center</aligny>
                    </control>
@RATINGS@                    <control type="label" id="2001">
                        <width max="1100">auto</width>
                        <height>44</height>
                        <font>font13</font> <!-- DEADLIGHT_30 -->
                        <textcolor>FFE8E8EA</textcolor>
                        <aligny>center</aligny>
                    </control>
                </control>
                <control type="grouplist">
                    <!-- the status: an amber dot and text (windows/extras.set_infoline2) -->
                    <height>36</height>
                    <orientation>horizontal</orientation>
                    <itemgap>14</itemgap>
                    <visible>!String.IsEmpty(Window.Property(status_pill))</visible>
                    <control type="image">
                        <top>12</top>
                        <width>12</width>
                        <height>12</height>
                        <texture colordiffuse="FFE8A33D">deadlight_common/circle.png</texture>
                    </control>
                    <control type="label">
                        <width max="1200">auto</width>
                        <height>36</height>
                        <font>font12</font> <!-- DEADLIGHT_26 -->
                        <textcolor>FFE8A33D</textcolor>
                        <aligny>center</aligny>
                        <label>[B]$INFO[Window.Property(status_pill)][/B]</label>
                    </control>
                </control>
                <control type="textbox">
                    <width>1020</width>
                    <height>114</height>
                    <font>font13</font> <!-- DEADLIGHT_30 -->
                    <textcolor>D9FFFFFF</textcolor>
                    <label>$INFO[Window.Property(plot_body)]</label>
                    <autoscroll>false</autoscroll>
                </control>
                <control type="grouplist" id="9">
                    <!-- a slot set to 'None (hidden)' has no label and takes no room; each button carries its own down -->
                    <height>60</height>
                    <width>1700</width>
                    <orientation>horizontal</orientation>
                    <itemgap>14</itemgap>
@BUTTONS@                </control>
            </control>
            <!-- the tab bar -->
            <control type="grouplist" id="9000">
                <left>@LEFT@</left>
                <top>@TABS_TOP@</top>
                <width>1700</width>
                <height>52</height>
                <orientation>horizontal</orientation>
                <itemgap>6</itemgap>
                <onup>9</onup>
@TABS@            </control>
            <control type="image">
                <left>@LEFT@</left>
                <top>@RULE_TOP@</top>
                <width>1680</width>
                <height>2</height>
                <texture colordiffuse="1AFFFFFF">deadlight_common/white.png</texture>
            </control>
            <!-- the content: one section at a time -->
            <control type="group">
                <left>@LEFT@</left>
                <top>@CONTENT_TOP@</top>
'''

_FOOTER = '''\
            </control>
        </control>
    </controls>
</window>
'''

# ---- the tab bar -----------------------------------------------------------------------------------------------------
_TAB = '''\
                <control type="togglebutton" id="@TAB@">
                    <visible>@VISIBLE@</visible>
                    <width min="100" max="460">auto</width>
                    <height>52</height>
                    <label>@LABEL@</label>
                    <altlabel>@LABEL@</altlabel>
                    <font>font12</font> <!-- DEADLIGHT_26 -->
                    <textoffsetx>24</textoffsetx>
                    <align>center</align>
                    <aligny>center</aligny>
                    <!-- LOCAL PATCH 2026-11-13: an underline, not a filled pill (user): focused = white text and a white bar,
                         the selected tab = a dim bar, the others faded (the animation below) -->
                    <textcolor>FFFFFFFF</textcolor>
                    <focusedcolor>FFFFFFFF</focusedcolor>
                    <texturenofocus />
                    <texturefocus border="20,0,20,0">deadlight_common/tab-underline.png</texturefocus>
                    <alttexturenofocus colordiffuse="59FFFFFF" border="20,0,20,0">deadlight_common/tab-underline.png</alttexturenofocus>
                    <alttexturefocus border="20,0,20,0">deadlight_common/tab-underline.png</alttexturefocus>
                    <usealttexture>String.IsEqual(Window.Property(tab),@CID@)</usealttexture>
                    <animation effect="fade" start="100" end="55" time="150" condition="!String.IsEqual(Window.Property(tab),@CID@) + !Control.HasFocus(@TAB@)">Conditional</animation>
                    <onfocus>SetProperty(tab,@CID@)</onfocus>
                    <onfocus>SetProperty(tab_button,@TAB@)</onfocus>
@DOWN@                </control>
'''


def _tab(cid):
	label = TABS[cid][0]
	visible = 'Integer.IsGreater(Container(%d).NumItems,0)' % cid
	down = '                    <ondown>SetFocus(%d)</ondown>\n                    <onclick>SetFocus(%d)</onclick>\n' % (cid, cid)
	return _TAB.replace('@TAB@', str(cid + TAB_OFFSET)).replace('@CID@', str(cid)).replace('@VISIBLE@', visible) \
		.replace('@LABEL@', label).replace('@DOWN@', down)


def _details_tab():
	return _TAB.replace('@TAB@', str(DETAILS_ID + TAB_OFFSET)).replace('@CID@', str(DETAILS_ID)) \
		.replace('@VISIBLE@', '!String.IsEmpty(Window.Property(detail1.v))').replace('@LABEL@', 'Details').replace('@DOWN@', '')


# ---- the content -----------------------------------------------------------------------------------------------------
# every section: a group shown while its tab is the current one; the list's Up goes back to its tab
_SECTION = '''\
                <control type="group">
                    <visible>String.IsEqual(Window.Property(tab),@CID@)</visible>
                    <animation effect="fade" start="0" end="100" time="180">Visible</animation>
@BODY@                </control>
'''

_POSTERS = '''\
                    <control type="list" id="@CID@">
                        <left>-24</left>
                        <top>-30</top>
                        <width>1824</width>
                        <height>396</height>
                        <onup>SetFocus(@TAB@)</onup>
                        <orientation>horizontal</orientation>
                        <scrolltime tween="sine">300</scrolltime>
                        <itemlayout height="396" width="230">
                            <control type="image">
                                <left>32</left>
                                <top>38</top>
                                <width>210</width>
                                <height>315</height>
                                <aspectratio scalediffuse="false">scale</aspectratio>
                                <texture diffuse="deadlight_live/poster-50.png" background="true">$INFO[ListItem.Property(thumbnail)]</texture>
                            </control>
                        </itemlayout>
                        <focusedlayout height="396" width="230">
                            <control type="group">
                                <left>32</left>
                                <top>38</top>
                                <width>210</width>
                                <height>315</height>
                                <animation type="Focus" reversible="false"><effect type="zoom" start="100" end="112" time="220" tween="cubic" easing="out" center="auto"/></animation>
                                <animation type="Unfocus" reversible="false"><effect type="zoom" start="112" end="100" time="160" tween="cubic" easing="out" center="auto"/></animation>
                                <control type="image">
                                    <left>-24</left>
                                    <top>-16</top>
                                    <width>258</width>
                                    <height>363</height>
                                    <texture border="40">deadlight_live/shadow-16.png</texture>
                                    <visible>Control.HasFocus(@CID@)</visible>
                                </control>
                                <control type="image">
                                    <width>210</width>
                                    <height>315</height>
                                    <aspectratio scalediffuse="false">scale</aspectratio>
                                    <texture diffuse="deadlight_live/poster-50.png" background="true">$INFO[ListItem.Property(thumbnail)]</texture>
                                </control>
                            </control>
                        </focusedlayout>
                    </control>
                    <control type="label">
                        <!-- the caption: the focused title, under its row (clear of the lifted poster) -->
                        <left>8</left>
                        <top>352</top>
                        <width>1660</width>
                        <height>40</height>
                        <font>font12</font> <!-- DEADLIGHT_26 -->
                        <textcolor>B3FFFFFF</textcolor>
                        <label>[COLOR FFFFFFFF][B]$INFO[Container(@CID@).ListItem.Property(name)][/B][/COLOR]$INFO[Container(@CID@).ListItem.Property(release_date),   ]$INFO[Container(@CID@).ListItem.Property(vote_average),  •  ]$INFO[Container(@CID@).ListItem.Property(plot),  •  ]</label>
                        <visible>Control.HasFocus(@CID@)</visible>
                    </control>
'''

_CAST = '''\
                    <control type="list" id="@CID@">
                        <width>1800</width>
                        <height>290</height>
                        <onup>SetFocus(@TAB@)</onup>
                        <orientation>horizontal</orientation>
                        <scrolltime tween="sine">300</scrolltime>
                        <itemlayout height="290" width="250">
                            <control type="image">
                                <left>45</left>
                                <top>12</top>
                                <width>160</width>
                                <height>160</height>
                                <aspectratio scalediffuse="false">scale</aspectratio>
                                <texture diffuse="deadlight_common/circle-256.png" background="true">$INFO[ListItem.Property(thumbnail)]</texture>
                            </control>
                            <control type="label">
                                <top>190</top>
                                <width>250</width>
                                <height>30</height>
                                <font>font10</font> <!-- DEADLIGHT_21 -->
                                <textcolor>FFE8E8EA</textcolor>
                                <align>center</align>
                                <label>[B]$INFO[ListItem.Property(actor)][/B]</label>
                            </control>
                            <control type="label">
                                <top>220</top>
                                <width>250</width>
                                <height>30</height>
                                <font>font10</font> <!-- DEADLIGHT_21 -->
                                <textcolor>80FFFFFF</textcolor>
                                <align>center</align>
                                <label>$INFO[ListItem.Property(role)]</label>
                            </control>
                        </itemlayout>
                        <focusedlayout height="290" width="250">
                            <control type="group">
                                <left>45</left>
                                <top>12</top>
                                <width>160</width>
                                <height>160</height>
                                <animation type="Focus" reversible="false"><effect type="zoom" start="100" end="110" time="220" tween="cubic" easing="out" center="auto"/></animation>
                                <animation type="Unfocus" reversible="false"><effect type="zoom" start="110" end="100" time="160" tween="cubic" easing="out" center="auto"/></animation>
                                <control type="image">
                                    <width>160</width>
                                    <height>160</height>
                                    <aspectratio scalediffuse="false">scale</aspectratio>
                                    <texture diffuse="deadlight_common/circle-256.png" background="true">$INFO[ListItem.Property(thumbnail)]</texture>
                                </control>
                            </control>
                            <control type="label">
                                <top>190</top>
                                <width>250</width>
                                <height>30</height>
                                <font>font10</font> <!-- DEADLIGHT_21 -->
                                <textcolor>FFFFFFFF</textcolor>
                                <align>center</align>
                                <label>[B]$INFO[ListItem.Property(actor)][/B]</label>
                            </control>
                            <control type="label">
                                <top>220</top>
                                <width>250</width>
                                <height>30</height>
                                <font>font10</font> <!-- DEADLIGHT_21 -->
                                <textcolor>B3FFFFFF</textcolor>
                                <align>center</align>
                                <label>$INFO[ListItem.Property(role)]</label>
                            </control>
                        </focusedlayout>
                    </control>
'''

# reviews, comments, trivia, blunders: readable cards; OK opens the full text in the reader
_TEXT = '''\
                    <control type="list" id="@CID@">
                        <left>-16</left>
                        <top>-16</top>
                        <width>1816</width>
                        <height>334</height>
                        <onup>SetFocus(@TAB@)</onup>
                        <orientation>horizontal</orientation>
                        <scrolltime tween="sine">300</scrolltime>
                        <itemlayout height="334" width="584">
                            <control type="group">
                                <left>24</left>
                                <top>24</top>
                                <control type="image">
                                    <width>560</width>
                                    <height>270</height>
                                    <texture colordiffuse="14FFFFFF" border="16">deadlight_live/rounded-16.png</texture>
                                </control>
                                <control type="textbox">
                                    <left>28</left>
                                    <top>22</top>
                                    <width>504</width>
                                    <height>203</height>
                                    <font>font12</font> <!-- DEADLIGHT_26 -->
                                    <textcolor>CCFFFFFF</textcolor>
                                    <label>$INFO[ListItem.Property(text)]</label>
                                    <autoscroll>false</autoscroll>
                                </control>
                            </control>
                        </itemlayout>
                        <focusedlayout height="334" width="584">
                            <control type="group">
                                <left>24</left>
                                <top>24</top>
                                <width>560</width>
                                <height>270</height>
                                <animation type="Focus" reversible="false"><effect type="zoom" start="100" end="104" time="220" tween="cubic" easing="out" center="auto"/></animation>
                                <animation type="Unfocus" reversible="false"><effect type="zoom" start="104" end="100" time="160" tween="cubic" easing="out" center="auto"/></animation>
                                <control type="image">
                                    <left>-24</left>
                                    <top>-16</top>
                                    <width>608</width>
                                    <height>318</height>
                                    <texture border="40">deadlight_live/shadow-16.png</texture>
                                    <visible>Control.HasFocus(@CID@)</visible>
                                </control>
                                <control type="image">
                                    <width>560</width>
                                    <height>270</height>
                                    <texture colordiffuse="2EFFFFFF" border="16">deadlight_live/rounded-16.png</texture>
                                </control>
                                <control type="textbox">
                                    <left>28</left>
                                    <top>22</top>
                                    <width>504</width>
                                    <height>203</height>
                                    <font>font12</font> <!-- DEADLIGHT_26 -->
                                    <textcolor>FFFFFFFF</textcolor>
                                    <label>$INFO[ListItem.Property(text)]</label>
                                    <autoscroll>false</autoscroll>
                                </control>
                            </control>
                        </focusedlayout>
                    </control>
'''

# Trakt lists the title is in: a card with the list's name block (windows/extras.make_in_lists builds the text)
# the text boxes hold whole lines: font12 (29 px a line on the 1080 grid) 7 lines = 203; Kodi draws any line that STARTS
# inside a textbox, so a box between two multiples showed half a line (2026-11-13 capture). font10 (~23.5 px): 9 lines = 211.
_LISTS = _TEXT.replace('<height>203</height>', '<height>211</height>').replace('width="584"', 'width="324"').replace('<width>560</width>', '<width>300</width>') \
	.replace('<width>608</width>', '<width>348</width>').replace('<width>504</width>', '<width>244</width>') \
	.replace('ListItem.Property(text)', 'ListItem.Property(name)') \
	.replace('<font>font12</font> <!-- DEADLIGHT_26 -->', '<font>font10</font> <!-- DEADLIGHT_21 -->')

_VIDEOS = '''\
                    <control type="list" id="@CID@">
                        <left>-16</left>
                        <top>-16</top>
                        <width>1816</width>
                        <height>316</height>
                        <onup>SetFocus(@TAB@)</onup>
                        <orientation>horizontal</orientation>
                        <scrolltime tween="sine">300</scrolltime>
                        <itemlayout height="316" width="424">
                            <control type="image">
                                <left>24</left>
                                <top>24</top>
                                <width>400</width>
                                <height>225</height>
                                <aspectratio scalediffuse="false">scale</aspectratio>
                                <texture diffuse="deadlight_live/landscape.png" background="true">$INFO[ListItem.Property(thumbnail)]</texture>
                            </control>
                            <control type="label">
                                <left>24</left>
                                <top>262</top>
                                <width>400</width>
                                <height>32</height>
                                <font>font10</font> <!-- DEADLIGHT_21 -->
                                <textcolor>B3FFFFFF</textcolor>
                                <label>$INFO[ListItem.Property(name)]</label>
                            </control>
                        </itemlayout>
                        <focusedlayout height="316" width="424">
                            <control type="group">
                                <left>24</left>
                                <top>24</top>
                                <width>400</width>
                                <height>225</height>
                                <animation type="Focus" reversible="false"><effect type="zoom" start="100" end="106" time="220" tween="cubic" easing="out" center="auto"/></animation>
                                <animation type="Unfocus" reversible="false"><effect type="zoom" start="106" end="100" time="160" tween="cubic" easing="out" center="auto"/></animation>
                                <control type="image">
                                    <left>-24</left>
                                    <top>-16</top>
                                    <width>448</width>
                                    <height>273</height>
                                    <texture border="40">deadlight_live/shadow-16.png</texture>
                                    <visible>Control.HasFocus(@CID@)</visible>
                                </control>
                                <control type="image">
                                    <width>400</width>
                                    <height>225</height>
                                    <aspectratio scalediffuse="false">scale</aspectratio>
                                    <texture diffuse="deadlight_live/landscape.png" background="true">$INFO[ListItem.Property(thumbnail)]</texture>
                                </control>
                            </control>
                            <control type="label">
                                <left>24</left>
                                <top>262</top>
                                <width>400</width>
                                <height>32</height>
                                <font>font10</font> <!-- DEADLIGHT_21 -->
                                <textcolor>FFFFFFFF</textcolor>
                                <label>[B]$INFO[ListItem.Property(name)][/B]</label>
                            </control>
                        </focusedlayout>
                    </control>
'''

_GUIDE = '''\
                    <control type="list" id="@CID@">
                        <left>-16</left>
                        <top>-16</top>
                        <width>1816</width>
                        <height>334</height>
                        <onup>SetFocus(@TAB@)</onup>
                        <orientation>horizontal</orientation>
                        <scrolltime tween="sine">300</scrolltime>
                        <itemlayout height="334" width="324">
                            <control type="group">
                                <left>24</left>
                                <top>24</top>
                                <control type="image">
                                    <width>300</width>
                                    <height>270</height>
                                    <texture colordiffuse="14FFFFFF" border="16">deadlight_live/rounded-16.png</texture>
                                </control>
                                <control type="image">
                                    <left>110</left>
                                    <top>32</top>
                                    <width>80</width>
                                    <height>80</height>
                                    <aspectratio>keep</aspectratio>
                                    <texture>$INFO[ListItem.Property(thumbnail)]</texture>
                                </control>
                                <control type="label">
                                    <left>12</left>
                                    <top>132</top>
                                    <width>276</width>
                                    <height>60</height>
                                    <font>font10</font> <!-- DEADLIGHT_21 -->
                                    <textcolor>FFE8E8EA</textcolor>
                                    <align>center</align>
                                    <wrapmultiline>true</wrapmultiline>
                                    <label>[B]$INFO[ListItem.Property(name)][/B]</label>
                                </control>
                                <control type="label">
                                    <left>12</left>
                                    <top>204</top>
                                    <width>276</width>
                                    <height>32</height>
                                    <font>font10</font> <!-- DEADLIGHT_21 -->
                                    <textcolor>FFE8A33D</textcolor>
                                    <align>center</align>
                                    <label>$INFO[ListItem.Property(ranking)]</label>
                                </control>
                            </control>
                        </itemlayout>
                        <focusedlayout height="334" width="324">
                            <control type="group">
                                <left>24</left>
                                <top>24</top>
                                <width>300</width>
                                <height>270</height>
                                <animation type="Focus" reversible="false"><effect type="zoom" start="100" end="104" time="220" tween="cubic" easing="out" center="auto"/></animation>
                                <animation type="Unfocus" reversible="false"><effect type="zoom" start="104" end="100" time="160" tween="cubic" easing="out" center="auto"/></animation>
                                <control type="image">
                                    <left>-24</left>
                                    <top>-16</top>
                                    <width>348</width>
                                    <height>318</height>
                                    <texture border="40">deadlight_live/shadow-16.png</texture>
                                    <visible>Control.HasFocus(@CID@)</visible>
                                </control>
                                <control type="image">
                                    <width>300</width>
                                    <height>270</height>
                                    <texture colordiffuse="2EFFFFFF" border="16">deadlight_live/rounded-16.png</texture>
                                </control>
                                <control type="image">
                                    <left>110</left>
                                    <top>32</top>
                                    <width>80</width>
                                    <height>80</height>
                                    <aspectratio>keep</aspectratio>
                                    <texture>$INFO[ListItem.Property(thumbnail)]</texture>
                                </control>
                                <control type="label">
                                    <left>12</left>
                                    <top>132</top>
                                    <width>276</width>
                                    <height>60</height>
                                    <font>font10</font> <!-- DEADLIGHT_21 -->
                                    <textcolor>FFFFFFFF</textcolor>
                                    <align>center</align>
                                    <wrapmultiline>true</wrapmultiline>
                                    <label>[B]$INFO[ListItem.Property(name)][/B]</label>
                                </control>
                                <control type="label">
                                    <left>12</left>
                                    <top>204</top>
                                    <width>276</width>
                                    <height>32</height>
                                    <font>font10</font> <!-- DEADLIGHT_21 -->
                                    <textcolor>FFE8A33D</textcolor>
                                    <align>center</align>
                                    <label>$INFO[ListItem.Property(ranking)]</label>
                                </control>
                            </control>
                        </focusedlayout>
                    </control>
'''

# the Details tab: the facts windows/extras.set_infoline2 sets (detail1-6), three columns, plain text; not focusable
_DETAIL_CELL = '''\
                    <control type="group">
                        <left>@X@</left>
                        <top>@Y@</top>
                        <visible>!String.IsEmpty(Window.Property(detail@N@.v))</visible>
                        <control type="label">
                            <width>520</width>
                            <height>28</height>
                            <font>font10</font> <!-- DEADLIGHT_21 -->
                            <textcolor>80FFFFFF</textcolor>
                            <label>$INFO[Window.Property(detail@N@.k)]</label>
                        </control>
                        <control type="label">
                            <top>30</top>
                            <width>520</width>
                            <height>40</height>
                            <font>font13</font> <!-- DEADLIGHT_30 -->
                            <textcolor>FFE8E8EA</textcolor>
                            <label>$INFO[Window.Property(detail@N@.v)]</label>
                        </control>
                    </control>
'''


def _details_body():
	cells = [('0', '20'), ('560', '20'), ('1120', '20'), ('0', '130'), ('560', '130'), ('1120', '130')]
	return ''.join(_DETAIL_CELL.replace('@N@', str(n)).replace('@X@', x).replace('@Y@', y) for n, (x, y) in enumerate(cells, 1))


def _section(cid):
	body = {'cast': _CAST, 'text': _TEXT, 'lists': _LISTS, 'videos': _VIDEOS, 'guide': _GUIDE}.get(KIND.get(cid), _POSTERS)
	body = body.replace('@CID@', str(cid)).replace('@TAB@', str(cid + TAB_OFFSET))
	return _SECTION.replace('@CID@', str(cid)).replace('@BODY@', body)


def build_xml(order):
	head = _HEADER.replace('@LEFT@', str(HERO_LEFT)).replace('@TABS_TOP@', str(TABS_TOP)).replace('@RULE_TOP@', str(TABS_TOP + 62)) \
		.replace('@CONTENT_TOP@', str(CONTENT_TOP)).replace('@RATINGS@', _rating_slots()).replace('@BUTTONS@', _buttons()) \
		.replace('@TABS@', _details_tab() + ''.join(_tab(i) for i in order))
	sections = ''.join(_section(i) for i in order)
	details = _SECTION.replace('@CID@', str(DETAILS_ID)).replace('@BODY@', _details_body())
	return head + details + sections + _FOOTER


# ---- People ----------------------------------------------------------------------------------------------------------
# LOCAL PATCH 2026-11-13: People in the Extras style (mock-up extras_mock/redesign.html, 'People'): a portrait hero with the
# known-for kicker, the name, born / age / birthplace (label 2001), three lines of biography and the buttons, then tabs:
# Movies (2050), TV Shows (2051), Directed (2053), Trivia (2052). windows/people.py sets the button labels and the tabs.
PEOPLE_TABS = ((2050, 'Movies', 'poster'), (2051, 'TV Shows', 'poster'), (2053, 'Directed', 'poster'), (2052, 'Trivia', 'text'))
PEOPLE_BUTTONS = (50, 10, 11, 12, 13)   # Biography, Images, Tagged Images, Easynews, Favourites (windows/people.onClick)

_PEOPLE_HEAD = '''\
<?xml version="1.0" encoding="UTF-8"?>
<!-- generated by windows/extras_layout.py (LOCAL PATCH 2026-11-13: People in the Extras style); edits here are overwritten -->
<window>
    <defaultcontrol always="true">50</defaultcontrol>
    <controls>
        <control type="group">
            <!-- the plain theme background (windows/base_window.set_glass: full-screen windows), black when there is none -->
            <control type="image">
                <visible>String.IsEmpty(Window.Property(deadlight.glass))</visible>
                <texture colordiffuse="FF000000">deadlight_common/white.png</texture>
            </control>
            <control type="group">
                <visible>!String.IsEmpty(Window.Property(deadlight.glass))</visible>
                <animation effect="fade" start="0" end="100" time="300" tween="cubic" easing="out">WindowOpen</animation>
                <control type="image">
                    <aspectratio>scale</aspectratio>
                    <texture background="true">$INFO[Window.Property(deadlight.glass)]</texture>
                </control>
                <control type="image">
                    <texture colordiffuse="$INFO[Window(Home).Property(deadlight.win.glass_tint)]">deadlight_common/white.png</texture>
                    <visible>!String.IsEmpty(Window.Property(deadlight.glass_tint))</visible>
                </control>
            </control>
        </control>
        <control type="group">
            <animation effect="fade" end="100" time="200" delay="300">WindowOpen</animation>
            <control type="image">
                <left>@LEFT@</left>
                <top>78</top>
                <width>280</width>
                <height>280</height>
                <aspectratio scalediffuse="false">scale</aspectratio>
                <texture diffuse="deadlight_common/circle-256.png" background="true">$INFO[Window.Property(image)]</texture>
            </control>
            <control type="grouplist">
                <left>460</left>
                <top>70</top>
                <width>1360</width>
                <height>480</height>
                <orientation>vertical</orientation>
                <itemgap>14</itemgap>
                <usecontrolcoords>true</usecontrolcoords>
                <control type="label">
                    <width>1360</width>
                    <height>34</height>
                    <font>font12</font> <!-- DEADLIGHT_26 -->
                    <textcolor>FFE8A33D</textcolor>
                    <label>[B]$INFO[Window.Property(known_for)][/B]</label>
                    <visible>!String.IsEmpty(Window.Property(known_for))</visible>
                </control>
                <control type="label">
                    <width>1360</width>
                    <height>84</height>
                    <font>font60</font> <!-- DEADLIGHT_60_BOLD -->
                    <textcolor>FFE8E8EA</textcolor>
                    <aligny>center</aligny>
                    <label>[B]$INFO[Window.Property(name)][/B]</label>
                </control>
                <control type="label" id="2001">
                    <width>1360</width>
                    <height>40</height>
                    <font>font13</font> <!-- DEADLIGHT_30 -->
                    <textcolor>FFE8E8EA</textcolor>
                    <aligny>center</aligny>
                </control>
                <control type="textbox">
                    <width>1240</width>
                    <height>114</height>
                    <font>font13</font> <!-- DEADLIGHT_30 -->
                    <textcolor>D9FFFFFF</textcolor>
                    <label>$INFO[Window.Property(biography)]</label>
                    <autoscroll>false</autoscroll>
                    <visible>!String.IsEmpty(Window.Property(biography))</visible>
                </control>
                <control type="grouplist" id="9">
                    <height>60</height>
                    <width>1360</width>
                    <orientation>horizontal</orientation>
                    <itemgap>14</itemgap>
@BUTTONS@                </control>
            </control>
            <control type="grouplist" id="9000">
                <left>@LEFT@</left>
                <top>@TABS_TOP@</top>
                <width>1700</width>
                <height>52</height>
                <orientation>horizontal</orientation>
                <itemgap>6</itemgap>
                <onup>9</onup>
@TABS@            </control>
            <control type="image">
                <left>@LEFT@</left>
                <top>@RULE_TOP@</top>
                <width>1680</width>
                <height>2</height>
                <texture colordiffuse="1AFFFFFF">deadlight_common/white.png</texture>
            </control>
            <control type="group">
                <left>@LEFT@</left>
                <top>@CONTENT_TOP@</top>
'''

# the caption under a credit row: the title, the year, the role and TMDb's rating (windows/people.make_tmdb_listitems)
_PEOPLE_CAPTION = '[COLOR FFFFFFFF][B]$INFO[Container(@CID@).ListItem.Property(name)][/B][/COLOR]$INFO[Container(@CID@).ListItem.Property(release_date),   ]$INFO[Container(@CID@).ListItem.Property(role),  •  ]$INFO[Container(@CID@).ListItem.Property(vote_average),  •  TMDb ]'
_POSTER_CAPTION = '[COLOR FFFFFFFF][B]$INFO[Container(@CID@).ListItem.Property(name)][/B][/COLOR]$INFO[Container(@CID@).ListItem.Property(release_date),   ]$INFO[Container(@CID@).ListItem.Property(vote_average),  •  ]$INFO[Container(@CID@).ListItem.Property(plot),  •  ]'


def _people_tab(cid, label):
	return _TAB.replace('@TAB@', str(cid + TAB_OFFSET)).replace('@CID@', str(cid)) \
		.replace('@VISIBLE@', 'Integer.IsGreater(Container(%d).NumItems,0)' % cid).replace('@LABEL@', label) \
		.replace('@DOWN@', '                    <ondown>SetFocus(%d)</ondown>\n                    <onclick>SetFocus(%d)</onclick>\n' % (cid, cid))


def build_people_xml():
	assert _POSTERS.count(_POSTER_CAPTION) == 1
	posters = _POSTERS.replace(_POSTER_CAPTION, _PEOPLE_CAPTION)
	head = _PEOPLE_HEAD.replace('@LEFT@', str(HERO_LEFT)).replace('@TABS_TOP@', str(TABS_TOP)).replace('@RULE_TOP@', str(TABS_TOP + 62)) \
		.replace('@CONTENT_TOP@', str(CONTENT_TOP)).replace('@BUTTONS@', ''.join(_BUTTON.replace('@ID@', str(i)).replace('@LOOK@', _LOOK) for i in PEOPLE_BUTTONS)) \
		.replace('@TABS@', ''.join(_people_tab(cid, label) for cid, label, kind in PEOPLE_TABS))
	sections = ''.join(_SECTION.replace('@CID@', str(cid)).replace('@BODY@', (posters if kind == 'poster' else _TEXT)
					   .replace('@CID@', str(cid)).replace('@TAB@', str(cid + TAB_OFFSET))) for cid, label, kind in PEOPLE_TABS)
	return head + sections + _FOOTER


def _write_if_changed(file, content):
	"""Write only when the layout changed: the file on disk carries the skin's font names (the font pass fills them in), so
	compare with the <font> values blanked out (LOCAL PATCH 2026-10-02, kept)."""
	try:
		with kodi_utils.open_file(file) as f: on_disk = f.read()
	except Exception: on_disk = None
	if on_disk is None or re.sub(r'<font>.*?</font>', '', on_disk) != re.sub(r'<font>.*?</font>', '', content):
		with kodi_utils.open_file(file, 'w') as f: f.write(content)


class ExtrasUtils:
	"""Writes extras.xml and people.xml (called by the service at start and after the row order changes, as before)."""
	def run(self):
		from windows.base_window import FontUtils
		folder = 'special://home/addons/plugin.video.deadlight/resources/skins/Default/1080i/%s'
		_write_if_changed(kodi_utils.translate_path(folder % 'extras.xml'), build_xml(tab_order()))
		_write_if_changed(kodi_utils.translate_path(folder % 'people.xml'), build_people_xml())
		FontUtils().execute_custom_fonts(skin_files=['extras.xml', 'people.xml'])
