# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-27: AnimeTosho provider -- anime episodes matched by ID.
#
# Every other provider here decides from the release NAME whether a row is the episode asked for. For anime that is
# not reliably decidable: the same episode ships under different, equally correct numbers (Bleach TYBW premiere is
# both "S01E01" and "S17E01"; AoT S3E20 is "S03E20 (57)"). AnimeTosho tags each torrent with its AniDB episode id
# (eid); DeadLight resolves the eid before scraping (Fribb -> AniList id -> ani.zip -> eid, all cached), so this
# provider asks "which torrents ARE eid N?" and does no name parsing for identity.
#
# *** THE INDEX IS FROZEN -- READ THIS BEFORE DEBUGGING AN EMPTY RESULT ***
# AnimeTosho stopped ingesting on 2026-05-08. The API still answers HTTP 200 and serves the back catalogue, but holds
# NOTHING released after that. A current show returning zero rows by eid and aid is the frozen index, not a broken
# lookup -- the newest `timestamp` in an unfiltered /json?limit=25 call confirms it. So nyaa covers current seasons
# and must stay enabled; seadex.py covers curated picks; this provider covers the archive.
#
# SCOPE -- two queries, because they find different things:
#   sources()       ?eid=<episode id>  single episodes, exact, no parsing
#   sources_packs() ?aid=<anime id>    season packs, which the eid query cannot see (see pack_capable)
# Remux rows are tagged, not assumed away: `name_info` lets DeadLight apply its REMUX filter and quality sort.
#
# API: https://feed.animetosho.net/json?eid=<eid>   No key. No auth. JSON list.
#
# LOCAL PATCH 2026-09-15: .net, AnimeTosho's newer domain. Hosts running this software are NOT mirrors: their
# internal `id` spaces are disjoint, so the same release carries a different id on each. Compare by info_hash, never id.

from magneto.modules import client
from magneto.modules import source_utils
# LOCAL PATCH 2026-09-15: sibling-cour reject, see sources(). The same helper nyaa.py uses, so the anime numbering
# schemes stay implemented in one place.
try:
	from magneto.modules.anime_utils import cour_match
except Exception:
	cour_match = None

# LOCAL PATCH 2026-09-22: the same extractor cour_match uses, for the pack range check in sources_packs. Imported
# separately so a failure there cannot disable cour_match.
try:
	from magneto.modules.anime_utils import _clean_for_extract, _extract_meta, alias_titles
except Exception:
	_clean_for_extract = _extract_meta = alias_titles = None

# LOCAL PATCH 2026-09-23: the whole-run name check in sources(). Separate import, same reason.
try:
	from magneto.modules.anime_utils import whole_run_episode
except Exception:
	whole_run_episode = None

# LOCAL PATCH 2026-09-23: another cour's words in a PACK name, see sources/sources_packs.
try:
	from magneto.modules.anime_utils import names_foreign_cour
except Exception:
	names_foreign_cour = None

# LOCAL PATCH 2026-09-24: the pack-name readers, moved to anime_utils. Separate import, same reason.
try:
	from magneto.modules.anime_utils import pack_excludes_episode, pack_declares_season_only, pack_names_sibling_series
except Exception:
	pack_excludes_episode = pack_declares_season_only = pack_names_sibling_series = None

try:
	from statistics import median as _median
except ImportError:
	_median = None

try:
	import json as _json
except ImportError:
	_json = None

import re

# Raw Blu-ray disc structures and disc images carry no episode files to pick from (a BDMV is a tree of .m2ts
# streams), so the debrid layer can never resolve one to an episode and the row would only fail on click.
_DISC_STRUCTURE = re.compile(r'(?:^|[^a-z0-9])(?:bdmv|m2ts|iso|disc\s?\d|bdiso)(?:[^a-z0-9]|$)', re.I)

# LOCAL PATCH 2026-09-22: the feed's real per-page cap is 200, not 75 (limit=300 returns 200). That lets the pack
# query be a SINGLE self-calibrating request: a 200-row size-sorted page reaches down to single-file rows where a
# 75-row one contains none.
_PAGE_MAX = 200

# LOCAL PATCH 2026-09-23: how many times heavier a 'single episode' may be than a file inside a pack before it is
# disbelieved (see _one_episode_size). Legitimate cases reach 6.8x (1080p singles vs 480p packs); One Piece's
# films-as-singles read 65.7x. 10 clears every real case and still catches it.
_SINGLE_FILE_SANITY = 10

# LOCAL PATCH 2026-09-24: the pack-NAME readers live in anime_utils. This file keeps the ROW plumbing: which of a
# row's fields carry a name, and in what order both are read.
def _row_names(row):
	return [n for n in (row.get('title'), row.get('torrent_name')) if n]


def _declares_season_without_episodes(row):
	if not pack_declares_season_only: return False
	return pack_declares_season_only(_row_names(row))




class source:
	# LOCAL PATCH 2026-08-27 (revised): True. ?eid= only sees batches AnimeTosho has file-indexed and matched to
	# episodes; most sit at anidb_eid=None (Bleach TYBW: 0 packs by eid, 42 by aid). sources_packs() asks by ANIME id
	# instead -- safe because the aid comes from Fribb offline and the debrid layer can pick the right file out of an
	# anime pack.
	pack_capable = True
	# Anime films are one AniDB episode too, but DeadLight only resolves an eid on the episode path, so a movie scrape
	# would always no-op. Left off until it passes one.
	hasMovies = False
	hasEpisodes = True

	def __init__(self):
		# ONE index, two domains. .net is the live host; .xyz serves the same data (identical by info_hash) and is tried
		# only when .net cannot be reached -- asking both would return every row twice.
		# feed.animetosho.ORG IS DEAD AND MUST NOT BE ADDED BACK. It still answers HTTP 200 with a full-looking payload,
		# but its index stopped updating on 2026-05-07, so its "extra" rows are only stale, likely-dead torrents.
		# Freshness here is the `timestamp` field, not HTTP status.
		self.base_link = 'https://feed.animetosho.net'
		# NOT self.sources -- that name is the provider's own sources() METHOD; assigning it replaced the bound method with
		# a tuple and every scrape died on "'tuple' object is not callable".
		self.feed_hosts = ((self.base_link, 'https://feed.animetosho.xyz'),)
		# Debrid-only, like nyaa.py: a 0-seeder torrent can still be cached and instantly playable, so seeders do not gate it.
		# 2026-09-26: set by _query when NO index answered (every domain unreachable). DeadLight's external.py then does not
		# cache the empty result -- same contract as nekobt's flag.
		self.request_failed = False

	# LOCAL PATCH 2026-09-15: hosts are tried in order and a failing one is skipped (failover: a host being down degrades
	# results rather than emptying them). Merges dedupe on info_hash and NEVER on `id` (the hosts number rows
	# separately); magnet_uri is the fallback key for a row with no hash.
	def _fetch_index(self, host, params, pages, limit=75):
		"""All pages from ONE host, or None if the host could not be reached.

		None and [] mean different things and the caller depends on it: None is "ask this
		index's other domain", [] is "this index answered and genuinely has nothing"."""
		out = []
		for page in range(1, pages + 1):
			url = '%s/json?%s&limit=%d%s' % (host, params, limit,
										'&page=%d' % page if page > 1 else '')
			# 2026-09-26: no response is UNREACHABLE, not an empty page -- treating a timeout as "nothing" skipped the .xyz alias
			# and cached the empty result as genuine.
			response = client.request(url, timeout=10)
			if not response: return None if not out else out
			try:
				batch = _json.loads(response)
			except Exception:
				return None if not out else out
			if not isinstance(batch, list): return None if not out else out
			out.extend(batch)
			# A short page means the index is exhausted. Compared against the limit ASKED for,
			# not a literal 75, or a 200-row request would always look short and stop early.
			if len(batch) < limit: break
		return out

	def _query(self, params, pages=1, limit=75):
		"""Rows from every index, deduped on info_hash.

		One entry in self.feed_hosts is one INDEX; its domains are interchangeable, so the first
		that answers wins and the rest are skipped -- querying an alias would return the same
		rows and every one would be dropped by the dedupe anyway. Indexes, by contrast, hold
		different releases and are all merged.

		Dedupe is on info_hash and NEVER on `id`: the indexes number rows separately, so the
		same release carries a different id on each and an id-keyed merge would double every
		shared row. magnet_uri is the fallback key for a row carrying no hash.
		"""
		rows, seen, answered = [], set(), False
		for domains in self.feed_hosts:
			for host in domains:
				batch = self._fetch_index(host, params, pages, limit)
				if batch is None: continue          # unreachable -- try this index's alias
				answered = True
				for row in batch:
					if not isinstance(row, dict): continue
					key = (row.get('info_hash') or row.get('magnet_uri') or '').lower()
					if key:
						if key in seen: continue
						seen.add(key)
					rows.append(row)
				break                                # this index answered; skip its aliases
		if not answered: self.request_failed = True
		return rows

	def _one_episode_size(self, rows):
		"""What one episode of this anime weighs, from the single-file rows in `rows`.
		
		Self-calibrating on purpose: a hardcoded "packs are over N GB" is wrong across a 350MB SD show and a 3GB 1080p one,
		and reading "Batch" from the title is the name parsing this provider avoids. Real batches measure 18.5x+ the median;
		the false positive this rejects (one episode with a separate subtitle file) sits at 0.5x.
		"""
		singles = [r.get('total_size') or 0 for r in rows
				if isinstance(r, dict) and int(r.get('num_files') or 1) == 1]
		singles = [x for x in singles if x > 0]
		one = _median(singles) if (singles and _median) else 0
		# LOCAL PATCH 2026-09-23: a single FILE is not always a single EPISODE. AnimeTosho files a franchise's FILMS under
		# the series aid (One Piece: the only single-file rows are 31-53 GB Film Red remuxes), which made 'one episode'
		# 45 GB and let huge unlabelled packs through as S1E1, escaping every downstream pack safeguard.
		# Cross-check: a file INSIDE a pack is an episode by construction, so the median per-file size of multi-file rows
		# says what an episode weighs (One Piece: 0.69 GB, a 66x contradiction). Only a contradiction this large
		# intervenes -- singles simply higher quality than packs are normal (Re:ZERO S1 6.8x).
		# Deliberately a VETO, not a replacement: deriving the threshold FROM pack rows was tried twice and failed.
		if not one: return 0
		per_file = []
		for r in rows:
			if not isinstance(r, dict): continue
			try: n = int(r.get('num_files') or 1)
			except (TypeError, ValueError): continue
			if n < 2: continue
			try: size = float(r.get('total_size') or 0)
			except (TypeError, ValueError): continue
			if size > 0: per_file.append(size / n)
		# No pack rows to cross-check against (a film entry, or an eid query returning only single files) -- keep it.
		if not (per_file and _median): return one
		typical = _median(per_file)
		if typical and one > _SINGLE_FILE_SANITY * typical: return typical
		return one

	def _is_pack(self, row, one_episode, allow_unknown=False):
		"""Several files only means a pack if it also weighs like one.
		
		LOCAL PATCH 2026-09-22: `allow_unknown` covers one_episode not being measurable (no single-file row in the window):
		an unconditional `if not one_episode: return False` rejected EVERY row, silently. With no threshold the file count
		alone decides, which re-admits the subtitle-file false positive -- right ONLY where the alternative is returning
		nothing, so it is opt-in: sources() keeps the strict reading, where a mislabel would relabel a real result."""
		try:
			if int(row.get('num_files') or 1) < 2: return False
			if not one_episode: return bool(allow_unknown)
			return float(row.get('total_size') or 0) >= 2 * one_episode
		except (TypeError, ValueError): return False

	def _build(self, row, data, package, undesirables, check_foreign_audio):
		"""One feed row -> one DeadLight source, or None if it should be dropped."""
		info_hash = (row.get('info_hash') or '').lower()
		magnet = row.get('magnet_uri')
		if not info_hash or not magnet: return None
		# Which name to use depends on what the row IS.
		#   single file -> `torrent_name` is the actual filename, more accurate than the posting title.
		#   pack        -> `torrent_name` is the ROOT FOLDER, often useless (non-ASCII folders reduce to "V5"); the title
		#                  also carries the resolution and codec tags quality detection and the REMUX filter read.
		posting, filename = row.get('title') or '', row.get('torrent_name') or ''
		raw = (posting or filename) if package else (filename or posting)
		# Descriptive rejects, not identity ones: this only asks what KIND of thing the row is, never which episode.
		if _DISC_STRUCTURE.search(raw): return None
		name = source_utils.clean_name(raw)
		if not name: return None
		# name_info drives DeadLight's quality and tag detection (REMUX / BLURAY / HEVC / AV1 / WEB / audio). Without it,
		# scrapers/external.py parses the magnet URL, where url_strip() flattens the dotted tokens get_info() looks for.
		name_info = source_utils.info_from_name(
			name, data.get('tvshowtitle') or '', str(data.get('year') or ''),
			season=str(data.get('season') or ''), pack=package)
		# These read the name only to DESCRIBE or veto a release, never to decide which episode it is -- episode identity
		# comes from the id.
		if source_utils.remove_lang(name_info, check_foreign_audio): return None
		if undesirables and source_utils.remove_undesirables(name_info, undesirables): return None
		try:
			seeders = int(row.get('seeders') or 0)
			if seeders < 0: seeders = 0   # AnimeTosho reports -1 for "unknown"
		except (TypeError, ValueError): seeders = 0
		quality, info = source_utils.get_release_quality(name_info, magnet)
		# total_size is bytes, unlike other providers' human-readable strings, so it is converted here, not via _size().
		# Packs report a PER-EPISODE size from their own file count, and scrapers/external.py's no-divide list stops it
		# dividing again: its default divides by the TMDb season's episode_count, which for anime is routinely unrelated
		# (TMDb files every Re:ZERO cour under season 1: 85 episodes vs a 12-file cour pack). num_files is inflated by
		# separate subtitle files, but it is the pack's own count and was closer in every case measured.
		try:
			total = float(row.get('total_size') or 0) / 1073741824
			files = int(row.get('num_files') or 1) if package else 1
			dsize = round(total / max(files, 1), 2)
			if dsize: info.insert(0, '%.2f GB' % dsize)
			# The full size still matters -- it is what the debrid service has to hold.
			if package and total: info.append('%.1f GB pack' % total)
		except (TypeError, ValueError): dsize = 0
		item = {'provider': 'animetosho', 'source': 'torrent', 'seeders': seeders,
				'hash': info_hash, 'name': name, 'name_info': name_info, 'quality': quality,
				'language': 'en', 'url': magnet, 'info': ' | '.join(info), 'direct': False,
				'debridonly': True, 'size': dsize}
		# LOCAL PATCH 2026-09-22: the release group, for the picker's Group column. Read from `raw` because clean_name()
		# has already stripped the leading bracket tag, where a fansub group lives.
		group = source_utils.release_group(raw)
		if group: item['release_group'] = group
		if package: item['package'] = package
		# LOCAL PATCH 2026-09-23: tell DeadLight this pack's name names a season and no episodes, so it can drop it when no
		# file listing exists to check it against. Packs only -- a single-file row is its own evidence.
		if package:
			try:
				if _declares_season_without_episodes(row): item['season_only'] = True
			except Exception: pass
		return item

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		eid = data.get('anidb_eid')
		# No eid means the chain upstream could not identify the episode. Returning nothing is correct -- guessing from
		# names would reintroduce exactly what this provider avoids.
		if not eid:
			# LOCAL PATCH 2026-09-22: say so. The most common reason this provider contributes nothing (no Fribb row, or
			# ani.zip withholding an eid for a whole-run entry like Naruto); without a log line it looks like an empty scrape.
			try:
				import xbmc as _x
				_x.log('TOSHO-DIAG: sources SKIPPED, no anidb_eid (aid=%s) -- packs only for this show'
					% data.get('anidb_aid'), _x.LOGINFO)
			except Exception: pass
			return sources
		try:
			rows = self._query('eid=%s' % eid)
			if not rows: return sources
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('ANIMETOSHO')
			return sources

		one_episode = self._one_episode_size(rows)
		seen = set()
		_cour_rejected = 0
		# LOCAL PATCH 2026-09-23: which anime a row belongs to, for the aid reject below.
		_want_aids = set()
		for _a in ([data.get('anidb_aid')] + list(data.get('anidb_part_aids') or [])):
			try:
				if _a: _want_aids.add(int(_a))
			except (TypeError, ValueError): continue
		_aid_rejected = 0
		_name_rejected = 0
		for row in rows:
			try:
				if not isinstance(row, dict): continue
				# LOCAL PATCH 2026-09-23: an eid query can return rows belonging to a DIFFERENT anime (?eid=977, One Piece ep 10,
				# carries rows of the recap series 'One Piece Log: Fish-Man Island Saga', its own AniDB anime). An id test, not a
				# name test. Sibling part aids count (a split season's parts are the same show). Skipped when our own aid is
				# unknown, since an empty expectation must not reject everything.
				if _want_aids:
					try: _ra = int(row.get('anidb_aid') or 0)
					except (TypeError, ValueError): _ra = 0
					if _ra and _ra not in _want_aids:
						_aid_rejected += 1
						continue
				# A multi-file row here is a batch that CONTAINS this eid, so it is a
				# legitimate result and is kept, labelled so DeadLight shows it as a PACK.
				package = 'season' if self._is_pack(row, one_episode) else None
				# LOCAL PATCH 2026-11-04 (release judge, phase 4b): the NAME checks (whole-run absolute number, pack naming another
				# cour, single contradicting the cour) are modules/release_judge's for this provider's rows (an id provider: checks
				# 5 and 6, and the whole-run one), applied after the cache. The aid reject above and sources_packs' range / sibling /
				# part checks read ids and file counts the judge does not see, and stay.
				item = self._build(row, data, package, undesirables, check_foreign_audio)
				if not item or item['hash'] in seen: continue
				seen.add(item['hash'])
				sources.append(item)
			except Exception:
				source_utils.scraper_error('ANIMETOSHO')
				continue
		# LOCAL PATCH 2026-09-21: report this provider's work, so a silent over-reject cannot pass for an index with no
		# releases. Mirrors nyaa.py's NYAA-DIAG so both anime providers report the same way.
		try:
			import xbmc as _x
			_x.log('TOSHO-DIAG: sources eid=%s raw=%d aid_rejected=%d name_rejected=%d cour_rejected=%d kept=%d'
				% (eid, len(rows), _aid_rejected, _name_rejected, _cour_rejected, len(sources)), _x.LOGINFO)
		except Exception: pass
		return sources

	# LOCAL PATCH 2026-09-22: a pack whose NAME declares an episode range must actually contain the episode. "An aid IS
	# one cour" breaks for a long single-entry show: Naruto is ONE aid covering 220 episodes, so its packs are
	# BOX / VOL / EP-range subdivisions ("(EP 37-50)" cannot serve episode 212). A range REJECT only: no season number,
	# nothing compared to TMDb; a pack that declares no range is kept.
	def _pack_excludes_episode(self, row, wanted):
		"""True only when the names state a range and the wanted episode is outside it."""
		if not pack_excludes_episode: return False
		return pack_excludes_episode(_row_names(row), row.get('num_files'), wanted)


	# LOCAL PATCH 2026-11-04: an AniDB id's pack list, kept 3 days. It is the same list whichever episode asks (every
	# check runs per episode afterwards) and costs ~1 s per aid -- TYBW is four aids. Parallel fetching gains nothing (see
	# sources_packs). Kept slim: only the fields read from a row; a failed or empty answer is not kept.
	# 3 days, not hours: a cour's packs appear once it has finished airing and then change slowly, and browsing from a
	# widget skips the episode-list prewarm. Asking fewer aids (this part + part 1) loses right packs: TYBW's all-parts
	# BD collection is filed under a later part's aid.
	_PACK_KEYS = ('num_files', 'total_size', 'torrent_name', 'title', 'info_hash', 'magnet_uri', 'seeders', 'anidb_aid', 'anidb_eid')

	def _aid_packs(self, aid):
		key = 'animetosho_packs_%s' % aid
		try:
			from caches.main_cache import main_cache
			cached = main_cache.get(key)
			if isinstance(cached, list): return cached
		except Exception: main_cache = None
		rows = self._query('aid=%s&order=size-d' % aid, pages=1, limit=_PAGE_MAX)
		if not rows or main_cache is None: return rows
		slim = [dict((k, r[k]) for k in self._PACK_KEYS if r.get(k) is not None) for r in rows if isinstance(r, dict)]
		try: main_cache.set(key, slim, expiration=72)
		except Exception: pass
		return slim

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		"""Season packs, found with the ANIME id rather than the episode id.
		
		A separate query because a batch only carries an anidb_eid once AnimeTosho has file-indexed and matched it, and
		most never are; asking by aid is where nearly all the packs live.
		
		No title or season validation, so `bypass_filter` is unused. Deliberate: an AniDB aid IS one cour, so every row
		already belongs to the exact anime and cour. filter_season_pack would re-introduce name parsing AND reject correct
		rows -- it matches "S02"-style markers against TMDb's season number, which for anime is routinely not what the
		release says. torrentio's kitsu path skips validation for the same reason.
		"""
		sources = []
		if not data: return sources
		# AniDB files an anime per cour, so there is no whole-franchise grouping to ask for. nyaa still answers show-pack
		# requests.
		if search_series: return sources
		aid = data.get('anidb_aid')
		if not aid: return sources
		try:
			# LOCAL PATCH 2026-09-22: ONE request, biggest rows first, at the feed's real page cap (_PAGE_MAX).
			#  - Biggest, not newest: the default date order is an arbitrary slice of a long show, and packs are the large rows.
			#    `order` accepts ONLY size-d and size-a; anything else (seeders-d, a typo) silently returns the default order.
			#  - Size-sorting removes the single-file rows _one_episode_size medians: a 75-row sorted page of a long show holds
			#    none, the median is 0 and every row was rejected. A 200-row page reaches down to singles, so one request carries
			#    both the packs and its own calibration (costs one pack where the window is mostly singles).
			#  - The cap is undocumented; if it ever returns to 75, _is_pack's allow_unknown falls back to the file count and
			#    one_ep in the diag line shows the zeroed threshold.
			# LOCAL PATCH 2026-09-22: ask every part of this season, not just the one scraped. A pack covering the WHOLE split
			# season is filed under the FIRST part's aid, so part 2's aid never sees it. One request per part (most anime have
			# one); rows merged and deduped on info_hash, and every one still faces release_judge._id_pack_reject and DeadLight's
			# cached-pack file listing check. The current aid is asked FIRST so a partial failure still returns its own packs.
			_aids = [aid]
			for _pa in (data.get('anidb_part_aids') or []):
				try:
					if int(_pa) != int(aid): _aids.append(int(_pa))
				except (TypeError, ValueError): continue
			# Serial on purpose: fetching the parts in parallel gained nothing -- overlapping queries each took about twice as
			# long.
			rows, _seen_h, _own_h = [], set(), set()
			for _a in _aids:
				for _r in (self._aid_packs(_a) or []):
					if not isinstance(_r, dict): continue
					_k = (_r.get('info_hash') or _r.get('magnet_uri') or '').lower()
					if _k:
						if _k in _seen_h: continue
						_seen_h.add(_k)
					rows.append(_r)
					if _k and int(_a) == int(aid): _own_h.add(_k)
			if not rows: return sources
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('ANIMETOSHO')
			return sources

		# One window, self-calibrating: the 200-row size-sorted page includes single-file rows even on a long show, so the
		# pack-threshold median comes from the same request (0.76 vs the unsorted sample's 0.70 GB on aid 239).
		one_episode = self._one_episode_size(rows)
		# No single-file row in the window at all: judge on file count rather than dropping
		# everything. See _is_pack's allow_unknown.
		_no_threshold = not one_episode
		# the episode's numbers, for the diag line below (the release judge works out the same set for the pack rejects:
		# release_judge._id_pack_reject)
		def _num(_key):
			try:
				_v = data.get(_key)
				return None if _v is None else int(_v)
			except (TypeError, ValueError): return None
		_wanted = set(x for x in (_num('cour_episode'), _num('season_episode'),
			_num('absolute_episode')) if x is not None)
		# LOCAL PATCH 2026-11-07 (anime core plan phase 2d): the pack-NAME rejects (another part, a declared range without
		# this episode, a sibling series, another cour) are modules/release_judge._id_pack_reject's. This loop keeps what only
		# the provider knows and hands it over as 'pack_facts': both names, the file count, whether the row came from THIS
		# part's aid query (own) and how many parts were merged.
		seen = set()
		for row in rows:
			try:
				if not isinstance(row, dict): continue
				if not self._is_pack(row, one_episode, allow_unknown=_no_threshold): continue
				item = self._build(row, data, 'season', undesirables, check_foreign_audio)
				if not item or item['hash'] in seen: continue
				seen.add(item['hash'])
				item['pack_facts'] = {'names': _row_names(row), 'num_files': row.get('num_files'), 'parts': len(_aids),
									'own': (row.get('info_hash') or '').lower() in _own_h}
				sources.append(item)
			except Exception:
				source_utils.scraper_error('ANIMETOSHO')
				continue
		try:
			import xbmc as _x
			_x.log('TOSHO-DIAG: packs aid=%s parts=%d raw=%d one_ep=%.2fGB packs=%d (judged by the release judge) wanted=%s'
				% (aid, len(_aids), len(rows), (one_episode or 0) / 1073741824.0, len(sources), sorted(_wanted) or '-'), _x.LOGINFO)
		except Exception: pass
		return sources
