# -*- coding: utf-8 -*-
import datetime
from urllib.parse import quote_plus

# LOCAL PATCH 2026-10-15: search text URL-encoded -- raw, '&', '+' and '#' broke the query (and the wrong page was
# cached under the right key). Cache keys keep the raw text.
def _q(query): return quote_plus(str(query))
from caches.meta_cache import cache_function
from caches.lists_cache import lists_cache_object
from modules.settings import get_meta_filter, tmdb_api_key, lists_cache_duraton
from modules.kodi_utils import make_session

# LOCAL PATCH 2026-08-26: pool the failover host too -- make_session only mounts an adapter for the prefix it is given.
# LOCAL PATCH 2026-09-04: passed as extra_mounts rather than mounted here: a module-level `import requests` would defeat
# make_session's laziness, the biggest import cost of a fresh widget process.
session = make_session('https://api.themoviedb.org/3', extra_mounts=('https://api.tmdb.org/3',))


def no_api_key():
	from modules.kodi_utils import notification
	notification('Please set a valid TMDb API Key')
	return []

def movie_release_dates(tmdb_id, api_key):
	# LOCAL PATCH 2026-09-29: release dates alone, for a cached meta saved before 'digital_release' existed. It runs as
	# the loading window opens, so 3 s on the host last proved reachable -- not get_tmdb's 20 s x 2 hosts.
	try: return session.get('https://%s/3/movie/%s/release_dates?api_key=%s' % (tmdb_api_host(), tmdb_id, api_key), timeout=3.0).json()['results']
	except Exception: return None

# LOCAL PATCH 2026-10-19: no 'translations' (a third to half of the answer): it fed only english_title, and with
# language=en TMDb's own title already is that. english_title stays None and its readers fall back to the title. No
# 'external_ids' for movies either: movie_meta reads the top-level imdb_id.
# LOCAL PATCH 2026-10-19: videos in these languages too (TMDb otherwise returns only the request's `language`), so
# titles whose trailers are all Hindi / Japanese / Tamil get one. TMDb honours only the FIRST FIVE values. No 'null':
# untagged videos never came back anyway. metadata._trailers_newest_first still prefers English.
_VIDEO_LANGUAGES = 'en,hi,ja,ta,ml'

def movie_details(tmdb_id, api_key):
	try:
		url = 'https://api.themoviedb.org/3/movie/%s?api_key=%s&language=en&append_to_response=videos,credits,release_dates,alternative_titles,' \
		'images,keywords&include_image_language=en,null&include_video_language=%s' % (tmdb_id, api_key, _VIDEO_LANGUAGES)
		return get_tmdb(url).json()
	except Exception as e:
		from modules.kodi_utils import logger
		from modules.utils import safe_err   # LOCAL PATCH 2026-10-25 (4.0.5): str(e) of a request error carries ?api_key=
		logger('DEADLIGHT_TMDB_DIAG', f'movie_details({tmdb_id}) outer failure :: {safe_err(e)}')
		return None

# LOCAL PATCH 2026-08-26: per-season trailers. TMDb's append_to_response caps at 20 items; the 8 above leave room for
# 12 season video blocks, so seasons 1-12 ride along on the (cached) show request. Seasons a show doesn't have are just
# absent from the response, so a fixed 1..12 is safe. See metadata._pick_trailer.
_SEASON_VIDEO_APPENDS = ','.join('season/%d/videos' % i for i in range(1, 13))

def tvshow_details(tmdb_id, api_key):
	try:
		url = 'https://api.themoviedb.org/3/tv/%s?api_key=%s&language=en&append_to_response=external_ids,videos,credits,content_ratings,alternative_titles,' \
		'images,keywords,%s&include_image_language=en,null&include_video_language=%s' % (tmdb_id, api_key, _SEASON_VIDEO_APPENDS, _VIDEO_LANGUAGES)
		return get_tmdb(url).json()
	except: return None

def tvshow_seasons_light(tmdb_id):
	"""LOCAL PATCH 2026-09-12: bare /tv/{id} purely for its `seasons` array.

	tvshow_details() is far heavier and uncached. The flat-season repair in fribb_mappings needs only the season
	NUMBERS, to tell a show whose cours Fribb scattered across seasons TMDb does not have from one that has them.
	Cached 168h; only reached for shows that passed the index-only candidate filter."""
	# LOCAL PATCH 2026-10-19: the show's cached meta already holds that array (season_data is TMDb's `seasons`) and is
	# refreshed at least as often. Asked only when it is not cached.
	try:
		from caches.meta_cache import meta_cache
		cached = meta_cache.get('tvshow', 'tmdb_id', tmdb_id)
		if cached and cached.get('season_data'): return {'seasons': cached['season_data']}
	except Exception: pass
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tvshow_seasons_light_%s' % tmdb_id
	url = 'https://api.themoviedb.org/3/tv/%s?api_key=%s&language=en' % (tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def episode_tvdb_id(tmdb_id, season, episode):
	"""LOCAL PATCH 2026-11-03: the TVDB episode id TMDb records for one episode (int) or None -- the key that maps a TMDb
	special onto TVDB's / Stremio's season-0 number (modules/cinemeta.special_episode). Cached a year (LOCAL PATCH
	2026-11-08): the id does not change, and an anime scrape waits on it (scrape_prewarm._warm_tvdb_ids fetches a list's ahead)."""
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return None
	string = 'episode_tvdb_id_%s_%s_%s' % (tmdb_id, season, episode)
	url = 'https://api.themoviedb.org/3/tv/%s/season/%s/episode/%s/external_ids?api_key=%s' % (tmdb_id, season, episode, api_key)
	try:
		# asked from two threads at once by the anime scrape (Stremio pair + episode card): cache_function makes it one request
		value = (cache_function(get_tmdb, string, url, expiration=8760) or {}).get('tvdb_id')
		return int(value) if value else None
	except Exception: return None

def episode_groups_data(tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'episode_groups_data_%s' % tmdb_id
	url = 'https://api.themoviedb.org/3/tv/%s/episode_groups?api_key=%s' % (tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def episode_group_details(group_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'episode_groups_details_%s' % group_id
	url = 'https://api.themoviedb.org/3/tv/episode_group/%s?api_key=%s' % (group_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def movie_set_details(collection_id, api_key):
	try:
		url = 'https://api.themoviedb.org/3/collection/%s?api_key=%s&language=en' % (collection_id, api_key)
		return get_tmdb(url).json()
	except: return None

def movie_external_id(external_source, external_id, api_key):
	try:
		string = 'movie_external_id_%s_%s' % (external_source, external_id)
		url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=%s' % (external_id, api_key, external_source)
		result = cache_function(get_tmdb, string, url)
		result = result['movie_results']
		if result: return result[0]
		else: return None
	except: return None

def tvshow_external_id(external_source, external_id, api_key):
	try:
		string = 'tvshow_external_id_%s_%s' % (external_source, external_id)
		url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=%s' % (external_id, api_key, external_source)
		result = cache_function(get_tmdb, string, url)
		result = result['tv_results']
		if result: return result[0]
		else: return None
	except: return None

# LOCAL PATCH 2026-11-01 (cleanup): one resolver for the {'tmdb', 'imdb', 'tvdb'} id dicts Trakt and MDBList rows carry:
# the TMDb id as given, else looked up by IMDb id (shows: then TVDB id) through the cached /find above. None when
# nothing resolves.
def tmdb_id_from_ids(ids, media_type):
	ids = ids or {}
	if ids.get('tmdb'): return ids['tmdb']
	lookup, sources = (movie_external_id, ('imdb',)) if media_type == 'movie' else (tvshow_external_id, ('imdb', 'tvdb'))
	for source in sources:
		if not ids.get(source): continue
		try:
			res = lookup('%s_id' % source, ids[source], tmdb_api_key())
			if res: return res['id']
		except: pass
	return None

def tmdb_movies_oscar_winners(page_no):
	from modules.meta_lists import oscar_winners
	return oscar_winners()[page_no-1]


def tmdb_keywords_by_query(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_keywords_by_query_%s_%s' % (query, page_no)
	url = 'https://api.themoviedb.org/3/search/keyword?api_key=%s&query=%s&page=%s' % (api_key, _q(query), page_no)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_movie_keywords(tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movie_keywords_%s' % tmdb_id
	url = 'https://api.themoviedb.org/3/movie/%s/keywords?api_key=%s' % (tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_tv_keywords(tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_keywords_%s' % tmdb_id
	url = 'https://api.themoviedb.org/3/tv/%s/keywords?api_key=%s' % (tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_movie_keyword_results(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movie_keyword_results_%s_%s' % (tmdb_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&with_keywords=%s&page=%s' % (api_key, tmdb_id, page_no)
	return lists_cache_object(_list_data, string, url, expiration=96)

def tmdb_tv_keyword_results(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_keyword_results_%s_%s' % (tmdb_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&with_keywords=%s&page=%s' % (api_key, tmdb_id, page_no)
	return lists_cache_object(_list_data, string, url, expiration=96)

def tmdb_movie_keyword_results_direct(query, page_no):
	if tmdb_api_key() in (None, 'empty_setting', ''): return no_api_key()
	try:
		results = tmdb_movie_keyword_results(tmdb_keywords_by_query(query, page_no)['results'][0]['id'], page_no)
		results['total_pages'] = 1
		return results
	except: return None

def tmdb_tv_keyword_results_direct(query, page_no):
	if tmdb_api_key() in (None, 'empty_setting', ''): return no_api_key()
	try:
		results = tmdb_tv_keyword_results(tmdb_keywords_by_query(query, page_no)['results'][0]['id'], page_no)
		results['total_pages'] = 1
		return results
	except: return None

def tmdb_company_id(query):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_company_id_%s' % query
	url = 'https://api.themoviedb.org/3/search/company?api_key=%s&query=%s' % (api_key, _q(query))
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_media_images(media_type, tmdb_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	if media_type in ('movie', 'movies'): media_type = 'movie'
	else: media_type = 'tv'
	string = 'tmdb_media_images_%s_%s' % (media_type, tmdb_id)
	url = 'https://api.themoviedb.org/3/%s/%s/images?include_image_language=en,null&api_key=%s' % (media_type, tmdb_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

# LOCAL PATCH 2026-10-19: the logos tagged `language` alone. The details requests ask for en,null images only, so a title
# whose logos are all in its own language (often anime, Hindi / Tamil / Chinese titles) had none and showed its name as
# text. Asked only when no source had an English or untagged logo; 48 h, as a new title's logos often come late.
def tmdb_logos(media_type, tmdb_id, language):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', '') or not language: return []
	media_type = 'movie' if media_type == 'movie' else 'tv'
	string = 'tmdb_logos_%s_%s_%s' % (media_type, tmdb_id, language)
	url = 'https://api.themoviedb.org/3/%s/%s/images?include_image_language=%s&api_key=%s' % (media_type, tmdb_id, language, api_key)
	try: return [l for l in (cache_function(get_tmdb, string, url, expiration=48).get('logos') or []) if l.get('file_path')]
	except Exception: return []


def tmdb_movies_discover(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	if '[current_date]' in query: query = query.replace('[current_date]', get_current_date())
	if '[random]' in query: query = query.replace('[random]', '')
	string = url = query + '&api_key=%s&page=%s' % (api_key, page_no)
	return lists_cache_object(get_tmdb, string, url, json=True, expiration=min(lists_cache_duraton(), 24))

def tmdb_movies_popular(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_popular_en_%s' % page_no   # LOCAL PATCH 2026-10-19: see _english_list_data
	url = 'https://api.themoviedb.org/3/movie/popular?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (api_key, page_no)
	return lists_cache_object(_english_list_data, string, url)

def tmdb_movies_popular_today(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_popular_today_en_%s' % page_no   # LOCAL PATCH 2026-10-19: see _english_list_data
	url = 'https://api.themoviedb.org/3/trending/movie/day?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (api_key, page_no)
	return lists_cache_object(_english_list_data, string, url)

# LOCAL PATCH 2026-08-05 (POV 6.08 P1 port): TMDb "Trending This Week" as a Trakt-independent replacement.
# /trending/{movie,tv}/week ranks by TMDb's view velocity, closer to Trakt's trending than /trending/movie/day.
def tmdb_movies_trending(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_trending_en_%s' % page_no   # LOCAL PATCH 2026-10-19: see _english_list_data
	url = 'https://api.themoviedb.org/3/trending/movie/week?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (api_key, page_no)
	return lists_cache_object(_english_list_data, string, url)

def tmdb_movies_blockbusters(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_blockbusters_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&sort_by=revenue.desc&page=%s' % (api_key, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_movies_in_theaters(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_in_theaters_en_%s' % page_no   # LOCAL PATCH 2026-10-19: see _english_list_data
	url = 'https://api.themoviedb.org/3/movie/now_playing?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (api_key, page_no)
	return lists_cache_object(_english_list_data, string, url)

def tmdb_movies_upcoming(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, future_date = get_dates(31, reverse=False)
	string = 'tmdb_movies_upcoming_%s' % page_no
	# LOCAL PATCH 2026-10-19: primary_release_date, not release_date: with region=US, release_date matches a film when ANY
	# of its US releases falls in the window, so re-releases and late limited / festival dates filled page 1.
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&primary_release_date.gte=%s&primary_release_date.lte=%s' \
	'&with_release_type=3|2|1&page=%s' % (api_key, current_date, future_date, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_movies_latest_releases(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, previous_date = get_dates(31, reverse=True)
	string = 'tmdb_movies_latest_releases_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&release_date.gte=%s&release_date.lte=%s' \
	'&with_release_type=4|5|6&page=%s' % (api_key, previous_date, current_date, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_movies_premieres(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, previous_date = get_dates(31, reverse=True)
	string = 'tmdb_movies_premieres_%s' % page_no
	# LOCAL PATCH 2026-10-19: primary_release_date, as tmdb_movies_upcoming (release_date with region=US matches
	# re-releases).
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en&primary_release_date.gte=%s&primary_release_date.lte=%s' \
	'&with_release_type=1|3|2&page=%s' % (api_key, previous_date, current_date, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_movies_genres(genre_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_genres_%s_%s' % (genre_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&with_genres=%s&language=en-US&region=US&with_original_language=en&sort_by=popularity.desc&release_date.lte=%s&page=%s' \
			% (api_key, genre_id, get_current_date(), page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_movies_languages(language, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_languages_%s_%s' % (language, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&with_original_language=%s&sort_by=popularity.desc&release_date.lte=%s&page=%s' \
			% (api_key, language, get_current_date(), page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_movies_certifications(certification, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_certifications_%s_%s' % (certification, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&with_original_language=en' \
	'&certification_country=US&certification=%s&sort_by=popularity.desc&release_date.lte=%s&page=%s' % (api_key, certification, get_current_date(), page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_movies_year(year, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_year_%s_%s' % (year, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&primary_release_year=%s&page=%s' \
							% (api_key, year, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_movies_decade(decade, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_decade_%s_%s' % (decade, page_no)
	start = '%s-01-01' % decade
	end = get_dates(2)[0] if decade == '2020' else '%s-12-31' % str(int(decade) + 9)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&primary_release_date.gte=%s' \
			'&primary_release_date.lte=%s&page=%s' % (api_key, start, end, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_movies_providers(provider, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_providers_%s_%s' % (provider, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=popularity.desc&watch_region=US&with_watch_providers=%s&page=%s' % (api_key, provider, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_movies_recommendations(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_recommendations_%s_%s' % (tmdb_id, page_no)
	url = 'https://api.themoviedb.org/3/movie/%s/recommendations?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (tmdb_id, api_key, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_movies_search(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	meta_filter = get_meta_filter()
	string = 'tmdb_movies_search_%s_%s_%s' % (query, meta_filter, page_no)
	url = 'https://api.themoviedb.org/3/search/movie?api_key=%s&language=en-US&include_adult=%s&query=%s&page=%s' % (api_key, meta_filter, _q(query), page_no)
	return lists_cache_object(_search_data, string, url)

def tmdb_movies_companies(company_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_movies_companies_%s_%s' % (company_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/movie?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&with_companies=%s&page=%s' \
							% (api_key, company_id, page_no)
	return lists_cache_object(_list_data, string, url, expiration=168)

tmdb_tv_discover = tmdb_movies_discover   # the media type is in the query: one body for both (callers look the name up as a string)

def tmdb_tv_popular(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_popular_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en' \
	'&without_keywords=210024&page=%s' % (api_key, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_tv_popular_today(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, previous_date = get_dates(180, reverse=True)
	string = 'tmdb_tv_popular_today_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&without_keywords=210024' \
	'&include_null_first_air_dates=false&first_air_date.gte=%s' \
	'&first_air_date.lte=%s&page=%s' % (api_key, previous_date, current_date, page_no)
	return lists_cache_object(_list_data, string, url)

# LOCAL PATCH 2026-08-05 (POV 6.08 P1 port): TV counterpart of tmdb_movies_trending.
def tmdb_tv_trending(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_trending_en_%s' % page_no   # LOCAL PATCH 2026-10-19: see _english_list_data
	url = 'https://api.themoviedb.org/3/trending/tv/week?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (api_key, page_no)
	return lists_cache_object(_english_list_data, string, url)


def tmdb_tv_premieres(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, previous_date = get_dates(31, reverse=True)
	string = 'tmdb_tv_premieres_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false' \
	'&first_air_date.gte=%s&first_air_date.lte=%s&without_keywords=210024&page=%s' % (api_key, previous_date, current_date, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_tv_airing_today(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	expiration = min(lists_cache_duraton(), 24)
	# LOCAL PATCH 2026-10-19: /discover with today's air date -- /tv/airing_today ignores with_original_language and
	# without_keywords. Same popularity order. The date is in the key: a page kept up to 24 h must not answer the next day.
	today = get_current_date()
	string = 'tmdb_tv_airing_today_d_%s_%s' % (today, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&with_original_language=en&without_keywords=210024' \
	'&sort_by=popularity.desc&air_date.gte=%s&air_date.lte=%s&page=%s' % (api_key, today, today, page_no)
	return lists_cache_object(_list_data, string, url, expiration=expiration)

def tmdb_tv_on_the_air(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	# LOCAL PATCH 2026-10-19: /discover over the next 7 days (TMDb's own on_the_air window) -- /tv/on_the_air ignores the
	# language and anime filters. Dated key, as airing_today.
	current_date, future_date = get_dates(7, reverse=False)
	string = 'tmdb_tv_on_the_air_d_%s_%s' % (current_date, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&with_original_language=en&without_keywords=210024' \
	'&sort_by=popularity.desc&air_date.gte=%s&air_date.lte=%s&page=%s' % (api_key, current_date, future_date, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_tv_upcoming(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, future_date = get_dates(31, reverse=False)
	string = 'tmdb_tv_upcoming_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&language=en-US&region=US&with_original_language=en&without_keywords=210024' \
	'&first_air_date.gte=%s&first_air_date.lte=%s&page=%s' % (api_key, current_date, future_date, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_tv_genres(genre_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_genres_%s_%s' % (genre_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&with_genres=%s&language=en-US&region=US&with_original_language=en' \
	'&include_null_first_air_dates=false&first_air_date.lte=%s&without_keywords=210024&page=%s' % (api_key, genre_id, get_current_date(), page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_tv_languages(language, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_languages_%s_%s' % (language, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&include_null_first_air_dates=false&with_original_language=%s&first_air_date.lte=%s' \
	'&without_keywords=210024&page=%s' % (api_key, language, get_current_date(), page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_tv_networks(network_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_networks_%s_%s' % (network_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false' \
	'&with_networks=%s&first_air_date.lte=%s&without_keywords=210024&page=%s' % (api_key, network_id, get_current_date(), page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_tv_providers(provider, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_providers_%s_%s' % (provider, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&watch_region=US&with_watch_providers=%s&include_null_first_air_dates=false' \
	'&first_air_date.lte=%s&without_keywords=210024&page=%s' % (api_key, provider, get_current_date(), page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_tv_year(year, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_year_%s_%s' % (year, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false' \
	'&first_air_date_year=%s&without_keywords=210024&page=%s' % (api_key, year, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_tv_decade(decade, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_decade_%s_%s' % (decade, page_no)
	start = '%s-01-01' % decade
	end = get_dates(2)[0] if decade == '2020' else '%s-12-31' % str(int(decade) + 9)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&language=en-US&region=US&with_original_language=en&include_null_first_air_dates=false' \
	'&first_air_date.gte=%s&first_air_date.lte=%s&without_keywords=210024&page=%s' % (api_key, start, end, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_tv_recommendations(tmdb_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_recommendations_%s_%s' % (tmdb_id, page_no)
	url = 'https://api.themoviedb.org/3/tv/%s/recommendations?api_key=%s&language=en-US&region=US&with_original_language=en&page=%s' % (tmdb_id, api_key, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_tv_search(query, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	meta_filter = get_meta_filter()
	string = 'tmdb_tv_search_%s_%s_%s' % (query, meta_filter, page_no)
	url = 'https://api.themoviedb.org/3/search/tv?api_key=%s&language=en-US&include_adult=%s&query=%s&page=%s' % (api_key, meta_filter, _q(query), page_no)
	return lists_cache_object(_search_data, string, url)

def tmdb_anime_popular(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_anime_popular_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&page=%s' % (api_key, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_anime_popular_recent(page_no):
	from modules.meta_lists import years_tvshows
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_tv_anime_popular_recent_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&sort_by=first_air_date.desc&include_null_first_air_dates=false&first_air_date_year=%s&page=%s' \
							% (api_key, years_tvshows()[0]['id'], page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_anime_premieres(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, previous_date = get_dates(93, reverse=True)
	string = 'tmdb_anime_premieres_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&include_null_first_air_dates=false&first_air_date.gte=%s&first_air_date.lte=%s&page=%s' \
							% (api_key, previous_date, current_date, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_anime_upcoming(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, future_date = get_dates(93, reverse=False)
	string = 'tmdb_anime_upcoming_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&first_air_date.gte=%s&first_air_date.lte=%s&sort_by=first_air_date.asc&page=%s' \
							% (api_key, current_date, future_date, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_anime_on_the_air(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	current_date, future_date = get_dates(7, reverse=False)
	string = 'tmdb_anime_on_the_air_%s' % page_no
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&air_date.gte=%s&air_date.lte=%s&page=%s' \
							% (api_key, current_date, future_date, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_anime_genres(genre_id, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_anime_genres_%s_%s' % (genre_id, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&with_genres=%s&include_null_first_air_dates=false&first_air_date.lte=%s&page=%s' \
							% (api_key, genre_id, get_current_date(), page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_anime_providers(provider, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_anime_providers_%s_%s' % (provider, page_no)
	# LOCAL PATCH 2026-10-19: 210024 ('anime', as every other anime query); 210048 is no TMDb keyword (404).
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&watch_region=US&with_watch_providers=%s&include_null_first_air_dates=false' \
	'&first_air_date.lte=%s&page=%s' % (api_key, provider, get_current_date(), page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_anime_year(year, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_anime_year_%s_%s' % (year, page_no)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&include_null_first_air_dates=false&first_air_date_year=%s&page=%s' % (api_key, year, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_anime_decade(decade, page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_anime_decade_%s_%s' % (decade, page_no)
	start = '%s-01-01' % decade
	end = get_dates(2)[0] if decade == '2020' else '%s-12-31' % str(int(decade) + 9)
	url = 'https://api.themoviedb.org/3/discover/tv?api_key=%s&with_keywords=210024&include_null_first_air_dates=false&first_air_date.gte=%s' \
			'&first_air_date.lte=%s&page=%s' % (api_key, start, end, page_no)
	return lists_cache_object(_list_data, string, url)

def tmdb_popular_people(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_people_popular_%s' % page_no
	url = 'https://api.themoviedb.org/3/person/popular?api_key=%s&language=en&page=%s' % (api_key, page_no)
	return cache_function(get_tmdb, string, url, expiration=48)

def tmdb_trending_people_day(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_people_trending_day_%s' % page_no
	url = 'https://api.themoviedb.org/3/trending/person/day?api_key=%s&page=%s' % (api_key, page_no)
	return cache_function(get_tmdb, string, url, expiration=48)

def tmdb_trending_people_week(page_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_people_trending_week_%s' % page_no
	url = 'https://api.themoviedb.org/3/trending/person/week?api_key=%s&page=%s' % (api_key, page_no)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_people_full_info(actor_id):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	string = 'tmdb_people_full_info_%s' % actor_id
	url = 'https://api.themoviedb.org/3/person/%s?api_key=%s&language=en&append_to_response=external_ids,combined_credits,images,tagged_images' % (actor_id, api_key)
	return cache_function(get_tmdb, string, url, expiration=168)

def tmdb_people_info(query, page_no=1):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	meta_filter = get_meta_filter()
	string = 'tmdb_people_info_%s_%s_%s' % (query, meta_filter, page_no)
	url = 'https://api.themoviedb.org/3/search/person?api_key=%s&language=en&include_adult=%s&query=%s&page=%s' % (api_key, meta_filter, _q(query), page_no)
	return cache_function(get_tmdb, string, url, expiration=4)

def season_episodes_details(tmdb_id, season_no):
	api_key = tmdb_api_key()
	if api_key in (None, 'empty_setting', ''): return no_api_key()
	try:
		# LOCAL PATCH 2026-10-03: no append_to_response=credits -- its only caller (metadata.episodes_meta) reads ['episodes'],
		# whose crew and guest_stars come with the default payload.
		url = 'https://api.themoviedb.org/3/tv/%s/season/%s?api_key=%s&language=en' % (tmdb_id, season_no, api_key)
		return get_tmdb(url).json()
	except: return None

def get_dates(days, reverse=True):
	current_date = get_current_date(return_str=False)
	if reverse: new_date = (current_date - datetime.timedelta(days=days)).strftime('%Y-%m-%d')
	else: new_date = (current_date + datetime.timedelta(days=days)).strftime('%Y-%m-%d')
	return str(current_date), new_date

def get_current_date(return_str=True):
	if return_str: return str(datetime.date.today())
	else: return datetime.date.today()


def get_data(url):
	return get_tmdb(url).json()

# LOCAL PATCH 2026-10-19: /movie/popular, /movie/now_playing and /trending ignore with_original_language (and region /
# without_keywords). The page keeps only original-language-'en' rows; paging is TMDb's, so a page can be short. Cached
# under a '_en' key so a page stored unfiltered is never served.
def _english_list_data(url):
	data = _list_data(url)
	try: data['results'] = [r for r in data['results'] if r.get('original_language') == 'en']
	except Exception: pass
	return data

# LOCAL PATCH 2026-10-02: a search page's detail calls run on SEARCH_POOL connections opened WHILE the search request is
# in flight. Each plugin call is a new process, so every connection starts cold (~1.1-1.5 s TLS over a long route), and
# 20 detail threads paid it at once. Warm-up only when the search itself is not cached (it is the builder
# lists_cache_object calls), one tiny request per connection, never blocking the search.
SEARCH_POOL = 8
# Fewer warm-ups than workers: they share the search request's own cold handshake time, and more of them slow it
# (4 measured best).
_SEARCH_WARM = 4

def _warm_connections(count):
	from threading import Thread
	host = _tmdb_hosts_in_order()[0]
	url = 'https://%s/3/configuration?api_key=%s' % (host, tmdb_api_key())
	def _open():
		try: session.get(url, timeout=(3.05, 5.0))
		except Exception: pass
	threads = [Thread(target=_open, daemon=True) for _ in range(count)]
	for t in threads: t.start()
	return threads

# LOCAL PATCH 2026-10-06: a skin search row (light rows, metadata.light_meta) fetches no details, so the _SEARCH_WARM
# warm-ups only slowed the search's own handshake. Instead ONE connection is opened during search_superseded's idle wait,
# and the search waits for it (_PREWARM) and goes out on it.
_LIGHT_SEARCH, _PREWARM = False, None

def light_search():
	global _LIGHT_SEARCH
	_LIGHT_SEARCH = True

def _search_data(url):
	if _PREWARM is not None: _PREWARM.join(3.5)   # the connection opened during the wait: reuse it, not a second cold one
	if not _LIGHT_SEARCH: _warm_connections(_SEARCH_WARM)
	return get_data(url)

# LOCAL PATCH 2026-10-06: the skin searches as you type, and a one-letter TMDb search matches junk ('s' matches every
# "...'s" title -- TMDb splits "Hippo's" into hippo + s). Under SEARCH_MIN_CHARS only an EXACT title match is kept (so
# Up, It, Us, X, 9, Oz still come up), one page only. Used by the movie and TV search lists, not by the AniList / AI
# title lookups, which search with whole titles.
SEARCH_MIN_CHARS = 3

def _title_key(title):
	# letters of ANY script are kept: ASCII-only turned original titles into one letter ('ブレンド・S' -> 's') that passed
	# as exact matches
	import re
	return re.sub(r'[\W_]+', '', str(title or '').lower())

# LOCAL PATCH 2026-10-06: search-as-you-type started a full search per key, all competing, though only the last is
# shown. A skin search row now waits SEARCH_SETTLE seconds and gives up, empty, when the search box no longer holds its
# query. The box is read as the skin builds the path (AF3 Path_SearchTerm: Control.GetLabel(3000).index(1)); when that
# is empty -- DeadLight's own search dialog, another window or skin -- nothing waits.
SEARCH_SETTLE = 0.4

def search_superseded(query, is_external):
	global _PREWARM
	if not is_external: return False
	try:
		import xbmc
		want = str(query or '').strip().lower()
		box = lambda: xbmc.getInfoLabel('Control.GetLabel(3000).index(1)').strip().lower()
		now = box()
		# LOCAL PATCH 2026-10-25: an empty box in AF3's own search window (Custom_1105_Search) means the box was cleared and
		# this row is left over. Anywhere else an empty box still means no box at all: search.
		if not now:
			if not xbmc.getCondVisibility('Window.IsVisible(1105)'): return False
			from modules.kodi_utils import logger
			logger('search.settle', 'dropped %r, the search box is empty' % want)
			return True
		if now == want:
			_PREWARM = _warm_connections(1)[0]   # LOCAL PATCH 2026-10-06: the TLS handshake overlaps the wait (see _search_data)
			if xbmc.Monitor().waitForAbort(SEARCH_SETTLE): return True
		later = box() if now == want else now
		if later and later != want:
			from modules.kodi_utils import logger
			logger('search.settle', 'dropped %r, the box now says %r' % (want, later))
			return True
		return False
	except Exception: return False

def short_search_filter(query, data):
	"""(data, short): data unchanged from SEARCH_MIN_CHARS characters on; below, only its exact title matches, one page."""
	if len(str(query or '').strip()) >= SEARCH_MIN_CHARS: return data, False
	want = _title_key(query)
	keep = [i for i in (data or {}).get('results') or [] if want and want in
			(_title_key(i.get('title') or i.get('name')), _title_key(i.get('original_title') or i.get('original_name')))]
	return dict(data or {}, results=keep, total_pages=1, page=1), True

# LOCAL PATCH 2026-10-03 (3.0.8): the catalogue lists (popular, trending, genres, networks, anime ...) the same way, so a
# cold page's 20 details do not go out on 20 cold connections. _list_data runs only on a list-cache miss; LAST_LIST_COLD
# tells the indexer to size its detail pool to SEARCH_POOL. Read it right after the page call -- the next-page prefetch
# sets it too, from its own thread.
LAST_LIST_COLD = False

# LOCAL PATCH 2026-10-20: a list's connections are warmed once per call: the next-page prefetch (modules/page_prefetch)
# runs in the same process right after the list, whose connections are still warm in the pool. Search keeps its own
# warm-ups (_search_data). Reset per call (modules/invocation).
_LIST_WARMED = False

def _list_data(url):
	global LAST_LIST_COLD, _LIST_WARMED
	LAST_LIST_COLD = True
	if not _LIST_WARMED:
		_LIST_WARMED = True
		_warm_connections(_SEARCH_WARM)
	return get_data(url)

# LOCAL PATCH 2026-08-26: TMDb API host failover. api.themoviedb.org is reset at TLS handshake on some networks
# (ConnectionResetError 10054); api.tmdb.org is TMDb's alternate host, byte-identical JSON on the same paths. Image
# delivery (image.tmdb.org) is unaffected, so only the API host is swapped.
# The winner is kept in a window property, NOT a module global: with reuselanguageinvoker=false module state dies with
# every invocation, and a global would re-probe the dead host on every call.
_TMDB_HOSTS = ('api.themoviedb.org', 'api.tmdb.org')
_TMDB_HOST_PROP = 'deadlight.tmdb_api_host'


# LOCAL PATCH 2026-10-02: the preference is changed only by a FAILOVER (one host failed, the other then answered), and
# survives a Kodi restart (7 days in main_cache). Not "whichever host answered last": the blocked host still gets
# through now and then, and each lucky success flipped the preference back so the next requests paid the reset again.
_TMDB_HOST_CACHE = 'tmdb_api_host_preferred'

def _tmdb_hosts_in_order():
	try:
		from modules.kodi_utils import get_property, set_property
		preferred = get_property(_TMDB_HOST_PROP)
		if not preferred:
			from caches.main_cache import main_cache
			preferred = main_cache.get(_TMDB_HOST_CACHE) or ''
			# LOCAL PATCH 2026-11-10: 'none' when no failover is stored, so the next request skips this cache read -- it missed on
			# every TMDb request (cache audit 2026-11-10). 'none' is no host: the default order below applies.
			set_property(_TMDB_HOST_PROP, preferred if preferred in _TMDB_HOSTS else 'none')
	except Exception:
		preferred = ''
	if preferred in _TMDB_HOSTS:
		return (preferred,) + tuple(h for h in _TMDB_HOSTS if h != preferred)
	return _TMDB_HOSTS


def tmdb_api_host():
	"""Host other TMDb clients should use. Reflects whatever get_tmdb last proved
	reachable, so tmdblist_api rides the same failover without duplicating it."""
	return _tmdb_hosts_in_order()[0]


# LOCAL PATCH 2026-10-25: after a call failed on every host, TMDb is taken as down for _TMDB_DOWN_SECONDS (a Home
# property, so every plugin process sees it) and get_tmdb answers None at once -- otherwise each title waits through
# both hosts' resets (~2.1 s each) and widgets take 10x longer. Nothing failed is cached, so the next build fills rows.
_TMDB_DOWN_PROP = 'deadlight.tmdb_down_until'
_TMDB_DOWN_SECONDS = 20
_tmdb_down_logged = False

def _tmdb_down():
	global _tmdb_down_logged
	try:
		import time
		from modules.kodi_utils import get_property
		until = float(get_property(_TMDB_DOWN_PROP) or 0)
		if time.time() >= until: return False
	except (TypeError, ValueError): return False
	if not _tmdb_down_logged:
		_tmdb_down_logged = True
		from modules.kodi_utils import logger
		logger('DEADLIGHT_TMDB_DIAG', 'TMDb marked down for %.0f s more: requests skipped' % (until - time.time()))
	return True

def get_tmdb(url):
	if _tmdb_down(): return None
	last_error = None
	for host in _tmdb_hosts_in_order():
		try_url = url
		for known in _TMDB_HOSTS:
			if known != host: try_url = try_url.replace('https://%s/' % known, 'https://%s/' % host)
		try:
			# LOCAL PATCH 2026-10-02: (connect, read) instead of 20 s for both: a dead host fails over in ~3 s, while reads keep a
			# generous 10 s (detail calls take under 1 s).
			response = session.get(try_url, timeout=(3.05, 10.0))
		except Exception as e:
			last_error = e
			continue
		if last_error is not None:   # answered only after another host failed: a real failover, remember it
			try:
				from modules.kodi_utils import get_property, set_property
				if get_property(_TMDB_HOST_PROP) != host:
					set_property(_TMDB_HOST_PROP, host)
					from caches.main_cache import main_cache
					main_cache.set(_TMDB_HOST_CACHE, host, expiration=168)
			except Exception: pass
		return response
	from modules.kodi_utils import logger, set_property
	from modules.utils import safe_err, url_path   # LOCAL PATCH 2026-10-25 (4.0.5): the url's query holds api_key
	logger('DEADLIGHT_TMDB_DIAG', f'get_tmdb failed on all hosts for {url_path(url)} :: {safe_err(last_error) if last_error else None}')
	try:
		import time
		set_property(_TMDB_DOWN_PROP, str(time.time() + _TMDB_DOWN_SECONDS))
	except Exception: pass
	return None
