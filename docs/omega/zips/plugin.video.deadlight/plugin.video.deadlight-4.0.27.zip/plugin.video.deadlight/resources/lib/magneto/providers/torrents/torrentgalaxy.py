# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-10-31: torrentgalaxy -- TorrentGalaxy's JSON search, searched by NAME (POV 6.10 added it with its twin
	therarbg; they are ONE database: identical rows for every query tried, so this provider asks torrentgalaxy.one and falls
	back to therarbg.to when that request fails).

	Measured 2026-10-31 against Torrentio and knaben for the same titles (matching rows / in neither): The Last of Us S02E03
	44 / 7 (2160p + 1080p CRAV WEB-DL), Severance S02E05 34 / 8 (ATVP WEB-DL), Banshee S02E02 5 / 2 (AMZN WEB-DL), Dune:
	Part Two 50 / 8 (BluRay TrueHD); anime (Frieren) nothing. 0.6-1.3 s a query. This network resets ~40 % of its connections
	(WinError 10054, by SNI); client.request retries those.

	API: <base>/get-posts/format:json:keywords:<query>   No key. {'count', 'total', 'page_size': 50, 'links', 'results': [
	  {'n' name, 'h' info hash (upper case), 'se' seeders, 'le' leechers, 's' size in bytes, 'c' category ('TV', 'Movies',
	   ...), 'i' IMDb id or None, 'tg' tags, ...}]}  -- the first page only (50 rows), as POV.
	A row whose 'i' names ANOTHER IMDb id than the title's is dropped: 'Dance Brothers S01E06' matched a 'Brothers S01E06'
	query by name. Not in POV.

	Laid out like apibay.py (episode / season-pack / show-pack queries, the pack ones in parallel threads), using
	client.request so the loading window's ok / failed tally sees it. LOCAL PATCH 2026-11-01 (cleanup): the bodies are
	provider_base.NameSearchSource's.
"""

import json
from urllib.parse import quote
from magneto.modules import client
from magneto.modules.provider_base import NameSearchSource

_VIDEO = ('TV', 'Movies', 'Anime', 'Documentaries')


class source(NameSearchSource):
	provider = 'torrentgalaxy'
	base_links = ('https://torrentgalaxy.one', 'https://therarbg.to')
	search_link = '/get-posts/format:json:keywords:%s'
	name_key, hash_key, seeders_key, size_key = 'n', 'h', 'se', 's'

	def _prepare(self, data):
		imdb = str(data.get('imdb') or '')
		self.imdb = imdb if imdb.startswith('tt') and imdb.strip('t0') else None

	def _request(self, category, query):
		results = None
		for base in self.base_links:
			results = client.request('%s%s' % (base, self.search_link % quote(query)), timeout=6)
			if results: break
		return results

	def _rows(self, results):
		return json.loads(results).get('results') or []

	def _valid(self, row, hash):
		"""video categories only, another title's IMDb id dropped"""
		if not hash: return False
		if row.get('c') and row['c'] not in _VIDEO: return False
		return not (self.imdb and row.get('i') and str(row['i']).startswith('tt') and row['i'] != self.imdb)
