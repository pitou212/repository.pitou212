# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-11-01: reload only the DeadLight widgets a change touches, instead of every widget on Home.
# Needs Arctic Fuse 3's side (af3-src widgets_row.xml) adding $INFO[Window(Home).Property(deadlight.reload.<guid>),&reload=,]
# to each DeadLight widget path: Kodi reloads a widget when its path text changes, so setting one property reloads that
# widget alone. guid -> path comes from script.skinvariables' widget files. reload_widgets() returns False when the skin has
# no token or the files cannot be read, and the caller does the full reload (a silently stale widget is worse).
# Which titles each widget listed is read from the rows' tmdb_id= URLs and kept in one Home property per widget
# ('|' + ids; '|' alone = listed nothing), so widgets building at the same time never overwrite each other.
import os, re, sys, time
import xbmc
from urllib.parse import parse_qsl, unquote_plus
from modules import kodi_utils as ku

_RELOAD_PROP = 'deadlight.reload.%s'
_IDS_PROP = 'deadlight.widget_ids.%s'
_TMDB_ID_RE = re.compile(r'[?&]tmdb_id=(\d+)')
_ROW_IDS = []   # this call's row ids; emptied per call (invocation._CLEARS)


# --- recording what each widget listed (called from kodi_utils.add_item / add_items / end_directory) ---

def note_rows(urls):
	try:
		for url in urls:
			found = _TMDB_ID_RE.search(url)
			if found: _ROW_IDS.append(found.group(1))
	except Exception: pass

def record_widget():
	try:
		if len(sys.argv) > 2 and int(sys.argv[1]) >= 0 and ku.external():
			ku.set_property(_IDS_PROP % widget_key(sys.argv[2]), '|' + ','.join(sorted(set(_ROW_IDS))))
	except Exception: pass
	_ROW_IDS.clear()

def widget_key(url):
	"""A widget's plugin path as a short key, the same however it is quoted and without AF3's reload token."""
	import zlib   # LOCAL PATCH 2026-11-08: not hashlib (OpenSSL import is slow); a session-only property key
	query = url.split('?', 1)[1] if '?' in url else ''
	pairs = sorted((k, v) for k, v in parse_qsl(query, keep_blank_values=True) if k != 'reload')
	b = repr(pairs).encode('utf-8')
	return '%08x%08x' % (zlib.crc32(b), zlib.adler32(b))


# --- reloading ---

def _tokens_on():
	try:
		with open(ku.translate_path('special://skin/1080i/script-skinvariables-generator-includes-.xml'), encoding='utf-8') as f:
			return 'deadlight.reload.' in f.read()
	except Exception: return False

def _deadlight_widgets():
	"""[(guid, unquoted path, path as stored)] for each DeadLight widget in the skin's shortcut files; None when unreadable."""
	import glob, json
	folder = ku.translate_path('special://profile/addon_data/script.skinvariables/nodes/%s/' % xbmc.getSkinDir())
	files = glob.glob(os.path.join(folder, '*widgets.json'))
	if not files: return None
	found, stack = [], []
	for name in files:
		try:
			with open(name, encoding='utf-8') as f: stack.append(json.load(f))
		except Exception: return None
	while stack:
		item = stack.pop()
		if isinstance(item, list): stack.extend(item)
		elif isinstance(item, dict):
			path, guid = item.get('path'), item.get('guid')
			if isinstance(path, str) and guid and path.startswith('plugin://plugin.video.deadlight/'):
				found.append((guid, unquote_plus(path), path))
			stack.extend(v for v in item.values() if isinstance(v, (list, dict)))
	return found

def _may_list(raw_path, tmdb_ids):
	"""True when the widget last listed one of tmdb_ids -- or has not listed anything since Kodi started (no record)."""
	ids = ku.get_property(_IDS_PROP % widget_key(raw_path))
	return not ids or not set(ids[1:].split(',')).isdisjoint(tmdb_ids)

def id_list(tmdb_id):
	if not tmdb_id: return []
	if isinstance(tmdb_id, (str, int)): return [str(tmdb_id)]
	return sorted(set(str(i) for i in tmdb_id if i))

def reload_widgets(*matches, tmdb_id=None):
	"""Reload the DeadLight widgets whose path contains one of `matches`, and with `tmdb_id` (one id or several) also those
	that may list that title (no matches and no tmdb_id: all of them). False when the per-widget reload is not available,
	so the caller does the full one."""
	if not _tokens_on(): return False
	widgets = _deadlight_widgets()
	if widgets is None: return False
	ids = id_list(tmdb_id)
	every = not matches and not ids
	hit = sorted(set(g for g, p, raw in widgets if every or any(m in p for m in matches) or (ids and _may_list(raw, ids))))
	stamp = '%d' % (time.time() * 1000)
	for guid in hit: ku.set_property(_RELOAD_PROP % guid, stamp)
	why = ', '.join(list(matches) + (['tmdb %s' % ','.join(ids)] if ids else []))
	ku.logger('widget.refresh', '%d of %d DeadLight widgets%s' % (len(hit), len(widgets), (' for %s' % why) if why else ''))
	return True
