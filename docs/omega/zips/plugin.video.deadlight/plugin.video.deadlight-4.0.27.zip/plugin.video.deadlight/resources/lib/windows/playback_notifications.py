# -*- coding: utf-8 -*-
import time
from modules.kodi_utils import addon_fanart
from windows.base_window import BaseDialog
from modules.settings import avoid_episode_spoilers

class NextEpisode(BaseDialog):
	episode_status_dict = {
	'season_premiere': ('Season Premiere', 'b30385b5'),
	'mid_season_premiere': ('Mid-Season Premiere', 'b385b503'),
	'series_premiere': ('Series Premiere', 'b30385b5'),   # LOCAL PATCH 2026-10-31: metadata gives it; missing, it raised KeyError
	'series_finale': ('Series Finale', 'b38503b5'),
	'season_finale': ('Season Finale', 'b3b50385'),
	'mid_season_finale': ('Mid-Season Finale', 'b3b58503'),
	'':  (None, None)}
	NEXT_W = 236   # the Next episode button's width in playback_notifications.xml
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.closed = False
		self.meta = kwargs.get('meta')
		self.selected = kwargs.get('default_action', 'cancel')
		# LOCAL PATCH 2026-08-25: countdown_mode ('fixed' | 'to_end') drives monitor().
		self.countdown_mode = kwargs.get('countdown_mode', 'fixed')
		self.total_time = kwargs.get('total_time') or 0
		# LOCAL PATCH 2026-10-15: the Choose Source card -- SmartPlay found no match, so 'Choose source' stops the episode and
		# opens the source list (2026-11-08: it opened over the still-playing episode), and no answer means the list at the real
		# end (sources._wait_out_playback). It only relabels; the buttons and answers are the Up Next card's.
		self.choose = bool(kwargs.get('choose'))
		self.fill_clock, self.fill_width = None, None   # LOCAL PATCH 2026-10-21: see sleep_filling
		self.set_properties()

	def onInit(self):
		self.setFocusId(11)
		self.monitor()

	def run(self):
		self.doModal()
		self.clearProperties()
		self.clear_modals()
		return self.selected

	def onAction(self, action):
		if action in self.closing_actions:
			self.selected = 'cancel'
			self.closed = True
			self.close()

	def onClick(self, controlID):
		self.selected = {10: 'close', 11: 'play', 12: 'cancel'}[controlID]
		self.closed = True
		self.close()

	def set_properties(self):
		self.setProperty('mode', 'next_episode')
		self.setProperty('next_name', 'Choose source' if self.choose else 'Next episode')   # 2026-11-08: named buttons, sentence case
		# LOCAL PATCH 2026-10-08: 'Watch Credits' only when the alert opened at the credits (IntroDB outro / last chapter);
		# at the percentage fallback there may be story left, and the button keeps playing all the same
		self.setProperty('credits_label', 'Keep watching' if self.countdown_mode == 'to_end' else 'Watch credits')
		self.setProperty('thumb', self.get_thumb())
		self.setProperty('clearlogo', self.meta.get('clearlogo', ''))
		self.setProperty('episode_label', '%s[B] | [/B]%02dx%02d[B] | [/B]%s' % (self.meta['title'], self.meta['season'], self.meta['episode'], self.meta['ep_name']))
		status_label, status_highlight = self.episode_status_dict.get(self.meta.get('episode_type') or '', (None, None))
		if status_label:
			self.setProperty('episode_status.label', status_label)
			self.setProperty('episode_status.highlight', status_highlight)
		# LOCAL PATCH 2026-10-09: the Up Next card -- title on its own line, then 'S04  ·  E09  ·  48 min' and the status in its colour
		self.setProperty('ep_title', self.meta.get('ep_name') or 'Episode %d' % int(self.meta['episode']))
		meta_line = 'S%02d  ·  E%02d' % (int(self.meta['season']), int(self.meta['episode']))
		try:
			minutes = int(self.meta.get('ep_duration') or 0) // 60
			if minutes: meta_line += '  ·  %d min' % minutes
		except (TypeError, ValueError): pass
		# LOCAL PATCH 2026-10-31: the status is on the still again (playback_notifications.xml), not appended here
		self.setProperty('ep_meta', meta_line)
		self.clearProperty('next_label')   # the count alone; the button is an icon (empty -> the icon centres)

	def set_fill(self, fraction):
		"""LOCAL PATCH 2026-10-09: the Next Episode button fills left to right as the countdown runs (images 30 / 31 in
		playback_notifications.xml, the focused and unfocused colours). Hidden below the width a rounded image can be drawn."""
		# LOCAL PATCH 2026-10-21: only touches the controls when the width changes -- sleep_filling calls this 25 times a second
		fraction = max(0.0, min(1.0, fraction))
		# LOCAL PATCH 2026-11-08: round 5 -- the named button is NEXT_W wide; a 10 px-corner image is drawable from 20 px
		width = int(20 + (self.NEXT_W - 20) * fraction) if fraction > 0 else 0
		if width == self.fill_width: return
		self.fill_width = width
		for control_id in (30, 31):
			try:
				control = self.getControl(control_id)
				if not width: control.setVisible(False)
				else:
					control.setWidth(width)
					control.setVisible(True)
			except Exception: pass

	def sleep_filling(self, ms):
		"""LOCAL PATCH 2026-10-21: monitor() ticks every 500 ms (visible jumps). When the fill runs on the wall clock
		(fill_clock = (start, seconds): the fixed countdown, and the grace after playback ended) redraw it every 40 ms
		through the wait instead. The 'to_end' fill follows the player, so it keeps the tick."""
		if not self.fill_clock: return self.sleep(ms)
		start, duration = self.fill_clock
		end = time.time() + ms / 1000.0
		while not self.closed:
			left = end - time.time()
			if left <= 0: break
			self.set_fill((time.time() - start) / float(duration or 1))
			self.sleep(max(1, int(min(0.04, left) * 1000)))

	def get_thumb(self):
		if avoid_episode_spoilers() and int(self.meta.get('playcount', '0')) == 0: thumb = self.meta.get('fanart', '') or addon_fanart()
		else: thumb = self.meta.get('ep_thumb', None) or self.meta.get('fanart', '') or addon_fanart()
		return thumb

	def monitor(self):
		# LOCAL PATCH 2026-08-25: driven by the timing tier chosen in player.info_next_ep(), handed over as `countdown_mode`.
		#   'fixed'  (HIGH confidence -- IntroDB outro / final chapter): the alert opened when the credits started, so a short
		#            fixed countdown then autoplay is correct.
		#   'to_end' (LOW confidence -- percentage fallback): the alert point is arbitrary, and a fixed countdown from there
		#            autoplays real episode early. Track the true remaining time and fire only when the video ends.
		# Both modes are bounded by playback, so the countdown never outlives the video and ticks on over Home.
		from caches.settings_cache import get_setting
		from modules.player import PLAYBACK_STOPPED_PROP
		from modules.kodi_utils import get_property
		try: countdown_duration = int(get_setting('deadlight.autoplay_alert_countdown_sec', '10') or '10')
		except: countdown_duration = 10
		countdown_start = time.time()
		try: total_time = self.total_time or self.player.getTotalTime()
		except: total_time = 0
		mode = self.countdown_mode
		# Was playback live when the alert opened? Separates "user pressed Stop" from "alert opened after playback had already
		# ended" (the outro-skip race, where the alert is deliberately kept).
		try: playing_at_open = self.player.isPlaying()
		except: playing_at_open = False
		STOP_EPSILON = 5    # seconds; at or under this, "not playing" reads as a natural end
		playback_ended_at = None
		last_remaining = None
		while True:
			if self.closed: break
			try: playing = self.player.isPlaying()
			except: playing = False
			if playing:
				try:
					last_remaining = max(0, round(total_time - self.player.getTime()))
				except: pass
			remaining = last_remaining
			# --- dismissal on user stop -------------------------------------------
			# Position-based, so instant. PLAYBACK_STOPPED_PROP is authoritative but Kodi sets it ~2.5s after isPlaying() flips,
			# which loses the race against a 10s countdown. Property kept as a secondary signal.
			if playing_at_open and not playing:
				stopped_early = remaining is not None and remaining > STOP_EPSILON
				if stopped_early or get_property(PLAYBACK_STOPPED_PROP) == 'true':
					self.selected = 'cancel'
					self.closed = True
					self.close()
					break
			elif get_property(PLAYBACK_STOPPED_PROP) == 'true':
				# Alert opened with playback already over, and a stop verdict landed late -- a user stop after all.
				self.selected = 'cancel'
				self.closed = True
				self.close()
				break
			# --- fire condition ----------------------------------------------------
			if mode == 'to_end':
				if playing:
					if remaining is not None and remaining <= 1:
						self.closed = True; self.close(); break
					# Above a minute feed M:SS (the card has no Player.TimeRemaining label of its own); the countdown label hard-codes an
					# "s" suffix, so under a minute it gets plain seconds.
					# LOCAL PATCH 2026-10-14: M:SS above a minute.
					try:
						if remaining is None: self.clearProperty('countdown')
						elif remaining <= 60: self.setProperty('countdown', str(int(remaining)))
						else: self.setProperty('countdown', '%d:%02d' % divmod(int(remaining), 60))
					except: pass
					# LOCAL PATCH 2026-10-09: the last minute fills the button; before it the card says when it will play
					if remaining is not None and remaining <= 60:
						self.clearProperty('up_next_when'); self.set_fill((60 - remaining) / 60.0)
					else:
						self.setProperty('up_next_when', 'Sources when this ends' if self.choose else 'When this ends'); self.set_fill(0)
				else:
					# Playback ended before the end mark -- short grace so the alert is still readable, then fire.
					if playback_ended_at is None: playback_ended_at = time.time()
					self.fill_clock = (playback_ended_at, countdown_duration)
					elapsed_since_end = time.time() - playback_ended_at
					try: self.setProperty('countdown', str(max(0, countdown_duration - int(elapsed_since_end))))
					except: pass
					self.clearProperty('up_next_when'); self.set_fill(elapsed_since_end / float(countdown_duration or 1))
					if elapsed_since_end >= countdown_duration:
						self.closed = True; self.close(); break
			else:
				elapsed = time.time() - countdown_start
				try: self.setProperty('countdown', str(max(0, countdown_duration - int(elapsed))))
				except: pass
				# LOCAL PATCH 2026-10-15 (later): the Choose Source card counts down too; no answer stops the episode and opens the list
				# (sources._wait_out_playback), so the header says so
				if self.choose: self.setProperty('up_next_when', 'Source list next')
				self.set_fill(elapsed / float(countdown_duration or 1))   # LOCAL PATCH 2026-10-09
				self.fill_clock = (countdown_start, countdown_duration)
				# LOCAL PATCH 2026-10-15: 'Pause & Wait' does not time out here -- it pauses 10 s before the end (below), as 'to_end'
				# does. Otherwise, with credits longer than the countdown, the card closed and the pause loop ran on a window nobody
				# could click, its final pause() toggling whatever was playing.
				if elapsed >= countdown_duration and self.selected != 'pause':
					self.closed = True; self.close(); break
				# Bounded by playback: if the video ends first, fire now instead of ticking over Home.
				if playing_at_open and not playing:
					self.closed = True; self.close(); break
			# --- pause handling (unchanged) ----------------------------------------
			if playing and self.selected == 'pause' and remaining is not None and remaining <= 10:
				self.player.pause()
				self.sleep(500)
				break
			# LOCAL PATCH 2026-10-09: the card's Next button is an icon carrying the count ('7') beside it
			self.setProperty('next_label', self.getProperty('countdown'))
			self.sleep_filling(500)
		if self.selected == 'pause' and not self.closed:   # LOCAL PATCH 2026-10-15: never on a card already closed (playback ended)
			start_time = time.time()
			end_time = start_time + 900
			current_time = start_time
			while current_time <= end_time and self.selected == 'pause':
				try:
					current_time = time.time()
					pause_timer = time.strftime('%M:%S', time.gmtime(max(end_time - current_time, 0)))
					self.setProperty('pause_timer', pause_timer)
					self.sleep(1000)
				except: break
			if self.selected != 'cancel': self.player.pause()
		self.close()

class StillWatching(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.closed = False
		self.selected = False
		self.meta = kwargs.get('meta')
		self.check_text = kwargs.get('check_text')
		self.set_properties()

	def onInit(self):
		self.setFocusId(10)
		self.monitor()

	def run(self):
		self.doModal()
		self.clearProperties()
		self.clear_modals()
		return self.selected

	def onAction(self, action):
		if action in self.closing_actions:
			# LOCAL PATCH 2026-10-15: False, not 'no' -- every caller tests the answer as a boolean (a truthy string made Back/Esc
			# mean 'yes, still watching').
			self.selected = False
			self.closed = True
			self.close()

	def onClick(self, controlID):
		self.selected = {10: True, 11: False}[controlID]
		self.closed = True
		self.close()

	def set_properties(self):
		landscape, fanart, clearlogo = self.meta.get('landscape', ''), self.meta.get('fanart', ''), self.meta.get('clearlogo', '')
		self.setProperty('mode', 'still_watching')
		self.setProperty('thumb', landscape or fanart)
		if not landscape: self.setProperty('clearlogo', clearlogo)
		self.setProperty('episode_label', self.check_text % self.meta['title'])

	def monitor(self):
		pause_timer = 10
		while self.player.isPlaying():
			self.setProperty('pause_timer', '%02d %s' % (pause_timer, 'seconds' if pause_timer > 1 else 'second'))
			self.sleep(1000)
			if self.closed: break
			if pause_timer == 0: break
			pause_timer -= 1
		self.close()

class StingersNotification(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.stinger_dict = {'duringcreditsstinger': {'id': 200, 'property': 'color_during'}, 'aftercreditsstinger': {'id': 201, 'property': 'color_after'}}
		self.closed = False
		self.meta = kwargs.get('meta')
		self.stingers = self.meta.get('stinger_keys')
		self.set_properties()

	def onInit(self):
		self.make_stingers()
		self.monitor()

	def run(self):
		self.doModal()
		self.clearProperties()
		self.clear_modals()

	def onAction(self, action):
		if action in self.closing_actions:
			self.closed = True
			self.close()

	def make_stingers(self):
		for k, v in self.stinger_dict.items():
			if k in self.stingers:
				self.setProperty(v['property'], 'FF5FC27E')   # LOCAL PATCH 2026-10-09: hex (were the words green / red)
				self.set_image(v['id'], 'deadlight_common/overlay_selected.png')
			else:
				self.setProperty(v['property'], 'FFE06C6C')
				self.set_image(v['id'], 'deadlight_common/cross.png')

	def set_properties(self):
		self.setProperty('mode', 'stinger')
		self.setProperty('thumb', self.meta.get('fanart', '') or addon_fanart())   # LOCAL PATCH 2026-10-15: the fallback sat outside the call
		self.setProperty('clearlogo', self.meta.get('clearlogo', ''))

	def monitor(self):
		total_time = 10000
		while self.player.isPlaying() and total_time > 0:
			if self.closed: break
			self.sleep(1000)
			total_time -= 1000
		self.close()