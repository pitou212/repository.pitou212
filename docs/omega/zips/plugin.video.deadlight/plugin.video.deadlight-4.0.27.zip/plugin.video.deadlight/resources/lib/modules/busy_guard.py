# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-11-01: a spinner for context-menu actions.
#
# Every context-menu item is RunPlugin(...), which Kodi runs with no busy indicator of its own, and most handlers never
# showed one: Trakt / MDBList / SIMKL / AniList / personal / TMDb / favourites managers, Options, Mark Watched, Clear
# SmartPlay Pin -- the press seemed to do nothing until a dialog or a notification arrived (user, 2026-11-01). Rather than
# thirty show / hide pairs, deadlight.py starts this guard around such a call: once the call has run DELAY seconds, Kodi's
# busy spinner shows, and it stays up while the call works. It steps aside for DeadLight's own dialogs -- open_window
# (select, confirm, ok, the extras / options windows), kodi_dialog() (keyboard input, browse, select) and progress_dialog
# -- which run inside paused(), and comes back if work continues after the dialog closes. stop() hides it.
#
# Only for user-pressed actions (wanted()): never a directory call (Kodi shows its own), never playback (its Resolving
# window is the indicator), never a call the service starts in the background.
import threading, time

DELAY = 0.4      # an action done sooner never flashes the spinner
_TICK = 0.1
_lock = threading.Lock()
_state = {'running': False, 'start': 0.0, 'paused': 0, 'shown': False}

_BACKGROUND_MODES = ('page_prefetch.warm_widget_pages', 'refresh_widgets', 'kodi_refresh')

def wanted(handle, mode):
	"""A RunPlugin call (handle -1) a person pressed: a menu choice, a mark-watched, a list manager action."""
	if handle >= 0 or not mode: return False
	if mode in _BACKGROUND_MODES or mode.startswith('playback') or mode == 'playback_choice': return False
	return mode.endswith('_choice') or mode.startswith(('watched_status.', 'trakt.', 'mdblist.', 'simkl.', 'anilist.',
		'personal_lists.', 'tmdblist.', 'favorites.', 'real_debrid.', 'torbox.')) or mode in ('trakt_drop_show',)

def _show():
	from modules.kodi_utils import show_busy_dialog
	show_busy_dialog()

def _hide():
	from modules.kodi_utils import hide_busy_dialog
	hide_busy_dialog()

def _loop():
	while True:
		time.sleep(_TICK)
		with _lock:
			if not _state['running']: return
			if _state['shown'] or _state['paused'] or time.time() - _state['start'] < DELAY: continue
			_show()
			_state['shown'] = True

def start():
	with _lock:
		if _state['running']: return
		_state.update(running=True, start=time.time(), paused=0, shown=False)
	t = threading.Thread(target=_loop, name='busy_guard')
	t.daemon = True
	t.start()

def stop():
	with _lock:
		if not _state['running']: return
		_state['running'] = False
		shown, _state['shown'] = _state['shown'], False
	if shown: _hide()

class paused(object):
	"""with paused(): ... -- a dialog is up: the spinner hides and stays off until the block ends. Nests; a no-op when
	no guard runs (directory calls, the service). After the block the spinner waits DELAY again before it returns, so a
	dialog that leads straight to another does not flash it in between."""
	def __enter__(self):
		with _lock:
			if not _state['running']: return self
			_state['paused'] += 1
			shown, _state['shown'] = _state['shown'], False
			if shown: _hide()
		return self

	def __exit__(self, *exc):
		with _lock:
			if not _state['running']: return False
			_state['paused'] = max(0, _state['paused'] - 1)
			if not _state['paused']: _state['start'] = time.time()
		return False
