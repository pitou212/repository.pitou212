# -*- coding: utf-8 -*-
import json
from caches.settings_cache import get_setting, set_setting, set_default, default_setting_values
from modules import kodi_utils, settings
from modules.metadata import display_genres as _display_genres   # LOCAL PATCH 2026-10-07: AniList tags on anime

# LOCAL PATCH 2026-11-01 (cleanup): the select-dialog boilerplate ~40 functions repeated (list_items, json.dumps, select_dialog)
def _pick(pairs, heading=None, icon=None, **kw):
	"""select_dialog on (label, value) or (label, value, line_icon) pairs -> the chosen value(s), or None. icon goes on every line
	without its own; heading and any other select_dialog keyword (narrow_window='true', multi_choice, preselect ...) pass through."""
	list_items = []
	for pair in pairs:
		item = {'line1': pair[0]}
		line_icon = pair[2] if len(pair) > 2 else icon
		if len(pair) > 2 or icon is not None: item['icon'] = line_icon
		list_items.append(item)
	kwargs = {'items': json.dumps(list_items)}
	if heading is not None: kwargs['heading'] = heading
	kwargs.update(kw)
	return kodi_utils.select_dialog([pair[1] for pair in pairs], **kwargs)

def _pick_setting(choices, setting_id, name_id, value_key='value', line_icon=None, **kw):
	"""choices: dicts with 'name' and value_key. The chosen one's value goes to setting_id, its name to name_id; returns it
	(None when cancelled). line_icon: choice -> that line's icon."""
	choice = _pick([(i['name'], i, line_icon(i)) if line_icon else (i['name'], i) for i in choices], **kw)
	if choice == None: return None
	set_setting(setting_id, choice[value_key])
	set_setting(name_id, choice['name'])
	return choice

def window_theme_choice(params):
	if params['type'] == 'theme':
		choice = _pick([(i['name'], i, kodi_utils.theme_icon(i['icon'])) for i in kodi_utils.addon_themes()], heading='Assign a Theme', narrow_window='true')
		if choice == None: return
		window_theme, window_theme_contrast, window_theme_name = choice['value'][0][2:], choice['value'][1], choice['name']
		window_theme_opacity = get_setting('deadlight.window_theme_opacity', 'CC')
		set_setting('window_theme_name', window_theme_name)
	else:
		choice = _pick([(i['name'], i) for i in kodi_utils.addon_themes_opacity()], heading='Assign an Opacity Level', narrow_window='true')
		if choice == None: return
		window_theme_opacity, window_theme_opacity_name = choice['value'], choice['name']
		window_theme = get_setting('deadlight.window_theme', 'FF1F2020')[2:]
		window_theme_contrast = get_setting('deadlight.window_theme_contrast', 'FF4a4347')
		set_setting('window_theme_opacity', window_theme_opacity)
		set_setting('window_theme_opacity_name', window_theme_opacity_name)
	set_setting('window_theme', window_theme_opacity + window_theme)
	set_setting('window_theme_contrast', window_theme_contrast)

def rpdb_poster_format_choice(params):
	choices = [{'name': 'default', 'value': ''}, {'name': 'blocks', 'value': '&theme=blocks'}, {'name': 'rounded', 'value': '&theme=rounded-blocks'}]
	_pick_setting(choices, 'rpdb_format', 'rpdb_format_name', line_icon=lambda i: kodi_utils.get_icon('rpdb_%s' % i['name'], 'rpdb_posters', 'jpg'))

def navigate_to_page_choice(params):
	def _builder():
		for item in start_list:
			if item == current_page: line1 = '[COLOR blue][B]Page %s   |   Current Page[/B][/COLOR]' % item
			else: line1 = 'Page %s' % item
			yield {'line1': line1}
	try:
		current_page, total_pages = int(params.get('current_page')), int(params.get('total_pages'))
		start_list = [i for i in range(1, total_pages+1)]
		list_items = list(_builder())
		kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true', 'set_focus': current_page - 1, 'heading': 'Go to Page'}
		new_page = kodi_utils.select_dialog(start_list, **kwargs)
		if new_page == None or new_page == current_page: return
		url_params = json.loads(params['url_params'])
		url_params.update({'new_page': new_page, 'refreshed': 'true'})
		kodi_utils.container_update(url_params)
	except: return

def list_display_order_choice(params):
	from modules.meta_lists import list_display_choices
	list_type = params['list_type']
	info = list_display_choices(list_type)
	choice = _pick([(i[0], i) for i in info['choices']], narrow_window='true')
	if choice == None: return
	set_setting('%s.list_sort_name' % info['setting'], choice[0])
	set_setting('%s.list_sort' % info['setting'], choice[1])

def language_invoker_choice(params):
	from xml.dom.minidom import parse as mdParse
	kodi_utils.close_all_dialog()
	addon_xml = kodi_utils.translate_path('special://home/addons/plugin.video.deadlight/addon.xml')
	root = mdParse(addon_xml)
	invoker_instance = root.getElementsByTagName('reuselanguageinvoker')[0].firstChild
	current_invoker_setting = invoker_instance.data
	new_value = {'true': 'false', 'false': 'true'}[current_invoker_setting]
	if not kodi_utils.confirm_dialog(text='Turn [B]Reuse Language Invoker[/B] %s?' % ('On' if new_value == 'true' else 'Off')): return
	invoker_instance.data = new_value
	new_xml = str(root.toxml()).replace('<?xml version="1.0" ?>', '')
	# Explicit UTF-8, as in service.AddonXMLCheck: the platform codec (cp1252 on Windows)
	# truncates addon.xml to 0 bytes on any character outside it.
	import io as _io
	with _io.open(addon_xml, 'w', encoding='utf-8', newline='') as f: f.write(new_xml)
	set_setting('reuse_language_invoker', new_value)
	kodi_utils.execute_builtin('ActivateWindow(Home)', True)
	kodi_utils.update_local_addons()
	kodi_utils.disable_enable_addon()

def addon_icon_choice(params):
	# LOCAL PATCH 2026-09-05: choose from the icons bundled with the add-on (resources/media/addon_icons, minis
	# included). The old FenlightAnonyMouse / TIKIPETER icon repos no longer exist.
	import os
	import re
	import io
	icons_folder = os.path.join(kodi_utils.addon_path(), 'resources', 'media', 'addon_icons')
	icons_path = kodi_utils.translate_path(icons_folder)
	set_icon = params.get('set_icon')
	if set_icon: new_name = set_icon
	else:
		try:
			names = sorted(i for i in os.listdir(icons_path) if i.lower().endswith('.png'))
			all_icons = [{'line1': i, 'icon': os.path.join(icons_folder, i)} for i in names]
			if not all_icons: return kodi_utils.ok_dialog(heading='DeadLight Icon Images', text='No icon images are bundled with the add-on')
			kwargs = {'items': json.dumps(all_icons), 'heading': 'Choose New Icon Image'}
			new_icon = kodi_utils.select_dialog(all_icons, **kwargs)
			if new_icon == None: return
			if not kodi_utils.confirm_dialog(text='Set New Icon?'): return
			new_name = new_icon['line1']
		except: return kodi_utils.ok_dialog(heading='DeadLight Icon Images', text='Error Listing Addon Icon Images')
	new_icon_path = 'resources/media/addon_icons/%s' % new_name
	addon_xml = kodi_utils.translate_path('special://home/addons/plugin.video.deadlight/addon.xml')
	# Targeted replacement rather than a minidom round trip: re-serialising drops every comment in addon.xml, and
	# open(...,'w') uses the platform codec (cp1252 on Windows), which truncates the file to 0 bytes on any character
	# outside it and leaves Kodi unable to load the add-on.
	current = io.open(addon_xml, encoding='utf-8', newline='').read()
	replaced = re.sub(r'<icon>[^<]*</icon>', '<icon>%s</icon>' % new_icon_path, current, count=1)
	if replaced != current: io.open(addon_xml, 'w', encoding='utf-8', newline='').write(replaced)
	set_setting('addon_icon_choice', new_icon_path)
	set_setting('addon_icon_choice_name', new_name)
	if set_icon: return
	kodi_utils.execute_builtin('ActivateWindow(Home)', True)
	kodi_utils.update_local_addons()
	kodi_utils.disable_enable_addon()

def rescrape_actions_choice(params):
	set_focus = params.get('set_focus', 0)
	action_values, order_values = {0: 'Off', 1: 'Auto', 2: 'Prompt'}, {0: 'Highest', 1: 'High', 2: 'Middle', 3: 'Low', 4: 'Lowest'}
	rescrape_settings = settings.rescrape_settings(include_off=True)   # LOCAL PATCH 2026-10-04: Off steps too, see settings.py
	choices = [dict(i, **{'line1': '%02d, %s' % (int(k[2]) + 1, i['name']),
				'line2': 'Current | Action: [B]%s[/B] | Order: [B]%s[/B]' % (action_values[k[1]], order_values[k[2]]), 'value': i['value'],
				'action': k[1], 'order': k[2]}) for i in kodi_utils.rescrape_items() for k in rescrape_settings if k[0] == i['value']]
	choices = [dict(i, **{'position': c}) for c, i in enumerate(sorted(choices, key=lambda k: k['order']))]
	kwargs = {'items': json.dumps(choices), 'heading': 'Choose Properties for Rescrape Functions', 'multi_line': 'true', 'narrow_window': 'true', 'set_focus': set_focus}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None: return
	choice_value, choice_action, choice_order = choice['value'], choice['action'], choice['order']
	params['set_focus'] = choice['position']
	choices = [{'line1': 'Set Action', 'action': 'set_action'}, {'line1': 'Set Order', 'action': 'set_order'}]
	kwargs = {'items': json.dumps(choices), 'heading': 'Choose Properties for Rescrape Functions', 'narrow_window': 'true', 'set_focus': set_focus}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None: return rescrape_actions_choice(params)
	action = choice['action']
	if action == 'set_action':
		choices = [{'line1': 'Off', 'value': '0'}, {'line1': 'Auto', 'value': '1'}, {'line1': 'Prompt', 'value': '2'}]
		heading, setting = 'Choose Action Value', 'rescrape.%s' % choice_value
		kwargs = {'items': json.dumps(choices), 'heading': heading, 'narrow_window': 'true'}
		choice = kodi_utils.select_dialog(choices, **kwargs)
		if choice == None: return rescrape_actions_choice(params)
		setting_value = choice['value']
		set_setting(setting, setting_value)
	else:
		choices = [{'line1': 'Highest', 'value': '0'}, {'line1': 'High', 'value': '1'}, {'line1': 'Middle', 'value': '2'},
					{'line1': 'Low', 'value': '3'}, {'line1': 'Lowest', 'value': '4'}]
		heading, setting = 'Choose Order', 'rescrape.%s.order'
		kwargs = {'items': json.dumps(choices), 'heading': heading, 'narrow_window': 'true'}
		choice = kodi_utils.select_dialog(choices, **kwargs)
		if choice == None: return rescrape_actions_choice(params)
		setting_value = choice['value']
		new_settings = list(rescrape_settings)
		new_settings.remove((choice_value, choice_action, choice_order))
		new_settings.insert(int(setting_value), (choice_value, choice_action, setting_value))
		for item in [(i[0], str(c)) for c, i in enumerate(new_settings)]: set_setting(setting % item[0], item[1])
		params['set_focus'] = int(setting_value)
	return rescrape_actions_choice(params)

def context_menu_choice(params):
	choices = kodi_utils.context_menu_items()
	current_settings = settings.cm_enabled()
	try: preselect = [choices.index(i) for i in choices if i['value'] in current_settings]
	except: preselect = []
	selection = _pick([(i['name'], i) for i in choices], heading='Enable Content for the Context Menu', multi_choice='true', preselect=preselect)
	if selection  == []:
		kodi_utils.ok_dialog(text='You must select at least 1 item')
		return context_menu_choice(params)
	elif selection == None: return
	selection = [i['value'] for i in selection]
	set_setting('context_menu.enabled', ','.join(selection))

def context_menu_order_choice(params):
	set_focus = params.get('set_focus', 0)
	all_items = kodi_utils.context_menu_items()
	enabled_items = settings.cm_enabled()
	current_order = settings.cm_current_order()
	active_items = [i for i in all_items if i['value'] in enabled_items]
	sorted_active_items = sorted(active_items, key=lambda k: current_order.index(k['value']))
	choices = [{'line1': 'Position %02d' % (count + 1), 'line2': 'Currently [B]%s[/B]' % (item['name']),
			 'current_item': item, 'display_position': count + 1, 'position': count} for count, item in enumerate(sorted_active_items)]
	kwargs = {'items': json.dumps(choices), 'heading': 'Choose Order for Context Menu', 'multi_line': 'true', 'narrow_window': 'true', 'set_focus': set_focus}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None: return
	current_item = choice['current_item']
	position = choice['position']
	display_position = choice['display_position']
	value = _pick([(item['name'], item['value']) for item in active_items if item != current_item], narrow_window='true',
					heading='Choose Context Menu Item for Position %02d' % display_position)
	if value != None:
		current_order.remove(value)
		current_order.insert(position, value)
		current_order = [str(i) for i in current_order]
		set_setting('context_menu.order', ','.join(current_order))
		params['set_focus'] = position
	return context_menu_order_choice(params)

def personallists_manager_choice(params):
	from indexers.personal_lists import get_all_personal_lists, make_new_personal_list, new_list_check
	icon = params.get('icon', None) or kodi_utils.get_icon('lists')
	list_type = params['list_type']
	all_lists = get_all_personal_lists(get_setting('deadlight.personal_list.list_sort', '0'))
	choices = []
	if not all_lists: action = 'add_new'
	else:
		choices = [('Add To Personal List...', 'add'), ('Remove From Personal List...', 'remove'), ('Add To [B]NEW[/B] Personal List...', 'add_new')]
		action = _pick(choices, heading='Personal Lists Manager', icon=icon)
		if action == None: return
	if action == 'add_new':
		list_name, author = make_new_personal_list({'external_creation': 'true'})
		if not list_name: return kodi_utils.notification('Error Creating List', 3000)
		action = 'add'
	else:
		new_template, normal_template = '[COLOR FF008EB2]%s [I](x%02d)[/I][/COLOR]', '%s [I](x%02d)[/I]'
		choices = [((new_template if new_list_check(i['seen']) else normal_template) % (i['name'], i['total']), (i['name'], i['author'])) for i in all_lists]
		try:list_name, author = _pick(choices, narrow_window='true')
		except: return
	if action == 'add': new_contents = {'media_id': params['tmdb_id'], 'title': params['title'], 'type': list_type,
										'release_date': params['premiered'], 'date_added': params['current_time']}
	else: new_contents = {'media_id': params['tmdb_id'], 'type': list_type}
	from caches.personal_lists_cache import personal_lists_cache
	result = personal_lists_cache.add_remove_list_item(list_name, author, action, new_contents)
	kodi_utils.notification(result, 3000)
	kodi_utils.refresh(list_name, screen='if_listed')   # LOCAL PATCH 2026-11-01: adds too (was removals only)

def tmdblists_manager_choice(params):
	from caches.tmdb_lists import tmdb_lists_cache
	from indexers.tmdb_lists import get_all_tmdb_lists, make_new_tmdb_list, add_to_tmdb_list, remove_from_tmdb_list, check_item_status, check_item_status_watchfav, add_remove_watchfavs
	icon = params.get('icon', None) or kodi_utils.get_icon('tmdb')
	media_type, tmdb_id = params['media_type'], params['tmdb_id']
	choices = [('Add To TMDb List...', 'list_add'), ('Remove From TMDb List...', 'list_remove'), ('Add To [B]NEW[/B] TMDb List...', 'list_add_new'),
				('Add To [B]Watchlist[/B]', 'watchlist_add'), ('Remove From [B]Watchlist[/B]', 'watchlist_remove'),
				('Add To [B]Favorites[/B]', 'favorites_add'), ('Remove From [B]Favorites[/B]', 'favorites_remove')]
	action = _pick(choices, heading='TMDb Lists Manager', icon=icon)
	if action == None: return
	if action.startswith(('watchlist', 'favorites')):
		list_id = action.split('_')[0]
		status = True if 'add' in action else False
		item_in_list = check_item_status_watchfav(list_id, media_type, tmdb_id)
		if item_in_list and status: return kodi_utils.notification('Item already in %s' % list_id.capitalize())
		if not item_in_list and not status: return kodi_utils.notification('Item not in %s' % list_id.capitalize())
		success = add_remove_watchfavs(media_type, tmdb_id, list_id, status)
		tmdb_lists_cache.clear_watchfavrecs(list_id, media_type)
	else:
		all_lists = get_all_tmdb_lists('0')
		if not all_lists: action = 'list_add_new'
		if action == 'list_add_new':
			list_id = make_new_tmdb_list({'external_creation': 'true'})
			if not list_id: return kodi_utils.notification('Error Creating List')
			action, item_in_list = 'list_add', False
		else:
			list_id = _pick([('%s [I](x%02d)[/I]' % (i['name'], i['number_of_items']), i['id']) for i in all_lists], narrow_window='true')
			if list_id == None: return
			item_in_list = check_item_status(list_id, media_type, tmdb_id)
		new_contents = {'items': [{'media_type': media_type, 'media_id': tmdb_id}]}
		if action == 'list_add':
			if item_in_list: return kodi_utils.notification('Item already in List')
			success = add_to_tmdb_list(list_id, new_contents)
		elif action == 'list_remove':
			if not item_in_list: return kodi_utils.notification('Item not in List')
			success = remove_from_tmdb_list(list_id, new_contents)
		tmdb_lists_cache.clear_list(list_id)
		tmdb_lists_cache.clear_all_lists()
	kodi_utils.notification('Success' if success else 'Failed', 3000)
	if success: kodi_utils.refresh(str(list_id), screen='if_listed')   # LOCAL PATCH 2026-11-01: adds too (was removals only)

def favorites_manager_choice(params):
	from caches.favorites_cache import favorites_cache
	media_type, tmdb_id, title = params.get('media_type'), params.get('tmdb_id'), params.get('title')
	current_favorites = favorites_cache.get_favorites(media_type)
	people_favorite = media_type == 'people'
	current_favorite = any(i['tmdb_id'] == tmdb_id for i in current_favorites)
	if current_favorite:
		function, text = favorites_cache.delete_favourite, 'Remove From Favorites?'
		param_refresh = params.get('refresh', None)
		if param_refresh == None: refresh = any(i in kodi_utils.folder_path() for i in ('action=favorites_movies', 'action=favorites_tvshows', 'action=favorites_anime'))
		else: refresh = param_refresh == 'true'
	else: function, text, refresh = favorites_cache.set_favourite, 'Add To Favorites?', False
	heading = title.split('|')[0] if people_favorite else title
	if not kodi_utils.confirm_dialog(heading=heading, text=text): return
	success = function(media_type, tmdb_id, title)
	if success:
		# LOCAL PATCH 2026-11-01: Home widgets too (an add or a removal): it reloaded only inside the favourites folders.
		if refresh or kodi_utils.external(): kodi_utils.refresh()
		kodi_utils.notification('Success', 3500)
	else: kodi_utils.notification('Error', 3500)
	if people_favorite and success: return text

def ai_model_order_choice(params):
	model_descriptions = {'gemini-3.1-flash-lite': ('GEMINI 3.1 LITE, FAST, BEST PICKS', 'gemini'), 'gemini-2.5-flash-lite': ('GEMINI 2.5 LITE, FASTEST', 'gemini'),
							'gemini-3.5-flash-lite': ('GEMINI 3.5 LITE, FAST', 'gemini'), 'gemini-3-flash-preview': ('GEMINI 3 FLASH, PREVIEW', 'gemini')}
	default_order = default_setting_values('ai_model.order')['setting_default'].split(',')
	current_order = settings.ai_model_order()
	choices = [{'line1': 'Position %02d' % (count + 1), 'line2': 'Currently [B]%s[/B] (%s)' % (item, model_descriptions[item][0]),
				'icon': kodi_utils.get_icon(model_descriptions[item][1]), 'current_item': item, 'display_position': count + 1, 'position': count}
				for count, item in enumerate(current_order)]
	kwargs = {'items': json.dumps(choices), 'multi_line': 'true', 'heading': 'Choose Sort Order Of AI Models'}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None: return
	current_model_id = choice['current_item']
	position = choice['position']
	display_position = choice['display_position']
	choices = [{'line1': item, 'line2': model_descriptions[item][0], 'icon': kodi_utils.get_icon(model_descriptions[item][1]), 'model_id': item}
				for item in default_order if item != current_model_id]
	kwargs = {'items': json.dumps(choices), 'multi_line': 'true', 'heading': 'Choose Model for Position %02d' % display_position}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice != None:
		from caches.lists_cache import lists_cache
		lists_cache.delete_like("ai_similar_%")
		model_id = choice['model_id']
		current_order.remove(model_id)
		current_order.insert(position, model_id)
		set_setting('ai_model.order', ','.join(current_order))
	return ai_model_order_choice(params)

def extras_lists_choice(params={}):
	current_settings = settings.extras_enabled()
	choices = kodi_utils.extras_items()
	try: preselect = [choices.index(i) for i in choices if i['value'] in current_settings]
	except: preselect = []
	selection = _pick([(i['name'], i) for i in choices], heading='Enable Content for Extras Lists', multi_choice='true', preselect=preselect)
	if selection  == []:
		kodi_utils.ok_dialog(text='You must select at least 1 item')
		return extras_lists_choice(params)
	elif selection == None: return
	selection = [str(i['value']) for i in selection]
	set_setting('extras.enabled', ','.join(selection))

def extras_order_choice(params={}):
	all_items = kodi_utils.extras_items()
	enabled_items = settings.extras_enabled()
	current_order = settings.extras_order()
	active_items = [i for i in all_items if i['value'] in enabled_items]
	active_items = sorted(active_items, key=lambda k: current_order.index(k['value']))
	choices = [{'line1': 'Position %02d' % (count + 1), 'line2': 'Currently [B]%s[/B]' % (item['name']),
			 'current_item': item, 'display_position': count + 1, 'position': count} for count, item in enumerate(active_items)]
	kwargs = {'items': json.dumps(choices), 'heading': 'Choose Order Of Extras Lists', 'multi_line': 'true', 'narrow_window': 'true'}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None:
		if params.get('remake', False):
			from windows.base_window import ExtrasUtils
			ExtrasUtils().run()
		return
	current_item = choice['current_item']
	position = choice['position']
	display_position = choice['display_position']
	value = _pick([(item['name'], item['value']) for item in active_items if item != current_item], narrow_window='true',
					heading='Choose List Item for Position %02d' % display_position)
	if value != None:
		current_order.remove(value)
		current_order.insert(position, value)
		current_order = [str(i) for i in current_order]
		set_setting('extras.order', ','.join(current_order))
		params['remake'] = True
	return extras_order_choice(params)

def preferred_filters_choice(params):
	from modules.source_utils import source_filters, include_exclude_filters
	def _default_choices():
		return [{'name': '1st Sort', 'value': 'Choose 1st Sort Param'}, {'name': '2nd Sort', 'value': 'Choose 2nd Sort Param'},
				{'name': '3rd Sort', 'value': 'Choose 3rd Sort Param'}, {'name': '4th Sort', 'value': 'Choose 4th Sort Param'},
				{'name': '5th Sort', 'value': 'Choose 5th Sort Param'}]
	def _beginning_choices():
		defaults = _default_choices()
		for count, item in enumerate(auto_settings): defaults[count]['value'] = item
		return defaults
	def _rechoose_checker(choice):
		if choice['value'].startswith('Choose'): return (choice, True)
		clear_choice = kodi_utils.confirm_dialog(heading='Current Param Active', text='This sort slot is already filled.[CR]Please choose what action to take.',
						ok_label='Remake Slot', cancel_label='Clear Slot')
		if clear_choice == None: new_default = choice
		else:
			choice_index = choices.index(choice)
			new_default = _default_choices()[choice_index]
			choices[choice_index] = new_default
		return (new_default, clear_choice)
	def _param_choices(choice):
		filter_keys = include_exclude_filters()
		disabled_filters = [v for k, v in filter_keys.items() if settings.filter_status(k) == 1]
		s_filters = source_filters()
		filters_choice = [(i[0], i[1].replace('[B]', '').replace('[/B]', '')) for i in s_filters]
		filters_choice = [i for i in filters_choice if not i[1] in disabled_filters]
		unused_filters = [i for i in filters_choice if not i[1] in auto_settings]
		param_list_items = [{'line1': i[0], 'line2': i[1]} for i in unused_filters]
		param_kwargs = {'items': json.dumps(param_list_items), 'multi_line': 'true', 'heading': 'Choose Sort to Top Params for Autoplay', 'narrow_window': 'true'}
		param_choice = kodi_utils.select_dialog(unused_filters, **param_kwargs)
		if param_choice == None: return ''
		choice['value'] = param_choice[1]
		return choice
	def _make_settings():
		new_settings = [i['value'] for i in choices if not i['value'].startswith('Choose')]
		if not new_settings: set_setting('filter.preferred_filters', 'empty_setting')
		else: set_setting('filter.preferred_filters', ', '.join(new_settings))
	auto_settings = settings.preferred_filters()
	choices = params.get('choices') or _beginning_choices()
	list_items = [{'line1': i['name'], 'line2': i['value']} for i in choices]
	kwargs = {'items': json.dumps(list_items), 'multi_line': 'true', 'heading': 'Choose Sort to Top Params for Autoplay', 'narrow_window': 'true'}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if choice == None: return _make_settings()
	choice, ask_params = _rechoose_checker(choice)
	if not ask_params: return preferred_filters_choice({'choices': choices})
	param_choice = _param_choices(choice)
	if not param_choice: return preferred_filters_choice({'choices': choices})
	choices[choices.index(choice)] = param_choice
	_make_settings()
	return preferred_filters_choice({'choices': choices})


def clear_sources_folder_choice(params):
	setting_id = params['setting_id']
	set_default(['%s.display_name' % setting_id, '%s.movies_directory' % setting_id, '%s.tv_shows_directory' % setting_id])

def widget_refresh_timer_choice(params):
	choices = [{'name': 'OFF', 'value': '0'}]
	choices.extend([{'name': 'Every %s Minutes' % i, 'value': str(i)} for i in range(5,25,5)])
	choices.extend([{'name': 'Every %s Minutes' % i, 'value': str(i)} for i in range(30,65,10)])
	choices.extend([{'name': 'Every %s Hours' % (float(i)/60), 'value': str(i)} for i in range(90,720,30)])
	_pick_setting(choices, 'widget_refresh_timer', 'widget_refresh_timer_name', narrow_window='true')

def limit_number_quality_choice(params):
	choices = [{'name': 'OFF', 'value': '0'}]
	choices.extend([{'name': '%sx Per Quality' % i, 'value': str(i)} for i in range(1,5)])
	choices.extend([{'name': '%sx Per Quality' % i, 'value': str(i)} for i in range(5,205,5)])
	_pick_setting(choices, 'results.limit_number_quality', 'results.limit_number_quality_name', narrow_window='true')

def limit_number_total_choice(params):
	choices = [{'name': 'OFF', 'value': '0'}]
	choices.extend([{'name': '%sx Total Results' % i, 'value': str(i)} for i in range(1,10)])
	choices.extend([{'name': '%sx Total Results' % i, 'value': str(i)} for i in range(10,1000,5)])
	_pick_setting(choices, 'results.limit_number_total', 'results.limit_number_total_name', narrow_window='true')

def sources_folders_choice(params):
	# LOCAL PATCH 2026-10-01: back with the settings window (Direct Providers > Local Media Folders)
	from windows.base_window import open_window
	return open_window(('windows.settings_manager', 'SettingsManagerFolders'), 'settings_manager_folders.xml')

def anime_providers_choice(params={}):
	# LOCAL PATCH 2026-09-26: the anime whitelist (scrape.anime_providers) read by scrapers/external.py; on anime, a
	# provider NOT ticked here is skipped. The anime-only providers have no switch of their own on the settings screen:
	# ticking one here IS its switch (magneto.provider.<id>, which the bundled magneto.sources() dispatches on).
	# LOCAL PATCH 2026-10-04: only source_utils.ANIME_PROVIDERS are offered (and only they ever run on anime). Saving
	# drops any general provider an older list still named.
	from modules.source_utils import provider_display_name, ANIME_ONLY_PROVIDERS, ANIME_PROVIDERS
	anime_only, providers = list(ANIME_ONLY_PROVIDERS), list(ANIME_PROVIDERS)
	current = [i.strip().lower() for i in get_setting('deadlight.scrape.anime_providers', 'animetosho,seadex,nyaa,nekobt').split(',') if i.strip()]
	preselect = [providers.index(i) for i in current if i in providers]
	# LOCAL PATCH 2026-10-05: a tick here is the provider's anime switch on its own; its switch above is Movies & TV only
	def _line2(i):
		if i in anime_only: return 'Anime only'
		_movies = 'On' if get_setting('deadlight.magneto.provider.%s' % i) == 'true' else 'Off'
		# LOCAL PATCH 2026-11-07: mediafusion has no anime id -- IMDb in Cinemeta's season:episode (external.py stremio_se)
		if i == 'mediafusion': return 'IMDb, Cinemeta season:episode  ·  Movies & TV: %s' % _movies
		return '%s id when mapped, else IMDb season:episode  ·  Movies & TV: %s' % ('AniList' if i == 'meteor' else 'Kitsu', _movies)
	list_items = [{'line1': provider_display_name(i), 'line2': _line2(i)} for i in providers]
	kwargs = {'items': json.dumps(list_items), 'multi_choice': 'true', 'preselect': preselect, 'heading': 'Anime providers'}
	choice = kodi_utils.select_dialog(providers, **kwargs)
	if choice is None: return
	if not choice: return kodi_utils.notification('Choose at least one provider')
	save_anime_providers(choice)

def clear_smartplay_pin_choice(params):
	# LOCAL PATCH 2026-09-27: the context-menu entry. Clears this title's pin only -- the next play shows the
	# picker (or plays as autoplay would) and whatever is chosen then becomes the new pin.
	from modules import smartplay_utils
	tmdb_id = params.get('tmdb_id')
	if smartplay_utils.clear_one(tmdb_id):
		kodi_utils.notification('SmartPlay pin cleared', 2500)
		# LOCAL PATCH 2026-11-08: the entry is baked into each row's context menu when the list is built, so it stays until
		# the list is rebuilt -- rebuild the widgets listing this title and the list on screen, as after a Mark Watched.
		kodi_utils.refresh(titles=tmdb_id)
	else: kodi_utils.notification('No SmartPlay pin for this title', 2500)

def magneto_health_choice(params={}):
	# LOCAL PATCH 2026-09-27: magneto's "Test All Torrent Providers" for the bundled providers. Searches one movie on
	# EVERY general provider, switched on or not (the point is to see which are worth switching on), and lists time and
	# results. A 30 s cap so a dead site cannot hold the dialog; anime-only providers are listed, not searched, because
	# they need the anime ids scrapers/external.py prepares for a real scrape.
	import requests
	from time import monotonic
	from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
	from magneto import sources as magneto_sources
	from modules.source_utils import provider_display_name
	limit, resolutions = 30, ('4K', '1080p', '720p', 'SD')
	imdb_id = (kodi_utils.kodi_dialog().input('Movie IMDb id to search for', defaultt='tt0120903') or '').strip()
	if not imdb_id: return
	try:
		result = requests.get('https://v2.sg.media-imdb.com/suggestion/t/%s.json' % imdb_id, timeout=5).json()
		hit = next((i for i in result.get('d', []) if i.get('id') == imdb_id), None)
	except Exception: hit = None
	if not hit: return kodi_utils.notification('Movie %s not found' % imdb_id)
	data = {'imdb': imdb_id, 'title': hit.get('l') or '', 'aliases': [], 'year': str(hit.get('y') or '')}
	poster = (hit.get('i') or {}).get('imageUrl') or kodi_utils.addon_icon()
	rootname = '%s (%s)' % (data['title'], data['year'])
	anime_only = {i.strip().lower() for i in (get_setting('deadlight.scrape.anime_only_providers', 'nyaa,animetosho,seadex,nekobt') or '').split(',') if i.strip()}
	modules, skipped = [], []
	for name, cls in magneto_sources(ret_all=True):
		if name in anime_only: skipped.append(name)
		elif getattr(cls, 'hasMovies', False): modules.append((name, cls))
	if not modules: return kodi_utils.notification('No torrent providers found')
	def _run(name, cls):
		start = monotonic()
		try: found = cls().sources(dict(data), {})
		except Exception as e:
			kodi_utils.logger('magneto_health', '%s raised: %s' % (name, e))
			found = None
		return name, found, monotonic() - start
	results = {}
	progress = kodi_utils.progress_dialog('Testing torrent providers', poster)
	pool = ThreadPoolExecutor(max_workers=len(modules))
	pending, start, cancelled = {pool.submit(_run, n, c) for n, c in modules}, monotonic(), False
	try:
		while pending and monotonic() - start < limit:
			done, pending = wait(pending, timeout=0.5, return_when=FIRST_COMPLETED)
			for future in done:
				name, found, secs = future.result()
				results[name] = (found, secs)
			try:
				if progress.iscanceled():
					cancelled = True
					break
				progress.update('%s[CR]%d of %d providers answered  ·  %ds' % (rootname, len(results), len(modules), monotonic() - start),
								int(100.0 * len(results) / len(modules)))
			except Exception: pass
	finally:
		try: progress.close()
		except Exception: pass
		pool.shutdown(wait=False)
	if cancelled: return
	def _row(name):
		on = 'On' if get_setting('deadlight.magneto.provider.%s' % name) == 'true' else 'Off'
		if name not in results: return 2, limit, {'line1': '%s  ·  no answer' % provider_display_name(name), 'line2': '%s  |  no answer in %d s' % (on, limit)}
		found, secs = results[name]
		if found is None: return 2, secs, {'line1': '%s  ·  %.2fs' % (provider_display_name(name), secs), 'line2': '%s  |  failed (see kodi.log)' % on}
		counts = dict.fromkeys(resolutions, 0)
		for i in found:
			quality = i.get('quality')
			counts[quality if quality in counts else 'SD'] += 1
		line2 = '%s  |  %d results  |  %s' % (on, len(found), '  '.join('%s %d' % (k, v) for k, v in counts.items()))
		return (0 if found else 1), secs, {'line1': '%s  ·  %.2fs' % (provider_display_name(name), secs), 'line2': line2}
	rows = sorted((_row(name) for name, cls in modules), key=lambda r: (r[0], r[1]))
	list_items = [r[2] for r in rows] + [{'line1': provider_display_name(name), 'line2': 'Anime only  |  not searched on a movie'} for name in sorted(skipped)]
	for i in list_items: i['icon'] = poster
	kwargs = {'items': json.dumps(list_items), 'heading': 'Torrent providers - %s' % rootname}
	kodi_utils.select_dialog(list_items, **kwargs)

def magneto_undesirables_choice(params):
	# LOCAL PATCH 2026-09-26: magneto's own undesirables editors, for the bundled providers.
	from magneto.modules import undesirables
	undesirables.Undesirables().check_database()
	func = {'select': undesirables.undesirablesSelect, 'input': undesirables.undesirablesInput,
			'remove': undesirables.undesirablesUserRemove, 'remove_all': undesirables.undesirablesUserRemoveAll}.get(params.get('action'))
	if func: func()

def audio_filters_choice(params={}):
	from modules.source_utils import audio_filter_choices
	icon = kodi_utils.get_icon('audio')
	audio_filters = audio_filter_choices()
	list_items = [{'line1': item[0], 'line2': item[1], 'icon': icon} for item in audio_filters]
	try: preselect = [audio_filters.index(item) for item in audio_filters if item[1] in settings.audio_filters()]
	except: preselect = []
	kwargs = {'items': json.dumps(list_items), 'heading': 'Choose Audio Properties to Exclude', 'multi_choice': 'true', 'multi_line': 'true', 'preselect': preselect}
	selection = kodi_utils.select_dialog([i[1] for i in audio_filters], **kwargs)
	if selection == None: return
	if selection == []: set_setting('filter_audio', 'empty_setting')
	else: set_setting('filter_audio', ', '.join(selection))

def genres_choice(params):
	genres_list, genres, poster = params['genres_list'], params['genres'], params['poster']
	genre_list = [i for i in genres_list if i['name'] in genres]
	if not genre_list:
		kodi_utils.notification('No Results', 2500)
		return None
	list_items = [{'line1': i['name'], 'icon': poster} for i in genre_list]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Genres'}
	return kodi_utils.select_dialog([i['id'] for i in genre_list], **kwargs)

def keywords_choice(params):
	media_type, meta = params['media_type'], params['meta']
	keywords, tmdb_id, poster = meta.get('keywords', []), meta['tmdb_id'], meta['poster']
	if keywords: keywords = keywords.get('keywords') or keywords.get('results')
	else:
		kodi_utils.show_busy_dialog()
		from apis.tmdb_api import tmdb_movie_keywords, tmdb_tv_keywords
		if media_type == 'movie': function, key = tmdb_movie_keywords, 'keywords'
		else: function, key = tmdb_tv_keywords, 'results'
		try: keywords = function(tmdb_id)[key]
		except: keywords = []
		kodi_utils.hide_busy_dialog()
	if not keywords:
		kodi_utils.notification('No Results', 2500)
		return None
	list_items = [{'line1': i['name'], 'icon': poster} for i in keywords]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Keywords'}
	return kodi_utils.select_dialog([i['id'] for i in keywords], **kwargs)

def random_choice(params):
	meta, poster, return_choice = params.get('meta'), params.get('poster'), params.get('return_choice', 'false')
	list_items = [{'line1': 'Single Random Play', 'icon': poster}, {'line1': 'Continual Random Play', 'icon': poster}]
	choices = ['play_random', 'play_random_continual']
	kwargs = {'items': json.dumps(list_items), 'heading': 'Choose Random Play Type...'}
	choice = kodi_utils.select_dialog(choices, **kwargs)
	if return_choice == 'true': return choice
	if choice == None: return
	exec('EpisodeTools(meta).%s()' % choice)

# LOCAL PATCH 2026-11-01 (cleanup): the menu trakt_manager_choice and mdblist_manager_choice share, and its four
# watchlist / collection actions run from a table of each service's functions
_LIST_MANAGER_CHOICES = [('Add to [B]Watchlist[/B]', 'add_watchlist'), ('Remove from [B]Watchlist[/B]', 'remove_watchlist'),
						('Add to [B]Collection[/B]', 'add_collection'), ('Remove from [B]Collection[/B]', 'remove_collection'),
						('Add To [B]Personal List[/B]...', 'add'), ('Remove from [B]Personal List[/B]...', 'remove')]

def trakt_manager_choice(params):
	if not settings.trakt_user_active(): return kodi_utils.notification('No Active Trakt Account', 3500)
	tmdb_id, tvdb_id, imdb_id, media_type = params['tmdb_id'], params['tvdb_id'], params['imdb_id'], params['media_type']
	icon = params.get('icon', None) or kodi_utils.get_icon('trakt')
	choice = _pick(_LIST_MANAGER_CHOICES, heading='Trakt Lists Manager', icon=icon)
	if choice == None: return
	from apis import trakt_api
	if media_type == 'movie': key, media_key, media_id = ('movies', 'tmdb', int(tmdb_id))
	else:
		key = 'shows'
		media_ids = [(tmdb_id, 'tmdb'), (imdb_id, 'imdb'), (tvdb_id, 'tvdb')]
		media_id, media_key = next(item for item in media_ids if item[0] not in ('None', None, ''))
		if media_id in (tmdb_id, tvdb_id): media_id = int(media_id)
	data = {key: [{'ids': {media_key: media_id}}]}
	simple = {'add_watchlist': trakt_api.add_to_watchlist, 'remove_watchlist': trakt_api.remove_from_watchlist,
			'add_collection': trakt_api.add_to_collection, 'remove_collection': trakt_api.remove_from_collection}
	if choice in simple: return simple[choice](data)
	selected = trakt_api.get_trakt_list_selection(['personal'])
	if selected == None: return
	trakt_api.add_to_list(selected['user'], selected['slug'], data) if choice == 'add' else trakt_api.remove_from_list(selected['user'], selected['slug'], data)

# LOCAL PATCH 2026-07-23: MDBList Manager context-menu dialog, mirroring trakt_manager_choice. Personal-list
# add/remove uses the user's own MDBList lists (from mdbl_get_lists).
def mdblist_manager_choice(params):
	if not settings.mdblist_user_active(): return kodi_utils.notification('No Active MDBList Account', 3500)
	tmdb_id, imdb_id, media_type = params['tmdb_id'], params['imdb_id'], params['media_type']
	icon = params.get('icon', None) or kodi_utils.get_icon('mdblist')
	choices = list(_LIST_MANAGER_CHOICES)
	if media_type in ('tvshow', 'shows'):
		choices.append(('Toggle [B]Dropped[/B]', 'toggle_drop'))
	choice = _pick(choices, heading='MDBList Manager', icon=icon)
	if choice is None: return
	from apis import mdblist_api
	# MDBList prefers tmdb for movies, imdb for shows (matches POV's mdbl_watched_unwatched).
	if media_type == 'movie':
		key, media_key, media_id = 'movies', 'tmdb', int(tmdb_id)
	else:
		key = 'shows'
		# Prefer imdb for shows; fall back to tmdb.
		if imdb_id not in ('None', None, ''): media_key, media_id = 'imdb', imdb_id
		else: media_key, media_id = 'tmdb', int(tmdb_id)
	data = {key: [{'ids': {media_key: media_id}}]}
	simple = {'add_watchlist': lambda d: mdblist_api.add_to_list('watchlist', d), 'remove_watchlist': lambda d: mdblist_api.remove_from_list('watchlist', d),
			'add_collection': mdblist_api.add_to_collection, 'remove_collection': mdblist_api.remove_from_collection}
	if choice in simple: return simple[choice](data)
	if choice == 'toggle_drop':
		# LOCAL PATCH 2026-09-20: the first argument is the id the toggle looks up in the dropped set (TMDb ids); media_id
		# is imdb-preferred for shows, so pass tmdb_id for the lookup and keep media_id as the payload -- as POV does.
		return mdblist_api.hide_unhide_mdbl_items(str(tmdb_id), media_type, media_id, 'dropped')
	# Personal-list add/remove — user picks which of their MDBList lists to target.
	try:
		lists = mdblist_api.mdbl_get_lists('my_lists') or []
	except: lists = []
	if not lists: return kodi_utils.notification('No MDBList Lists Found')
	list_items = [{'line1': l.get('name', 'Unnamed'), 'line2': '%s items' % l.get('items', l.get('item_count', 0)), 'icon': icon} for l in lists]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Select MDBList List', 'multi_line': 'true'}
	list_ids = [l.get('id') or l.get('list_id') for l in lists]
	list_choice = kodi_utils.select_dialog(list_ids, **kwargs)
	if list_choice is None: return
	if choice == 'add':
		return mdblist_api.add_to_list(list_choice, data)
	return mdblist_api.remove_from_list(list_choice, data)


# LOCAL PATCH 2026-07-29: SIMKL Manager context-menu dialog. SIMKL uses list statuses (watching / plantowatch /
# hold / completed / dropped) rather than named lists, with "On Hold" first-class. Adds a Rate action too.
def simkl_manager_choice(params):
	if not settings.simkl_user_active(): return kodi_utils.notification('No Active SIMKL Account', 3500)
	tmdb_id, media_type = params.get('tmdb_id'), params.get('media_type')
	icon = params.get('icon', None) or kodi_utils.get_icon('lists')
	choices = [
		('Add to [B]Watching[/B]', 'watching'),
		('Add to [B]Plan to Watch[/B]', 'plantowatch'),
		('Add to [B]On Hold[/B]', 'hold'),
		('Add to [B]Completed[/B]', 'completed'),
		('Add to [B]Dropped[/B]', 'dropped'),
		('[B]Rate...[/B]', 'rate'),
		('Remove from All Lists', 'remove_all'),
	]
	choice = _pick(choices, heading='SIMKL Manager', icon=icon)
	if choice is None: return
	from apis import simkl_api
	# LOCAL PATCH 2026-07-30: SIMKL splits shows vs anime as separate list types; anime detected via TMDb keyword 210024
	# (is_anime_check). Falls back to 'shows' when unknown.
	if media_type == 'movie':
		list_type = 'movies'
	else:
		list_type = 'shows'
		try:
			from modules.metadata import is_anime_check
			if is_anime_check(tmdb_id=tmdb_id): list_type = 'anime'
		except Exception: pass
	try: tmdb_int = int(tmdb_id)
	except: return kodi_utils.notification('SIMKL: invalid TMDb ID', 3500)
	def _clear_lists_cache():   # LOCAL PATCH 2026-11-01 (cleanup): was written out in both branches below
		try:
			from caches.simkl_cache import clear_simkl_lists_cache
			clear_simkl_lists_cache()
		except Exception: pass
	if choice == 'rate':
		# Delegates to the rating picker in apis/simkl_api.py.
		return simkl_api.simkl_rate_dialog({'tmdb_id': tmdb_int, 'list_type': list_type, 'media_type': media_type})
	if choice == 'remove_all':
		# SIMKL doesn't have "remove from all lists" in one call — use unwatched
		# (which drops from history) and try to move-out of the status lists too.
		ok = simkl_api.simkl_mark_unwatched(list_type, 'tmdb', tmdb_int)
		_clear_lists_cache()
		if ok: kodi_utils.refresh('simkl', screen='if_listed')   # LOCAL PATCH 2026-11-01: no reload at all before
		return kodi_utils.notification('SIMKL: Removed' if ok else 'SIMKL: Remove Failed', 3500)
	# Status add — watching / plantowatch / hold / completed / dropped
	ok = simkl_api.simkl_add_to_list(list_type, 'tmdb', tmdb_int, choice)
	label_by_status = {'watching': 'Watching', 'plantowatch': 'Plan to Watch',
		'hold': 'On Hold', 'completed': 'Completed', 'dropped': 'Dropped'}
	_clear_lists_cache()
	if ok: kodi_utils.refresh('simkl', screen='if_listed')   # LOCAL PATCH 2026-11-01: no reload at all before
	kodi_utils.notification('SIMKL: Added to %s' % label_by_status.get(choice, choice) if ok else 'SIMKL: Failed', 3500)


def episode_groups_choice(params):
	from modules.metadata import episode_groups
	episode_group_types = {1: 'Original Air Date', 2: 'Absolute', 3: 'DVD', 4: 'Digital', 5: 'Story Arc', 6: 'Production', 7: 'TV'}
	meta = params.get('meta')
	poster = params.get('poster') or kodi_utils.get_icon('box_office')
	groups = episode_groups(meta['tmdb_id'])
	if not groups:
		kodi_utils.notification('No Episode Groups to choose from.')
		return None
	list_items = [{'line1': '%s | %s Order | %d Groups | %02d Episodes' % (item['name'], episode_group_types[item['type']], item['group_count'], item['episode_count']),
					'line2': item['description'], 'icon': poster} for item in groups]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Episode Groups', 'enable_context_menu': 'true', 'enumerate': 'true', 'multi_line': 'true'}
	choice = kodi_utils.select_dialog([i['id'] for i in groups], **kwargs)
	return choice

def assign_episode_group_choice(params):
	from caches.episode_groups_cache import episode_groups_cache
	from modules import metadata
	tmdb_id = params['meta']['tmdb_id']
	current_group = episode_groups_cache.get(tmdb_id)
	if current_group:
		action = kodi_utils.confirm_dialog(text='Set new Group or Clear Current Group?', ok_label='Set New', cancel_label='Clear', default_control=10)
		if action == None: return
		if not action:
			episode_groups_cache.delete(tmdb_id)
			return kodi_utils.notification('Success', 2000)
	choice = episode_groups_choice(params)
	if choice == None: return
	group_details = metadata.group_details(choice)
	group_data = {'name': group_details['name'], 'id': group_details['id']}
	episode_groups_cache.set(tmdb_id, group_data)
	kodi_utils.notification('Success', 2000)

def playback_choice(params):
	from modules.utils import get_datetime
	from modules.debrid import debrid_for_ext_cache_check
	from modules.source_utils import get_aliases_titles, make_alias_dict
	from modules import metadata
	media_type, season, episode, episode_id = params.get('media_type'), params.get('season', ''), params.get('episode', ''), params.get('episode_id', None)
	playcount = params.get('playcount', '0')
	playback_key = settings.playback_key()
	play_mode = 'playback.%s' % playback_key
	meta = params.get('meta')
	try: meta = json.loads(meta)
	except: pass
	if not isinstance(meta, dict):
		function = metadata.movie_meta if media_type == 'movie' else metadata.tvshow_meta
		meta = function('tmdb_id', meta, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
	poster = meta.get('poster') or kodi_utils.get_icon('box_office')
	aliases = get_aliases_titles(make_alias_dict(meta, meta['title']))
	check_cache_status, check_cache_toggle =  ('OFF', 'false') if settings.external_cache_check() else ('ON', 'true')
	items = [{'line': 'Select Source', 'function': 'scrape'},
			{'line': 'Rescrape & Select Source', 'function': 'clear_and_rescrape'}]
	if debrid_for_ext_cache_check():
		items.append({'line': 'Rescrape with External Cache Check [B]%s[/B]' % check_cache_status, 'function': 'rescrape_external_cache_check'})
	items.extend([{'line': 'Clear Debrid Cache & Show Results', 'function': 'clear_debrid_cache_and_show'},
				{'line': 'Scrape with ALL External Scrapers', 'function': 'scrape_with_disabled'},
				{'line': 'Scrape With All Filters Ignored', 'function': 'scrape_with_filters_ignored'}])
	if media_type == 'episode': items.append({'line': 'Scrape with Custom Episode Groups Value', 'function': 'scrape_with_episode_group'})
	if aliases: items.append({'line': 'Scrape with an Alias', 'function': 'scrape_with_aliases'})
	items.append({'line': 'Scrape with Custom Values', 'function': 'scrape_with_custom_values'})
	# LOCAL PATCH 2026-09-27: 'Clear SmartPlay Sticky for This Title' moved to the item's context menu
	# (Clear SmartPlay Pin -> clear_smartplay_pin_choice).
	list_items = [{'line1': i['line'], 'icon': poster} for i in items]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Playback Options'}
	choice = kodi_utils.select_dialog([i['function'] for i in items], **kwargs)
	if choice == None: return kodi_utils.notification('Cancelled', 2500)
	if choice in ('clear_and_rescrape', 'scrape_with_custom_values'):
		kodi_utils.show_busy_dialog()
		from caches.base_cache import clear_cache
		from caches.external_cache import ExternalCache
		clear_cache('internal_scrapers', silent=True)
		ExternalCache().delete_cache_single(media_type, str(meta['tmdb_id']))
		kodi_utils.hide_busy_dialog()
	if choice == 'scrape':
		if media_type == 'movie': play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'], 'autoplay': 'false', 'prescrape': 'false'}
		else: play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'],
							'season': season, 'episode': episode, 'autoplay': 'false', 'prescrape': 'false'}
	elif choice == 'clear_and_rescrape':
		if media_type == 'movie': play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'], 'autoplay': 'false', 'prescrape': 'false'}
		else: play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'],
							'season': season, 'episode': episode, 'autoplay': 'false', 'prescrape': 'false'}
	elif choice == 'rescrape_external_cache_check':
		# LOCAL PATCH 2026-06-15: autoplay=false on rescrape paths (port from POV 5.10)
		if media_type == 'movie': play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'],
												'external_cache_check': check_cache_toggle, 'prescrape': 'false', 'autoplay': 'false'}
		else:
			play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'], 'season': season, 'episode': episode,
							'external_cache_check': check_cache_toggle, 'prescrape': 'false', 'autoplay': 'false'}
	elif choice == 'clear_debrid_cache_and_show':
		from caches.debrid_cache import debrid_cache
		debrid_cache.clear_cache()	
		if media_type == 'movie': play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'], 'autoplay': 'false', 'prescrape': 'false'}
		else: play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'],
							'season': season, 'episode': episode, 'autoplay': 'false', 'prescrape': 'false'}
	elif choice == 'scrape_with_disabled':
		if media_type == 'movie': play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'],
												'disabled_ext_ignored': 'true', 'all_scrapers': 'true', 'prescrape': 'false', 'autoplay': 'false'}
		else: play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'], 'season': season,
							'episode': episode, 'disabled_ext_ignored': 'true', 'all_scrapers': 'true', 'prescrape': 'false', 'autoplay': 'false'}
	elif choice == 'scrape_with_filters_ignored':
		if media_type == 'movie': play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'],
												'ignore_scrape_filters': 'true', 'prescrape': 'false', 'autoplay': 'false'}
		else: play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'], 'season': season,
							'episode': episode, 'ignore_scrape_filters': 'true', 'prescrape': 'false', 'autoplay': 'false'}
		kodi_utils.set_property('fs_filterless_search', 'true')
	elif choice == 'scrape_with_episode_group':
		choice = episode_groups_choice({'meta': meta, 'poster': poster})
		if choice == None: return playback_choice(params)
		episode_details = metadata.group_episode_data(metadata.group_details(choice), episode_id, season, episode)
		if not episode_details:
			kodi_utils.notification('No matching episode')
			return playback_choice(params)
		# LOCAL PATCH 2026-06-15: autoplay=false on rescrape paths (port from POV 5.10)
		play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'], 'season': season, 'episode': episode, 'prescrape': 'false',
		'custom_season': episode_details['season'], 'custom_episode': episode_details['episode'], 'autoplay': 'false'}
	elif choice == 'scrape_with_aliases':
		if len(aliases) == 1: custom_title = aliases[0]
		else:
			list_items = [{'line1': i, 'icon': poster} for i in aliases]
			kwargs = {'items': json.dumps(list_items), 'heading': 'Search with Title'}
			custom_title = kodi_utils.select_dialog(aliases, **kwargs)
			if custom_title == None: return kodi_utils.notification('Cancelled', 2500)
		custom_title = kodi_utils.kodi_dialog().input('Title', defaultt=custom_title)
		if not custom_title: return kodi_utils.notification('Cancelled', 2500)
		# LOCAL PATCH 2026-06-15: autoplay=false on rescrape paths (port from POV 5.10)
		if media_type in ('movie', 'movies'): play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'],
						'custom_title': custom_title, 'prescrape': 'false', 'autoplay': 'false'}
		else: play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'], 'season': season, 'episode': episode,
							'custom_title': custom_title, 'prescrape': 'false', 'autoplay': 'false'}
	elif choice == 'scrape_with_custom_values':
		default_title, default_year = meta['title'], str(meta['year'])
		# LOCAL PATCH 2026-06-15: autoplay=false on rescrape paths (port from POV 5.10)
		if media_type in ('movie', 'movies'): play_params = {'mode': play_mode, 'media_type': 'movie', 'tmdb_id': meta['tmdb_id'], 'prescrape': 'false', 'autoplay': 'false'}
		else: play_params = {'mode': play_mode, 'media_type': 'episode', 'tmdb_id': meta['tmdb_id'], 'season': season, 'episode': episode, 'prescrape': 'false', 'autoplay': 'false'}
		if aliases:
			if len(aliases) == 1: alias_title = aliases[0]
			list_items = [{'line1': i, 'icon': poster} for i in aliases]
			kwargs = {'items': json.dumps(list_items), 'heading': 'Search with Title'}
			alias_title = kodi_utils.select_dialog(aliases, **kwargs)
			if alias_title: custom_title = kodi_utils.kodi_dialog().input('Title', defaultt=alias_title)
			else: custom_title = kodi_utils.kodi_dialog().input('Title', defaultt=default_title)
		else: custom_title = kodi_utils.kodi_dialog().input('Title', defaultt=default_title)
		if not custom_title: return kodi_utils.notification('Cancelled', 2500)
		def _process_params(default_value, custom_value, param_value):
			if custom_value and custom_value != default_value: play_params[param_value] = custom_value
		_process_params(default_title, custom_title, 'custom_title')
		custom_year = kodi_utils.kodi_dialog().input('Year', type=1, defaultt=default_year)
		_process_params(default_year, custom_year, 'custom_year')
		if media_type == 'episode':
			custom_season = kodi_utils.kodi_dialog().input('Season', type=1, defaultt=season)
			_process_params(season, custom_season, 'custom_season')
			custom_episode = kodi_utils.kodi_dialog().input('Episode', type=1, defaultt=episode)
			_process_params(episode, custom_episode, 'custom_episode')
			if any(i in play_params for i in ('custom_season', 'custom_episode')):
				if settings.autoplay_next_episode(): _process_params('', 'true', 'disable_autoplay_next_episode')
		all_choice = kodi_utils.confirm_dialog(heading=meta.get('rootname', ''), text='Scrape with ALL External Scrapers?', ok_label='Yes', cancel_label='No')
		if all_choice == None: return kodi_utils.notification('Cancelled', 2500)
		if all_choice: _process_params('', 'true', 'disabled_ext_ignored')
		disable_filters_choice = kodi_utils.confirm_dialog(heading=meta.get('rootname', ''), text='Disable All Filters for Search?', ok_label='Yes', cancel_label='No')
		if disable_filters_choice == None: return kodi_utils.notification('Cancelled', 2500)
		if disable_filters_choice:
			_process_params('', 'true', 'ignore_scrape_filters')
			kodi_utils.set_property('fs_filterless_search', 'true')
	if media_type == 'episode': play_params['playcount'] = playcount
	play_params[playback_key] = playback_key
	from modules.sources import Sources
	Sources().playback_prep(play_params)

def set_quality_choice(params):
	quality_setting = params.get('setting_id')
	icon = params.get('icon', None) or ''
	dl = ['Include 4K', 'Include 1080p', 'Include 720p', 'Include SD']
	fl = ['4K', '1080p', '720p', 'SD']
	q_setting = get_setting('deadlight.%s' % quality_setting).split(', ')
	try: preselect = [fl.index(i) for i in q_setting]
	except: preselect = []
	choice = _pick(list(zip(dl, fl)), heading='Choose the Included Qualities', icon=icon, multi_choice='true', preselect=preselect)
	if choice is None: return
	if choice == []:
		kodi_utils.ok_dialog(text='You must select at least 1 Quality')
		return set_quality_choice(params)
	set_setting(quality_setting, ', '.join(choice))

def extras_buttons_choice(params):
	extras_button_label_values = kodi_utils.extras_button_label_values()
	media_type, button_dict, orig_button_dict = params.get('media_type', None), params.get('button_dict', {}), params.get('orig_button_dict', {})
	if not orig_button_dict:
		for _type in ('movie', 'tvshow'):
			for item in range(10, 18):
				setting_id = 'extras.%s.button%s' % (_type, item)
				try:
					button_action = get_setting('deadlight.%s' % setting_id)
					button_label = extras_button_label_values[_type][button_action]
				except:
					set_setting(setting_id.replace('deadlight.', ''), default_setting_values(setting_id)['setting_default'])
					button_action = get_setting('deadlight.%s' % setting_id)
					button_label = extras_button_label_values[_type][button_action]
				# LOCAL PATCH 2026-11-07: Button 1 is the accent-filled primary of the Extras button row
				name = 'Button 1 (highlighted)' if item == 10 else 'Button %s' % str(item - 9)
				button_dict[setting_id] = {'button_action': button_action, 'button_label': button_label, 'button_name': name}
				orig_button_dict[setting_id] = {'button_action': button_action, 'button_label': button_label, 'button_name': name}
	if media_type == None:
		choices = [('Set [B]Movie[/B] Buttons', 'movie'),
					('Set [B]TV Show[/B] Buttons', 'tvshow'),
					('Restore [B]Movie[/B] Buttons to Default', 'restore.movie'),
					('Restore [B]TV Show[/B] Buttons to Default', 'restore.tvshow'),
					('Restore [B]Movie & TV Show[/B] Buttons to Default', 'restore.both')]
		choice = _pick([(i[0], i) for i in choices], heading='Choose Media Type to Set Buttons', narrow_window='true')
		if choice == None:
			if button_dict != orig_button_dict:
				for k, v in button_dict.items(): set_setting(k, v['button_action'])
			return
		media_type = choice[1]
		if 'restore' in media_type:
			restore_type = media_type.split('.')[1]
			if restore_type in ('movie', 'both'):
				for item in [(i, default_setting_values(i)['setting_default']) for i in ('extras.movie.button%s' % i for i in range(10,18))]:
					set_setting(item[0], item[1])
			if restore_type in ('tvshow', 'both'):
				for item in [(i, default_setting_values(i)['setting_default']) for i in ('extras.tvshow.button%s' % i for i in range(10,18))]:
					set_setting(item[0], item[1])
			return extras_buttons_choice({})
	choices = [('[B]%s[/B]   |   %s' % (v['button_name'], v['button_label']), v['button_name'], v['button_label'], k) for k, v in button_dict.items() if media_type in k]
	choice = _pick([(i[0], i) for i in choices], heading='Choose Button to Set', narrow_window='true')
	if choice == None: return extras_buttons_choice({'button_dict': button_dict, 'orig_button_dict': orig_button_dict})
	button_name, button_label, button_setting = choice[1:]
	choices = [(v, k) for k, v in extras_button_label_values[media_type].items() if not v == button_label]
	choices = [i for i in choices if not i[0] == button_label]
	choice = _pick([(i[0], i) for i in choices], heading='Choose Action For %s' % button_name, narrow_window='true')
	if choice == None: return extras_buttons_choice({'button_dict': button_dict, 'orig_button_dict': orig_button_dict, 'media_type': media_type})
	button_label, button_action = choice
	button_dict[button_setting] = {'button_action': button_action, 'button_label': button_label, 'button_name': button_name}
	return extras_buttons_choice({'button_dict': button_dict, 'orig_button_dict': orig_button_dict, 'media_type': media_type})

def extras_ratings_choice(params={}):
	choices = [('Metacritic', 'Meta', 'metacritic.png'), ('Tomato Rating Critic', 'Tom/Critic', 'rtcertified.png'),
				('Tomato Rating User', 'Tom/User', 'popcorn.png'), ('IMDb', 'IMDb', 'imdb.png'), ('TMDb', 'TMDb', 'tmdb.png'),
				('AniList (anime)', 'AniList', 'anilist.png'), ('MyAnimeList (anime)', 'MAL', 'mal.png')]   # LOCAL PATCH 2026-11-07
	current_settings = settings.extras_enabled_ratings()
	try: preselect = [choices.index(i) for i in choices if i[1] in current_settings]
	except: preselect = []
	selection = _pick([(i[0], i, 'deadlight_flags/ratings/%s' % i[2]) for i in choices], heading='Ratings to Display', multi_choice='true', preselect=preselect)
	if selection == None: return
	if selection == []:
		kodi_utils.ok_dialog(text='You must select at least 1 Ratings Provider')
		return extras_ratings_choice()
	set_setting('extras.enabled_ratings', ', '.join([i[1] for i in selection]))

def set_language_filter_choice(params):
	from modules.meta_lists import language_choices
	filter_setting_id, multi_choice, include_none = params.get('filter_setting_id'), params.get('multi_choice', 'false'), params.get('include_none', 'false')
	lang_choices = language_choices()
	if include_none == 'false': lang_choices.pop('None')
	dl, fl = list(lang_choices.keys()), list(lang_choices.values())
	set_filter = get_setting('deadlight.%s' % filter_setting_id).split(', ')
	try: preselect = [fl.index(i) for i in set_filter]
	except: preselect = []
	choice = _pick(list(zip(dl, fl)), multi_choice=multi_choice, preselect=preselect)
	if choice == None: return
	if multi_choice == 'true':
		if choice == []: set_setting(filter_setting_id, 'eng')
		else: set_setting(filter_setting_id, ', '.join(choice))
	else: set_setting(filter_setting_id, choice)

# LOCAL PATCH 2026-10-01: each bundled torrent provider is its own line too, under the groups (as Red Light's
# Options > Enable Scrapers), writing the same magneto.provider.<id> settings as the Scrapers page. The anime-only
# providers are switched by their tick in scrape.anime_providers, which sync_settings re-applies at every start.
_TORRENT_SCRAPERS = ('torrentio', 'comet', 'mediafusion', 'torz', 'torrentsdb', 'bitmagnet', 'meteor',
					 'knaben', 'torlock', 'torrentdownload', 'apibay', 'torrentgalaxy', 'torrentscsv', 'torrentdownloads')
_ANIME_ONLY_SCRAPERS = ('animetosho', 'seadex', 'nekobt', 'nyaa')
# LOCAL PATCH 2026-10-05: two lists that never touch -- Movies & TV (each provider's own switch, magneto.provider.<id>)
# and Anime (scrape.anime_providers alone, source_utils.anime_provider_list). The Options menu shows the one for the
# item it was opened on; the anime-only providers never run off anime.

def enabled_torrent_scrapers(anime=False):
	if anime:
		from modules.source_utils import anime_provider_list
		return anime_provider_list()
	return [i for i in _TORRENT_SCRAPERS if get_setting('deadlight.magneto.provider.%s' % i) == 'true']

def save_anime_providers(choice):
	"""scrape.anime_providers, plus the anime-only four's own switches kept in step with it (settings_cache.sync_settings
	re-applies the same at every start; the health test and magneto read those switches)."""
	for i in _ANIME_ONLY_SCRAPERS: set_setting('magneto.provider.%s' % i, 'true' if i in choice else 'false')
	set_setting('scrape.anime_providers', ','.join(choice))

def enable_scrapers_choice(params={}):
	from modules.source_utils import provider_panel_name, ANIME_PROVIDERS
	icon = params.get('icon', None) or kodi_utils.get_icon('fenlight')
	anime = params.get('anime') in (True, 'true')
	cloud_scrapers = {'rd_cloud': 'rd.enabled', 'pm_cloud': 'pm.enabled', 'ad_cloud': 'ad.enabled', 'tb_cloud': 'tb.enabled'}
	# LOCAL PATCH 2026-10-01: the torrent sites sit right under External Scrapers, in Settings > Scrapers order (IMDb-id
	# providers, then indexers); the other sources follow, TorBox Cloud first among the clouds.
	torrents = list(ANIME_PROVIDERS if anime else _TORRENT_SCRAPERS)
	groups = ['external', 'http_streams', 'aiostreams', 'easynews', 'tb_cloud', 'rd_cloud', 'pm_cloud', 'ad_cloud', 'folders']
	# LOCAL PATCH 2026-10-09: what is switched on comes first -- the sources, and the sites under External -- each part keeping
	# the order above. External stays a block with its sites under it, wherever it sorts to.
	active = settings.active_internal_scrapers()
	sites_enabled = enabled_torrent_scrapers(anime)
	torrents.sort(key=lambda i: i not in sites_enabled)
	groups.sort(key=lambda i: i not in active)
	# LOCAL PATCH 2026-10-09: Direct Streams' own providers under it, the way External has its sites (switched-on first)
	direct = [('hdhub', 'HDHUB'), ('sootio', 'CUSTOM STREMIO ADDON')]
	direct_enabled = [k for k, _n in direct if get_setting('deadlight.http_streams.%s' % k, 'false') == 'true']
	direct.sort(key=lambda kn: kn[0] not in direct_enabled)
	no_url = get_setting('deadlight.http_streams.sootio_url', '') in ('', 'empty_setting', 'None')
	group_names = {'external': 'EXTERNAL SCRAPERS (%s)' % ('ANIME' if anime else 'TORRENTS'), 'http_streams': 'DIRECT STREAMS',
				   'aiostreams': 'AIOSTREAMS', 'easynews': 'EASYNEWS', 'tb_cloud': 'TB CLOUD', 'rd_cloud': 'RD CLOUD', 'pm_cloud': 'PM CLOUD',
				   'ad_cloud': 'AD CLOUD', 'folders': 'FOLDERS 1-5'}
	scrapers, scraper_names = [], []
	for g in groups:
		scrapers.append(g); scraper_names.append(group_names[g])
		if g == 'external':
			scrapers.extend('magneto.%s' % i for i in torrents)
			scraper_names.extend('     %s' % provider_panel_name(i).upper() for i in torrents)
		elif g == 'http_streams':
			scrapers.extend('direct.%s' % k for k, _n in direct)
			scraper_names.extend('     %s%s' % (n, ' (NO URL SET)' if k == 'sootio' and no_url else '') for k, n in direct)
	# LOCAL PATCH 2026-10-05: with External off its sites show unticked (nothing of theirs runs) but keep their own
	# settings; ticking External back re-ticks them (Select 'groups', windows/default_dialogs).
	sites_on = ['magneto.%s' % i for i in sites_enabled]
	direct_on = ['direct.%s' % k for k in direct_enabled]
	on = active + (sites_on if 'external' in active else []) + (direct_on if 'http_streams' in active else [])
	preselect = [scrapers.index(i) for i in on if i in scrapers]
	site_rows = [scrapers.index('magneto.%s' % i) for i in torrents]
	direct_rows = [scrapers.index('direct.%s' % k) for k, _n in direct]
	groups_kwarg = json.dumps([[scrapers.index('external'), site_rows, [scrapers.index(i) for i in sites_on]],
							   [scrapers.index('http_streams'), direct_rows, [scrapers.index(i) for i in direct_on]]])
	list_items = [{'line1': item, 'icon': icon} for item in scraper_names]
	kwargs = {'items': json.dumps(list_items), 'multi_choice': 'true', 'preselect': preselect, 'groups': groups_kwarg,
			  'heading': 'Anime Scrapers' if anime else 'Enable Scrapers'}
	choice = kodi_utils.select_dialog(scrapers, **kwargs)
	if choice is None: return
	# LOCAL PATCH 2026-10-01: External is the master switch of every torrent site under it (off = no torrent provider
	# runs). Ticking a site that was off turns External on, as Red Light does; unticking External itself is respected
	# when no site was newly ticked.
	if 'external' not in choice and any(('magneto.%s' % i) in choice and ('magneto.%s' % i) not in on for i in torrents):
		choice = list(choice) + ['external']
	# Direct Streams the same way: ticking one of its providers that was off turns it on
	if 'http_streams' not in choice and any(('direct.%s' % k) in choice and ('direct.%s' % k) not in on for k, _n in direct):
		choice = list(choice) + ['http_streams']
	for i in groups:
		set_setting('provider.%s' % i, ('true' if i in choice else 'false'))
		if i in cloud_scrapers and i in choice: set_setting(cloud_scrapers[i], 'true')
	if 'http_streams' in choice:   # with it off, its providers keep their settings for when it is ticked again
		for k, _n in direct:
			state = 'true' if 'direct.%s' % k in choice else 'false'
			if get_setting('deadlight.http_streams.%s' % k) != state: set_setting('http_streams.%s' % k, state)
	if 'external' not in choice: return   # the sites keep their settings for when External is ticked again
	if anime:
		ticked = [i for i in torrents if 'magneto.%s' % i in choice]
		# an empty anime list cannot be saved (anime_providers_choice refuses it too): it is kept as it was
		if ticked: save_anime_providers(ticked)
		elif 'external' in choice: kodi_utils.notification('Anime list kept: choose at least one anime provider')
		return
	for i in torrents:
		state = 'true' if 'magneto.%s' % i in choice else 'false'
		if get_setting('deadlight.magneto.provider.%s' % i) != state: set_setting('magneto.provider.%s' % i, state)

def results_sorting_choice(params):
	choices = [('Quality, Provider, Size', '0'), ('Quality, Size, Provider', '1'),
				('Provider, Quality, Size', '2'), ('Provider, Size, Quality', '3'),
				('Size, Quality, Provider', '4'), ('Size, Provider, Quality', '5')]
	choice = _pick([(i[0], i) for i in choices], narrow_window='true')
	if choice is None: return
	set_setting('results.sort_order_display', choice[0])
	set_setting('results.sort_order', choice[1])

def results_format_choice(params):
	choices = [('List', kodi_utils.get_icon('results_list', 'results')), ('Cards', kodi_utils.get_icon('results_row', 'results')),
				('WideList', kodi_utils.get_icon('results_widelist', 'results'))]
	choice = _pick([(i[0], i, i[1]) for i in choices], heading='Choose Results Format')
	if choice is None: return
	set_setting('results.list_format', choice[0])

def clear_favorites_choice(params):
	fl = [('Clear Movies Favorites', 'movie'), ('Clear TV Show Favorites', 'tvshow'), ('Clear People Favorites', 'people')]
	media_type = _pick(fl, narrow_window='true')
	if media_type == None: return
	if not kodi_utils.confirm_dialog(): return
	from caches.favorites_cache import favorites_cache
	favorites_cache.clear_favorites(media_type)
	kodi_utils.notification('Success', 3000)

def scraper_color_choice(params):
	setting = params.get('setting_id')
	current_setting, original_highlight = get_setting('deadlight.%s' % setting), default_setting_values(setting)['setting_default']
	if current_setting != original_highlight:
		action = kodi_utils.confirm_dialog(text='Set new Highlight or Restore Default Highlight?', ok_label='Set New', cancel_label='Restore Default', default_control=10)
		if action == None: return
		if not action: return set_setting(setting, original_highlight)
	chosen_color = color_choice({'current_setting': current_setting})
	if chosen_color: set_setting(setting, chosen_color)

def color_choice(params):
	from windows.base_window import open_window
	return open_window(('windows.color', 'SelectColor'), 'color.xml', current_setting=params.get('current_setting', None))

def mpaa_region_choice(params={}):
	from modules.meta_lists import regions as rg
	regions = rg()
	regions.sort(key=lambda x: x['name'])
	if _pick_setting(regions, 'mpaa_region', 'mpaa_region_display_name', value_key='id', heading='Set MPAA Region', narrow_window='true') == None: return None
	from caches.meta_cache import delete_meta_cache
	delete_meta_cache(silent=True)

def lists_cache_duration_choice(params={}):
	durations = [{'name': '6 hours', 'duration': '6'}, {'name': '12 hours', 'duration': '12'}, {'name': '18 hours', 'duration': '18'}, {'name': '1 Day', 'duration': '24'},
				{'name': '2 Days', 'duration': '48'}, {'name': '3 Days', 'duration': '72'}, {'name': '4 Days', 'duration': '96'}, {'name': '5 Days', 'duration': '120'},
				{'name': '6 Days', 'duration': '144'}, {'name': '7 Days', 'duration': '168'}]
	_pick_setting(durations, 'lists_cache_duraton', 'lists_cache_duraton_display_name', value_key='duration', heading='Set Generic List Cache Duration',
					narrow_window='true')

def options_menu_choice(params, meta=None):
	from caches.episode_groups_cache import episode_groups_cache
	from modules.utils import get_datetime
	from modules import metadata
	params_get = params.get
	tmdb_id, content, poster = params_get('tmdb_id', None), params_get('content', None), params_get('poster', None)
	is_external, from_extras = params_get('is_external') in (True, 'True', 'true'), params_get('from_extras', 'false') == 'true'
	season, episode = params_get('season', ''), params_get('episode', '')
	single_ep_list = ('episode.progress', 'episode.recently_watched', 'episode.next_trakt', 'episode.next_deadlight', 'episode.trakt_recently_aired', 'episode.trakt_calendar')
	if not content: content = kodi_utils.container_content()[:-1]
	menu_type = content
	if content.startswith('episode.'): content = 'episode'
	if not meta:
		function = metadata.movie_meta if content == 'movie' else metadata.tvshow_meta
		meta = function('tmdb_id', tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
	meta_get = meta.get
	rootname, title, imdb_id, tvdb_id = meta_get('rootname', None), meta_get('title'), meta_get('imdb_id', None), meta_get('tvdb_id', None)
	window_function = kodi_utils.activate_window if is_external else kodi_utils.container_update
	listing = []
	listing_append = listing.append
	if from_extras:
		if menu_type in ('movie', 'episode'): listing_append(('Playback Options', 'Scrapers Options', 'playback_choice'))
		if settings.trakt_user_active(): listing_append(('Trakt Lists Manager', '', 'trakt_manager'))
		# LOCAL PATCH 2026-07-23: MDBList Manager entry mirrors Trakt Manager.
		if settings.mdblist_user_active(): listing_append(('MDBList Manager', '', 'mdblist_manager'))
		# LOCAL PATCH 2026-07-29: SIMKL Manager entry.
		if settings.simkl_user_active(): listing_append(('SIMKL Manager', '', 'simkl_manager'))
		listing_append(('Personal Lists Manager', '', 'personallists_manager_choice'))
		listing_append(('TMDb Lists Manager', '', 'tmdblists_manager_choice'))
		listing_append(('Favorites Manager', '', 'favorites_manager_choice'))
	if menu_type == 'tvshow': listing_append(('Play Random', 'Based On %s' % rootname, 'random'))
	if menu_type in ('tvshow', 'season'):
		listing_append(('Assign an Episode Group to %s' % rootname, 'Currently %s' % episode_groups_cache.get(tmdb_id).get('name', 'None'), 'episode_group'))
	if menu_type in ('movie', 'episode') or menu_type in single_ep_list:
		base_str1, base_str2, on_str, off_str = '%s%s', 'Currently: [B]%s[/B]', 'On', 'Off'
		if settings.auto_play(content): autoplay_status, autoplay_toggle, quality_setting = on_str, 'false', 'autoplay_quality_%s' % content
		else: autoplay_status, autoplay_toggle, quality_setting = off_str, 'true', 'results_quality_%s' % content
		set_active = settings.active_internal_scrapers()
		active_int_scrapers = [i.replace('_', '') for i in set_active]
		current_scrapers_status = ', '.join([i for i in active_int_scrapers]) if len(active_int_scrapers) > 0 else 'N/A'
		# LOCAL PATCH 2026-10-01: how many torrent providers are on, since they are listed one by one now
		# LOCAL PATCH 2026-10-05: counted for this item -- the anime list on anime, the Movies & TV switches otherwise
		from modules.metadata import is_anime_meta
		anime_item = is_anime_meta(meta)
		if 'external' in set_active: current_scrapers_status += '  |  %d %s sites' % (len(enabled_torrent_scrapers(anime_item)), 'anime' if anime_item else 'torrent')
		current_quality_status =  ', '.join(settings.quality_filter(quality_setting))
		listing_append((base_str1 % ('Auto Play', ' (%s)' % content), base_str2 % autoplay_status, 'toggle_autoplay'))
		# LOCAL PATCH 2026-10-08: one Next Episode choice (Off / Show Sources / Play Automatically) for the two toggles. Only
		# with Auto Play off, as both modes are off while it is on (settings.autoplay_next_episode / autoscrape_next_episode).
		if (menu_type == 'episode' or menu_type in single_ep_list) and autoplay_status == off_str:
			next_mode_options = default_setting_values('next_episode_mode')['settings_options']
			listing_append((base_str1 % ('Next Episode', ''), base_str2 % next_mode_options.get(settings.next_episode_mode(), 'Off'), 'next_episode_mode'))
		listing_append((base_str1 % ('Quality Limit', ' (%s)' % content), base_str2 % current_quality_status, 'set_quality'))
		listing_append((base_str1 % ('', 'Anime Scrapers' if anime_item else 'Enable Scrapers'), base_str2 % current_scrapers_status, 'enable_scrapers'))
		if menu_type == 'episode' or menu_type in single_ep_list:
			listing_append(('Assign an Episode Group to %s' % rootname, base_str2 % episode_groups_cache.get(tmdb_id).get('name', 'None'), 'episode_group'))
	if not from_extras:
		if menu_type in ('movie', 'tvshow'):
			listing_append(('Re-Cache %s Info' % ('Movies' if menu_type == 'movie' else 'TV Shows'), 'Clear %s Cache' % rootname, 'clear_media_cache'))
		if menu_type in ('movie', 'episode') or menu_type in single_ep_list: listing_append(('Clear Scrapers Cache', '', 'clear_scrapers_cache'))
		if menu_type in ('tvshow', 'season', 'episode'): listing_append(('TV Shows Progress Manager', '', 'nextep_manager'))
		listing_append(('Open Download Manager', '', 'open_download_manager'))
		listing_append(('Open Tools', '', 'open_tools'))
		if menu_type in ('movie', 'episode') or menu_type in single_ep_list: listing_append(('Open External Scraper Settings', '', 'open_external_scraper_settings'))
		listing_append(('Open Settings', '', 'open_settings'))
	list_items = [{'line1': item[0], 'line2': item[1] or item[0], 'icon': poster} for item in listing]
	heading = rootname or 'Options...'
	kwargs = {'items': json.dumps(list_items), 'heading': heading, 'multi_line': 'true'}
	choice = kodi_utils.select_dialog([i[2] for i in listing], **kwargs)
	if choice == None: return
	if choice == 'clear_media_cache':
		from caches.base_cache import refresh_cached_data
		kodi_utils.close_all_dialog()
		return refresh_cached_data(meta)
	if choice == 'clear_scrapers_cache':
		from modules.source_utils import clear_scrapers_cache
		return clear_scrapers_cache()
	if choice == 'open_download_manager':
		from modules.downloader import manager
		kodi_utils.close_all_dialog()
		return manager()
	if choice == 'open_tools':
		kodi_utils.close_all_dialog()
		return window_function({'mode': 'navigator.tools'})
	if choice == 'open_settings':
		kodi_utils.close_all_dialog()
		return kodi_utils.open_settings()
	if choice == 'open_external_scraper_settings':
		kodi_utils.close_all_dialog()
		return kodi_utils.external_scraper_settings()
	if choice == 'playback_choice':
		return playback_choice({'media_type': content, 'poster': poster, 'meta': meta, 'season': season, 'episode': episode})
	if choice == 'nextep_manager':
		return window_function({'mode': 'build_next_episode_manager'})
	if choice == 'random':
		kodi_utils.close_all_dialog()
		return random_choice({'meta': meta, 'poster': poster})
	if choice == 'trakt_manager':
		return trakt_manager_choice({'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id or 'None', 'media_type': content, 'icon': poster})
	# LOCAL PATCH 2026-07-23: MDBList Manager dispatch.
	if choice == 'mdblist_manager':
		return mdblist_manager_choice({'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id or 'None', 'media_type': content, 'icon': poster})
	# LOCAL PATCH 2026-07-29: SIMKL Manager dispatch.
	if choice == 'simkl_manager':
		return simkl_manager_choice({'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'media_type': content, 'icon': poster})
	if choice == 'personallists_manager_choice':
		from modules.utils import get_current_timestamp
		return personallists_manager_choice({'list_type': content, 'tmdb_id': tmdb_id, 'title': title,
							'premiered': meta_get('premiered'), 'current_time': get_current_timestamp(), 'icon': poster})
	if choice == 'favorites_manager_choice':
		return favorites_manager_choice({'media_type': content if content in ('movie', 'tvshow') else 'tvshow', 'tmdb_id': tmdb_id, 'title': title})
	if choice == 'tmdblists_manager_choice':
		return tmdblists_manager_choice({'media_type': content if content in ('movie', 'movies') else 'tv', 'tmdb_id': tmdb_id, 'icon': poster})
	if choice == 'toggle_autoplay':
		set_setting('auto_play_%s' % content, autoplay_toggle)
	elif choice == 'next_episode_mode':
		keys = sorted(next_mode_options)
		picked = kodi_utils.kodi_dialog().select('Next Episode', [next_mode_options[k] for k in keys], preselect=keys.index(settings.next_episode_mode()) if settings.next_episode_mode() in keys else 0)
		if picked >= 0: set_setting('next_episode_mode', keys[picked])
	elif choice == 'set_quality':
		set_quality_choice({'setting_id': 'autoplay_quality_%s' % content if autoplay_status == on_str else 'results_quality_%s' % content, 'icon': poster})
	elif choice == 'enable_scrapers':
		enable_scrapers_choice({'icon': poster, 'anime': anime_item})
	elif choice == 'episode_group':
		assign_episode_group_choice({'meta': meta, 'poster': poster})
	options_menu_choice(params, meta=meta)

def extras_menu_choice(params):
	from windows.base_window import open_window
	from modules.utils import get_datetime
	from modules import metadata
	stacked = params.get('stacked', 'false') == 'true'
	if not stacked: kodi_utils.show_busy_dialog()
	media_type = params['media_type']
	function = metadata.movie_meta if media_type == 'movie' else metadata.tvshow_meta
	meta = function('tmdb_id', params['tmdb_id'], settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
	if not stacked: kodi_utils.hide_busy_dialog()
	open_window(('windows.extras', 'Extras'), 'extras.xml', meta=meta, is_external=params.get('is_external', 'true' if kodi_utils.external() else 'false'),
															options_media_type=media_type, starting_position=params.get('starting_position', None),
															season=params.get('season', None))

def open_movieset_choice(params):
	kodi_utils.hide_busy_dialog()
	window_function = kodi_utils.activate_window if params['is_external'] in (True, 'True', 'true') else kodi_utils.container_update
	return window_function({'mode': 'build_movie_list', 'action': 'tmdb_movies_sets', 'key_id': params['key_id'], 'name': params['name']})

def _lead_cast(meta, limit=10):
	"""LOCAL PATCH 2026-11-07 (Red Light 2.9.9, #288): the first `limit` cast names for Extra Info, '' when there are none.
	Never raises -- media_extra_info_choice builds every line inside one try, so one bad field would empty the dialog."""
	try: return ', '.join(n for n in ((c.get('name') if isinstance(c, dict) else str(c)) for c in (meta.get('cast') or [])[:limit]) if n)
	except Exception: return ''

def media_extra_info_choice(params):
	from modules.utils import adjust_premiered_date
	from modules.source_utils import get_aliases_titles, make_alias_dict
	media_type, meta = params.get('media_type'), params.get('meta')
	extra_info, listings = meta.get('extra_info', None), []
	append = listings.append
	try:
		if media_type == 'movie':
			if meta['tagline']: append('[B]Tagline:[/B] %s' % meta['tagline'])
			aliases = get_aliases_titles(make_alias_dict(meta, meta['title']))
			if aliases: append('[B]Aliases:[/B] %s' % ', '.join(aliases))
			append('[B]Status:[/B] %s' % extra_info['status'])
			append('[B]Premiered:[/B] %s' % meta['premiered'])
			append('[B]Rating:[/B] %s (%s Votes)' % (str(round(meta['rating'], 1)), meta['votes']))
			append('[B]Runtime:[/B] %s mins' % int(float(meta['duration'])/60))
			append('[B]Genre/s:[/B] %s' % ', '.join(_display_genres(meta)))
			append('[B]Budget:[/B] %s' % extra_info['budget'])
			append('[B]Revenue:[/B] %s' % extra_info['revenue'])
			append('[B]Director:[/B] %s' % ', '.join(meta['director']))
			append('[B]Writer/s:[/B] %s' % ', '.join(meta['writer']) or 'N/A')
			if _lead_cast(meta): append('[B]Cast:[/B] %s' % _lead_cast(meta))   # LOCAL PATCH 2026-11-07 (Red Light 2.9.9, #288)
			append('[B]Studio:[/B] %s' % ', '.join(meta['studio']) or 'N/A')
			if extra_info['collection_name']: append('[B]Collection:[/B] %s' % extra_info['collection_name'])
			append('[B]Homepage:[/B] %s' % extra_info['homepage'])
		else:
			append('[B]Type:[/B] %s' % extra_info['type'])
			if meta['tagline']: append('[B]Tagline:[/B] %s' % meta['tagline'])
			aliases = get_aliases_titles(make_alias_dict(meta, meta['title']))
			if aliases: append('[B]Aliases:[/B] %s' % ', '.join(aliases))
			append('[B]Status:[/B] %s' % extra_info['status'])
			append('[B]Premiered:[/B] %s' % meta['premiered'])
			append('[B]Rating:[/B] %s (%s Votes)' % (str(round(meta['rating'], 1)), meta['votes']))
			append('[B]Runtime:[/B] %d mins' % int(float(meta['duration'])/60))
			append('[B]Classification:[/B] %s' % meta['mpaa'])
			append('[B]Genre/s:[/B] %s' % ', '.join(_display_genres(meta)))
			append('[B]Networks:[/B] %s' % ', '.join(meta['studio']))
			append('[B]Created By:[/B] %s' % extra_info['created_by'])
			if _lead_cast(meta): append('[B]Cast:[/B] %s' % _lead_cast(meta))   # LOCAL PATCH 2026-11-07 (Red Light 2.9.9, #288)
			# LOCAL PATCH 2026-11-08: the Extras window passes its own ep_label and season count, so an anime reads as it aired
			# (like its Details panel); anywhere else TMDb's SxxEyy
			ep_label = params.get('ep_label') or (lambda season, episode: 'S%.2dE%.2d' % (int(season), int(episode)))
			for key, title in (('last_episode_to_air', 'Last Aired'), ('next_episode_to_air', 'Next Aired')):
				try:
					ep = extra_info[key]
					append('[B]%s:[/B] %s - [B]%s[/B] - %s' % (title, adjust_premiered_date(ep['air_date'], settings.date_offset())[0].strftime('%d %B %Y'),
						ep_label(ep['season_number'], ep['episode_number']), ep['name']))
				except: pass
			append('[B]Seasons:[/B] %s' % (params.get('seasons') or meta['total_seasons']))
			append('[B]Episodes:[/B] %s' % meta['total_aired_eps'])
			append('[B]Homepage:[/B] %s' % extra_info['homepage'])
	except: return kodi_utils.notification('Error', 2000)
	return '[CR][CR]'.join(listings)

def discover_choice(params):
	from windows.base_window import open_window
	open_window(('windows.discover', 'Discover'), 'discover.xml', media_type=params['media_type'])

def clear_all_sticky_sources_choice(params=None):
	# LOCAL PATCH: wipe ALL SmartPlay sticky sources (every show).
	# Wired into the Settings → SmartPlay → "Clear All" button.
	from modules import smartplay_utils
	total = smartplay_utils.count()
	if not total:
		return kodi_utils.notification('No SmartPlay stickies stored', 2500)
	if not kodi_utils.confirm_dialog(heading='Clear ALL SmartPlay Stickies',
			text='Forget saved sources for ALL %d titles? This cannot be undone.' % total):
		return
	if smartplay_utils.clear_all():
		kodi_utils.notification('All %d SmartPlay stickies cleared' % total, 3000)
	else:
		kodi_utils.notification('Failed to clear stickies', 2500)


# LOCAL PATCH 2026-08-29: AniList list manager. A TMDb show maps to ONE Trakt/SIMKL entry but to N AniList entries,
# one per cour, so the entry has to be pinned before anything can be written:
#   from an EPISODE row  -> season+episode are known, find_cour_by_tmdb_coords is exact
#   from a MOVIE row     -> one entry, anilist_for_tmdb_movie
#   from a SHOW row      -> ambiguous; one cour is used silently, several open a picker
# Season 0 rows are dropped first: OVA/special entries are a dead end (one can sort ahead of season 1).
# LOCAL PATCH 2026-11-01: the context menu's Watch Order opens a window (windows/watch_order.py) instead of a folder.
# A *_choice mode, so busy_guard shows the spinner while the steps load and steps aside for the window.
def watch_order_choice(params):
	from indexers.anilist_lists import watch_order_rows, next_step_index
	from windows.base_window import open_window
	_seed, rows = watch_order_rows(params)
	if not rows: return
	try: start = next_step_index(rows) or 0
	except Exception: start = 0
	return open_window(('windows.watch_order', 'WatchOrder'), 'watch_order.xml', rows=rows, heading=params.get('title') or '',
		start_index=start if 0 <= start < len(rows) else 0, manager_enabled=settings.anilist_user_active() or settings.mal_user_active(),
		# the context menu passes the list's is_external, a bool built into the url as 'True' / 'False'
		is_external='true' if str(params.get('is_external') or kodi_utils.external()).lower() == 'true' else 'false')

def anilist_manager_choice(params):
	# LOCAL PATCH 2026-10-02: the Anime List Manager -- one entry, written to AniList AND MyAnimeList (whichever are
	# signed in), so the two lists cannot disagree. Both ids come from the same Fribb row. Mode name and context-menu key
	# stay 'anilist_manager', so saved context-menu orders keep working.
	from apis import anilist_api, mal_api
	from caches import fribb_mappings
	al_on, mal_on = settings.anilist_user_active(), settings.mal_user_active()
	if not (al_on or mal_on): return kodi_utils.notification('No Active AniList or MyAnimeList Account', 3500)
	tmdb_id, media_type = params.get('tmdb_id'), params.get('media_type', 'tvshow')
	title = params.get('title') or 'this title'
	icon = params.get('icon', None) or kodi_utils.get_icon('lists')
	season, episode = params.get('season'), params.get('episode')

	anilist_id, mal_id, entry_label = None, None, title
	# LOCAL PATCH 2026-11-01: the Watch Order window names the exact entry (its AniList / MAL ids) -- no TMDb lookup or picker
	if params.get('anilist_id') or params.get('mal_id'):
		anilist_id, mal_id = params.get('anilist_id') or None, params.get('mal_id') or None
	elif media_type == 'movie':
		ids = fribb_mappings.anime_ids_for_tmdb_movie(tmdb_id)
		anilist_id, mal_id = ids.get('anilist'), ids.get('mal')
	elif season and episode:
		try:
			cour = fribb_mappings.find_cour_by_tmdb_coords(int(tmdb_id), int(season), int(episode)) or {}
			anilist_id, mal_id = cour.get('anilist'), cour.get('mal')
		except (TypeError, ValueError): pass
	if not (anilist_id or mal_id) and media_type != 'movie':
		rows = [r for r in (fribb_mappings.tmdb_tv_to_fribb_rows(tmdb_id) or []) if r.get('anilist_id') or r.get('mal_id')]
		main = [r for r in rows if ((r.get('season') or {}).get('tmdb') or 0) > 0]
		rows = main or rows
		rows.sort(key=lambda r: (((r.get('season') or {}).get('tmdb') or 0),
								((r.get('episode_offset') or {}).get('tmdb') or 0)))
		pick = 0 if len(rows) == 1 else None
		if len(rows) > 1:
			# Label the picker with romaji titles -- "Season 2 Part 2" distinguishes cours, the TMDb season number does not.
			# One bulk request, cached.
			# LOCAL PATCH 2026-10-03: named by the AniList id that gets written, MAL id only as the fallback -- one MAL id can be
			# several AniList entries.
			names, al_names = {}, {}
			try: al_names = anilist_api.anilist_romaji_by_ids([r.get('anilist_id') for r in rows if r.get('anilist_id')]) or {}
			except Exception: al_names = {}
			if any(not al_names.get(r.get('anilist_id')) for r in rows):
				try: names = anilist_api.anilist_media_bulk([r.get('mal_id') for r in rows if r.get('mal_id')]) or {}
				except Exception: names = {}
			labels = [al_names.get(r.get('anilist_id')) or (names.get(r.get('mal_id')) or {}).get('title') or '%s - cour %d' % (title, idx)
					  for idx, r in enumerate(rows, 1)]
			pick = kodi_utils.select_dialog(list(range(len(rows))),
					items=json.dumps([{'line1': l, 'icon': icon} for l in labels]), heading='Anime List: which entry?')
			if pick is None: return
			entry_label = labels[pick]
		if pick is not None:
			anilist_id, mal_id = rows[pick].get('anilist_id'), rows[pick].get('mal_id')
	targets = [(n, i) for n, i, on in (('AniList', anilist_id, al_on), ('MAL', mal_id, mal_on)) if on and i]
	if not targets:
		return kodi_utils.ok_dialog('Anime List Manager', 'No AniList or MyAnimeList entry found for [B]%s[/B].' % title)

	# Where it sits now on each list. One request per service.
	al_now, mal_now = {}, {}
	if al_on and anilist_id:
		try: al_now = (anilist_api.anilist_media_list_all() or {}).get(int(anilist_id)) or {}
		except Exception: al_now = {}
	if mal_on and mal_id:
		try: mal_now = mal_api.mal_list_status(mal_id) or {}
		except Exception: mal_now = {}
	# (label, AniList status, MAL status, MAL rewatching)
	statuses = [('Watching', 'CURRENT', 'watching', False), ('Plan to Watch', 'PLANNING', 'plan_to_watch', False),
				('Completed', 'COMPLETED', 'completed', False), ('On Hold', 'PAUSED', 'on_hold', False),
				('Dropped', 'DROPPED', 'dropped', False), ('Rewatching', 'REPEATING', 'completed', True)]
	# LOCAL PATCH 2026-10-03: each list marks its OWN status row -- a heading carrying both was cut at ~68 characters,
	# and a shared '(current)' needed both lists to agree.
	al_listed, mal_listed = bool(al_on and anilist_id and al_now.get('status')), bool(mal_on and mal_id and mal_now.get('status'))
	def _marks(al_status, mal_status, rew):
		al_hit = al_listed and al_now.get('status') == al_status
		mal_hit = mal_listed and mal_now.get('status') == mal_status and bool(mal_now.get('is_rewatching')) == rew
		on = []
		if al_hit: on.append('AniList ep %s' % (al_now.get('progress') or 0))
		if mal_hit: on.append('MAL ep %s' % (mal_now.get('num_episodes_watched') or 0))
		return '  [COLOR limegreen](%s)[/COLOR]' % ', '.join(on) if on else ''
	choices, values = [], []
	for label, al_status, mal_status, rew in statuses:
		choices.append('Set to [B]%s[/B]%s' % (label, _marks(al_status, mal_status, rew))); values.append((al_status, mal_status, rew))
	choices.append('[B]Set Score...[/B]'); values.append('score')
	if al_now or mal_now: choices.append('Remove from List'); values.append('delete')

	# Only what no row can show: a signed-in list that does not hold this entry.
	missing = [n for n, here, listed in (('AniList', al_on and anilist_id, al_listed), ('MAL', mal_on and mal_id, mal_listed)) if here and not listed]
	heading = entry_label[:64] +(' (not on %s)' % ' / '.join(missing) if missing else '')
	choice = kodi_utils.select_dialog(values, items=json.dumps([{'line1': c, 'icon': icon} for c in choices]), heading=heading)
	if choice is None: return

	results = []
	if choice == 'score':
		scores = ['Remove Rating'] + ['%d' % i for i in range(1, 11)]
		si = kodi_utils.select_dialog(list(range(len(scores))),
				items=json.dumps([{'line1': s, 'icon': icon} for s in scores]), heading='Anime List Score')
		if si is None: return
		if al_on and anilist_id: results.append(('AniList', anilist_api.anilist_set_score(anilist_id, si)))
		if mal_on and mal_id: results.append(('MAL', mal_api.mal_set_score(mal_id, si)))
		done = 'score %s' % ('removed' if si == 0 else si)
	elif choice == 'delete':
		if al_now.get('entry_id'): results.append(('AniList', anilist_api.anilist_delete_entry(al_now['entry_id'])))
		if mal_now: results.append(('MAL', mal_api.mal_delete_entry(mal_id)))
		done = 'removed'
	else:
		al_status, mal_status, rew = choice
		if al_on and anilist_id: results.append(('AniList', anilist_api.anilist_set_status(anilist_id, al_status)))
		if mal_on and mal_id: results.append(('MAL', mal_api.mal_set_status(mal_id, mal_status, rewatching=rew)))
		done = next(label for label, a, m, r in statuses if (a, m, r) == choice)
	failed = [n for n, ok in results if not ok]
	if not results: return kodi_utils.notification('Nothing to change', 3000)
	# LOCAL PATCH 2026-11-01: reload what shows the lists. The writes clear the AniList / MAL list caches but nothing
	# asked Kodi to rebuild, so a removed or moved show stayed in its widget. Trakt's manager does the same.
	if len(failed) < len(results): kodi_utils.refresh('anilist.list.', 'mal.list.', screen='if_listed')
	if failed: return kodi_utils.notification('%s: %s failed' % (done, ' and '.join(failed)), 4000)
	return kodi_utils.notification('%s: %s' % (' + '.join(n for n, _ok in results), done), 3000)

# LOCAL PATCH 2026-10-09: settings backup and reset (modules.settings_backup), reached from Settings > General
def export_settings_choice(params):
	from modules.settings_backup import export_settings
	return export_settings(params)

def import_settings_choice(params):
	from modules.settings_backup import import_settings
	return import_settings(params)

def reset_settings_choice(params):
	from modules.settings_backup import reset_settings
	return reset_settings(params)

# LOCAL PATCH 2026-10-09: rows that replace several settings rows (settings audit merges). Each writes the original settings,
# so everything that reads them is unchanged; settings_cache.publish_setting_displays shows the combined value.
def provider_priority_choice(params={}):
	"""Provider Priority: put the eight providers in order -- pick a position, then the provider for it -- and they are
	numbered 1..8 into rd.priority, pm.priority ... (lower plays first). Replaces the eight per-provider Priority rows."""
	from caches.settings_cache import priority_order
	order = list(priority_order())
	changed = False
	while True:
		choices = [{'line1': 'Position %d' % (n + 1), 'line2': '[B]%s[/B]%s' % (row[2], '' if get_setting('deadlight.%s' % row[1], 'false') == 'true' else '  (off)'),
					'position': n} for n, row in enumerate(order)]
		kwargs = {'items': json.dumps(choices), 'heading': 'Provider Priority (top plays first)', 'multi_line': 'true', 'narrow_window': 'true'}
		choice = kodi_utils.select_dialog(choices, **kwargs)
		if choice is None: break
		position = choice['position']
		others = [row for n, row in enumerate(order) if n != position]
		picked = _pick([(row[2], row) for row in others], narrow_window='true', heading='Provider for Position %d' % (position + 1))
		if picked is None: continue
		order.remove(picked); order.insert(position, picked); changed = True
	if changed:
		for n, row in enumerate(order): set_setting(row[0], str(n + 1))

def undesirables_manage_choice(params={}):
	"""Manage Undesirables: magneto's four undesirables editors from one row."""
	actions = [('Enable/Disable Default Undesirables', 'select'), ('Add Your Own Undesirables', 'input'),
			   ('Remove Some of Your Undesirables', 'remove'), ('Remove All of Your Undesirables', 'remove_all')]
	action = _pick(actions, heading='Manage Undesirables', narrow_window='true')
	if action: magneto_undesirables_choice({'action': action})

def extra_ratings_setup_choice(params={}):
	"""Extra Ratings: one list for 'Enable Extra Ratings' + 'Enabled Ratings'; ticking none turns them off."""
	choices = [('Metacritic', 'Meta', 'metacritic.png'), ('Tomato Rating Critic', 'Tom/Critic', 'rtcertified.png'),
			   ('Tomato Rating User', 'Tom/User', 'popcorn.png'), ('IMDb', 'IMDb', 'imdb.png'), ('TMDb', 'TMDb', 'tmdb.png'),
			   ('AniList (anime)', 'AniList', 'anilist.png'), ('MyAnimeList (anime)', 'MAL', 'mal.png')]   # LOCAL PATCH 2026-11-07
	enabled = get_setting('deadlight.extras.enable_extra_ratings', 'true') == 'true'
	current = settings.extras_enabled_ratings() if enabled else []
	preselect = [n for n, c in enumerate(choices) if c[1] in current]
	selection = _pick([(c[0], c, 'deadlight_flags/ratings/%s' % c[2]) for c in choices], heading='Extra Ratings (none = off)', multi_choice='true', preselect=preselect)
	if selection is None: return
	if selection: set_setting('extras.enabled_ratings', ', '.join(c[1] for c in selection))
	set_setting('extras.enable_extra_ratings', 'true' if selection else 'false')

def rpdb_targets_choice(params={}):
	"""Use RPDb Posters For...: Movies / TV Shows / Extras Lists in one list, written to rpdb_enabled and
	extras.enable_item_ratings."""
	options = ['Movies', 'TV Shows', 'Extras Lists']
	rpdb = get_setting('deadlight.rpdb_enabled', '0')
	current = {'1': ['Movies'], '2': ['TV Shows'], '3': ['Movies', 'TV Shows']}.get(rpdb, [])
	if get_setting('deadlight.extras.enable_item_ratings', 'false') == 'true': current.append('Extras Lists')
	selection = _pick([(o, o) for o in options], heading='Use RPDb Posters For...', multi_choice='true', narrow_window='true',
					preselect=[n for n, o in enumerate(options) if o in current])
	if selection is None: return
	value = {(False, False): '0', (True, False): '1', (False, True): '2', (True, True): '3'}[('Movies' in selection, 'TV Shows' in selection)]
	set_setting('rpdb_enabled', value)
	set_setting('extras.enable_item_ratings', 'true' if 'Extras Lists' in selection else 'false')

def size_sorting_choice(params={}):
	"""Size Sorting: direction and HEVC weighting together (results.size_sort_direction + results.size_sort_weighted)."""
	choices = [('Largest First', '0', 'false'), ('Largest First, HEVC Counts Double', '0', 'true'),
			   ('Smallest First', '1', 'false'), ('Smallest First, HEVC Counts Double', '1', 'true')]
	choice = _pick([(c[0], c) for c in choices], heading='Size Sorting', narrow_window='true')
	if choice is None: return
	set_setting('results.size_sort_direction', choice[1])
	set_setting('results.size_sort_weighted', choice[2])
