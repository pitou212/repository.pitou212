# -*- coding: utf-8 -*-
from caches.base_cache import connect_database, get_timestamp

# LOCAL PATCH 2026-09-05:
# 1. get_many filters expiry PER ROW and removes only the expired subset -- row [0] (lowest hash) says nothing about
#    the rest of the batch.
# 2. No dbcon.close(): base_cache.connect_database caches the connection PER THREAD and hands it back next time
#    (never pinging it), so a close breaks the next call in that thread. The pool owns the connection's lifetime.

# LOCAL PATCH 2026-10-02: IN-lists in chunks. Kodi 21 on Windows ships SQLite 3.30.1, whose limit is 999 bound parameters
# a statement (3.32 raised it to 32766); over it the bare except below would read every hash as unknown. 900 leaves room
# for the debrid parameter.
def _chunks(items, size=900):
	for n in range(0, len(items), size): yield items[n:n + size]


# LOCAL PATCH 2026-10-02: each wipe of the table logs the call chain that asked for it.
def _log_wipe(what):
	try:
		import os, traceback
		from modules.kodi_utils import logger_debug as logger   # LOCAL PATCH 2026-10-25 (4.0.5): DEBUG level, a routine event
		chain = ' <- '.join('%s:%d %s' % (os.path.basename(f.filename), f.lineno, f.name) for f in traceback.extract_stack()[-7:-2])
		logger('debrid cache wiped', '%s, from %s' % (what, chain))
	except Exception: pass

class DebridCache:
	# LOCAL PATCH 2026-09-22: give a database created before the `files` column existed one -- table_creators only
	# runs CREATE TABLE IF NOT EXISTS. One PRAGMA per process. check_databases_integrity counts TABLES, not columns,
	# so the added column cannot make it judge the database corrupt.
	_files_column = None

	def _ensure_files_column(self, dbcon):
		if DebridCache._files_column is not None: return DebridCache._files_column
		ok = False
		try:
			cols = [i[1] for i in dbcon.execute('PRAGMA table_info(debrid_data)')]
			if 'files' in cols: ok = True
			elif cols:
				dbcon.execute('ALTER TABLE debrid_data ADD COLUMN files text')
				ok = True
			# empty cols means the table itself is missing -- leave that to make_databases
		except Exception: ok = False
		DebridCache._files_column = ok
		return ok

	def get_files_many(self, hash_list, debrid):
		"""{hash: files JSON} for hashes whose listing is recorded and still live.

		Read back separately rather than returned from the check so that a hash answered from
		the local cache -- the common case on a re-scrape, since only unchecked hashes are sent
		to the service -- yields the same listing as one just fetched."""
		out = {}
		if not hash_list: return out
		try:
			dbcon = connect_database('debridcache_db')
			if not self._ensure_files_column(dbcon): return out
			current_time = get_timestamp()
			rows = []
			for chunk in _chunks(list(hash_list)):
				rows.extend(dbcon.execute(
					'SELECT hash, files, expires FROM debrid_data WHERE debrid=? AND files IS NOT NULL AND hash in (%s)'
					% (', '.join('?' for _ in chunk)), [debrid] + chunk).fetchall())
			for h, f, exp in rows:
				if f and exp > current_time: out[h] = f
		except: pass
		return out

	def get_many(self, hash_list):
		result = None
		try:
			dbcon = connect_database('debridcache_db')
			current_time = get_timestamp()
			cache_data = []
			for chunk in _chunks(list(hash_list)):
				cache_data.extend(dbcon.execute('SELECT * FROM debrid_data WHERE hash in (%s)' % (', '.join('?' for _ in chunk)), chunk).fetchall())
			if cache_data:
				live = [i for i in cache_data if i[3] > current_time]
				expired = [i for i in cache_data if i[3] <= current_time]
				if expired: self.remove_many(expired)
				result = live or None
		except: pass
		return result

	def set_many(self, hash_list, debrid, expires=24):
		try:
			dbcon = connect_database('debridcache_db')
			expires = get_timestamp(expires)
			# LOCAL PATCH 2026-09-22: an entry may carry a THIRD member, the JSON file listing (RD_check and PM_check pass
			# plain pairs). Explicit column list: the table has five columns.
			# LOCAL PATCH 2026-10-02: OR REPLACE -- the table is unique (hash, debrid), and one existing row would fail a
			# plain INSERT's WHOLE batch, silently.
			if self._ensure_files_column(dbcon):
				insert_list = [(i[0], debrid, i[1], expires, (i[2] if len(i) > 2 else None)) for i in hash_list]
				dbcon.executemany('INSERT OR REPLACE INTO debrid_data (hash, debrid, cached, expires, files) VALUES (?, ?, ?, ?, ?)', insert_list)
			else:
				insert_list = [(i[0], debrid, i[1], expires) for i in hash_list]
				dbcon.executemany('INSERT OR REPLACE INTO debrid_data (hash, debrid, cached, expires) VALUES (?, ?, ?, ?)', insert_list)
		except: pass

	def remove_many(self, old_cached_data):
		# LOCAL PATCH 2026-09-05: delete by (hash, debrid), not hash alone -- one hash can hold a row per
		# service, and pruning one service's expired verdict must not take another's live one.
		try:
			dbcon = connect_database('debridcache_db')
			old_cached_data = [(str(i[0]), str(i[1])) for i in old_cached_data]
			dbcon.executemany('DELETE FROM debrid_data WHERE hash=? AND debrid=?', old_cached_data)
		except: pass

	def clear_debrid_results(self, debrid):
		_log_wipe(debrid)
		try:
			dbcon = connect_database('debridcache_db')
			dbcon.execute('DELETE FROM debrid_data WHERE debrid=?', (debrid,))
			dbcon.execute('VACUUM')
			return True
		except: return False
	
	def clear_cache(self):
		_log_wipe('all debrids')
		try:
			dbcon = connect_database('debridcache_db')
			dbcon.execute('DELETE FROM debrid_data')
			dbcon.execute('VACUUM')
			return True
		except: return False

	def clean_database(self):
		try:
			dbcon = connect_database('debridcache_db')
			dbcon.execute('DELETE from debrid_data WHERE CAST(expires AS INT) <= ?', (get_timestamp(),))
			dbcon.execute('VACUUM')
			return True
		except: return False

debrid_cache = DebridCache()


def clear_account_cache(debrid, patterns, clear_hashes=True):
	"""LOCAL PATCH 2026-11-01 (cleanup): shared body of the four debrid APIs' clear_cache methods. Deletes the
	maincache rows matching each LIKE pattern (account listings), then, with clear_hashes, this debrid's cached-hash rows.
	False only when the maincache delete failed (clear_debrid_results' result was never part of it)."""
	ok = True
	try:
		dbcon = connect_database('maincache_db')
		for pattern in patterns: dbcon.execute('DELETE FROM maincache WHERE id LIKE ?', (pattern,))
	except: ok = False
	if clear_hashes: debrid_cache.clear_debrid_results(debrid)
	return ok