# -*- coding: utf-8 -*-
import sys
import time
from modules import kodi_utils, settings, watched_status as ws
from modules.anime_filler import mark as _filler_mark, skip_ahead as _filler_skip   # LOCAL PATCH 2026-11-08
from modules.metadata import tvshow_meta, episodes_meta, all_episodes_meta, season_trailer_for, cour_display_numbers, display_genres, show_status_props
# LOCAL PATCH 2026-09-04: imported once here, not inside the per-item block (the import lock contends across TaskPool
# threads). Optional, so an import failure degrades to the TMDb air-date behaviour.
try:
	from apis.trakt_air import parse_utc_to_local
except Exception:
	parse_utc_to_local = None
from modules.utils import jsondate_to_datetime, adjust_premiered_date, adjust_premiered_datetime, make_day, get_datetime, get_current_timestamp, title_key, date_difference, TaskPool

# LOCAL PATCH 2026-07-30 / rewritten 2026-08-09: auto-focus the first unwatched episode after directory render, as Otaku's
# ui/control.py:draw_items smart-scroll does:
#   - SYNCHRONOUS (no thread): Kodi renders at end_directory and keeps the GUI live while the invocation finishes.
#   - Waits until the video window (10025) is active, a list control has focus, and Container.NumItems matches the episode
#     count just added -- during the nav transition the PREVIOUS (season) container is still there.
#   - Fires `Control.SetFocus(<focused_control_id>, <index>)`, not the unreliable Container.SetFocus.
#   - +1 when the container has a parent ".." item (NumAllItems > NumItems).
# LOCAL PATCH 2026-10-19: _grace is settings.with_air_grace (one copy, shared with modules/episode_tools).
_grace = settings.with_air_grace


def _publish_first_unwatched(items):
	"""The first unwatched episode's index, published for AF3's Combined view BEFORE end_directory: the skin's Right action
	reads it the moment the episodes show. LOCAL PATCH 2026-11-09: it was set after the anime id prewarm, which runs inline
	for up to ~5 s, so a quick Right found the previous season's path and entered at episode 1."""
	try:
		expected = len(items)
		if expected <= 1: return None
		target = None
		for idx, (_url, li, _isdir) in enumerate(items):
			try:
				info = li.getVideoInfoTag()
				if info.getPlayCount() > 0: continue
				if info.getSeason() == 0: continue
				title = info.getTitle() or ''
				if title.startswith('[COLOR red]'): continue   # unaired items are red-italicized
				target = idx
				break
			except: continue
		# LOCAL PATCH 2026-10-27: published for AF3's Combined List (its second list, 537, is this list filled while the seasons
		# have focus): kodi_utils.autoscroll_focus cannot reach that list, so the skin's Right action reads these and enters the
		# episodes here. The path is the URL the skin asked for, i.e. the season row's FolderPath it compares against.
		try:
			kodi_utils.set_property('deadlight.episodes.first_unwatched_path', '%s%s' % (sys.argv[0], sys.argv[2]))
			kodi_utils.set_property('deadlight.episodes.first_unwatched', str(target or 0))
		except Exception: pass
		return target
	except: return None


def _episode_rating_props(item):
	"""LOCAL PATCH 2026-10-19: an episode row's rating chips, from the EPISODE only -- IMDb's and Trakt's when the season
	backfill stored them, TMDb's own vote. Nothing from the show (AF3 hides TMDbHelper's show-level chips on episodes)."""
	out = {}
	try:
		if item.get('imdb_rating'): out['extra_imdb_rating'] = str(item['imdb_rating'])
		if item.get('trakt_rating'): out['extra_trakt_rating'] = str(item['trakt_rating'])
		if float(item.get('rating') or 0) > 0: out['extra_tmdb_rating'] = '%.1f' % float(item['rating'])
	except Exception: pass
	return out

# LOCAL PATCH 2026-10-26: set (Home window, time.time()) when an episode list starts building, so the season list's
# after-list warm (indexers/seasons._queue_episode_warm) sees that AF3's combined view (527) already asked for the same
# season and does not fetch it twice.
EPISODE_LIST_PROP = 'deadlight.episode_list.%s_%s'

def build_episode_list(params):
	try: kodi_utils.set_property(EPISODE_LIST_PROP % (int(params.get('tmdb_id')), int(params.get('season'))), str(time.time()))
	except Exception: pass
	def _process():
		for item in episodes_data:
			try:
				cm = []
				cm_append = cm.append
				listitem = make_listitem()
				set_properties = listitem.setProperties
				item_get = item.get
				season, episode, ep_name = item_get('season'), item_get('episode'), item_get('title')
				season_special = season == 0
				episode_date, premiered = adjust_premiered_date(item_get('premiered'), adjust_hours)
				# LOCAL PATCH 2026-07-02: same-day precision -- an episode airing later today stays 'unaired' until wall-clock passes
				# the assumed 20:00 local + adjust_hours airtime.
				episode_datetime = adjust_premiered_datetime(item_get('premiered'), adjust_hours)
				# LOCAL PATCH 2026-08-07: prefer Trakt UTC first_aired when enriched (see metadata.py).
				first_aired_utc = item_get('first_aired_utc')
				if first_aired_utc:
					try:
						trakt_local = parse_utc_to_local(first_aired_utc) if parse_utc_to_local else None
						if trakt_local:
							episode_datetime = trakt_local
							episode_date = trakt_local.date()
							# LOCAL PATCH 2026-10-25 (4.0.5): the date shown (first aired, year, the Next Episodes sort key) is the real air time's
							# local day too, not only the aired test
							premiered = trakt_local.strftime('%Y-%m-%d')
					except Exception: pass
				episode_type = item_get('episode_type') or ''
				episode_id = item_get('episode_id') or None
				if season_special: playcount, progress = 0, None
				else:
					playcount = ws.get_watched_status_episode(watched_info, (season, episode))
					if playcount and hide_watched: continue
					if total_seasons: progress = ws.get_progress_status_all_episode(bookmarks, season, episode)
					else: progress = ws.get_progress_status_episode(bookmarks, episode)
				if no_spoilers and not playcount: thumb, plot = show_landscape or show_fanart, tvshow_plot or '* Hidden to Prevent Spoilers *'
				else: thumb, plot = item_get('thumb', None) or show_landscape or show_fanart, item_get('plot') or tvshow_plot
				try: year = premiered.split('-')[0]
				except: year = show_year or ''
				duration = item_get('duration')
				if not duration:
					duration = show_duration
					item['duration'] = duration
				if not episode_date or current_date < episode_date or (episode_datetime and current_datetime < _grace(episode_datetime)):
					# LOCAL PATCH 2026-08-29: an unaired episode cannot be played, so by default it is dropped. An episode with no air date
					# counts as unaired (common for announced anime cours).
					# continue, NOT return: _process() here is a generator over episodes_data, so returning would hide every aired episode
					# after the first unaired one. (build_single_episode's identical line IS a return -- its _process runs per item.)
					if not include_unaired: continue
					# LOCAL PATCH 2026-10-15: the label only -- writing the styled name into item['title'] saved it into metacache via the
					# deferred backfill, and the next listing wrapped it again (a stray '[/I]').
					display, unaired = '[COLOR red][I]%s[/I][/COLOR]' % ep_name, True
				else: display, unaired = _filler_mark(meta, season, episode, ep_name), False   # LOCAL PATCH 2026-11-08: ' . Filler'
				extras_params = build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'episode', 'is_external': is_external, 'season': season})
				options_params = build_url({'mode': 'options_menu_choice', 'content': 'episode', 'tmdb_id': tmdb_id, 'poster': show_poster, 'is_external': is_external})
				playback_options_params = build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': season, 'playcount': playcount,
												'episode': episode, 'episode_id': episode_id})
				play_params = build_url({'mode': play_mode, 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'playcount': playcount,
										'episode_id': episode_id, playback_key: playback_key})
				cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
				cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
				cm_append(['playback_options', ('[B]Play Options[/B]', 'RunPlugin(%s)' % playback_options_params)])
				if str(tmdb_id) in pinned: cm_append(['playback_options', ('[B]Clear SmartPlay Pin[/B]', 'RunPlugin(%s)' % build_url({'mode': 'clear_smartplay_pin_choice', 'tmdb_id': tmdb_id}))])
				# LOCAL PATCH 2026-11-07 (Red Light 2.9.5, #290): unaired episodes get Mark Watched / Unwatched too (early releases)
				if not season_special:
					if playcount:
						cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_unwatched',
													'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode,  'title': title}))])
					else: cm_append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_watched',
													'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode,  'title': title}))])
					if progress: cm_append(['mark_watched', ('[B]Clear Progress[/B]', 'RunPlugin(%s)' % \
								build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'episode', 'tmdb_id': tmdb_id,
								'season': season, 'episode': episode, 'refresh': 'true'}))])
					# LOCAL PATCH 2026-11-07 (Red Light 2.9.5): Unmark Previous Watched, only when the episode before this one in the season
					# IS watched (E1's previous is another season's, not in this list)
					if episode > 1 and ws.get_watched_status_episode(watched_info, (season, episode - 1)):
						cm_append(['unmark_previous_episode', ('[B]Unmark Previous Watched[/B]', 'RunPlugin(%s)' % \
								build_url({'mode': 'watched_status.unmark_previous_episode', 'action': 'mark_as_unwatched', 'tmdb_id': tmdb_id,
								'tvdb_id': tvdb_id, 'season': season, 'episode': episode, 'title': title, 'refresh': 'true'}))])
				if is_external:
					cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
							['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
				if custom_cm_menu:
					try: cm = sorted([i for i in cm if i[0] in cm_sort_order], key=lambda k: cm_sort_order[k[0]])
					except: pass
				cm = [i[1] for i in cm]
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setMediaType('episode'), info_tag.setTitle(display), info_tag.setOriginalTitle(orig_title), info_tag.setTvShowTitle(title), info_tag.setGenres(genre)
				# LOCAL PATCH 2026-08-27: the skin formats SxxExx from the info tag, so the numbering shows here, and both halves must
				# come from the cour (episode alone read '1x02' for Frieren cour 2). Urls and watched-state lookups keep TMDb's pair.
				_ds, _de = cour_display_numbers(meta, season, episode)
				info_tag.setPlaycount(playcount), info_tag.setSeason(_ds), info_tag.setEpisode(_de), info_tag.setPlot(plot)
				info_tag.setDuration(duration), info_tag.setIMDBNumber(imdb_id), info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str(tmdb_id), 'tvdb': str(tvdb_id)})
				info_tag.setFirstAired(premiered), info_tag.setTvShowStatus(show_status)
				info_tag.setCountries(country), info_tag.setTrailer(season_trailer_for(meta, season, trailer)), info_tag.setDirectors(item_get('director'))
				(year and info_tag.setYear(int(year))), info_tag.setRating(item_get('rating')), info_tag.setVotes(item_get('votes')), info_tag.setMpaa(mpaa)
				info_tag.setStudios(studio), info_tag.setWriters(item_get('writer'))
				full_cast = cast + item_get('guest_stars', [])
				info_tag.setCast([kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in full_cast])
				if progress and not unaired:
					info_tag.setResumePoint(ws.get_resume_seconds(progress, duration))
					set_properties({'WatchedProgress': progress})
				listitem.setLabel(display)
				listitem.addContextMenuItems(cm)
				# LOCAL PATCH 2026-08-06: extend art with parent show's fanart1..fanart8 for AF3 cycler.
				# LOCAL PATCH 2026-09-14: no season.poster / tvshow.poster / tvshow.clearlogo (a deliberate divergence from upstream):
				# AF3 and TMDbHelper read the base key first and DeadLight always sets it, so they were unreachable, and filling
				# season.poster cost TVDB requests under artwork_provider=2.
				_art = {'poster': list_poster, 'fanart': show_fanart, 'thumb': thumb, 'icon':thumb, 'clearlogo': show_clearlogo, 'landscape': show_landscape}
				for _idx, _bg in enumerate(show_extra_fanart, start=1): _art['fanart%d' % _idx] = _bg
				listitem.setArt(_art)
				set_properties({
					'episode_type': episode_type, 'deadlight.extras_params': extras_params, 'deadlight.options_params': options_params,
					'deadlight.playback_options_params': playback_options_params
					})
				# LOCAL PATCH 2026-09-14: the EPISODE's own IMDb rating (metadata.episodes_meta, cached with the season); otherwise
				# extra_rating_props shows the SHOW's rating on every episode. Feeds AF3's IMDb chip only; TMDb's still drives setRating.
				_ep_imdb = item_get('imdb_rating')
				if _ep_imdb: set_properties({'extra_imdb_rating': str(_ep_imdb)})
				# LOCAL PATCH 2026-09-15: the Trakt chip, per episode from Trakt (metadata._backfill_season_trakt). Its own chip, NOT a
				# fallback for IMDb's -- Trakt covers far more episodes than OMDb, so a Trakt rating without an IMDb one is normal.
				_ep_trakt = item_get('trakt_rating')
				if _ep_trakt: set_properties({'extra_trakt_rating': str(_ep_trakt)})
				_ep_tmdb = _episode_rating_props(item).get('extra_tmdb_rating')   # LOCAL PATCH 2026-10-19: the episode's TMDb vote
				if _ep_tmdb: set_properties({'extra_tmdb_rating': _ep_tmdb})
				yield (play_params, listitem, False)
			except: kodi_utils.log_row_error('episodes')
	kodi_actor, make_listitem, build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
	poster_empty, fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	include_unaired = settings.include_unaired_episodes()
	no_spoilers = settings.avoid_episode_spoilers()
	watched_indicators, adjust_hours = settings.watched_indicators(), settings.date_offset()
	current_date, hide_watched = get_datetime(), is_external and settings.widget_hide_watched()
	current_datetime = get_datetime(dt=True)  # LOCAL PATCH 2026-07-02: same-day airtime precision
	cm_sort_order = settings.cm_sort_order()
	custom_cm_menu = cm_sort_order != settings.cm_default_order()
	from modules.smartplay_utils import pinned_ids
	pinned = pinned_ids()   # LOCAL PATCH 2026-09-27: Clear SmartPlay Pin on the context menu
	rpdb_info = settings.rpdb_info('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	playback_key = settings.playback_key()
	play_mode = 'playback.%s' % playback_key
	meta = tvshow_meta('tmdb_id', params.get('tmdb_id'), settings.tmdb_api_key(), settings.mpaa_region(), current_date)
	meta_get = meta.get
	tmdb_id, tvdb_id, imdb_id, tvshow_plot, orig_title = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id'), meta_get('plot'), meta_get('original_title')
	title, show_year, show_duration, show_status = meta_get('title'), meta_get('year') or '', meta_get('duration'), meta_get('status')
	mpaa, trailer, genre, studio, country = meta_get('mpaa'), str(meta_get('trailer')), display_genres(meta), meta_get('studio'), meta_get('country')
	cast = meta_get('short_cast', []) or meta_get('cast', []) or []
	season = params['season']
	# LOCAL PATCH 2026-08-27: a cour is a slice of a TMDb season (caches/fribb_mappings.cours_for_tmdb_season). `season`
	# stays TMDb's; cour_offset is how many of its episodes precede this cour.
	try: cour_offset = int(params.get('cour_offset') or 0)
	except (TypeError, ValueError): cour_offset = 0
	try: cour_len = int(params.get('cour_len') or 0)
	except (TypeError, ValueError): cour_len = 0
	# LOCAL PATCH 2026-08-27: the cour's own AniList cover, handed over by the season row, so the list matches the row.
	cour_poster = params.get('cour_poster') or ''
	if rpdb_api_key:
		try: show_poster = meta_get('rpdb_poster') % rpdb_api_key + rpdb_format
		except: show_poster = meta_get('poster') or poster_empty
	else: show_poster = meta_get('poster') or poster_empty
	show_fanart = meta_get('fanart') or fanart_empty
	# LOCAL PATCH 2026-08-06: episode listitems inherit the parent show's extra_fanart_list for AF3's fanart cycler.
	show_extra_fanart = meta_get('extra_fanart_list') or []
	show_clearlogo = meta_get('clearlogo') or ''
	show_landscape = meta_get('landscape') or ''
	watched_db = ws.get_database(watched_indicators)
	watched_info = ws.watched_info_episode(tmdb_id, watched_db)
	if season == 'all':
		cour_offset, cour_len = 0, 0   # a flat list spans every cour
		total_seasons = meta_get('total_seasons')
		_with_specials = settings.show_specials()
		try:   # LOCAL PATCH 2026-10-17: anime follows anime.specials
			from modules.metadata import is_anime_check
			if is_anime_check(meta): _with_specials = settings.anime_specials() != 'hidden'
		except Exception: pass
		episodes_data = sorted(all_episodes_meta(meta, _with_specials, backfill=True), key=lambda x: (x['season'], x['episode']))
		bookmarks = ws.get_bookmarks_all_episode(tmdb_id, total_seasons, watched_db)
		season_poster = show_poster
		category_name = 'Season 1' if total_seasons == 1 else 'Seasons 1-%s' % total_seasons
	else:
		total_seasons = None
		episodes_data = episodes_meta(season, meta, backfill=True)
		bookmarks = ws.get_bookmarks_episode(tmdb_id, season, watched_db)
		try:
			season_data = meta_get('season_data')
			poster_path = next((i['poster_path'] for i in season_data if i['season_number'] == int(season)), None)
			season_poster = 'https://image.tmdb.org/t/p/w500%s' % poster_path if poster_path is not None else show_poster
		except: season_poster = show_poster
		# LOCAL PATCH 2026-09-14: TVDB season poster, below the AniList cour cover (a cour cover names one cour, a season poster
		# the TMDb season the cours share). Resolved HERE, in the branch that reads it: assigned elsewhere it was unbound on this
		# path (UnboundLocalError killed the whole list).
		_tmdb_season_poster = season_poster
		season_poster = _tvdb_season_poster(_tvdb_season_poster_map(meta, tvdb_id), season, season_poster)
		season_poster = cour_poster or season_poster
		# DIAGNOSTIC 2026-09-14: as in seasons.py -- `source` is what won (the texture cache records only what Kodi RENDERED).
		# LOCAL PATCH 2026-11-01 (cleanup): only with scrape.diag_timing on.
		if settings.diag_timing():
			try: kodi_utils.logger('episodes.season_poster', 'tmdb_id=%s season=%s source=%s poster=%s'
							  % (tmdb_id, season,
								 'cour' if cour_poster else ('tvdb' if season_poster != _tmdb_season_poster else
															 ('tmdb' if _tmdb_season_poster != show_poster else 'show')),
								 str(season_poster)[-48:]))
			except Exception: pass
		category_name = 'Season %s' % season
		if cour_len:
			episodes_data = [i for i in episodes_data
				if cour_offset < (i.get('episode') or 0) <= cour_offset + cour_len]
			category_name = params.get('cour_title') or '%s (%s-%s)' % (
				category_name, cour_offset + 1, cour_offset + cour_len)
	# LOCAL PATCH 2026-08-27 / widened 2026-09-15: the season (or cour) poster is the primary art of an episode list, for
	# EVERY show, so the list carries the artwork of the row you came from. Not anime-only: AF3 tests Art(poster) before
	# Art(season.poster) everywhere, so on a regular show the season poster never rendered. season_poster already falls back
	# to show_poster, so no case loses a poster.
	list_poster = season_poster or show_poster
	items = list(_process())
	kodi_utils.add_items(handle, items)
	kodi_utils.set_sort_method(handle, 'episodes')
	kodi_utils.set_content(handle, 'episodes')
	kodi_utils.set_category(handle, category_name)
	_autoscroll = not is_external and season != 'all' and settings.autoscroll_unwatched()   # LOCAL PATCH 2026-07-30
	_target = _publish_first_unwatched(items) if _autoscroll else None
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	kodi_utils.set_view_mode('view.episodes', 'episodes', is_external)
	# flat list / wall views: focus it once the list is live (None = all watched, 0 = already at the top). Before the prewarm,
	# whose anime id warm runs inline.
	if _target: kodi_utils.autoscroll_focus(_target, len(items))
	# LOCAL PATCH 2026-10-06: warm the scrape ids of the episodes most likely played next -- the first aired unwatched one and
	# the newest aired one (often another AniList entry); see modules/scrape_prewarm.py. In-addon browsing only.
	# LOCAL PATCH 2026-11-05: every show, for Direct Streams (HDHub's slow first answer); the anime id warm stays anime-only
	if not is_external:
		try:
			from modules.metadata import is_anime_meta   # LOCAL PATCH 2026-10-19: not source_utils (slow imports to forward here)
			_today = str(current_date)
			_aired = [i for i in episodes_data if i.get('season') and str(i.get('premiered') or '9999')[:10] <= _today]
			_next = next((i for i in _aired if not ws.get_watched_status_episode(watched_info, (i['season'], i['episode']))), None)
			_warm = [i for i in (_next, _aired[-1] if _aired else None) if i]
			if _warm:
				from modules.scrape_prewarm import queue
				_anime = is_anime_meta(meta)
				# LOCAL PATCH 2026-11-08: the TVDB episode ids of the aired episodes, nearest the next unwatched first (from it
				# forward, then back) -- scrape_prewarm._warm_tvdb_ids; anime only
				_tvdb = []
				if _anime:
					_at = _aired.index(_next) if _next in _aired else len(_aired)
					_tvdb = [(i['season'], i['episode']) for i in _aired[_at:] + _aired[:_at][::-1]]
				queue(meta, [(i['season'], i['episode'], i.get('title') or '', i.get('premiered') or '') for i in _warm], anime=_anime, tvdb_pairs=_tvdb)
		except Exception: pass

# LOCAL PATCH 2026-08-29: shared planning for Continue Watching, used here and by indexers.continue_watching (which folds
# movies in). Returns (resume_episodes, next_episodes), deduped against each other:
#  - A show in BOTH (resume on S02E04, watched through S02E03): the resume side wins, the show leaves the next side.
#  - A resume point at or behind the last watched (season, episode) is STALE and dropped; one AHEAD of it is live.
# LOCAL PATCH 2026-09-04: `hidden` is resolved once by the caller and passed in (one get_hidden_progress_items per render,
# a set for the membership test). Default None keeps build_single_episode working.
def continue_watching_plan(watched_indicators, hidden=None):
	def _tmdb_of(entry):
		try: return int(entry['media_ids']['tmdb'])
		except (KeyError, TypeError, ValueError): return None
	if hidden is None: hidden = ws.get_hidden_progress_items(watched_indicators) or []
	hidden_list = hidden if isinstance(hidden, set) else set(hidden)
	in_progress = ws.get_in_progress_episodes(hidden_list)
	next_data = ws.get_next_episodes(settings.nextep_method())
	if hidden_list: next_data = [i for i in next_data if not i['media_ids']['tmdb'] in hidden_list]
	watched_pos = {}
	for i in next_data:
		tid = _tmdb_of(i)
		if tid is None: continue
		try: watched_pos[tid] = (int(i['season']), int(i['episode']))
		except (TypeError, ValueError): pass
	resume = []
	for i in in_progress:
		tid = _tmdb_of(i)
		try: resume_at = (int(i['season']), int(i['episode']))
		except (TypeError, ValueError): continue
		if tid is not None and watched_pos.get(tid, (-1, -1)) >= resume_at: continue
		i['is_next'] = False
		# get_in_progress_episodes names the timestamp 'date'; the shared sorts read
		# 'last_played', so normalise rather than special-casing every consumer.
		i.setdefault('last_played', i.get('date'))
		resume.append(i)
	# LOCAL PATCH 2026-11-04 (Red Light 2.9.3, #286): one card per show -- of two paused episodes only the newest pause is
	# listed. Same 'T'-blind timestamp compare as continue_watching._sort_time; a row with no tmdb id is kept.
	newest = {}
	for i in resume:
		tid = _tmdb_of(i)
		if tid is None: continue
		when = str(i.get('last_played') or '').replace('T', ' ')
		if tid not in newest or when > newest[tid][0]: newest[tid] = (when, id(i))
	resume = [i for i in resume if _tmdb_of(i) is None or newest[_tmdb_of(i)][1] == id(i)]
	covered = {t for t in (_tmdb_of(i) for i in resume) if t is not None}
	upcoming = None
	# LOCAL PATCH 2026-10-05: under MDBList indicators the next-episode rows are MDBList's own Up Next (mdbl_upnext), so the
	# widget matches the website (DeadLight's own rule listed every unfinished show however long ago watched). Those rows
	# name the episode to play (from_upnext). Computed here as before when MDBList cannot be reached.
	if watched_indicators == 2:
		try:
			from apis.mdblist_api import mdbl_upnext
			from caches import mdblist_cache
			up = mdbl_upnext()
			if up is not None:
				# LOCAL PATCH 2026-10-09: MDBList recomputes Up Next a few seconds after a mark, but the widget refresh fetches within a
				# second and keeps that answer an hour. A row behind the local position (a watch MDBList has not seen) or more than one
				# ahead of it in the same season (an unwatch) is computed here from the local row; a later season is MDBList's call.
				# Only under 'Last Aired', whose local row is the furthest episode watched (the other is the latest played).
				local_next = {_tmdb_of(i): i for i in next_data} if settings.nextep_method() == 0 else {}
				def _upnext_row(x):
					pos = watched_pos.get(x['tmdb'])
					if pos and x['tmdb'] in local_next:
						at = (x['season'], x['episode'])
						if at <= pos or (at[0] == pos[0] and at[1] > pos[1] + 1):
							row = dict(local_next[x['tmdb']]); row['is_next'] = True
							return row
					return {'media_ids': {'tmdb': x['tmdb']}, 'season': x['season'], 'episode': x['episode'], 'title': '',
						'last_played': x['last_watched_at'], 'from_upnext': True, 'is_next': False}
				# LOCAL PATCH 2026-11-06: the rule above needs a local row; a show unmarked down to NOTHING watched has none, so the stale
				# copy passed whole. A show with no local watched row unmarked here within 2 minutes before this copy was fetched is
				# dropped; a later fetch is MDBList's settled answer, and a show watched elsewhere but not synced has no tombstone.
				fetched = (mdblist_cache.mdbl_cache.get('mdbl_upnext') or {}).get('at') or time.time()
				emptied = ws.shows_unwatched_since(watched_indicators, float(fetched) - 120) - set(watched_pos)
				upcoming = [_upnext_row(x) for x in up if x['tmdb'] not in covered and x['tmdb'] not in hidden_list and x['tmdb'] not in emptied]
		except Exception: upcoming = None
	if upcoming is None:
		upcoming = [i for i in next_data if _tmdb_of(i) not in covered]
		for i in upcoming: i['is_next'] = True
	if settings.nextep_limit_history(): upcoming = upcoming[:settings.nextep_limit()]
	return resume, upcoming


# LOCAL PATCH 2026-09-14: TVDB season posters for the EPISODE list (it builds its own season_poster from TMDb's
# season_data, so seasons.py's change did not reach it). Resolved once per list build; {} unless TVDB is the chosen
# provider for this kind. Only POSTERS: TVDB's season background type (8) is empty in practice.
# Memoised per invocation: modules/invocation.py (_CLEARS) empties the module-level dict at the start of every plugin
# call (Reuse Language Invoker keeps the module alive between calls).
_TVDB_POSTER_MEMO = {}

def _tvdb_season_poster_map(meta, tvdb_id):
	if tvdb_id in _TVDB_POSTER_MEMO: return _TVDB_POSTER_MEMO[tvdb_id]
	try:
		from modules.metadata import is_anime_check
		kind = 'anime' if is_anime_check(meta) else 'tvshow'
		mode = str(settings.get_setting('deadlight.%s.artwork_provider' % kind, '0'))
		# LOCAL PATCH 2026-09-16: mode 3 included, matching seasons.py -- fanart.tv serves no season posters, so excluding it
		# disabled them rather than sourcing them elsewhere.
		if mode not in ('1', '2', '3'):
			_TVDB_POSTER_MEMO[tvdb_id] = {}
			return {}
		from apis.tvdb_api import season_posters
		result = season_posters(tvdb_id)
	except Exception: result = {}
	_TVDB_POSTER_MEMO[tvdb_id] = result
	return result


def _tvdb_season_poster(posters, season, fallback):
	"""Season numbers arrive as ints from TVDB and as either from callers, so normalise."""
	if not posters: return fallback
	try: return posters.get(int(season)) or fallback
	except Exception: return fallback


# LOCAL PATCH 2026-11-13: AF3's Next Aired hub (one row per day, upstream fed by TMDb Helper's calendar) asks for one day of
# the MDBList calendar: build_mdbl_calendar&day=<offset from today, -1 .. 6>. The day is the LOCAL air date: a UTC time goes
# through parse_utc_to_local (system timezone; never deadlight.datetime.offset, see apis.trakt_air); a bare date is taken as
# it is. Each item also carries the two properties AF3's row titles read: widget (Yesterday / Today / Tomorrow / weekday)
# and air_date_short ("13 Nov").
def _calendar_local_date(first_aired):
	# jsondate_to_datetime, not datetime.strptime: strptime fails inside Kodi's embedded Python after its first use (it
	# returned None for every row on 2026-11-13); the helper exists for exactly that.
	try:
		if 'T' in (first_aired or '') and parse_utc_to_local:
			local = parse_utc_to_local(first_aired)
			if local: return local.date()
		return jsondate_to_datetime((first_aired or '')[:10], '%Y-%m-%d').date()
	except Exception: return None


def _calendar_day(params):
	"""(target date, AF3 row properties) for params['day'], or (None, None)."""
	try: offset = int(params.get('day'))
	except (TypeError, ValueError): return None, None
	from datetime import timedelta
	target = get_datetime() + timedelta(days=offset)
	label = {-1: 'Yesterday', 0: 'Today', 1: 'Tomorrow'}.get(offset) or target.strftime('%A')
	return target, {'widget': label, 'air_date_short': '%d %s' % (target.day, target.strftime('%b'))}


def build_single_episode(list_type, params={}):
	calendar_target, calendar_props = _calendar_day(params) if list_type == 'episode.mdblist' else (None, None)
	def _get_category_name():
		try:
			if is_combined: return 'Continue Watching'
			cat_name = {'episode.progress': 'In Progress Episodes',
						'episode.recently_watched': 'Recently Watched Episodes',
						'episode.next_trakt': 'Next Episodes', 'episode.next_deadlight': 'Next Episodes',
						'episode.trakt': {'true': 'Recently Aired Episodes', None: 'Trakt Calendar'}}[list_type]
			if isinstance(cat_name, dict): cat_name = cat_name[params.get('recently_aired')]
		except: cat_name = 'Episodes'
		return cat_name
	def _process(_position, ep_data):
		try:
			ep_data_get = ep_data.get
			meta = tvshow_meta('trakt_dict', ep_data_get('media_ids'), api_key, mpaa_region_value, current_date, current_time, is_anime_list=is_anime_list)
			if not meta: return
			meta_get = meta.get
			cm = []
			cm_append = cm.append
			listitem = make_listitem()
			set_properties = listitem.setProperties
			orig_season, orig_episode = ep_data_get('season'), ep_data_get('episode')
			unwatched = ep_data_get('unwatched', False)
			_position = ep_data_get('custom_order', _position)
			tmdb_id, tvdb_id, imdb_id, title, show_year = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id'), meta_get('title'), meta_get('year') or ''
			season_data = meta_get('season_data')
			if watched_all is not None: watched_info = watched_all.get(str(meta_get('tmdb_id')), [])   # LOCAL PATCH 2026-10-02
			else: watched_info = ws.watched_info_episode(meta_get('tmdb_id'), watched_db)
			# LOCAL PATCH 2026-08-29: per-ITEM rather than per-list: the combined Continue Watching list carries resume points (the
			# exact episode) and watched rows (the PREVIOUS one, needing get_next()). ep_data['is_next'] says which; other lists
			# fall back to the list type.
			item_is_next = ep_data_get('is_next', list_type_starts_with('next'))
			# LOCAL PATCH 2026-10-05: a row from MDBList's Up Next names the next episode itself (no get_next), but is a
			# next-episode row everywhere else -- the unaired rule, Unmark Previous, the order below the resume points
			item_next_row = item_is_next or bool(ep_data_get('from_upnext'))
			if item_is_next:
				orig_season, orig_episode = ws.get_next(orig_season, orig_episode, watched_info, season_data, nextep_content)
				if orig_season is None or not orig_episode: return   # season 0 (the next special) is falsy
				# LOCAL PATCH 2026-11-08: Skip filler -- the next canon episode (stored flags only: a list never waits on tenrai)
				orig_season, orig_episode = _filler_skip(meta, orig_season, orig_episode,
					lambda s, e: ws.get_next(s, e, watched_info, season_data, nextep_content), fetch=False)
			episodes_data = episodes_meta(orig_season, meta, backfill=True)
			if not episodes_data: return
			item = next((i for i in episodes_data if i['episode'] == orig_episode), None)
			if not item: return
			item_get = item.get
			season, episode, ep_name = item_get('season'), item_get('episode'), item_get('title')
			episode_date, premiered = adjust_premiered_date(item_get('premiered'), adjust_hours)
			# LOCAL PATCH 2026-07-02: same-day precision -- episodes airing later today stay 'unaired' until their assumed airtime
			# (20:00 local + offset).
			episode_datetime = adjust_premiered_datetime(item_get('premiered'), adjust_hours)
			# LOCAL PATCH 2026-08-07: prefer Trakt's UTC first_aired when episodes_meta enriched it (irregular airtimes: Netflix,
			# anime late-night JST); silent fallback to the TMDb date otherwise.
			first_aired_utc = item_get('first_aired_utc')
			if first_aired_utc:
				try:
					trakt_local = parse_utc_to_local(first_aired_utc) if parse_utc_to_local else None
					if trakt_local:
						episode_datetime = trakt_local
						episode_date = trakt_local.date()
						premiered = trakt_local.strftime('%Y-%m-%d')   # LOCAL PATCH 2026-10-25 (4.0.5): see build_episode_list
				except Exception: pass
			episode_type = item_get('episode_type') or ''
			episode_id = item_get('episode_id') or None
			if not episode_date or current_date < episode_date or (episode_datetime and current_datetime < _grace(episode_datetime)):
				if item_next_row:
					if not episode_date: return
					if not include_unaired: return
					if not date_difference(current_date, episode_date, 7): return
				unaired = True
			else: unaired = False
			orig_title, trailer, genre = meta_get('original_title'), str(meta_get('trailer')), display_genres(meta)
			mpaa, tvshow_plot, studio, show_status = meta_get('mpaa'), meta_get('plot'), meta_get('studio'), meta_get('status')
			cast = meta_get('short_cast', []) or meta_get('cast', []) or []
			if rpdb_api_key:
				try: show_poster = meta_get('rpdb_poster') % rpdb_api_key + rpdb_format
				except: show_poster = meta_get('poster') or poster_empty
			else: show_poster = meta_get('poster') or poster_empty
			show_fanart = meta_get('fanart') or fanart_empty
			# LOCAL PATCH 2026-08-06: parent show extra_fanart_list for AF3 cycler.
			show_extra_fanart = meta_get('extra_fanart_list') or []
			show_clearlogo = meta_get('clearlogo') or ''
			show_landscape = meta_get('landscape') or ''
			try: year = premiered.split('-')[0]
			except: year = show_year or ''
			# LOCAL PATCH 2026-09-14: no season_poster lookup here -- it fed only season.poster, which nothing reads (see _art above).
			# Next Up / In Progress build their label from these, so they need the cour numbering too (else '01x30' for what the
			# episode list and every release call S02E02).
			_ds, _de = cour_display_numbers(meta, season, episode)
			str_season_zfill2, str_episode_zfill2 = str(_ds).zfill(2), str(_de).zfill(2)
			if display_format == 0: title_str = '%s: ' % title
			else: title_str = ''
			if display_format in (0, 1): seas_ep = '%sx%s - ' % (str_season_zfill2, str_episode_zfill2)
			else: seas_ep = ''
			# LOCAL PATCH 2026-08-29: these two stay LIST-wide, deliberately: they control playcount and label, and on the combined
			# list both suit resume rows (part-way = playcount 0; one label format reads better). A resume on a watched episode is
			# the stale bookmark already dropped above.
			if not list_type_starts_with('next_'):
				playcount = ws.get_watched_status_episode(watched_info, (season, episode))
				if playcount and hide_watched: return
			if not unaired: ep_name = _filler_mark(meta, season, episode, ep_name)   # LOCAL PATCH 2026-11-08: ' . Filler'
			if list_type_starts_with('next_'):
				playcount = 0
				if include_airdate:
					if episode_date: display_premiered = '[%s] ' % make_day(current_date, episode_date)
					else: display_premiered = '[UNKNOWN] '
				else: display_premiered = ''
				if unwatched: highlight_start, highlight_end = '[COLOR darkgoldenrod]', '[/COLOR]'
				elif unaired: highlight_start, highlight_end = '[COLOR red]', '[/COLOR]'
				else: highlight_start, highlight_end = '', ''
				display = '%s%s%s%s%s%s' % (display_premiered, title_str, highlight_start, seas_ep, ep_name, highlight_end)
			elif list_type_compare == 'trakt_calendar':
				if episode_date: display_premiered = make_day(current_date, episode_date)
				else: display_premiered = 'UNKNOWN'
				display = '[%s] %s%s%s' % (display_premiered, title_str, seas_ep, ep_name)
			else: display = '%s%s%s' % (title_str, seas_ep, ep_name)
			if no_spoilers and not playcount: thumb, plot = show_landscape or show_fanart, tvshow_plot or '* Hidden to Prevent Spoilers *'
			else: thumb, plot = item_get('thumb', None) or show_landscape or show_fanart, item_get('plot') or tvshow_plot
			duration = item_get('duration')
			if not duration:
				duration = meta_get('duration')
				item['duration'] = duration
			# LOCAL PATCH 2026-10-03 (3.0.8): the long lists read every resume point once (bookmarks_all, below)
			try: bookmarks = bookmarks_all[(str(tmdb_id), int(season))] if bookmarks_all is not None else None
			except KeyError: bookmarks = {}
			except (TypeError, ValueError): bookmarks = None
			if bookmarks is None: bookmarks = ws.get_bookmarks_episode(tmdb_id, season, watched_db)
			progress = ws.get_progress_status_episode(bookmarks, episode)
			play_params = build_url({'mode': play_mode, 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'playcount': playcount,
									'episode_id': episode_id, playback_key: playback_key})
			extras_params = build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'episode', 'is_external': is_external, 'season': season})
			options_params = build_url({'mode': 'options_menu_choice', 'content': list_type, 'tmdb_id': tmdb_id, 'poster': show_poster, 'is_external': is_external})
			playback_options_params = build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': season, 'playcount': playcount,
											'episode': episode, 'episode_id': episode_id})
			cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
			cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
			cm_append(['playback_options', ('[B]Play Options[/B]', 'RunPlugin(%s)' % \
						build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': season, 'episode': episode, 'episode_id': episode_id}))])
			if str(tmdb_id) in pinned: cm_append(['playback_options', ('[B]Clear SmartPlay Pin[/B]', 'RunPlugin(%s)' % build_url({'mode': 'clear_smartplay_pin_choice', 'tmdb_id': tmdb_id}))])
			cm_append(['browse_seasons', ('[B]Browse Seasons[/B]', window_command % build_url({'mode': 'build_season_list', 'tmdb_id': tmdb_id}))])
			cm_append(['browse_episodes', ('[B]Browse Episodes[/B]', window_command % build_url({'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': season}))])
			# LOCAL PATCH 2026-11-07 (Red Light 2.9.5, #290): unaired episodes get Mark Watched / Unwatched too -- an early release
			# is ticked by hand. Mark season / show watched still skips future dates.
			if playcount:
				cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_unwatched',
											'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode,  'title': title}))])
			else: cm_append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_watched',
										'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode,  'title': title}))])
			if progress:
				cm_append(['mark_watched', ('[B]Clear Progress[/B]', 'RunPlugin(%s)' % \
							build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'episode', 'tmdb_id': tmdb_id,
										'season': season, 'episode': episode, 'refresh': 'true'}))])
			if unwatched_info:
				total_aired_eps = meta_get('total_aired_eps')
				total_unwatched = ws.get_watched_status_tvshow(ws.watched_info_tvshow(watched_db).get(str(tmdb_id), None), total_aired_eps)[2]
				if total_aired_eps != total_unwatched: set_properties({'watchedepisodes': '1', 'unwatchedepisodes': str(total_unwatched)})
			if item_next_row and (season, episode) != (1, 1):
				cm_append(['unmark_previous_episode', ('[B]Unmark Previous Watched[/B]', 'RunPlugin(%s)' % \
								build_url({'mode': 'watched_status.unmark_previous_episode', 'action': 'mark_as_unwatched', 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id,
											'season': season, 'episode': episode, 'title': title, 'refresh': 'true'}))])
			if is_external:
				cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
						['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
			if custom_cm_menu:
				try: cm = sorted([i for i in cm if i[0] in cm_sort_order], key=lambda k: cm_sort_order[k[0]])
				except: pass
			cm = [i[1] for i in cm]
			info_tag = listitem.getVideoInfoTag(True)
			info_tag.setMediaType('episode'), info_tag.setOriginalTitle(orig_title), info_tag.setTvShowTitle(title), info_tag.setTitle(display), info_tag.setGenres(genre)
			info_tag.setPlaycount(playcount), info_tag.setSeason(_ds), info_tag.setEpisode(_de), info_tag.setPlot(plot), info_tag.setFirstAired(premiered)
			info_tag.setDuration(duration), info_tag.setIMDBNumber(imdb_id), info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str(tmdb_id), 'tvdb': str(tvdb_id)})
			info_tag.setCountries(meta_get('country', [])), info_tag.setTrailer(season_trailer_for(meta, season, trailer)), info_tag.setTvShowStatus(show_status)
			info_tag.setStudios(studio), info_tag.setWriters(item_get('writer')), info_tag.setDirectors(item_get('director'))
			(year and info_tag.setYear(int(year))), info_tag.setRating(item_get('rating')), info_tag.setVotes(item_get('votes')), info_tag.setMpaa(mpaa)
			full_cast = cast + item_get('guest_stars', [])
			info_tag.setCast([kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in full_cast])
			if progress and not unaired:
				info_tag.setResumePoint(ws.get_resume_seconds(progress, duration))
				set_properties({'WatchedProgress': progress})
			listitem.setLabel(display)
			listitem.addContextMenuItems(cm)
			# LOCAL PATCH 2026-08-06: extend art with parent show's fanart1..fanart8 for AF3 cycler.
			_art = {'poster': show_poster, 'fanart': show_fanart, 'thumb': thumb, 'icon':thumb, 'clearlogo': show_clearlogo, 'landscape': show_landscape}
			for _idx, _bg in enumerate(show_extra_fanart, start=1): _art['fanart%d' % _idx] = _bg
			listitem.setArt(_art)
			set_properties({
				'episode_type': episode_type, 'deadlight.extras_params': extras_params, 'deadlight.options_params': options_params,
				'deadlight.playback_options_params': playback_options_params
				})
			# LOCAL PATCH 2026-10-19: episode-level ratings ONLY (user's call: an episode tile shows the episode's rating or none);
			# extra_rating_props(meta) reads the SHOW meta.
			extra_props = _episode_rating_props(item)
			# LOCAL PATCH 2026-09-14: the EPISODE's own IMDb rating (metadata.episodes_meta, cached with the season); feeds AF3's IMDb
			# chip only. Read off `item`, NOT ep_data: on the Continue Watching path ep_data is a watched-status row with no meta.
			_ep_imdb = item_get('imdb_rating')
			if _ep_imdb: extra_props['extra_imdb_rating'] = str(_ep_imdb)
			_ep_trakt = item_get('trakt_rating')  # LOCAL PATCH 2026-09-15, see above
			if _ep_trakt: extra_props['extra_trakt_rating'] = str(_ep_trakt)
			# LOCAL PATCH 2026-10-13: AF3's status chip.
			# LOCAL PATCH 2026-10-19: always light on an EPISODE row -- AF3 draws the chip only for DBType tvshow / season, and the
			# full form cost TMDb / TVmaze / AniList requests inside Continue Watching / Next Episodes.
			extra_props.update(show_status_props(meta, light=True))
			if calendar_props: extra_props.update(calendar_props)   # LOCAL PATCH 2026-11-13: AF3 Next Aired row title
			if extra_props: set_properties(extra_props)
			item_list_append({'list_items': (play_params, listitem, False), 'first_aired': premiered, 'name': '%s - %sx%s' % (title, str_season_zfill2, str_episode_zfill2),
							'unaired': unaired, 'last_played': ep_data_get('last_played', resinsert), 'sort_order': _position, 'unwatched': ep_data_get('unwatched'),
							'is_next': item_next_row})
		except: kodi_utils.log_row_error('episodes.single')
	kodi_actor, make_listitem, build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
	poster_empty, fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	is_anime_list = 'is_anime_list' in params
	if not is_anime_list and settings.include_anime_tvshow(): is_anime_list = None
	# LOCAL PATCH 2026-08-29: Continue Watching -- In Progress and Next Episodes in one list. Anime always included unless the
	# caller asked for one side (include_anime_tvshow defaults to false, which would drop every anime).
	is_combined = list_type == 'episode.continue'
	if is_combined and 'is_anime_list' not in params: is_anime_list = None
	item_list, airing_today, unwatched, return_results = [], [], [], False
	resinsert = ''
	item_list_append = item_list.append
	window_command = 'ActivateWindow(Videos,%s,return)' if is_external else 'Container.Update(%s)'
	no_spoilers = settings.avoid_episode_spoilers()
	watched_indicators, display_format = settings.watched_indicators(), settings.single_ep_display_format(is_external)
	current_date, current_time, adjust_hours = get_datetime(), get_current_timestamp(), settings.date_offset()
	current_datetime = get_datetime(dt=True)  # LOCAL PATCH 2026-07-02: same-day airtime precision
	unwatched_info = settings.single_ep_unwatched_episodes()
	hide_watched = is_external and settings.widget_hide_watched() and list_type != 'episode.recently_watched'
	api_key, mpaa_region_value = settings.tmdb_api_key(), settings.mpaa_region()
	cm_sort_order, ignore_articles = settings.cm_sort_order(), settings.ignore_articles()
	custom_cm_menu = cm_sort_order != settings.cm_default_order()
	from modules.smartplay_utils import pinned_ids
	pinned = pinned_ids()   # LOCAL PATCH 2026-09-27: Clear SmartPlay Pin on the context menu
	rpdb_info = settings.rpdb_info('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	playback_key = settings.playback_key()
	play_mode = 'playback.%s' % playback_key
	watched_db = ws.get_database(watched_indicators)
	if list_type == 'episode.next':
		include_unwatched, include_unaired, nextep_content = settings.nextep_include_unwatched(), settings.nextep_include_unaired(), settings.nextep_method()
		sort_key, sort_direction = settings.nextep_sort_key(), settings.nextep_sort_direction()
		include_airdate = settings.nextep_include_airdate()
		data = ws.get_next_episodes(nextep_content)
		if settings.nextep_limit_history(): data = data[:settings.nextep_limit()]
		hidden_list = ws.get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not i['media_ids']['tmdb'] in hidden_list]
		# LOCAL PATCH 2026-07-28 / 2026-07-29: MDBList (2) + SIMKL (3) write ISO last_watched_at like Trakt (1).
		if watched_indicators in (1, 2, 3): resformat, resinsert, list_type = '%Y-%m-%dT%H:%M:%S.%fZ', '2000-01-01T00:00:00.000Z', 'episode.next_trakt'
		else: resformat, resinsert, list_type = '%Y-%m-%d %H:%M:%S', '2000-01-01 00:00:00', 'episode.next_deadlight'
		if include_unwatched != 0:
			if include_unwatched in (1, 3):
				from apis.trakt_api import trakt_watchlist
				try:
					watchlist = trakt_watchlist('tvshow', '')
					unwatched.extend([{'media_ids': i['media_ids'], 'season': 1, 'episode': 0, 'unwatched': True, 'title': i['title']} for i in watchlist])
				except: pass
			if include_unwatched in (2, 3):
				from caches.favorites_cache import favorites_cache
				try:
					favorites = favorites_cache.get_favorites('tvshow')
					unwatched.extend([{'media_ids': {'tmdb': int(i['tmdb_id'])}, 'season': 1, 'episode': 0, 'unwatched': True, 'title': i['title']} \
									for i in favorites if not int(i['tmdb_id']) in [x['media_ids']['tmdb'] for x in data]])
				except: pass
			data += unwatched
	elif is_combined:
		include_unwatched, include_unaired, nextep_content = 0, settings.nextep_include_unaired(), settings.nextep_method()
		sort_key, sort_direction = settings.nextep_sort_key(), settings.nextep_sort_direction()
		include_airdate = settings.nextep_include_airdate()
		if params.get('prepared') is not None:
			# Supplied by indexers.continue_watching, which has already merged movies in
			# and assigned the global ordering. Nothing to plan here.
			data, return_results = params['prepared'], True
		else:
			resume, upcoming = continue_watching_plan(watched_indicators)
			data = resume + upcoming
		if watched_indicators in (1, 2, 3): resformat, resinsert = '%Y-%m-%dT%H:%M:%S.%fZ', '2000-01-01T00:00:00.000Z'
		else: resformat, resinsert = '%Y-%m-%d %H:%M:%S', '2000-01-01 00:00:00'
		list_type = 'episode.next_trakt' if watched_indicators in (1, 2, 3) else 'episode.next_deadlight'
	elif list_type == 'episode.progress': data = ws.get_in_progress_episodes()
	elif list_type == 'episode.recently_watched': data = ws.get_recently_watched('episode', short_list=True)
	elif list_type == 'episode.trakt':
		from apis.trakt_api import trakt_get_my_calendar
		recently_aired = params.get('recently_aired', None)
		data = trakt_get_my_calendar(recently_aired, get_datetime())
		hidden_list = ws.get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not i['media_ids']['tmdb'] in hidden_list]
		list_type = 'episode.trakt_recently_aired' if recently_aired else 'episode.trakt_calendar'
	elif list_type == 'episode.mdblist':
		# LOCAL PATCH 2026-08-05 (POV 6.08 P2 port): MDBList Calendar, sharing Trakt Calendar's rendering + settings.
		from apis.mdblist_api import mdbl_get_my_calendar
		recently_aired = params.get('recently_aired', None)
		data = mdbl_get_my_calendar(recently_aired, get_datetime(), day_window=calendar_target is not None)
		if calendar_target is not None: data = [i for i in data if _calendar_local_date(i.get('first_aired')) == calendar_target]
		hidden_list = ws.get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not str(i['media_ids']['tmdb']) in map(str, hidden_list)]
		list_type = 'episode.trakt_recently_aired' if recently_aired else 'episode.trakt_calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	else: data, return_results = sorted(params, key=lambda i: i['custom_order']), True
	list_type_compare = list_type.split('episode.')[1]
	list_type_starts_with = list_type_compare.startswith
	# LOCAL PATCH 2026-10-02: a list walking many shows (Next Episodes, Continue Watching) reads every show's watched rows in
	# one query (watched_status.watched_info_episodes_all) and runs on a small pool: the work is CPU and SQLite, and many
	# threads queue on one connection. Short lists keep the per-show query and the full pool.
	watched_all = ws.watched_info_episodes_all(watched_db) if len(data) > 20 else None
	bookmarks_all = ws.get_bookmarks_episodes_all(watched_db) if watched_all is not None else None
	pool_size = min(len(data), settings.max_threads())
	if watched_all is not None: pool_size = min(pool_size, 6)
	# LOCAL PATCH 2026-10-20: rows of the SAME show run one after another (a calendar season drop, a resume + next row): in
	# parallel each missed the cache and fetched the show again. Different shows still run in parallel.
	def _show_key(ep_data):
		try: return str((ep_data.get('media_ids') or {}).get('tmdb') or '') or None
		except Exception: return None
	from collections import Counter
	from threading import Lock
	_show_locks = dict((k, Lock()) for k, n in Counter(_show_key(i) for i in data).items() if k and n > 1)
	_process_row = _process
	def _process_locked(_position, ep_data):
		lock = _show_locks.get(_show_key(ep_data))
		if lock is None: return _process_row(_position, ep_data)
		with lock: return _process_row(_position, ep_data)
	# LOCAL PATCH 2026-11-08: the shows' cached metas in one query before the pool (caches.meta_cache.prefetch)
	try:
		from caches.meta_cache import meta_cache as _mc
		_mc.prefetch('tvshow', [(i.get('media_ids') or {}).get('tmdb') for i in data])
	except Exception: pass
	threads = TaskPool().tasks_enumerate(_process_locked, data, pool_size)
	[i.join() for i in threads]
	def _nextep_sorted(item_list):
		# LOCAL PATCH 2026-10-18: one function for both paths, so Continue Watching follows the Next Episodes sort / Airing Today
		# settings too.
		def func(function):
			if sort_key == 'name': return title_key(function, ignore_articles)
			elif sort_key == 'last_played': return jsondate_to_datetime(function, resformat)
			# a row with a Trakt / TVmaze air time but no TMDb date carries first_aired None: None < str would raise outside any try
			else: return function if function is not None else '2100-12-31'
		if settings.nextep_airing_today():
			# LOCAL PATCH 2026-09-04: single-pass partition, not a filter plus an O(n*m) `not i in airing_today` dict-compare scan.
			airing_today, _rest = [], []
			for i in item_list:
				if date_difference(current_date, jsondate_to_datetime(i.get('first_aired') or '2100-12-31', '%Y-%m-%d').date(), 0):
					airing_today.append(i)
				else: _rest.append(i)
			airing_today.sort(key=lambda i: func(i[sort_key]), reverse=sort_direction)
			item_list = _rest
		else: airing_today = []
		if sort_key == 'last_played':
			unwatched = sorted([i for i in item_list if i['unwatched']], key=lambda i: title_key(i['name'], ignore_articles))
			item_list = sorted([i for i in item_list if not i['unwatched']], key=lambda i: func(i[sort_key]), reverse=sort_direction) + unwatched
		else: item_list = sorted(item_list, key=lambda i: func(i[sort_key]), reverse=sort_direction)
		return airing_today + item_list
	if return_results:
		if is_combined:
			# the upcoming rows take the user's nextep order among themselves, in the slots continue_watching gave them
			# (resume points, movies included, keep theirs)
			nexts = [i for i in item_list if i.get('is_next')]
			if len(nexts) > 1:
				try:
					slots = sorted(i['sort_order'] for i in nexts)
					for slot, i in zip(slots, _nextep_sorted(nexts)): i['sort_order'] = slot
				except Exception: kodi_utils.log_row_error('episodes.continue sort')
		return [(i['list_items'], i['sort_order']) for i in item_list]
	if list_type_starts_with('next_'):
		item_list = _nextep_sorted(item_list)
		# LOCAL PATCH 2026-08-29: on the combined list, a resume point outranks an episode not started; the user's nextep order
		# is kept within each group.
		if is_combined:
			item_list = [i for i in item_list if not i.get('is_next')] + [i for i in item_list if i.get('is_next')]
	else:
		item_list.sort(key=lambda i: i['sort_order'])
		if list_type_compare in ('trakt_calendar', 'trakt_recently_aired'):
			if list_type_compare == 'trakt_calendar': reverse = settings.calendar_sort_order() == 0
			else: reverse = True
			try: item_list = sorted(item_list, key=lambda i: i.get('first_aired', '2100-12-31'), reverse=reverse)
			except:
				item_list = [i for i in item_list if i.get('first_aired') not in (None, 'None', '')]
				item_list = sorted(item_list, key=lambda i: i.get('first_aired'), reverse=reverse)
			if list_type_compare == 'trakt_calendar':
				# LOCAL PATCH 2026-09-04: single-pass partition, not a filter plus an O(n*m) `not i in airing_today` dict-compare scan.
				airing_today, _rest = [], []
				for i in item_list:
					if date_difference(current_date, jsondate_to_datetime(i.get('first_aired', '2100-12-31'), '%Y-%m-%d').date(), 0):
						airing_today.append(i)
					else: _rest.append(i)
				airing_today.sort(key=lambda i: i['first_aired'])
				item_list = _rest
				item_list = airing_today + item_list
	kodi_utils.add_items(handle, [i['list_items'] for i in item_list])
	kodi_utils.set_content(handle, 'episodes')
	kodi_utils.set_category(handle, _get_category_name())
	kodi_utils.end_directory(handle, cacheToDisc=False)
	kodi_utils.set_view_mode('view.episodes_single', 'episodes', is_external)
