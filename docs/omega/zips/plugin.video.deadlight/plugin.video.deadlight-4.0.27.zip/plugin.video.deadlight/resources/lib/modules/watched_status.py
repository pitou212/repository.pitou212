# -*- coding: utf-8 -*-
from datetime import datetime, timezone
from threading import Thread
# LOCAL PATCH 2026-10-19: the three provider APIs load on first use. Every list and widget imports this module, and
# importing all three (with their caches) cost ~15 ms per call, though a TMDb list or widget calls none.
def _lazy(module, name):
	def call(*args, **kwargs):
		import importlib
		return getattr(importlib.import_module(module), name)(*args, **kwargs)
	call.__name__ = name
	return call

trakt_watched_status_mark, trakt_official_status, trakt_progress, trakt_get_hidden_items, trakt_queue_write, trakt_pending_drop, \
	trakt_sync_activities = (_lazy('apis.trakt_api', n) for n in ('trakt_watched_status_mark', 'trakt_official_status', 'trakt_progress',
	'trakt_get_hidden_items', 'trakt_queue_write', 'trakt_pending_drop', 'trakt_sync_activities'))
# LOCAL PATCH 2026-07-23: MDBList as watched_indicators == 2 (see settings.py).
mdbl_watched_unwatched, mdbl_progress, mdbl_get_hidden_items, hide_unhide_mdbl_items, mdbl_queue_progress, mdbl_pending_drop, \
	mdblist_on_cooldown, mdbl_acked_write = (_lazy('apis.mdblist_api', n) for n in ('mdbl_watched_unwatched', 'mdbl_progress',
	'mdbl_get_hidden_items', 'hide_unhide_mdbl_items', 'mdbl_queue_progress', 'mdbl_pending_drop', 'mdblist_on_cooldown', 'mdbl_acked_write'))
# LOCAL PATCH 2026-07-29: SIMKL as watched_indicators == 3. Movies + shows + anime, and "On Hold" as a first-class
# status alongside Watching/Completed/Dropped/PTW.
simkl_mark_watched, simkl_mark_unwatched, simkl_add_to_list, simkl_list = (_lazy('apis.simkl_api', n) for n in
	('simkl_mark_watched', 'simkl_mark_unwatched', 'simkl_add_to_list', 'simkl_list'))
from caches.base_cache import connect_database, set_tombstones, clear_tombstones, write_transaction, kv_decode
from caches.trakt_cache import clear_trakt_collection_watchlist_data
from caches.mdblist_cache import clear_mdbl_collection_watchlist_data
from caches.simkl_cache import clear_simkl_lists_cache
from modules.kodi_utils import kodi_progress_background, sleep, notification, refresh as refresh_lists, get_property, set_property, auto_kodi_refresh, get_visibility, logger
from modules.utils import get_datetime, adjust_premiered_date, sort_for_article, TaskPool, get_current_timestamp
from modules import metadata, settings

def get_database(watched_indicators=None):
	# LOCAL PATCH 2026-07-23 / 2026-07-29: mdblist_db -> watched_indicators == 2, simkl_db -> 3.
	return connect_database({0: 'watched_db', 1: 'trakt_db', 2: 'mdblist_db', 3: 'simkl_db'}[watched_indicators if watched_indicators is not None else settings.watched_indicators()])

def shows_unwatched_since(watched_indicators, since_epoch):
	"""LOCAL PATCH 2026-11-06: TMDb ids of shows with an episode unmarked here after `since_epoch`, from the 'unwatched'
	tombstones (base_cache.set_tombstones; stamped with get_last_played_value, UTC ISO under the providers)."""
	if watched_indicators == 0: return set()
	try:
		cutoff = datetime.fromtimestamp(since_epoch, timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.000Z')
		rows = get_database(watched_indicators).execute("SELECT media_id FROM watched_status WHERE db_type = 'unwatched' AND status > ? "
			"AND media_id LIKE 'episode|%'", (cutoff,)).fetchall()
		return {int(i[0].split('|')[1]) for i in rows}
	except Exception: return set()

def get_hidden_progress_items(watched_indicators):
	try:
		if watched_indicators == 0:
			watched_db = get_database()
			watched_info = watched_db.execute('SELECT status FROM watched_status WHERE db_type = ?', ('hidden_progress_items',)).fetchone()[0]
			return kv_decode(watched_info) or []   # LOCAL PATCH 2026-10-25 (4.0.5): was eval() -- a stored row never runs as code
		elif watched_indicators == 2:
			return mdbl_get_hidden_items('dropped')
		elif watched_indicators == 3:
			# LOCAL PATCH 2026-07-29 / 2026-07-30: SIMKL 'dropped' AND 'hold' both mean stopped watching, hidden from Next
			# Episodes / In Progress. Fetched across BOTH 'shows' and 'anime' (SIMKL's all-items endpoint treats anime as a
			# separate type); TMDb ids unioned.
			hidden = []
			for list_type in ('shows', 'anime'):
				for status in ('dropped', 'hold'):
					try:
						data = simkl_list(list_type, status) or {}
						for it in (data.get(list_type) or []):
							try:
								tmdb = (it.get('show') or {}).get('ids', {}).get('tmdb')
								if tmdb: hidden.append(int(tmdb))
							except Exception: continue
					except Exception: continue
			return hidden
		else: return trakt_get_hidden_items('dropped')
	except: return []

def update_hidden_progress(media_id):
	watched_indicators = settings.watched_indicators()
	current_hidden = get_hidden_progress_items(watched_indicators)
	new_hidden = [i for i in current_hidden if i != int(media_id)]
	if new_hidden == current_hidden: return
	if watched_indicators == 0: function = hide_unhide_progress_items
	elif watched_indicators == 2:
		# MDBList uses hide_unhide_mdbl_items(action, mediatype, media_id, list_type)
		return hide_unhide_mdbl_items('unhide', 'shows', media_id, 'dropped', refresh=False)   # LOCAL PATCH 2026-11-01: as Trakt's 'refresh': 'false'
	elif watched_indicators == 3:
		# LOCAL PATCH 2026-07-29: SIMKL undrop -> move the show back to 'watching'. SIMKL has no "remove from dropped"
		# endpoint; moving to another list removes it from the old one.
		simkl_add_to_list('shows', 'tmdb', int(media_id), 'watching')
		clear_simkl_lists_cache()
		return
	else: from apis.trakt_api import hide_unhide_progress_items as function
	function({'action': 'undrop', 'media_type': 'shows', 'media_id': media_id, 'section': 'dropped', 'refresh': 'false'})

def hide_unhide_progress_items(params):
	action, media_id, refresh = params['action'], int(params.get('media_id', '0')), params.get('refresh', 'true') == 'true'
	current_items = get_hidden_progress_items(0) or []
	if action == 'drop': current_items.append(media_id)
	else: current_items.remove(media_id)
	watched_db = get_database()
	watched_db.execute('INSERT OR REPLACE INTO watched_status VALUES (?, ?, ?)', ('hidden_progress_items', 'hidden', repr(current_items),))
	refresh_container(refresh, media_id)

def get_last_played_value(watched_indicators):
	if watched_indicators == 0: return datetime.now().strftime('%Y-%m-%d %H:%M:%S')
	else: return datetime.now(timezone.utc).replace(tzinfo=None).strftime('%Y-%m-%dT%H:%M:%S.000Z')

# LOCAL PATCH 2026-10-03 (Batch 2): a removal leaves a tombstone so a sync already downloading cannot put the
# row back (base_cache.replace_watched_rows / replace_progress_rows); re-adding the row lifts it. Provider
# databases only: watched_indicators 0 has no sync. rows: (db_type, media_id, season, episode, ...).
def _mark_removed(watched_indicators, dbcon, kind, rows):
	if watched_indicators == 0 or not rows: return
	try: set_tombstones(dbcon, kind, rows, get_last_played_value(watched_indicators))
	except Exception: pass

def _mark_restored(watched_indicators, dbcon, kind, rows):
	if watched_indicators == 0 or not rows: return
	try: clear_tombstones(dbcon, kind, rows)
	except Exception: pass

def make_batch_insert(action, media_type, media_id, season, episode, last_played, title):
	if action == 'mark_as_watched': return (media_type, media_id, season, episode, last_played, title)
	else: return (media_type, media_id, season, episode)

# LOCAL PATCH 2026-11-01: with the title, only the widgets that list it (kodi_utils.reload_widgets) plus the progress lists
# (Continue Watching, In Progress, Next Episodes, Recently Watched), which gain or lose it; without, every DeadLight widget.
def refresh_container(refresh=True, tmdb_id=None):
	if refresh: refresh_lists(titles=tmdb_id)

def _bulk_show_fields(media_ids, mpaa_region):
	"""LOCAL PATCH 2026-11-08: {tmdb_id: (total_aired_eps, status)} for the cached, unexpired, region-current shows among
	media_ids, in one query per 500 -- the progress scans read only these two fields, not a full tvshow_meta per watched
	show. Blank entries, legacy (non-JSON) rows and anything unexpected are left out,
	so the caller reads them the old way; any database error answers {} (everything the old way)."""
	out = {}
	try:
		from caches.base_cache import connect_database, get_timestamp
		dbcon, now, ids = connect_database('metacache_db'), get_timestamp(), [str(i) for i in media_ids]
		for start in range(0, len(ids), 500):
			chunk = ids[start:start + 500]
			rows = dbcon.execute("SELECT tmdb_id, json_extract(meta, '$.total_aired_eps'), json_extract(meta, '$.status'), "
				"json_extract(meta, '$.mpaa_region'), json_extract(meta, '$.blank_entry') FROM metadata WHERE db_type = 'tvshow' "
				"AND expires > ? AND json_valid(meta) AND tmdb_id IN (%s)" % ','.join('?' * len(chunk)), [now] + chunk).fetchall()
			for tmdb_id, aired, status, region, blank in rows:
				if blank or (region is not None and region != mpaa_region): continue
				out[tmdb_id] = (aired, status or '')
	except Exception: return {}
	return out

def active_tvshows_information(status_type):
	def _process(item):
		media_id = item['media_id']
		if media_id in show_fields: total_aired_eps, airing_status = show_fields[media_id]
		else:
			meta = metadata.tvshow_meta('tmdb_id', media_id, api_key, mpaa_region, get_datetime())
			total_aired_eps, airing_status = meta.get('total_aired_eps'), meta.get('status', '')
		watched_status = get_watched_status_tvshow(watched_info[media_id], total_aired_eps)[0]
		if status_type == 'watched':
			if watched_status == 1:
				if not include_other and airing_status not in ('Ended', 'Canceled'): return
				results_append(item)
		else:
			if watched_status == 0: results_append(item)
			elif include_other and airing_status not in ('Ended', 'Canceled'): results_append(item)
	results = []
	results_append = results.append
	watched_info = watched_info_tvshow()
	if status_type == 'progress':
		hidden_items = get_hidden_progress_items(settings.watched_indicators())
		for k in hidden_items: watched_info.pop(str(k), None)
	api_key, mpaa_region = settings.tmdb_api_key(), settings.mpaa_region()
	watched_items = watched_info.items()
	data = [v for k, v in watched_items]
	show_fields = _bulk_show_fields([i['media_id'] for i in data], mpaa_region)
	progress_location = settings.tv_progress_location()
	if status_type == 'watched': include_other = progress_location in (0, 2)
	else: include_other = progress_location in (1, 2)
	threads = TaskPool().tasks(_process, data, min(len(data), settings.max_threads()))
	[i.join() for i in threads]
	return results

def watched_info_movie(watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		watched_info = watched_db.execute('SELECT media_id, title, last_played FROM watched WHERE db_type = ?', ('movie',)).fetchall()
		return dict([(i[0], {'media_id': i[0], 'title': i[1], 'last_played': i[2]}) for i in watched_info])
	except: return {}

def get_watched_status_movie(watched_info, media_id):
	if not watched_info: return 0
	try:
		watched = 1 if media_id in watched_info else 0
		return watched
	except: return 0

def get_bookmarks_movie(watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		info = watched_db.execute('SELECT media_id, resume_point, curr_time, resume_id FROM progress WHERE db_type = ?', ('movie',)).fetchall()
		info = dict([(i[0], {'media_id': i[0], 'resume_point': i[1], 'curr_time': i[2], 'resume_id': i[3]}) for i in info])
	except: info = {}
	return info

def get_progress_status_movie(progress_info, media_id):
	try: percent = str(round(float(progress_info[media_id]['resume_point'])))
	except: percent = None
	return percent

def watched_info_tvshow(watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		# LOCAL PATCH 2026-08-05 (Red Light R4 port): exclude S0 specials from COUNT(*) so playcount/progress align with
		# total_aired_eps (which already excludes S0); S0 rows would also skew MAX(season/episode) for get_next_episodes.
		exclude_specials = settings.exclude_specials_from_progress()
		if exclude_specials:
			data = watched_db.execute('SELECT media_id, season, episode, title, MAX(last_played), COUNT(*) AS COUNTER FROM watched WHERE db_type = ? AND season != 0 GROUP BY media_id',
									('episode',)).fetchall()
		else:
			data = watched_db.execute('SELECT media_id, season, episode, title, MAX(last_played), COUNT(*) AS COUNTER FROM watched WHERE db_type = ? GROUP BY media_id',
									('episode',)).fetchall()
		return dict([(i[0], {'media_id': i[0], 'season': i[1], 'episode': i[2], 'title': i[3], 'last_played': i[4], 'total_played': i[5]}) for i in data])
	except: return {}

def get_watched_status_tvshow(watched_info, aired_eps):
	if not watched_info: return 0, 0, aired_eps
	try:
		watched = min(watched_info['total_played'], aired_eps)
		unwatched = aired_eps - watched
		if watched >= aired_eps: playcount = 1
		else: playcount = 0
		return playcount, watched, unwatched
	except: return 0, 0, aired_eps

def get_progress_status_tvshow(watched, aired_eps):
	try: progress = int((float(watched)/aired_eps)*100) or 1
	except: progress = 1
	return progress

def watched_info_season(media_id, watched_db=None):
	if not watched_db: watched_db = get_database()
	try: watched_info = dict(watched_db.execute('SELECT season, COUNT(*) AS COUNTER FROM watched WHERE db_type = ? AND media_id = ? GROUP BY media_id, season',
							('episode', str(media_id))).fetchall())
	except: watched_info = {}
	return watched_info

def get_watched_status_season(watched_info, aired_eps):
	if not watched_info: return 0, 0, aired_eps
	try:
		watched = min(watched_info, aired_eps)
		unwatched = aired_eps - watched
		if watched >= aired_eps: playcount = 1
		else: playcount = 0
		return playcount, watched, unwatched
	except: return 0, 0, aired_eps

def get_progress_status_season(watched, aired_eps):
	try: progress = int((float(watched)/aired_eps)*100)
	except: progress = 0
	return progress

# LOCAL PATCH 2026-10-25 (4.0.5): a set, not a list -- get_watched_status_episode tests (season, episode) membership once
# per episode, and get_next walks every remaining episode of a long show (~1100 x ~1100 lookups). Every consumer only
# iterates or tests membership.
def watched_info_episode(media_id, watched_db=None):
	if not watched_db: watched_db = get_database()
	try: watched_info = set(watched_db.execute('SELECT season, episode FROM watched WHERE db_type = ? AND media_id = ?', ('episode', str(media_id))).fetchall())
	except: watched_info = set()
	return watched_info

# LOCAL PATCH 2026-10-02: every show's watched episodes in ONE query, for lists that walk many shows (Next Episodes,
# Continue Watching). {media_id (str): [(season, episode), ...]} -- per show the same rows, order and values as
# watched_info_episode(media_id). Per-show queries from up to 32 pool threads queued on one connection.
def watched_info_episodes_all(watched_db=None):
	if not watched_db: watched_db = get_database()
	result = {}
	try:
		for media_id, season, episode in watched_db.execute('SELECT media_id, season, episode FROM watched WHERE db_type = ?', ('episode',)).fetchall():
			result.setdefault(str(media_id), set()).add((season, episode))   # LOCAL PATCH 2026-10-25 (4.0.5): a set, see watched_info_episode
	except: return None
	return result

def get_watched_status_episode(watched_info, season_episode):
	if season_episode in watched_info: return 1
	return 0

def get_bookmarks_episode(media_id, season, watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		info = watched_db.execute('SELECT resume_point, curr_time, resume_id, episode FROM progress WHERE db_type = ? AND media_id = ? AND season = ?',
			('episode', str(media_id), int(season))).fetchall()
		info = dict([(i[3], {'resume_point': i[0], 'curr_time': i[1], 'resume_id': i[2]}) for i in info])
	except: info = {}
	return info

def get_bookmarks_episodes_all(watched_db=None):
	"""LOCAL PATCH 2026-10-03 (3.0.8): every episode resume point in one query -- {(media_id, season): {episode: {...}}}.
	For the long episode lists, which read them one show at a time (watched_info_episodes_all is the same idea)."""
	if not watched_db: watched_db = get_database()
	result = {}
	try:
		for media_id, season, episode, resume_point, curr_time, resume_id in watched_db.execute(
				'SELECT media_id, season, episode, resume_point, curr_time, resume_id FROM progress WHERE db_type = ?', ('episode',)).fetchall():
			try: key = (str(media_id), int(season))
			except (TypeError, ValueError): continue
			result.setdefault(key, {})[episode] = {'resume_point': resume_point, 'curr_time': curr_time, 'resume_id': resume_id}
	except: return None
	return result

def get_bookmarks_all_episode(media_id, total_seasons, watched_db=None):
	if not watched_db: watched_db = get_database()
	all_seasons_info = {}
	for season in range(1, total_seasons + 1):
		try:
			season_info = get_bookmarks_episode(media_id, season, watched_db)
			all_seasons_info[season] = season_info
		except: pass
	return all_seasons_info

def get_progress_status_episode(progress_info, episode):
	try: percent = str(round(float(progress_info[episode]['resume_point'])))
	except: percent = None
	return percent

def get_progress_status_all_episode(progress_info, season, episode):
	try: percent = str(round(float(progress_info[season][episode]['resume_point'])))
	except: percent = None
	return percent

def get_resume_seconds(progress, duration):
	return float(int(float(progress)/100 * duration))


def erase_bookmark(media_type, media_id, season='', episode='', refresh='false'):
	try:
		watched_indicators = settings.watched_indicators()
		watched_db = get_database(watched_indicators)
		# LOCAL PATCH 2026-10-03 (Batch 2): only with a real resume_id. A row DeadLight wrote itself has 0, and a clear for
		# sync/playback/0 (Trakt) or {'id': 0} (MDBList) clears nothing.
		if watched_indicators == 1:
			trakt_pending_drop('progress', media_type, media_id, season, episode)   # LOCAL PATCH 2026-10-25 (4.0.5): never re-send it
			try:
				if media_type == 'episode': resume_id = get_bookmarks_episode(str(media_id), season, watched_db)[int(episode)]['resume_id']
				else: resume_id = get_bookmarks_movie()[str(media_id)]['resume_id']
				if resume_id:
					sleep(1000)
					# LOCAL PATCH 2026-10-25 (4.0.5): a refused clear is queued -- the next sync would otherwise bring it back
					if not trakt_progress('clear_progress', media_type, media_id, 0, season, episode, resume_id):
						trakt_queue_write('clear', media_type, media_id, season, episode, resume_id=resume_id)
			except (KeyError, IndexError, TypeError, ValueError): pass   # no resume point here
			except Exception as e: logger('erase_bookmark', 'Trakt clear failed: %s' % e)
		elif watched_indicators == 2:
			mdbl_pending_drop(media_type, media_id, season, episode)   # LOCAL PATCH 2026-09-24: never re-send it
			try:
				if media_type == 'episode': resume_id = get_bookmarks_episode(str(media_id), season, watched_db)[int(episode)]['resume_id']
				else: resume_id = get_bookmarks_movie()[str(media_id)]['resume_id']
				if resume_id:
					sleep(1000)
					# LOCAL PATCH 2026-10-25: acknowledged like the watched mark. The clear moves the paused stamp; done bare, it runs
					# BEFORE mark_episode's acked watched mark, which then finds the snapshot stale -- and the next build re-downloads the
					# whole history and reloads every widget.
					mdbl_acked_write(lambda: mdbl_progress('clear_progress', media_type, media_id, 0, season, episode, resume_id),
						('paused_at', 'episode_paused_at'))
			except (KeyError, IndexError, TypeError, ValueError): pass   # no resume point here
			except Exception as e: logger('erase_bookmark', 'MDBList clear failed: %s' % e)
		watched_db.execute('DELETE FROM progress where db_type = ? and media_id = ? and season = ? and episode = ?', (media_type, media_id, season, episode))
		_mark_removed(watched_indicators, watched_db, 'unprogress', [(media_type, media_id, season, episode)])
		refresh_container(refresh == 'true', media_id)
	except Exception as e: logger('erase_bookmark', '%s %s S%sE%s: %s' % (media_type, media_id, season, episode, e))   # LOCAL PATCH 2026-10-25 (4.0.5): was silent

def batch_erase_bookmark(watched_indicators, insert_list, action):
	try:
		watched_db = get_database(watched_indicators)
		if action == 'mark_as_watched': modified_list = [(i[0], i[1], i[2], i[3]) for i in insert_list]
		else: modified_list = insert_list
		if watched_indicators in (1, 2):
			progress_fn = trakt_progress if watched_indicators == 1 else mdbl_progress
			# LOCAL PATCH 2026-10-25 (4.0.5): the resume ids are read HERE, before the thread starts and before the DELETE below --
			# looked up in the thread, they raced the delete and only one remote resume point was cleared. One query per season.
			# The thread only sends.
			seasons, to_clear = {}, []
			for i in insert_list:
				try:
					key = (str(i[1]), i[2])
					if key not in seasons: seasons[key] = get_bookmarks_episode(str(i[1]), i[2], watched_db)
					resume_id = seasons[key].get(int(i[3]), {}).get('resume_id')
				except (TypeError, ValueError): resume_id = None
				to_clear.append((i, resume_id))
			def _process():
				for i, resume_id in to_clear:
					if watched_indicators == 2: mdbl_pending_drop(i[0], i[1], i[2], i[3])   # LOCAL PATCH 2026-09-24
					else: trakt_pending_drop('progress', i[0], i[1], i[2], i[3])
					if not resume_id: continue   # LOCAL PATCH 2026-10-03 (Batch 2): see erase_bookmark
					try:
						sleep(1000)
						ok = progress_fn('clear_progress', i[0], i[1], 0, i[2], i[3], resume_id)
						if watched_indicators == 1 and not ok: trakt_queue_write('clear', i[0], i[1], i[2], i[3], resume_id=resume_id)
					except Exception as e: logger('batch_erase_bookmark', '%s S%sE%s: %s' % (i[1], i[2], i[3], e))
			Thread(target=_process).start()
		with write_transaction(watched_db):   # LOCAL PATCH 2026-10-03 (Batch 2): one write, never half-seen by a sync
			watched_db.executemany('DELETE FROM progress where db_type = ? and media_id = ? and season = ? and episode = ?', modified_list)
			_mark_removed(watched_indicators, watched_db, 'unprogress', modified_list)
	except Exception as e: logger('batch_erase_bookmark', str(e))   # LOCAL PATCH 2026-10-25 (4.0.5): was silent

def set_bookmark(params):
	try:
		media_type, tmdb_id, curr_time, total_time = params.get('media_type'), params.get('tmdb_id'), params.get('curr_time'), params.get('total_time')
		refresh = False if params.get('from_playback', 'false') == 'true' else True
		title, season, episode = params.get('title'), params.get('season'), params.get('episode')
		adjusted_current_time = float(curr_time) - 5
		resume_point = round(adjusted_current_time/float(total_time)*100,1)
		watched_indicators = settings.watched_indicators()
		if watched_indicators == 1:
			# LOCAL PATCH 2026-10-25 (4.0.5): local-first, as MDBList below: the row is written first; a refused save (network,
			# 5xx, 429) is queued and re-sent at the next sync (trakt_api._PENDING_KEY). With script.trakt scrobbling, it saves the
			# pause itself and only the local row is written here.
			dbcon = get_database(watched_indicators)
			dbcon.execute('INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
						(media_type, tmdb_id, season, episode, str(resume_point), str(curr_time), get_last_played_value(watched_indicators), 0, title))
			if trakt_official_status(media_type) == False: pass
			elif trakt_progress('set_progress', media_type, tmdb_id, resume_point, season, episode):
				trakt_pending_drop('progress', media_type, tmdb_id, season, episode)
				trakt_sync_activities()
			else: trakt_queue_write('progress', media_type, tmdb_id, season, episode, percent=resume_point, curr_time=str(curr_time), title=title)
		elif watched_indicators == 2:
			# LOCAL PATCH 2026-09-24: the local row FIRST, so resume works whatever MDBList says, then the save; a refused save is
			# queued and re-sent (mdblist_api._PENDING_KEY). On a known cooldown the call is not made (it would only 429 again). A
			# save MDBList takes supersedes any older queued one. The local row has no MDBList resume_id; the next sync brings it.
			dbcon = get_database(watched_indicators)
			dbcon.execute('INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
						(media_type, tmdb_id, season, episode, str(resume_point), str(curr_time), get_last_played_value(watched_indicators), 0, title))
			if not mdblist_on_cooldown() and mdbl_progress('set_progress', media_type, tmdb_id, resume_point, season, episode, refresh_mdb=True):
				mdbl_pending_drop(media_type, tmdb_id, season, episode)
			else:
				mdbl_queue_progress(media_type, tmdb_id, resume_point, season, episode, curr_time, title)
		elif watched_indicators == 3:
			# LOCAL PATCH 2026-07-29: SIMKL has no resume-point API -- recorded locally only in simkl_db.progress for the resume
			# bar. The real scrobble at playback stop (>=90%) is modules/player.py's.
			erase_bookmark(media_type, tmdb_id, season, episode)
			last_played = get_last_played_value(watched_indicators)
			dbcon = get_database(watched_indicators)
			dbcon.execute('INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
						(media_type, tmdb_id, season, episode, str(resume_point), str(curr_time), last_played, 0, title))
		else:
			erase_bookmark(media_type, tmdb_id, season, episode)
			last_played = get_last_played_value(watched_indicators)
			dbcon = get_database(watched_indicators)
			dbcon.execute('INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
						(media_type, tmdb_id, season, episode, str(resume_point), str(curr_time), last_played, 0, title))
		# LOCAL PATCH 2026-10-03 (Batch 2): a resume point saved again is no longer a cleared one (SIMKL's branch tombstones it
		# through erase_bookmark a few lines up).
		_mark_restored(watched_indicators, get_database(watched_indicators), 'unprogress', [(media_type, tmdb_id, season, episode)])
		refresh_container(refresh, tmdb_id)
	except Exception as e: logger('set_bookmark', '%s: %s' % (params.get('tmdb_id'), e))   # LOCAL PATCH 2026-10-25 (4.0.5): was silent

def mark_movie(params):
	action, media_type = params.get('action'), 'movie'
	refresh, from_playback = params.get('refresh', 'true') == 'true', params.get('from_playback', 'false') == 'true'
	if from_playback: refresh = False
	tmdb_id, title = params.get('tmdb_id'), params.get('title')
	watched_indicators = settings.watched_indicators()
	# LOCAL PATCH 2026-09-22 (Red Light 2.6.2 port): on the PLAYBACK path the local tick is written BEFORE the provider
	# call, because every provider branch below returns notification('Error') on failure and would skip the local write.
	# The trailing write is left unconditional: both statements are idempotent (INSERT OR REPLACE / DELETE).
	# Only from_playback: a manual mark failing shows an Error toast with no local change. The local table is a MIRROR of
	# the provider, so a remote write that really failed is undone by the next sync -- hence the retry queue too.
	if from_playback:
		watched_status_mark(watched_indicators, media_type, tmdb_id, action, title=title)
	if watched_indicators == 1:
		trakt_pending_drop(('progress', 'mark'), media_type, tmdb_id)   # LOCAL PATCH 2026-10-25 (4.0.5): this mark supersedes them
		if from_playback and trakt_official_status(media_type) == False: sleep(1000)
		elif not trakt_watched_status_mark(action, 'movies', tmdb_id):
			# LOCAL PATCH 2026-10-25 (4.0.5): from playback the local tick is already written -- queue the mark for the next sync
			# (see trakt_api._PENDING_KEY). A manual mark keeps its Error toast.
			if not from_playback: return notification('Error')
			trakt_queue_write('mark', media_type, tmdb_id, action=action, title=title)
		clear_trakt_collection_watchlist_data('watchlist', media_type)
	elif watched_indicators == 2:
		# LOCAL PATCH 2026-10-03 (3.0.8): mdbl_acked_write -- the sync after this mark skips the full re-download
		if not mdbl_acked_write(lambda: mdbl_watched_unwatched(action, 'movies', tmdb_id), ('watched_at',)): return notification('Error')
		clear_mdbl_collection_watchlist_data('watchlist')
	elif watched_indicators == 3:
		# LOCAL PATCH 2026-07-29: SIMKL mark movie watched/unwatched.
		fn = simkl_mark_watched if action == 'mark_as_watched' else simkl_mark_unwatched
		if not fn('movies', 'tmdb', int(tmdb_id)): return notification('Error')
		clear_simkl_lists_cache()
	watched_status_mark(watched_indicators, media_type, tmdb_id, action, title=title)
	refresh_container(refresh, tmdb_id)

def mark_tvshow(params):
	title, action, tmdb_id = params.get('title', ''), params.get('action'), params.get('tmdb_id')
	try: tvdb_id = int(params.get('tvdb_id', '0'))
	except: tvdb_id = 0
	watched_indicators = settings.watched_indicators()
	progress_backround = kodi_progress_background()
	progress_backround.create('[B]Please Wait..[/B]', '')
	if watched_indicators == 1:
		if not trakt_watched_status_mark(action, 'shows', tmdb_id, tvdb_id): return progress_backround.close(), notification('Error')
		clear_trakt_collection_watchlist_data('watchlist', 'tvshow')
	elif watched_indicators == 2:
		if not mdbl_acked_write(lambda: mdbl_watched_unwatched(action, 'shows', tmdb_id, tvdb_id), ('episode_watched_at',)): return progress_backround.close(), notification('Error')
		clear_mdbl_collection_watchlist_data('watchlist')
	elif watched_indicators == 3:
		# LOCAL PATCH 2026-07-29: SIMKL mark whole show — no seasons kwarg = mark all.
		fn = simkl_mark_watched if action == 'mark_as_watched' else simkl_mark_unwatched
		if not fn('shows', 'tmdb', int(tmdb_id)): return progress_backround.close(), notification('Error')
		clear_simkl_lists_cache()
	current_date = get_datetime()
	insert_list = []
	insert_append = insert_list.append
	meta = metadata.tvshow_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
	season_data = meta['season_data']
	season_data = [i for i in season_data if i['season_number'] > 0]
	total = len(season_data)
	last_played = get_last_played_value(watched_indicators)
	for count, item in enumerate(season_data, 1):
		season_number = item['season_number']
		ep_data = metadata.episodes_meta(season_number, meta)
		for ep in ep_data:
			season_number = ep['season']
			ep_number = ep['episode']
			display = '%s - S%.2dE%.2d' % (title, int(season_number), int(ep_number))
			progress_backround.update(int(float(count)/float(total)*100), '[B]Please Wait..[/B]', display)
			episode_date, premiered = adjust_premiered_date(ep['premiered'], settings.date_offset())
			# LOCAL PATCH 2026-11-07 (Red Light 2.9.5): Mark Unwatched also clears an unaired episode ticked early
			if episode_date and current_date < episode_date and action == 'mark_as_watched': continue
			insert_append(make_batch_insert(action, 'episode', tmdb_id, season_number, ep_number, last_played, title))
	batch_watched_status_mark(watched_indicators, insert_list, action)
	progress_backround.close()
	refresh_container(True, tmdb_id)

def mark_season(params):
	season = int(params.get('season'))
	# LOCAL PATCH 2026-10-19: specials can be marked as a season too. Trakt, MDBList and SIMKL take season 0 like any other;
	# the AniList / MAL season push is skipped below, as a special is not the regular cour's progress.
	insert_list = []
	insert_append = insert_list.append
	action, title, tmdb_id = params.get('action'), params.get('title'), params.get('tmdb_id')
	try: tvdb_id = int(params.get('tvdb_id', '0'))
	except: tvdb_id = 0
	# LOCAL PATCH 2026-08-29: optional cour range, for anime seasons split into parts. A cour is a SLICE of a TMDb season,
	# so the season-level provider call would mark the sibling cours too. With an offset and length the range is exact:
	# TMDb episodes offset+1 .. offset+length within `season`, pushed as an episode LIST (all three providers accept it).
	try:
		cour_offset = int(params.get('cour_offset', '') or -1)
		cour_len = int(params.get('cour_len', '') or 0)
	except (TypeError, ValueError):
		cour_offset, cour_len = -1, 0
	is_cour = cour_offset >= 0 and cour_len > 0
	cour_eps = list(range(cour_offset + 1, cour_offset + cour_len + 1)) if is_cour else []
	watched_indicators = settings.watched_indicators()
	if watched_indicators == 1:
		if is_cour:
			if not trakt_watched_status_mark(action, 'episodes', tmdb_id, tvdb_id, season, None, 'tmdb', cour_eps): return notification('Error')
		elif not trakt_watched_status_mark(action, 'season', tmdb_id, tvdb_id, season): return notification('Error')
		clear_trakt_collection_watchlist_data('watchlist', 'tvshow')
	elif watched_indicators == 2:
		if is_cour:
			if not mdbl_acked_write(lambda: mdbl_watched_unwatched(action, 'episodes', tmdb_id, tvdb_id, season, None, 'tmdb', cour_eps),
									('episode_watched_at',)): return notification('Error')
		elif not mdbl_acked_write(lambda: mdbl_watched_unwatched(action, 'season', tmdb_id, tvdb_id, season), ('episode_watched_at',)): return notification('Error')
		clear_mdbl_collection_watchlist_data('watchlist')
	elif watched_indicators == 3:
		# LOCAL PATCH 2026-07-29: SIMKL marks a whole season when the episodes list is omitted. A cour names its episodes.
		if is_cour: seasons = [{'number': int(season), 'episodes': [{'number': e} for e in cour_eps]}]
		else: seasons = [{'number': int(season)}]
		fn = simkl_mark_watched if action == 'mark_as_watched' else simkl_mark_unwatched
		if not fn('shows', 'tmdb', int(tmdb_id), seasons=seasons): return notification('Error')
		clear_simkl_lists_cache()
	progress_backround = kodi_progress_background()
	progress_backround.create('[B]Please Wait..[/B]', '')
	current_date = get_datetime()
	meta = metadata.tvshow_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
	ep_data = metadata.episodes_meta(season, meta)
	last_played = get_last_played_value(watched_indicators)
	if is_cour: ep_data = [i for i in ep_data if i['episode'] in cour_eps]
	aired_count = 0
	for count, item in enumerate(ep_data, 1):
		season_number = item['season']
		ep_number = item['episode']
		display = '%s - S%.2dE%.2d' % (title, season_number, ep_number)
		episode_date, premiered = adjust_premiered_date(item['premiered'], settings.date_offset())
		# LOCAL PATCH 2026-11-07 (Red Light 2.9.5, #290): an unaired episode can be ticked by hand (early releases), so
		# Mark Unwatched clears it too; Mark Watched still skips future dates.
		unaired = bool(episode_date and current_date < episode_date)
		if unaired and action == 'mark_as_watched': continue
		if not unaired: aired_count += 1
		progress_backround.update(int(float(count) / float(len(ep_data)) * 100), '[B]Please Wait..[/B]', display)
		insert_append(make_batch_insert(action, 'episode', tmdb_id, season_number, ep_number, last_played, title))
	batch_watched_status_mark(watched_indicators, insert_list, action)
	# aired_count is the aired episodes in the range -- unaired ones are left out -- so a part-aired season reports
	# honest progress instead of COMPLETED, and an unwatch resets only the AniList / MAL entries that have aired.
	if season != 0:   # LOCAL PATCH 2026-10-19: see the top of mark_season
		_anilist_mark_season(tmdb_id, season, action, aired_count, params.get('anilist_id'), cour_eps)
		_mal_mark_season(tmdb_id, season, action, aired_count, cour_eps)   # LOCAL PATCH 2026-10-02: own gate, own call
	progress_backround.close()
	refresh_container(True, tmdb_id)

def _anime_entry_ids(tmdb_id, season, ep, joined=True):
	"""LOCAL PATCH 2026-11-01: (anilist, mal, episode within that entry) of one TMDb episode: Fribb's cour, or for a special
	(season 0, which Fribb maps to nothing) the Watch Order's air-date mapping (anilist_lists.special_entry_for_episode) --
	marking specials sent nothing to AniList / MAL."""
	from caches import fribb_mappings
	if int(season) == 0:
		from indexers.anilist_lists import special_entry_for_episode
		e = special_entry_for_episode(tmdb_id, ep) or {}
		return e.get('anilist'), e.get('mal'), e.get('cour_ep')
	c = fribb_mappings.find_cour_by_tmdb_coords(int(tmdb_id), int(season), ep) or {}
	if not joined: return c.get('anilist'), c.get('mal'), c.get('cour_ep')
	# LOCAL PATCH 2026-11-07: the entry's own episode number (episode_card.entry_episode) -- Monogatari S3E6 is 7, not 6
	from modules.episode_card import entry_episode
	return c.get('anilist'), c.get('mal'), entry_episode(tmdb_id, season, ep, c) or c.get('cour_ep')

def _entry_counts(tmdb_id, season, eps, slot):
	"""LOCAL PATCH 2026-11-07: {entry id: progress} for a season / cour mark of TMDb episodes `eps` (slot 0 = AniList,
	1 = MAL). Progress is the count of marked episodes in the entry, plus the episodes the entry counts that TMDb leaves out
	(recaps) up to the last one marked -- measured once per entry, at its last marked episode (entry_episode - cour_ep).
	Monogatari S3 marked whole: 23 TMDb episodes -> 26, the entry's length, so it is COMPLETED as it should be."""
	per_entry, last = {}, {}
	for ep in eps:
		ids = _anime_entry_ids(tmdb_id, season, ep, joined=False)
		if ids[slot]: per_entry[ids[slot]], last[ids[slot]] = per_entry.get(ids[slot], 0) + 1, (ep, ids[2])
	for _id, (ep, raw) in last.items():
		try:
			raw, in_entry = int(raw or 0), int(_anime_entry_ids(tmdb_id, season, ep)[2] or 0)
			if raw and in_entry > raw: per_entry[_id] += in_entry - raw
		except (TypeError, ValueError): pass
	return per_entry

def _anime_mark_episode(tmdb_id, season, episode, action):
	"""LOCAL PATCH 2026-11-01: Mark Watched / Unwatched on ONE episode, pushed to AniList and MyAnimeList. Only playback
	(player._anilist_scrobble / _mal_scrobble) and season / cour marks reached them; marking a single episode reached
	neither. Watched: the episode's place in its entry, raise-only (marking an old episode never lowers newer progress,
	as playback). Unwatched: progress set to just before it, only when the list counts it watched now (unmarking episode
	7 at progress 3 must not raise it). Not for marks made by the player itself (from_playback), which push on their own."""
	try:
		from modules.settings import anilist_user_active, mal_user_active
		al_on, mal_on = anilist_user_active(), mal_user_active()
		if not (al_on or mal_on): return
		anilist_id, mal_id, cour_ep = _anime_entry_ids(tmdb_id, season, episode)
		if not cour_ep: return
		cour_ep = int(cour_ep)
		if al_on and anilist_id:
			from apis.anilist_api import anilist_set_progress, _entry_progress
			if action == 'mark_as_watched': anilist_set_progress(anilist_id, cour_ep, raise_only=True)
			else:
				now = _entry_progress(anilist_id)
				if now and (now[0] or 0) >= cour_ep: anilist_set_progress(anilist_id, cour_ep - 1)
		if mal_on and mal_id:
			from apis.mal_api import mal_set_progress, mal_list_status
			if action == 'mark_as_watched': mal_set_progress(mal_id, cour_ep, raise_only=True)
			else:
				now = mal_list_status(mal_id) or {}
				if (now.get('num_episodes_watched') or 0) >= cour_ep: mal_set_progress(mal_id, cour_ep - 1)
	except Exception as e:
		from modules.kodi_utils import logger
		logger('anime episode mark', str(e))

def _anilist_mark_season(tmdb_id, season, action, marked_count, anilist_id=None, cour_eps=None):
	"""Push a season/cour mark to AniList. Best-effort -- never blocks the local mark.

	LOCAL PATCH 2026-08-29. AniList is not a watched_indicators provider; player._anilist_scrobble covers only
	playback, so marks need this push.

	Its own path because AniList does not speak TMDb numbering: progress counts WITHIN an entry, and an entry is one
	cour (Frieren S01E30 is entry 182255 progress 2). A whole-cour mark completes the entry outright.

	marked_count excludes unaired episodes, so a part-aired season reports real progress and
	anilist_set_progress picks CURRENT rather than COMPLETED. Unwatching sends 0, which it
	maps to PLANNING.
	"""
	try:
		from modules.settings import anilist_user_active
		if not anilist_user_active(): return
		if action == 'mark_as_watched' and not marked_count: return
		from apis.anilist_api import anilist_set_progress
		eps = (cour_eps or list(range(1, marked_count + 1)))[:marked_count]   # unaired episodes are the skipped tail
		if anilist_id:
			# LOCAL PATCH 2026-11-07: plus the recaps the entry counts (_entry_counts), when the marked episodes are this entry's
			count = 0
			if action == 'mark_as_watched':
				try: count = _entry_counts(tmdb_id, season, eps, 0).get(int(anilist_id), marked_count)
				except Exception: count = marked_count
			anilist_set_progress(anilist_id, count)
			return
		# LOCAL PATCH 2026-10-09: an unsplit season, or a season row that merges several cours of one release season (Stone
		# Ocean's three parts), spans several AniList entries -- each gets the episodes of the range that are its own.
		per_entry = _entry_counts(tmdb_id, season, eps, 0)   # LOCAL PATCH 2026-11-07: recaps the entry counts (Monogatari S3)
		for _al, count in per_entry.items():
			anilist_set_progress(_al, count if action == 'mark_as_watched' else 0)
	except Exception as e:
		from modules.kodi_utils import logger
		logger('anilist season mark', str(e))

def _mal_mark_season(tmdb_id, season, action, marked_count, cour_eps=None):
	"""LOCAL PATCH 2026-10-02: the same season / cour mark, pushed to MyAnimeList. Best-effort, like the AniList one.

	Each MAL entry in range gets its own episodes -- one entry per cour, as on AniList. Sets the count
	exactly (not raise-only): marking or unmarking is the user asking for that number."""
	try:
		from modules.settings import mal_user_active
		if not mal_user_active(): return
		if action == 'mark_as_watched' and not marked_count: return
		from apis.mal_api import mal_set_progress
		# LOCAL PATCH 2026-10-09: per entry, as _anilist_mark_season -- a merged season row spans several MAL entries
		eps = (cour_eps or list(range(1, marked_count + 1)))[:marked_count]
		per_entry = _entry_counts(tmdb_id, season, eps, 1)   # LOCAL PATCH 2026-11-07: recaps the entry counts (Monogatari S3)
		for _mal, count in per_entry.items():
			mal_set_progress(_mal, count if action == 'mark_as_watched' else 0)
	except Exception as e:
		from modules.kodi_utils import logger
		logger('mal season mark', str(e))


def mark_episode(params):
	season, episode, title = int(params.get('season')), int(params.get('episode')), params.get('title')
	# LOCAL PATCH 2026-10-18: specials are marked like any episode. Progress / Next Episodes still honour
	# exclude_specials_from_progress.
	action, media_type = params.get('action'), 'episode'
	refresh, from_playback = params.get('refresh', 'true') == 'true', params.get('from_playback', 'false') == 'true'
	if from_playback: refresh = False
	tmdb_id = params.get('tmdb_id')
	try: tvdb_id = int(params.get('tvdb_id', '0'))
	except: tvdb_id = 0
	watched_indicators = settings.watched_indicators()
	# LOCAL PATCH 2026-09-22 (Red Light 2.6.2 port): on the PLAYBACK path the local tick is written first -- see the same
	# block in mark_movie.
	if from_playback:
		watched_status_mark(watched_indicators, media_type, tmdb_id, action, season, episode, title)
	if watched_indicators == 1:
		trakt_pending_drop(('progress', 'mark'), media_type, tmdb_id, season, episode)   # LOCAL PATCH 2026-10-25 (4.0.5): superseded
		if from_playback and trakt_official_status(media_type) == False: sleep(1000)
		elif not trakt_watched_status_mark(action, media_type, tmdb_id, tvdb_id, season, episode):
			# LOCAL PATCH 2026-10-25 (4.0.5): queued from playback, as mark_movie
			if not from_playback: return notification('Error')
			trakt_queue_write('mark', media_type, tmdb_id, season, episode, action=action, tvdb_id=tvdb_id, title=title)
		clear_trakt_collection_watchlist_data('watchlist', 'tvshow')
	elif watched_indicators == 2:
		if not mdbl_acked_write(lambda: mdbl_watched_unwatched(action, 'episode', tmdb_id, tvdb_id, season, episode), ('episode_watched_at',)): return notification('Error')
		# LOCAL PATCH 2026-10-03 (3.0.8): no watchlist clear on a single episode (it forced a full watchlist re-download after
		# every episode). If MDBList ever moves the watchlist, watchlisted_at moves and the sync clears it. Movie/show/season
		# marks keep theirs.
	elif watched_indicators == 3:
		# LOCAL PATCH 2026-07-29: SIMKL mark single episode.
		seasons = [{'number': int(season), 'episodes': [{'number': int(episode)}]}]
		fn = simkl_mark_watched if action == 'mark_as_watched' else simkl_mark_unwatched
		if not fn('shows', 'tmdb', int(tmdb_id), seasons=seasons): return notification('Error')
		clear_simkl_lists_cache()
		# LOCAL PATCH 2026-09-19: if that episode ended a cour, put the next one on Watching -- SIMKL files each cour as its own
		# entry. Self-gates on anime via Fribb, no-op mid-cour; never on an unwatch.
		if action == 'mark_as_watched':
			try:
				from apis.simkl_api import simkl_advance_cour
				if simkl_advance_cour(tmdb_id, season, episode): clear_simkl_lists_cache()
			except Exception: pass
	watched_status_mark(watched_indicators, media_type, tmdb_id, action, season, episode, title)
	if params.get('from_playback') != 'true': _anime_mark_episode(tmdb_id, season, episode, action)   # LOCAL PATCH 2026-11-01
	update_hidden_progress(tmdb_id)
	refresh_container(refresh, tmdb_id)

def unmark_previous_episode(params):
	try:
		season, episode = int(params.get('season')), int(params.get('episode'))
		if episode == 1:
			season = params['season'] = season - 1
			meta = metadata.tvshow_meta('tmdb_id', params.get('tmdb_id'), settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
			params['episode'] = episode = next((i for i in meta['season_data'] if i['season_number'] == season))['episode_count']
		else: episode = params['episode'] = episode - 1
		return mark_episode(params)
	except Exception as e:
		logger('unmark_previous_episode', str(e))
		notification('Error')

def watched_status_mark(watched_indicators, media_type='', media_id='', action='', season='', episode='', title=''):
	try:
		last_played = get_last_played_value(watched_indicators)
		dbcon = get_database(watched_indicators)
		row = [(media_type, media_id, season, episode)]
		if action == 'mark_as_watched':
			dbcon.execute('INSERT OR REPLACE INTO watched VALUES (?, ?, ?, ?, ?, ?)', (media_type, media_id, season, episode, last_played, title))
			_mark_restored(watched_indicators, dbcon, 'unwatched', row)
		elif action == 'mark_as_unwatched':
			dbcon.execute('DELETE FROM watched WHERE (db_type = ? and media_id = ? and season = ? and episode = ?)', (media_type, media_id, season, episode))
			_mark_removed(watched_indicators, dbcon, 'unwatched', row)   # LOCAL PATCH 2026-10-03 (Batch 2)
		erase_bookmark(media_type, media_id, season, episode)
	except Exception as e:
		logger('watched_status_mark', '%s %s %s S%sE%s: %s' % (action, media_type, media_id, season, episode, e))   # LOCAL PATCH 2026-10-25 (4.0.5)
		notification('Error')

def batch_watched_status_mark(watched_indicators, insert_list, action):
	try:
		dbcon = get_database(watched_indicators)
		# LOCAL PATCH 2026-10-03 (Batch 2): one transaction with its tombstones, so a sync never sees half a season
		with write_transaction(dbcon):
			if action == 'mark_as_watched':
				dbcon.executemany('INSERT OR IGNORE INTO watched VALUES (?, ?, ?, ?, ?, ?)', insert_list)
				_mark_restored(watched_indicators, dbcon, 'unwatched', insert_list)
			elif action == 'mark_as_unwatched':
				dbcon.executemany('DELETE FROM watched WHERE (db_type = ? and media_id = ? and season = ? and episode = ?)', insert_list)
				_mark_removed(watched_indicators, dbcon, 'unwatched', insert_list)
		batch_erase_bookmark(watched_indicators, insert_list, action)
	except Exception as e:
		logger('batch_watched_status_mark', '%s %d rows: %s' % (action, len(insert_list or []), e))   # LOCAL PATCH 2026-10-25 (4.0.5)
		notification('Error')

# LOCAL PATCH 2026-08-05 (Red Light R3 port): refresh provider watched data before building In-Progress + Next-Episodes
# lists so episodes watched elsewhere surface without waiting for the 60 min sync tick.
# LOCAL PATCH 2026-08-29: throttled. Comparing timestamps needs a network round-trip every call (~0.3 s, several times a
# widget build), and service.py's monitors poll the same endpoint hourly anyway.
# The guard is a WINDOW PROPERTY, not a module global: with reuselanguageinvoker false every widget is its own process,
# so a global would throttle nothing; a window property is shared, so two widgets sync once between them.
# Staleness is safe: ws.mark_episode writes the local table at playback end, so this only pulls changes made elsewhere.
# Failure is silent -- falls back to cached DB.
_SYNC_GUARD_PROP = 'deadlight.provider_sync_at'
_SYNC_GUARD_SECONDS = 60

def _refresh_provider_watched():
	try:
		# LOCAL PATCH 2026-10-25: not while a video plays -- Kodi rebuilds Continue Watching several times as the next episode
		# starts, and the sync's widget reload would draw nothing visible. The guard is not stamped, so the rebuild at playback
		# end syncs.
		if get_visibility('Player.HasVideo'): return
		wi = settings.watched_indicators()
		now = get_current_timestamp()
		try:
			# Provider id is part of the value: switching watched_indicators must not inherit the previous provider's timestamp.
			last_wi, last_at = get_property(_SYNC_GUARD_PROP).split(':')
			if int(last_wi) == wi and 0 <= now - int(last_at) < _SYNC_GUARD_SECONDS: return
		except Exception: pass   # unset or malformed -> fall through and sync
		# Stamped BEFORE the sync so two widgets starting together do not both find the guard cold. Narrows the race rather
		# than closing it; losing it just means two syncs.
		set_property(_SYNC_GUARD_PROP, '%s:%s' % (wi, now))
		if wi == 1: from apis.trakt_api import trakt_sync_activities as sync
		elif wi == 2: from apis.mdblist_api import mdbl_sync_activities as sync
		elif wi == 3: from apis.simkl_api import simkl_sync_activities as sync
		else: return
		# LOCAL PATCH 2026-09-26: off the render path. The list renders from the local DB and the sync runs behind it; only when
		# it pulled changes ('success') do the widgets reload, which re-enters here inside the guard window and so cannot loop.
		# Non-daemon thread: the plugin process stays alive until it finishes.
		Thread(target=_sync_then_refresh, args=(sync,)).start()
	except Exception: pass

def _sync_then_refresh(sync):
	try:
		# LOCAL PATCH 2026-10-03: through the coalescer, like every other automatic reload (a bare kodi_refresh() is logged
		# nowhere and folded into nothing).
		if sync() == 'success': auto_kodi_refresh('provider sync')
	except Exception: pass


def get_next_episodes(nextep_content):
	_refresh_provider_watched()
	watched_db = get_database()
	if nextep_content == 0:
		data = watched_db.execute('''WITH cte AS (SELECT *, ROW_NUMBER() OVER (PARTITION BY media_id ORDER BY season DESC, episode DESC) rn FROM watched WHERE db_type == ?)
									SELECT media_id, season, episode, title, last_played FROM cte WHERE rn = 1''', ('episode',)).fetchall()
	else:
		data = watched_db.execute('SELECT media_id, season, episode, title, MAX(last_played), COUNT(*) AS COUNTER FROM watched WHERE db_type = ? GROUP BY media_id',
								('episode',)).fetchall()
	data = [{'media_ids': {'tmdb': int(i[0])}, 'season': int(i[1]), 'episode': int(i[2]), 'title': i[3], 'last_played': i[4]} for i in data]
	data.sort(key=lambda x: (x['last_played']), reverse=True)
	return data
	
def get_next(season, episode, watched_info, season_data, nextep_content):
	# LOCAL PATCH 2026-08-05 (Red Light R1 port): absolute-numbered anime (One Piece S23E1170) reports an episode number
	# beyond any single season's episode_count, and the naive +1 rolls to an out-of-range season+1. If the watched number
	# exceeds every season's count, treat it as absolute and map it back by walking season_data.
	# LOCAL PATCH 2026-10-15: specials stay specials -- no absolute remap and no +1 rollover into S1E1.
	if season == 0:
		try: count = next((i.get('episode_count') for i in season_data or [] if i.get('season_number') == 0), None)
		except Exception: count = None
		return (0, episode + 1) if count and episode and episode < count else (None, None)
	if season_data and episode:
		try:
			ordered_seasons = sorted([i for i in season_data if i.get('season_number', 0) != 0], key=lambda x: x['season_number'])
			max_season_count = max([i.get('episode_count', 0) for i in ordered_seasons] or [0])
			if episode > max_season_count and ordered_seasons:
				# Absolute-numbered — walk seasons summing episode_count to find true (season, ep)
				running_total = 0
				for s in ordered_seasons:
					ec = s.get('episode_count', 0)
					if running_total + ec >= episode:
						season = s.get('season_number')
						episode = episode - running_total
						break
					running_total += ec
		except Exception: pass
	if episode == 0: episode = 1
	elif nextep_content == 0:
		try:
			episode_count = next((i['episode_count'] for i in season_data if i['season_number'] == season), None)
			# LOCAL PATCH 2026-10-15: a season season_data does not list has no next (otherwise the except below returns the
			# CURRENT episode as next, replaying what was just watched).
			if episode_count is None: return None, None
			rollover = not episode < episode_count
			# LOCAL PATCH 2026-10-03: no rolling into a season the show does not list -- each would cost an episodes_meta miss
			# (cached 96 h, all expiring together into a burst of TMDb requests). season_data is already in the show meta.
			if rollover and not any(i.get('season_number') == season + 1 and (i.get('episode_count') or 0) > 0 for i in season_data):
				return None, None
			season = season if not rollover else season + 1
			episode = episode + 1 if not rollover else 1
		except Exception: return None, None   # LOCAL PATCH 2026-10-15: see above -- never the current episode as 'next'
	else:
		try:
			next_episode = 0
			relevant_seasons = [i for i in season_data if i['season_number'] >= season]
			for item in relevant_seasons:
				episode_count, item_season = item['episode_count'], item['season_number']
				if season == item_season:
					if episode >= episode_count:
						item_season, next_episode = None, None
						continue
					episode_range = range(episode + 1, episode_count + 1)
				else: episode_range = range(1, episode_count + 1)
				next_episode = next((i for i in episode_range if not get_watched_status_episode(watched_info, (item_season, i))), None)
				if next_episode: break
			# LOCAL PATCH 2026-10-18: else the bare except returns the input pair -- the current episode offered as next.
			if next_episode: season, episode = item_season, next_episode
			else: season, episode = None, None
		except: return None, None
	return season, episode

def get_in_progress_movies(dummy_arg, page_no):
	dbcon = get_database()
	data = dbcon.execute('SELECT media_id, title, last_played FROM progress WHERE db_type = ?', ('movie',)).fetchall()
	data = [{'media_id': i[0], 'title': i[1], 'last_played': i[2]} for i in data if not i[0] == '']
	if settings.lists_sort_order('progress') == 0: data = sort_for_article(data, 'title', settings.ignore_articles())
	else: data = sorted(data, key=lambda x: x['last_played'], reverse=True)
	return data

def get_in_progress_tvshows(dummy_arg, page_no):
	_refresh_provider_watched()  # LOCAL PATCH 2026-08-05 (Red Light R3 port)
	results = active_tvshows_information('progress')
	if settings.lists_sort_order('progress') == 0: results = sort_for_article(results, 'title', settings.ignore_articles())
	else: results = sorted(results, key=lambda x: x['last_played'], reverse=True)
	return results

# LOCAL PATCH 2026-09-04: accept a pre-computed hidden set, so a Continue Watching render does not run
# get_hidden_progress_items three times (expensive under SIMKL: four simkl_list() reads each). Default None preserves
# every existing call site's behaviour.
def get_in_progress_episodes(hidden=None):
	dbcon = get_database()
	data = dbcon.execute('SELECT media_id, season, episode, resume_point, last_played, title FROM progress WHERE db_type = ?', ('episode',)).fetchall()
	if hidden is None: hidden = get_hidden_progress_items(settings.watched_indicators()) or []
	hidden = hidden if isinstance(hidden, set) else set(hidden)
	if hidden:
		def _hidden(mid):
			try: return int(mid) in hidden
			except: return False
		data = [i for i in data if not _hidden(i[0])]
	episode_list = [{'media_ids': {'tmdb': i[0]}, 'season': int(i[1]), 'episode': int(i[2]), 'resume_point': float(i[3]), 'date': i[4], 'title': i[5]} for i in data]
	if settings.lists_sort_order('progress') == 0: episode_list = sort_for_article(episode_list, 'title', settings.ignore_articles())
	else: episode_list.sort(key=lambda k: k['date'], reverse=True)
	return episode_list

# LOCAL PATCH 2026-10-06: the Dropped lists under Movies, TV Shows and Anime, from the selected watched provider:
# SIMKL's 'dropped' lists, MDBList's sync/dropped, Trakt's hidden 'dropped', or the local hidden list. Only SIMKL drops
# movies, so Movies > Dropped is shown only with SIMKL. Provider order, duplicates removed; the anime / TV split is the
# list builder's (is_anime_list).
def get_dropped_items(media_type, page_no):
	chosen, ids = settings.watched_indicators(), []
	try:
		if chosen == 3:
			if settings.simkl_user_active():
				from indexers.simkl_lists import _split_items
				for list_type in (('movies',) if media_type == 'movie' else ('shows', 'anime')):
					movies, shows = _split_items((simkl_list(list_type, 'dropped') or {}).get(list_type) or [], list_type)
					ids.extend(i['tmdb'] for i in (movies if media_type == 'movie' else shows))
		elif media_type == 'movie': pass   # Trakt, MDBList and the local list drop shows only
		elif chosen == 2:
			if settings.mdblist_user_active(): ids = mdbl_get_hidden_items('dropped') or []
		elif chosen == 1:
			if settings.trakt_user_active(): ids = trakt_get_hidden_items('dropped') or []
		else: ids = get_hidden_progress_items(0) or []
	except Exception: ids = []
	seen, results = set(), []
	for i in ids:
		try: i = str(int(i))
		except (TypeError, ValueError): continue
		if i not in seen:
			seen.add(i)
			results.append({'media_id': i})
	return results

def get_watched_items(media_type, page_no):
	if media_type == 'tvshow': results = active_tvshows_information('watched')
	else: results = [v for k,v in watched_info_movie().items()]
	if settings.lists_sort_order('watched') == 0: results = sort_for_article(results, 'title', settings.ignore_articles())
	else: results = sorted(results, key=lambda x: x['last_played'], reverse=True)
	return results

def get_recently_watched(media_type, short_list=0):
	watched_indicators = settings.watched_indicators()
	if media_type == 'movie':
		watched_movies = watched_info_movie().items()
		data = sorted([v for k,v in watched_movies], key=lambda x: x['last_played'], reverse=True)
		if short_list: data = data[:20]
	elif media_type == 'tvshow':
		watched_tvshows = watched_info_tvshow().items()
		data = sorted([v for k,v in watched_tvshows], key=lambda x: x['last_played'], reverse=True)
		if short_list: data = data[:20]
	else:
		dbcon = get_database(watched_indicators)
		data = dbcon.execute('SELECT media_id, season, episode, title, last_played FROM watched WHERE db_type = ? ORDER BY last_played DESC', ('episode',)).fetchall()
		data = [{'media_ids': {'tmdb': int(i[0])}, 'season': int(i[1]), 'episode': int(i[2]), 'title': i[3], 'last_played': i[4]}
					for i in data]
		if short_list: data = data[:20]
	return data
