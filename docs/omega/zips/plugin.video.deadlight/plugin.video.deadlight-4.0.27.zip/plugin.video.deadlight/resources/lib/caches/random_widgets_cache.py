# -*- coding: utf-8 -*-
from caches.base_cache import BaseCache

class RandomWidgets(BaseCache):
	def __init__(self):
		BaseCache.__init__(self, 'random_widgets_db', 'random_widgets')
