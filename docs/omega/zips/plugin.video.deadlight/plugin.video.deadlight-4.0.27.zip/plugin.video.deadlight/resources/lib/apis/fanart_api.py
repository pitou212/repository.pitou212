# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-06: Fanart.tv integration for curated backdrops (AF3's fanart cycler). Per-title JSON:
#   Movies:  data['moviebackground'] -> [{id, url, lang, likes}, ...]
#   TV:      data['showbackground']  -> [{id, url, lang, likes}, ...]
# Cached 7 days (art rarely changes); any error degrades to an empty list -- callers merge with TMDb backdrops.
# Needs a free Personal API Key (https://fanart.tv/get-an-api-key/), stored as `deadlight.fanarttv_api`. Rate limit:
# 30 req / 5 min for personal keys -- the 7-day per-title cache keeps us well under it.

from caches.main_cache import cache_object
from caches.settings_cache import get_setting
from modules.kodi_utils import make_session, logger
from modules.utils import safe_err   # LOCAL PATCH 2026-10-25 (4.0.5): str(e) of a request error carries the url and api_key

_API_BASE = 'https://webservice.fanart.tv/v3'
_TIMEOUT = 10
_CACHE_HOURS = 168  # 7 days
_session = make_session(_API_BASE)


# LOCAL PATCH 2026-10-03 (3.0.8): both read once per process -- they ran on every artwork read of every title.
_SETTINGS = {}

def _enabled():
	"""LOCAL PATCH 2026-08-07: master toggle — off skips fanart.tv even when key set."""
	if 'enabled' not in _SETTINGS: _SETTINGS['enabled'] = get_setting('deadlight.fanarttv.enabled', 'true') == 'true'
	return _SETTINGS['enabled']


def _api_key():
	if 'key' not in _SETTINGS:
		v = (get_setting('deadlight.fanarttv_api', '') or '').strip()
		_SETTINGS['key'] = v if v and v != 'empty_setting' else ''
	return _SETTINGS['key']


def _get_json(url):
	"""HTTP fetcher for cache_object(json=False): returns the payload dict itself (LOCAL PATCH 2026-11-01 (cleanup): was
	wrapped in an _Answer object only so json=True could call .json() on it)."""
	response = _session.get(url, timeout=_TIMEOUT)
	# LOCAL PATCH 2026-10-03 (Batch 3): 404 is fanart.tv's real "no art for this title" and stays cached 7 days. Anything
	# else that is not a 200 (bad key 401, rate limit, 5xx) raises so its error body stays out of the cache; every caller
	# catches and returns no art for this call only.
	if response.status_code not in (200, 404): raise ValueError('fanart.tv answered %s' % response.status_code)
	# LOCAL PATCH 2026-10-19: a no-art answer is stored as a marker, not empty -- base_cache.cache_ttl keeps an empty answer
	# only 0.3 h, so every title without art would ask again 18 minutes later. Readers look up art keys, which the marker
	# has none of.
	data = {}
	if response.status_code == 200:
		try: data = response.json()
		except ValueError: data = {}
	return data if isinstance(data, dict) and data else {'_none': 1}


# LOCAL PATCH 2026-10-03 (3.0.8): the TV and movie payloads are read up to six times per cold title (backgrounds,
# clearlogo, poster, landscape, season art), each a main_cache SELECT + decode, so they are kept per process. A failed
# fetch is remembered for the call too (one timeout, not six) and re-raised to each caller.
_MEMO = {}

def _payload(key, url):
	if key not in _MEMO:
		try: _MEMO[key] = (True, cache_object(_get_json, key, url, json=False, expiration=_CACHE_HOURS))
		except Exception as e: _MEMO[key] = (False, e)
	ok, value = _MEMO[key]
	if not ok: raise value
	return value


def _pick_backgrounds(payload, key, cap=8):
	"""Sort by likes desc, prefer language-neutral (00) then English (en),
	strip duplicates, return up to `cap` URLs.
	Fanart.tv `lang` values: '00' = no language / clean, 'en'/'fr'/… = with text."""
	if not isinstance(payload, dict): return []
	items = payload.get(key) or []
	if not items: return []
	def _rank(item):
		lang = (item.get('lang') or '').lower()
		lang_score = 0 if lang == '00' else (1 if lang in ('', 'en') else 2)
		try: likes = int(item.get('likes') or 0)
		except (TypeError, ValueError): likes = 0
		return (lang_score, -likes)
	ordered = sorted(items, key=_rank)
	out, seen = [], set()
	for it in ordered:
		u = it.get('url')
		if not u or u in seen: continue
		seen.add(u)
		out.append(u)
		if len(out) >= cap: break
	return out


def fanart_movie_backgrounds(imdb_id, cap=8):
	"""Return up to `cap` fanart.tv `moviebackground` URLs for the given IMDb id.
	Silent on any failure (no key / HTTP error / no coverage) — returns []."""
	if not _enabled() or not _api_key(): return []
	if not imdb_id or not str(imdb_id).startswith('tt'): return []
	try:
		url = '%s/movies/%s?api_key=%s' % (_API_BASE, imdb_id, _api_key())
		cache_key = 'fanart_movie_%s' % imdb_id
		data = _payload(cache_key, url)
		return _pick_backgrounds(data, 'moviebackground', cap)
	except Exception as e:
		logger('fanart.tv', 'movie fetch failed %s: %s' % (imdb_id, safe_err(e)))
		return []


def fanart_tvshow_backgrounds(tvdb_id, cap=8):
	"""Return up to `cap` fanart.tv `showbackground` URLs for the given TVDB id.
	Silent on any failure — returns []."""
	if not _enabled() or not _api_key(): return []
	if not tvdb_id or str(tvdb_id) in ('', 'None', '0'): return []
	try:
		url = '%s/tv/%s?api_key=%s' % (_API_BASE, tvdb_id, _api_key())
		cache_key = 'fanart_tvshow_%s' % tvdb_id
		data = _payload(cache_key, url)
		return _pick_backgrounds(data, 'showbackground', cap)
	except Exception as e:
		logger('fanart.tv', 'tv fetch failed %s: %s' % (tvdb_id, safe_err(e)))
		return []


# LOCAL PATCH 2026-08-27: clearlogos from fanart.tv, preferred over TMDb's unranked images.logos[0]. fanart.tv's are
# community-curated with language tags and votes, reliably transparent PNGs, and exist where TMDb has none. Free: the
# payload is already cached (7 days) for the fanart cycler under the same key.

# Highest-resolution array first. `clearlogo`/`movielogo` are the older, smaller uploads
# and are only reached when no HD one exists.
_TV_LOGO_KEYS = ('hdtvlogo', 'clearlogo')
_MOVIE_LOGO_KEYS = ('hdmovielogo', 'movielogo')


def _pick_logo(payload, keys, lang='en', only=False):
	"""Best single logo URL, or ''.

	Ranking differs from _pick_backgrounds on purpose. A background is best when it is
	textless, so that function puts lang '00' first. A clearlogo IS the title as artwork,
	so the wanted language comes first and '00' is only a fallback; within a language the
	most-liked wins.
	"""
	if not isinstance(payload, dict): return ''
	def _rank(item):
		l = (item.get('lang') or '').lower()
		lang_score = 0 if l == lang else (1 if l in ('', '00') else 2)
		try: likes = int(item.get('likes') or 0)
		except (TypeError, ValueError): likes = 0
		return (lang_score, -likes)
	for key in keys:
		items = [i for i in (payload.get(key) or []) if isinstance(i, dict) and i.get('url')]
		# LOCAL PATCH 2026-09-24: only=True -- a logo in `lang` or nothing (metadata._chain_art's English pass)
		if only: items = [i for i in items if (i.get('lang') or '').lower() == lang]
		if items: return sorted(items, key=_rank)[0]['url']
	return ''


def fanart_tvshow_clearlogo(tvdb_id, english_only=False):
	"""fanart.tv clearlogo URL for a TVDB id, or '' when unavailable."""
	if not _enabled() or not _api_key(): return ''
	if not tvdb_id or str(tvdb_id) in ('', 'None', '0'): return ''
	try:
		url = '%s/tv/%s?api_key=%s' % (_API_BASE, tvdb_id, _api_key())
		data = _payload('fanart_tvshow_%s' % tvdb_id, url)
		return _pick_logo(data, _TV_LOGO_KEYS, only=english_only)
	except Exception as e:
		logger('fanart.tv', 'tv logo failed %s: %s' % (tvdb_id, safe_err(e)))
		return ''


def fanart_movie_clearlogo(imdb_id, english_only=False):
	"""fanart.tv clearlogo URL for an IMDb id, or '' when unavailable."""
	if not _enabled() or not _api_key(): return ''
	if not imdb_id or not str(imdb_id).startswith('tt'): return ''
	try:
		url = '%s/movies/%s?api_key=%s' % (_API_BASE, imdb_id, _api_key())
		data = _payload('fanart_movie_%s' % imdb_id, url)
		return _pick_logo(data, _MOVIE_LOGO_KEYS, only=english_only)
	except Exception as e:
		logger('fanart.tv', 'movie logo failed %s: %s' % (imdb_id, safe_err(e)))
		return ''


# LOCAL PATCH 2026-09-26: posters and landscapes from fanart.tv too, so the "Most Liked (fanart.tv)" artwork setting
# governs every piece, not only logos and backgrounds. Same cached payload, no extra request. Ranked like a logo, not a
# background: a poster or `tvthumb` carries the title as text, so the English one is wanted first.
_TV_POSTER_KEYS = ('tvposter',)
_TV_LANDSCAPE_KEYS = ('tvthumb',)
_MOVIE_POSTER_KEYS = ('movieposter',)
_MOVIE_LANDSCAPE_KEYS = ('moviethumb',)


def _tv_payload(tvdb_id):
	if not _enabled() or not _api_key(): return None
	if not tvdb_id or str(tvdb_id) in ('', 'None', '0'): return None
	url = '%s/tv/%s?api_key=%s' % (_API_BASE, tvdb_id, _api_key())
	return _payload('fanart_tvshow_%s' % tvdb_id, url)


def _movie_payload(imdb_id):
	if not _enabled() or not _api_key(): return None
	if not imdb_id or not str(imdb_id).startswith('tt'): return None
	url = '%s/movies/%s?api_key=%s' % (_API_BASE, imdb_id, _api_key())
	return _payload('fanart_movie_%s' % imdb_id, url)


def fanart_tvshow_poster(tvdb_id):
	try: return _pick_logo(_tv_payload(tvdb_id), _TV_POSTER_KEYS)
	except Exception as e:
		logger('fanart.tv', 'tv poster failed %s: %s' % (tvdb_id, safe_err(e)))
		return ''


def fanart_tvshow_landscape(tvdb_id):
	try: return _pick_logo(_tv_payload(tvdb_id), _TV_LANDSCAPE_KEYS)
	except Exception as e:
		logger('fanart.tv', 'tv landscape failed %s: %s' % (tvdb_id, safe_err(e)))
		return ''


def fanart_movie_poster(imdb_id):
	try: return _pick_logo(_movie_payload(imdb_id), _MOVIE_POSTER_KEYS)
	except Exception as e:
		logger('fanart.tv', 'movie poster failed %s: %s' % (imdb_id, safe_err(e)))
		return ''


def fanart_movie_landscape(imdb_id):
	try: return _pick_logo(_movie_payload(imdb_id), _MOVIE_LANDSCAPE_KEYS)
	except Exception as e:
		logger('fanart.tv', 'movie landscape failed %s: %s' % (imdb_id, safe_err(e)))
		return ''


# LOCAL PATCH 2026-09-26: per-season art. `seasonposter` and `seasonthumb` entries carry a
# `season` field in TVDB numbering -- the numbering Fribb's cour_season uses -- so a cour
# row can get its own season's art. 'all' and missing seasons are show-wide and skipped.
# seasonthumb is the only per-season LANDSCAPE any provider here has: TVDB's season
# artwork is posters (type 7) and banners (type 6) only, and TMDb has neither.
def fanart_season_art_cached(tvdb_id):
	"""LOCAL PATCH 2026-10-20: fanart_season_art() when the show's payload is already cached (or read this call), else None
	-- never a request. See tvdb_api.season_posters_cached."""
	key = 'fanart_tvshow_%s' % tvdb_id
	try:
		from caches.main_cache import main_cache
		if key not in _MEMO and main_cache.get(key) is None: return None
	except Exception: return None
	return fanart_season_art(tvdb_id)


def fanart_season_art(tvdb_id):
	"""{'poster': {season: url}, 'landscape': {season: url}}, empty dicts when unavailable."""
	out = {'poster': {}, 'landscape': {}}
	try:
		data = _tv_payload(tvdb_id)
		if not isinstance(data, dict): return out
		for field, key in (('poster', 'seasonposter'), ('landscape', 'seasonthumb')):
			by_season = {}
			for item in data.get(key) or []:
				if not isinstance(item, dict) or not item.get('url'): continue
				number = str(item.get('season') or '')
				if number.isdigit(): by_season.setdefault(int(number), []).append(item)
			for number, items in by_season.items():
				url = _pick_logo({key: items}, (key,))
				if url: out[field][number] = url
	except Exception as e:
		logger('fanart.tv', 'season art failed %s: %s' % (tvdb_id, safe_err(e)))
	return out
