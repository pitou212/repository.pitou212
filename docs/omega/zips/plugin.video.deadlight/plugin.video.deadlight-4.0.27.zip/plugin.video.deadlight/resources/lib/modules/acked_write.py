# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-11-08: a write DeadLight makes to a watched provider, acknowledged in the provider's activity snapshot so the
# next sync does not re-download what the write itself changed. One copy for MDBList, Trakt and SIMKL (it was MDBList-only, as
# mdblist_api.mdbl_acked_write, since 2026-10-03: a mark moved episode_watched_at, the next sync saw the stamp move and fetched
# the whole history -- 9,010 rows, 4.5-8.3 s -- to learn about the mark it had just made; Trakt and SIMKL still did that after
# every episode).
#
# The rule: poll the activity before the write; only when it still equals the stored snapshot (nothing changed elsewhere since
# the last sync) and, after the write, only keys this write is expected to move have moved, is the new activity stored as seen.
# Anything else -- a key moved before the write, an unexpected key moved, a poll failed -- leaves the snapshot alone, so the
# next sync downloads exactly as before. The blind spot is a change made elsewhere to the same key in the ~0.5 s between the
# polls; each provider's sync re-downloads its history once a day after an acknowledgement (on_ack records when) to cover it.


def flatten(activity, prefix=''):
	"""{'episodes': {'watched_at': t}} -> {'episodes.watched_at': t}; a flat dict is returned as it is."""
	out = {}
	for k, v in (activity or {}).items():
		key = '%s.%s' % (prefix, k) if prefix else str(k)
		if isinstance(v, dict): out.update(flatten(v, key))
		else: out[key] = v
	return out


def acked_write(write, moves, poll, stored, store, keys=None, on_ack=None, label=''):
	"""write(): the provider write, truthy on success (returned as is). moves: the activity keys (flattened; a family name
	covers what is under it: 'tv_shows' -> 'tv_shows.watching') this write may move. poll(): the provider's current activity or
	None. stored(): the stored snapshot or None. store(activity): record it as seen. keys: compare only these (flattened) keys --
	the known ones, so a field the provider adds does not count; None compares everything. on_ack(): after an acknowledgement."""
	def _view(activity):
		flat = flatten(activity)
		return flat if keys is None else dict((k, flat.get(k)) for k in keys)
	try:
		snapshot, before = stored(), poll()
		quiet = isinstance(snapshot, dict) and isinstance(before, dict) and _view(before) == _view(snapshot)
	except Exception: quiet, before = False, None
	result = write()
	if not (result and quiet): return result
	try:
		after = poll()
		if not isinstance(after, dict): return result
		was, now = _view(before), _view(after)
		moved = [k for k in set(was) | set(now) if was.get(k) != now.get(k)]
		if moved and all(any(k == m or k.startswith(m + '.') for m in moves) for k in moved):
			store(after)
			if on_ack: on_ack()
			from modules.kodi_utils import logger
			logger(label or 'acked write', 'own write acknowledged (%s): no re-download' % ', '.join(sorted(moved)))
	except Exception: pass
	return result
