"""
	Fenomscrapers Module
"""

import re
from string import printable
from magneto.modules import cleantitle
from magneto.modules.undesirables import Undesirables
from magneto.modules.control import homeWindow, setting as getSetting


SCR = ('dvdscr', 'screener', '.scr.', '.r5', '.r6')
CAM = ('1xbet', 'betwin', '.cam.', 'camrip', 'cam.rip', 'dvdcam', 'dvd.cam', 'dvdts', 'hdcam', '.hd.cam', '.hctc', '.hc.tc', '.hdtc',
				'.hd.tc', 'hdts', '.hd.ts', 'hqcam', '.hg.cam', '.tc.', '.tc1', '.tc7', '.ts.', '.ts1', '.ts7', 'tsrip', 'telecine', 'telesync', 'tele.sync')

LANG = ('arabic', 'bengali', 'bgaudio', 'castellano', 'chinese', 'dutch', 'finnish', 'french', 'german', 'greek', 'indonesian', 'hebrew', 'italian', 'korean', 'latino', 'polish',
				'portuguese', 'russian', 'swedish', 'spanish', 'tamil', 'telugu', 'truefrench', 'truespanish', 'turkish')
ABV_LANG = ('.ara.', '.ces.', '.chi.', '.chs.', '.cze.', '.dan.', '.de.', '.deu.', '.dut.', '.ell.', '.es.', '.esl.', '.esp.', '.fi.', '.fin.', '.fr.', '.fra.', '.fre.', '.frn.', '.gai.', '.ger.', '.gle.', '.gre.',
						'.gtm.', '.he.', '.heb.', '.hi.', '.hin.', '.hun.', '.hindi.', '.ind.', '.iri.', '.it.', '.ita.', '.ja.', '.jap.', '.jpn.', '.ko.', '.kor.', '.lat.', '.nl.', '.lit.', '.nld.', '.nor.', '.pl.', '.pol.',
						'.pt.', '.por.', '.ru.', '.rus.', '.som.', '.spa.', '.sv.', '.sve.', '.swe.', '.tha.', '.tr.', '.tur.', '.uae.', '.uk.', '.ukr.', '.vi.', '.vie.', '.zh.', '.zho.')
DUBBED = ('bengali.dub', 'dublado', 'dubbed', 'pldub')
SUBS = ('subita', 'subfrench', 'subspanish', 'subtitula', 'swesub', 'nl.subs')

ENG_CHECK = ('.eng.', '.en.', 'english', 'multi')
SRT_CHECK = ('with.srt', '.avi', '.mkv', '.mp4')

UNDESIRABLES = ['400p.octopus', '720p.octopus', '1080p.octopus', 'alexfilm', 'amedia', 'audiobook', 'baibako', 'bigsinema', 'bonus.disc', 'casstudio.tv', 'courage.bambey',
				'.cbr', '.cbz', 'coldfilm', 'dilnix', 'dutchreleaseteam', 'e.book.collection', 'empire.minutemen', 'eniahd', '.exe', 'exkinoray', 'extras.only',
				'gears.media', 'gearsmedia', 'good.people', 'gostfilm', 'hamsterstudio', 'hdrezka', 'hdtvrip', 'hurtom', 'idea.film', 'ideafilm', 'jaskier', 'kapatejl6', 'kb.1080p',
				'kb.720p', 'kb.400p', 'kerob', 'kinokopilka', 'kravec', 'kuraj.bambey', 'lakefilm', 'le.production', 'lostfilm', 'megapeer', 'minutemen.empire', 'newstudio',
				'omskbird', '.ost.', 'paravozik', 'profix.media', 'rifftrax', 'sample', 'soundtrack', 'subtitle.only', 'sunshinestudio', 'teaser', 'trailer', 'tumbler.studio',
				'tvshows', 'ultradox', 'viruseproject', 'vostfr', 'vo.stfr', 'web.dlrip', 'webdlrip', 'wish666', 'pa.web.dl', '.p.web.dl', '.d.web.dl', '.dt.web.dl']
# viruseproject has lots of uploads on glotorrents and site fixes the "&dn=???" portion in html title to reflect the true range the pack covers vs. assclowns incomplete pack file name used

season_list = ('one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eigh', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen',
			'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty', 'twenty-one', 'twenty-two', 'twenty-three',
			'twenty-four', 'twenty-five')
season_ordinal_list = ('first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth', 'eleventh', 'twelfth',
			'thirteenth', 'fourteenth', 'fifteenth', 'sixteenth', 'seventeenth', 'eighteenth', 'nineteenth', 'twentieth', 'twenty-first',
			'twenty-second', 'twenty-third', 'twenty-fourth', 'twenty-fifth')
season_ordinal2_list = ('1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th', '11th', '12th', '13th', '14th', '15th', '16th',
			'17th', '18th', '19th', '20th', '21st', '22nd', '23rd', '24th', '25th')


unwanted_tags = ('tamilrockers.com', 'www.tamilrockers.com', 'www.tamilrockers.ws', 'www.tamilrockers.pl',
			'www-tamilrockers-cl', 'www.tamilrockers.cl', 'www.tamilrockers.li', 'www-tamilrockers-tw',
			'www.tamilrockerrs.pl',
			'www.tamilmv.bid', 'www.tamilmv.biz', 'www.1tamilmv.org',
			'gktorrent-bz', 'gktorrent-com',
			'www.torrenting.com', 'www.torrenting.org', 'www-torrenting-com', 'www-torrenting-org',
			'katmoviehd.pw', 'katmoviehd-pw',
			'www.torrent9.nz', 'www-torrent9-uno', 'torrent9-cz', 'torrent9.cz', 'torrent9-red', 'torrent9-bz',
			'agusiq-torrents-pl',
			'oxtorrent-bz', 'oxtorrent-com', 'oxtorrent.com', 'oxtorrent-sh', 'oxtorrent-vc',
			'www.movcr.tv', 'movcr-com', 'www.movcr.to',
			'(imax)', 'imax',
			'xtorrenty.org', 'nastoletni.wilkoak', 'www.scenetime.com', 'kst-vn',
			'www.movierulz.vc', 'www-movierulz-ht', 'www.2movierulz.ac', 'www.2movierulz.ms',
			'www.3movierulz.com', 'www.3movierulz.tv', 'www.3movierulz.ws', 'www.3movierulz.ms',
			'www.7movierulz.pw', 'www.8movierulz.ws',
			'mkvcinemas.live', 'torrentcounter-to',
			'www.bludv.tv', 'ramin.djawadi', 'extramovies.casa', 'extramovies.wiki',
			'13+', '18+', 'taht.oyunlar', 'crazy4tv.com', 'karibu', '989pa.com',
			'best-torrents-net', '1-3-3-8.com', 'ssrmovies.club',
			'va:', 'zgxybbs-fdns-uk', 'www.tamilblasters.mx',
			'www.1tamilmv.work', 'www.xbay.me', 'www.uindex.org',   # LOCAL PATCH 2026-10-21: le.production / www.uindex.org from POV 6.10.17
			'crazy4tv-com', '(es)')

home_getProperty = homeWindow.getProperty


# LOCAL PATCH 2026-10-06: port of upstream 6.10.01's SourceRegistry. A provider's sources() hands its answer to its own
# sources_packs() calls, which search nothing themselves. Each search is filed under its own key, so a pack call waits
# only for its own (one shared queue handed later scrapes another title's packs).
# Unlike upstream: keyed on registry_key(data), not str(data) -- DeadLight adds fields to the dict during the scrape. No
# clear_all() per scrape (a background scrape in the same process would lose its futures); the latest _REGISTRY_MAX keys
# are kept. start_future() replaces a FINISHED future, so a re-scrape is not handed an old empty answer.
from concurrent.futures import Future

_REGISTRY_MAX = 32

def registry_key(data):
	data = data or {}
	return (str(data.get('imdb') or ''), data.get('tvshowtitle') or data.get('title') or '', str(data.get('year') or ''),
		str(data.get('season') or ''), str(data.get('episode') or ''))

class SourceRegistry:
	_lock = None   # set by each provider class
	_cache = None

	def _put(self, key, future):
		self._cache.pop(key, None)
		self._cache[key] = future
		while len(self._cache) > _REGISTRY_MAX: self._cache.pop(next(iter(self._cache)))
		return future

	def start_future(self, data):
		"""For sources(): this search's future, a new one unless one is waiting unfinished (a pack call got there first)."""
		key = registry_key(data)
		with self._lock:
			future = self._cache.get(key)
			if future is None or future.done(): future = self._put(key, Future())
			return future

	def wait_future(self, data, timeout):
		"""For sources_packs(): the files its sources() call fetched, [] when it fails or takes longer than timeout."""
		key = registry_key(data)
		with self._lock:
			future = self._cache.get(key)
			if future is None: future = self._put(key, Future())
		try: return future.result(timeout=timeout)
		except Exception: return []

def set_future(future, files):
	if not future.done(): future.set_result(files)

def get_undesirables():
	if not getSetting('filter.undesirables') == 'true' or home_getProperty('fs_filterless_search') == 'true' : return []
	try: undesirables = Undesirables().get_enabled()
	except: undesirables = UNDESIRABLES
	return undesirables

def check_foreign_audio():
	return False if home_getProperty('fs_filterless_search') == 'true' else getSetting('filter.foreign.single.audio') == 'true'

# LOCAL PATCH 2026-10-21 (after POV 6.10.17): a resolution number may not touch another DIGIT ('10800' is not 1080p) and
# '720mb' is a size. Not POV's \b: it reads '1080i', '2160p60' and '1920x1080' as SD. Order SCR, CAM, 720, 1080, 4K;
# the CAM keywords POV dropped are kept.
_RES_720_RE = re.compile(r'(?<![0-9])(?:720|72o)(?![0-9])(?!mb)')
_RES_1080_RE = re.compile(r'(?<![0-9])(?:1080|1o8o|108o|1o80)(?![0-9])|\.fhd\.')
_RES_4K_RE = re.compile(r'(?<![0-9])(?:2160|216o)(?![0-9])|\.4k|ultrahd|ultra\.hd|\.uhd\.')

def get_qual(term):
	if any(i in term for i in SCR): return 'SCR'
	elif any(i in term for i in CAM): return 'CAM'
	elif _RES_720_RE.search(term): return '720p'
	elif _RES_1080_RE.search(term): return '1080p'
	elif _RES_4K_RE.search(term): return '4K'
	elif '.hd.' in term: return '720p'
	else: return 'SD'

# LOCAL PATCH 2026-11-01 (cleanup): get_qual always answers (SD at worst), so the link is read only when there is no
# release_info at all. info is always [] (the callers prepend the size to it).
def get_release_quality(release_info, release_link=None):
	try: return get_qual(release_info or (release_link or '').lower()), []
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return 'SD', []

def aliases_to_array(aliases, filter=None):
	try:
		if all(isinstance(x, str) for x in aliases): return aliases
		if not filter: filter = []
		if isinstance(filter, str): filter = [filter]
		return [x.get('title') for x in aliases if not filter or x.get('country') in filter]
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return []

# LOCAL PATCH 2026-10-24: a release named by its air date ('The.Daily.Show.2026.10.20.1080p'), as CocoScrapers does. Any
# separator (or none), but always year, month, day -- 10.20.2026 / 20.10.2026 are ambiguous and no scene group uses them.
def air_date_pattern(air_date):
	m = re.match(r'^((?:19|20)\d{2})[-.](\d{2})[-.](\d{2})', str(air_date or '').strip())
	if not m: return None
	return r'(?<![0-9])%s[.\-_ ]?%s[.\-_ ]?%s(?![0-9])' % m.groups()   # no groups: check_title re.splits on it

# LOCAL PATCH 2026-10-24: the air date as a text search needs it: '2026 10 20', words (knaben finds nothing for the dotted
# spelling). Text-search providers run it as a second query when DeadLight flags a date-released show
# (data['date_search']); check_title reads every spelling back.
def air_date_query(air_date):
	m = re.match(r'^((?:19|20)\d{2})[-.](\d{2})[-.](\d{2})', str(air_date or '').strip())
	return '%s %s %s' % m.groups() if m else None

# LOCAL PATCH 2026-10-25 (4.0.5): the season / episode an id-searched (Stremio) provider is ASKED for. A date-released show
# is numbered differently there (Jeopardy! TMDb S43E30 = Stremio S2026E177); DeadLight passes data['stremio_se'] from
# Cinemeta. Only the request changes -- hdlr stays TMDb's and date-named releases match by air_date.
def stremio_se(data, season, episode):
	return tuple(data.get('stremio_se') or (season, episode))

# LOCAL PATCH 2026-10-24: scene groups name a talk show after its host ('Jimmy.Fallon.2026.10.22'), which TMDb's
# alternative titles do not list. A release carrying the exact air date is accepted when the words before the date are
# two or more CONSECUTIVE words of the title or an alias. Never for S01E05 or a film: the date makes the short name safe.
def _title_run(release_part, title_list):
	words = [w for w in re.split(r'[^a-z0-9]+', release_part.lower()) if w]
	if len(words) < 2: return False
	for name in title_list:
		tw = [w for w in re.split(r'[^a-z0-9]+', name.lower().replace('&', 'and')) if w]
		if any(tw[i:i + len(words)] == words for i in range(len(tw) - len(words) + 1)): return True
	return False

# LOCAL PATCH 2026-10-25 (4.0.5): a film name with NO year, from a provider asked by IMDb / Kitsu id (id_matched, passed by
# comet / mediafusion / meteor / torrentsdb / torz / bitmagnet / torrentio), e.g. 'Matrix [4K UHDremux][2160p]'.
# It passes only when no year-like number is in the name at all and the words before the first
# resolution / source / codec tag are exactly the title or an alias (cleantitle). Text-search providers never pass it.
_ANY_YEAR = re.compile(r'(?<![0-9])(?:19|20)[0-9]{2}(?![0-9])')
_ID_TAGS = re.compile(r'(?<![a-z0-9])(?:bluray|blu-ray|bdrip|brrip|bdremux|uhdremux|remux|web-?dl|webrip|web|hdtv|dvdrip|uhd|hdr|hdr10|dv|'
	r'x26[45]|h\.?26[45]|hevc|avc|av1|10bit)(?![a-z0-9])', re.I)

def check_title(title, aliases, release_title, hdlr, year, years=None, air_date=None, id_matched=False): # non pack file title check, single eps and movies
	# LOCAL PATCH 2026-10-15: a film's year is +-1 for every provider, not torrentio alone -- id-asked providers' rows are
	# the right film, and festival or December/January releases are named a year off.
	if not years and hdlr and str(hdlr) == str(year) and re.match(r'^(19|20)\d{2}$', str(year)):
		_y = int(year)
		years = [str(_y - 1), str(_y), str(_y + 1)]
	# LOCAL PATCH 2026-10-15: an episode token also matches its NxNN form ('1x05', older shows' releases), and is anchored at
	# its end -- a bare search let S01E10 match S01E100-S01E109.
	_m = re.match(r'^S(\d+)E(\d+)$', str(hdlr or ''), re.I)
	hdlr_re = r'(?:%s|(?<![0-9])%dx%02d)(?![0-9])' % (hdlr, int(_m.group(1)), int(_m.group(2))) if _m else r'%s' % hdlr
	# LOCAL PATCH 2026-10-25 (4.0.5): a double-episode file ('S01E01E02') is also its SECOND episode. Also 'S01E01-E02' /
	# 'S01E01-02' (the range filter below still sends those to the pack path).
	# The episode stays digit-anchored: S01E012 and S01E20 are not E02.
	if _m: hdlr_re = r'(?:%s|S%s(?:E\d{2,3}[-.]?)+E%s(?![0-9])|S%sE\d{2,3}-%s(?![0-9]))' % (hdlr_re, _m.group(1), _m.group(2), _m.group(1), _m.group(2))
	# LOCAL PATCH 2026-10-24: an episode also matches its air date (air_date_pattern); the title is then read up to the date
	_date_re = air_date_pattern(air_date) if not years else None
	if _date_re: hdlr_re = r'(?:%s|%s)' % (hdlr_re, _date_re)
	no_year = False
	if years: # for movies only, scraper to pass None for episodes
		if not any(value in release_title for value in years):
			if not id_matched or _ANY_YEAR.search(release_title): return False
			no_year = True
	else: 
		if not re.search(hdlr_re, release_title, re.I): return False
	aliases = aliases_to_array(aliases)
	title_list = []
	title_list_append = title_list.append
	if aliases:
		for item in aliases:
			try:
				alias = item.replace('&', 'and').replace(year, '')
				if years: # for movies only, scraper to pass None for episodes
					for i in years: alias = alias.replace(i, '')
				if alias in title_list: continue
				title_list_append(alias)
			except:
				from magneto.modules import log_utils
				log_utils.error()
	try:
		
		title = title.replace('&', 'and').replace(year, '') # year only in meta title if an addon custom query added it
		if title not in title_list: title_list_append(title)
		release_title = re.sub(r'([(])(?=((19|20)[0-9]{2})).*?([)])', '\\2', release_title) #remove parenthesis only if surrounding a 4 digit date
		t = re.split(hdlr_re, release_title, maxsplit=1, flags=re.I)[0].replace(year, '').replace('&', 'and')
		if years:
			for i in years: t = t.split(i)[0]
		t = re.split(r'2160p|216op|4k|1080p|1o8op|108op|1o80p|720p|72op|480p|48op', t, maxsplit=1, flags=re.I)[0]
		if no_year: t = _ID_TAGS.split(t, maxsplit=1)[0]
		cleantitle_t = cleantitle.get(t)
		if all(cleantitle.get(i) != cleantitle_t for i in title_list) and not (_date_re and re.search(_date_re, release_title) and _title_run(t, title_list)): return False

# filter to remove episode ranges that should be picked up in "filter_season_pack()" ex. "s01e01-08"
		if hdlr != year: # equal for movies but not for shows
			range_regex = (
					r's\d{1,3}e\d{1,3}[-.]e\d{1,3}',
					r's\d{1,3}e\d{1,3}[-.]\d{1,3}(?!p|bit|gb)(?!\d{1,3})',
					r's\d{1,3}[-.]e\d{1,3}[-.]e\d{1,3}',
					r'season[.-]?\d{1,3}[.-]?ep[.-]?\d{1,3}[-.]ep[.-]?\d{1,3}',
					r'season[.-]?\d{1,3}[.-]?episode[.-]?\d{1,3}[-.]episode[.-]?\d{1,3}') # may need to add "to", "thru"
			for regex in range_regex:
				if bool(re.search(regex, release_title, re.I)): return False
		return True
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return False

def remove_lang(release_info, check_foreign_audio):
	if not release_info: return False
	try:
		if any(value in release_info for value in DUBBED): return True
		if any(value in release_info for value in SUBS): return True
		if check_foreign_audio:
			if any(value in release_info for value in LANG) and not any(value in release_info for value in ENG_CHECK): return True
			if any(value in release_info for value in ABV_LANG) and not any(value in release_info for value in ENG_CHECK): return True
		if release_info.endswith('.srt.') and not any(value in release_info for value in SRT_CHECK): return True
		return False
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return False

def remove_undesirables(release_info, undesirables):
	if any(value in release_info for value in undesirables): return True

def filter_season_pack(show_title, aliases, year, season, release_title):
	aliases = aliases_to_array(aliases)
	title_list = []
	title_list_append = title_list.append
	if aliases:
		for item in aliases:
			try:
				alias = item.replace('!', '').replace('(', '').replace(')', '').replace('&', 'and').replace(year, '')
				if alias in title_list: continue
				title_list_append(alias)
			except:
				from magneto.modules import log_utils
				log_utils.error()
	try:
		show_title = show_title.replace('!', '').replace('(', '').replace(')', '').replace('&', 'and').replace(year, '') # year only in meta title if an addon custom query added it
		if show_title not in title_list: title_list_append(show_title)

		season_fill = season.zfill(2)
		season_check = '.s%s.' % season
		season_fill_check = '.s%s.' % season_fill
		season_fill_checke = '.s%se' % season_fill # added 3/2/22 to pick up episode range packs ex "Reacher.s01e01-08"
		season_full_check = '.season.%s.' % season
		season_full_check_ns = '.season%s.' % season
		season_full_fill_check = '.season.%s.' % season_fill
		season_full_fill_check_ns = '.season%s.' % season_fill
		split_list = (season_check, season_fill_check, season_fill_checke, '.' + season + '.season', 'total.season', 'season', 'the.complete', 'complete', year)
		string_list = (season_check, season_fill_check, season_fill_checke, season_full_check, season_full_check_ns, season_full_fill_check, season_full_fill_check_ns)

		# LOCAL PATCH 2026-10-18: 'Show S03E20 (57)' -- one episode with its absolute number in brackets; formatted
		# 's03e20.57.', which the range regexes read as episodes 20-57 (anime_utils._pack_shape does the same for nyaa).
		if re.search(r'(?i)s\d{1,3}[ ._-]?e\d{1,4}[ ._-]*[(\[]\d{1,4}[)\]]', release_title): return False, 0, 0
		release_title = release_title_format(release_title)
		t = release_title.replace('-', '.')
		for i in split_list: t = t.split(i)[0]
		cleantitle_t = cleantitle.get(t)
		if all(cleantitle.get(x) != cleantitle_t for x in title_list): return False, 0, 0

# remove single episodes ONLY (returned in single ep scrape), keep episode ranges as season packs
		episode_regex = (
				r's\d{1,3}e\d{1,3}[-.](?!\d{2,3}[-.])(?!e\d{1,3})(?!\d{2}gb)',
				r'season[.-]?\d{1,3}[.-]?ep[.-]?\d{1,3}[-.](?!\d{2,3}[-.])(?!e\d{1,3})(?!\d{2}gb)',
				r'season[.-]?\d{1,3}[.-]?episode[.-]?\d{1,3}[-.](?!\d{2,3}[-.])(?!e\d{1,3})(?!\d{2}gb)')
		for item in episode_regex:
			if bool(re.search(item, release_title)): return False, 0, 0

# return and identify episode ranges
		# LOCAL PATCH 2026-10-18: the season is captured and must be the one asked -- the year sits in split_list, so a
		# name carrying it passes the title check whatever season it names ('Shogun.2024.S02E01-E05').
		range_regex = (
				r's(\d{1,3})e(\d{1,3})[-.]e(\d{1,3})',
				r's(\d{1,3})e(\d{1,3})[-.](\d{1,3})(?!p|bit|gb)(?!\d{1,3})',
				r's(\d{1,3})[-.]e(\d{1,3})[-.]e(\d{1,3})',
				r'season[.-]?(\d{1,3})[.-]?ep[.-]?(\d{1,3})[-.]ep[.-]?(\d{1,3})',
				r'season[.-]?(\d{1,3})[.-]?episode[.-]?(\d{1,3})[-.]episode[.-]?(\d{1,3})') # may need to add "to", "thru"
		for regex in range_regex:
			match = re.search(regex, release_title)
			if match:
				if int(match.group(1)) != int(season): return False, 0, 0
				episode_start = int(match.group(2))
				episode_end = int(match.group(3))
				return True, episode_start, episode_end

# remove season ranges - returned in showPack scrape, plus non conforming season and specific crap
		rt = release_title.replace('-', '.')
		if any(i in rt for i in string_list):
			for item in (
				season_check.rstrip('.') + r'[.-]s([2-9]{1}|[1-3]{1}[0-9]{1})(?:[.-]|$)', # ex. ".s1-s9.", .s1-s39.
				season_fill_check.rstrip('.') + r'[.-]s\d{2}(?:[.-]|$)', # ".s01-s09.", .s01-s39.
				season_fill_check.rstrip('.') + r'[.-]\d{2}(?:[.-]|$)', # ".s01.09."
				r'\Ws\d{2}\W%s' % season_fill_check.lstrip('.'), # may need more reverse ranges
				season_full_check.rstrip('.') + r'[.-]to[.-]([2-9]{1}|[1-3]{1}[0-9]{1})(?:[.-]|$)', # ".season.1.to.9.", ".season.1.to.39"
				season_full_check.rstrip('.') + r'[.-]season[.-]([2-9]{1}|[1-3]{1}[0-9]{1})(?:[.-]|$)', # ".season.1.season.9.", ".season.1.season.39"
				season_full_check.rstrip('.') + r'[.-]([2-9]{1}|[1-3]{1}[0-9]{1})(?:[.-]|$)', # "season.1.9.", "season.1.39.
				season_full_check.rstrip('.') + r'[.-]\d{1}[.-]\d{1,2}(?:[.-]|$)', # "season.1.9.09."
				season_full_check.rstrip('.') + r'[.-]\d{3}[.-](?:19|20)[0-9]{2}(?:[.-]|$)', # single season followed by 3 digit followed by 4 digit year ex."season.1.004.1971"
				season_full_fill_check.rstrip('.') + r'[.-]\d{3}[.-]\d{3}(?:[.-]|$)', # 2 digit season followed by 3 digit dash range ex."season.10.001-025."
				season_full_fill_check.rstrip('.') + r'[.-]season[.-]\d{2}(?:[.-]|$)' # 2 digit season followed by 2 digit season range ex."season.01-season.09."
					):
				if bool(re.search(item, release_title)): return False, 0, 0
			return True, 0, 0
		return False, 0, 0
	except:
		from magneto.modules import log_utils
		log_utils.error()
		# LOCAL PATCH 2026-10-03: a 3-tuple, not a bare True -- every caller unpacks three values.
		return False, 0, 0

def pack_range_fields(episode_start, episode_end):
	"""LOCAL PATCH 2026-10-03: item keys for a partial season pack -- its range, and its length, which is what DeadLight
	divides the size by. The range was only used to filter, so 'S01E01-E08' was sized by the whole season's count."""
	if not episode_start: return {}
	out = {'episode_start': episode_start, 'episode_end': episode_end}
	try:
		n = int(episode_end) - int(episode_start) + 1
		if n > 0: out['pack_episodes'] = n
	except (TypeError, ValueError): pass
	return out

def _season_range_end(to_ranges, dot_title, title, marker, with_dot):
	"""The season a show pack's range ends at, or None. `to_ranges` are '<first>.to.<marker><n>' for every n; the same range is looked
	for as .to. and .thru. in the dotted title, and as - and ~ (and, with_dot, .) in the title as it is. The first range found wins."""
	variants = [(to_ranges, dot_title, 'to.'), ([i.replace('to', 'thru') for i in to_ranges], dot_title, 'thru.'),
				([i.replace('.to.', '-') for i in to_ranges], title, '-'), ([i.replace('.to.', '~') for i in to_ranges], title, '~')]
	if with_dot: variants.append(([i.replace('.to.', '.') for i in to_ranges], title, '.'))
	for ranges, haystack, separator in variants:
		keys = [i for i in ranges if i in haystack]
		if keys: return int(keys[0].split(separator + marker)[1])
	return None

def filter_show_pack(show_title, aliases, imdb, year, season, release_title, total_seasons):
	aliases = aliases_to_array(aliases)
	title_list = []
	title_list_append = title_list.append
	if aliases:
		for item in aliases:
			try:
				alias = item.replace('!', '').replace('(', '').replace(')', '').replace('&', 'and').replace(year, '')
				if alias in title_list: continue
				title_list_append(alias)
			except:
				from magneto.modules import log_utils
				log_utils.error()
	try:
		show_title = show_title.replace('!', '').replace('(', '').replace(')', '').replace('&', 'and').replace(year, '') # year only in meta title if an addon custom query added it
		if show_title not in title_list: title_list_append(show_title)

		split_list = ('.all.seasons', 'seasons', 'season', 'the.complete', 'complete', 'all.torrent', 'total.series', 'tv.series', 'series', 'edited', 's1', 's01', year)#s1 or s01 used so show pack only kept that begin with 1
		release_title = release_title_format(release_title)
		t = release_title.replace('-', '.')
		for i in split_list: t = t.split(i)[0]
		cleantitle_t = cleantitle.get(t)
		if all(cleantitle.get(x) != cleantitle_t for x in title_list): return False, 0

# remove single episodes(returned in single ep scrape)
		episode_regex = (
				r's\d{1,3}e\d{1,3}',
				r's[0-3]{1}[0-9]{1}[.-]e\d{1,2}',
				r's\d{1,3}[.-]\d{1,3}e\d{1,3}',
				r'season[.-]?\d{1,3}[.-]?ep[.-]?\d{1,3}',
				r'season[.-]?\d{1,3}[.-]?episode[.-]?\d{1,3}')
		for item in episode_regex:
			if bool(re.search(item, release_title)):
				return False, 0

# remove season ranges that do not begin at 1
		season_range_regex = (
				r'(?:season|seasons|s)[.-]?(?:0?[2-9]{1}|[1-3]{1}[0-9]{1})(?:[.-]?to[.-]?|[.-]?thru[.-]?|[.-])(?:season|seasons|s|)[.-]?(?:0?[3-9]{1}(?!\d{2}p)|[1-3]{1}[0-9]{1}(?!\d{2}p))',) # seasons.5-6, seasons5.to.6, seasons.5.thru.6, season.2-9.s02-s09.1080p
		for item in season_range_regex:
			if bool(re.search(item, release_title)):
				return False, 0

# remove single seasons - returned in seasonPack scrape
		season_regex = (
				r'season[.-]?([1-9]{1})[.-]0{1}\1[.-]?complete', # "season.1.01.complete" when 2nd number matches the fiirst group with leading 0
				r'season[.-]?([2-9]{1})[.-](?:[0-9]+)[.-]?complete', # "season.9.10.complete" when first number is >1 followed by 2 digit number
				r'season[.-]?\d{1,2}[.-]s\d{1,2}', # season.02.s02
				r'season[.-]?\d{1,2}[.-]complete', # season.02.complete
				r'season[.-]?\d{1,2}[.-]\d{3,4}p{0,1}', # "season.02.1080p" and no seperator "season02.1080p"
				r'season[.-]?\d{1,2}[.-](?!thru|to|\d{1,2}[.-])', # "season.02." or "season.1" not followed by "to", "thru", or another single or 2 digit number then a dot(which would be a range)
				r'season[.-]?\d{1,2}[.]?$', # end of line ex."season.1", "season.01", "season01" can also have trailing dot or end of line(dash would be a range)
				r'season[.-]?\d{1,2}[.-](?:19|20)[0-9]{2}', # single season followed by 4 digit year ex."season.1.1971", "season.01.1971", or "season01.1971"
				r'season[.-]?\d{1,2}[.-]\d{3}[.-]{1,2}(?:19|20)[0-9]{2}', # single season followed by 3 digits then 4 digit year ex."season.1.004.1971" or "season.01.004.1971" (comic book format)
				r'(?<!thru)(?<!to)(?<!\d{2})[.-]s\d{2}[.-]complete', # ".s01.complete" not preceded by "thru", "to", or 2 digit number
				r'(?<!thru)(?<!to)(?<!s\d{2})[.-]s\d{2}(?![.-]thru)(?![.-]to)(?![.-]s\d{2})(?![.-]\d{2}[.-])' # .s02. not preceded by "thru", "to", or "s01". Not followed by ".thru", ".to", ".s02", "-s02", ".02.", or "-02."
				)
		for item in season_regex:
			if bool(re.search(item, release_title)):
				return False, 0


# remove spelled out single seasons
		season_regex = ()
		season_regex += tuple([r'complete[.-]%s[.-]season' % x for x in season_ordinal_list])
		season_regex += tuple([r'complete[.-]%s[.-]season' % x for x in season_ordinal2_list])
		season_regex += tuple([r'season[.-]%s' % x for x in season_list]) 
		for item in season_regex:
			if bool(re.search(item, release_title)):
				return False, 0


# from here down we don't filter out, we set and pass "last_season" it covers for the range and addon can filter it so the db will have full valid showPacks.
# set last_season for range type ex "1.2.3.4" or "1.2.3.and.4" (dots or dashes)
		dot_release_title = release_title.replace('-', '.')
		dot_season_ranges = []
		all_seasons = '1'
		season_count = 2
		while season_count <= int(total_seasons):
			dot_season_ranges.append(all_seasons + '.and.%s' % str(season_count))
			all_seasons += '.%s' % str(season_count)
			dot_season_ranges.append(all_seasons)
			season_count += 1
		if any(i in dot_release_title for i in dot_season_ranges):
			keys = [i for i in dot_season_ranges if i in dot_release_title]
			last_season = int(keys[-1].split('.')[-1])
			return True, last_season


# LOCAL PATCH 2026-11-08: the five spellings of a range that starts at the first season -- "1.to.9", "01.to.09", "s1.to.s9",
# "s01.to.s09" -- each tried as .to. / .thru. / -  / ~ (and, for the last, a bare dot: "s01.s09"). The first spelling
# found gives the last season.
		for start, two_digits, marker, with_dot in (('1', False, '', False), ('01', True, '', False), ('s1', False, 's', False), ('s01', True, 's', True)):
			to_season_ranges = []
			for season_count in range(2, int(total_seasons) + 1):
				number = '0' + str(season_count) if two_digits and season_count < 10 else str(season_count)
				to_season_ranges.append('%s.to.%s%s' % (start, marker, number))
			last_season = _season_range_end(to_season_ranges, dot_release_title, release_title, marker, with_dot)
			if last_season is not None: return True, last_season

		return True, total_seasons
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return False, 0

def _strip_token(text, token, count=0):
	token = (token or '').strip('.')
	if not token: return text
	return re.sub(r'(?<![a-z0-9])%s(?![a-z0-9])' % re.escape(token), '', text, count=count)

def info_from_name(release_title, title, year, hdlr=None, episode_title=None, season=None, pack=None):
	try:
		# LOCAL PATCH 2026-09-26: HDR10+ / HDR10P -> 'hdr10plus' before the '+' is lost to a dot, which
		# made it indistinguishable from HDR10. Same fold as DeadLight's release_info_format.
		release_title = re.sub(r'hdr10(?:\+|p(?![a-z0-9]))', 'hdr10plus', release_title.lower()).replace('&', 'and').replace("'", "")
		# LOCAL PATCH 2026-10-02: 'DD+' -> 'ddp' the same way ('DD+7.1' read as DD). Same fold as DeadLight's release_info_format.
		release_title = re.sub(r'(?<![a-z0-9])dd\+', 'ddp', release_title)
		release_title = re.sub(r'[^a-z0-9]+', '.', release_title)
		title = title.lower().replace('&', 'and').replace("'", "")
		title = re.sub(r'[^a-z0-9]+', '.', title)
		# LOCAL PATCH 2026-10-25 (4.0.5): title / year / hdlr / episode title come out as whole dot-delimited tokens, the
		# titles once. Not a substring replace: a short title (X, Us, Ma) cut pieces out of the tags ('remux' -> 'remu').
		name_info = _strip_token(_strip_token(release_title, title, 1), year)
		if hdlr: name_info = _strip_token(name_info, hdlr.lower())
		if episode_title:
			episode_title = episode_title.lower().replace('&', 'and').replace("'", "")
			episode_title = re.sub(r'[^a-z0-9]+', '.', episode_title)
			name_info = _strip_token(name_info, episode_title, 1)
		if pack:
			if pack == 'season':
				season_fill = season.zfill(2)
				str1_replace = ('.s%s' % season, '.s%s' % season_fill, '.season.%s' % season, '.season%s' % season, '.season.%s' % season_fill, '.season%s' % season_fill, 'complete')
				for i in str1_replace: name_info = name_info.replace(i, '')
			elif pack == 'show':
				str2_replace = ('.all.seasons', 'seasons', 'season', 'the.complete', 'complete', 'all.torrent', 'total.series', 'tv.series', 'series', 'edited', 's1', 's01')
				for i in str2_replace: name_info = name_info.replace(i, '')
		name_info = name_info.lstrip('.').rstrip('.')
		name_info = '.%s.' % name_info
		return name_info
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return release_title

def release_title_format(release_title):
	try:
		release_title = release_title.lower().replace("'", "").lstrip('.').rstrip('.')
		fmt = '.%s.' % re.sub(r'[^a-z0-9-~]+', '.', release_title).replace('.-.', '-').replace('-.', '-').replace('.-', '-').replace('--', '-')
		return fmt
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return release_title

# LOCAL PATCH 2026-10-25: the group clean_name() strips off the front ('[SubsPlease] ...', '[Erai-raws] ...'), kept by the
# name it returns, for DeadLight's external.process_sources to put on the row as release_group -- otherwise only the
# providers reading release_group(raw) themselves keep an anime row's fansub group.
_STRIPPED_GROUPS = {}

def stripped_group(name):
	"""The leading group clean_name() removed from the raw name it turned into `name`, or ''."""
	return _STRIPPED_GROUPS.get(name or '', '')

def clean_name(release_title):
	try:
		_raw = release_title
		release_title = re.sub(r'【.*?】', '', release_title)
		release_title = strip_non_ascii_and_unprintable(release_title).lstrip('+.-:/ ').replace(' ', '.')
		releasetitle_startswith = release_title.lower().startswith
		if releasetitle_startswith('rifftrax'): return release_title # removed by "undesirables" anyway so exit
		for i in unwanted_tags:
			if releasetitle_startswith(i):
				release_title = re.sub(r'^%s' % re.escape(i), '', release_title, count=1, flags=re.I)
		release_title = release_title.lstrip('+.-:/ ')
		_before = release_title
		release_title = re.sub(r'^\[.*?]', '', release_title, count=1, flags=re.I)
		release_title = release_title.lstrip('.-[](){}:/')
		if release_title != _before:
			_group = release_group(_raw)
			if _group:
				if len(_STRIPPED_GROUPS) > 5000: _STRIPPED_GROUPS.clear()
				_STRIPPED_GROUPS[release_title] = _group
		return release_title
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return release_title

def strip_non_ascii_and_unprintable(text):
	# LOCAL PATCH 2026-10-21 (from POV 6.10.17): letters folded to ASCII first (NFKD), not deleted ('Amélie', fullwidth
	# 'ＳＰＹ×ＦＡＭＩＬＹ'). cleantitle.get folds the searched title the same way.
	try:
		import unicodedata
		return ''.join(c for c in unicodedata.normalize('NFKD', text) if ord(c) < 128 and c in printable and not unicodedata.combining(c))
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return text

def _size(siz):
	try:
		if siz in ('0', 0, '', None): return 0, ''
		_low = siz.strip().lower()
		div = 1 if _low.endswith(('gb', 'gib')) else (1.0 / 1024 if _low.endswith(('tb', 'tib')) else 1024)
		# LOCAL PATCH 2026-10-25 (4.0.5): KB / KiB was divided as MB -- '700 KB' read 0.68 GB
		if _low.endswith(('kb', 'kib')): div = 1024 * 1024
		# LOCAL PATCH 2026-10-18: a comma not followed by exactly 3 digits is a decimal comma ('2,75 GB'), not thousands
		if re.search(r',\d{1,2}(?!\d)', siz) and '.' not in siz: siz = siz.replace(',', '.')
		dec_count = len(re.findall(r'[.]', siz))
		if dec_count == 2: siz = siz.replace('.', ',', 1) # torrentproject2 likes to randomly use 2 decimals vs. a comma then a decimal
		float_size = round(float(re.sub(r'[^0-9|/.|/,]', '', siz.replace(',', ''))) / div, 2) #comma issue where 2,750 MB or 2,75 GB (sometimes replace with "." and sometimes not)
		str_size = '%.2f GB' % float_size
		return float_size, str_size
	except:
		from magneto.modules import log_utils
		log_utils.error('failed on siz=%s' % siz)
		return 0, ''

def convert_size(size_bytes, to='GB'):
	try:
		import math
		if size_bytes == 0: return 0, ''
		power = {'B' : 0, 'KB': 1, 'MB' : 2, 'GB': 3, 'TB' : 4, 'EB' : 5, 'ZB' : 6, 'YB': 7}
		i = power[to]
		p = math.pow(1024, i)
		float_size = round(size_bytes / p, 2)
		str_size = "%s %s" % (float_size, to)
		return float_size, str_size
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return 0, ''

# LOCAL PATCH 2026-11-01 (cleanup): through log_utils.error(), one '###magneto error###' line naming the line that raised.
# Not log_utils.log(): it is silent (no 'debug.enabled' setting).
def scraper_error(provider):
	from magneto.modules import log_utils
	log_utils.error(provider.upper())

# LOCAL PATCH 2026-10-25 (4.0.5): no copy2clip here -- it ran 'echo <text>|clip' through a shell with server-supplied
# text (command injection). DeadLight's modules.utils.copy2clip is the safe one.


# LOCAL PATCH 2026-09-22: the release group, read from the RAW name -- clean_name() deletes the leading bracket, which
# IS the fansub tag. Two conventions, in order of reliability:
#   fansub  '[SubsPlease] Title - 01 [1080p]'      -> leading bracket
#   scene   'Title.1080p.BluRay.x264-SPARKS'       -> trailing -GROUP
# The trailing form tolerates a source tag and an extension after the group ('... x264 -NanDesuKa (CR).mkv').
# Two-letter hits like '[DB]' and '[uP]' are real groups.
_RG_NOT_GROUP = set((
	'1080p 720p 480p 2160p 4k 8bit 10bit 10bits hevc x264 x265 av1 h264 h265 avc '
	'bd bdrip bluray bdremux remux web webrip webdl dvd dvdrip hdtv dvdremux '
	'flac aac ac3 eac3 opus dts truehd multi dual subs sub dub cr amzn nf dsnp hulu '
	'batch complete repack raw eng jpn engjap sdr hdr dv mkv mp4 unofficial'
).split())
_RG_LEAD = re.compile(r'^\s*[\[(]([^\])]{2,24})[\])]')
_RG_TAIL = re.compile(r'-\s*([A-Za-z][A-Za-z0-9]{1,19})\s*(?:\([^)]{1,12}\))?\s*(?:\.[a-z0-9]{2,4})?\s*$')


def _rg_plausible(cand):
	low = cand.lower().strip()
	if not low or low in _RG_NOT_GROUP: return False
	if re.fullmatch(r'[\d\s._-]+', cand): return False
	toks = [t for t in re.split(r'[\s._-]+', low) if t]
	return not all(t in _RG_NOT_GROUP for t in toks)


def release_group(raw):
	"""The release group from an uncleaned name, or '' when the name carries none."""
	try:
		raw = (raw or '').strip()
		if not raw: return ''
		m = _RG_LEAD.match(raw)
		if m and _rg_plausible(m.group(1)): return m.group(1).strip()
		m = _RG_TAIL.search(raw)
		if m and _rg_plausible(m.group(1)): return m.group(1)
		return ''
	except Exception:
		return ''
