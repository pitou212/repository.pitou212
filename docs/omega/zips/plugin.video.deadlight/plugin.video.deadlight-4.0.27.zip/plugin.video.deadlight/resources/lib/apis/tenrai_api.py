# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-11-08: api.tenrai.org -- MyAnimeList data in Jikan's shape (Jikan's own public API shut down; tenrai answers
# Jikan's /v4 paths with a redirect to its /v1 ones and the same JSON). No key, no account.
#
# Used for four things, each degrading to 'no data' when tenrai does not answer:
#   episode_flags   MAL's per-episode filler / recap flags (modules/anime_filler.py: the episode-list marks, Skip filler)
#   anime_info      MAL score + genres when the official MAL API cannot answer (metadata._backfill_mal)
#   catalogue page  anime lists when AniList is down (apis/anime_backup.py, ahead of MAL and Kitsu)
# It is a third-party mirror with no published limits: requests are paced (Jikan's documented 3 / s, here one per 0.4 s across
# every DeadLight process), a failure stops all calls for 10 min (429: 1 min), and answers are cached long -- flags 7 days,
# scores 72 h, catalogue pages 12 h (anime_backup's own cache).

import time
from threading import Lock
from modules.kodi_utils import make_session, logger, cooldown_active, start_cooldown, get_property, set_property
from modules.utils import safe_err

_API_URL = 'https://api.tenrai.org/v1/%s'
session = make_session('https://api.tenrai.org')
_HEADERS = {'User-Agent': 'DeadLight (Kodi add-on)', 'Accept': 'application/json'}
_COOLDOWN_PROP = 'deadlight.tenrai.cooldown'
_PACE_PROP = 'deadlight.tenrai.last_call'
_MIN_CALL_INTERVAL = 0.4
_pace_lock = Lock()

FLAGS_CACHE_HOURS = 168
INFO_CACHE_HOURS = 72
_MAX_EPISODE_PAGES = 30   # 100 episodes a page: One Piece needs 12


def available():
	return not cooldown_active(_COOLDOWN_PROP)


_last_call = [0.0]   # this process's own last call, for when the shared property is not there

def _pace():
	"""Block until _MIN_CALL_INTERVAL has passed since the last call by ANY DeadLight process (a window property) and by
	this one."""
	try:
		with _pace_lock:
			for _ in range(40):
				try: last = float(get_property(_PACE_PROP) or 0)
				except (TypeError, ValueError): last = 0
				wait = _MIN_CALL_INTERVAL - (time.time() - max(last, _last_call[0]))
				if wait <= 0: break
				time.sleep(min(wait, 0.4))
			_last_call[0] = time.time()
			set_property(_PACE_PROP, str(_last_call[0]))
	except Exception: pass


def call(path, params=None, timeout=10):
	"""The JSON answer, {} for a 404, None when tenrai did not answer (and then no call for 10 min; 1 min after repeated 429s).
	A 429 (rate limit; a long show's 12 episode pages can meet it) waits as told -- Retry-After, at most 5 s -- and asks again,
	twice at most."""
	if not available(): return None
	for attempt in range(3):
		_pace()
		try: r = session.get(_API_URL % path, params=params, timeout=timeout, headers=_HEADERS)
		except Exception as e:
			logger('tenrai', '%s: %s' % (path.split('?')[0], safe_err(e)))
			start_cooldown(_COOLDOWN_PROP, 600)
			return None
		if r.status_code != 429: break
		try: wait = min(5.0, max(1.0, float(r.headers.get('Retry-After') or 1.5)))
		except (TypeError, ValueError): wait = 1.5
		time.sleep(wait * (attempt + 1))
	if r.status_code == 404: return {}
	if r.status_code == 429:
		logger('tenrai', 'rate limited on %s; no calls for 1 min' % path.split('?')[0])
		start_cooldown(_COOLDOWN_PROP, 60)
		return None
	if not r.ok:
		logger('tenrai', 'HTTP %s for %s' % (r.status_code, path.split('?')[0]))
		start_cooldown(_COOLDOWN_PROP, 600)
		return None
	try: return r.json()
	except ValueError:
		start_cooldown(_COOLDOWN_PROP, 600)
		return None


def _flags_key(mal_id): return 'tenrai_episode_flags_%s' % mal_id

def _fetch_flags(mal_id):
	filler, recap, count, page = [], [], 0, 1
	while page <= _MAX_EPISODE_PAGES:
		res = call('anime/%d/episodes' % mal_id, params={'page': page})
		if res is None: return {'success': False}   # not stored; asked again next time
		for ep in res.get('data') or []:
			try: n = int(ep.get('mal_id'))
			except (TypeError, ValueError): continue
			count = max(count, n)
			if ep.get('filler'): filler.append(n)
			if ep.get('recap'): recap.append(n)
		if not (res.get('pagination') or {}).get('has_next_page'): break
		page += 1
	return {'filler': filler, 'recap': recap, 'count': count}


def cached_episode_flags(mal_id):
	"""The stored flags of a MAL entry, or None when none are stored (no request)."""
	try:
		from caches.lists_cache import lists_cache
		return lists_cache.get(_flags_key(int(mal_id)))
	except Exception: return None


def episode_flags(mal_id):
	"""{'filler': [episode numbers], 'recap': [...], 'count': n} for a MAL entry (fetched and stored when missing), or None
	when tenrai did not answer."""
	try: mal_id = int(mal_id)
	except (TypeError, ValueError): return None
	stored = cached_episode_flags(mal_id)
	if stored is not None: return stored
	from caches.lists_cache import lists_cache_object
	from caches.base_cache import is_failed_result
	try: res = lists_cache_object(_fetch_flags, _flags_key(mal_id), mal_id, expiration=FLAGS_CACHE_HOURS)
	except Exception: return None
	return None if is_failed_result(res) else res


def anime_info(mal_id):
	"""{'score': '9.2' or None, 'genres': [...]} like mal_api.mal_anime_info; {} for no such entry, None when tenrai did not
	answer. Genres as MAL's own API lists them: genres, explicit genres, themes and demographics."""
	try: mal_id = int(mal_id)
	except (TypeError, ValueError): return None
	def _fetch(_dummy):
		res = call('anime/%d' % mal_id)
		if res is None: return {'success': False}
		data = res.get('data') or {}
		if not data.get('mal_id'): return {}
		try: score = '%.1f' % float(data['score']) if data.get('score') else None
		except (TypeError, ValueError): score = None
		genres = []
		for group in ('genres', 'explicit_genres', 'themes', 'demographics'):
			for g in data.get(group) or []:
				if isinstance(g, dict) and g.get('name') and g['name'] not in genres: genres.append(g['name'])
		return {'score': score, 'genres': genres}
	from caches.lists_cache import lists_cache_object
	from caches.base_cache import is_failed_result
	try: res = lists_cache_object(_fetch, 'tenrai_anime_info_%s' % mal_id, 1, expiration=INFO_CACHE_HOURS)
	except Exception: return None
	return None if is_failed_result(res) else res
