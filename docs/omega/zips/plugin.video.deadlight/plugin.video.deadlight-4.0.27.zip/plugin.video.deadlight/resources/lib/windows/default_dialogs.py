# -*- coding: utf-8 -*-
import json
from windows.base_window import BaseDialog

class Select(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.window_id = 2025
		self.kwargs = kwargs
		self.enumerate = self.kwargs.get('enumerate', 'false')
		self.multi_choice = self.kwargs.get('multi_choice', 'false')
		self.multi_line = self.kwargs.get('multi_line', 'false')
		self.preselect = self.kwargs.get('preselect', [])
		self.items = json.loads(self.kwargs['items'])
		self.heading = self.kwargs.get('heading', '')
		self.media_type = self.kwargs.get('media_type', '')
		self.narrow_window = self.kwargs.get('narrow_window', 'false')
		self.enable_context_menu = self.kwargs.get('enable_context_menu', 'false') == 'true'
		self.set_focus = self.kwargs.get('set_focus', None)
		self.groups = json.loads(self.kwargs.get('groups') or '[]')   # LOCAL PATCH 2026-10-05, see apply_groups
		self.item_list = []
		self.chosen_indexes = []
		self.selected = None
		# LOCAL PATCH 2026-11-06: as Red Light has it -- onAction reads control_id, which only onClick sets, so OK pressed with
		# nothing clickable focused raised AttributeError
		self.control_id = None
		self.set_properties()
		self.make_menu()
		self.track_buttons((10, 11, 12, 13))   # LOCAL PATCH 2026-11-07: the last-used button stays yellow (base_window)

	def onInit(self):
		# LOCAL PATCH 2026-10-05: the preselected ticks are set in make_menu, BEFORE add_items. Set after it, the focused first
		# row is already drawn and Kodi never redraws it.
		self.add_items(self.window_id, self.item_list)
		if self.preselect:
			if len(self.preselect) == len(self.item_list): self.setProperty('select_button', 'deselect_all')
			for index in self.preselect: self.chosen_indexes.append(index)
		self.setFocusId(self.window_id)
		if self.set_focus is not None: self.select_item(self.window_id, self.set_focus)
		self.ensure_focus(self.window_id)   # LOCAL PATCH 2026-11-07: see base_window.ensure_focus

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.selected

	def onClick(self, controlID):
		self.control_id = None
		if controlID in (10, 11, 12, 13):
			if controlID == 10:
				self.selected = sorted(self.chosen_indexes)
				self.close()
			elif controlID == 11:
				self.close()
			elif controlID in (12, 13):
				item_list_indexes = list(range(0, len(self.item_list)))
				if controlID == 12: status, select_property, self.chosen_indexes = 'checked', 'deselect_all', item_list_indexes
				else: status, select_property, self.chosen_indexes = '', 'select_all', []
				for index in item_list_indexes: self.item_list[index].setProperty('check_status', status)
				self.setProperty('select_button', select_property)
				try: self.setFocusId(10)
				except: pass
		else: self.control_id = controlID

	def onAction(self, action):
		chosen_listitem = self.get_listitem(self.window_id)
		if action in self.selection_actions:
			if not self.control_id: return
			position = self.get_position(self.window_id)
			if self.multi_choice == 'true':
				if chosen_listitem.getProperty('check_status') == 'checked':
					chosen_listitem.setProperty('check_status', '')
					self.chosen_indexes.remove(position)
				else:
					chosen_listitem.setProperty('check_status', 'checked')
					self.chosen_indexes.append(position)
				self.apply_groups(position)
			else:
				self.selected = position
				return self.close()
		elif action in self.context_actions or action in self.closing_actions: return self.close()

	def set_checked(self, index, checked):
		if (index in self.chosen_indexes) == checked: return
		self.item_list[index].setProperty('check_status', 'checked' if checked else '')
		if checked: self.chosen_indexes.append(index)
		else: self.chosen_indexes.remove(index)

	def apply_groups(self, position):
		# LOCAL PATCH 2026-10-05: kwargs 'groups' = [[parent, [children], [children to tick when the parent is ticked]], ...]
		# (Enable Scrapers: External and its torrent sites). Unticking the parent unticks its children; ticking it back
		# ticks the remembered ones if none is ticked; ticking a child ticks the parent.
		for parent, children, restore in self.groups:
			if position == parent:
				if parent in self.chosen_indexes:
					if not any(i in self.chosen_indexes for i in children):
						for i in restore: self.set_checked(i, True)
				else:
					for i in children: self.set_checked(i, False)
			elif position in children and position in self.chosen_indexes: self.set_checked(parent, True)

	def make_menu(self):
		def builder():
			for count, item in enumerate(self.items, 1):
				listitem = self.make_listitem()
				if enum: line1 = '%02d. %s' % (count, item['line1'])
				else: line1 = item['line1']
				# LOCAL PATCH 2026-11-07: select.xml bolds every label; a label's own [B]..[/B] nested inside shows a literal '[/B]'
				line1 = str(line1).replace('[B]', '').replace('[/B]', '')
				if 'line2' in item: line2 = item['line2']
				else: line2 = ''
				# LOCAL PATCH 2026-11-07: a value that only repeats the label ('Open Tools' / 'Open Tools') is dropped: one-line row
				if line2 and str(line2).strip().lower() == str(item['line1']).strip().lower(): line2 = ''
				listitem.setProperty('icon', item.get('icon', '') if self.row_art() else '')
				# LOCAL PATCH 2026-11-07: the row's own chip is for narrow pickers (theme swatches); a poster passed as 'icon' to a
				# wide menu would show as a small poster on every row. select.xml reads 'chip', not 'icon'.
				listitem.setProperty('chip', item.get('icon', '') if self.narrow_window == 'true' and self.multi_choice != 'true' else '')
				listitem.setProperty('line1', line1)
				listitem.setProperty('line2', line2)
				if count - 1 in preselected: listitem.setProperty('check_status', 'checked')
				yield listitem
		enum = self.enumerate == 'true'
		preselected = set(self.preselect or [])
		self.item_list = list(builder())

	def row_art(self):
		"""LOCAL PATCH 2026-11-07: the art pane only when it tells rows apart (seasons, episodes, people). The same title poster
		on every row (a scraper picker, a title's menu) is one more large image saying nothing; a one-row list keeps its art."""
		if not hasattr(self, '_row_art'):
			icons = [i.get('icon') for i in self.items if i.get('icon')]
			self._row_art = bool(icons) and (len(self.items) == 1 or len(set(icons)) > 1)
		return self._row_art

	def set_properties(self):
		self.setProperty('multi_choice', self.multi_choice)
		self.setProperty('multi_line', self.multi_line)
		self.setProperty('select_button', 'select_all')
		self.setProperty('heading', self.heading)
		self.setProperty('narrow_window', self.narrow_window)
		# LOCAL PATCH 2026-11-07: dialogs redesign -- 'wide' keeps the art pane (items with art) or the OK / Cancel column (multi
		# choice); anything else is a compact panel sized to its rows (select.xml draws 1-8 row panels)
		wide = self.multi_choice == 'true' or (self.row_art() and self.narrow_window != 'true')   # multi: its buttons need the room
		self.setProperty('layout', 'wide' if wide else 'compact')
		# LOCAL PATCH 2026-11-08: the wide panel fits its rows too (select.xml, 3-8 rows): the art pane needs the full height, a
		# multi choice's OK / Cancel / Select All column 3 rows
		rows = max(1, min(len(self.items), 8))
		if wide: rows = 8 if self.row_art() else max(3, rows)
		self.setProperty('rows', str(rows))

class Confirm(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.ok_label = kwargs['ok_label']
		self.cancel_label = kwargs['cancel_label']
		self.text = kwargs['text']
		self.heading = kwargs['heading']
		self.default_control = kwargs['default_control']
		self.selected = None
		self.set_properties()
		self.track_buttons((10, 11))   # LOCAL PATCH 2026-11-07: the last-used button stays yellow (base_window)

	def onInit(self):
		self.setFocusId(self.default_control)

	def run(self):
		self.doModal()
		self.clearProperties()   # LOCAL PATCH 2026-10-24: re-sets the glass colours for the close fade (base_window)
		return self.selected

	def onClick(self, controlID):
		self.selected = {10: True, 11: False}[controlID]
		self.close()

	def onAction(self, action):
		if action in self.closing_actions: self.close()

	def set_properties(self):
		self.setProperty('ok_label', self.ok_label)
		self.setProperty('cancel_label', self.cancel_label)
		self.setProperty('text', self.text)
		self.setProperty('heading', self.heading)

class OK(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.ok_label = kwargs.get('ok_label')
		self.text = kwargs['text']
		self.heading = kwargs['heading']
		self.set_properties()

	def run(self):
		self.doModal()
		self.clearProperties()   # LOCAL PATCH 2026-10-24: re-sets the glass colours for the close fade (base_window)

	def onClick(self, controlID):
		self.close()

	def onAction(self, action):
		if action in self.closing_actions:
			self.close()

	def set_properties(self):
		self.setProperty('ok_label', self.ok_label)
		self.setProperty('text', self.text)
		self.setProperty('heading', self.heading)
