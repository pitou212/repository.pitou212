# -*- coding: utf-8 -*-
from caches.base_cache import BaseCache, cache_ttl, single_flight
from modules.settings import lists_cache_duraton

class ListsCache(BaseCache):
	def __init__(self):
		BaseCache.__init__(self, 'lists_db', 'lists')

	def delete_all_lists(self):
		try:
			dbcon = self.manual_connect('lists_db')
			dbcon.execute('DELETE FROM lists WHERE id NOT LIKE %s' % "'ai_%'")
			dbcon.execute('VACUUM')
			return True
		except: return False

	def delete_all_ai_lists(self):
		try:
			dbcon = self.manual_connect('lists_db')
			dbcon.execute('DELETE FROM lists WHERE id LIKE %s' % "'ai_%'")
			dbcon.execute('VACUUM')
			return True
		except: return False

lists_cache = ListsCache()

def lists_cache_object(function, string, args, json=False, expiration=None):
	cache = lists_cache.get(string)
	if cache is not None: return cache
	with single_flight('lists:' + string):   # LOCAL PATCH 2026-11-08: one fetch per key (base_cache.single_flight)
		cache = lists_cache.get(string)
		if cache is not None: return cache
		if isinstance(args, list): args = tuple(args)
		else: args = (args,)
		if json: result = function(*args).json()
		else: result = function(*args)
		# LOCAL PATCH 2026-10-03 (Batch 3): base_cache.cache_ttl -- refusals are not stored, empties 0.3 h as before
		expiration = cache_ttl(result, expiration or lists_cache_duraton())
		if expiration: lists_cache.set(string, result, expiration=expiration)
		return result