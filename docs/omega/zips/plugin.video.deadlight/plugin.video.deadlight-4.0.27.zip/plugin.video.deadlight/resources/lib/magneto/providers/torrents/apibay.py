# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-09-29: apibay -- The Pirate Bay's JSON search API, searched by NAME.

	Replaces knaben (removed the same day: seconds per search). Timed 2026-09-29: 0.43-0.81 s per query,
	Reacher S02E01 25 rows, and the Monster: The Lizzie Borden Story packs (TMDb gives that show no IMDb id,
	so every IMDb-keyed provider finds nothing) -- the reason a name search is bundled at all.

	API: https://apibay.org/q.php?q=<query>&cat=0   No key. JSON list of at most 100 rows:
	  {'name', 'info_hash' (upper case), 'seeders', 'size' (bytes, as a string), 'category', 'imdb', ...}
	No hits is ONE placeholder row, 'No results returned' with an all-zero hash.
	Category 2xx is video (201 movies, 205 TV, 207 HD movies, 208 HD TV, ...); 1xx audio (soundtracks),
	6xx e-books and the rest are dropped.

	Episode / season-pack / show-pack queries (the pack ones in parallel threads), using client.request so the loading
	window's ok / failed tally sees it. LOCAL PATCH 2026-11-01 (cleanup): the bodies are provider_base.NameSearchSource's.
"""

import json
from magneto.modules.provider_base import NameSearchSource

_NO_HASH = '0' * 40


class source(NameSearchSource):
	provider = 'apibay'
	base_link = 'https://apibay.org'
	search_link = '/q.php?q=%s&cat=0'
	hash_key = 'info_hash'

	def _rows(self, results):
		return json.loads(results)

	def _valid(self, row, hash):
		"""video categories only, placeholder dropped"""
		return bool(hash) and hash != _NO_HASH and str(row.get('category', '')).startswith('2')
