# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-28: AniList (GraphQL) browse client, a stripped-down port of Otaku's AniListBrowser.py. Rate
# limit 30 req/min (X-RateLimit-Limit).
#
# Endpoint: https://graphql.anilist.co
# Docs: https://anilist.gitbook.io/anilist-apiv2-docs/
# All browse methods return: {'items': [...], 'has_next': bool, 'page': int}

import datetime
import time

from caches.lists_cache import lists_cache_object, lists_cache
from caches.base_cache import is_failed_result
from caches.settings_cache import get_setting, set_setting
from modules.kodi_utils import make_session, logger, notification, kodi_dialog, get_property, set_property, qr_dialog, cooldown_active, start_cooldown
from modules.utils import safe_err   # LOCAL PATCH 2026-10-25 (4.0.5): request errors logged without their url / query keys

_ANILIST_URL = 'https://graphql.anilist.co'
_APP_REGISTER_URL = 'https://anilist.co/settings/developer'

session = make_session(_ANILIST_URL)


# ═══════════════════════════════════════════════════════════════════════════
#  Account layer (LOCAL PATCH 2026-08-29)
#
#  Everything above the mutations stays anonymous -- browse never needs a token and must
#  keep working for users who never log in. Settings accessors strip whitespace, matching
#  simkl_api._client_id, because these values arrive by copy-paste.
# ═══════════════════════════════════════════════════════════════════════════

def _setting(name):
	val = (get_setting('deadlight.anilist.%s' % name, '') or '').strip()
	return val if val and val != 'empty_setting' else ''


def _access_token(): return _setting('token')


def _auth_headers():
	token = _access_token()
	return {'Authorization': 'Bearer %s' % token} if token else {}


def anilist_user_active():
	return bool(_access_token() and _setting('user'))

_SEASONS = ('WINTER', 'SPRING', 'SUMMER', 'FALL')

# GraphQL fragment for the Media fields we hand off to TMDb and display (Otaku's field list).
_MEDIA_FIELDS = '''
	id
	idMal
	title { romaji english native }
	coverImage { extraLarge large }
	bannerImage
	startDate { year month day }
	endDate { year }
	description
	format
	episodes
	status
	genres
	# LOCAL PATCH 2026-08-29: AniList tags are far more specific than TMDb genres
	# ("Female Protagonist", "Time Manipulation", "Episodic"). rank is 0-100 and
	# isMediaSpoiler marks the ones that give plot away -- both are needed to filter
	# sensibly, so pull all three fields.
	tags { name rank category isMediaSpoiler }
	duration
	averageScore
	countryOfOrigin
	trailer { id site }
'''


def _current_season():
	"""Return (season_enum, year) for the current calendar quarter."""
	now = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
	season = _SEASONS[(now.month - 1) // 3]
	return season, now.year


def _shift_season(base_season, base_year, direction):
	"""Advance/rewind by one season. direction=+1 for next, -1 for last."""
	idx = _SEASONS.index(base_season)
	new_idx = (idx + direction) % 4
	new_season = _SEASONS[new_idx]
	# Year rolls over on WINTER→FALL (backwards) or FALL→WINTER (forwards).
	if direction == 1 and base_season == 'FALL':
		return new_season, base_year + 1
	if direction == -1 and base_season == 'WINTER':
		return new_season, base_year - 1
	return new_season, base_year


def _season_for(period):
	"""period ∈ {'this', 'next', 'last'} → (season_enum, year)."""
	base_season, base_year = _current_season()
	if period == 'this': return base_season, base_year
	if period == 'next': return _shift_season(base_season, base_year, +1)
	if period == 'last': return _shift_season(base_season, base_year, -1)
	return base_season, base_year


# ═══════════════════════════════════════════════════════════════════════════
#  GraphQL POST + response cache
# ═══════════════════════════════════════════════════════════════════════════

def _warn_once(user_msg, log_msg):
	"""LOCAL PATCH 2026-09-07: one toast per Kodi session (the window property dies with Kodi)."""
	logger('AniList outage', log_msg)
	if get_property('deadlight.anilist.outage_warned') == 'true': return
	set_property('deadlight.anilist.outage_warned', 'true')
	notification(user_msg, 5000)


def _post_anilist(query, variables, auth=False, node='Page'):
	"""Uncached POST. lists_cache_object handles caching around this.

	auth=True attaches the user's bearer token -- required for anything touching Viewer or
	SaveMediaListEntry. node names the field to unwrap from `data`; the browse queries all
	return a Page, the account queries and mutations do not, so they pass node=None and get
	the whole `data` object back.
	"""
	# LOCAL PATCH 2026-10-20: while AniList's own back-off runs (a 429 / 5xx / timeout started it: _start_score_cooldown),
	# no request but the account ones (auth=True: list edits, scrobbles). None is the failure every caller already
	# handles, and none caches it.
	if not auth and anilist_score_on_cooldown(): return None
	try:
		# LOCAL PATCH 2026-09-07: browse sends the bearer token WHEN ONE EXISTS: AniList can disable anonymous access
		# (HTTP 403 'temporarily disabled due to severe stability issues') while bearer requests still work. With no
		# token _auth_headers() is {}, so a logged-out user sends the anonymous request.
		headers = _auth_headers() or None
		r = session.post(_ANILIST_URL, json={'query': query, 'variables': variables},
						headers=headers, timeout=15)
		# LOCAL PATCH 2026-09-07: if the TOKEN got a call that never needed one rejected, retry anonymously, so a stale
		# token cannot break browse. auth=True is excluded: meaningless without a user.
		# 400 is in the list because AniList answers a bad token with 400 ('Invalid token'), NOT 401. A malformed query
		# also yields 400; retrying it costs one wasted request.
		if r.status_code in (400, 401, 403) and not auth and headers:
			logger('AniList: token rejected on browse', 'HTTP %s -- retrying anonymously' % r.status_code)
			r = session.post(_ANILIST_URL, json={'query': query, 'variables': variables},
							headers=None, timeout=15)
		# A dead or revoked token answers 400/401 with an errors array; treat it like any
		# other miss rather than raising into a caller that may be tearing down playback.
		# LOCAL PATCH 2026-09-07: say so when AniList itself is down (403 'disabled'), or every menu just comes up empty.
		# Only reached when no token was sent, or the anonymous retry also failed.
		if r.status_code == 403 and not auth:
			try: _msg = str((r.json().get('errors') or [{}])[0].get('message', ''))
			except Exception: _msg = ''
			if 'disabled' in _msg.lower():
				# LOCAL PATCH 2026-10-21: the lists fall back to MyAnimeList / Kitsu (apis/anime_backup.py), and the outage
				# backs off like a 5xx does, so pages and score lookups stop asking twice before the backup starts.
				_warn_once('AniList has disabled its API (stability issues) - anime lists from MyAnimeList / Kitsu until it returns',
					'anonymous browse refused by AniList: %s' % _msg[:120])
				_start_score_cooldown(600, 'API disabled')
		if r.status_code in (400, 401) and auth:
			logger('AniList: auth rejected', 'HTTP %s -- token may be expired or revoked' % r.status_code)
			return None
		# LOCAL PATCH 2026-09-15: record a throttle, so per-title callers (anilist_score_and_tags) stop paying for
		# guaranteed failures; a bare None cannot tell "rate-limited" from "no score".
		if r.status_code == 429:
			try: _retry = int(r.headers.get('Retry-After') or 60)
			except (TypeError, ValueError): _retry = 60
			_start_score_cooldown(max(30, min(_retry, 3600)), 'HTTP 429')
			return None
		# LOCAL PATCH 2026-10-15: AniList DOWN backs off too, not only a 429 -- see the except below.
		if r.status_code >= 500:
			_start_score_cooldown(600, 'HTTP %s' % r.status_code)
			return None
		r.raise_for_status()
		data = r.json()
		if 'errors' in data:
			if auth: logger('AniList: query errors', str(data['errors'])[:200])
			return None
		data = data.get('data') or {}
		return data if node is None else data.get(node)
	# LOCAL PATCH 2026-10-15: a timeout or a refused connection starts the same cooldown (10 min): callers such as
	# metadata._anilist_air_times ask up to ~12 times per season read, each up to the 15 s timeout.
	# LOCAL PATCH 2026-10-19: requests' exceptions imported HERE, not at module level (that loads all of requests,
	# ~0.3 s, in every fresh interpreter). Once a request has raised, the lazy session has imported it anyway.
	except Exception as e:
		try:
			from requests import exceptions as _rq_exc
			if isinstance(e, (_rq_exc.Timeout, _rq_exc.ConnectionError)): _start_score_cooldown(600, type(e).__name__)
		except Exception: pass
		return None


# LOCAL PATCH 2026-10-03 (3.0.8): 20 per browse page, matching the TMDb catalogue pages: every row is a full TMDb meta
# build (a cold one costs a request), and a screen shows 10-14.
_BROWSE_PAGE_SIZE = 20

def _cached_page(cache_key, query, variables):
	"""Return {'items': [...], 'has_next': bool} from a cached AniList query.
	lists_cache_object stores the pickled result under `string=cache_key`."""
	# LOCAL PATCH 2026-10-22: Anime Catalogues = MyAnimeList / Kitsu -- that service first (the other one for a list it cannot
	# answer), AniList only when both fail. AniList chosen: AniList first and the backup on failure, as below.
	from modules.settings import anime_catalogue_provider
	provider = anime_catalogue_provider()
	if provider != 'anilist':
		try:
			from apis.anime_backup import page as backup_page
			chosen = backup_page(variables, first=provider, announce=False)
			if chosen: return chosen
		except Exception as e: logger('anime catalogues', '%s failed: %s' % (provider, safe_err(e)))
	def _fetch(_dummy_arg):
		res = _post_anilist(query, variables)
		# LOCAL PATCH 2026-09-07: never an empty-but-valid-looking page on failure -- {'items': [], ...} is a populated
		# dict and would be cached for the FULL TTL. The callers coalesce a falsy return.
		# LOCAL PATCH 2026-10-19: no answer (429, 5xx, timeout) is {'success': False}, which base_cache.cache_ttl never
		# stores ({} would keep 0.3 h and blank every anime row after one short throttle).
		if not res: return {'success': False}
		items = res.get('ANIME') or res.get('media') or []
		# LOCAL PATCH 2026-09-30: an EMPTY page is a failure too (short TTL): AniList sometimes answers with nothing,
		# and a browse page is never legitimately empty except one past the last.
		if not items: return {}
		_prime_entries(items)   # LOCAL PATCH 2026-10-20: the page's entries (episodes, titles, covers) -- see anilist_entries
		return {
			'items': items,
			'has_next': (res.get('pageInfo') or {}).get('hasNextPage', False),
		}
	# lists_cache_object signature: (function, string, *args) — pass a
	# throwaway arg since _fetch requires one.
	# LOCAL PATCH 2026-08-29 / 2026-10-03 (3.0.8): the key suffix versions the page shape (_t2: tags in _MEDIA_FIELDS,
	# 20 items); bump it when the shape changes so old rows are not read.
	result = lists_cache_object(_fetch, '%s_t2' % cache_key, 1)
	# LOCAL PATCH 2026-10-21: AniList did not answer (down, throttling, backing off) -- the same list from MyAnimeList or
	# Kitsu (apis/anime_backup.py) rather than an empty menu. Only a failure: an answered empty page is the end of a list.
	if is_failed_result(result):
		try:
			from apis.anime_backup import page as backup_page
			return backup_page(variables)
		except Exception as e:
			logger('anime backup', 'failed: %s' % safe_err(e))
			return {}   # the callers' `or {'items': [], ...}` takes it from here
	# LOCAL PATCH 2026-10-20: the page already carries each title's score, tags and genres (_MEDIA_FIELDS) -- prime them,
	# so the rating flush after the list (metadata._prime_anilist_scores) does not ask AniList for them again
	for media in (result or {}).get('items') or []:
		try:
			if 'averageScore' in media and int(media['id']) not in _SCORES_PRIMED: _SCORES_PRIMED[int(media['id'])] = _score_record(media)
		except (KeyError, TypeError, ValueError): continue
	return result


# ═══════════════════════════════════════════════════════════════════════════
#  Query templates
# ═══════════════════════════════════════════════════════════════════════════

_BROWSE_QUERY = '''
query (
	$page: Int = 1,
	$perpage: Int = 25,
	$type: MediaType,
	$isAdult: Boolean = false,
	$season: MediaSeason,
	$year: String,
	$status: MediaStatus,
	$format: [MediaFormat],
	$genre: [String],
	$sort: [MediaSort] = [POPULARITY_DESC, SCORE_DESC]
) {
	Page(page: $page, perPage: $perpage) {
		pageInfo { hasNextPage }
		ANIME: media(
			type: $type,
			season: $season,
			startDate_like: $year,
			sort: $sort,
			status: $status,
			format_in: $format,
			genre_in: $genre,
			isAdult: $isAdult
		) {
''' + _MEDIA_FIELDS + '''
		}
	}
}
'''

_SEARCH_QUERY = '''
query ($page: Int = 1, $perpage: Int = 25, $search: String, $type: MediaType, $isAdult: Boolean = false) {
	Page(page: $page, perPage: $perpage) {
		pageInfo { hasNextPage }
		ANIME: media(
			search: $search,
			type: $type,
			sort: SEARCH_MATCH,
			isAdult: $isAdult
		) {
''' + _MEDIA_FIELDS + '''
		}
	}
}
'''


# ═══════════════════════════════════════════════════════════════════════════
#  Public browse methods — one per menu entry
#  All return {'items': [...], 'has_next': bool, 'page': int}
# ═══════════════════════════════════════════════════════════════════════════

def _airing_season(period, sort, page_no):
	season, year = _season_for(period)
	variables = {
		'page': int(page_no),
		'perpage': _BROWSE_PAGE_SIZE,
		'type': 'ANIME',
		'season': season,
		'year': '%s%%' % year,
		'sort': [sort],
	}
	cache_key = 'anilist_airing_%s_%s_%s' % (period, sort, page_no)
	res = _cached_page(cache_key, _BROWSE_QUERY, variables) or {'items': [], 'has_next': False}
	res['page'] = int(page_no)
	return res


# LOCAL PATCH 2026-09-04: fmt/genre ride the same engine: AniList's media() takes format_in and genre_in, so a format
# row (Otaku's Movies / TV Shorts / OVAs / ONAs / Specials) is the ranked browse with one more filter.
def _ranked(sort, period_mode, page_no, fmt=None, genre=None):
	"""period_mode ∈ {'all_time', 'this_year', 'last_year', 'this_season', 'last_season'}"""
	variables = {
		'page': int(page_no),
		'perpage': _BROWSE_PAGE_SIZE,
		'type': 'ANIME',
		'sort': [sort],
	}
	if period_mode == 'this_year':
		variables['year'] = '%s%%' % datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None).year
	elif period_mode == 'last_year':
		variables['year'] = '%s%%' % (datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None).year - 1)
	elif period_mode == 'this_season':
		season, year = _season_for('this')
		variables['season'] = season
		variables['year'] = '%s%%' % year
	elif period_mode == 'last_season':
		season, year = _season_for('last')
		variables['season'] = season
		variables['year'] = '%s%%' % year
	# 'all_time' -> no year/season filter
	if fmt: variables['format'] = list(fmt)
	if genre: variables['genre'] = list(genre)
	# the filters MUST reach the cache key or every format row would serve whichever one
	# was fetched first out of lists_cache.
	cache_key = 'anilist_%s_%s_%s%s%s' % (sort, period_mode, page_no,
			'_f' + '.'.join(fmt) if fmt else '', '_g' + '.'.join(genre) if genre else '')
	res = _cached_page(cache_key, _BROWSE_QUERY, variables) or {'items': [], 'has_next': False}
	res['page'] = int(page_no)
	return res


# Season / airing
# LOCAL PATCH 2026-10-20: this / last season are the SAME request as Popular This Season / Trending Last Season, so they
# go through _ranked and share one cache row. Next season has no _ranked twin.
def anilist_airing_this_season(page_no): return _ranked('POPULARITY_DESC', 'this_season', page_no)
def anilist_airing_next_season(page_no): return _airing_season('next', 'POPULARITY_DESC', page_no)
def anilist_airing_last_season(page_no): return _ranked('TRENDING_DESC', 'last_season', page_no)

# Trending
def anilist_trending_this_season(page_no): return _ranked('TRENDING_DESC', 'this_season', page_no)
def anilist_trending_this_year(page_no):   return _ranked('TRENDING_DESC', 'this_year', page_no)
def anilist_trending_all_time(page_no):    return _ranked('TRENDING_DESC', 'all_time', page_no)

# Popular
def anilist_popular_this_season(page_no):  return _ranked('POPULARITY_DESC', 'this_season', page_no)
def anilist_popular_this_year(page_no):    return _ranked('POPULARITY_DESC', 'this_year', page_no)
def anilist_popular_all_time(page_no):     return _ranked('POPULARITY_DESC', 'all_time', page_no)

# Top rated
def anilist_top_100(page_no):              return _ranked('SCORE_DESC', 'all_time', page_no)

# Most favorited
def anilist_favourites_all_time(page_no):  return _ranked('FAVOURITES_DESC', 'all_time', page_no)

# LOCAL PATCH 2026-09-04: periods the engine already supported but nothing exposed.
def anilist_popular_last_year(page_no):    return _ranked('POPULARITY_DESC', 'last_year', page_no)
def anilist_trending_last_season(page_no): return _ranked('TRENDING_DESC', 'last_season', page_no)

# LOCAL PATCH 2026-09-04: browse by format. MUSIC is deliberately absent: anilist_lists._classify drops it, so the row
# would display nothing.
def anilist_movies(page_no):     return _ranked('POPULARITY_DESC', 'all_time', page_no, fmt=['MOVIE'])
def anilist_tv_shorts(page_no):  return _ranked('POPULARITY_DESC', 'all_time', page_no, fmt=['TV_SHORT'])
def anilist_ovas(page_no):       return _ranked('POPULARITY_DESC', 'all_time', page_no, fmt=['OVA'])
def anilist_onas(page_no):       return _ranked('POPULARITY_DESC', 'all_time', page_no, fmt=['ONA'])
def anilist_specials(page_no):   return _ranked('POPULARITY_DESC', 'all_time', page_no, fmt=['SPECIAL'])

# LOCAL PATCH 2026-10-27: browse by genre (Anime > Genres), most popular first. AniList's own genre list, which is short and
# fixed (the finer ones, Isekai and the like, are tags). No Hentai: _BROWSE_QUERY asks isAdult false, so it would be empty.
ANILIST_GENRES = ('Action', 'Adventure', 'Comedy', 'Drama', 'Ecchi', 'Fantasy', 'Horror', 'Mahou Shoujo', 'Mecha', 'Music',
				'Mystery', 'Psychological', 'Romance', 'Sci-Fi', 'Slice of Life', 'Sports', 'Supernatural', 'Thriller')
def anilist_genre(genre, page_no): return _ranked('POPULARITY_DESC', 'all_time', page_no, genre=[genre])


# ═══════════════════════════════════════════════════════════════════════════
#  Watch order (LOCAL PATCH 2026-10-27)
#
#  A franchise's entries in the order to watch them, from AniList's relation graph: the PREQUEL / SEQUEL / SIDE_STORY /
#  PARENT / SUMMARY links stay in the story and are followed, ALTERNATIVE is recorded but not followed, SPIN_OFF /
#  CHARACTER / OTHER are left out. One request reaches two levels of relations (a third comes back empty), so a
#  franchise takes about half as many requests as its longest chain has entries, at most _WO_MAX_CALLS. Release order,
#  then each entry labelled from the links that point AT it:
#    upcoming     not released yet: listed last, unnumbered
#    alternative  a film telling a TV entry's story (Mugen Train film / TV arc): one step
#    recap        something SUMMARY points at
#    side story   only SIDE_STORY / PARENT point at it
#    optional     an OVA / special / ONA / short nothing continues into
#    main         the rest, numbered
# ═══════════════════════════════════════════════════════════════════════════

_WO_FORMATS = frozenset(('TV', 'TV_SHORT', 'MOVIE', 'OVA', 'ONA', 'SPECIAL'))
_WO_FOLLOW = frozenset(('PREQUEL', 'SEQUEL', 'SIDE_STORY', 'PARENT', 'SUMMARY'))
_WO_MAX_CALLS, _WO_MAX_NODES = 6, 40
_WO_FIELDS = 'id type format status episodes duration title { romaji english } startDate { year month day } coverImage { large } bannerImage'

def _wo_media(depth):
	if depth == 0: return 'id type format'
	return _WO_FIELDS + ' relations { edges { relationType node { %s } } }' % _wo_media(depth - 1)

_WO_QUERY = 'query ($ids: [Int]) { Page(perPage: 50) { media(id_in: $ids, type: ANIME) { %s } } }' % _wo_media(2)   # AniList answers relations two levels deep; a third level comes back empty


def _wo_walk(seed_id):
	"""({id: entry}, {id: [(relationType, id)]}, requests made) for the franchise around seed_id."""
	nodes, edges, done, frontier, calls = {}, {}, set(), [int(seed_id)], 0
	def keep(m):
		nodes.setdefault(m['id'], {'id': m['id'], 'format': m.get('format'), 'status': m.get('status'), 'episodes': m.get('episodes'), 'duration': m.get('duration'),
			'title': (m.get('title') or {}).get('english') or (m.get('title') or {}).get('romaji') or '',
			'english': (m.get('title') or {}).get('english') or '', 'romaji': (m.get('title') or {}).get('romaji') or '',
			'date': [(m.get('startDate') or {}).get(k) for k in ('year', 'month', 'day')],
			'cover': (m.get('coverImage') or {}).get('large') or '', 'banner': m.get('bannerImage') or ''})
	def visit(m, pending):
		mid = m['id']
		if 'relations' not in m:
			if mid not in done: pending.add(mid)
			return
		if mid in done: return
		done.add(mid)
		keep(m)
		for e in m['relations'].get('edges') or []:
			n, rel = e.get('node') or {}, e.get('relationType')
			if n.get('type') != 'ANIME' or n.get('format') not in _WO_FORMATS: continue
			if rel == 'ALTERNATIVE':
				edges.setdefault(mid, []).append((rel, n['id']))
				if 'title' in n: keep(n)
			elif rel in _WO_FOLLOW:
				edges.setdefault(mid, []).append((rel, n['id']))
				visit(n, pending)
	while frontier and calls < _WO_MAX_CALLS and len(done) < _WO_MAX_NODES:
		batch, frontier = frontier[:25], frontier[25:]
		res = _post_anilist(_WO_QUERY, {'ids': batch})
		calls += 1
		if not res: break
		pending = set()
		for m in res.get('media') or []: visit(m, pending)
		frontier.extend(i for i in pending if i not in done and i not in frontier)
	return nodes, edges, calls


def _wo_english(nodes):
	"""LOCAL PATCH 2026-10-31: an entry with no English title (a sequel only just announced) is named after the entry whose
	romaji it extends: 'Futsutsuka na Akujo de wa Gozaimasu ga: Suuguu Chouso Torikae Den Part 2' (AniList 217070) ->
	'Though I Am an Inept Villainess Part 2'. The longest such romaji wins; with none the romaji stays."""
	named = [n for n in nodes.values() if n.get('english') and n.get('romaji')]
	for n in nodes.values():
		if n.get('english') or not n.get('romaji'): continue
		base = max((b for b in named if b is not n and n['romaji'].startswith(b['romaji']) and len(n['romaji']) > len(b['romaji'])),
				   key=lambda b: len(b['romaji']), default=None)
		if base: n['title'] = (base['english'] + n['romaji'][len(base['romaji']):]).strip()

def _wo_when(n):
	"""Release-order sort key: (year, month, day), unknown parts last, no date at all after everything."""
	return tuple(v or 99 for v in n['date']) if n['date'][0] else (9999, 99, 99)


def _wo_steps(nodes, edges):
	_wo_english(nodes)
	inbound, alt_of = {}, {}
	for src, links in edges.items():
		for rel, dst in links:
			inbound.setdefault(dst, set()).add(rel)
			if rel != 'ALTERNATIVE' or src not in nodes or dst not in nodes: continue
			a, b = nodes[src], nodes[dst]
			if a['format'] == 'MOVIE' and b['format'] != 'MOVIE': alt_of[src] = dst
			elif b['format'] == 'MOVIE' and a['format'] != 'MOVIE': alt_of[dst] = src
			# LOCAL PATCH 2026-11-01: an OVA / ONA that retells a TV entry hangs under the earliest TV entry it retells
			# ('or watch this instead', e.g. JoJo's 1993 OVAs). A SERIES only (3+ episodes): AniList tags one-offs (a PV)
			# ALTERNATIVE too, and those stay extras
			else:
				retelling = lambda n: n['format'] in ('OVA', 'ONA') and (n['episodes'] or 0) >= 3
				short, tv = (src, dst) if retelling(a) and b['format'] == 'TV' else \
					(dst, src) if retelling(b) and a['format'] == 'TV' else (None, None)
				if short and (short not in alt_of or _wo_when(nodes[tv]) < _wo_when(nodes[alt_of[short]])): alt_of[short] = tv
	# LOCAL PATCH 2026-11-01: an OVA / special / ONA / short is main when it CONTINUES the main line, not merely when it is
	# somebody's sequel (a web series is all ONAs). With prequels: main if any prequel is main; with none: main when it
	# heads a series (not a side story, and something continues from it); otherwise optional. TV and films are main.
	prequels = {}
	for src, links in edges.items():
		for rel, dst in links:
			if rel == 'SEQUEL' and src in nodes: prequels.setdefault(dst, set()).add(src)
			elif rel == 'PREQUEL' and dst in nodes: prequels.setdefault(src, set()).add(dst)
	memo = {}
	def kind(i):
		if i not in memo:
			memo[i] = 'optional'   # a relation cycle reads as optional instead of recursing forever
			memo[i] = _kind(i)
		return memo[i]
	def _kind(i):
		n, inb = nodes[i], inbound.get(i, set())
		if n['status'] == 'NOT_YET_RELEASED': return 'upcoming'
		if i in alt_of: return 'alternative'
		if 'SUMMARY' in inb: return 'recap'
		if inb and inb <= {'SIDE_STORY', 'PARENT', 'ALTERNATIVE'} and inb != {'ALTERNATIVE'}: return 'side story'
		if n['format'] in ('OVA', 'SPECIAL', 'ONA', 'TV_SHORT'):
			# release order throughout: a prequel STORY released later does not decide what came first, and a head must air
			# before what continues from it (an OVA released after the series it 'continues' into is an extra)
			before = [p for p in prequels.get(i, ()) if p in nodes and p != i and when(nodes[p]) <= when(n)]
			if before: return 'main' if any(kind(p) == 'main' for p in before) else 'optional'
			if 'SIDE_STORY' in inb: return 'optional'
			if any(rel == 'SEQUEL' and dst in nodes and when(n) < when(nodes[dst]) for rel, dst in edges.get(i, ())): return 'main'
			return 'main' if (n['episodes'] or 0) >= 6 else 'optional'   # a series in its own right (Hellsing Ultimate, 10 OVAs)
		return 'main'
	when = lambda n: tuple(v or 99 for v in n['date']) if n['date'][0] else (9999, 99, 99)
	steps, number = [], 0
	for n in sorted(nodes.values(), key=when):
		k = kind(n['id'])
		if k in ('upcoming', 'alternative'): continue
		if k == 'main': number += 1
		steps.append(dict(n, kind=k, number=number if k == 'main' else None))
		for alt_id in sorted((a for a, t in alt_of.items() if t == n['id']), key=lambda a: when(nodes[a])):
			steps.append(dict(nodes[alt_id], kind='alternative', number=None))
	steps.extend(dict(n, kind='upcoming', number=None) for n in sorted(nodes.values(), key=when) if kind(n['id']) == 'upcoming')
	return steps


def anilist_watch_order(anilist_id):
	"""[step] for the franchise around anilist_id, each step an entry dict plus 'kind' and 'number' (see above). Cached
	7 days under every member's id, so the same franchise opened from another season or a film costs nothing."""
	if not anilist_id: return []
	from caches.main_cache import main_cache
	def _fetch(seed):
		nodes, edges, calls = _wo_walk(seed)
		logger('anilist.watch_order', 'anilist %s: %d entries, %d AniList requests' % (seed, len(nodes), calls))
		return _wo_steps(nodes, edges) if nodes else []
	# any member walks to the same franchise, so each member remembers whose walk it is in
	seed = main_cache.get('anilist_wo_member_%s' % anilist_id) or int(anilist_id)
	# LOCAL PATCH 2026-10-31 / 2026-11-01: the key's _vN versions the step shape (banner, borrowed English title, main-line
	# rule, retellings, duration); bump it when _wo_steps changes
	steps = lists_cache_object(_fetch, 'anilist_watch_order_v5_%s' % seed, seed, expiration=168) or []
	for s in steps: main_cache.set('anilist_wo_member_%s' % s['id'], seed, expiration=168)
	return steps


# Search
def anilist_search(query, page_no):
	variables = {'page': int(page_no), 'perpage': 25, 'search': query, 'type': 'ANIME'}
	cache_key = 'anilist_search_%s_%s' % (query, page_no)
	res = _cached_page(cache_key, _SEARCH_QUERY, variables) or {'items': [], 'has_next': False}
	res['page'] = int(page_no)
	return res


# ═══════════════════════════════════════════════════════════════════════════
#  Romaji title lookup by MAL id
#
#  LOCAL PATCH 2026-08-10: replaces the `mal_title` column of the retired (frozen)
#  anime_mappings DB. Romaji titles are what anime releases use ("Tensei Shitara
#  Slime Datta Ken"), so this feeds the search-alias path in scrapers/external.py.
#  ~600 ms per uncached call, so cached 30 days (romaji titles never change); the
#  bulk variant fetches every cour of a show in ONE request.
# ═══════════════════════════════════════════════════════════════════════════

# LOCAL PATCH 2026-10-03 (Batch 4): MAL ids are NOT unique on AniList (one MAL id can be two AniList entries). Every
# MAL-keyed query below asks for `id` and `sort: ID` so a split comes back in a known order and is resolved on purpose
# (_pick_per_mal). 25 MAL ids per request: a split returns more rows than ids, and the page holds 50.
_MAL_CHUNK = 25

_ROMAJI_BY_MAL_QUERY = '''
query ($idMal: Int) {
	Page(page: 1, perPage: 1) {
		ANIME: media(idMal: $idMal, type: ANIME, sort: ID) {
			id
			idMal
			title { romaji english native }
		}
	}
}
'''

_ROMAJI_BULK_QUERY = '''
query ($idMal_in: [Int]) {
	Page(page: 1, perPage: 50) {
		ANIME: media(idMal_in: $idMal_in, type: ANIME, sort: ID) {
			id
			idMal
			title { romaji english native }
			coverImage { extraLarge large }
		}
	}
}
'''

_MEDIA_BULK_BY_ID_QUERY = '''
query ($ids: [Int]) {
	Page(page: 1, perPage: 50) {
		ANIME: media(id_in: $ids, type: ANIME) {
			id
			idMal
			episodes
			startDate { year month day }
			title { romaji english native }
			coverImage { extraLarge large }
		}
	}
}
'''


def _fribb_anilist_for_mal(mal_id):
	try:
		from caches.fribb_mappings import mal_to_fribb
		return int((mal_to_fribb(mal_id) or {}).get('anilist_id') or 0) or None
	except Exception: return None


def _pick_per_mal(medias):
	"""({mal_id: media}, {split mal ids}) from AniList media nodes. When one MAL id came back as several entries,
	the one Fribb maps that MAL id to wins (Fribb's row is what every other id lookup here follows), else the
	lowest AniList id -- the original entry, which is also what the single-id lookup has always returned."""
	groups = {}
	for media in medias or []:
		try: groups.setdefault(int(media.get('idMal')), []).append(media)
		except (TypeError, ValueError): continue
	out, split = {}, set()
	for mid, nodes in groups.items():
		nodes = sorted(nodes, key=lambda m: int(m.get('id') or 0))
		pick = nodes[0]
		if len(nodes) > 1:
			split.add(mid)
			want = _fribb_anilist_for_mal(mid)
			pick = next((m for m in nodes if want and int(m.get('id') or 0) == want), nodes[0])
		out[mid] = pick
	return out, split

_TITLE_CACHE_HOURS = 720   # 30 days — romaji titles are immutable in practice


def _pick_romaji(media):
	"""Prefer romaji (what release groups use), fall back to native then english."""
	t = (media or {}).get('title') or {}
	return t.get('romaji') or t.get('native') or t.get('english') or None


def anilist_romaji_for_mal(mal_id):
	"""MAL id -> romaji title (str) or None. Cached 30 days."""
	if not mal_id: return None
	try: mal_id = int(mal_id)
	except (TypeError, ValueError): return None
	def _fetch(_dummy):
		res = _post_anilist(_ROMAJI_BY_MAL_QUERY, {'idMal': mal_id})
		# A failed request returns {} (0.3 h TTL, retried soon); a real miss caches the '' sentinel for the full TTL.
		if res is None: return {}
		media = res.get('ANIME') or res.get('media') or []
		return {'title': (_pick_romaji(media[0]) if media else None) or ''}
	# LOCAL PATCH 2026-10-03 (Batch 4): new key; the old anilist_romaji_<mal> rows could hold a split MAL id's wrong title.
	out = lists_cache_object(_fetch, 'anilist_romaji_mal_%s' % mal_id, 1, expiration=_TITLE_CACHE_HOURS)
	return (out or {}).get('title') or None


def _pick_cover(media):
	"""Best cover image URL for a media node, or None.

	LOCAL PATCH 2026-08-27: each cour of an anime is its own AniList entry with its own
	cover, which is what makes per-cour season art possible.
	"""
	c = (media or {}).get('coverImage') or {}
	return c.get('extraLarge') or c.get('large') or None


def anilist_media_bulk(mal_ids):
	"""Fetch title AND cover art for up to 50 MAL ids in ONE request.

	Returns {mal_id: {'title': str|None, 'poster': str|None}}.

	LOCAL PATCH 2026-08-27: coverImage rides along in the same query that names the cours.
	"""
	ids = []
	for m in (mal_ids or []):
		try: ids.append(int(m))
		except (TypeError, ValueError): continue
	if not ids: return {}
	ids = ids[:50]
	# LOCAL PATCH 2026-10-19: cached a week per id set (otherwise asked on every anime season list with a MAL-only cour,
	# ~1.3 s). A failed request is {'success': False}, never stored (base_cache.cache_ttl).
	def _fetch(_dummy):
		medias = []
		for i in range(0, len(ids), _MAL_CHUNK):   # LOCAL PATCH 2026-10-03 (Batch 4): see _MAL_CHUNK
			res = _post_anilist(_ROMAJI_BULK_QUERY, {'idMal_in': ids[i:i + _MAL_CHUNK]})
			if res is None: return {'success': False}
			medias += res.get('ANIME') or res.get('media') or []
		return {'medias': medias}
	got = lists_cache_object(_fetch, 'anilist_mal_bulk_%s' % '_'.join(str(i) for i in sorted(ids)), 1, expiration=168)
	if not isinstance(got, dict) or is_failed_result(got): return {}
	picked, split = _pick_per_mal(got.get('medias') or [])
	out = {}
	for mid, media in picked.items():
		title, poster = _pick_romaji(media), _pick_cover(media)
		# LOCAL PATCH 2026-09-23: the English title as well, for DISPLAY only. It was already in
		# the reply and thrown away. 'title' stays romaji -- external.py matches releases with it.
		title_en = ((media.get('title') or {}).get('english') or '').strip() or None
		if title or poster: out[mid] = {'title': title, 'title_en': title_en, 'poster': poster}
	# Warm the per-id cache so subsequent single lookups are free -- except for a split MAL id, whose title
	# depends on which entry is meant; that one is left to the single lookup.
	for mid, rec in out.items():
		if mid in split: continue
		try:
			lists_cache_object(lambda _d, _r=rec: dict(_r), 'anilist_romaji_mal_%s' % mid, 1, expiration=_TITLE_CACHE_HOURS)
		except Exception: pass
	return out


# LOCAL PATCH 2026-10-20: ONE per-id store (anilist_entry_<id>) for what every cour lookup asks of an AniList entry --
# idMal, episode count, romaji / English title, cover. Not keyed by id SET: overlapping sets re-asked the same entries,
# and AniList's per-minute allowance is what throttles anime browsing. Missing ids go in one request; a browse page
# writes its own entries in for free (_prime_entries). An unknown id is stored as such a day; a failed request stores
# nothing. A still-airing entry's count is null until AniList fixes it, so that row lives a day.
_ENTRY_HOURS, _ENTRY_OPEN_HOURS, _ENTRY_UNKNOWN_HOURS = 720, 24, 24

def _entry_record(media):
	try: mal = int(media.get('idMal') or 0) or None
	except (TypeError, ValueError): mal = None
	try: episodes = int(media['episodes']) if media.get('episodes') is not None else None
	except (TypeError, ValueError): episodes = None
	rec = {'idMal': mal, 'episodes': episodes, 'title': _pick_romaji(media), 'poster': _pick_cover(media),
			'title_en': ((media.get('title') or {}).get('english') or '').strip() or None}
	# LOCAL PATCH 2026-10-25 (4.0.5): the premiere date, for the cour checks (caches/fribb_mappings._e1_date). Only when the
	# reply carried startDate, so an entry cached before it -- or primed from a browse page without it -- reads as not known.
	if 'startDate' in media:
		sd = media.get('startDate') or {}
		try: rec['start'] = '%04d-%02d-%02d' % (int(sd['year']), int(sd['month']), int(sd['day']))
		except (KeyError, TypeError, ValueError): rec['start'] = None
	return rec

def _store_entry(anilist_id, rec):
	hours = _ENTRY_UNKNOWN_HOURS if rec.get('unknown') else _ENTRY_HOURS if rec.get('episodes') is not None else _ENTRY_OPEN_HOURS
	try: lists_cache.set('anilist_entry_%s' % anilist_id, rec, expiration=hours)
	except Exception: pass

def _prime_entries(medias):
	"""Entries from media nodes another query already returned (a browse page). Only nodes carrying every field."""
	for media in medias or []:
		try:
			if 'episodes' in media and 'idMal' in media and 'title' in media and 'coverImage' in media:
				_store_entry(int(media['id']), _entry_record(media))
		except (KeyError, TypeError, ValueError): continue

def anilist_start_dates(anilist_ids, cached_only=False):
	"""LOCAL PATCH 2026-10-25 (4.0.5): {anilist_id: 'YYYY-MM-DD'} -- each entry's premiere, from the same per-id cache and
	50-a-request query as anilist_entries (an entry cached before startDate was asked is fetched again, once)."""
	return dict((a, rec['start']) for a, rec in anilist_entries(anilist_ids, cached_only, need_start=True).items() if rec.get('start'))

def anilist_entries(anilist_ids, cached_only=False, need_start=False):
	"""{anilist_id: {'idMal', 'episodes', 'title', 'title_en', 'poster'}} for the ids AniList knows. Cached ids are read,
	the rest go out 50 per request (cached_only: never -- widget calls). A failed request leaves its ids out, uncached.
	need_start: an entry cached without 'start' (before 4.0.5) counts as missing."""
	ids = []
	for a in (anilist_ids or []):
		try: a = int(a)
		except (TypeError, ValueError): continue
		if a not in ids: ids.append(a)
	out, missing = {}, []
	for a in ids:
		try: hit = lists_cache.get('anilist_entry_%s' % a)
		except Exception: hit = None
		if not isinstance(hit, dict) or (need_start and not hit.get('unknown') and 'start' not in hit): missing.append(a)
		elif not hit.get('unknown'): out[a] = hit
	if cached_only: return out
	for i in range(0, len(missing), 50):
		chunk = missing[i:i + 50]
		res = _post_anilist(_MEDIA_BULK_BY_ID_QUERY, {'ids': chunk})
		if res is None: break   # failed (or AniList's cooldown): nothing stored, asked again next time
		got = {}
		for media in (res.get('ANIME') or res.get('media') or []):
			try: got[int(media['id'])] = _entry_record(media)
			except (KeyError, TypeError, ValueError): continue
		for a in chunk:
			rec = got.get(a) or {'unknown': True}
			_store_entry(a, rec)
			if a in got: out[a] = rec
		if i + 50 < len(missing): time.sleep(_RATE_MIN_INTERVAL)
	return out


def anilist_media_bulk_by_id(anilist_ids):
	"""LOCAL PATCH 2026-10-03 (Batch 4): anilist_media_bulk keyed by AniList id -- {anilist_id: {'title', 'title_en',
	'poster'}}. For cours, whose Fribb row names the exact AniList entry. LOCAL PATCH 2026-10-20: from anilist_entries."""
	return dict((a, {'title': rec.get('title'), 'title_en': rec.get('title_en'), 'poster': rec.get('poster')})
				for a, rec in anilist_entries(anilist_ids).items() if rec.get('title') or rec.get('poster'))


# LOCAL PATCH 2026-10-02: full media for a list of MAL ids, for the MyAnimeList lists (indexers/mal_lists.py): MAL's
# own API carries little art and no cour metadata; AniList has both, in the shape anilist_lists._render reads.
_MEDIA_BY_MAL_QUERY = '''
query ($idMal_in: [Int]) {
	Page(page: 1, perPage: 50) {
		media(idMal_in: $idMal_in, type: ANIME, sort: ID) { %s }
	}
}
''' % _MEDIA_FIELDS


def anilist_media_by_mal(mal_ids):
	"""{mal_id: AniList media dict} for every MAL id AniList knows. Unknown ids are simply absent."""
	ids = []
	for m in (mal_ids or []):
		try: ids.append(int(m))
		except (TypeError, ValueError): continue
	# LOCAL PATCH 2026-10-03 (Batch 4): 25 ids a request (_MAL_CHUNK); one entry per MAL id, chosen by _pick_per_mal.
	medias = []
	for i in range(0, len(ids), _MAL_CHUNK):
		res = _post_anilist(_MEDIA_BY_MAL_QUERY, {'idMal_in': ids[i:i + _MAL_CHUNK]})
		medias += (res or {}).get('media') or []
	return _pick_per_mal(medias)[0]


def anilist_romaji_bulk(mal_ids):
	"""{mal_id: romaji}. Thin wrapper kept so existing callers are untouched."""
	return {mid: rec['title'] for mid, rec in (anilist_media_bulk(mal_ids) or {}).items()
			if rec.get('title')}


# LOCAL PATCH 2026-09-01: per-cour episode counts, for the Fribb flat-season repair (fribb_mappings._anilist_boundaries):
# Fribb records no episode_offset when TMDb has flattened one-cour-per-season cours into a single season, and each cour
# is its own AniList entry with its own length.
_EPISODES_BULK_QUERY = '''
query ($ids: [Int]) {
	Page(page: 1, perPage: 50) {
		ANIME: media(idMal_in: $ids, type: ANIME, sort: ID) {
			id
			idMal
			episodes
		}
	}
}
'''

# A finished cour's episode count never changes. A still-airing one reports null and is
# simply absent from the result, so 7 days only governs how soon it is re-asked.
_EPISODE_COUNT_CACHE_HOURS = 168


def anilist_episode_counts(ids, by='mal', cached_only=False):
	"""{id: episode_count} for up to 50 ids, by MAL id (by='mal') or AniList id (by='id').

	Ids AniList does not know, and cours it reports with `episodes: null` (still
	airing, final count not yet fixed), are ABSENT from the returned dict rather
	than present as zero -- callers must treat a missing id as unknown.
	LOCAL PATCH 2026-10-03 (Batch 4): so is a MAL id AniList splits into several entries -- it has no single count.
	"""
	clean = []
	for m in (ids or []):
		try: clean.append(int(m))
		except (TypeError, ValueError): continue
	if not clean: return {}
	ids = sorted(set(clean))[:50]
	# LOCAL PATCH 2026-10-20: by AniList id, from the per-id entry store (anilist_entries): callers ask for different
	# subsets of one show's cours. By MAL id stays per id set (a split MAL id has no single count).
	if by == 'id':
		return dict((a, rec['episodes']) for a, rec in anilist_entries(ids, cached_only=cached_only).items()
					if rec.get('episodes') is not None)
	def _fetch(_dummy):
		out, seen = {}, {}
		for i in range(0, len(ids), _MAL_CHUNK):
			res = _post_anilist(_EPISODES_BULK_QUERY, {'ids': ids[i:i + _MAL_CHUNK]})
			# None is a failed request; {} earns the 0.3 h TTL instead of a week.
			if res is None: return {}
			for media in (res.get('ANIME') or res.get('media') or []):
				key, eps = media.get('idMal'), media.get('episodes')
				if key is None: continue
				seen[key] = seen.get(key, 0) + 1
				if eps is None: continue
				try: out[int(key)] = int(eps)
				except (TypeError, ValueError): pass
		for key, n in seen.items():
			if n > 1: out.pop(int(key), None)
		return out
	key = 'anilist_epcounts_mal_%s' % '_'.join(str(i) for i in ids)
	# LOCAL PATCH 2026-10-16: cached_only -- the stored answer or {}, never a request (widget calls, see
	# fribb_mappings._checked_offsets)
	if cached_only:
		try: result = lists_cache.get(key)
		except Exception: result = None
	else: result = lists_cache_object(_fetch, key, 1, expiration=_EPISODE_COUNT_CACHE_HOURS)
	# LOCAL PATCH 2026-09-04: normalise keys to int: JSON stringifies int dict keys, and a silent miss reads as "unknown
	# cour length" and abandons the cour-split repair. Done here, not in the cache layer, so legacy repr rows work too.
	if not isinstance(result, dict): return {}
	out = {}
	for k, v in result.items():
		try: out[int(k)] = v
		except (TypeError, ValueError): continue
	return out


# ═══════════════════════════════════════════════════════════════════════════
#  Authenticated surface (LOCAL PATCH 2026-08-29)
#
#  Not the implicit grant: AniList's token endpoint answers "unsupported_grant_type" for it.
#  This is the Authorization Code (PIN) flow, which DOES require the client secret:
#    1. user registers a client with Redirect URL exactly https://anilist.co/api/v2/oauth/pin
#    2. authorize with response_type=code -> AniList displays a PIN (the auth code)
#    3. POST that code + client_id + client_secret to the token endpoint
#    4. back comes a ~1-year access_token plus a refresh_token
#
#  The 1-year life is why there is no refresh loop (untestable dead code). The refresh token
#  is stored anyway, and a rejected token is logged by _post_anilist.
# ═══════════════════════════════════════════════════════════════════════════

_AUTHORIZE_URL = 'https://anilist.co/api/v2/oauth/authorize?client_id=%s&redirect_uri=%s&response_type=code'
_TOKEN_URL = 'https://anilist.co/api/v2/oauth/token'
_REDIRECT_URI = 'https://anilist.co/api/v2/oauth/pin'

_VIEWER_QUERY = '''
query {
	Viewer { id name }
}
'''

_LAST_ACTIVITY_QUERY = '''
query {
	Viewer {
		updatedAt
		statistics { anime { count } }
	}
}
'''


def _exchange_code(client_id, client_secret, code):
	"""Swap the PIN for a token. Returns the token dict or None."""
	try:
		r = session.post(_TOKEN_URL, json={
			'grant_type': 'authorization_code',
			'client_id': client_id,
			'client_secret': client_secret,
			'redirect_uri': _REDIRECT_URI,
			'code': code,
		}, headers={'Content-Type': 'application/json', 'Accept': 'application/json'}, timeout=20)
		data = r.json()
		if r.status_code != 200 or 'access_token' not in data:
			# Surface AniList's own wording -- 'invalid_client' means the id/secret pair is
			# wrong, 'invalid_grant' means the PIN was stale or already spent.
			logger('AniList: token exchange failed', '%s %s' % (r.status_code, str(data)[:200]))
			return None
		return data
	except Exception as e:
		logger('AniList: token exchange error', safe_err(e))
		return None


def anilist_authenticate(dummy=''):
	"""Authorise against the user's own AniList client. Called from the settings Authorize row."""
	client_id, client_secret = _setting('client_id'), _setting('client_secret')
	if not client_id or not client_secret:
		# LOCAL PATCH 2026-09-30: with a QR code of the developer page (kodi_utils.qr_dialog)
		qr_dialog('AniList Authorize', _APP_REGISTER_URL,
			'[B]Step 1:[/B] Scan the [B]QR code[/B] or open [B]%s[/B] and create a new client.[CR]'
			'[B]Step 2:[/B] Set its [B]Redirect URL[/B] to exactly:   [COLOR gold]%s[/COLOR][CR]'
			'[B]Step 3:[/B] Press [B]Back[/B], then enter its Client ID and Client Secret.'
			% (_APP_REGISTER_URL, _REDIRECT_URI))
		if not client_id:
			client_id = kodi_dialog().input('AniList Client ID')
			if not client_id: return notification('AniList Authorize Cancelled - no Client ID', 4000)
			client_id = client_id.strip()
			set_setting('anilist.client_id', client_id)
		if not client_secret:
			client_secret = kodi_dialog().input('AniList Client Secret')
			if not client_secret: return notification('AniList Authorize Cancelled - no Client Secret', 4000)
			client_secret = client_secret.strip()
			set_setting('anilist.client_secret', client_secret)

	auth_url = _AUTHORIZE_URL % (client_id, _REDIRECT_URI)
	try:
		from modules.utils import copy2clip
		copy2clip(auth_url)
	except Exception: pass

	# LOCAL PATCH 2026-09-30: with a QR code of the authorize link (kodi_utils.qr_dialog); on a TV the link opens on
	# a phone. The PIN AniList then shows is still entered on the next screen.
	if not qr_dialog('AniList Authorize', auth_url,
		'[B]Step 1:[/B] Scan the [B]QR code[/B], or open the link (copied to your clipboard):[CR]'
		'   [COLOR gold]%s[/COLOR][CR]'
		'[B]Step 2:[/B] Approve access. AniList shows you a PIN code.[CR]'
		'[B]Step 3:[/B] Press [B]Back[/B], then enter that PIN.' % auth_url):
		return notification('AniList Authorize timed out', 4000)

	code = kodi_dialog().input('Paste the AniList PIN')
	if not code: return notification('AniList Authorize Cancelled - no PIN', 4000)

	tokens = _exchange_code(client_id, client_secret, code.strip())
	if not tokens:
		return notification('AniList Authorize Failed - PIN rejected. Check the Client Secret and that the PIN is fresh.', 7000)
	set_setting('anilist.token', tokens['access_token'])
	if tokens.get('refresh_token'): set_setting('anilist.refresh', tokens['refresh_token'])
	if tokens.get('expires_in'):
		try: set_setting('anilist.expires', str(int(time.time()) + int(tokens['expires_in'])))
		except Exception: pass

	# Verify rather than trust the exchange -- confirms the token actually authenticates.
	viewer = (_post_anilist(_VIEWER_QUERY, {}, auth=True, node=None) or {}).get('Viewer') or {}
	if not viewer.get('id'):
		set_setting('anilist.token', 'empty_setting')
		return notification('AniList Authorize Failed - token did not authenticate.', 6000)

	set_setting('anilist.userid', str(viewer['id']))
	set_setting('anilist.user', viewer.get('name') or 'Authorized')
	# LOCAL PATCH 2026-10-03 (Batch 3): the lists cached for the previous (or no) account are not this one's.
	# Revoke already cleared them; sign-in did not, so a different account showed the old lists until they expired.
	_invalidate_lists()
	notification('AniList Authorized as %s' % (viewer.get('name') or 'user'), 5000)
	return True


def anilist_revoke_authentication(dummy=''):
	for name in ('token', 'user', 'userid', 'last_activity', 'refresh', 'expires'):
		set_setting('anilist.%s' % name, 'empty_setting')
	_invalidate_lists()
	notification('AniList Authorization Revoked', 4000)
	return True


def anilist_last_activity():
	"""Composite change key for the sync monitor.

	updatedAt alone misses deletions -- removing an entry does not bump it -- so the anime
	count rides along, the same pairing Otaku uses.
	"""
	if not anilist_user_active(): return None
	viewer = (_post_anilist(_LAST_ACTIVITY_QUERY, {}, auth=True, node=None) or {}).get('Viewer') or {}
	if not viewer: return None
	count = ((viewer.get('statistics') or {}).get('anime') or {}).get('count', 0)
	return '%s_%s' % (viewer.get('updatedAt', ''), count)


# ═══════════════════════════════════════════════════════════════════════════
#  List mutations
#
#  AniList counts `progress` WITHIN the entry, which is cour-relative. Callers must pass
#  the AniList id and episode number that fribb_mappings.find_cour_by_tmdb_coords returns
#  for the TMDb coordinates -- NOT TMDb's own episode number (Frieren TMDb S01E30 is entry
#  182255 progress 2).
# ═══════════════════════════════════════════════════════════════════════════

_SAVE_PROGRESS_MUTATION = '''
mutation ($mediaId: Int, $progress: Int, $status: MediaListStatus) {
	SaveMediaListEntry (mediaId: $mediaId, progress: $progress, status: $status) {
		id progress status
	}
}
'''

_SAVE_STATUS_MUTATION = '''
mutation ($mediaId: Int, $status: MediaListStatus) {
	SaveMediaListEntry (mediaId: $mediaId, status: $status) { id status }
}
'''

_SAVE_SCORE_MUTATION = '''
mutation ($mediaId: Int, $score: Float) {
	SaveMediaListEntry (mediaId: $mediaId, score: $score) { id score }
}
'''

_DELETE_ENTRY_MUTATION = '''
mutation ($id: Int) {
	DeleteMediaListEntry (id: $id) { deleted }
}
'''

# LOCAL PATCH 2026-10-02: this user's entry for one media, for the raise-only playback push.
_ENTRY_PROGRESS_QUERY = '''
query ($id: Int, $userId: Int) {
	MediaList (mediaId: $id, userId: $userId, type: ANIME) { progress status }
}
'''

def anilist_episode_count(anilist_id):
	"""Total episodes in an AniList entry, or None. LOCAL PATCH 2026-10-20: from the per-id entry store
	(anilist_entries) -- the bulk count, the cour titles and the browse page fill the same row, so this is usually free.
	It had its own key (anilist_epcount_<id>) and re-fetched counts the season list had just stored."""
	try: anilist_id = int(anilist_id)
	except (TypeError, ValueError): return None
	try: return (anilist_entries([anilist_id]).get(anilist_id) or {}).get('episodes')
	except Exception: return None


_SEASON_SEARCH_QUERY = '''query ($search: String, $from: FuzzyDateInt, $to: FuzzyDateInt) {
  Page(perPage: 15) { media(search: $search, type: ANIME, startDate_greater: $from, startDate_lesser: $to,
    format_in: [TV, TV_SHORT, ONA]) { id idMal format episodes startDate { year month day } } } }'''


def anilist_for_tmdb_season(titles, air_date):
	"""LOCAL PATCH 2026-10-04: the AniList entry that starts a TMDb season, found WITHOUT Fribb -- {'anilist', 'mal',
	'episodes', 'start'} or {}.

	For a season Fribb has not mapped yet. Black Clover's 2026 Season 2 (TMDb 73223 S2, from 2026-10-03) had no row the
	day it aired, so animetosho had no AniDB episode id, seadex no AniList id and torrentio/comet no Kitsu id -- while
	AniList (195604) and ani.zip (AniDB 19433, eid 316587, Kitsu 50024) already had it all.

	The match: an AniList TV / TV_SHORT / ONA entry found by the show's title whose start date is within 10 days of TMDb's
	date for the season. One candidate is taken; with several, only one starting within a day of TMDb's date. Anything
	else is no answer -- Frieren 2026-01-16 also finds a 6-episode ONA starting 01-19, which the one-day rule settles. A
	wrong entry would scrape a different show's episode, so every doubt ends in {}. Titles are tried in order (TMDb's
	name, then the original) until one finds candidates. Cached 24 h, the miss too: an entry AniList adds later is picked
	up the next day. A failed request is not cached (None from _post_anilist)."""
	# Not strptime: Kodi's embedded Python 3.8 breaks it on worker threads, and the scrape is one -- in Kodi this returned
	# {} on every call, silently, while every test outside Kodi passed (Black Clover S2E1 and Overgeared S1E1, 23:02-23:03).
	try:
		year, month, dom = (int(part) for part in str(air_date)[:10].split('-'))
		day = datetime.date(year, month, dom)
	except Exception: return {}
	titles = [t for t in dict.fromkeys(titles or []) if t]
	if not titles: return {}
	def _int(d): return int(d.strftime('%Y%m%d'))
	window = {'from': _int(day - datetime.timedelta(days=10)), 'to': _int(day + datetime.timedelta(days=10))}
	def _fetch(_dummy):
		for title in titles:
			res = _post_anilist(_SEASON_SEARCH_QUERY, dict(window, search=title))
			if res is None: return None
			rows = [m for m in (res.get('media') or []) if isinstance(m, dict)]
			if not rows: continue
			def _start(m):
				s = m.get('startDate') or {}
				try: return datetime.date(int(s['year']), int(s['month']), int(s['day']))
				except Exception: return None
			if len(rows) > 1: rows = [m for m in rows if _start(m) and abs((_start(m) - day).days) <= 1]
			if len(rows) != 1: return {'miss': '%d entries near %s for %r' % (len(rows), day, title)}
			m = rows[0]
			return {'anilist': m.get('id'), 'mal': m.get('idMal'), 'episodes': m.get('episodes'), 'start': str(_start(m))}
		return {'miss': 'no entry near %s' % day}
	try:
		key = 'anilist_season_%s_%s' % (day, '|'.join(titles).lower()[:80])
		found = lists_cache_object(_fetch, key, 1, expiration=24) or {}
	except Exception: return {}
	if found.get('miss'):
		logger('anilist season', 'no match: %s' % found['miss'])
		return {}
	return found


def _tmdb_episode_air_date(meta, season, number):
	"""Air date ('YYYY-MM-DD') of TMDb episode `number` of `season`, from the cached episode list."""
	try:
		from modules.metadata import episodes_meta, tmdb_air_day
		for item in episodes_meta(season, meta) or []:
			if int(item.get('episode') or 0) == int(number): return tmdb_air_day(item) or None   # LOCAL PATCH 2026-10-25: not a dub-shifted day
	except Exception: pass
	return None


def anilist_entry_for_tmdb_episode(meta, season, episode, air_dates=None):
	"""LOCAL PATCH 2026-10-05: the AniList entry holding TMDb episode (season, episode) of a season Fribb has not mapped,
	and the episode's number inside it -- {'anilist', 'mal', 'episodes', 'start', 'episode', 'offset'} -- or {} when none
	is found, or {'exhausted': found} when the episode runs past every entry tried.

	Moved here from scrapers/external._new_season_ids so the scrape and the AniList/MAL scrobble share one copy: the
	scrobble asked Fribb only and silently pushed nothing for such a show ('I'm Dating a Dark Summoner' S01E01 played to
	the end 2026-10-05: Trakt and SIMKL got /sync/history, AniList and MAL no request at all -- Fribb had no row, while
	this finds AniList 208025 / MAL 63509 from the season's air date).

	The entry is the one that STARTS this TMDb season (anilist_for_tmdb_season), so episode N of the season is episode N
	of the entry -- as long as the entry is that long. One too short means TMDb folded the next season into this one (A
	Wild Last Boss Appeared: a 12-episode season 1 + its 2nd Season as one TMDb season of 24): search again from the air
	date of the first TMDb episode after it and count from there. At most 3 steps; each is one AniList search, cached.
	air_dates ({TMDb episode: 'YYYY-MM-DD'}) stands in for the cached episode list -- metadata.episodes_meta passes it
	while it is still building that list (reading it from there would recurse)."""
	try: season, episode = int(season), int(episode)
	except (TypeError, ValueError): return {}
	if season < 1: return {}
	row = next((s for s in (meta.get('season_data') or []) if int(s.get('season_number') or -1) == season), None)
	if not row or not row.get('air_date'): return {}
	titles = [meta.get('tvshowtitle') or meta.get('title'), meta.get('original_title')]
	offset, start = 0, row['air_date']
	for _hop in range(4):
		found = anilist_for_tmdb_season(titles, start)
		if not found.get('anilist'): return {}
		if not found.get('episodes') or episode - offset <= int(found['episodes']): break
		offset += int(found['episodes'])
		start = air_dates.get(offset + 1) if air_dates is not None else _tmdb_episode_air_date(meta, season, offset + 1)
		if not start or _hop == 3: return {'exhausted': found}
	return dict(found, episode=episode - offset, offset=offset)


_SEQUEL_QUERY = '''query ($id: Int) { Media(id: $id) { relations { edges { relationType node {
  id type format status title { english romaji } startDate { year month day } season seasonYear } } } } }'''


def anilist_sequel(anilist_id):
	"""LOCAL PATCH 2026-10-13: the announced, not yet released TV / ONA sequel of an AniList entry -- {'title', 'start':
	{'year','month','day'}, 'season', 'season_year'} -- or {} when there is none, None when AniList did not answer.
	Mushoku Tensei III (178789) -> 'Mushoku Tensei III: Isekai Ittara Honki Dasu Part 2' (217434), 2027: TMDb only says
	'Returning Series' until it has an episode date. A movie / special sequel is not a next season. Cached 24 h."""
	try: anilist_id = int(anilist_id)
	except (TypeError, ValueError): return None
	def _fetch(_dummy):
		res = _post_anilist(_SEQUEL_QUERY, {'id': anilist_id}, node='Media')
		if res is None: return None
		for edge in ((res.get('relations') or {}).get('edges') or []):
			node = edge.get('node') or {}
			if edge.get('relationType') != 'SEQUEL' or node.get('type') != 'ANIME': continue
			if node.get('format') not in ('TV', 'TV_SHORT', 'ONA') or node.get('status') != 'NOT_YET_RELEASED': continue
			title = node.get('title') or {}
			return {'sequel': {'title': title.get('english') or title.get('romaji') or '', 'start': node.get('startDate') or {},
								'season': node.get('season'), 'season_year': node.get('seasonYear')}}
		return {'sequel': {}}
	try: got = lists_cache_object(_fetch, 'anilist_sequel_%s' % anilist_id, 1, expiration=24)
	except Exception: return None
	return got.get('sequel') if isinstance(got, dict) else None


def anilist_alternatives(anilist_id):
	"""LOCAL PATCH 2026-11-06: the titles (romaji and English) of an AniList entry's ALTERNATIVE relations -- other adaptations of
	the same story, never the entry itself -- for the release judge's 'another cour' words (release_judge.build_reject_words).
	Fate/stay night (2006, 356): the Unlimited Blade Works film and TV series, Fate/Prototype, Heaven's Feel I -- Fribb maps only
	the 2010 film to TMDb's show, so 'Heaven's Feel' collections were kept as packs of TMDb S1E1. [] when there are none, None when
	AniList did not answer (not cached). Cached a week: relations change rarely."""
	try: anilist_id = int(anilist_id)
	except (TypeError, ValueError): return None
	def _fetch(_dummy):
		res = _post_anilist(_SEQUEL_QUERY, {'id': anilist_id}, node='Media')
		if res is None: return None
		out = []
		for edge in ((res.get('relations') or {}).get('edges') or []):
			node = edge.get('node') or {}
			if edge.get('relationType') != 'ALTERNATIVE' or node.get('type') != 'ANIME': continue
			title = node.get('title') or {}
			out.extend(t for t in (title.get('romaji'), title.get('english')) if t)
		return {'titles': out}
	try: got = lists_cache_object(_fetch, 'anilist_alternatives_%s' % anilist_id, 1, expiration=168)
	except Exception: return None
	return got.get('titles') if isinstance(got, dict) else None


_AIRING_QUERY = '''query ($id: Int, $after: Int) {
  Page(perPage: 50) { airingSchedules(mediaId: $id, episode_greater: $after, sort: EPISODE) { episode airingAt } } }'''

# LOCAL PATCH 2026-10-20: the schedule by TIME, with the entry riding along. metadata._anilist_air_times only touches
# episodes dated in the last 30 days (120 for a dub), later, or undated, so everything from _RECENT_AIR_DAYS ago on
# answers it whatever the entry's numbering (by episode, a 50+ episode entry needs two requests). Media fills the
# per-id entry store (anilist_entries) in the same request.
_RECENT_AIR_DAYS = 150
_RECENT_AIRING_QUERY = '''query ($id: Int, $since: Int) {
  Page(perPage: 50) { airingSchedules(mediaId: $id, airingAt_greater: $since, sort: EPISODE) { episode airingAt } }
  Media(id: $id, type: ANIME) { id idMal episodes title { romaji english native } coverImage { extraLarge large } } }'''


def anilist_recent_air_times(anilist_id):
	"""{entry episode: airingAt (UTC epoch)} for every episode AniList schedules from _RECENT_AIR_DAYS ago on, {} when it
	has none, None when it did not answer (not cached). Cached 12 h; the entry itself goes to anilist_entries' store."""
	try: anilist_id = int(anilist_id)
	except (TypeError, ValueError): return None
	def _fetch(_dummy):
		res = _post_anilist(_RECENT_AIRING_QUERY, {'id': anilist_id, 'since': int(time.time()) - _RECENT_AIR_DAYS * 86400}, node=None)
		if res is None: return {'success': False}   # not stored (base_cache.cache_ttl)
		if isinstance(res.get('Media'), dict): _prime_entries([res['Media']])
		return {'times': dict((str(n['episode']), n['airingAt']) for n in ((res.get('Page') or {}).get('airingSchedules') or [])
								if isinstance(n, dict) and n.get('episode') and n.get('airingAt'))}
	try: got = lists_cache_object(_fetch, 'anilist_airtimes_recent_%s' % anilist_id, 1, expiration=12)
	except Exception: return None
	if not isinstance(got, dict) or 'times' not in got: return None
	return dict((int(k), int(v)) for k, v in got['times'].items())


def anilist_air_times(anilist_id, first_episode=1):
	"""LOCAL PATCH 2026-10-13: {entry episode: airingAt (UTC epoch)} from AniList's airing schedule, 50 episodes from
	`first_episode` on; {} when AniList has none, None when it did not answer (not cached, so the next list asks again).
	The broadcast time to the minute (TMDb, Trakt and AniDB can be a week off). Cached 12 h."""
	try: anilist_id, first_episode = int(anilist_id), max(1, int(first_episode))
	except (TypeError, ValueError): return None
	# LOCAL PATCH 2026-10-20: answered from the entry's RECENT schedule (anilist_recent_air_times) whenever it reaches back
	# to first_episode; only an older first episode asks from that episode (below).
	recent = anilist_recent_air_times(anilist_id)
	if recent is None: return None
	if not recent: return {}
	if first_episode >= min(recent): return dict((k, v) for k, v in recent.items() if k >= first_episode)
	def _fetch(_dummy):
		res = _post_anilist(_AIRING_QUERY, {'id': anilist_id, 'after': first_episode - 1})
		if res is None: return None
		return {'times': dict((str(n['episode']), n['airingAt']) for n in (res.get('airingSchedules') or [])
								if isinstance(n, dict) and n.get('episode') and n.get('airingAt'))}
	try: got = lists_cache_object(_fetch, 'anilist_airtimes_%s_%s' % (anilist_id, first_episode), 1, expiration=12)
	except Exception: return None
	if not isinstance(got, dict) or 'times' not in got: return None
	return dict((int(k), int(v)) for k, v in got['times'].items())

def _invalidate_lists():
	"""Drop cached watchlist pages after we change something. Without this the user's own
	edit would not show until AniListMonitor next notices Viewer.updatedAt moved."""
	try:
		from caches.anilist_cache import clear_anilist_lists_cache
		clear_anilist_lists_cache()
	except Exception: pass


def _entry_progress(anilist_id):
	"""(progress, status) of this user's entry, (0, None) when it is not on the list, None when unknown.

	MediaList answers 'Not Found' for a title that is not on the list; _post_anilist logs that and returns None,
	so a missing entry and a failed request look alike. Both fall through to the write: the first is a new entry,
	and for the second writing is the safe default."""
	user_id = _setting('userid')
	if not user_id: return None
	res = _post_anilist(_ENTRY_PROGRESS_QUERY, {'id': int(anilist_id), 'userId': int(user_id)}, auth=True, node='MediaList')
	if not res: return (0, None)
	return (res.get('progress') or 0, res.get('status'))


def anilist_set_progress(anilist_id, progress, status=None, raise_only=False):
	"""Set watched-episode count on an entry. Returns True on success.

	status=None picks it: COMPLETED once progress reaches the entry's episode count,
	CURRENT otherwise. An unknown count falls back to CURRENT -- understating progress is
	recoverable, marking a show complete early is not.
	"""
	if not anilist_user_active(): return False
	try:
		anilist_id, progress = int(anilist_id), int(progress)
	except (TypeError, ValueError): return False
	if progress < 0: return False
	# LOCAL PATCH 2026-10-02: an episode past the entry's own length means the cour mapping is off. Not sent.
	total = anilist_episode_count(anilist_id) if progress else None
	if total and progress > int(total):
		logger('AniList progress', 'entry %s: ep %s is past its %s episodes - cour mapping off, not sent' % (anilist_id, progress, total))
		return False
	# LOCAL PATCH 2026-10-02: raise_only (playback): rewatching an early episode must not lower a finished entry.
	# Season marks and Unmark pass False -- there the user asked for that number.
	if raise_only:
		current = _entry_progress(anilist_id)
		if current and current[0] >= progress:
			logger('AniList progress', 'entry %s: already at ep %s (%s), not lowering to %s' % (anilist_id, current[0], current[1], progress))
			return True
	if status is None:
		# LOCAL PATCH 2026-08-29: progress 0 (Mark Unwatched on a season/cour row) is PLANNING, not CURRENT: CURRENT
		# would keep it in the "Watching" list forever.
		if progress == 0: status = 'PLANNING'
		else: status = 'COMPLETED' if (total and progress >= int(total)) else 'CURRENT'
	res = _post_anilist(_SAVE_PROGRESS_MUTATION,
						{'mediaId': anilist_id, 'progress': progress, 'status': status},
						auth=True, node='SaveMediaListEntry')
	if res:
		logger('AniList progress', 'entry %s -> ep %s (%s)' % (anilist_id, progress, status))
		_invalidate_lists()
	return bool(res)


def anilist_set_status(anilist_id, status):
	"""status in CURRENT / PLANNING / COMPLETED / DROPPED / PAUSED / REPEATING."""
	if not anilist_user_active(): return False
	res = _post_anilist(_SAVE_STATUS_MUTATION, {'mediaId': int(anilist_id), 'status': status},
						auth=True, node='SaveMediaListEntry')
	if res: _invalidate_lists()
	return bool(res)


def anilist_set_score(anilist_id, score):
	if not anilist_user_active(): return False
	res = _post_anilist(_SAVE_SCORE_MUTATION, {'mediaId': int(anilist_id), 'score': float(score)},
						auth=True, node='SaveMediaListEntry')
	if res: _invalidate_lists()
	return bool(res)


def anilist_delete_entry(entry_id):
	"""Takes the LIST ENTRY id (from MediaList.id), not the media id."""
	if not anilist_user_active(): return False
	res = _post_anilist(_DELETE_ENTRY_MUTATION, {'id': int(entry_id)}, auth=True,
						node='DeleteMediaListEntry')
	if (res or {}).get('deleted'): _invalidate_lists()
	return bool((res or {}).get('deleted'))


# ═══════════════════════════════════════════════════════════════════════════
#  List reads
# ═══════════════════════════════════════════════════════════════════════════

_MEDIA_LIST_QUERY = '''
query ($userId: Int, $status: MediaListStatus) {
	MediaListCollection (userId: $userId, type: ANIME, status: $status) {
		lists {
			entries {
				id
				progress
				score
				media { %s }
			}
		}
	}
}
''' % _MEDIA_FIELDS

_STATUSES = ('CURRENT', 'PLANNING', 'COMPLETED', 'PAUSED', 'DROPPED', 'REPEATING')


def anilist_media_list(status):
	"""All entries for one list status. Returns [{'entry_id','progress','score', **media}].

	MediaListCollection is not paged the way the browse queries are -- it returns the whole
	list in one response, grouped into custom lists which are flattened here.
	"""
	if not anilist_user_active(): return []
	if status not in _STATUSES: return []
	user_id = _setting('userid')
	if not user_id: return []
	res = _post_anilist(_MEDIA_LIST_QUERY, {'userId': int(user_id), 'status': status},
						auth=True, node='MediaListCollection')
	out = []
	for group in ((res or {}).get('lists') or []):
		for entry in (group.get('entries') or []):
			media = entry.get('media') or {}
			if not media.get('id'): continue
			item = dict(media)
			item['entry_id'] = entry.get('id')
			item['progress'] = entry.get('progress')
			item['user_score'] = entry.get('score')
			out.append(item)
	return out


# ═══════════════════════════════════════════════════════════════════════════
#  Bulk / throttled surface (LOCAL PATCH 2026-08-29)
#
#  Only the backfill tool needs these. AniList's limit is 30 requests/minute (X-RateLimit-Limit,
#  not the documented 90), so a backfill MUST pace itself. The interactive paths above make one
#  or two requests and are deliberately left unthrottled.
# ═══════════════════════════════════════════════════════════════════════════

_RATE_MIN_INTERVAL = 2.2      # seconds between writes: 30/min with headroom
_MEDIA_LIST_ALL_QUERY = '''
query ($userId: Int) {
	MediaListCollection (userId: $userId, type: ANIME) {
		lists {
			entries { id mediaId progress status }
		}
	}
}
'''


def anilist_media_list_all():
	"""Every entry on the user's anime list in ONE request: {media_id: {...}}.

	Deliberately does not select _MEDIA_FIELDS -- the backfill only needs to know what is
	already there and how far, and pulling full media for a 1000-entry list would be a
	large response for no gain.
	"""
	if not anilist_user_active(): return {}
	user_id = _setting('userid')
	if not user_id: return {}
	res = _post_anilist(_MEDIA_LIST_ALL_QUERY, {'userId': int(user_id)}, auth=True,
						node='MediaListCollection')
	out = {}
	for group in ((res or {}).get('lists') or []):
		for entry in (group.get('entries') or []):
			try: mid = int(entry['mediaId'])
			except (KeyError, TypeError, ValueError): continue
			out[mid] = {'entry_id': entry.get('id'),
						'progress': entry.get('progress') or 0,
						'status': entry.get('status')}
	return out


def anilist_covers_bulk(anilist_ids):
	"""{anilist_id: cover_url} for any number of ids, 50 per request.

	AniList art is per COUR (each cour its own key visual), while TMDb carries a single
	show-level poster. LOCAL PATCH 2026-10-20: from the per-id entry store (anilist_entries).
	"""
	return dict((a, rec['poster']) for a, rec in anilist_entries(anilist_ids).items() if rec.get('poster'))


def anilist_romaji_by_ids(anilist_ids):
	"""LOCAL PATCH 2026-10-03 (Batch 4): {anilist_id: romaji} (_pick_romaji). The scraper's title source: Fribb names the
	exact AniList entry of a cour, so this cannot land on the wrong half of a split MAL id the way anilist_romaji_for_mal
	can; the Anime List Manager names its entries by it for the same reason. LOCAL PATCH 2026-10-20: from the per-id
	entry store (anilist_entries)."""
	return dict((a, rec['title']) for a, rec in anilist_entries(anilist_ids).items() if rec.get('title'))


def anilist_romaji_for_id(anilist_id):
	try: return anilist_romaji_by_ids([anilist_id]).get(int(anilist_id))
	except (TypeError, ValueError): return None


# LOCAL PATCH 2026-08-29: pick the tags worth showing on a list row. Spoiler-flagged tags are dropped; the rest are
# ranked 0-100 by vote and popular shows carry 30+, so only the top few fit any skin layout.
_TAG_LIMIT = 5


# LOCAL PATCH 2026-10-07: the tags are the anime's genres (metadata.display_genres), so those that say nothing about what
# a show is about are dropped: who the main cast is (Cast-Main Cast), how it was made (Technical), sexual content, and
# 'Heterosexual' / 'Nudity'. Below rank 60 a tag is a weak vote. By NAME (AniList's MediaTagCollection), not only by
# category: cached rows may lack the category. Kept from Cast-Main Cast: 'Anti-Hero', 'Estranged Family' (story).
_TAG_SKIP_NAMES = frozenset((
	'Elderly Protagonist', 'Ensemble Cast', 'Female Protagonist', 'Male Protagonist', 'Primarily Adult Cast', 'Primarily Animal Cast',
	'Primarily Child Cast', 'Primarily Female Cast', 'Primarily Male Cast', 'Primarily Teen Cast',                       # Cast-Main Cast
	'4-koma', 'Achromatic', 'Advertisement', 'Anthology', 'CGI', 'Episodic', 'Flash', 'Full CGI', 'Full Color', 'Gekiga',
	'Graduation Project', 'Long Strip', 'Mixed Media', 'No Dialogue', 'Non-fiction', 'POV', 'Puppetry', 'Rotoscoping',
	'Short-Form Chapter', 'Stop Motion', 'Vertical Video',                                                              # Technical
	'Heterosexual', 'Nudity'))
_TAG_SKIP_CATEGORIES = ('Sexual Content',)
_TAG_MIN_RANK = 60
# The demographic is kept whatever its rank: it is the magazine the source ran in, not a vote. It leads the list
# ('Seinen, Isekai, ...'), so the limit never cuts it.
_TAG_DEMOGRAPHICS = frozenset(('Josei', 'Kids', 'Seinen', 'Shoujo', 'Shounen'))


def anilist_tag_names(media, limit=_TAG_LIMIT):
	"""['Isekai', 'Elf', ...] -- highest-ranked non-spoiler tags first, without the kinds above."""
	try:
		tags = [t for t in (media.get('tags') or []) if t and not t.get('isMediaSpoiler') and t.get('name')
				and ((t.get('rank') or 0) >= _TAG_MIN_RANK or t['name'] in _TAG_DEMOGRAPHICS) and t['name'] not in _TAG_SKIP_NAMES
				and not str(t.get('category') or '').startswith(_TAG_SKIP_CATEGORIES)]
		tags.sort(key=lambda t: t.get('rank') or 0, reverse=True)
		demographic = [t['name'] for t in tags if t['name'] in _TAG_DEMOGRAPHICS][:1]
		rest = [t['name'] for t in tags if t['name'] not in _TAG_DEMOGRAPHICS]
		return demographic + rest[:limit - len(demographic)]
	except Exception:
		return []


# ═══════════════════════════════════════════════════════════════════════════
#  Per-title score, for the AF3 AniList rating chip (LOCAL PATCH 2026-09-15)
#
#  For TV rows built from TMDb (an AniList browse row carries its score in the page). The
#  result is stored in the meta's extra_ratings, so it is paid once per show per meta TTL;
#  the 429 handler in _post_anilist backs everything off.
# ═══════════════════════════════════════════════════════════════════════════

_SCORE_COOLDOWN_PROP = 'deadlight.anilist_score_cooldown_until'
# LOCAL PATCH 2026-10-07: the same request also brings the tags, which replace TMDb's genres on anime (metadata.display_genres)
# LOCAL PATCH 2026-10-15: and the genres, for the anime genre choice (setting anime.genre_provider) -- same request, no extra call.
_SCORE_FIELDS = 'averageScore tags { name rank category isMediaSpoiler } genres'
_SCORE_QUERY = '''
query ($id: Int) {
	Media (id: $id, type: ANIME) { %s }
}
''' % _SCORE_FIELDS


def anilist_score_on_cooldown():
	"""True while AniList has told us to back off. Checked before the request so a cold
	meta build skips it entirely, the same contract as omdb_on_cooldown."""
	return cooldown_active(_SCORE_COOLDOWN_PROP)


def _start_score_cooldown(secs, reason):
	try:
		start_cooldown(_SCORE_COOLDOWN_PROP, secs)
		logger('AniList', 'rate limited (%s) - skipping score lookups for %d min' % (reason, max(1, secs // 60)))
	except Exception: pass


# LOCAL PATCH 2026-10-03 (3.0.8): scores fetched in bulk for a whole page (metadata.flush_rating_backfills), then read
# here: one request per 50 shows, not per show, against the 30-a-minute limit. Per process only.
_SCORES_PRIMED = {}

_SCORES_BULK_QUERY = '''
query ($ids: [Int]) {
	Page(page: 1, perPage: 50) {
		media(id_in: $ids, type: ANIME) { id %s }
	}
}
''' % _SCORE_FIELDS


def _score_record(media):
	return {'score': _score_text(media.get('averageScore')), 'tags': anilist_tag_names(media),
			'genres': [g for g in (media.get('genres') or []) if g]}


def _score_text(score):
	try: return '%.1f' % (float(score) / 10.0) if score else None
	except (TypeError, ValueError): return None


def anilist_scores_bulk(anilist_ids):
	"""Prime anilist_score_and_tags for these ids. A failed request primes nothing (each title then asks alone)."""
	ids = []
	for a in (anilist_ids or []):
		try: a = int(a)
		except (TypeError, ValueError): continue
		if a not in ids and a not in _SCORES_PRIMED: ids.append(a)
	for i in range(0, len(ids), 50):
		if anilist_score_on_cooldown(): return
		chunk = ids[i:i + 50]
		res = _post_anilist(_SCORES_BULK_QUERY, {'ids': chunk}, node='Page')
		if res is None: return
		got = {}
		for media in (res.get('media') or []):
			try: got[int(media['id'])] = _score_record(media)
			except (KeyError, TypeError, ValueError): continue
		# an id AniList did not return is primed as {} -- answered, nothing there -- so it is not asked for again alone
		for a in chunk: _SCORES_PRIMED[a] = got.get(a, {})
		if i + 50 < len(ids): time.sleep(_RATE_MIN_INTERVAL)


def anilist_score_and_tags(anilist_id):
	"""{'score': '8.5' or None, 'tags': [...]} for ONE media id, or None when AniList did not answer.

	AniList scores out of 100; '%.1f' % (score / 10.0), the same shape anilist_lists
	publishes. The tags are anilist_tag_names' top five non-spoiler ones.
	"""
	try: anilist_id = int(anilist_id)
	except (TypeError, ValueError): return None
	if anilist_id in _SCORES_PRIMED:
		primed = _SCORES_PRIMED[anilist_id] or {}
		return {'score': primed.get('score'), 'tags': primed.get('tags') or [], 'genres': primed.get('genres') or []}
	if anilist_score_on_cooldown(): return None
	data = _post_anilist(_SCORE_QUERY, {'id': anilist_id}, node='Media')
	if not isinstance(data, dict): return None
	return _score_record(data)


# ═══════════════════════════════════════════════════════════════════════════
#  User recommendations (LOCAL PATCH 2026-10-09)
# ═══════════════════════════════════════════════════════════════════════════

_RECS_QUERY = '''
query ($ids: [Int]) {
	Page(page: 1, perPage: 50) {
		media(id_in: $ids, type: ANIME) {
			id
			recommendations(sort: RATING_DESC, perPage: 25) {
				nodes { rating mediaRecommendation { id idMal format } }
			}
		}
	}
}'''


def _recs_tmdb_id(rec, media_type):
	"""A recommended entry's TMDb id (int) via Fribb, or None. Films only from a Fribb MOVIE id and series only from a TV
	id, so a film never lands in a show list (Fribb's TV fallback for an ONA film would do exactly that)."""
	from caches import fribb_mappings
	row = fribb_mappings.anilist_to_fribb(rec.get('id')) or fribb_mappings.mal_to_fribb(rec.get('idMal'))
	ids = (row or {}).get('themoviedb_id')
	if not isinstance(ids, dict): return None
	value = ids.get('movie') if media_type == 'movie' else ids.get('tv')
	if isinstance(value, list): value = value[0] if value else None
	try: return int(value)
	except (TypeError, ValueError): return None


def anilist_recommend_seed(media_type, tmdb_id):
	"""True when a 'Because You Watched' seed can use AniList recommendations: an anime Fribb maps to an AniList entry.
	Anything else falls back to TMDb Recommended (indexers/navigator, indexers/random_lists)."""
	try:
		from caches import fribb_mappings
		if media_type == 'movie': return bool(fribb_mappings.anilist_for_tmdb_movie(tmdb_id))
		return any(r.get('anilist_id') for r in fribb_mappings.tmdb_tv_to_fribb_rows(tmdb_id))
	except Exception: return False


def anilist_recommended(media_info, page_no=1):
	"""'movie|<tmdb>' or 'tvshow|<tmdb>' -> {'results': [{'id': tmdb_id}, ...]}: what AniList users recommend for that anime.

	A show is several AniList entries (Frieren's two seasons, JoJo's nine parts), so every entry Fribb maps to the TMDb
	show is asked in one request and the votes are summed per TMDb title -- the same show recommended for season 1 and
	for season 2 counts once, with both votes. Entries of the source show itself (its other seasons) are dropped, and
	the format has to match: films in a film list, everything else in a show list. Entries Fribb cannot map to TMDb are
	dropped. Measured for Frieren, 2026-10-09: Violet Evergarden 1197 votes, Delicious in Dungeon 767, Elaina 508, To
	Your Eternity 423, Witch Hat Atelier 403 -- closer in tone than TMDb's, which runs to generic isekai."""
	media_type, tmdb_id = media_info.split('|')
	media_type = 'movie' if media_type == 'movie' else 'tvshow'
	tmdb_id = int(tmdb_id)

	def _fetch(_dummy):
		from caches import fribb_mappings
		if media_type == 'movie': source = [fribb_mappings.anilist_for_tmdb_movie(tmdb_id)]
		else: source = [r.get('anilist_id') for r in fribb_mappings.tmdb_tv_to_fribb_rows(tmdb_id)]
		source = sorted({int(i) for i in source if i})[:50]
		if not source: return {'results': [], 'page': 1, 'total_pages': 1}
		page = _post_anilist(_RECS_QUERY, {'ids': source})
		if page is None: return {'success': False}   # a failed request (429 included) is not stored: base_cache.is_failed_result
		votes, order = {}, []
		for media in page.get('media') or []:
			for node in ((media.get('recommendations') or {}).get('nodes') or []):
				rec, rating = node.get('mediaRecommendation') or {}, node.get('rating') or 0
				if rating <= 0 or not rec.get('id') or rec.get('id') in source: continue
				if (rec.get('format') == 'MOVIE') != (media_type == 'movie'): continue
				rec_tmdb = _recs_tmdb_id(rec, media_type)
				if not rec_tmdb or rec_tmdb == tmdb_id: continue
				if rec_tmdb not in votes: order.append(rec_tmdb)
				votes[rec_tmdb] = votes.get(rec_tmdb, 0) + rating
		ranked = sorted(order, key=lambda k: -votes[k])[:20]
		return {'results': [{'id': i} for i in ranked], 'page': 1, 'total_pages': 1}

	data = lists_cache_object(_fetch, 'anilist_recs_%s_%s' % (media_type, tmdb_id), 'foo', expiration=168)
	return data if (data or {}).get('results') is not None else {'results': [], 'page': 1, 'total_pages': 1}
