# created by Venom for Fenomscrapers
"""
	Fenomscrapers Project
"""

import re
import concurrent.futures
from urllib.parse import quote_plus, unquote_plus
from magneto.modules import client
from magneto.modules import source_utils


# LOCAL PATCH 2026-07-20: Otaku-style rewrite. Nyaa's OR-query syntax fetches all episode/batch variants in fewer
# calls; quality/codec tokens are stripped BEFORE extracting numbers ('1080p', 'H264' are not episodes). Torrents with
# no season/episode/part info (bare batches) are accepted, as Otaku does. Alias titles are queried too: anime torrents
# often use romaji names ('Diamond no Ace') sharing no tokens with TMDb's English title.

# LOCAL PATCH 2026-08-27: the anime name parsing lives in magneto/modules/anime_utils.py (shared with comet).
from magneto.modules.anime_utils import (
	_TOKEN_STOPWORDS, _tokenize, _title_seq, _seq_matches,
	_clean_for_extract, _extract_meta, _pack_shape, cour_match, name_cour_check, title_cour_markers,
	batch_fields)   # LOCAL PATCH 2026-10-03: batch tagging shared with torrentio/comet

# LOCAL PATCH 2026-08-27 (revised): no nyaa.media -- it is a different search backend that silently IGNORES AND terms,
# so narrow queries return many wrong rows. A host that lies passes every liveness check; hence the row-based test in
# _fetch_urls. nyaa.si FIRST: the authoritative host; the translate proxy is rate limited (a burst earns blanket 429s)
# and is the fallback when nyaa.si's intermittent ISP block bites.
_NYAA_HOSTS = (
	('https://nyaa.si', ''),
	('https://nyaa-si.translate.goog', '&_x_tr_sl=es&_x_tr_tl=en&_x_tr_hl=en'),
)
_NYAA_HOST_PROP = 'magneto.nyaa_host'


def _nyaa_hosts_in_order():
	"""Preferred host first, then the rest as fallbacks."""
	try:
		import xbmcgui
		preferred = xbmcgui.Window(10000).getProperty(_NYAA_HOST_PROP)
	except Exception:
		preferred = ''
	if preferred:
		chosen = [h for h in _NYAA_HOSTS if h[0] == preferred]
		if chosen: return chosen + [h for h in _NYAA_HOSTS if h[0] != preferred]
	return list(_NYAA_HOSTS)


def _remember_nyaa_host(base):
	try:
		import xbmcgui
		win = xbmcgui.Window(10000)
		if win.getProperty(_NYAA_HOST_PROP) != base: win.setProperty(_NYAA_HOST_PROP, base)
	except Exception: pass


# LOCAL PATCH 2026-09-16: read the RSS feed instead of scraping the results table (upstream 6.09.04 did too; only the
# transport was taken). RSS gives the hash, size and seeders as fields, a much smaller body, and passes the translate
# proxy untouched (it rewrites HTML). But RSS IGNORES the seeder sort and `&p=N`: one page of the NEWEST 75. So a body
# AT _RSS_PAGE_CAP is re-asked over HTML, seeder-sorted, and both are kept (callers dedupe on info_hash) -- old,
# well-seeded BD batches are half the point of this provider.
_RSS_NS = {'nyaa': 'https://nyaa.si/xmlns/nyaa'}
_RSS_PAGE_CAP = 75
_HTML_SORT_SUFFIX = '&s=seeders&o=desc'


# LOCAL PATCH 2026-10-01: nyaa.si over KEPT-OPEN connections. Most NEW connections to nyaa.si can be reset during the
# TLS handshake, but one that opens stays good. So: one Session, a pool of 5, and only the reset handshake is retried
# (it fails in ~0.3 s). A timeout or HTTP error is not retried; _fetch_urls' per-query proxy fallback covers it.
_NYAA_SESSION = None
_NYAA_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Safari/537.36'

def _nyaa_session():
	global _NYAA_SESSION
	if _NYAA_SESSION is None:
		import requests
		s = requests.Session()
		s.mount('https://', requests.adapters.HTTPAdapter(pool_connections=1, pool_maxsize=5, max_retries=0))
		s.headers['User-Agent'] = _NYAA_UA
		_NYAA_SESSION = s
	return _NYAA_SESSION

def _nyaa_get(url, attempts=4):
	import requests
	for attempt in range(attempts):
		try:
			r = _nyaa_session().get(url, timeout=6)
			return r.text if r.status_code == 200 else None
		except requests.exceptions.ConnectionError:
			continue
		except Exception:
			return None
	return None


def _is_rss(body):
	return bool(body) and '<item>' in body


def _rss_item_count(body):
	return body.count('<item>') if body else 0


def _body_has_rows(body):
	"""A body is not proof of success on its own: a 429, a Cloudflare interstitial and a
	blocked-host error page are all non-empty bodies carrying no rows. Only rows count."""
	if not body: return False
	if '<item>' in body or '<rss' in body[:400]: return '<item>' in body
	return 'magnet:' in body


def _rss_rows(body):
	"""Yield (magnet, size, [seeders]) -- the exact shape the HTML path produced, so every
	filter downstream is untouched. The magnet is synthesised from the hash, with the name
	quote_plus'd so the existing unquote_plus round-trips it back unchanged."""
	import xml.etree.ElementTree as _ET
	try: root = _ET.fromstring(body)
	except Exception: return
	for item in root.iter('item'):
		try:
			def _f(tag):
				node = item.find(tag, _RSS_NS)
				return node.text.strip() if node is not None and node.text else ''
			info_hash, name = _f('nyaa:infoHash'), _f('title')
			if not info_hash or not name: continue
			yield ('magnet:?xt=urn:btih:%s&dn=%s' % (info_hash, quote_plus(name)),
					_f('nyaa:size'), [_f('nyaa:seeders')])
		except Exception: continue


def _html_rows(body):
	"""The HTML table scrape: the seeder-sorted top-up on capped queries, and the fallback
	if RSS ever stops answering."""
	body = re.sub(r'[\n\t]', '', body)
	for row in client.parseDOM(client.parseDOM(body, 'tbody'), 'tr'):
		for link in zip(
						# LOCAL PATCH 2026-08-27: backreference \1 closes on the SAME quote that opened the
						# attribute. Not [^"\']+: it cut a magnet at any apostrophe in the name ("Journey's").
						[_m.group(2) for _m in re.finditer(r'href\s*=\s*(["\'])(magnet:.+?)\1', row, re.DOTALL | re.I)],
						re.findall(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', row, re.DOTALL),
						[re.findall(r'<td class\s*=\s*["\']text-center["\']>([0-9]+)</td>', row, re.DOTALL)]):
			yield link

def _rows_from_body(body):
	"""Normalised rows from whichever transport answered."""
	if not body: return []
	return _rss_rows(body) if _is_rss(body) else _html_rows(body)


class source:
	# LOCAL PATCH 2026-08-27: batches must carry a `package` key, or resolve_cached() never picks the episode out of them.
	# LOCAL PATCH 2026-10-03: pack_capable False, as nekobt -- sources() runs its own batch query and tags each batch
	# (anime_utils.batch_fields), so a Season search only repeated it. sources_packs() stays below, unused, for a
	# quick switch back.
	pack_capable = False
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		# LOCAL PATCH 2026-08-27: resolved from _NYAA_HOSTS; see the note above.
		self.base_link, self.url_suffix = _nyaa_hosts_in_order()[0]
		# LOCAL PATCH 2026-09-16: RSS. No seeder sort in the URL (the feed ignores it);
		# _fetch_urls re-asks capped queries over HTML to get it back.
		self.search_link = '/?page=rss&f=0&c=0_0&q=%s'
		# LOCAL PATCH 2026-08-09: no seeder gate -- debrid only, and a 0-seeder old batch can still be cached and
		# instant-playable (as Otaku keeps them). The sources window shows uncached separately.
		self.request_failed = False   # LOCAL PATCH 2026-10-01: set by _fetch_urls when nothing answered

	def _fetch_urls(self, urls):
		"""Fetch all urls, walking the host list until one answers.

		LOCAL PATCH 2026-08-27: shared by sources() and sources_packs(). A blocked host fails
		fast (SNI reset ~0.5s) or hits the 5s timeout, so trying the next is bounded; the
		winner is remembered for the session."""
		import xbmc as _xbmc_diag
		if not urls: return []
		def _fetch(u):
			# LOCAL PATCH 2026-10-01: nyaa.si over kept-open connections (_nyaa_get); the proxy as before
			if u.startswith('https://nyaa.si/'): return u, _nyaa_get(u)
			try: return u, client.request(u, timeout=5)
			except Exception: return u, None
		def _fetch_all(_urls):
			try:
				# 5 at once, each worker on one kept-open connection (the pool holds 5); more means more handshakes to lose
				with concurrent.futures.ThreadPoolExecutor(max_workers=min(5, len(_urls))) as _ex:
					return list(_ex.map(_fetch, _urls))
			except Exception:
				# fall back to sequential if threading blows up for any reason
				return [_fetch(u) for u in _urls]
		_has_magnets = _body_has_rows   # LOCAL PATCH 2026-09-16: rows, not magnets (RSS has none)
		# LOCAL PATCH 2026-10-01: retry on the next host only when nyaa.si did not ANSWER. An empty feed or 'No results
		# found' is a valid answer (most narrow OR-queries find nothing; the proxy costs ~2 s each). A reset, a timeout
		# or a block page still retries.
		def _answered(body):
			if not body: return False
			if '<rss' in body[:400] or _has_magnets(body): return True
			return 'No results found' in body

		def _alt_urls_for(idxs, alt_base, alt_suffix):
			out = []
			for i in idxs:
				u = urls[i].replace(self.base_link, alt_base, 1)
				if self.url_suffix: u = u.replace(self.url_suffix, '', 1)
				if alt_suffix: u = '%s%s' % (u, alt_suffix)
				out.append(u)
			return out

		# LOCAL PATCH 2026-08-27 (revised): retry PER URL, not all-or-nothing -- nyaa.si's block is intermittent per
		# request, so a scrape gets some queries through and loses the rest.
		fetch_results = _fetch_all(urls)
		missing = [i for i, r in enumerate(fetch_results) if not _answered(r[1])]
		for _alt_base, _alt_suffix in _nyaa_hosts_in_order()[1:]:
			if not missing: break
			if _alt_base == self.base_link: continue
			_xbmc_diag.log('NYAA-DIAG: %d/%d queries empty on %s, retrying on %s'
					% (len(missing), len(urls), self.base_link, _alt_base), _xbmc_diag.LOGINFO)
			_retry = _fetch_all(_alt_urls_for(missing, _alt_base, _alt_suffix))
			_still = []
			for _idx, _res in zip(missing, _retry):
				if _answered(_res[1]): fetch_results[_idx] = _res
				else: _still.append(_idx)
			missing = _still
		# LOCAL PATCH 2026-09-16: seeder-sorted top-up for capped queries (see _RSS_PAGE_CAP).
		_capped = [i for i, r in enumerate(fetch_results)
					if _is_rss(r[1]) and _rss_item_count(r[1]) >= _RSS_PAGE_CAP]
		if _capped:
			_top_urls = [fetch_results[i][0].replace('?page=rss&', '?', 1) + _HTML_SORT_SUFFIX
							for i in _capped]
			_xbmc_diag.log('NYAA-DIAG: %d/%d queries hit the %d-row RSS cap, topping up over HTML'
					% (len(_capped), len(urls), _RSS_PAGE_CAP), _xbmc_diag.LOGINFO)
			fetch_results.extend([r for r in _fetch_all(_top_urls) if _body_has_rows(r[1])])

		# Remember whichever host answered the FIRST query, so the next scrape starts
		# where this one succeeded rather than re-probing a dead host.
		if any(_has_magnets(r[1]) for r in fetch_results): _remember_nyaa_host(self.base_link)
		if not any(_answered(r[1]) for r in fetch_results): self.request_failed = True   # LOCAL PATCH 2026-10-01
		return fetch_results

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		"""Season / show packs. LOCAL PATCH 2026-08-27.

		Mirrors torrentio.sources_packs: the shared source_utils.filter_season_pack /
		filter_show_pack helpers decide validity, and the item carries `package` so
		DeadLight resolves the requested episode from inside the torrent.

		CAVEAT: those helpers assume western season numbering, while nyaa batches are
		anime cours -- a batch labelled S01 may be one cour of a TMDb season. Expect
		some valid packs filtered out; season packs are safer than show packs here."""
		sources = []
		if not data: return sources
		sources_append = sources.append
		try:
			import xbmc as _x
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data.get('title')
			if not title: return sources
			title = title.replace('&', 'and').replace('/', ' ').replace('$', 's')
			aliases = list(data.get('aliases') or [])
			mal_title = data.get('mal_title')
			if mal_title and mal_title not in [a if isinstance(a, str) else a.get('title', '') for a in aliases]:
				aliases.insert(0, {'title': mal_title})   # LOCAL PATCH 2026-10-01: first, so the 3-alias cap cannot cut it
			# str, not int: filter_season_pack does season.zfill(2) and replace(year, ''); an int makes its
			# except return a bare True instead of a 3-tuple, and the unpack silently loses every pack.
			# season_num stays int for query formatting.
			year, imdb = str(data.get('year') or ''), data.get('imdb')
			season = str(data.get('season') or '1')
			try: season_num = int(season)
			except Exception: season_num, season = 1, '1'
			# Same title candidates sources() uses: primary plus romaji/alias forms, which
			# is how most anime packs are actually named.
			cands = [title]
			# LOCAL PATCH 2026-10-01: as in sources() -- no alias naming another cour, none cleaned to almost nothing
			cour_plan = data.get('cour_plan')
			cour_season = data.get('cour_season')
			for a in aliases:
				if len(cands) >= 4: break
				t = a if isinstance(a, str) else a.get('title', '')
				if not t or len(re.sub(r'[^A-Za-z0-9]', '', t)) < 4: continue
				if cour_plan and (title_cour_markers(t) & set(cour_plan.get('foreign') or ())): continue
				if t not in cands: cands.append(t)
			s2 = '%02d' % season_num
			# Batch OR-pattern, same shape sources() uses. `01-NN` ranges are left open
			# ended here because a pack search does not know the episode count.
			batch_or = '"Batch"|"Complete"|"S%s"|"Season %s"|"Seasons"|"Complete Series"' % (s2, s2)
			if search_series:
				batch_or = '"Batch"|"Complete"|"Complete Series"|"Seasons"|"S01-"'
			urls = []
			for t in cands:
				urls.append('%s%s%s' % (self.base_link, self.search_link % quote_plus('%s %s' % (t, batch_or)), self.url_suffix))
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('NYAA')
			return sources
		fetch_results = self._fetch_urls(urls)
		seen_hashes = set()
		_kept = 0
		for _u, results in fetch_results:
			try:
				if not _body_has_rows(results): continue
				# LOCAL PATCH 2026-09-16: rows from _rows_from_body (RSS or HTML), in a 1-tuple to keep the loop nesting.
				for _rows in (_rows_from_body(results),):
					for link in _rows:
						magnet = unquote_plus(link[0]).replace('&amp;', '&').split('&tr')[0].replace(' ', '.')
						magnet = source_utils.strip_non_ascii_and_unprintable(magnet)
						try: hash = re.search(r'btih:(.*?)&', magnet, re.I).group(1)
						except Exception: continue
						if hash in seen_hashes: continue
						try: name = source_utils.clean_name(magnet.split('&dn=')[1])
						except Exception: continue
						episode_start = episode_end = 0
						last_season = total_seasons
						# filter_season_pack decides TITLE and SEASON validity; only its episode range
						# is discarded (see _pack_shape).
						is_pack, shape_start, shape_end = _pack_shape(name)
						if search_series:
							if not bypass_filter:
								if not is_pack: continue
								valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season, name, total_seasons)
								if not valid: continue
							package = 'show'
						else:
							if not bypass_filter:
								if not is_pack: continue
								# LOCAL PATCH 2026-10-01: a single episode is no season pack (some pass _pack_shape), and a pack
								# of ANOTHER cour is not ours (anime_utils.name_cour_check)
								_ps, _pe, _pp, _prange = _extract_meta(_clean_for_extract(name))
								if _pe and len(_pe) == 1 and not _prange: continue
								if cour_plan and name_cour_check(name, cour_plan, cour_season)[0] is False: continue
								valid, _fsp_start, _fsp_end = source_utils.filter_season_pack(title, aliases, year, season, name)
								if not valid: continue
							episode_start, episode_end = shape_start, shape_end
							package = 'season'
						name_info = source_utils.info_from_name(name, title, year, season=season, pack=package)
						if source_utils.remove_lang(name_info, check_foreign_audio): continue
						if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue
						try: seeders = int(link[2][0])
						except Exception: seeders = 0
						quality, info = source_utils.get_release_quality(name_info, magnet)
						try:
							dsize, isize = source_utils._size(link[1])
							info.insert(0, isize)
						except Exception: dsize = 0
						info = ' | '.join(info)
						seen_hashes.add(hash)
						item = {
							'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True,
							'provider': 'nyaa', 'hash': hash, 'url': magnet,   # LOCAL PATCH 2026-10-03: no true_size -- nyaa's size is the whole torrent
							'name': name, 'name_info': name_info, 'quality': quality, 'info': info,
							'size': dsize, 'seeders': seeders, 'package': package
						}
						# LOCAL PATCH 2026-10-03: the pack's own episode count for the size, as in sources()
						_m = _extract_meta(_clean_for_extract(name))
						_fields = batch_fields(name, _m[1], _m[3], data.get('season_length'))
						if search_series:
							_fields.pop('last_season', None)   # filter_show_pack's answer below is the one the Show filter trusts
							if _fields.get('package') == 'season': _fields.pop('package')
						item.update(_fields)
						if search_series: item.update({'last_season': last_season})
						elif episode_start: item.update(source_utils.pack_range_fields(episode_start, episode_end))
						sources_append(item)
						_kept += 1
			except Exception:
				source_utils.scraper_error('NYAA')
				continue
		_x.log('NYAA-DIAG: sources_packs kind=%s urls=%d kept=%d' % ('show' if search_series else 'season', len(urls), _kept), _x.LOGINFO)
		return sources

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		append = sources.append
		try:
			title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
			title = title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			aliases = list(data.get('aliases') or [])
			# LOCAL PATCH 2026-08-09: data['mal_title'] is the cour's romaji title (via Fribb), which Nyaa releases
			# commonly use instead of TMDb's English one; fed in as an alias.
			mal_title = data.get('mal_title')
			if mal_title and mal_title not in [a if isinstance(a, str) else a.get('title', '') for a in aliases]:
				aliases.insert(0, {'title': mal_title})   # LOCAL PATCH 2026-10-01: first, so the 3-alias cap cannot cut it
			year = data['year']
			is_show = 'tvshowtitle' in data
			season_num = int(data['season']) if is_show else 0
			episode_num = int(data['episode']) if is_show else 0
			# LOCAL PATCH 2026-08-27: cour context, set by DeadLight for anime only -- releases do not carry TMDb's
			# number (Frieren S1E30 is '2nd Season - 02' or '- 30', never 'S01E30').
			cour_episode = data.get('cour_episode') if is_show else None
			cour_season = data.get('cour_season') if is_show else None
			absolute_episode = data.get('absolute_episode') if is_show else None
			season_episode = data.get('season_episode') if is_show else None
			try: season_episode = int(season_episode) if season_episode is not None else None
			except (TypeError, ValueError): season_episode = None
			cour_part = data.get('cour_part') if is_show else None
			foreign_cour_tokens = data.get('foreign_cour_tokens') if is_show else None
			try: cour_episode = int(cour_episode) if cour_episode is not None else None
			except (TypeError, ValueError): cour_episode = None
			try: absolute_episode = int(absolute_episode) if absolute_episode is not None else None
			except (TypeError, ValueError): absolute_episode = None

			import xbmc as _xbmc_diag
			_xbmc_diag.log('NYAA-DIAG: entering sources() title=%r season=%s episode=%s is_show=%s' % (title, data.get('season'), data.get('episode'), is_show), _xbmc_diag.LOGINFO)

			# --- title candidates: primary + up to 3 aliases (deduped) ---
			def _clean_q(s):
				# LOCAL PATCH 2026-10-01: an apostrophe joins its word; as a space it made a stray 's' that Nyaa searched for
				# LOCAL PATCH 2026-10-03: a possessive 's goes WITH the apostrophe ('Journey's' -> 'Journey') -- Nyaa does
				# not match 'Journeys' to "Journey's"
				s = re.sub(r"['\u2019`]s\b", '', s, flags=re.I)
				s = re.sub(r"['\u2019`]", '', s)
				return re.sub(r'[^A-Za-z0-9\s\.-]+', ' ', s).strip()
			clean_title = _clean_q(title)
			cour_plan = data.get('cour_plan') if is_show else None
			primary_lc = clean_title.lower()

			# LOCAL PATCH 2026-07-20: filter out sequel-style aliases -- TMDb may list a separate show as an alias
			# ('Bleach: Thousand-Year Blood War' for 'Bleach'). An alias that is the primary title plus a separator
			# (`:`, `-`, `~`) is neither queried nor allowed into accept_tokens.
			def _is_sequel_variant(a_lc):
				if not a_lc or a_lc == primary_lc: return False
				if not a_lc.startswith(primary_lc): return False
				rest = a_lc[len(primary_lc):]
				return bool(rest) and rest[0] in ':-~.,/ '

			title_candidates = [clean_title]
			seen_titles_lc = {primary_lc}
			safe_aliases = []       # non-sequel aliases we CAN query
			sequel_extra_tokens = set()  # tokens ONLY in sequel aliases — used for reject list
			for alias in aliases:
				try:
					name_al = alias.get('title') if isinstance(alias, dict) else alias
					if not name_al: continue
					c = _clean_q(name_al)
					# LOCAL PATCH 2026-10-01: skip a title cleaned down to almost nothing ('ダイヤのA' -> 'A')
					if len(re.sub(r'[^A-Za-z0-9]', '', c or '')) < 4: continue
					if not c or c.lower() in seen_titles_lc: continue
					seen_titles_lc.add(c.lower())
					# LOCAL PATCH 2026-10-01: an alias naming ANOTHER cour is neither searched nor allowed to vouch for a title
					if cour_plan and (title_cour_markers(c) & set(cour_plan.get('foreign') or ())): continue
					if _is_sequel_variant(c.lower()):
						# collect tokens beyond the primary as sequel-only tokens
						sequel_extra_tokens |= (_tokenize(c) - _tokenize(clean_title))
					else:
						safe_aliases.append(c)
				except Exception: pass
			# cap safe aliases at 3
			for c in safe_aliases[:3]:
				title_candidates.append(c)

			# --- title-token guard set (primary + SAFE aliases only) ---
			accept_tokens = _tokenize(title)
			# Phrase forms of the same candidates; see _title_seq above.
			title_seqs = [_title_seq(title)]
			for c in safe_aliases[:3]:
				accept_tokens |= _tokenize(c)
				_cs = _title_seq(c)
				if _cs and _cs not in title_seqs: title_seqs.append(_cs)
			title_seqs = [t for t in title_seqs if t]

			# LOCAL PATCH 2026-08-07: cross-season contamination filter. data['foreign_season_tokens'] holds tokens
			# from OTHER seasons' TMDb names; reject torrents matching them unless they claim our season.
			foreign_reject_tokens = set()
			try:
				for _t in (data.get('foreign_season_tokens') or []):
					try:
						_t = str(_t).lower()
						if _t and len(_t) >= 4 and _t not in _TOKEN_STOPWORDS:
							foreign_reject_tokens.add(_t)
					except Exception: continue
			except Exception: pass

			# --- build OR-syntax queries ---
			# Nyaa search syntax: quoted phrases OR'd with `|`. One query per title
			# candidate covers all common episode formats; a second covers batches.
			queries = []
			if is_show:
				ep2 = '%02d' % episode_num
				s2 = '%02d' % season_num
				ep_or = '"- %s"|"S%sE%s"|"E%s"|"Episode %s"|"Ep %s"' % (ep2, s2, ep2, ep2, ep2, ep2)
				# LOCAL PATCH 2026-08-27: also ask for the cour-relative number, for the dominant '<Cour Title> - NN'
				# naming. Alongside, not instead: some groups number from the series start.
				cour_or = ''
				# season_episode first: groups keep counting across a season's cours (Re:ZERO S2 ep 24 is cour 2's
				# episode 12). Then the cour number. Absolute last: shows with no Fribb cour (Naruto) only have that.
				_qep = season_episode or cour_episode or absolute_episode
				if _qep and _qep != episode_num:
					cep2 = '%02d' % _qep
					cour_or = '"- %s"|"E%s"|"Episode %s"|"Ep %s"' % (cep2, cep2, cep2, cep2)
				batch_or = '"Batch"|"Complete"|"S%s"|"Season %s"|"01-%s"|"01~%s"|"01 - %s"|"01 ~ %s"' % (s2, s2, ep2, ep2, ep2, ep2)
				# LOCAL PATCH 2026-10-01: Nyaa ANDs a query's words, so a title holding all the words of a shorter one only
				# re-finds a subset: its episode and batch queries are left out (it keeps its bare-title page below)
				_words = lambda s: set(w for w in re.findall(r'[a-z0-9]+', s.lower()))
				_query_titles = [t for t in title_candidates
								 if not any(o != t and _words(o) and _words(o) < _words(t) for o in title_candidates)]
				for t in _query_titles:
					queries.append('%s %s' % (t, ep_or))
					if cour_or: queries.append('%s %s' % (t, cour_or))
					queries.append('%s %s' % (t, batch_or))
			else:
				# movies
				for t in title_candidates:
					queries.append('%s %s' % (t, year))

			urls = ['%s%s%s' % (self.base_link, self.search_link % quote_plus(q), self.url_suffix) for q in queries]
			# LOCAL PATCH 2026-08-09: bare-title queries (Otaku's pattern), downloads-sorted -- the best BD batches
			# often carry no '- NN' / 'Batch' / 'S01' token ('[Moozzi2] Diamond no Ace BD-BOX'). The filter pass below
			# keeps correctness.
			if is_show:
				_bare_link = '/?f=0&c=0_0&q=%s&s=downloads&o=desc'
				# LOCAL PATCH 2026-10-01: the first two titles only (show title and the cour's romaji, when known): each
				# page is ~140 KB and the rest found the same batches again
				_bare_titles = title_candidates[:1] + [t for t in title_candidates[1:] if mal_title and t.lower() == _clean_q(mal_title).lower()][:1]
				if len(_bare_titles) < 2: _bare_titles = title_candidates[:2]
				for t in _bare_titles:
					urls.append('%s%s%s' % (self.base_link, _bare_link % quote_plus(t), self.url_suffix))
			_xbmc_diag.log('NYAA-DIAG: title_candidates=%r queries=%d' % (title_candidates, len(queries)), _xbmc_diag.LOGINFO)

			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('NYYAA')
			return sources

		# --- parallel fetch (Otaku-style): all N queries at once, then process ---
		# LOCAL PATCH 2026-07-20: HTTP round-trips are the whole wall clock (parsing is <1ms), so all URLs go in parallel.
		import time as _time
		_t_fetch_start = _time.time()
		fetch_results = self._fetch_urls(urls)
		_xbmc_diag.log('NYAA-DIAG: parallel fetch %d urls took %.2fs' % (len(urls), _time.time() - _t_fetch_start), _xbmc_diag.LOGINFO)

		# --- filter (sequential — parsing is CPU-bound and cheap) ---
		# LOCAL PATCH 2026-08-09: track rejection reasons for diagnosis
		_reject_stats = {'token': 0, 'season': 0, 'episode': 0, 's2_ambig': 0, 'sequel': 0, 'foreign_lang': 0, 'foreign_season': 0, 'seeders': 0, 'duplicate': 0}
		_pre_filter_count = 0
		seen_hashes = set()
		for url, results in fetch_results:
			try:
				if not _body_has_rows(results): continue
				# LOCAL PATCH 2026-09-16: rows from _rows_from_body (RSS or HTML), in a 1-tuple to keep the loop nesting.
				for _rows in (_rows_from_body(results),):
					for link in _rows:
						magnet = unquote_plus(link[0]).replace('&amp;', '&').split('&tr')[0].replace(' ', '.')
						magnet = source_utils.strip_non_ascii_and_unprintable(magnet)
						try: hash = re.search(r'btih:(.*?)&', magnet, re.I).group(1)
						except: continue
						if hash in seen_hashes:
							_reject_stats['duplicate'] += 1
							continue
						try: name = source_utils.clean_name(magnet.split('&dn=')[1])
						except: continue
						_pre_filter_count += 1

						# ---------- manga/audio junk guard ----------
						# LOCAL PATCH 2026-08-09: bare-title queries pull in manga volumes and music albums whose
						# volume ranges pass the episode-range check. Rejected only when the name has NO video signal
						# (resolution / codec / rip source / container) -- real WEB-DLs can say "Digital".
						_name_lc = name.lower().replace('.', ' ')
						_has_video_signal = re.search(
							r'\b(?:360p|480p|540p|576p|720p|1080p|1440p|2160p|4k|hd|sd|uhd)\b'
							r'|\b(?:x264|x265|h ?264|h ?265|hevc|avc|av1|xvid|vp9)\b'
							r'|\b(?:bd|bdrip|bluray|blu-ray|web-?dl|webrip|hdtv|dvdrip|remux|bdmv|hdrip)\b'
							r'|\b(?:mkv|mp4|avi|m2ts|ts)\b', _name_lc)
						if not _has_video_signal and re.search(
								r'\bvol\b|\bv\d{1,3}\s*[-~]\s*v?\d{1,3}\b|scanlation|\bdigital\b'
								r'|\bcomplete\s+songs\b|\bost\b|\bsoundtrack\b|\bhi-?res\b'
								r'|\bflac\b|\bmp3\b|\b\d{2,3}kbps\b|\b\d{2}bit\b|\bkhz\b', _name_lc):
							_reject_stats['manga_audio'] = _reject_stats.get('manga_audio', 0) + 1
							continue

						# ---------- title phrase guard (cross-show contamination) ----------
						# Stronger than the token guard below, so it runs first. Deliberately NO fallback-when-empty:
						# that would bring back the wrong-show rows; the 'title_phrase' counter in NYAA-DIAG shows misses.
						_name_seq = _title_seq(name)
						if title_seqs and not _seq_matches(_name_seq, title_seqs):
							_reject_stats['title_phrase'] = _reject_stats.get('title_phrase', 0) + 1
							continue
						# ---------- title-token guard (cross-show contamination) ----------
						if accept_tokens:
							name_tokens = _tokenize(name)
							# LOCAL PATCH 2026-10-03: not when the phrase guard above already matched -- it reads
							# 'TokyoRevengers' as the title, while tokens see one word sharing nothing with {'tokyo', 'revengers'}
							if not (accept_tokens & name_tokens) and not title_seqs:
								_reject_stats['token'] += 1
								continue
						else:
							name_tokens = _tokenize(name)

						# ---------- Otaku-style extract on cleaned text ----------
						seasons, episodes, parts, is_range = (set(), None, set(), False)
						if is_show:
							cleaned = _clean_for_extract(name)
							seasons, episodes, parts, is_range = _extract_meta(cleaned)

							# LOCAL PATCH 2026-08-07: cross-season contamination reject -- hits on other seasons' tokens
							# unless the torrent explicitly claims our season.
							if foreign_reject_tokens and (foreign_reject_tokens & name_tokens):
								if season_num not in seasons:  # includes empty seasons set
									_xbmc_diag.log('NYAA-DIAG: REJECT foreign-season-token hit=%s name=%r' % ((foreign_reject_tokens & name_tokens), name), _xbmc_diag.LOGINFO)
									_reject_stats['foreign_season'] += 1
									continue

							# LOCAL PATCH 2026-08-27: with a cour mapping, judge by the cour -- TMDb's numbers match nothing
							# for split seasons. cour_match compares the release season (Fribb's season.tvdb) and accepts
							# the cour-relative or the absolute episode number.
							if cour_episode is not None and cour_season:
								# LOCAL PATCH 2026-10-01: which cour the NAME says this is (anime_utils.name_cour_check)
								_named, _cm_name = name_cour_check(name, cour_plan, cour_season, absolute_episode, (season_episode, cour_episode))
								if _named is False:
									_reject_stats['other_cour'] = _reject_stats.get('other_cour', 0) + 1
									continue
								if not cour_match(_cm_name, cour_season, cour_episode, absolute_episode,
									season_episode, cour_part, foreign_cour_tokens, trust_id=bool(_named)):
									_reject_stats['cour'] = _reject_stats.get('cour', 0) + 1
									continue
							else:
								# season check — reject if explicit season present AND not ours
								if seasons and season_num not in seasons:
									_reject_stats['season'] += 1
									continue

								# episode check — accept when episodes covers our target OR
								# when no episode could be extracted (bare batch, auto-accept).
								# The absolute number counts as our target too: without a Fribb cour this
								# is the only path, and 'Naruto - 159' is TMDb's S04E01.
								_want_eps = set([episode_num])
								if absolute_episode: _want_eps.add(absolute_episode)
								if episodes is not None and not (_want_eps & set(episodes)):
									_reject_stats['episode'] += 1
									continue

								# S2+ ambiguity guard: reject a batch-style match (no episode, or a range) with no season
								# marker. Bare single episodes are still accepted (weekly naming, `[Group] Show - 05`).
								if season_num >= 2 and not seasons and (episodes is None or is_range):
									_reject_stats['s2_ambig'] += 1
									continue

						# ---------- sequel/spinoff reject (deferred until AFTER season extract) ----------
						# LOCAL PATCH 2026-07-20: reject sequel-alias tokens, except when the torrent's season marker
						# claims our season (the target season may BE the sequel in TMDb).
						# LOCAL PATCH 2026-10-01: not when the cour plan already judged the name -- a cour's own alias
						# ('... Act II') would make its word a sequel word.
						if accept_tokens and sequel_extra_tokens and (sequel_extra_tokens & name_tokens) and not cour_plan:
							if season_num not in seasons:   # includes empty seasons set
								_xbmc_diag.log('NYAA-DIAG: REJECT sequel-token hit=%s name=%r' % ((sequel_extra_tokens & name_tokens), name), _xbmc_diag.LOGINFO)
								_reject_stats['sequel'] += 1
								continue

						# ---------- foreign-lang guard ----------
						if source_utils.remove_lang(name, check_foreign_audio):
							_reject_stats['foreign_lang'] += 1
							continue

						# ---------- seeders ----------
						try: seeders = int(link[2][0])
						except: seeders = 0

						quality, info = source_utils.get_release_quality(name, magnet)
						try:
							size = link[1]
							dsize, isize = source_utils._size(size)
							info.insert(0, isize)
						except: dsize = 0
						info = ' | '.join(info)

						seen_hashes.add(hash)
						_item = {'provider': 'nyaa', 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name, 'quality': quality,
										'language': 'en', 'url': magnet, 'info': info, 'direct': False, 'debridonly': True, 'size': dsize}
						# LOCAL PATCH 2026-10-03: batches say so (anime_utils.batch_fields); a multi-season one carries its seasons
						if is_show: _item.update(batch_fields(name, episodes, is_range, data.get('season_length')))
						append(_item)
			except:
				source_utils.scraper_error('NYAA')
				continue
		_xbmc_diag.log('NYAA-DIAG: final source count=%d (pre-filter unique=%d) rejects=%s' % (
			len(sources), _pre_filter_count, {k: v for k, v in _reject_stats.items() if v}), _xbmc_diag.LOGINFO)
		return sources
