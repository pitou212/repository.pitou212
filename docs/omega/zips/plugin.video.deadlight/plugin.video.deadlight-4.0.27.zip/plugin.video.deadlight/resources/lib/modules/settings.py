# -*- coding: utf-8 -*-
from caches.settings_cache import get_setting, set_setting, default_setting_values
from modules.kodi_utils import translate_path, get_property

# LOCAL PATCH 2026-11-02: the timing diagnostics (scrape / TorBox / source window / season art lines) are switched here,
# in code, not by the hidden scrape.diag_timing setting. True logs them.
DIAG_TIMING = False

def diag_timing():
	return DIAG_TIMING

def tmdb_api_key():
	return get_setting('deadlight.tmdb_api', '')

def trakt_client():
	return get_setting('deadlight.trakt.client', '')

def trakt_secret():
	return get_setting('deadlight.trakt.secret', '')

def trakt_user_active():
	return get_setting('deadlight.trakt.user', 'empty_setting') not in (None, 'empty_setting', '')

def tmdblist_user_active():
	return get_setting('deadlight.tmdb.account_id', 'empty_setting') not in (None, 'empty_setting', '')

# LOCAL PATCH 2026-07-23: MDBList accessors — mirror trakt_user_active. `mdblist_user_active`
# gates the MDBList menu section + write ops. Signed in with OAuth device code since 2026-08-07 (mdblist_api).
def mdblist_user_active():
	return get_setting('deadlight.mdblist.user', 'empty_setting') not in (None, 'empty_setting', '')

def mdblist_sync_interval():
	# Returns (str_minutes, seconds) — matches trakt_sync_interval signature.
	setting = get_setting('deadlight.mdblist.sync_interval', '60')
	try: interval = int(setting) * 60
	except (TypeError, ValueError): setting, interval = '60', 3600   # LOCAL PATCH 2026-10-15: an empty value killed the sync monitor before its first sync
	return setting, interval

# LOCAL PATCH 2026-07-29: SIMKL accessors — same shape as trakt/mdblist. `simkl_user_active`
# gates SIMKL menu sections + writes. Auth via PIN device flow (no OAuth PKCE).
def simkl_user_active():
	return get_setting('deadlight.simkl.user', 'empty_setting') not in (None, 'empty_setting', '') \
		and get_setting('deadlight.simkl.token', 'empty_setting') not in (None, 'empty_setting', '')

def simkl_sync_interval():
	setting = get_setting('deadlight.simkl.sync_interval', '60')
	try: interval = int(setting) * 60
	except (TypeError, ValueError): setting, interval = '60', 3600   # LOCAL PATCH 2026-10-15: an empty value killed the sync monitor before its first sync
	return setting, interval

def simkl_scrobble_enabled():
	return get_setting('deadlight.simkl.scrobble', 'true') == 'true'

# LOCAL PATCH 2026-08-29: AniList accessors — same shape as the SIMKL block above. Auth is a
# pasted ~1-year bearer against the user's own client, so there is no expiry to check here.
def anilist_user_active():
	return get_setting('deadlight.anilist.user', 'empty_setting') not in (None, 'empty_setting', '') \
		and get_setting('deadlight.anilist.token', 'empty_setting') not in (None, 'empty_setting', '')

def anilist_sync_interval():
	setting = get_setting('deadlight.anilist.sync_interval', '60')
	try: interval = int(setting) * 60
	except (TypeError, ValueError): setting, interval = '60', 3600   # LOCAL PATCH 2026-10-15: an empty value killed the sync monitor before its first sync
	return setting, interval

def anilist_scrobble_enabled():
	return get_setting('deadlight.anilist.scrobble', 'true') == 'true'

# LOCAL PATCH 2026-10-02: MyAnimeList progress push (apis/mal_api.py)
def mal_user_active():
	return get_setting('deadlight.mal.token', 'empty_setting') not in (None, 'empty_setting', '')

def mal_scrobble_enabled():
	return get_setting('deadlight.mal.scrobble', 'true') == 'true'

# LOCAL PATCH 2026-07-30: auto-scroll to first unwatched episode in season view.
def autoscroll_unwatched():
	return get_setting('deadlight.episodes.autoscroll_unwatched', 'true') == 'true'

# LOCAL PATCH 2026-08-29: gates unaired episodes AND wholly unaired seasons in the browse
# lists. Off by default, matching nextep.include_unaired's polarity.
def include_unaired_episodes():
	return get_setting('deadlight.episodes.include_unaired', 'false') == 'true'

def results_format():
	# LOCAL PATCH 2026-10-02: 'Rows' is now 'Cards' (the layout was redesigned as cards). A stored 'Rows' is migrated once;
	# the window and its skin still call the layout 'rows' internally (window 2001).
	results_window_numbers_dict = {'List': 2000, 'Cards': 2001, 'WideList': 2002}
	window_format = str(get_setting('deadlight.results.list_format', 'List'))
	if window_format == 'Rows':
		window_format = 'Cards'
		set_setting('results.list_format', window_format)
	if not window_format in results_window_numbers_dict:
		window_format = 'List'
		set_setting('results.list_format', window_format)
	window_number = results_window_numbers_dict[window_format]
	return ('rows' if window_format == 'Cards' else window_format.lower()), window_number

def store_resolved_to_cloud(debrid_service, pack):
	setting_value = int(get_setting('deadlight.store_resolved_to_cloud.%s' % debrid_service.lower(), '0'))
	return setting_value in (1, 2) if pack else setting_value == 1

def enabled_debrids_check(debrid_service):
	if not get_setting('deadlight.%s.enabled' % debrid_service) == 'true': return False
	return authorized_debrid_check(debrid_service)

def authorized_debrid_check(debrid_service):
	if get_setting('deadlight.%s.token' % debrid_service) in (None, '', 'empty_setting'): return False
	return True

def playback_key():
	return get_setting('deadlight.playback_key', '0')

def limit_resolve():
	return get_setting('deadlight.playback.limit_resolve', 'false') == 'true'

def movies_directory():
	return translate_path(get_setting('deadlight.movies_directory'))
	
def download_directory(media_type):
	download_directories_dict = {'movie': 'deadlight.movie_download_directory', 'episode': 'deadlight.tvshow_download_directory', 'thumb_url': 'deadlight.image_download_directory',
								'image_url': 'deadlight.image_download_directory','image': 'deadlight.image_download_directory', 'premium': 'deadlight.premium_download_directory',
								None: 'deadlight.premium_download_directory', 'None': False}
	return translate_path(get_setting(download_directories_dict[media_type]))

def ai_model_active():
	return get_setting('deadlight.google_api', 'empty_setting') not in (None, 'None', '', 'empty_setting')

def ai_model_order():
	# LOCAL PATCH 2026-10-09: a saved order can name retired or Groq models -- keep the known ones in the user's order,
	# append any new model at the end.
	from apis.google_api import models
	known = models()
	saved = [i for i in get_setting('deadlight.ai_model.order', ','.join(known)).split(',') if i in known]
	return saved + [i for i in known if i not in saved]

def ai_model_limit():
	return max(1, int(get_setting('deadlight.ai_model.limit', '10')))

def show_unaired_watchlist():
	return get_setting('deadlight.show_unaired_watchlist', 'true') == 'true'

def lists_cache_duraton():
	return int(get_setting('deadlight.lists_cache_duraton', '48'))

def auto_start_deadlight():
	return get_setting('deadlight.auto_start_deadlight', 'false') == 'true'

def source_folders_directory(media_type, source):
	setting = 'deadlight.%s.movies_directory' % source if media_type == 'movie' else 'deadlight.%s.tv_shows_directory' % source
	if get_setting(setting) not in ('', 'None', None): return translate_path( get_setting(setting))
	else: return False

def avoid_episode_spoilers():
	return get_setting('deadlight.avoid_episode_spoilers', 'false') == 'true'

def paginate(is_home):
	paginate_lists = int(get_setting('deadlight.paginate.lists', '0'))
	if is_home: return paginate_lists in (2, 3)
	else: return paginate_lists in (1, 3)

def page_limit(is_home):	
	return int(get_setting({True: 'deadlight.paginate.limit_widgets', False: 'deadlight.paginate.limit_addon'}[is_home], '20'))

def quality_filter(setting):
	return get_setting('deadlight.%s' % setting).split(', ')

def prefer_release_groups(autoplay):
	# LOCAL PATCH 2026-10-25: known release groups lead within a quality (modules/release_groups.py), same choices as sort_to_top
	return {0: False, 1: False if autoplay else True, 2: True if autoplay else False, 3: True}.get(int(get_setting('deadlight.filter.prefer_release_groups', '0') or 0), False)

def sort_to_top_filter(autoplay):
	return {0: False, 1: False if autoplay else True, 2: True if autoplay else False, 3: True}[int(get_setting('deadlight.filter.sort_to_top', '0'))]

def audio_filters():
	setting = get_setting('deadlight.filter_audio')
	if setting in ('empty_setting', ''): return []
	return setting.split(', ')

def preferred_filters():
	setting = get_setting('deadlight.filter.preferred_filters')
	if setting in ('empty_setting', ''): return []
	return setting.split(', ')

def banned_keywords_filter():
	# LOCAL PATCH 2026-06-20: comma-separated tokens; case-insensitive substring match against raw filename in sources.filter_banned_keywords.
	setting = get_setting('deadlight.filter.banned_keywords', '')
	if setting in ('empty_setting', ''): return ''
	return setting

def include_prerelease_results():
	return int(get_setting('deadlight.filter.include_prerelease', '0')) == 0

def stingers_show():
	return get_setting('deadlight.stinger_alert.show', 'false') == 'true'

def stingers_use_chapters():
	return get_setting('deadlight.stinger_alert.use_chapters', 'false') == 'true'

def stingers_percentage():
	return int(get_setting('deadlight.stinger_alert.window_percentage', '90'))

def include_anime_tvshow():
	return get_setting('deadlight.include_anime_tvshow', 'false') == 'true'

def auto_play(media_type):
	return get_setting('deadlight.auto_play_%s' % media_type, 'false') == 'true'

# LOCAL PATCH 2026-10-08: both read the one next_episode_mode setting -- '1' Show Sources (autoscrape), '2' Play
# Automatically (autoplay). Still off while Auto Play (episodes) is on, as the two switches were.
def next_episode_mode():
	return get_setting('deadlight.next_episode_mode', '0')

def autoplay_next_episode():
	return not auto_play('episode') and next_episode_mode() == '2'

def autoscrape_next_episode():
	return not auto_play('episode') and next_episode_mode() == '1'

def autoscrape_confirm():
	return get_setting('deadlight.autoscrape_confirm', 'false') == 'true'

def autoplay_prescrape(scrape_provider):
	return get_setting('deadlight.autoplay.%s' % scrape_provider, 'false') == 'true'

def auto_nextep_settings(play_type):
	play_type = 'autoplay' if play_type == 'autoplay_nextep' else 'autoscrape'
	# LOCAL PATCH 2026-10-08: one timing pair for both modes (the autoscrape_* copies went with the merged setting)
	window_percentage = 100 - int(get_setting('deadlight.autoplay_next_window_percentage', '95'))
	use_chapters = get_setting('deadlight.autoplay_use_chapters', 'true') == 'true'
	watching_check = int(get_setting('deadlight.autoplay_watching_check', '3'))
	scraper_time = int(get_setting('deadlight.results.timeout', '20')) + 20   # LOCAL PATCH 2026-08-25: fallback aligned to DB seed (was '60')
	if play_type == 'autoplay':
		alert_method = int(get_setting('deadlight.autoplay_alert_method', '0'))
		default_action = {'0': 'play', '1': 'cancel', '2': 'pause'}[get_setting('deadlight.autoplay_default_action', '0')]   # LOCAL PATCH 2026-08-25: fallback aligned to DB seed (was '1')
	else: alert_method, default_action = '', ''
	return {'scraper_time': scraper_time, 'window_percentage': window_percentage, 'alert_method': alert_method,
			'default_action': default_action, 'use_chapters': use_chapters, 'watching_check': watching_check}

def filter_status(filter_type):
	return int(get_setting('deadlight.filter.%s' % filter_type, '0'))

def limit_number_quality():
	return int(get_setting('deadlight.results.limit_number_quality', '0'))

def limit_number_total():
	return int(get_setting('deadlight.results.limit_number_total', '0'))

def trakt_sync_interval():
	setting = get_setting('deadlight.trakt.sync_interval', '60')
	try: interval = int(setting) * 60
	except (TypeError, ValueError): setting, interval = '60', 3600   # LOCAL PATCH 2026-10-15: an empty value killed the sync monitor before its first sync
	return setting, interval

def lists_sort_order(setting):
	return int(get_setting('deadlight.sort.%s' % setting, '0'))

def tmdblists_sort_order(setting):
	if setting == 'recommendations': return None
	return str(get_setting('deadlight.tmdbsort.%s' % setting, '4'))

def personal_lists_sort_unseen_to_top():
	return get_setting('deadlight.personal_list.sort_unseen_to_top') == 'true'

def personal_lists_unseen_highlight():
	if get_setting('deadlight.personal_list.highlight_unseen', 'false') == 'false': return None
	return get_setting('deadlight.personal_list.unseen_highlight', 'FF4DDBFF')

def personal_lists_show_author():
	return get_setting('deadlight.personal_list.show_author', 'true') == 'true'

def show_specials():
	return get_setting('deadlight.show_specials', 'false') == 'true'

# LOCAL PATCH 2026-10-17: anime has its own -- 'hidden', 'folder' (TMDb's Specials season, last) or 'airing' (each run of
# specials its own row, between the seasons it aired between: indexers.seasons._special_rows). show_specials is non-anime.
def anime_specials():
	try: return ('hidden', 'folder', 'airing')[int(get_setting('deadlight.anime.specials', '1'))]
	except (ValueError, IndexError): return 'folder'

def single_ep_unwatched_episodes():
	return get_setting('deadlight.single_ep_unwatched_episodes', 'false') == 'true'

def single_ep_display_format(is_external):
	if is_external: setting, default = 'deadlight.single_ep_display_widget', '1'
	else: setting, default = 'deadlight.single_ep_display', ''
	return int(get_setting(setting, default))

def easynews_playback_method(query):
	method = int(get_setting('deadlight.easynews.playback_method', '0'))
	queries = {'retry': lambda: method in (1, 3), 'non_seek': lambda: method in (2, 3),
				'direct_play': lambda: method in (2, 3) and get_setting('deadlight.easynews.playback_method_limited', 'false') != 'true'}
	setting = queries[query]()
	return setting

def easynews_playback_method_retries():
	return int(get_setting('deadlight.easynews.playback_method_retries', '1')) + 1

def easynews_authorized():
	easynews_user = get_setting('deadlight.easynews_user', 'empty_setting')
	easynews_password = get_setting('deadlight.easynews_password', 'empty_setting')
	if easynews_user in ('empty_setting', '') or easynews_password in ('empty_setting', ''): easynews_status = False
	else: easynews_status = True
	return easynews_status

def extras_enable_extra_ratings():
	return get_setting('deadlight.extras.enable_extra_ratings', 'true') == 'true'

def extras_enabled_ratings():
	return get_setting('deadlight.extras.enabled_ratings', 'Meta, Tom/Critic, Tom/User, IMDb, TMDb, AniList, MAL').split(', ')

def extras_enable_item_ratings():
	return get_setting('deadlight.extras.enable_item_ratings', 'false') =='true'

def extras_enable_scrollbars():
	return get_setting('deadlight.extras.enable_scrollbars', 'false')

def extras_enabled():
	setting = get_setting('deadlight.extras.enabled', '2000,2050,2051,2052,2053,2054,2055,2056,2057,2058,2059,2060,2061,2062')
	if setting in ('', None, 'noop', []): return []
	split_setting = setting.split(',')
	return [int(i) for i in split_setting]

def extras_order():
	setting = get_setting('deadlight.extras.order', '2000,2050,2051,2052,2053,2054,2055,2056,2057,2058,2059,2060,2061,2062')
	if setting in ('', None, 'noop', []): return []
	order = [int(i) for i in setting.split(',')]
	# LOCAL PATCH 2026-10-09: a row added after the order was saved (2067 AniList Recommended) goes in after its neighbour
	# in the default order. extras.xml is generated from this list, so a row missing here has no control at all, and
	# ticking it under Extras lists would do nothing. Same as cm_current_order.
	default = [int(i) for i in default_setting_values('extras.order')['setting_default'].split(',')]
	for prev, item in zip([None] + default, default):
		if item in order: continue
		order.insert(order.index(prev) + 1 if prev in order else len(order), item)
	return order

def recommend_service():
	return int(get_setting('deadlight.recommend_service', '0'))

# LOCAL PATCH 2026-10-15: anime metadata providers -- 'anilist', 'mal', and the third choice of each setting
_ANIME_PROVIDER_CHOICES = {'score': ('anilist', 'mal', 'both'), 'genre': ('anilist', 'mal', 'tmdb'),
						'airtime': ('anilist', 'sub', 'dub', 'tmdb')}

# LOCAL PATCH 2026-10-16: 'TV Air Times' -- 'tvmaze' (Trakt when TVmaze has none), 'trakt', or 'tmdb' (the date alone)
def tv_airtime_provider():
	try: return ('tvmaze', 'trakt', 'tmdb')[int(get_setting('deadlight.tv.airtime_provider', '0'))]
	except (ValueError, IndexError): return 'tvmaze'

# LOCAL PATCH 2026-10-22: 'Anime Catalogues' -- the service the anime lists and search come from (apis/anime_backup.py)
def anime_catalogue_provider():
	try: return ('anilist', 'mal', 'kitsu')[int(get_setting('deadlight.anime.catalogue_provider', '0'))]
	except (ValueError, IndexError): return 'anilist'

# LOCAL PATCH 2026-11-08: MyAnimeList's filler / recap flags (modules/anime_filler.py, data from api.tenrai.org)
def anime_filler_marks():
	return get_setting('deadlight.anime.filler_marks', 'true') == 'true'

def anime_skip_filler():
	"""0 off, 1 skip filler, 2 skip filler and recap -- for the next episode (Up Next, autoplay, Next Episodes)."""
	try: return max(0, min(2, int(get_setting('deadlight.anime.skip_filler', '0'))))
	except (TypeError, ValueError): return 0

def anime_provider(kind):
	choices = _ANIME_PROVIDER_CHOICES[kind]
	try: return choices[int(get_setting('deadlight.anime.%s_provider' % kind, '0'))]
	except (ValueError, IndexError): return choices[0]

def recommend_seed():
	return int(get_setting('deadlight.recommend_seed', '5'))

def tv_progress_location():
	return int(get_setting('deadlight.tv_progress_location', '0'))

def check_prescrape_sources(scraper, media_type):
	if scraper in ('easynews', 'rd_cloud', 'pm_cloud', 'ad_cloud', 'tb_cloud', 'folders', 'aiostreams', 'http_streams'): return get_setting('deadlight.check.%s' % scraper) == 'true'
	if get_setting('deadlight.check.%s' % scraper) == 'true' and auto_play(media_type): return True
	else: return False

def filter_by_name(scraper):
	if get_property('fs_filterless_search') == 'true': return False
	return get_setting('deadlight.%s.title_filter' % scraper, 'false') == 'true'

def uncached_min_seeders():
	return int(get_setting('deadlight.results.uncached_min_seeders', '0'))

def easynews_language_filter():
	enabled = get_setting('deadlight.easynews.filter_lang') == 'true'
	if enabled: filters = get_setting('deadlight.easynews.lang_filters').split(', ')
	else: filters = []
	return enabled, filters

def size_sort_weighted():
	return get_setting('deadlight.results.size_sort_weighted', 'false') == 'true'

def results_sort_order():
	sort_direction = -1 if get_setting('deadlight.results.size_sort_direction') == '0' else 1
	return (
			lambda k: (k['quality_rank'], k['provider_rank'], sort_direction*k['size_rank']), #Quality, Provider, Size
			lambda k: (k['quality_rank'], sort_direction*k['size_rank'], k['provider_rank']), #Quality, Size, Provider
			lambda k: (k['provider_rank'], k['quality_rank'], sort_direction*k['size_rank']), #Provider, Quality, Size
			lambda k: (k['provider_rank'], sort_direction*k['size_rank'], k['quality_rank']), #Provider, Size, Quality
			lambda k: (sort_direction*k['size_rank'], k['quality_rank'], k['provider_rank']), #Size, Quality, Provider
			lambda k: (sort_direction*k['size_rank'], k['provider_rank'], k['quality_rank'])  #Size, Provider, Quality
			)[int(get_setting('deadlight.results.sort_order', '1'))]

def active_internal_scrapers():
	settings = ['provider.external', 'provider.easynews', 'provider.folders']
	settings_append = settings.append
	for item in [('rd', 'provider.rd_cloud'), ('pm', 'provider.pm_cloud'), ('ad', 'provider.ad_cloud'), ('tb', 'provider.tb_cloud')]:
		if enabled_debrids_check(item[0]): settings_append(item[1])
	settings_append('provider.aiostreams')
	settings_append('provider.http_streams')
	active = [i.split('.')[1] for i in settings if get_setting('deadlight.%s' % i) == 'true']
	return active

def provider_sort_ranks():
	fo_priority = int(get_setting('deadlight.folders.priority', '6'))
	en_priority = int(get_setting('deadlight.en.priority', '7'))
	aiostreams_priority = int(get_setting('deadlight.aiostreams.priority', '10'))
	http_streams_priority = int(get_setting('deadlight.http_streams.priority', '8'))
	rd_priority = int(get_setting('deadlight.rd.priority', '8'))
	ad_priority = int(get_setting('deadlight.ad.priority', '9'))
	pm_priority = int(get_setting('deadlight.pm.priority', '10'))
	tb_priority = int(get_setting('deadlight.tb.priority', '10'))
	return {'easynews': en_priority, 'real-debrid': rd_priority, 'premiumize.me': pm_priority, 'alldebrid': ad_priority,
	'torbox': tb_priority, 'rd_cloud': rd_priority, 'pm_cloud': pm_priority, 'ad_cloud': ad_priority, 'tb_cloud': tb_priority, 'folders': fo_priority,
	'aiostreams': aiostreams_priority, 'http_streams': http_streams_priority}

def sort_to_top(provider):
	sort_to_top_dict = {'folders': 'deadlight.results.sort_folders_first', 'rd_cloud': 'deadlight.results.sort_rdcloud_first', 'pm_cloud': 'deadlight.results.sort_pmcloud_first',
						'ad_cloud': 'deadlight.results.sort_adcloud_first', 'tb_cloud': 'deadlight.results.sort_tbcloud_first'}
	return get_setting(sort_to_top_dict[provider]) == 'true'

def auto_resume(media_type, autoplay_status):
	return {0: False, 1: True, 2: autoplay_status}[int(get_setting('deadlight.auto_resume_%s' % media_type))]

def scraping_settings():
	highlight_type = int(get_setting('deadlight.highlight.type', '0'))
	if highlight_type == 2:
		highlight = get_setting('deadlight.scraper_single_highlight', 'FF008EB2')
		# LOCAL PATCH 2026-10-03: + cam/scr/tele -- rows of those qualities raised KeyError in the results window and vanished
		return {'highlight_type': 1, '4k': highlight, '1080p': highlight, '720p': highlight, 'sd': highlight,
				'cam': highlight, 'scr': highlight, 'tele': highlight}
	easynews_highlight, debrid_cloud_highlight, folders_highlight, aiostreams_highlight, http_streams_highlight = '', '', '', '', ''
	rd_highlight, pm_highlight, ad_highlight, tb_highlight = '', '', '', ''
	highlight_4K, highlight_1080P, highlight_720P, highlight_SD = '', '', '', ''
	if highlight_type == 0:
		easynews_highlight = get_setting('deadlight.provider.easynews_highlight', 'FF3E9EC4')
		debrid_cloud_highlight = get_setting('deadlight.provider.debrid_cloud_highlight', 'FF8C9DB3')
		folders_highlight = get_setting('deadlight.provider.folders_highlight', 'FFC49A6C')
		aiostreams_highlight = get_setting('deadlight.provider.aiostreams_highlight', 'FF9D84D8')
		http_streams_highlight = get_setting('deadlight.provider.http_streams_highlight', 'FFA9B957')
		rd_highlight = get_setting('deadlight.provider.rd_highlight', 'FF52B878')
		pm_highlight = get_setting('deadlight.provider.pm_highlight', 'FFCC6F7E')
		ad_highlight = get_setting('deadlight.provider.ad_highlight', 'FFD0834E')
		tb_highlight = get_setting('deadlight.provider.tb_highlight', 'FF3FB8AF')
	else:
		highlight_4K = get_setting('deadlight.scraper_4k_highlight', 'FFFF00FE')
		highlight_1080P = get_setting('deadlight.scraper_1080p_highlight', 'FFE6B800')
		highlight_720P = get_setting('deadlight.scraper_720p_highlight', 'FF3C9900')
		highlight_SD = get_setting('deadlight.scraper_SD_highlight', 'FF0166FF')
	return {'highlight_type': highlight_type, 'real-debrid': rd_highlight, 'premiumize': pm_highlight, 'alldebrid': ad_highlight,
			'torbox': tb_highlight, 'rd_cloud': debrid_cloud_highlight, 'pm_cloud': debrid_cloud_highlight, 'ad_cloud': debrid_cloud_highlight,
			'tb_cloud': debrid_cloud_highlight, 'easynews': easynews_highlight, 'folders': folders_highlight, 'aiostreams': aiostreams_highlight,
			'http_streams': http_streams_highlight,
			'4k': highlight_4K, '1080p': highlight_1080P, '720p': highlight_720P, 'sd': highlight_SD,
			'cam': highlight_SD, 'scr': highlight_SD, 'tele': highlight_SD}   # LOCAL PATCH 2026-10-03: prerelease rows take the SD colour

def external_cache_check():
	return get_setting('deadlight.external.cache_check') == 'true'

def omdb_api_key():
	return get_setting('deadlight.omdb_api', 'empty_setting')

def default_all_episodes():
	return int(get_setting('deadlight.default_all_episodes', '0'))

def max_threads():
	if not get_setting('deadlight.limit_concurrent_threads', 'false') == 'true': return 60
	return int(get_setting('deadlight.max_threads', '60'))

def get_meta_filter():
	return get_setting('deadlight.meta_filter', 'true')

def mpaa_region():
	return get_setting('deadlight.mpaa_region', 'US')

def widget_hide_next_page():
	# LOCAL PATCH 2026-10-26 (4.0.8): or this call asked for none -- 'nextpage=false' in the plugin URL. AF3's hub spotlight
	# adds it (Includes_Hubs.xml, Hub_Spotlight_List): its last slide was the list's 'Next Page' item.
	try:
		import sys
		if 'nextpage=false' in (sys.argv[2] if len(sys.argv) > 2 else ''): return True
	except Exception: pass
	return get_setting('deadlight.widget_hide_next_page', 'false') == 'true'

def widget_hide_watched():
	return get_setting('deadlight.widget_hide_watched', 'false') == 'true'

def calendar_sort_order():
	return int(get_setting('deadlight.trakt.calendar_sort_order', '0'))

def ignore_articles():
	return get_setting('deadlight.ignore_articles', 'false') == 'true'

def jump_to_enabled():
	return get_setting('deadlight.paginate.jump_to', 'true') == 'true'

def date_offset():
	return int(get_setting('deadlight.datetime.offset', '0')) + 5


def air_grace_hours():
	"""Hours to wait AFTER an episode airs before treating it as available.

	LOCAL PATCH 2026-08-29. Trakt gives real UTC airtimes, so an episode appears the instant it drops at source, hours
	before anything is findable. This delays it without pretending the air time is wrong.

	Deliberately NOT reusing datetime.offset: that shifts the ASSUMED 20:00 airtime in the TMDb fallback and is bypassed
	when Trakt has a real timestamp; overloading it would re-create an earlier hours-off airtime bug.
	"""
	# LOCAL PATCH 2026-11-08: held 30 s. with_air_grace runs per episode (~150 reads on one page), each a Home-property read
	# under Kodi's GUI lock; 30 s, not the process, because the service lives all session.
	import time
	now = time.time()
	if now - _AIR_GRACE[1] < 30: return _AIR_GRACE[0]
	try: hours = int(get_setting('deadlight.episodes.air_grace', '0'))
	except (TypeError, ValueError): hours = 0
	_AIR_GRACE[:] = [hours, now]
	return hours
_AIR_GRACE = [0, 0.0]

# LOCAL PATCH 2026-10-19: the one copy of _grace (indexers/episodes and modules/episode_tools held their own).
# LOCAL PATCH 2026-11-01 (cleanup): no 30 s memo -- get_setting is a window-property read.
def with_air_grace(dt):
	"""Air datetime plus the user's grace period (air_grace_hours). Shifts only the AIRED decision, never the date shown:
	Trakt reports the real drop time, which for Paramount+ / Netflix can be the small hours local."""
	try:
		if not dt: return dt
		hours = air_grace_hours() or 0
		if not hours: return dt
		from datetime import timedelta
		return dt + timedelta(hours=hours)
	except Exception: return dt

def media_open_action(media_type):
	return int(get_setting('deadlight.media_open_action_%s' % media_type, '0'))

def watched_indicators():
	# LOCAL PATCH 2026-07-23 / 2026-07-29: 4-way enum (0=Fen local, 1=Trakt, 2=MDBList,
	# 3=SIMKL). Fall back to 0 when the chosen provider isn't authenticated so
	# callers never dispatch to an unconfigured backend.
	try: chosen = int(get_setting('deadlight.watched_indicators', '0'))
	except: chosen = 0
	if chosen == 1 and not trakt_user_active(): return 0
	if chosen == 2 and not mdblist_user_active(): return 0
	if chosen == 3 and not simkl_user_active(): return 0
	return chosen

# LOCAL PATCH 2026-09-03 (Red Light 2.3.6 port): the local watched tick follows the provider. Trakt and SIMKL scrobble
# server-side at ~80%; MDBList and the local table have no threshold of their own, so they keep 90.
# NOTE the enum is NOT Red Light's (0=local, 1=Trakt, 2=Simkl, 3=MDBList, tested `in (1, 2)`). DeadLight's is
# 0=local, 1=Trakt, 2=MDBList, 3=SIMKL -- copying that condition would invert MDBList and SIMKL.
def playback_watched_percent():
	return 80 if watched_indicators() in (1, 3) else 90

def flatten_episodes():
	return get_setting('deadlight.trakt.flatten_episodes', 'false') == 'true'

# LOCAL PATCH 2026-08-05 (Red Light R4 port)
def exclude_specials_from_progress():
	return get_setting('deadlight.progress.exclude_specials', 'true') == 'true'

def nextep_method():
	return int(get_setting('deadlight.nextep.method', '0'))

def nextep_limit_history():
	return get_setting('deadlight.nextep.limit_history', 'false') == 'true'

def nextep_limit():
	return int(get_setting('deadlight.nextep.limit', '20'))

def nextep_include_unwatched():
	return int(get_setting('deadlight.nextep.include_unwatched', '0'))

def nextep_include_airdate():
	return get_setting('deadlight.nextep.include_airdate', 'false') == 'true'

def nextep_airing_today():
	return get_setting('deadlight.nextep.airing_today', 'false') == 'true'

def nextep_include_unaired():
	return get_setting('deadlight.nextep.include_unaired', 'false') == 'true'

def nextep_sort_key():
	return {0: 'last_played', 1: 'first_aired', 2: 'name'}[int(get_setting('deadlight.nextep.sort_type', '0'))]

def nextep_sort_direction():
	return int(get_setting('deadlight.nextep.sort_order', '0')) == 0

def update_delay():
	return int(get_setting('deadlight.update.delay', '45'))

def update_action():
	return int(get_setting('deadlight.update.action', '2'))

def rescrape_settings(include_off=False):
	# LOCAL PATCH 2026-10-04: include_off for the settings dialog (dialogs.rescrape_actions_choice), so a step set to Off
	# can be switched back on. The no-results chain (sources.py retry_actions) still gets only the active ones.
	rescrapes = [('cache_ignored', '1', '0'), ('imdb_year', '0', '1'), ('with_all', '0', '2'), ('episode_group', '0', '3'), ('ignore_filters', '0', '4')]
	return sorted([(i[0], int(get_setting('deadlight.rescrape.%s' % i[0], i[1])), int(get_setting('deadlight.rescrape.%s.order' % i[0], i[2]))  ) \
					for i in rescrapes if include_off or int(get_setting('deadlight.rescrape.%s' % i[0], i[1])) in (1, 2)], key=lambda x: x[2])

def cm_enabled():
	default = 'extras,options,playback_options,browse_movie_set,browse_seasons,browse_episodes,recommended,related,more_like_this,similar,anilist_recommended,watch_order,in_trakt_list,' \
				'trakt_manager,anilist_manager,mdblist_manager,simkl_manager,drop_show,personal_manager,tmdb_manager,favorites_manager,mark_watched,unmark_previous_episode,exit,refresh,reload'
	setting = get_setting('deadlight.context_menu.enabled', default)
	if setting in ('', None, 'noop', '[]'): return default.split(',')
	return setting.split(',')

def cm_current_order():
	default = 'extras,options,playback_options,browse_movie_set,browse_seasons,browse_episodes,recommended,related,more_like_this,similar,anilist_recommended,watch_order,' \
				'in_trakt_list,trakt_manager,anilist_manager,mdblist_manager,simkl_manager,drop_show,personal_manager,tmdb_manager,favorites_manager,mark_watched,' \
				'unmark_previous_episode,exit,refresh,reload'
	setting = get_setting('deadlight.context_menu.order', default)
	if setting in ('', None, 'noop', '[]'): return default.split(',')
	# LOCAL PATCH 2026-10-09: an item added after the order was saved (anilist_recommended) goes in after its neighbour in the
	# default order. Without it a new item could be ticked in 'Enable content for the context menu' and still never show:
	# cm_sort_order keeps only items present in BOTH lists.
	order = setting.split(',')
	for prev, item in zip([None] + default.split(','), default.split(',')):
		if item in order: continue
		order.insert(order.index(prev) + 1 if prev in order else len(order), item)
	return order

def cm_sort_order():
	# LOCAL PATCH 2026-10-19: cm_enabled() read once, not per menu item inside the comprehension.
	try:
		enabled = set(cm_enabled())
		setting = {i: c for c, i in enumerate([i for i in cm_current_order() if i in enabled])}
	except: setting = cm_default_order()
	return setting

def cm_default_order():
	return {i: c for c, i in enumerate(default_setting_values('context_menu.order')['setting_default'].split(','))}

def rpdb_info(media_type):
	if media_type == 'extras': active = extras_enable_item_ratings()
	else: active = int(get_setting('deadlight.rpdb_enabled', '0')) in {'movie': (1, 3), 'tvshow': (2, 3)}[media_type]
	if active: return {'rpdb_api_key': get_setting('deadlight.rpdb_api'), 'rpdb_format': get_setting('deadlight.rpdb_format')}
	else: return {'rpdb_api_key': None, 'rpdb_format': None}

def use_season_name():
	return get_setting('deadlight.use_season_name', 'false') == 'true'

def anime_split_cours():
	"""Show anime cours as separate rows in the season list (display only)."""
	return get_setting('deadlight.anime.split_cours', 'true') == 'true'


