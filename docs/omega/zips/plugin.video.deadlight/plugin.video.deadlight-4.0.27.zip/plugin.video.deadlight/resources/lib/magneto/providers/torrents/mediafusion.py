# created by kodifitzwell for Fenomscrapers
"""
	Fenomscrapers Project
"""

from magneto.modules import source_utils
from magneto.modules.provider_base import StremioSource


# LOCAL PATCH 2026-11-01 (cleanup): the sources / sources_packs bodies are provider_base.StremioSource's; this file keeps what
# is mediafusion's own -- its address, the token in the path, and the title-or-description stream text (the default).
class source(StremioSource):
	provider = 'mediafusion'
	base_link = "https://mediafusionfortheweebs.midnightignite.me"
	movieSearch_link = '/%s/stream/movie/%s.json'
	tvSearch_link = '/%s/stream/series/%s:%s:%s.json'
	# LOCAL PATCH 2026-10-06: true_size on packs (pack_true_size, the default), as meteor / torrentsdb / comet -- mediafusion's
	# size is the EPISODE FILE's (all 124 captured streams: size == behaviorHints.videoSize), so dividing it by the season
	# showed The Last of Us S01 Remux at 3.57 GB an episode (32.16 GB file, 225 GB pack). Hidden until 2026-10-06: the
	# class-wide queue handed scrape_check's second show the first show's packs, so these rows were never checked.

	def _search_url(self, data, q):
		if q['tv']: return '%s%s' % (self.base_link, self.tvSearch_link % ((self._token(), q['imdb']) + source_utils.stremio_se(data, q['season'], q['episode'])))   # LOCAL PATCH 2026-10-25 (4.0.5)
		return '%s%s' % (self.base_link, self.movieSearch_link % (self._token(), q['imdb']))

	def _episode_ok(self, file, lines, name, data, q):
		# LOCAL PATCH 2026-11-07 (anime core plan phase 2b): an anime TV row is judged by modules/release_judge with the series rules
		# (found_by 'series_id', as torrentio / meteor since 11-04): asked by IMDb id in Cinemeta's numbering, MediaFusion picks the
		# file -- the judge checks the show, then that file. check_title demanded 'S01E25' / 'S02E01' in the name and refused
		# '[SubsPlease] Tokyo Revengers - 25'-style anime names. Films and shows that are not anime: unchanged.
		if q['tv'] and data.get('is_anime'): return True
		return self._check_title(name, q)

	def _token(self):
		return (
			'D-h5mpsX35oygOGFiHutl66dLAPiXzjQTODPXKQuKBaQOLjwNBbVkSPi7TJPr0gdykpCFREq8JOh'
			'DHZcvoS_UNZsWpsbjscCAwzgqc9VvP0S3Wt9lz5blcPT8lU6fcHdAHYctp_yde6nWKtSQ1O9Tjeh'
			'GNwajH9TjGZwn6rOybPFmoMpccXfTkB3Xwe9xRhT9O-bKzoYnGnlG8fCDxlNGdzrnlythePc3C7O'
			'phF8b5GyhuSnvBhxD7dTfkI77Dbay8_k_wqS-me9euZQ-oyOJBNTOIsO8HiWQhLGCC8m9rYsqJT6'
			'QF1Xhn-2bNzlukfbSYh_X1kOFdi6Y-YkBeEYokDlQHzzU45qmrj2b1Nz-GALcJHjNDJEMF3h9Eyx'
			'7UcmGWT1qvTpv_tcXjAX37ceqrWH-e_EqwVkvQDjNnmpjOhBWhuUW2R-0KbvxKUn1s5d2jZjLBxC'
			'bMotHIC-G2SrVCLgC_KV0OUainevUHKOKTe0CQmWz1HKV1ju52CFZFZYAWkOAX5cw55qzNnWl_nQ'
			'RnLyngrW_P6aYqghbYyyrAvQ6hCrIbSnVj4GsMFIelcMETvGW4jIXdwZGZA1L8gCzmyCbI9vAqPv'
			'dZxRWb7roc2EnB7gaSYdFtTP9gGoFKKkQ-9aircUEiPXjkP4QWO7lVI4GZri7KKCKjBM7-hWf4nm'
			'ttY7lJS_4Te_H80BeR_qpqeYQ6V0gpVwihARA6cIsZFbWmQXtoYNO16jt1ZqeVztwR6L1IQQnAsH'
			'ANyR5kF7ovGCOnhWlDDxO3nk8fhm3s0k7XewrMisZHy1zNsivTjvJW6KoVwghLn8-QCTf9PEPoPj'
			's6tW5KjciaRvbMg5-mbhpAhYOmPisB4ZyW63vWY6TeU1OBJV0T_fkHtgbvgiTEX5RFoRVDLnhaof'
			'-xHVw2oCc2AdXmBDVROmFjY8x9KEyZ91QfNjHnrTFmGetelcHE'
		)
