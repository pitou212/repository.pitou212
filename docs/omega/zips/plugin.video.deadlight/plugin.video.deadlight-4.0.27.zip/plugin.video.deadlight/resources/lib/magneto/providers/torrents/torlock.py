# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-10-21: torlock -- Torlock's torznab API (www.torlock.com/torznab/api), searched by NAME. Ported from
	POV 6.10.17 (magneto upstream is no longer maintained; POV is the source now) and laid out like knaben.py.

	The torlock tested on 2026-09-28 scraped torlock2.com's HTML (reachable, not bundled). POV moved it to this API.
	Tested 2026-10-21 from this PC: 3/3 answers; Reacher S02E01 33 rows -- 25 that Torrentio lacks, all of them S02E01,
	17 seeded (NTb 1080p AMZN, FLUX 2160p DV, ELiTE / MeGusta x265) -- and Oppenheimer 100 rows, 39 Torrentio lacks.
	On by default (user's call), unlike the other name-search providers.

	API: /torznab/api?t=<tvsearch|movie>&q=<query>   No key. RSS/torznab XML: <item><title>, <size> (bytes) and
	<torznab:attr name="infohash|seeders|..." value="..."/>. Parsed with the standard library as bitmagnet.py does --
	it resolves no external entities, and Kodi's expat caps entity expansion.
	LOCAL PATCH 2026-11-01 (cleanup): the bodies are provider_base.NameSearchSource's.
"""

import xml.etree.ElementTree as ET
from urllib.parse import quote_plus
from magneto.modules.provider_base import NameSearchSource

_TORZNAB = '{http://torznab.com/schemas/2015/feed}attr'


class source(NameSearchSource):
	provider = 'torlock'
	base_link = 'https://www.torlock.com'
	search_link = '/torznab/api?t=%s&q=%s'
	request_timeout = 7
	movie_category, tv_category = 'movie', 'tvsearch'
	name_key, hash_key = 'title', 'infohash'

	def _url(self, category, query):
		return '%s%s' % (self.base_link, self.search_link % (category, quote_plus(query)))

	def _rows(self, results):
		"""torlock's rows as {'title', 'size', 'infohash', 'seeders', ...}"""
		if '<!DOCTYPE' in results[:2048].upper(): return []   # a torznab feed never declares one; refuse any entity declarations
		rows = []
		for item in ET.fromstring(results).iter('item'):
			try:
				row = {'title': item.findtext('title') or '', 'size': item.findtext('size')}
				for attr in item.findall(_TORZNAB):
					if attr.get('name'): row[attr.get('name')] = attr.get('value')
				rows.append(row)
			except: continue
		return rows

	def _valid(self, row, hash):
		return len(hash) == 40 and bool(row['title'])
