# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-09-29: Torrents-CSV -- torrents-csv.com's open search API, searched by NAME. The second indexer
	beside apibay (PirateBay).

	Timed 2026-09-29: 0.45-0.62 s per query. A SMALL index: Reacher S02E01 7 rows, Reacher S02 11, Oppenheimer 25,
	Monster: The Lizzie Borden Story none. Off by default; worth it only as a backup to PirateBay.

	API: https://torrents-csv.com/service/search?q=<query>&size=100   No key. JSON {'torrents': [...], 'next': id}:
	  {'infohash' (lower case), 'name', 'size_bytes' (int), 'seeders', 'leechers', 'created_unix', ...}
	No hits is an empty list. No category field, so non-video rows fall to check_title like torrentdownload's.

	Laid out like apibay.py (episode / season-pack / show-pack queries, the pack ones in parallel threads), using
	client.request so the loading window's ok / failed tally sees it. LOCAL PATCH 2026-11-01 (cleanup): the bodies are
	provider_base.NameSearchSource's.
"""

import json
from magneto.modules.provider_base import NameSearchSource


class source(NameSearchSource):
	provider = 'torrentscsv'
	base_link = 'https://torrents-csv.com'
	search_link = '/service/search?q=%s&size=100'
	hash_key, size_key = 'infohash', 'size_bytes'

	def _rows(self, results):
		return json.loads(results).get('torrents') or []
