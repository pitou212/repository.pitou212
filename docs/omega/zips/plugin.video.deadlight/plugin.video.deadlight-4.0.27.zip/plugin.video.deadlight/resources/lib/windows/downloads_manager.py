# -*- coding: utf-8 -*-
import json
from threading import Thread
from windows.base_window import BaseDialog
from modules.kodi_utils import select_dialog, confirm_dialog, ok_dialog, execute_builtin, delete_file
from modules import completed_downloads

class DownloadsManager(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.window_id = 2500
		self.closed = False
		self.position = 0
		self.active_downloads, self.active_queued_downloads, self.active_item_list, self.queued_item_list, self.item_list = [], [], [], [], []
		self.completed_item_list = []

	def onInit(self):
		self.make_active_downloads(first_run=True)
		if self.item_list: self.ensure_focus(self.window_id)   # LOCAL PATCH 2026-11-07: see base_window.ensure_focus
		self.monitor()

	def run(self):
		self.doModal()
		self.clearProperties()

	def onAction(self, action):
		if action in self.closing_actions:
			self.closed = True
			return self.close()
		else:
			if action in self.selection_actions: return self.set_status(self.get_listitem(self.window_id))

	def make_active_downloads(self, first_run=False):
		def queued_builder():
			for item in self.active_queued_downloads:
				try:
					listitem = self.make_listitem()
					listitem.setProperty('name', item.replace('.', ' ').replace('_', ' '))
					listitem.setProperty('item_id', item)
					listitem.setProperty('percent', '0')
					listitem.setProperty('status', 'queued')
					self.set_row_display(listitem)
					yield listitem
				except: pass
		def builder():
			for item in self.active_downloads:
				try:
					listitem = self.make_listitem()
					listitem.setProperty('name', item.replace('.', ' ').replace('_', ' '))
					listitem.setProperty('item_id', item)
					listitem.setProperty('percent', self.get_home_property(item))
					listitem.setProperty('status', self.get_status(item))
					self.set_row_display(listitem)
					yield listitem
				except: pass
		def completed_builder():
			# LOCAL PATCH 2026-11-08: finished downloads under the active ones (modules/completed_downloads), newest first
			for record in completed_downloads.load():
				try:
					listitem = self.make_listitem()
					listitem.setProperty('name', record['name'])
					listitem.setProperty('item_id', record['path'])
					listitem.setProperty('status', 'completed')
					listitem.setProperty('detail', completed_downloads.detail(record))
					self.set_row_display(listitem)
					yield listitem
				except: pass
		try:
			self.active_downloads = json.loads(self.get_home_property('active_downloads') or '[]')
			self.active_item_list = list(builder())
			self.active_queued_downloads = json.loads(self.get_home_property('active_queued_downloads') or '[]')
			self.queued_item_list = list(queued_builder())
			self.completed_item_list = list(completed_builder())
			self.item_list = self.active_item_list + self.queued_item_list + self.completed_item_list
			self.set_summary()
			self.add_items(self.window_id, self.item_list)
			if first_run: self.setFocusId(self.window_id)
			else: self.select_item(self.window_id, self.position)
		except: pass

	def set_summary(self):
		# LOCAL PATCH 2026-11-07: the header counts ('1 active  •  1 paused  •  1 queued'), or 'Nothing downloading'
		paused = len([i for i in self.active_item_list if i.getProperty('status') == 'paused'])
		running = len(self.active_item_list) - paused
		parts = [('%d active' % running) if running else '', ('%d paused' % paused) if paused else '',
				 ('%d queued' % len(self.queued_item_list)) if self.queued_item_list else '']
		summary = '  •  '.join(p for p in parts if p) or 'Nothing downloading'
		if self.completed_item_list: summary += '  •  %d completed' % len(self.completed_item_list)
		self.setProperty('summary', summary)

	def set_row_display(self, listitem):
		# LOCAL PATCH 2026-11-07: round-2 redesign -- a status tag and a bar texture (deadlight_common/bar/bar_005..100.png, the
		# sources window's) per row; the downloader reports percent and status only
		status = listitem.getProperty('status')
		if status == 'completed':   # its detail (size  •  when  •  folder) is set by completed_builder; no bar
			listitem.setProperty('status_label', 'Done')
			listitem.setProperty('bar', '')
			return
		try: percent = max(0, min(100, int(float(listitem.getProperty('percent') or 0))))
		except: percent = 0
		label = {'paused': 'Paused', 'queued': 'Queued', 'cancelled': 'Cancelling'}.get(status, 'Downloading')
		listitem.setProperty('status_label', label)
		listitem.setProperty('bar', 'deadlight_common/bar/bar_%03d.png' % max(5, int(round(percent / 5.0)) * 5) if percent else '')
		listitem.setProperty('detail', '%d%%' % percent if status != 'queued' else 'waiting')

	def get_status(self, item_id):
		return self.get_home_property('download_status.%s' % item_id)

	def completed_options(self, list_item):
		# LOCAL PATCH 2026-11-08: OK on a finished download
		path, name = list_item.getProperty('item_id'), list_item.getProperty('name')
		choices = [('Play', 'play'), ('Delete File', 'delete'), ('Remove from List', 'remove'), ('Full Filename', 'filename')]
		kwargs = {'items': json.dumps([{'line1': i[0]} for i in choices]), 'narrow_window': 'true', 'heading': name}
		choice = select_dialog([i[1] for i in choices], **kwargs)
		if choice is None: return
		if choice == 'filename': return ok_dialog(text=path)
		if choice == 'play':
			self.closed = True
			self.close()
			return execute_builtin('PlayMedia("%s")' % path)
		if choice == 'delete':
			if not confirm_dialog(heading=name, text='Delete this file from disk?'): return
			delete_file(path)
			completed_downloads.remove_empty_folders(path)
		completed_downloads.remove(path)
		self.rebuild()

	def rebuild(self):
		self.position = self.get_position(self.window_id)
		self.reset_window(self.window_id)
		self.make_active_downloads()
		if self.item_list: self.setFocusId(self.window_id)

	def set_status(self, list_item):
		if list_item.getProperty('status') == 'completed': return self.completed_options(list_item)
		choices = []
		item_id = list_item.getProperty('item_id')
		status = self.get_status(item_id)
		if status == 'queued': choices.append(('Full Filename', 'filename'))
		elif status == 'paused': choices.append(('Resume Download', 'unpaused'))
		else: choices.append(('Pause Download', 'paused'))
		choices.append(('Cancel Download', 'cancelled'))
		choices.append(('Full Filename', 'filename'))
		list_items = [{'line1': i[0]} for i in choices]
		kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true', 'heading': list_item.getProperty('name')}
		status_choice = select_dialog([i[1] for i in choices], **kwargs)
		if status_choice == None: return
		if status_choice == 'filename': return ok_dialog(text=list_item.getProperty('name'))
		if status_choice == 'cancelled' and not confirm_dialog(): return
		return self.set_home_property('download_status.%s' % item_id, status_choice)

	def monitor(self):
		# LOCAL PATCH 2026-11-07: (1) this loop ran inside onInit, and Kodi runs a window's callbacks one at a time -- while a
		# download was active onAction never ran, so OK (pause / resume / cancel) did nothing; it runs in a thread now.
		# (2) every 2.5 s the list was reset and rebuilt, which also dropped its focus. The rows are updated in place now;
		# the list is rebuilt only when the set of downloads changes, and keeps its focus.
		def _loop():
			while not self.closed:
				self.sleep(2500)
				if self.closed: break
				try: self.refresh()
				except Exception: pass
				if not (self.active_item_list or self.queued_item_list): break   # finished rows do not change
		Thread(target=_loop).start()

	def refresh(self):
		active = json.loads(self.get_home_property('active_downloads') or '[]')
		queued = json.loads(self.get_home_property('active_queued_downloads') or '[]')
		if active == self.active_downloads and queued == self.active_queued_downloads:
			for listitem in self.active_item_list:
				item = listitem.getProperty('item_id')
				listitem.setProperty('percent', self.get_home_property(item))
				listitem.setProperty('status', self.get_status(item))
				self.set_row_display(listitem)
			self.set_summary()
			return
		had_focus = self.getFocusId() == self.window_id
		self.position = self.get_position(self.window_id)
		self.reset_window(self.window_id)
		self.make_active_downloads()
		if had_focus and self.item_list:
			try: self.setFocusId(self.window_id)
			except Exception: pass
