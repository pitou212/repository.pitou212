# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-09-25: nekoBT provider -- anime torrents, keyed on the TVDB id.
#
# nekobt.to maps its torrents to TVDB episodes: every torrent carries `media_episode_ids`, the tracker's ids of the
# episodes it contains, so whether a pack holds the episode is a lookup, not a guess from its name.
# Ported from Otaku (plugin.video.otaku.testing pages/nekobt.py) but not its request flow: Otaku searches by TITLE
# and takes the first hit when no TVDB id matches (a wrong show, silently); here DeadLight's data['tvdb'] is used.
#
# THE REQUEST (no API key): /torrents/search?media_id=tvdb-<id>&query=SxxEyy, ~1.2-1.7 s, returns singles AND packs
# in one call. Hence pack_capable = False: sources() files each row by its episode count.
#
# Traps, each handled below:
#   1. The hint is in TVDB numbering, and a hint the tracker cannot place is IGNORED, not failed (it returns the
#      show's newest 100 torrents). So the episode is mapped through the tracker's own episode list first, and every
#      row is kept only if its media_episode_ids holds the wanted episode.
#   2. Rows with NO episodes (films, specials) pass any hint; the episode-id check drops them.
#   3. `batch` is not the pack flag ('One Piece E0001-E1155' is batch=False); the episode count is.
# Also: /media/tvdb-<id> is a 404 despite the docs; /media/resolve?id=tvdb-<id> works. Burst limit: 429 at ~40
# requests/minute, clears in seconds; a scrape makes 1 request (3 on a show's first play).

import re
import threading

from magneto.modules import cache
from magneto.modules import client
from magneto.modules import source_utils

try:
	import json as _json
except ImportError:
	_json = None

_BASE = 'https://nekobt.to/api/v1'
_SEARCH = _BASE + '/torrents/search?media_id=tvdb-%s&query=%s&sort_by=seeders&limit=100' \
	'&group_secondary=true&group_parents=true&uploader_contributions=true'
# LOCAL PATCH 2026-10-27: the untagged-mode search, by the cour's AniList id and its episode number (AniList
# numbering). Where the TVDB mapping misses (One Piece 1180), the TVDB hint cannot be placed and returns the newest
# 100; anilist-<id> + the number returns that episode's rows. The TVDB search runs only if this finds nothing. Not the
# default: AniList ids found nothing for some shows (Mushoku Tensei S2) in any form.
_SEARCH_ANILIST = _BASE + '/torrents/search?media_id=anilist-%s&query=%s&sort_by=seeders&limit=100' \
	'&group_secondary=true&group_parents=true&uploader_contributions=true'

_TRACKERS = (
	'https://tracker.nekobt.to/api/tracker/public/announce',
	'http://nyaa.tracker.wf:7777/announce',
	'udp://tracker.opentrackr.org:1337/announce',
	'udp://open.stealth.si:80/announce',
	'udp://tracker.torrent.eu.org:451/announce',
)

# nekoBT appends its own tag block to every title: '... [AV1] {Tags:L2;V12;C3;A=ja,en;F=en;}'.
_TAGS = re.compile(r'\s*\{Tags:[^}]*\}\s*$', re.I)


# Search timeout: 5 s clears normal 1.2-3.5 s searches and still lands inside DeadLight's results window (10 s let a
# stalled search hold the whole scrape). The episode list keeps 10 s: it is cached a week and One Piece's takes 4.4 s.
_SEARCH_TIMEOUT = 5


# 2026-09-26: set when a request got NO response (timeout, connection error, 5xx), as opposed to an answer that says
# "unknown". Thread-local: episode and pack scrapes run in parallel.
_transport = threading.local()

def _get(url, timeout=10):
	# LOCAL PATCH 2026-10-09: ignoreErrors=404 -- a show nekoBT does not carry answers 404 {"error":true,"message":"No
	# media found for that external ID."}. That is an answer, not an outage (client.request returns None for it); the
	# JSON error payload is handled just below.
	response = client.request(url, timeout=timeout, ignoreErrors=404)
	if not response:
		_transport.failed = True
		return None
	payload = _json.loads(response)
	if not isinstance(payload, dict) or payload.get('error'): return None
	return payload.get('data')


# LOCAL PATCH 2026-10-27: rows carry nekoBT's own absolute number (4th field). The cache key includes _LIST_VERSION, so
# lists cached in the old 3-field shape are fetched again once instead of being read without it.
_LIST_VERSION = 2

def _episode_list(tvdb, version=None):
	"""{'media_id', 'eps': [[season, episode, id, absolute or None], ...]} for a TVDB series in (season, episode)
	order, specials (season 0) included. Cached per show by the caller; None is never cached. `version` only keys the
	cache (_LIST_VERSION)."""
	resolved = _get(_BASE + '/media/resolve?id=tvdb-%s' % tvdb) or {}
	media_id = resolved.get('media_id')
	if not media_id: return None
	media = _get(_BASE + '/media/%s' % media_id) or {}
	eps = sorted([int(e['season']), int(e['episode']), int(e['id']), _abs_of(e)]
			for e in (media.get('episodes') or [])
			# LOCAL PATCH 2026-09-27: season 0 too, so a special can be answered by its own entry (see _wanted_episode).
			if isinstance(e, dict) and e.get('season') is not None and e.get('episode') is not None and e.get('id'))
	if not eps: return None
	return {'media_id': media_id, 'eps': eps}


def _abs_of(episode):
	try: return int(episode.get('absolute')) or None
	except (TypeError, ValueError): return None


def _episode_list_recheck(tvdb, version=None):
	"""_episode_list under its own cache key (6 h): the re-fetch for an episode the week-old list lacks."""
	return _episode_list(tvdb)


def _wanted_episode(eps, data):
	"""The [season, episode, id] row of `eps` DeadLight is asking for, or None.
	
	Tried in order, first hit wins:
	  1. Fribb's TVDB coordinates (cour_season, season_episode) -- the numbering releases and
	     TVDB use, set when it differs from TMDb's (Re:ZERO files every cour under TMDb S1).
	  2. TMDb's own (season, episode) -- the same as TVDB's for most shows.
	  3. The series-absolute number against nekoBT's own `absolute` field (LOCAL PATCH 2026-10-27) -- regular
	     episodes first, then specials. Not by POSITION: TVDB files some absolute episodes as specials (One Piece's 590
	     is S0E39), so positions drift one ahead from there.
	  4. The same number as a position in the regular-episode list, only for a list with no absolute numbers.
	Only reached when 1 and 2 are not pairs the list holds, so it cannot override them.
	"""
	def _int(key):
		try: return int(data.get(key))
		except (TypeError, ValueError): return None
	by_pair = {(row[0], row[1]): row for row in eps}
	for pair in ((_int('cour_season'), _int('season_episode')), (_int('season'), _int('episode'))):
		# LOCAL PATCH 2026-09-27: `is not None`, not truthiness -- season 0 is falsy, so a special's own pair was never
		# looked up and it fell to the absolute branch (S0E2 became S01E02).
		if pair[0] is not None and pair[1] is not None and pair in by_pair: return by_pair[pair]
	# A special is answered by its own (0, n) or not at all: absolute numbering counts regular episodes only.
	if _int('season') == 0: return None
	regular = [row for row in eps if row[0] > 0]
	absolute = _int('absolute_episode') or _int('episode')
	if not absolute: return None
	numbered = [row for row in eps if len(row) > 3 and row[3]]
	if numbered:
		hit = next((row for row in numbered if row[0] > 0 and row[3] == absolute), None)
		return hit or next((row for row in numbered if row[3] == absolute), None)
	if 1 <= absolute <= len(regular): return regular[absolute - 1]
	return None


def _untagged_names_episode(title, data):
	"""LOCAL PATCH 2026-10-05: for a row nekoBT has attached to no episode (untagged mode in sources): True only if its NAME
	is this one single episode. With a season in the name, that season must be TMDb's or the release season and the episode
	TMDb's, season-relative or cour-relative ('Black Clover S02E01', 'Black Clover 2nd Season - 01'); with none, the number
	must be the series-absolute one ('Black Clover - 171'). Ranges and packs never pass. A lower season is NOT trusted
	here, unlike anime_utils.cour_match: without nekoBT's mapping the name is all there is, and 'S01E01' is season 1."""
	try:
		from magneto.modules import anime_utils as au
		cleaned = au._clean_for_extract(source_utils.clean_name(title))
		seasons, episodes, _parts, is_range = au._extract_meta(cleaned)
		if is_range or (episodes and len(episodes) != 1): return False
		if episodes: episode = next(iter(episodes))
		else: episode = au._title_anchored_episode(cleaned, [data.get('tvshowtitle') or ''] + au.alias_titles(data))
		if episode is None: return False
		def _ints(*keys):
			out = set()
			for key in keys:
				try: out.add(int(data.get(key)))
				except (TypeError, ValueError): pass
			return out
		if seasons: return bool(seasons & _ints('season', 'cour_season')) and int(episode) in _ints('episode', 'season_episode', 'cour_episode')
		return int(episode) in _ints('absolute_episode')
	except Exception:
		return False


class source:
	# One request returns singles and packs together; see the header.
	pack_capable = False
	hasMovies = False
	hasEpisodes = True

	def __init__(self):
		self.base_link = 'https://nekobt.to'
		# Set when the search itself failed (timeout, 5xx, error payload) rather than found nothing. DeadLight's
		# external.py reads it and does not cache the empty result.
		self.request_failed = False

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		tvdb = str(data.get('tvdb') or '').strip()
		if not tvdb.isdigit() or tvdb == '0': return sources
		_transport.failed = False
		try:
			# A week: a new episode missing from the list triggers the refetch below, so only a TVDB renumbering waits it out.
			# The list is the slow part (One Piece's 1179 episodes: 4.4 s + 1.1 s resolve).
			listing = cache.get(_episode_list, 168, tvdb, _LIST_VERSION)
			wanted = _wanted_episode(listing['eps'], data) if listing else None
			# A cached list predates an episode that aired since -- refetch, at most every 6 h per show.
			# LOCAL PATCH 2026-10-18: not on every scrape -- two requests (5.5 s for One Piece) each time put the search past
			# DeadLight's window and spent the ~40 requests/minute burst limit.
			if listing and not wanted:
				listing = cache.get(_episode_list_recheck, 6, tvdb, _LIST_VERSION) or listing
				wanted = _wanted_episode(listing['eps'], data) if listing else None
			# LOCAL PATCH 2026-10-05: nekoBT knows the show but not this episode yet -- new releases can sit under the show
			# attached to NO episode (media_episode_ids empty). Search anyway in 'untagged' mode: see _untagged_names_episode.
			untagged = bool(listing) and not wanted
			if not wanted and not untagged:
				# 2026-09-26: no listing because nekoBT did not ANSWER is an outage, not "show not on nekoBT" -- flag it so the
				# empty result is not cached.
				if not listing and getattr(_transport, 'failed', False): self.request_failed = True
				import xbmc as _x
				_x.log('NEKOBT: no episode for tvdb=%s S%sE%s (abs %s) -- skipped%s'
					% (tvdb, data.get('season'), data.get('episode'), data.get('absolute_episode'),
					' (episode list FAILED, not cached)' if self.request_failed else ''), _x.LOGINFO)
				return sources
			if untagged: wanted = (int(data.get('season') or 0), int(data.get('episode') or 0), None)
			season_of = dict((str(row[2]), row[0]) for row in listing['eps'])
			found, via_anilist = None, False
			if untagged and str(data.get('anilist_id') or '').isdigit() and str(data.get('cour_episode') or '').isdigit():
				found = _get(_SEARCH_ANILIST % (data['anilist_id'], int(data['cour_episode'])), timeout=_SEARCH_TIMEOUT)
				via_anilist = bool((found or {}).get('results'))
			if not via_anilist:
				found = _get(_SEARCH % (tvdb, 'S%02dE%02d' % (wanted[0], wanted[1])), timeout=_SEARCH_TIMEOUT)
			if found is None: self.request_failed = True
			rows = (found or {}).get('results') or []
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			self.request_failed = True
			source_utils.scraper_error('NEKOBT')
			return sources

		wanted_id, seen, dropped = str(wanted[2]), set(), 0
		for row in rows:
			try:
				eids = [str(i) for i in (row.get('media_episode_ids') or [])]
				# THE check: the tracker's own mapping says this torrent holds the episode.
				if untagged:
					# a row nekoBT attached to some episode is, by its own mapping, not this one (the 2017 run's
					# 'S02E01' Blu-rays are attached to its episode 52); an unattached one must NAME this episode
					# LOCAL PATCH 2026-10-27: via AniList the attachment is to THIS episode (our TVDB mapping is what
					# missed it), so the name alone decides
					if (eids and not via_anilist) or not _untagged_names_episode(_TAGS.sub('', row.get('title') or ''), data):
						dropped += 1
						continue
				elif wanted_id not in eids:
					dropped += 1
					continue
				info_hash = (row.get('infohash') or '').lower()
				if len(info_hash) != 40 or info_hash in seen: continue
				package = None
				if len(eids) > 1:
					package = 'season' if len(set(season_of.get(i) for i in eids)) == 1 else 'show'
				raw = _TAGS.sub('', row.get('title') or '')
				name = source_utils.clean_name(raw)
				if not name: continue
				name_info = source_utils.info_from_name(
					name, data.get('tvshowtitle') or '', str(data.get('year') or ''),
					season=str(data.get('season') or ''), pack=package)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue
				try: seeders = max(int(row.get('seeders') or 0), 0)
				except (TypeError, ValueError): seeders = 0
				magnet = 'magnet:?xt=urn:btih:%s&dn=%s%s' % (info_hash, name, ''.join('&tr=%s' % t for t in _TRACKERS))
				quality, info = source_utils.get_release_quality(name_info, magnet)
				# Per-episode size from the pack's OWN episode count, so nekobt is in DeadLight's no-divide list (TMDb's
				# episode_count is unrelated to what an anime pack holds).
				try: total = float(row.get('filesize') or 0) / 1073741824
				except (TypeError, ValueError): total = 0
				dsize = round(total / max(len(eids), 1), 2)
				if dsize: info.insert(0, '%.2f GB' % dsize)
				if package and total: info.append('%.1f GB pack' % total)
				seen.add(info_hash)
				item = {'provider': 'nekobt', 'source': 'torrent', 'seeders': seeders,
						'hash': info_hash, 'name': name, 'name_info': name_info, 'quality': quality,
						'language': 'en', 'url': magnet, 'info': ' | '.join(info), 'direct': False,
						'debridonly': True, 'size': dsize}
				group = source_utils.release_group(raw)
				if group: item['release_group'] = group
				if package: item['package'] = package
				sources.append(item)
			except Exception:
				source_utils.scraper_error('NEKOBT')
				continue
		try:
			import xbmc as _x
			_x.log('NEKOBT: tvdb=%s asked S%sE%s -> nekoBT S%02dE%02d (id %s): %d rows, %d not holding it, %d kept%s'
				% (tvdb, data.get('season'), data.get('episode'), wanted[0], wanted[1],
				('none yet -- untagged rows named for it' + (', searched by anilist-%s ep %s' % (data.get('anilist_id'),
				data.get('cour_episode')) if via_anilist else '')) if untagged else wanted_id,
				len(rows), dropped, len(sources), ' (search FAILED, not cached)' if self.request_failed else ''), _x.LOGINFO)
		except Exception: pass
		return sources
