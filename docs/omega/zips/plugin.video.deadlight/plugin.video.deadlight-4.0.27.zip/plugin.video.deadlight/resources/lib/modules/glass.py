# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-24: adaptive glass. TMDbHelper's blurred artwork runs from black to white (2,548 cached blurs here:
# median 35 percent, a quarter above 51), so no fixed tint suits them all -- 20 percent left Tenzing's snow a white haze
# under white text, 55 percent made a night scene black. The blur's mean brightness is measured once (Pillow, a 32x18
# thumbnail) and a black layer just strong enough to bring it to a target brightness is used instead. DeadLight's windows
# call dim() when they open (windows/base_window.set_glass). service.GlassMonitor published it for AF3's glass too (Home
# property deadlight.glass.dim) until 2026-11-08; now it only measures, and AF3 keeps its own tint (user: the two independent).
import xbmcvfs

TARGET_PANELS = 0.24   # behind windows whose text sits on a panel (dialogs, settings, AF3's glass)
TARGET_TEXT = 0.16     # behind windows whose text sits on the background itself (scraping screen, extras, people)
_MIN_DIM, _MAX_DIM = 0.12, 0.85
_cache = {}
# LOCAL PATCH 2026-10-25: the last measurement, shared across processes as 'path|value'. service.GlassMonitor measures
# the blur AF3 shows as focus moves; a DeadLight window opening over it then reads the same image's value here instead of
# importing Pillow in its own plugin process (~0.11 s import + 8 ms, before the scraping window appeared).
_SHARED_PROP = 'deadlight.glass.lum'


def _home():
	import xbmcgui
	return xbmcgui.Window(10000)


def luminance(path):
	"""Mean brightness 0..1 of an image file (special:// or a local path), None when it cannot be read."""
	if not path: return None
	if path in _cache:
		# republished: GlassMonitor going back to an image it measured before must leave it as the shared one
		if _cache[path] is not None:
			try: _home().setProperty(_SHARED_PROP, '%s|%.4f' % (path, _cache[path]))
			except Exception: pass
		return _cache[path]
	try:
		shared_path, _, shared_value = _home().getProperty(_SHARED_PROP).rpartition('|')
		if shared_path == path and shared_value:
			_cache[path] = float(shared_value)
			return _cache[path]
	except Exception: pass
	value = None
	try:
		from PIL import Image, ImageStat
		with Image.open(xbmcvfs.translatePath(path)) as im:
			value = ImageStat.Stat(im.convert('L').resize((32, 18))).mean[0] / 255.0
	except Exception: pass
	if len(_cache) > 500: _cache.clear()
	_cache[path] = value
	if value is not None:
		try: _home().setProperty(_SHARED_PROP, '%s|%.4f' % (path, value))
		except Exception: pass
	return value


def dim(path, target=TARGET_PANELS):
	"""The black layer's opacity 0..1 that brings the image's brightness to target (never less than _MIN_DIM, so even a
	dark backdrop sits a step behind the panels; None when the image cannot be read)."""
	lum = luminance(path)
	if lum is None: return None
	if lum <= 0: return _MIN_DIM
	return max(_MIN_DIM, min(_MAX_DIM, 1.0 - target / lum))


def black(opacity):
	"""A Kodi colour: black at this opacity (0..1)."""
	return '%02X000000' % int(round(opacity * 255))


def grey(opacity):
	"""A Kodi colordiffuse that darkens what it is put on as a black layer of this opacity would."""
	v = int(round((1.0 - opacity) * 255))
	return 'FF%02X%02X%02X' % (v, v, v)
