# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-11-08: filler / recap episodes of anime, from MyAnimeList's per-episode flags (apis/tenrai_api.episode_flags).
# A TMDb episode is found on MAL by its Fribb cour (cour's MAL entry, cour-relative number: Frieren TMDb S1E30 = MAL 59978
# ep 2), else -- long single-entry shows -- by the show's one main Fribb row (not a film, not season 0) and the
# series-absolute number (One Piece S4E100 = MAL 21 ep 100). Specials and anything else are left unmarked.
# Lists read flags from cache only and queue missing MAL entries for after the list is on screen (flush_pending, not on
# widget calls). Skip filler may fetch (once per next-episode decision); a show without flags is simply not skipped.

from modules.settings import anime_filler_marks, anime_skip_filler

_PENDING = set()
_ENTRY_MEMO = {}
_FLAGS_MEMO = {}
_MARKS_ON = [None]
_LABELS = {'filler': 'Filler', 'recap': 'Recap'}
_MARK_COLOUR = 'FFE0AA46'


def _main_entry(tmdb_id):
	"""The MAL id of a show's one main Fribb row (not a film, not season 0), or None when there is not exactly one."""
	from caches.fribb_mappings import tmdb_tv_to_fribb_rows
	mains = set()
	for row in tmdb_tv_to_fribb_rows(tmdb_id):
		if row.get('type') == 'MOVIE': continue
		season = row.get('season') or {}
		if season and str(season.get('tmdb')) == '0': continue
		if row.get('mal_id'): mains.add(int(row['mal_id']))
	return mains.pop() if len(mains) == 1 else None


def entry_for(meta, season, episode):
	"""(mal_id, mal_episode) for a TMDb anime episode, or (None, None)."""
	try:
		tmdb_id, season, episode = int(meta.get('tmdb_id')), int(season), int(episode)
		if season <= 0 or episode <= 0: return None, None
	except (TypeError, ValueError, AttributeError): return None, None
	key = (tmdb_id, season, episode)
	if key in _ENTRY_MEMO: return _ENTRY_MEMO[key]
	answer = (None, None)
	try:
		from caches.fribb_mappings import find_cour_by_tmdb_coords
		from modules.metadata import series_absolute_episode
		main = _main_entry(tmdb_id)
		cour = find_cour_by_tmdb_coords(tmdb_id, season, episode) or {}
		# the show's one main MAL entry runs across TMDb's seasons, so its number is the series-absolute one, not Fribb's
		# per-season cour_ep (Naruto Shippuden TMDb S3E4 is MAL 1735 ep 57). A cour that is its own MAL entry keeps cour_ep.
		if cour.get('mal') and cour.get('cour_ep') and int(cour['mal']) != main: answer = (int(cour['mal']), int(cour['cour_ep']))
		elif main:
			absolute = series_absolute_episode(meta, season, episode)
			if absolute: answer = (main, int(absolute))
	except Exception: pass
	_ENTRY_MEMO[key] = answer
	return answer


def kind_of(flags, mal_episode):
	if not flags or not mal_episode: return None
	if mal_episode in (flags.get('filler') or ()): return 'filler'
	if mal_episode in (flags.get('recap') or ()): return 'recap'
	return None


def episode_kind(meta, season, episode, fetch=False):
	"""'filler', 'recap' or None for a TMDb anime episode. fetch=False reads stored flags only and queues a missing entry."""
	mal_id, mal_ep = entry_for(meta, season, episode)
	if not mal_id: return None
	flags = _FLAGS_MEMO.get(mal_id)
	if flags is None:
		from apis import tenrai_api
		flags = tenrai_api.episode_flags(mal_id) if fetch else tenrai_api.cached_episode_flags(mal_id)
		if flags is None:
			if not fetch: _PENDING.add(mal_id)
			return None
		# held for the process as sets: a list asks once per row
		flags = _FLAGS_MEMO[mal_id] = {'filler': frozenset(flags.get('filler') or ()), 'recap': frozenset(flags.get('recap') or ())}
	return kind_of(flags, mal_ep)


def mark(meta, season, episode, display):
	"""The episode title with ' . Filler' / ' . Recap' after it when the Mark filler setting is on (stored flags only)."""
	try:
		if _MARKS_ON[0] is None: _MARKS_ON[0] = anime_filler_marks()   # once per process, not per row
		if not _MARKS_ON[0]: return display
		from modules.metadata import is_anime_check
		if not is_anime_check(meta): return display
		kind = episode_kind(meta, season, episode)
		if not kind: return display
		return '%s  [COLOR %s]· %s[/COLOR]' % (display, _MARK_COLOUR, _LABELS[kind])
	except Exception: return display


def _tmdb_after(meta, season, episode, seasons):
	"""The TMDb episode after (season, episode) as TMDb numbers them: the next number in the season's own episode list, else
	the first of the next season. Not watched_status.get_next: it reads a number above every season's count as absolute and
	remaps it, which is wrong for shows that keep series numbers inside each season (Naruto S2 is 53-104)."""
	from modules.metadata import episodes_meta
	while season is not None:
		if season not in seasons: seasons[season] = sorted(i['episode'] for i in (episodes_meta(season, meta) or []) if i.get('episode'))
		later = [n for n in seasons[season] if n > episode]
		if later: return season, later[0]
		listed = [i.get('season_number') for i in (meta.get('season_data') or []) if (i.get('season_number') or 0) > season]
		if not listed: return None, None
		season, episode = min(listed), 0
	return None, None


def skip_ahead(meta, season, episode, next_of=None, fetch=True):
	"""The first episode at or after (season, episode) that Skip filler does not skip, stepping through TMDb's own episode
	lists (_tmdb_after; next_of is no longer used). Off, not anime, or no flags: (season, episode) unchanged. At most 400
	steps. fetch=False (list builds): stored flags only -- a long show's first fetch is many paced requests."""
	try:
		mode = anime_skip_filler()
		if not mode or season is None or not episode: return season, episode
		from modules.metadata import is_anime_check
		if not is_anime_check(meta): return season, episode
		skip = ('filler',) if mode == 1 else ('filler', 'recap')
		start, skipped, seasons = (season, episode), 0, {}
		for _ in range(400):
			if episode_kind(meta, season, episode, fetch=fetch) not in skip: break
			nxt = _tmdb_after(meta, season, episode, seasons)
			if not nxt or nxt[0] is None or not nxt[1]: return start   # filler to the end: keep the plain next episode
			season, episode = nxt
			skipped += 1
		if skipped:
			from modules.kodi_utils import logger
			logger('skip filler', 'tmdb %s: S%sE%s -> S%sE%s (%d skipped)' % (meta.get('tmdb_id'), start[0], start[1], season, episode, skipped))
		return season, episode
	except Exception: return season, episode


def flush_pending():
	"""After a listing is on screen: fetch the flags of MAL entries the list could not mark (stored for the next view).
	Not on widget calls -- the same rule as the rating backfills."""
	if not _PENDING: return
	try:
		from modules.kodi_utils import external
		if external(): return
		from apis import tenrai_api
		for mal_id in sorted(_PENDING)[:4]:
			if not tenrai_api.available(): break
			tenrai_api.episode_flags(mal_id)
	except Exception: pass
	_PENDING.clear()
