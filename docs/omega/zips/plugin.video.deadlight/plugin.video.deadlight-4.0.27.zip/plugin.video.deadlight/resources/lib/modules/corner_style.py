# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-10-22: Window Corners for DeadLight's own windows. Since 2026-11-12 always Soft (8 px); the Rounded /
Square choice and its setting were removed, the switching below stays (it is what puts the soft images in place).

Kodi reads a texture's diffuse mask (diffuse="...") as a plain string when the window loads, never as an infolabel,
so no $INFO[] can switch the masks that round posters and thumbs. Instead the window XML points every rounded texture
at media/deadlight_live/, and this fills that folder with either the original rounded images or the copies in
media/deadlight_corners/square/ or soft/ (made by tools/square_corners.py). deadlight_live/ is not in git: it is built here, at
service start and before any window opens, so a fresh install or an addon update gets it back.

A window already open keeps the textures it loaded; the change shows on the windows opened after it."""
import os
import shutil
from modules import kodi_utils

# live name -> the original rounded image, relative to media/
ROUNDED = {'rounded-16.png': 'deadlight_common/rounded-16.png', 'rounded-10.png': 'deadlight_common/rounded-10.png',
		   'left-rounded-16.png': 'deadlight_common/left-rounded-16.png', 'panel-256-box.png': 'deadlight_common/panel-256-box.png',
		   'dialog.png': 'deadlight_common/dialog.png', 'shadow-16.png': 'deadlight_common/shadow-16.png',
		   'outline-16.png': 'deadlight_common/outline-16.png',
		   'poster-50.png': 'deadlight_diffuse/poster-50.png', 'poster_w217_h320.png': 'deadlight_diffuse/poster_w217_h320.png',
		   'poster_large_w217_h320.png': 'deadlight_diffuse/poster_large_w217_h320.png',
		   'landscape.png': 'deadlight_diffuse/landscape.png', 'landscape_w284_h160.png': 'deadlight_diffuse/landscape_w284_h160.png'}
_PROP = 'deadlight.corners_live'

def current_style():
	# LOCAL PATCH 2026-11-12: Soft (8 px), permanently -- the Window Corners setting is gone (user's call)
	return 'soft'

def ensure():
	"""Make deadlight_live/ match the setting. Cheap when it already does: one window-property read."""
	style = current_style()
	if kodi_utils.get_property(_PROP) == style: return
	try:
		media = os.path.join(kodi_utils.translate_path(kodi_utils.addon_path()), 'resources', 'skins', 'Default', 'media')
		live = os.path.join(media, 'deadlight_live')
		marker = os.path.join(live, 'style.txt')
		try:
			with open(marker) as f: built = f.read().strip()
		except Exception: built = ''
		if built != style or not all(os.path.exists(os.path.join(live, name)) for name in ROUNDED):
			if not os.path.isdir(live): os.makedirs(live)
			for name, rel in ROUNDED.items():
				source = os.path.join(media, *rel.split('/')) if style == 'rounded' else os.path.join(media, 'deadlight_corners', style, name)
				shutil.copyfile(source, os.path.join(live, name))
			with open(marker, 'w') as f: f.write(style)
			kodi_utils.logger('corner_style', 'window corners: %s' % style)
		kodi_utils.set_property(_PROP, style)
	except Exception as e:
		kodi_utils.logger('corner_style', 'could not build deadlight_live (%s): %s' % (style, e))
