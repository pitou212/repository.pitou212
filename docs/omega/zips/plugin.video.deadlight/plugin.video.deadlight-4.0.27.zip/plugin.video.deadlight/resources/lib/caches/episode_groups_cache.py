# -*- coding: utf-8 -*-
from caches.base_cache import connect_database, kv_decode
# LOCAL PATCH 2026-10-25 (4.0.5): stored rows were eval()-ed, so a crafted settings-backup zip (settings_backup imports this
# database) ran code. kv_decode reads JSON or a repr() literal and cannot execute anything; writes stay repr().

class EpisodeGroupsCache:
	def get(self, tmdb_id):
		try: data = kv_decode(connect_database('episode_groups_db').execute('SELECT data FROM groups_data WHERE tmdb_id = ?', (str(tmdb_id),)).fetchone()[0])
		except: data = {}
		return data

	def set(self, tmdb_id, data):
		connect_database('episode_groups_db').execute('INSERT OR REPLACE INTO groups_data VALUES (?, ?)', (str(tmdb_id), repr(data)))

	def delete(self, tmdb_id):
		dbcon = connect_database('episode_groups_db')
		dbcon.execute('DELETE FROM groups_data where tmdb_id=?', (str(tmdb_id),))
		dbcon.execute('VACUUM')

	def clear_cache(self):
		dbcon = connect_database('episode_groups_db')
		dbcon.execute('DELETE FROM groups_data')
		dbcon.execute('VACUUM')

episode_groups_cache = EpisodeGroupsCache()
