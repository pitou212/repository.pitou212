# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-11-08: the listitem and the closing calls every debrid cloud listing (indexers/alldebrid, real_debrid,
# premiumize, torbox) wrote out by hand, 11 times over. Each listing still builds its own label, params and context menu.
from modules import kodi_utils

def cloud_listitem(label, cm, icon, fanart, info='plot'):
	"""A cloud row: label, context menu, the service icon as every art type. info='plot' marks it a video item with a blank plot,
	'video' marks it a video item only (TorBox's file rows), None leaves it plain (TorBox's folder rows)."""
	listitem = kodi_utils.make_listitem()
	listitem.setLabel(label)
	listitem.addContextMenuItems(cm)
	listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': icon})
	if info == 'plot': listitem.getVideoInfoTag(True).setPlot(' ')
	elif info == 'video': listitem.getVideoInfoTag()   # LOCAL PATCH 2026-10-21: marks it a video item, without Kodi 20+'s deprecation warning
	return listitem

def end_cloud_directory(handle, items, cache_to_disc=False):
	"""Hand the rows to Kodi and close the directory the way every cloud listing does."""
	kodi_utils.add_items(handle, list(items))
	kodi_utils.set_content(handle, 'files')
	if cache_to_disc: kodi_utils.end_directory(handle)
	else: kodi_utils.end_directory(handle, cacheToDisc=False)
	kodi_utils.set_view_mode('view.premium')
