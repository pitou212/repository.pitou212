# created by kodifitzwell for Fenomscrapers
"""
	Fenomscrapers Project
"""

import re
from magneto.modules import anime_utils
from magneto.modules.provider_base import StremioSource, anime_file_reject, anime_pack_reject, tag_batch


# LOCAL PATCH 2026-11-01 (cleanup): the sources / sources_packs bodies are provider_base.StremioSource's; this file keeps what
# is meteor's own -- its address, the AniList path, its '👥 seeders' info and the anime checks.
class source(StremioSource):
	provider = 'meteor'
	base_link = "https://meteorfortheweebs.midnightignite.me"
	# LOCAL PATCH 2026-10-27: AniList endpoint for anime. Meteor maps every id (tt / kitsu / anilist / mal / anidb) to one
	# entry, so any id gets the same rows. AniList over Kitsu: Meteor's Kitsu map lags new entries (0 streams where the
	# other ids gave 39). A film is episode 1 of its entry ('anilist:1047:1'); bare movie/anilist:1047 finds nothing.
	animeSearch_link = '/stream/anime/anilist:%s:%s.json'
	_SEEDERS = re.compile(r'👥\s*(\d+)')

	def _query(self, data):
		q = super()._query(data)
		q['anilist_mode'] = q['anilist_film'] = False
		return q

	def _search_url(self, data, q):
		if q['tv']:
			# LOCAL PATCH 2026-10-27: anime only, DeadLight passes anilist_id + cour_episode (the entry's own episode; absolute for a
			# whole-run entry: anilist:21:1100 is One Piece 1100). Without both, IMDb.
			anilist_id, cour_ep = data.get('anilist_id'), data.get('cour_episode')
			q['anilist_mode'] = bool(data.get('is_anime')) and bool(anilist_id) and cour_ep is not None
			if q['anilist_mode']: return '%s%s' % (self.base_link, self.animeSearch_link % (anilist_id, cour_ep))
			return super()._search_url(data, q)
		# LOCAL PATCH 2026-10-27: an anime film keeps its IMDb id when it has one (by IMDb it finds far more rows); only a film
		# with no IMDb id is asked for by its AniList id.
		q['anilist_film'] = bool(data.get('anilist_id')) and not anime_utils.real_imdb(q['imdb'])
		return '%s%s' % (self.base_link, self.animeSearch_link % (data['anilist_id'], 1) if q['anilist_film'] else self.movieSearch_link % q['imdb'])

	def _episode_ok(self, file, lines, name, data, q):
		# LOCAL PATCH 2026-11-04 (release judge, phase 4b): anime TV rows are judged by modules/release_judge after the cache
		# (release_judge._TAKEN_OVER, 'stremio'). Films and non-anime shows: checked below.
		if q['tv'] and data.get('is_anime'): return True
		# LOCAL PATCH 2026-10-27: like torrentio's Kitsu path. The AniList answer is entry-scoped and anime names carry no S01E05,
		# which check_title demands -- so the SHOW is checked (title_guard), then the file Meteor picked.
		if not (q['anilist_mode'] or q['anilist_film']):
			if not self._check_title(name, q): return False
		elif not anime_utils.title_guard(name, q['title'], anime_utils.alias_titles(data)): return False
		if data.get('is_anime') and anime_file_reject(self._filename(file, lines), lines[0], q['title'], data): return False
		return True

	def _pack_ok(self, file, lines, name, package, data):
		if data.get('is_anime'): return True   # LOCAL PATCH 2026-11-04: the judge's (anime_pack_reject), see _episode_ok
		# LOCAL PATCH 2026-10-27: Meteor runs on anime now (source_utils.ANIME_PROVIDERS) -- torrentio's pack checks
		return not (data.get('is_anime') and anime_pack_reject(lines[0], self._filename(file, lines), package, data))

	def _tag(self, item, name, data, q):
		# LOCAL PATCH 2026-10-27: a batch is tagged as one (anime_utils.batch_fields); true_size because Meteor's size is the
		# episode file's (source_utils.pack_size_divider)
		if q['anilist_mode']: tag_batch(item, name, data, true_size=True)
