# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-02: warm the next page of a catalogue list after this one is on screen.
#
# A cold Next Page costs a list call plus ~20 TMDb detail calls; a cached one builds in ~50 ms. So while a page is
# built, fetch_list records how to get the NEXT page's ids (queue); deadlight.py calls run() once routing() has
# returned (endOfDirectory has already delivered the list), and run() makes the same list and tvshow_meta /
# movie_meta calls, filling the lists and meta caches.
#
# Only in-addon browsing: never on a widget call (widgets load in bursts, see metadata.flush_rating_backfills), never
# for searches (art deferred for the whole process) or random lists. Rating backfills the warm-up would trigger are
# dropped, not run: they queue again when the page is actually opened, so a page nobody opens spends no OMDb /
# AniList quota.
_PENDING = None
_BUSY_PROP = 'deadlight.page_prefetch_busy'   # LOCAL PATCH 2026-10-16: '<start time>' while a prefetch runs, in any process
PROCESS_START = None

def queue(media_type, id_type, fetch_ids, **meta_kwargs):
	"""fetch_ids() -> the next page's ids, exactly as fetch_list would build self.list for it. LOCAL PATCH 2026-10-16:
	media_type 'mixed' (AniList lists: shows and films on one page) -> fetch_ids() gives (media_type, ids) pairs."""
	global _PENDING
	_PENDING = (media_type, id_type, fetch_ids, meta_kwargs)

def run():
	global _PENDING
	pending, _PENDING = _PENDING, None
	if not pending: return
	from modules import kodi_utils
	if kodi_utils.external(): return
	_warm_pending(pending)

def _warm_pending(pending):
	"""The warm itself -- run() for the page just browsed, warm_widget_pages() for a widget's next page. LOCAL PATCH
	2026-11-01: True only when the whole page was warmed (no ids, an error or Kodi quitting part-way -> False)."""
	import time
	from modules import kodi_utils, settings
	media_type, id_type, fetch_ids, meta_kwargs = pending
	monitor = kodi_utils.kodi_monitor()
	if monitor.abortRequested(): return False
	from modules import metadata
	from modules.utils import get_datetime, get_current_timestamp, TaskPool
	start = time.time()
	kodi_utils.set_property(_BUSY_PROP, '%.3f' % start)
	metadata._DEFERRED = []   # swallow the rating backfills; see the note above
	try:
		ids = [i for i in (fetch_ids() or []) if i]
		if not ids: return False
		pairs = ids if media_type == 'mixed' else [(media_type, i) for i in ids]
		if media_type == 'mixed': meta_kwargs = {}   # movie_meta takes no is_anime_list
		api_key, mpaa_region = settings.tmdb_api_key(), settings.mpaa_region()
		current_date, current_time = get_datetime(), get_current_timestamp()
		# LOCAL PATCH 2026-10-16: and the status chip of shows being / been watched -- their full chip asks TVmaze while the
		# row is built (metadata._tv_renewal, two requests a show). Unwatched shows get the request-free light chip.
		watched = {}
		if any(mt == 'tvshow' for mt, _i in pairs):
			from modules import watched_status
			watched = watched_status.watched_info_tvshow(watched_status.get_database(settings.watched_indicators())) or {}
		def _warm(mt, _id):   # TaskPool unpacks each (media_type, id) pair into the arguments
			if monitor.abortRequested(): return
			function = metadata.tvshow_meta if mt == 'tvshow' else metadata.movie_meta
			meta = function(id_type, _id, api_key, mpaa_region, current_date, current_time, **meta_kwargs)
			# LOCAL PATCH 2026-10-16: unwatched ones too -- their light chip queues a TVmaze lookup (metadata._queue_tvmaze),
			# run below with the other prefetch work instead of being swallowed with the rating backfills
			if mt == 'tvshow' and isinstance(meta, dict): metadata.show_status_props(meta, light=str(meta.get('tmdb_id')) not in watched)
			# LOCAL PATCH 2026-10-25 (4.0.5): and an anime tile's season count -- it counts cours, which for a flat TMDb season
			# runs Fribb's repair (the season's TMDb episode list + AniList air dates).
			if mt == 'tvshow' and isinstance(meta, dict) and metadata.is_anime_check(meta): metadata.shown_season_count(meta)
		[i.join() for i in TaskPool().tasks(_warm, pairs, min(len(pairs), 6))]
		_refresh_warm_stale()   # LOCAL PATCH 2026-11-10
		tvmaze = [item[0] for item in (metadata._DEFERRED or []) if item[3] == (metadata._tvmaze_backfill,)]
		if tvmaze and not monitor.abortRequested(): [i.join() for i in TaskPool().tasks(metadata._tvmaze_backfill, tvmaze, min(len(tvmaze), 4))]
		if monitor.abortRequested():
			kodi_utils.logger('page prefetch', '%s: cut off by Kodi quitting after %.2f s' % (media_type, time.time() - start))
			return False
		kodi_utils.logger('page prefetch', '%s: %d titles in %.2f s' % (media_type, len(ids), time.time() - start))
		return True
	except Exception as e:
		kodi_utils.logger('page prefetch', 'failed: %s' % e)
		return False
	finally:
		metadata._DEFERRED = None
		kodi_utils.clear_property(_BUSY_PROP)


# LOCAL PATCH 2026-10-25 (4.0.5): a WIDGET's next page, warmed later by the service. run() skips widget calls on
# purpose (widgets load in bursts; a hung Kodi once showed ~25 widget threads deadlocked on the GIL), so a widget call
# only RECORDS its next page (note_widget_page: one window property, no network) and the service (WidgetPageWarmer)
# starts warm_widget_pages as a separate plugin call once no widget has loaded for _WIDGET_QUIET seconds and nothing
# plays -- each list at most once per _WIDGET_WARM_EVERY. AniList browse lists: next page = (browse_type, page).
_WIDGET_PAGES_PROP = 'deadlight.widget_pages'   # {key: {'kind', 'args'}} -- JSON, shared by every Kodi process
WIDGET_LAST_PROP = 'deadlight.widget_last'      # time of the last widget call (deadlight.py)
_WIDGET_WARMED_KEY = 'widget_pages_warmed'      # main_cache {key: time warmed}
_WIDGET_WARM_EVERY, _WIDGET_QUIET, _WIDGET_MAX = 6 * 3600, 30, 12   # LOCAL PATCH 2026-11-01: 12 (was 8) -- every widget now

def note_widget_page(kind, args):
	try:
		import json
		from modules import kodi_utils
		try: pending = json.loads(kodi_utils.get_property(_WIDGET_PAGES_PROP) or '{}')
		except ValueError: pending = {}
		key = '%s:%s' % (kind, json.dumps(args, sort_keys=True))
		if key in pending: return
		pending[key] = {'kind': kind, 'args': args}
		kodi_utils.set_property(_WIDGET_PAGES_PROP, json.dumps(pending))
	except Exception: pass

# LOCAL PATCH 2026-11-01: every widget's Next Page. A TMDb / Trakt / MDBList / personal widget's next page cannot be
# described by its ids (they come from its builder's state), but its Next Page item's URL describes it completely:
# _warm_url opens it later as a click would, rows thrown away. Recorded by kodi_utils.add_dir; left out: in-addon
# browsing (run() warms that), random lists, searches, AniList (its lighter 'anilist_browse' kind above) and anything
# recorded while a warm runs -- warming page 2 must not record page 3.
_WARMING = False
_URL_SKIP_MODES = ('random', 'search', 'anilist.')

def note_widget_url(url_params):
	if _WARMING or not isinstance(url_params, dict): return
	from modules import kodi_utils
	if not kodi_utils.external(): return
	mode = str(url_params.get('mode', ''))
	if any(s in mode for s in _URL_SKIP_MODES) or 'search' in str(url_params.get('action', '')) or url_params.get('query'): return
	note_widget_page('url', dict((str(k), str(v)) for k, v in url_params.items()))

def take():
	"""LOCAL PATCH 2026-11-15: True when this call queued a next page (and the queue emptied) -- modules/after_list then hands
	the page's URL to the service, which warms it with warm_next_page."""
	global _PENDING
	pending, _PENDING = _PENDING, None
	return bool(pending)

def _warm_url(params):
	"""A recorded widget Next Page URL (warm_widget_pages): see _warm_through_router."""
	return _warm_through_router(params, widget=True)

def warm_next_page(params):
	"""LOCAL PATCH 2026-11-15: the service's after-list worker (modules/after_list) warms an IN-ADDON list's next page here.
	The plugin call used to run _warm_pending itself, which kept its interpreter busy for 1-3 s after the list -- the next
	click then started a new interpreter, and their shutdowns crashed Kodi (python3.8.dll access violations, 2026-11-15).
	Its fetch_ids is a closure and cannot leave the call, so the page is opened through the router instead."""
	return _warm_through_router(params, widget=False)

def _warm_through_router(params, widget):
	"""LOCAL PATCH 2026-11-15 (one helper for both warms; was _warm_url and a near copy): open a page through the router as
	a click does, with Kodi's directory calls made no-ops -- the list request, every title's meta and art (inline,
	metadata._ART_INLINE: nobody waits on this page) and the anime season counts land in their caches. Rating backfills are
	dropped (a page nobody opens spends no quota) and nothing it queues runs after it. True when it ran to the end.
	widget=True: built as the WIDGET it came from, whatever is on screen (LOCAL PATCH 2026-11-01: with DeadLight itself on
	screen the warm otherwise acted as in-add-on browsing and queued the page after it). widget=False: as an in-addon list
	(the caller has set the call in-addon), and its shows' TVmaze status lookups run too, as _warm_pending's did."""
	import sys, time
	from urllib.parse import urlencode
	from modules import kodi_utils, metadata
	global _WARMING, _PENDING
	names = ('add_item', 'add_items', 'add_dir', 'end_directory', 'set_content', 'set_category', 'set_view_mode')
	saved = dict((n, getattr(kodi_utils, n)) for n in names if hasattr(kodi_utils, n))
	saved_argv, saved_call = list(sys.argv), kodi_utils._EXTERNAL_CALL
	monitor = kodi_utils.kodi_monitor()
	start = time.time()
	_WARMING = True
	kodi_utils.set_property(_BUSY_PROP, '%.3f' % start)
	metadata._DEFERRED, metadata._ART_INLINE = [], True
	try:
		for n in saved: setattr(kodi_utils, n, lambda *a, **k: None)
		if widget: kodi_utils._EXTERNAL_CALL = True
		sys.argv = ['plugin://plugin.video.deadlight/', '-1', '?' + urlencode(params)]
		from modules.router import routing
		routing(sys)
		tvmaze = [] if widget else [item[0] for item in (metadata._DEFERRED or []) if item[3] == (metadata._tvmaze_backfill,)]
		if tvmaze and not monitor.abortRequested():
			from modules.utils import TaskPool
			[i.join() for i in TaskPool().tasks(metadata._tvmaze_backfill, tvmaze, min(len(tvmaze), 4))]
		_refresh_warm_stale()   # LOCAL PATCH 2026-11-10: a warm fills the cache, stale rows included
		ok = not monitor.abortRequested()
		kodi_utils.logger('page prefetch', '%s%s %s p%s: %s in %.2f s' % ('widget page ' if widget else '', params.get('mode', ''),
			params.get('action') or params.get('browse_type') or '', params.get('new_page', '?'), 'warmed' if ok else 'cut off by Kodi quitting', time.time() - start))
		return ok
	except Exception as e:
		kodi_utils.logger('page prefetch', '%spage failed: %s' % ('widget ' if widget else 'next ', e))
		return False
	finally:
		for n, f in saved.items(): setattr(kodi_utils, n, f)
		sys.argv, kodi_utils._EXTERNAL_CALL = saved_argv, saved_call
		metadata._DEFERRED, metadata._ART_INLINE = None, False
		_WARMING = False
		_PENDING = None
		kodi_utils.clear_property(_BUSY_PROP)


# LOCAL PATCH 2026-11-10: shows a WIDGET call answered from an expired row (metadata.tvshow_meta). A widget call only records
# them here (no network: widgets load in bursts); warm_widget_pages refreshes them, as it warms the widgets' next pages.
_STALE_PROP, _STALE_MAX = 'deadlight.stale_metas', 300

def note_stale_metas(tmdb_ids):
	try:
		import json
		from modules import kodi_utils
		try: ids = json.loads(kodi_utils.get_property(_STALE_PROP) or '[]')
		except ValueError: ids = []
		ids = list(dict.fromkeys(ids + [str(i) for i in tmdb_ids]))[-_STALE_MAX:]
		kodi_utils.set_property(_STALE_PROP, json.dumps(ids))
	except Exception: pass

def _take_stale_metas():
	import json
	from modules import kodi_utils
	try: ids = json.loads(kodi_utils.get_property(_STALE_PROP) or '[]')
	except ValueError: ids = []
	kodi_utils.clear_property(_STALE_PROP)
	return ids

def _refresh_warm_stale():
	"""A warm built its page the way the widget would, stale rows included; the shows it queued are refreshed here."""
	try:
		from modules import metadata
		metadata.refresh_stale_metas(metadata.take_stale())
	except Exception: pass

def widget_pages_due():
	"""For the service: True when a recorded widget page or stale show is due and the widgets have been quiet for _WIDGET_QUIET s."""
	try:
		import time
		from modules import kodi_utils
		raw = kodi_utils.get_property(_WIDGET_PAGES_PROP)
		stale = kodi_utils.get_property(_STALE_PROP)
		if (not raw or raw == '{}') and (not stale or stale == '[]'): return False
		try: last = float(kodi_utils.get_property(WIDGET_LAST_PROP) or 0)
		except ValueError: last = 0
		return time.time() - last >= _WIDGET_QUIET
	except Exception: return False

def _anilist_browse_ids(args):
	from indexers.anilist_lists import browse_fetcher, _next_page_ids
	fetcher = browse_fetcher(args['browse_type'], args.get('genre'))[0]   # LOCAL PATCH 2026-10-27: genre widgets too
	return 'mixed', 'trakt_dict', lambda: _next_page_ids(fetcher, int(args['page']))

_WIDGET_KINDS = {'anilist_browse': _anilist_browse_ids, 'url': None}   # 'url' is opened whole by _warm_url

def warm_widget_pages(params=None):
	"""Router entry (mode=page_prefetch.warm_widget_pages), started by the service. Takes the recorded pages, skips any list
	warmed in the last _WIDGET_WARM_EVERY, and warms the rest one after another -- stopping for playback or Kodi quitting."""
	import json, time
	from modules import kodi_utils
	from caches.main_cache import main_cache
	stale = _take_stale_metas()   # LOCAL PATCH 2026-11-10: the stale shows first -- they are on screen now, the next pages are not
	if stale:
		from modules import metadata
		metadata.refresh_stale_metas(stale)
	try: pending = json.loads(kodi_utils.get_property(_WIDGET_PAGES_PROP) or '{}')
	except ValueError: pending = {}
	kodi_utils.clear_property(_WIDGET_PAGES_PROP)
	now = time.time()
	warmed = dict((k, t) for k, t in (main_cache.get(_WIDGET_WARMED_KEY) or {}).items() if now - t < _WIDGET_WARM_EVERY)
	todo = [(k, v) for k, v in pending.items() if k not in warmed and v.get('kind') in _WIDGET_KINDS][:_WIDGET_MAX]
	if not pending: return
	if not todo:
		# LOCAL PATCH 2026-11-01: say so -- a silent return read as the feature not working (log 2026-11-01)
		due = min([t for k, t in warmed.items() if k in pending] or [now]) + _WIDGET_WARM_EVERY
		kodi_utils.logger('page prefetch', 'widget pages: none due (%d recorded, all warmed < %d h ago), next after %s'
			% (len(pending), _WIDGET_WARM_EVERY // 3600, time.strftime('%H:%M', time.localtime(due))))
		return
	monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
	done = 0
	for key, entry in todo:
		if monitor.abortRequested() or player.isPlayingVideo(): break
		try:
			if entry['kind'] == 'url': ok = _warm_url(entry['args'])
			else:
				media_type, id_type, fetch_ids = _WIDGET_KINDS[entry['kind']](entry['args'])
				ok = _warm_pending((media_type, id_type, fetch_ids, {}))
		except Exception as e:
			ok = False
			kodi_utils.logger('page prefetch', 'widget page %s failed: %s' % (key, e))
		# LOCAL PATCH 2026-11-01: stamped only once the page is warm -- stamped before, Kodi quitting part-way left the page
		# marked warmed for 6 h. A page that did not finish is asked again on the next round (the service waits 10 min).
		if ok:
			warmed[key] = time.time()
			main_cache.set(_WIDGET_WARMED_KEY, warmed, expiration=_WIDGET_WARM_EVERY // 3600)
			done += 1
	kodi_utils.logger('page prefetch', 'widget pages warmed: %d of %d recorded (%d skipped, warmed < %d h ago)'
		% (done, len(pending), len(pending) - len(todo), _WIDGET_WARM_EVERY // 3600))


# LOCAL PATCH 2026-10-16: one ###page timing### line per catalogue page browsed in the addon: from this process's
# start (Kodi's interpreter start-up not counted), the list request, the rows, how many titles came from the meta
# cache and whether a prefetch was still running in another process when this page started.
def mark_start():
	global PROCESS_START
	import time
	PROCESS_START = time.time()

def page_marks():
	"""(now, prefetch busy since or None, meta counts) at the start of a page build."""
	import time
	from modules import kodi_utils
	from modules.metadata import META_COUNTS
	try: busy = float(kodi_utils.get_property(_BUSY_PROP) or 0) or None
	except ValueError: busy = None
	if _WARMING: busy = None   # LOCAL PATCH 2026-11-15: the service's own warm (warm_next_page) is not "another prefetch running"
	return time.time(), busy, dict(META_COUNTS)

def log_page(media_type, action, page_no, rows, marks, rows_start):
	import time
	from modules import kodi_utils
	from modules.metadata import META_COUNTS
	try:
		t0, busy, counts = marks
		now = time.time()
		cached, fetched = META_COUNTS['cached'] - counts['cached'], META_COUNTS['fetched'] - counts['fetched']
		startup = (' (+%.2f s start-up)' % (t0 - PROCESS_START)) if PROCESS_START else ''
		prefetch = (', a prefetch was still running (%.1f s in)' % (t0 - busy)) if busy else ''
		kodi_utils.logger('page timing', '%s %s p%s: %.2f s%s -- list %.2f s, rows %.2f s; %d rows, %d titles cached / %d from TMDb%s'
			% (media_type, action, page_no, now - t0, startup, (rows_start or now) - t0, now - (rows_start or now), rows, cached, fetched, prefetch))
	except Exception: pass
