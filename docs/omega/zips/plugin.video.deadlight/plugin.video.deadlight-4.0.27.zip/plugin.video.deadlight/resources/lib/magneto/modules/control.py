"""
	Bundled magneto -- control layer.

	LOCAL PATCH 2026-09-26: DeadLight carries its torrent providers in resources/lib/magneto (the way
	POV bundles its own copy) instead of loading script.module.magneto. Every other file in this
	package is a verbatim copy of magneto's; this one is rewritten so the same code reads DeadLight's
	settings and keeps its data under DeadLight's profile:

	  * setting('x') reads DeadLight setting 'magneto.x' (default rows in caches/settings_cache.py);
	  * cache.db / undesirables.db live in addon_data/plugin.video.deadlight/magneto/.

	Only the names the bundled modules import are defined here.
	LOCAL PATCH 2026-11-01 (cleanup): setSetting, lang, addonPath, addonVersion and selectDialog removed (no callers), and the
	one-time copy of the retired script.module.magneto's undesirables.db (_seed_data) with them -- cache.py and
	undesirables.py create the folder themselves (makeFile), and undesirables.check_database fills a new database.
"""

import os
import xbmcgui
import xbmcvfs
from caches.settings_cache import get_setting

homeWindow = xbmcgui.Window(10000)
dialog = xbmcgui.Dialog()
existsPath = xbmcvfs.exists
makeFile = xbmcvfs.mkdir
transPath = xbmcvfs.translatePath
joinPath = os.path.join

dataPath = transPath('special://profile/addon_data/plugin.video.deadlight/magneto/')
cacheFile = joinPath(dataPath, 'cache.db')
undesirablescacheFile = joinPath(dataPath, 'undesirables.db')

def setting(id, fallback=None):
	value = get_setting('deadlight.magneto.%s' % id, '')
	if value in (None, 'None'): value = ''
	if fallback is None: return value
	if value == '': return fallback
	return value

def notification(title='DeadLight', message='', icon='', time=3000, sound=False):
	dialog.notification(title, message, icon or xbmcgui.NOTIFICATION_INFO, time, sound)

def yesnoDialog(line, heading='DeadLight', nolabel='', yeslabel=''):
	return dialog.yesno(heading, line, nolabel=nolabel, yeslabel=yeslabel)

def multiselectDialog(list, preselect=[], heading='DeadLight'):
	return dialog.multiselect(heading, list, preselect=preselect)
