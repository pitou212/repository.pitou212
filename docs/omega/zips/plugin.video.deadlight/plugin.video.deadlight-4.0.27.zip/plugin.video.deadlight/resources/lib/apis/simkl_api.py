# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-29: SIMKL integration (ported from Otaku's WatchlistFlavor/Simkl.py).
#
# SIMKL uses a PIN device-flow auth (no OAuth PKCE, client_secret or redirect_uri): the user enters a short
# code at simkl.com/pin and DeadLight polls for the token. Tokens don't expire (SIMKL FAQ), so no refresh flow.
#
# Endpoints hit (all under https://api.simkl.com):
#   /oauth/pin                                (PIN request — public, no auth)
#   /oauth/pin/{code}                         (PIN poll — public, no auth)
#   /users/settings                           (get username after auth)
#   /sync/all-items/{type}/{status}           (user's lists — watching/completed/hold/dropped/plantowatch)
#   /sync/add-to-list                         (add movie/show to list w/ status)
#   /sync/history                             (mark watched — supports episode granularity)
#   /sync/history/remove                      (mark unwatched)
#   /sync/ratings + /sync/ratings/remove      (star rating 1-10)
#   /sync/activities                          (last-change timestamps — monitor uses this)
#
# SIMKL supports id_type in {'imdb', 'tmdb', 'tvdb', 'mal', 'anidb', 'simkl'}.
# DeadLight passes TMDb IDs (movies + shows) + MAL IDs (anime via Fribb anime-lists).

import json as _json
import time

from caches.settings_cache import get_setting, set_setting
from caches.base_cache import sync_since
from modules import kodi_utils
from modules.kodi_utils import logger, notification, kodi_dialog, make_session
from modules.utils import safe_err   # LOCAL PATCH 2026-10-25 (4.0.5): request errors logged without their url / query keys


_API_BASE = 'https://api.simkl.com'
_PIN_VERIFICATION_URL = 'https://simkl.com/pin'
_APP_REGISTER_URL = 'https://simkl.com/settings/developer'


_session = make_session(_API_BASE)


# ═══════════════════════════════════════════════════════════════════════════
#  Settings accessors — strip whitespace to survive copy-paste artifacts
# ═══════════════════════════════════════════════════════════════════════════

def _client_id():
	val = (get_setting('deadlight.simkl.client_id', '') or '').strip()
	return val if val and val != 'empty_setting' else ''


def _access_token():
	val = (get_setting('deadlight.simkl.token', '') or '').strip()
	return val if val and val != 'empty_setting' else ''


def _headers(with_auth=True):
	h = {'Content-Type': 'application/json'}
	client_id = _client_id()
	if client_id: h['simkl-api-key'] = client_id
	if with_auth:
		token = _access_token()
		if token: h['Authorization'] = 'Bearer %s' % token
	return h


def simkl_user_active():
	return bool(_access_token() and get_setting('deadlight.simkl.user', 'empty_setting') not in ('empty_setting', ''))


# ═══════════════════════════════════════════════════════════════════════════
#  Core HTTP helper — GET/POST with automatic auth headers
# ═══════════════════════════════════════════════════════════════════════════

def call_simkl(path, method='get', params=None, json=None, timeout=15, with_auth=True):
	"""Wrapper around _session.get/post. Returns parsed JSON or None on error."""
	url = '%s%s' % (_API_BASE, path if path.startswith('/') else '/' + path)
	try:
		r = _session.request(method.upper(), url, params=params, json=json,
							 headers=_headers(with_auth=with_auth), timeout=timeout)
		if r.status_code >= 400:
			logger('SIMKL', 'HTTP %d %s %s | body=%r' % (r.status_code, method.upper(), path, (r.text or '')[:300]))
			return None
		if not r.text: return {}
		try: return r.json()
		except Exception: return None
	except Exception as e:
		logger('SIMKL', 'request failed: %s %s %s' % (method, path, safe_err(e)))
		return None


# ═══════════════════════════════════════════════════════════════════════════
#  PIN device flow — user copies a short code, enters it at simkl.com/pin
# ═══════════════════════════════════════════════════════════════════════════

def simkl_authenticate(dummy=''):
	"""Start SIMKL PIN device flow. Called from settings XML Authorize row."""
	# LOCAL PATCH 2026-07-29: credentials.py bundling means simkl.client_id
	# is usually pre-populated on boot. If it's not, prompt inline (first-run).
	client_id = _client_id()
	if not client_id:
		client_id = kodi_dialog().input('Enter your SIMKL Client ID (register at %s)' % _APP_REGISTER_URL)
		if not client_id: return notification('SIMKL Authorize Cancelled — no Client ID', 4000)
		client_id = client_id.strip()
		set_setting('simkl.client_id', client_id)

	# 1. Request PIN
	pin_data = call_simkl('/oauth/pin', params={'client_id': client_id}, with_auth=False)
	if not pin_data or not pin_data.get('user_code'):
		return notification('SIMKL Authorize Failed — could not obtain PIN. Check Client ID + Network.', 6000)

	user_code = pin_data['user_code']
	expires_in = int(pin_data.get('expires_in', 900))
	interval = int(pin_data.get('interval', 5))

	# 2. Copy PIN to clipboard + show user instructions
	try:
		from modules.utils import copy2clip
		copy2clip(user_code)
	except Exception: pass

	# 3. Poll for authorization. SIMKL returns {result: 'KO'} while waiting, {result: 'OK', access_token: X} when done.
	# LOCAL PATCH 2026-09-30: a QR code of the PIN page beside the code (kodi_utils.qr_dialog), and BACK cancels.
	# SIMKL offers no link with the code filled in, so the code is still typed, on the phone.
	def _poll():
		poll = call_simkl('/oauth/pin/%s' % user_code, params={'client_id': client_id}, with_auth=False, timeout=10)
		if poll and poll.get('result') == 'OK' and poll.get('access_token'): return poll['access_token']
	access_token = kodi_utils.qr_dialog('SIMKL Authorize', _PIN_VERIFICATION_URL,
		'Scan the [B]QR code[/B] or open [B]%s[/B][CR]Sign in and enter this code:   [COLOR gold][B]%s[/B][/COLOR][CR]'
		'DeadLight carries on once you confirm. [B]Back[/B] cancels.' % (_PIN_VERIFICATION_URL, user_code),
		wait=expires_in, poll=_poll, interval=interval)
	if not access_token:
		return notification('SIMKL Authorize cancelled or timed out.', 6000)

	# 4. Fetch username for display in settings
	set_setting('simkl.token', access_token)
	settings = call_simkl('/users/settings', method='post', json={})
	username = ''
	try: username = ((settings or {}).get('user') or {}).get('name', '') or ''
	except Exception: pass
	set_setting('simkl.user', username or 'Authorized')
	_simkl_claim_mirror(username)
	notification('SIMKL Authorized as %s' % (username or 'user'), 5000)
	return True


def simkl_revoke_authentication(dummy=''):
	"""Clear SIMKL auth state. Called from settings XML Revoke row.
	SIMKL doesn't provide a token-revocation endpoint — we just wipe local state.
	Also clears client_id so next Authorize re-prompts for it (in case user needs
	to switch to a different SIMKL app)."""
	set_setting('simkl.token', '')
	set_setting('simkl.user', 'empty_setting')
	set_setting('simkl.last_activity', 'empty_setting')
	set_setting('simkl.client_id', 'empty_setting')
	_simkl_forget_account()
	notification('SIMKL Deauthorized', 3500)


# LOCAL PATCH 2026-10-03 (Batch 2): the local SIMKL mirror belongs to one account. Forgetting (revoke, or another
# account) clears marks, resume points, lists and both activity snapshots, so the next sync is a full rebuild. The
# owner lives in simkl_db.watched_status (db_type 'account'), not simkl_data, which every sync empties.
# Re-authorizing the SAME account forgets nothing: resume points SIMKL cannot store exist only here.
def _simkl_forget_account():
	try:
		from caches.simkl_cache import clear_simkl_lists_cache
		clear_simkl_lists_cache()
	except Exception: pass
	try:
		from caches.base_cache import connect_database, write_transaction
		dbcon = connect_database('simkl_db')
		with write_transaction(dbcon):
			for table in ('watched', 'progress', 'watched_status'): dbcon.execute('DELETE FROM %s' % table)
	except Exception as e: logger('SIMKL', 'forget account failed: %s' % safe_err(e))
	set_setting('simkl.last_activities', 'empty_setting')
	set_setting('simkl.last_activity', 'empty_setting')


def _simkl_claim_mirror(username):
	if not username: return
	try:
		from caches.base_cache import connect_database
		dbcon = connect_database('simkl_db')
		row = dbcon.execute("SELECT status FROM watched_status WHERE db_type = 'account' AND media_id = 'simkl'").fetchone()
		if row and row[0] != username:
			logger('SIMKL', 'signed in as %s, mirror belonged to %s: cleared' % (username, row[0]))
			_simkl_forget_account()
		dbcon.execute("INSERT OR REPLACE INTO watched_status VALUES ('account', 'simkl', ?)", (username,))
	except Exception as e: logger('SIMKL', 'claim mirror failed: %s' % safe_err(e))


# ═══════════════════════════════════════════════════════════════════════════
#  List reads — /sync/all-items/{type}/{status}
#  type ∈ {movies, shows, anime}   status ∈ {watching, completed, hold, dropped, plantowatch}
# ═══════════════════════════════════════════════════════════════════════════

_STATUSES = ('watching', 'completed', 'hold', 'dropped', 'plantowatch')
_TYPES = ('movies', 'shows', 'anime')


# LOCAL PATCH 2026-08-26: Simkl as an ID-resolution source for the anime catalogs -- curated TMDb mappings for new
# anime that Fribb misses and TMDb title search cannot match (romaji titles). Needs only the api-key header
# (with_auth=False): a public metadata read, no Simkl account needed.

def simkl_tmdb_for(simkl_id=None, anilist_id=None, mal_id=None):
	"""Resolve an anime to a TMDb id via Simkl. Returns str id or None.

	Path A (1 request):  a known simkl_id -> /anime/{id}?extended=full
	Path B (2 requests): /search/id?anilist=|mal= to find the simkl id, then A.
	Silent on every failure -- callers fall through to their next resolver."""
	if not _client_id(): return None
	def _tmdb_from_anime(sid):
		try:
			data = call_simkl('/anime/%s' % sid, params={'extended': 'full'}, with_auth=False)
			tmdb = ((data or {}).get('ids') or {}).get('tmdb')
			return str(tmdb) if tmdb else None
		except Exception: return None
	try:
		if simkl_id:
			tmdb = _tmdb_from_anime(simkl_id)
			if tmdb: return tmdb
		for key, val in (('anilist', anilist_id), ('mal', mal_id)):
			if not val: continue
			try:
				res = call_simkl('/search/id', params={key: val}, with_auth=False)
			except Exception: continue
			if not isinstance(res, list) or not res: continue
			sid = ((res[0] or {}).get('ids') or {}).get('simkl')
			if not sid: continue
			tmdb = _tmdb_from_anime(sid)
			if tmdb: return tmdb
	except Exception as e:
		logger('SIMKL', 'simkl_tmdb_for failed: %s' % safe_err(e))
	return None


def simkl_list(list_type, status, extended='full'):
	"""Return raw SIMKL response for user's list. list_type in _TYPES, status in _STATUSES.

	LOCAL PATCH 2026-08-26 (perf): read-through cached. This was hitting the network on
	EVERY call, and indexers/tvshows.py:_load_dropped_set calls it 4 times per list build
	(shows+anime x dropped+hold) whenever watched_indicators == 3 -- so four uncached HTTP
	round trips per widget/list render. modules/watched_status.py:get_hidden_progress_items
	loops it the same way. Caching here fixes every caller at once.

	No TTL by design, matching mdblist_cache.cache_mdbl_object: the entry is invalidated
	by events, not by time. clear_simkl_lists_cache() fires from simkl_sync_activities when
	/sync/activities timestamps advance, and from the write paths (dialogs.py SIMKL manager,
	trakt_drop.py), so dropping a show reflects immediately rather than after a TTL.

	Key format matches caches/simkl_cache.clear_simkl_list ('simkl_{type}_{status}') so its
	targeted clear keeps working. A non-default `extended` gets its own key -- no caller
	passes one today, but a shared key would silently serve the wrong shape if one did."""
	if not simkl_user_active(): return None
	if list_type not in _TYPES: return None
	if status not in _STATUSES: return None
	from caches.simkl_cache import simkl_cache_object
	cache_key = 'simkl_%s_%s' % (list_type, status)
	if extended != 'full': cache_key = '%s_%s' % (cache_key, extended)
	def _fetch():
		# call_simkl returns None on failure, and simkl_cache_object does not cache None,
		# so a transient error is retried rather than pinned.
		return call_simkl('/sync/all-items/%s/%s' % (list_type, status),
						  params={'extended': extended})
	return simkl_cache_object(_fetch, cache_key)


# ═══════════════════════════════════════════════════════════════════════════
#  Sync activities — monitor uses these timestamps to detect remote changes
# ═══════════════════════════════════════════════════════════════════════════

# LOCAL PATCH 2026-09-22 (Red Light 2.6.6 'Phase 2' port, adapted): not Red Light's date_from delta -- simkl_list is
# read-through cached and invalidated by events. Instead the invalidation is narrowed: /sync/activities carries
# per-type, per-status timestamps named like _STATUSES, so only the lists that moved are cleared and rebuilt.
_SIMKL_ACTIVITY_TYPE = {'movies': 'movies', 'shows': 'tv_shows', 'anime': 'anime'}


def _simkl_advanced(current, previous):
	"""True when SIMKL's timestamp for one list moved. Absent/blank is never a change,
	so a key SIMKL stops sending cannot force a permanent rebuild."""
	cur = str(current or '').strip()
	if not cur: return False
	return cur != str(previous or '').strip()


def _simkl_stale_lists(acts, prior):
	"""(list_type, status) pairs whose own timestamp advanced."""
	stale = set()
	for list_type, act_key in _SIMKL_ACTIVITY_TYPE.items():
		current = (acts or {}).get(act_key)
		if not isinstance(current, dict): continue
		previous = (prior or {}).get(act_key)
		if not isinstance(previous, dict): previous = {}
		# A removal does not say WHICH status lost the item, so refresh them all.
		if _simkl_advanced(current.get('removed_from_list'), previous.get('removed_from_list')):
			stale.update((list_type, status) for status in _STATUSES)
			continue
		for status in _STATUSES:
			if _simkl_advanced(current.get(status), previous.get(status)):
				stale.add((list_type, status))
	return stale


def _simkl_changed_kinds(acts, prior):
	"""Which rebuilds are actually needed: 'movies', 'tv' and/or 'playback'.

	simkl_progress_movies and simkl_progress_tv both read /sync/playback, so 'playback'
	is one flag covering both rather than one per media kind."""
	kinds = set()
	for list_type, act_key in _SIMKL_ACTIVITY_TYPE.items():
		current = (acts or {}).get(act_key)
		if not isinstance(current, dict): continue
		previous = (prior or {}).get(act_key)
		if not isinstance(previous, dict): previous = {}
		if _simkl_advanced(current.get('playback'), previous.get('playback')):
			kinds.add('playback')
		for status in _STATUSES + ('removed_from_list',):
			if _simkl_advanced(current.get(status), previous.get(status)):
				kinds.add('movies' if list_type == 'movies' else 'tv')
	return kinds


def simkl_sync_activities():
	"""Called by SIMKLMonitor in service.py. Returns one of:
	  'no_auth'      — user not signed in
	  'no changes'   — remote state matches local
	  'success'      — remote changes detected + local mirror rebuilt
	  'failed'       — API error
	Compares SIMKL's /sync/activities response timestamps against a local cached
	snapshot; on any advance, rebuilds simkl_db.watched + simkl_db.progress and
	invalidates list cache. Populating watched/progress is what makes the
	In-Progress + Next-Episodes widgets work under watched_indicators==3."""
	if not simkl_user_active(): return 'no_auth'
	try:
		# LOCAL PATCH 2026-10-03 (Batch 2): stamped before the poll; local marks at or after it survive the rewrite (base_cache.sync_since)
		since = sync_since()
		acts = call_simkl('/sync/activities')
		if acts is None: return 'failed'
		latest = _latest_stamp(acts)
		prior = get_setting('deadlight.simkl.last_activity', '') or ''
		# LOCAL PATCH 2026-07-29: also rebuild when local simkl_db.watched is empty (fresh install, wipe,
		# failed rebuild) -- remote timestamps may not have advanced.
		try:
			from caches.base_cache import connect_database
			dbcon = connect_database('simkl_db')
			local_watched_count = dbcon.execute('SELECT COUNT(*) FROM watched').fetchone()[0]
		except Exception: local_watched_count = 0
		# LOCAL PATCH 2026-10-03 (3.0.8): watched/progress are built only while SIMKL IS the watched provider; see
		# trakt_sync_activities. The skipped-download flag sits in simkl_db.watched_status (simkl_data is emptied by
		# every sync), and while it is set the next sync as provider rebuilds everything.
		try:
			from modules.settings import watched_indicators
			is_provider = watched_indicators() == 3
		except Exception: is_provider = True
		try: watched_stale = is_provider and dbcon.execute("SELECT 1 FROM watched_status WHERE db_type = 'flag' AND media_id = 'watched_stale'").fetchone() is not None
		except Exception: watched_stale = False
		# LOCAL PATCH 2026-11-08: the daily audit of acknowledged writes (simkl_acked_write): a day after one, the next sync as
		# provider rebuilds the mirror once, as after a skipped download
		if is_provider and not watched_stale:
			try:
				row = dbcon.execute("SELECT status FROM watched_status WHERE db_type = 'flag' AND media_id = 'ack_audit'").fetchone()
				if row and time.time() - float(row[0]) > 24 * 3600:
					watched_stale = True
					dbcon.execute("DELETE FROM watched_status WHERE db_type = 'flag' AND media_id = 'ack_audit'")
					logger('###SIMKL sync###', 'audit of acknowledged writes: mirror rebuilt once')
			except Exception: pass
		# an empty mirror forces a rebuild only for the provider -- otherwise it stays empty and must not count
		if latest and latest == prior and (local_watched_count > 0 or not is_provider) and not watched_stale: return 'no changes'
		# LOCAL PATCH 2026-09-22: rebuild only what moved (_simkl_stale_lists). Full rebuild when a delta cannot
		# be trusted: no stored snapshot, or an empty local mirror.
		prior_acts = None
		_raw = get_setting('deadlight.simkl.last_activities', '') or ''
		if _raw and _raw != 'empty_setting':
			try: prior_acts = _json.loads(_raw)
			except Exception: prior_acts = None
		if not isinstance(prior_acts, dict): prior_acts = None
		full_rebuild = prior_acts is None or (local_watched_count == 0 and is_provider) or watched_stale
		from caches.simkl_cache import clear_simkl_list, clear_simkl_lists_cache
		# LOCAL PATCH 2026-10-03 (Batch 2): each builder says whether it got everything it asked for. When one did
		# not, the snapshot below is not recorded, so the next sync asks again instead of believing it has it.
		skipped = False
		if not is_provider:
			# the lists below still clear; only the downloads wait
			kinds = _simkl_changed_kinds(acts, prior_acts) if prior_acts is not None else {'movies', 'tv', 'playback'}
			skipped = full_rebuild or bool(kinds & {'movies', 'tv', 'playback'})
			complete = True
			stale_lists = _simkl_stale_lists(acts, prior_acts) if prior_acts is not None and not full_rebuild else None
			if stale_lists is None:
				try: clear_simkl_lists_cache()
				except Exception: pass
			else:
				for list_type, status in stale_lists:
					try: clear_simkl_list(list_type, status)
					except Exception: pass
			logger('###SIMKL sync###', 'not the watched provider: lists cleared, downloads %s' % ('skipped' if skipped else 'not needed'))
		elif full_rebuild:
			complete = all([simkl_indicators_movies(since), simkl_indicators_tv(since)] + simkl_progress_all(since))
			try: clear_simkl_lists_cache()
			except Exception: pass
			logger('###SIMKL sync###', 'full rebuild (no snapshot)' if prior_acts is None
				else 'full rebuild (local mirror empty)')
		else:
			kinds = _simkl_changed_kinds(acts, prior_acts)
			stale = _simkl_stale_lists(acts, prior_acts)
			# LOCAL PATCH 2026-11-08: as mdbl_sync_activities -- downloads count as a change only when they changed the local
			# rows (ProviderCache.rows_digest); a cleared list always counts. Otherwise DeadLight's own marks come back as
			# 'success' (widget reload + list refresh) every episode. The full rebuild and not-the-provider branch stay 'success'.
			from caches.simkl_cache import simkl_cache
			rows_before = simkl_cache.rows_digest()
			built = []
			if 'movies' in kinds: built.append(simkl_indicators_movies(since))
			if 'tv' in kinds: built.append(simkl_indicators_tv(since))
			if 'playback' in kinds: built += simkl_progress_all(since)
			complete = all(built)
			for list_type, status in stale:
				try: clear_simkl_list(list_type, status)
				except Exception: pass
			logger('###SIMKL sync###', 'scoped: rebuilt=%s lists_cleared=%d/%d %s'
				% (','.join(sorted(kinds)) or 'none', len(stale), len(_TYPES) * len(_STATUSES),
				','.join('%s/%s' % pair for pair in sorted(stale)) or '-'))
		if not complete:
			logger('###SIMKL sync###', 'a download failed: snapshot not recorded, the next sync asks again')
			return 'success'
		try:
			if skipped: dbcon.execute("INSERT OR REPLACE INTO watched_status VALUES ('flag', 'watched_stale', '1')")
			elif watched_stale: dbcon.execute("DELETE FROM watched_status WHERE db_type = 'flag' AND media_id = 'watched_stale'")
		except Exception: pass
		try: set_setting('simkl.last_activities', _json.dumps(acts))
		except Exception: pass
		if latest:
			set_setting('simkl.last_activity', latest)
		if is_provider and not full_rebuild and not stale and rows_before is not None and simkl_cache.rows_digest() == rows_before:
			logger('###SIMKL sync###', 'downloaded, no row changed: no reload')
			return 'no changes'
		return 'success'
	except Exception as e:
		logger('SIMKL', 'sync_activities failed: %s' % safe_err(e))
		return 'failed'


# ═══════════════════════════════════════════════════════════════════════════
#  Indicator + progress builders — populate simkl_db.watched + simkl_db.progress.
#  Same signatures as trakt_indicators_* / mdbl_indicators_*, so In-Progress and
#  Next-Episodes work drop-in when watched_indicators == 3.
# ═══════════════════════════════════════════════════════════════════════════

# ISO timestamp SIMKL uses (YYYY-MM-DDTHH:MM:SS.000Z). LOCAL PATCH 2026-11-01 (cleanup): base_cache.sync_since gives it.
_js_utc_now = sync_since


def _normalize_ts(ts):
	"""SIMKL returns two ISO shapes: '2026-07-30T19:15:37Z' (endpoints)
	OR '2026-07-30T19:15:37.000Z' (others). DeadLight's episodes.py sorter
	parses last_played with format '%Y-%m-%dT%H:%M:%S.%fZ' which REQUIRES
	the microsecond section — the Z-only shape crashes it.
	Insert '.000' before 'Z' if missing."""
	if not ts: return _js_utc_now()
	if 'T' not in ts: return ts   # not our format, leave alone
	if ts.endswith('Z') and '.' not in ts[-8:]:
		return ts[:-1] + '.000Z'
	return ts


def _extract_tmdb(ids):
	if not isinstance(ids, dict): return None
	try: return int(ids.get('tmdb') or 0) or None
	except (TypeError, ValueError): return None


def simkl_indicators_movies(since=None):
	"""Populate simkl_db.watched with all movies the user has actually watched —
	across completed / dropped / hold statuses (any movie the user started).
	Plan-to-watch is excluded (never watched). Returns False when a download failed."""
	from caches.simkl_cache import simkl_cache
	try:
		insert_list = []
		seen_tmdb = set()
		raw = 0
		for status in ('completed', 'dropped', 'hold', 'watching'):
			data = call_simkl('/sync/all-items/movies/%s' % status, params={'extended': 'full'})
			# LOCAL PATCH 2026-10-03 (Batch 2): a failed page (None) is not an empty one ({}): rewriting from
			# the other statuses would wipe every movie in this one.
			if data is None: return False
			if not data: continue
			raw += len(data.get('movies') or [])
			for it in (data.get('movies') or []):
				try:
					movie = it.get('movie') or {}
					tmdb = _extract_tmdb(movie.get('ids'))
					if not tmdb or tmdb in seen_tmdb: continue
					seen_tmdb.add(tmdb)
					last = _normalize_ts(it.get('last_watched_at') or _js_utc_now())
					title = movie.get('title', '')
					insert_list.append(('movie', str(tmdb), '', '', last, title))
				except Exception: continue
		if raw and not insert_list: return True
		# LOCAL PATCH 2026-10-19: SIMKL holding none is written as none (allow_empty) -- the last mark / resume point removed
		# on SIMKL stayed here for ever. Rows that came back but could not be read keep what is stored.
		simkl_cache.set_bulk_movie_watched(insert_list, since, allow_empty=True)
		return True
	except Exception as e:
		logger('SIMKL', 'indicators_movies failed: %s' % safe_err(e))
		return False


def simkl_indicators_tv(since=None):
	"""Fetch all watched TV episodes + populate simkl_db.watched.
	Uses /sync/all-items/shows?extended=full which returns per-show seasons/episodes
	with last_watched_at at episode granularity. Anime is folded into shows here —
	SIMKL treats anime as an episode-based media type too."""
	from caches.simkl_cache import simkl_cache
	try:
		insert_list = []
		raw = 0
		for list_type in ('shows', 'anime'):
			data = call_simkl('/sync/all-items/%s' % list_type, params={'extended': 'full', 'episode_watched_at': 'yes'})
			if data is None: return False   # LOCAL PATCH 2026-10-03 (Batch 2): see simkl_indicators_movies
			if not data: continue
			for it in (data.get(list_type) or []):
				try:
					show = it.get('show') or {}
					tmdb = _extract_tmdb(show.get('ids'))
					if not tmdb: continue
					title = show.get('title', '')
					# `seasons` key contains only when extended=full is honored + user has watched episodes
					for season in (it.get('seasons') or []):
						try: s_n = int(season.get('number') or 0)
						except: continue
						if s_n == 0: continue
						for ep in (season.get('episodes') or []):
							raw += 1
							try: e_n = int(ep.get('number') or 0)
							except: continue
							if e_n == 0: continue
							last = _normalize_ts(ep.get('watched_at') or it.get('last_watched_at') or _js_utc_now())
							insert_list.append(('episode', str(tmdb), s_n, e_n, last, title))
				except Exception: continue
		if raw and not insert_list: return True
		# LOCAL PATCH 2026-10-19: SIMKL holding none is written as none (allow_empty) -- the last mark / resume point removed
		# on SIMKL stayed here for ever. Rows that came back but could not be read keep what is stored.
		simkl_cache.set_bulk_tvshow_watched(insert_list, since, allow_empty=True)
		return True
	except Exception as e:
		logger('SIMKL', 'indicators_tv failed: %s' % safe_err(e))
		return False


def simkl_progress_all(since=None):
	"""LOCAL PATCH 2026-11-01 (cleanup): /sync/playback once for both progress builders (each downloaded it itself), as
	Trakt / MDBList hand their progress_info to both. [movies_ok, tv_ok]."""
	try: data = call_simkl('/sync/playback')
	except Exception as e:
		logger('SIMKL', 'playback failed: %s' % safe_err(e))
		data = None
	if data is None: return [False, False]   # LOCAL PATCH 2026-10-03 (Batch 2): failed, not empty
	return [simkl_progress_movies(since, data), simkl_progress_tv(since, data)]


def simkl_progress_movies(since=None, data=None):
	"""Populate simkl_db.progress with paused movies (In Progress widget source).
	SIMKL /sync/playback returns items with `progress` (0-100 float) + timestamps. data: that download (simkl_progress_all)."""
	from caches.simkl_cache import simkl_cache
	try:
		if data is None: data = call_simkl('/sync/playback')
		if data is None: return False   # LOCAL PATCH 2026-10-03 (Batch 2): failed, not empty
		insert_list = []
		# Playback response shape can be a list of items or grouped movies/shows —
		# handle both defensively.
		items = data if isinstance(data, list) else (data.get('movies') or [])
		for it in items:
			try:
				movie = it.get('movie') or {}
				tmdb = _extract_tmdb(movie.get('ids'))
				if not tmdb: continue
				title = movie.get('title', '')
				progress = float(it.get('progress') or 0)
				if progress <= 0 or progress >= 90: continue
				paused_at = _normalize_ts(it.get('paused_at') or it.get('last_watched_at') or _js_utc_now())
				# DeadLight progress schema: (db_type, media_id, season, episode, resume_point, curr_time, last_played, resume_id, title)
				# curr_time '0' + resume_id 0 is what tells these rows from DeadLight's own (simkl_cache keep_local).
				insert_list.append(('movie', str(tmdb), '', '', str(progress), '0', paused_at, 0, title))
			except Exception: continue
		# LOCAL PATCH 2026-10-19: nothing paused on SIMKL is written too (allow_empty); keep_local still keeps the resume
		# points only DeadLight holds.
		simkl_cache.set_bulk_movie_progress(insert_list, since, allow_empty=True)
		return True
	except Exception as e:
		logger('SIMKL', 'progress_movies failed: %s' % safe_err(e))
		return False


def simkl_progress_tv(since=None, data=None):
	"""Populate simkl_db.progress with paused TV episodes.
	SIMKL /sync/playback for shows: items include season+episode + progress. data: as simkl_progress_movies."""
	from caches.simkl_cache import simkl_cache
	try:
		if data is None: data = call_simkl('/sync/playback')
		if data is None: return False   # LOCAL PATCH 2026-10-03 (Batch 2): failed, not empty
		insert_list = []
		items = data if isinstance(data, list) else (data.get('shows') or [])
		for it in items:
			try:
				show = it.get('show') or {}
				tmdb = _extract_tmdb(show.get('ids'))
				if not tmdb: continue
				title = show.get('title', '')
				progress = float(it.get('progress') or 0)
				if progress <= 0 or progress >= 90: continue
				ep = it.get('episode') or {}
				s_n = int((it.get('season') or {}).get('number') or ep.get('season') or 0)
				e_n = int(ep.get('number') or 0)
				if not (s_n and e_n): continue
				paused_at = _normalize_ts(it.get('paused_at') or it.get('last_watched_at') or _js_utc_now())
				insert_list.append(('episode', str(tmdb), s_n, e_n, str(progress), '0', paused_at, 0, title))   # '0'/0: see progress_movies
			except Exception: continue
		# LOCAL PATCH 2026-10-19: nothing paused on SIMKL is written too (allow_empty); keep_local still keeps the resume
		# points only DeadLight holds.
		simkl_cache.set_bulk_tvshow_progress(insert_list, since, allow_empty=True)
		return True
	except Exception as e:
		logger('SIMKL', 'progress_tv failed: %s' % safe_err(e))
		return False


# ═══════════════════════════════════════════════════════════════════════════
#  Writes — add/remove from list, mark watched, rate
# ═══════════════════════════════════════════════════════════════════════════

def _id_dict(id_type, id_val):
	"""SIMKL accepts {tmdb, imdb, tvdb, mal, anidb, simkl} keys in the ids object."""
	if not id_val: return {}
	return {id_type: id_val}


def simkl_add_to_list(list_type, id_type, id_val, status):
	"""list_type in _TYPES, status in _STATUSES + 'notinteresting' (legacy).
	Returns True on success."""
	if list_type not in _TYPES: return False
	if not simkl_user_active(): return False
	key = 'shows' if list_type in ('shows', 'anime') else 'movies'
	data = {key: [{'to': status, 'ids': _id_dict(id_type, id_val)}]}
	res = call_simkl('/sync/add-to-list', method='post', json=data)
	return bool(res)


# LOCAL PATCH 2026-09-19: put the NEXT cour on Watching when this one finishes -- SIMKL has one entry per cour, TMDb
# one season. A cour ended when Fribb maps `episode` and `episode + 1` to different cours (no answer for episode + 1:
# nothing to advance to). Anime-gated by that offline lookup itself. The finished cour is NOT written: SIMKL marks it
# completed itself.
def simkl_advance_cour(tmdb_id, season, episode):
	"""Add the next cour to SIMKL's Watching list when `episode` was the last of its cour.

	Returns True only when a next cour was actually added."""
	try:
		if not simkl_user_active(): return False
		try: tmdb_id, season, episode = int(tmdb_id), int(season), int(episode)
		except (TypeError, ValueError): return False
		from caches.fribb_mappings import find_cour_by_tmdb_coords
		current = find_cour_by_tmdb_coords(tmdb_id, season, episode)
		if not current: return False                      # not anime, or unmapped
		nxt = find_cour_by_tmdb_coords(tmdb_id, season, episode + 1)
		if not nxt: return False                          # no episode after this one
		cur_mal, nxt_mal = current.get('mal'), nxt.get('mal')
		if not nxt_mal or nxt_mal == cur_mal: return False  # still inside the same cour
		added = simkl_add_to_list('anime', 'mal', int(nxt_mal), 'watching')
		if added:
			logger('SIMKL cour', 'tmdb %s S%s E%s ended a cour; added mal %s to watching'
					% (tmdb_id, season, episode, nxt_mal))
		return bool(added)
	except Exception as e:
		try: logger('SIMKL cour error', safe_err(e))
		except Exception: pass
		return False


def _latest_stamp(d):
	"""The newest timestamp anywhere in SIMKL's /sync/activities answer ('' when none)."""
	if not isinstance(d, dict): return ''
	vals = [_latest_stamp(v) if isinstance(v, dict) else (v or '') for v in d.values()]
	vals = [v for v in vals if v]
	return max(vals) if vals else ''


# LOCAL PATCH 2026-11-08: SIMKL marks acknowledged like MDBList's and Trakt's (modules.acked_write) while SIMKL is the
# watched provider, so the next sync does not rebuild what the mark changed. Not when only cross-synced
# (player._simkl_scrobble): its downloads are skipped then.
def simkl_acked_write(write, list_type):
	try:
		from modules.settings import watched_indicators
		if watched_indicators() != 3: return write()
	except Exception: return write()
	from modules.acked_write import acked_write
	from caches.base_cache import connect_database
	def _stored():
		raw = get_setting('deadlight.simkl.last_activities', '') or ''
		try: return _json.loads(raw) if raw and raw != 'empty_setting' else None
		except Exception: return None
	def _store(acts):
		set_setting('simkl.last_activities', _json.dumps(acts))
		latest = _latest_stamp(acts)
		if latest: set_setting('simkl.last_activity', latest)
	def _audit():
		try:
			dbcon = connect_database('simkl_db')
			if not dbcon.execute("SELECT 1 FROM watched_status WHERE db_type = 'flag' AND media_id = 'ack_audit'").fetchone():
				dbcon.execute("INSERT OR REPLACE INTO watched_status VALUES ('flag', 'ack_audit', ?)", (str(time.time()),))
		except Exception: pass
	moves = ('all', 'tv_shows', 'anime') if list_type in ('shows', 'anime') else ('all', 'movies')
	return acked_write(write, moves, lambda: call_simkl('/sync/activities'), _stored, _store, on_ack=_audit, label='SIMKL')


def simkl_mark_watched(list_type, id_type, id_val, seasons=None):
	return simkl_acked_write(lambda: _simkl_mark_watched(list_type, id_type, id_val, seasons), list_type)


def simkl_mark_unwatched(list_type, id_type, id_val, seasons=None):
	return simkl_acked_write(lambda: _simkl_mark_unwatched(list_type, id_type, id_val, seasons), list_type)


def _simkl_mark_watched(list_type, id_type, id_val, seasons=None):
	"""Mark a movie or show/anime as watched. For shows/anime, pass
	seasons=[{'number': N, 'episodes': [{'number': X}, ...]}] for per-episode
	granularity; omit seasons to mark the whole show."""
	if not simkl_user_active(): return False
	key = 'shows' if list_type in ('shows', 'anime') else 'movies'
	item = {'ids': _id_dict(id_type, id_val)}
	if seasons: item['seasons'] = seasons
	res = call_simkl('/sync/history', method='post', json={key: [item]})
	return bool(res)


def _simkl_mark_unwatched(list_type, id_type, id_val, seasons=None):
	if not simkl_user_active(): return False
	key = 'shows' if list_type in ('shows', 'anime') else 'movies'
	item = {'ids': _id_dict(id_type, id_val)}
	if seasons: item['seasons'] = seasons
	res = call_simkl('/sync/history/remove', method='post', json={key: [item]})
	return bool(res)


def simkl_rate(list_type, id_type, id_val, score):
	"""Set / remove star rating (1-10). Passing score=0 removes the rating."""
	if not simkl_user_active(): return False
	key = 'shows' if list_type in ('shows', 'anime') else 'movies'
	item = {'rating': int(score), 'ids': _id_dict(id_type, id_val)}
	path = '/sync/ratings/remove' if int(score) == 0 else '/sync/ratings'
	res = call_simkl(path, method='post', json={key: [item]})
	return bool(res)


# ═══════════════════════════════════════════════════════════════════════════
#  Rating UI — router entry: mode=simkl.simkl_rate_dialog
#  Skin/context menu invokes this with params {list_type, tmdb_id[, imdb_id]}.
#  Shows a 0-10 picker; 0 removes the rating.
# ═══════════════════════════════════════════════════════════════════════════

def simkl_rate_dialog(params):
	"""Context-menu invocation. Opens a rating picker and pushes to SIMKL.
	params:
	  tmdb_id (required)
	  list_type ∈ {movies, shows, anime}  (defaults to media_type param mapping)
	  media_type ∈ {movie, tvshow, episode, anime}  (alt to list_type — auto-mapped)"""
	if not simkl_user_active():
		return notification('SIMKL not authorized — open Settings > Accounts > SIMKL first', 5000)
	tmdb_id = params.get('tmdb_id') or params.get('media_id')
	if not tmdb_id:
		return notification('SIMKL Rate: no TMDb ID', 3500)

	list_type = params.get('list_type')
	if not list_type:
		mt = params.get('media_type', 'movie')
		list_type = {'movie': 'movies', 'tvshow': 'shows', 'episode': 'shows', 'anime': 'anime'}.get(mt, 'movies')

	# Rating picker — 0 (remove) through 10.
	from modules.kodi_utils import select_dialog
	import json as _sel_json
	options = [('Remove Rating', 0)] + [('%s / 10' % s, s) for s in range(10, 0, -1)]
	kwargs = {'items': _sel_json.dumps([{'line1': opt[0]} for opt in options]), 'narrow_window': 'true', 'heading': 'SIMKL Rating'}
	choice = select_dialog(options, **kwargs)
	if choice is None: return
	score = int(choice[1])
	success = simkl_rate(list_type, 'tmdb', int(tmdb_id), score)
	if success:
		# Invalidate list caches so the new rating shows up on next browse.
		try:
			from caches.simkl_cache import clear_simkl_lists_cache
			clear_simkl_lists_cache()
		except Exception: pass
		notification('SIMKL: %s' % ('Rating Removed' if score == 0 else 'Rated %d/10' % score), 3500)
	else:
		notification('SIMKL Rate Failed', 4000)
