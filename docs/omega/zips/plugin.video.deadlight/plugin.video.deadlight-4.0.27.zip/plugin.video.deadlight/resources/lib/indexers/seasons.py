# -*- coding: utf-8 -*-
import sys
import re
from modules import kodi_utils, settings
from modules.metadata import tvshow_meta, season_trailer_for, display_genres
from modules.utils import get_datetime, adjust_premiered_date, TaskPool
from modules.watched_status import get_database, watched_info_season, get_watched_status_season, get_progress_status_season, watched_info_episode

# LOCAL PATCH 2026-08-27: anime cours as season rows.
# TMDb groups anime by its own season layout, often not how the show aired (Frieren: one TMDb season of 38 episodes,
# two cours of 28 and 10). Fribb records the boundaries offline, so the season list can show one row per cour.
# Presentation only: (season, episode) stays TMDb's everywhere it is an identity -- play urls, watched state,
# bookmarks, Trakt/Simkl sync, scrapers -- because renumbering would orphan existing watch history.
def _aired_per_season(season_data, total_seasons, total_aired_eps):
	"""{season_number: aired episode count}, mirroring the running total the
	season loop keeps: every season but the last reports its full TMDb count, and
	the last gets whatever is left of total_aired_eps."""
	out, acc = {}, 0
	# Ascending order matters: the running total is what decides how much of the
	# final season has actually aired.
	for item in sorted(season_data, key=lambda i: i.get('season_number') or 0):
		sn, ec = item.get('season_number'), item.get('episode_count') or 0
		if sn is None or sn == 0: continue
		if sn < total_seasons:
			out[sn] = ec
			acc += ec
		else: out[sn] = (total_aired_eps or 0) - acc
	return out


def _cour_watched_count(episode_rows, season_number, offset, length):
	"""How many episodes of one cour are watched.

	watched_info_season() only counts per TMDb season, which cannot be split, so
	the per-episode rows are counted directly. Rows are (season, episode) with
	TMDb numbering, so the cour covers offset+1 .. offset+length."""
	if not episode_rows: return 0
	total = 0
	for row in episode_rows:
		try: s, e = int(row[0]), int(row[1])
		except (TypeError, ValueError, IndexError): continue
		if s == season_number and offset < e <= offset + length: total += 1
	return total


def _prefetch_anizip(tmdb_id):
	"""LOCAL PATCH 2026-10-20: the ani.zip answers this show's episode map will read, fetched AT ONCE before the per-season
	loop asks them one by one. Only answers not cached yet, at most 8 at once, once per show a week; it only fills the
	cache -- the map is built by the same code from it afterwards."""
	try:
		from threading import Thread
		from caches import fribb_mappings, anizip_mappings
		from caches.lists_cache import lists_cache
		rows = fribb_mappings.tmdb_tv_to_fribb_rows(int(tmdb_id)) or []
		# LOCAL PATCH 2026-10-25 (4.0.5): the cour checks read each row's episode-1 date from AniList's startDate first
		# (fribb_mappings._e1_date), so every AniList id of the show is fetched here in ONE request (per-id cached), and
		# ani.zip is prefetched only for rows with no AniList id.
		# LOCAL PATCH 2026-10-26: only for a show of two or more rows -- a single-entry show has no cour to split, and with
		# Kitsu / MAL as catalogue this cache is never pre-filled. _e1_date fetches any date it needs itself.
		if len(rows) > 1:
			try:
				from apis.anilist_api import anilist_start_dates
				anilist_start_dates([r.get('anilist_id') for r in rows if r.get('anilist_id')])
			except Exception: pass
		# once per show a week: a long-running show's Fribb rows include OVAs / specials the map may never read, and
		# without this each visit would fetch the next 8 of them
		flag = 'anizip_prefetched_%s' % tmdb_id
		if lists_cache.get(flag): return
		lists_cache.set(flag, 1, expiration=168)
		todo, seen = [], set()
		for row in rows:
			pair = (row.get('anilist_id'), row.get('anidb_id'))
			if not any(pair) or pair in seen or pair[0]: continue   # AniList rows: dated by AniList (above)
			seen.add(pair)
			key = ('anidb_id', pair[1])
			if lists_cache.get(anizip_mappings._CACHE_KEY % key) is None: todo.append(pair)
		threads = [Thread(target=anizip_mappings.anizip_entry_dates, args=pair) for pair in todo[:8]]
		for t in threads: t.start()
		for t in threads: t.join(15)
	except Exception: pass

def _expand_anime_cours(meta, season_data):
	"""season_data with multi-cour seasons replaced by one entry per cour.

	Returns the list unchanged when the setting is off, the show is not anime, or
	Fribb has no split for any of its seasons -- so non-anime and single-cour shows
	keep the existing code path exactly.
	"""
	if not settings.anime_split_cours(): return season_data
	try:
		from modules.metadata import is_anime_check
		if not is_anime_check(meta): return season_data
		from caches import fribb_mappings
		if not fribb_mappings.is_available(): return season_data
	except Exception: return season_data
	tmdb_id = meta.get('tmdb_id')
	_prefetch_anizip(tmdb_id)   # LOCAL PATCH 2026-10-20
	split = {}
	for item in season_data:
		sn = item.get('season_number')
		if not sn: continue      # never split specials
		try: cours = fribb_mappings.cours_for_tmdb_season(tmdb_id, sn, item.get('episode_count') or 0)
		except Exception: cours = []
		if cours: split[sn] = cours
	# LOCAL PATCH 2026-10-09: one row per RELEASE season (Fribb's season.tvdb), not per AniList entry. A TMDb season is
	# split only where the release season changes (Frieren S1 = tvdb 1 + 2), and the cours of one release season are
	# merged back (Stone Ocean is one row, not three 'Part' rows).
	# One bulk AniList request names every cour of the show (and fills the per-id cache).
	# LOCAL PATCH 2026-08-27: the same bulk call returns each cour's cover art, so every cour row gets its own poster.
	# LOCAL PATCH 2026-10-03 (Batch 4): by each cour's AniList id, by MAL id only for a cour without one -- one MAL id
	# can be two AniList entries (Steel Ball Run). Keys are ('a', id) / ('m', id): the two id spaces overlap.
	titles, titles_en, art = {}, {}, {}
	def _ck(c): return ('a', int(c['anilist'])) if c.get('anilist') else ('m', int(c['mal'])) if c.get('mal') else None
	try:
		from apis.anilist_api import anilist_media_bulk, anilist_media_bulk_by_id
		all_cours = [c for cs in split.values() for c in cs]
		al_ids = [c['anilist'] for c in all_cours if c.get('anilist')]
		mal_ids = [c['mal'] for c in all_cours if c.get('mal') and not c.get('anilist')]
		recs = {}
		if al_ids: recs.update((('a', k), v) for k, v in (anilist_media_bulk_by_id(al_ids) or {}).items())
		if mal_ids: recs.update((('m', k), v) for k, v in (anilist_media_bulk(mal_ids) or {}).items())
		titles = {k: v.get('title') for k, v in recs.items() if v.get('title')}
		titles_en = {k: v.get('title_en') for k, v in recs.items() if v.get('title_en')}
		art = {k: v.get('poster') for k, v in recs.items() if v.get('poster')}
	except Exception: titles, titles_en, art = {}, {}, {}
	# LOCAL PATCH 2026-10-16: cours whose AniList titles name DIFFERENT seasons are not merged, even under one TVDB
	# season (TVDB files Bungou Stray Dogs S1 = Seasons 1+2). A title naming no season belongs with the group before it
	# (the first one: season 1); 'Re:ZERO 2nd Season' and '... 2nd Season Part 2' still merge.
	for sn in list(split):
		groups = []
		for cour in split[sn]:
			try: rel = (fribb_mappings.find_cour_by_tmdb_coords(tmdb_id, sn, cour['offset'] + 1) or {}).get('cour_season')
			except Exception: rel = None
			named = _title_season(titles.get(_ck(cour)))
			ts = named if named is not None else (groups[-1]['ts'] if groups else 1)
			if groups and groups[-1]['rel'] == rel and groups[-1]['ts'] == ts:
				groups[-1]['cours'].append(cour)
			else: groups.append({'rel': rel, 'ts': ts, 'cours': [cour]})
		if len(groups) < 2:
			del split[sn]
			continue
		merged = []
		for g in groups:
			first = dict(g['cours'][0])
			first['length'] = sum(c['length'] for c in g['cours'])
			first['_merged'] = len(g['cours']) > 1
			# rows sharing this AniList season -- 1 means the row is a whole season, not 'Part N' of TVDB's grouping
			first['_ts_rows'] = sum(1 for g2 in groups if g2['ts'] == g['ts'])
			merged.append(first)
		split[sn] = merged
	if not split: return season_data
	out = []
	for item in season_data:
		cours = split.get(item.get('season_number'))
		if not cours:
			out.append(item)
			continue
		# the first cour's title is the show's base name in the same language as the
		# others, which makes it the best prefix to strip
		_get = lambda d, c: d.get(_ck(c))
		base_title = _get(titles, cours[0])
		base_en = _get(titles_en, cours[0])
		for cour in cours:
			entry = dict(item)
			entry['episode_count'] = cour['length']
			entry['_cour_offset'] = cour['offset']
			entry['_cour_len'] = cour['length']
			name = _get(titles, cour)
			# LOCAL PATCH 2026-09-23: label in English when AniList has it. The prefix to trim must be in the SAME language as
			# the name, so a cour with no English title keeps the romaji pair (a base with none falls back to the romaji base,
			# which then fails to trim and hands over to the TMDb show title).
			_name_en = _get(titles_en, cour)
			_base = base_title
			if _name_en: name, _base = _name_en, (base_en or base_title)
			info = {}
			try: info = fribb_mappings.find_cour_by_tmdb_coords(tmdb_id, item.get('season_number'), cour['offset'] + 1) or {}
			except Exception: pass
			# Falls back through TMDb's season poster to the show poster in _process().
			cour_art = _get(art, cour)
			if cour_art: entry['_cour_poster'] = cour_art
			# LOCAL PATCH 2026-08-29: keep the AniList id, so Mark Watched can reach AniList (mark_season in watched_status).
			# A merged row spans several entries: no single id, so mark_season pushes each entry its own episodes.
			if info.get('anilist') and not cour.get('_merged'): entry['_cour_anilist'] = info['anilist']
			# LOCAL PATCH 2026-09-16: and its TVDB season number (Fribb's season.tvdb), so a cour can look up its OWN TVDB
			# season poster.
			if info.get('cour_season') is not None: entry['_cour_tvdb_season'] = info['cour_season']
			if cour.get('_merged'):
				# the first part's name minus its 'Part 1' / 'Cour 1' -- the row is the whole release season
				name = _TRAILING_PART_RE.sub('', name or '') or None
				entry['_cour_title'] = _short_cour_label(name, _base, meta.get('title'), info.get('cour_season'), 1, 1,
					item.get('season_number'))
			else:
				_parts = 1 if cour.get('_ts_rows') == 1 else (info.get('cour_part_count') or len(cours))   # LOCAL PATCH 2026-10-16
				entry['_cour_title'] = _short_cour_label(
					name, _base, meta.get('title'), info.get('cour_season'),
					info.get('cour_part') or cour['index'], _parts,
					item.get('season_number'))
			entry['_cour_title'] = _numbered_label(entry['_cour_title'], info.get('cour_season'), _title_season(_get(titles, cour)))
			out.append(entry)
	return out


_SPECIAL_PREFIX = 'SP · '


def _norm_name(text):
	return ''.join(ch for ch in str(text or '').lower() if ch.isalnum())


def _entry_name(meta, eps, stem=''):
	"""LOCAL PATCH 2026-11-07: a specials run's own name when its stem would repeat a regular season's, else None.
	  1. one episode: its own title;
	  2. the English title of the ONE AniDB entry Fribb maps every episode to, when it holds the stem AND a season marker
	     (Monogatari's S0E35-41 -> 'Owarimonogatari Second Season'). Not without the marker -- Tokyo Ghoul's Jack + Pinto
	     share an AniDB entry titled 'Tokyo Ghoul Pinto';
	  3. 2-3 distinct subtitles after 'stem:', joined: 'Tokyo Ghoul: Jack / Pinto'."""
	import re
	try:
		if len(eps) == 1: return (eps[0].get('title') or '').strip() or None
		from caches.fribb_mappings import find_cour_by_tmdb_coords
		from caches.anizip_mappings import anizip_entry_titles
		aids = set()
		for e in eps:
			aids.add((find_cour_by_tmdb_coords(meta.get('tmdb_id'), 0, int(e['episode']), allow_repair=False) or {}).get('anidb'))
		if len(aids) == 1 and None not in aids:
			titles = (anizip_entry_titles(anidb_id=aids.pop()) or {}).get('titles') or []
			title = titles[0] if titles else ''   # ani.zip's 'en' first, then 'x-jat'
			if _norm_name(stem) in _norm_name(title) and re.search(r'(?i)\b(?:second|third|final|2nd|3rd|\d+th|season|part|ii|iii)\b|\(\d{4}\)', title):
				return title
		subs = []
		for e in eps:
			t = e.get('title') or ''
			if ':' not in t: return None
			s = re.sub(r'\s*\(\d+\)\s*$', '', t.split(':', 1)[1]).strip()
			if s and s not in subs: subs.append(s)
		return '%s: %s' % (stem, ' / '.join(subs)) if 2 <= len(subs) <= 3 else None
	except Exception: return None


def _special_rows(meta, season_data):
	"""LOCAL PATCH 2026-10-17: TMDb's Specials season as one row per run of specials, each placed between the seasons it aired
	between (setting anime.specials = 'In Airing Order').
	
	A run is consecutive specials sharing a name stem (fribb_mappings.special_groups). A row is a slice of season 0
	(_cour_offset / _cour_len, as a cour row is of its season), so its episode list, watched count and progress are that
	run's alone. It goes before the first season row that started after it; one that aired after every season goes last,
	one with no air date yet is left out. Cour rows are dated by their first episode (cached episode lists). Any failure
	leaves the list as the Specials folder would have."""
	try:
		special = next((i for i in season_data if i.get('season_number') == 0), None)
		if not special: return season_data
		from modules.metadata import episodes_meta
		from caches.fribb_mappings import special_groups   # LOCAL PATCH 2026-10-17: shared with the season-0 id map
		groups = special_groups(episodes_meta(0, meta) or [])
		if not groups: return season_data
		import datetime
		today = datetime.date.today().isoformat()
		def _day(e): return (e.get('premiered') or '')[:10]
		rows = [i for i in season_data if i.get('season_number') != 0]
		# each season row's start: TMDb's season date, or a cour's first episode
		starts, season_eps = [], {}
		for r in rows:
			start = r.get('air_date') or ''
			if r.get('_cour_offset'):
				sn = r.get('season_number')
				if sn not in season_eps:
					season_eps[sn] = dict((int(x['episode']), _day(x)) for x in (episodes_meta(sn, meta) or []) if x.get('episode'))
				start = season_eps[sn].get(int(r['_cour_offset']) + 1) or start
			starts.append(start[:10])
		out = list(rows)
		season_names = set(_norm_name(r.get('name')) for r in rows if r.get('name'))
		# oldest first: each lands right before the next season, after the runs already placed in the same gap
		for g in sorted(groups, key=lambda g: (_day(g['eps'][0]) or '9999', int(g['eps'][0]['episode']))):
			first = _day(g['eps'][0])
			if not first: continue
			stem = g['stem']
			if _norm_name(stem) in season_names: stem = _entry_name(meta, g['eps'], stem) or stem
			entry = dict(special)
			entry.update({'episode_count': len(g['eps']), '_cour_offset': int(g['eps'][0]['episode']) - 1, '_cour_len': len(g['eps']),
						'_cour_title': '%s%s' % (_SPECIAL_PREFIX, stem), 'air_date': first, 'name': stem,
						'_special_aired': sum(1 for e in g['eps'] if _day(e) and _day(e) <= today)})
			if len(g['eps']) == 1 and g['eps'][0].get('plot'): entry['overview'] = g['eps'][0]['plot']
			at = next((k for k, s in enumerate(starts) if s and s > first), len(rows))
			# before that season's row (found by identity: two season dicts can compare equal), or at the end
			out.insert(next((k for k, r in enumerate(out) if r is rows[at]), len(out)) if at < len(rows) else len(out), entry)
		return out
	except Exception:
		from modules.kodi_utils import logger
		logger('anime specials', 'airing-order rows failed for tmdb %s' % meta.get('tmdb_id'))
		return season_data


_NUMBERED_LABEL_RE = re.compile(r'^season\s*(\d+)\b', re.I)


_TITLE_SEASON_RE = re.compile(r'(?i)(?<![a-z0-9])(?:(\d{1,2})(?:st|nd|rd|th)\s+season|season\s+(\d{1,2}))(?![a-z0-9])')


def _title_season(title):
	"""LOCAL PATCH 2026-10-16: the season an AniList (romaji) title names -- 'Bungou Stray Dogs 3rd Season' -> 3 -- or None."""
	m = _TITLE_SEASON_RE.search(title or '')
	return int(m.group(1) or m.group(2)) if m else None


def _numbered_label(label, release_season, title_season=None):
	"""LOCAL PATCH 2026-10-09: a bare 'Season N ...' label whose N is not the release season (season.tvdb) becomes
	'Season <release season>' -- AniList's English title can carry a streaming service's numbering. A label whose number
	agrees, or that is a name ('War of the Three Titans Arc'), is kept."""
	m = _NUMBERED_LABEL_RE.match(label or '')
	if not m or not release_season or int(m.group(1)) == int(release_season): return label
	# LOCAL PATCH 2026-10-16: the entry's own AniList title says so ('Bungou Stray Dogs 3rd Season' under TVDB season 2)
	if title_season is not None and int(m.group(1)) == title_season: return label
	return 'Season %s' % release_season


_ROMAN_RE = re.compile(r'^[IVX]+$')
_SMALL_WORDS = {'a', 'an', 'and', 'as', 'at', 'by', 'for', 'in', 'of', 'on', 'or', 'the', 'to', 'vs'}


def _soft_caps(title):
	"""LOCAL PATCH 2026-10-09: a season name TMDb keeps in capitals ('STONE OCEAN'), in title case. Only an all-capitals
	name with 4+ letters is touched (so 'SAO' or 'K' stay); Roman numerals and words with digits keep their case ('PART II'
	-> 'Part II'), small words go lower case after the first, and hyphenated parts are capitalised separately. Brand
	casing cannot be recovered: "JOJO'S" becomes "Jojo's", not "JoJo's"."""
	if not title: return title
	letters = [c for c in title if c.isalpha()]
	if len(letters) < 4 or title != title.upper(): return title
	words = title.split(' ')
	out = []
	for i, word in enumerate(words):
		if _ROMAN_RE.match(word) or any(c.isdigit() for c in word): out.append(word)
		elif i and word.lower() in _SMALL_WORDS: out.append(word.lower())
		else: out.append('-'.join(part[:1].upper() + part[1:].lower() for part in word.split('-')))
	return ' '.join(out)


_BARE_PART_RE = re.compile(r'^(?:part|cour)\s*\d+$', re.I)
_BARE_YEAR_RE = re.compile(r'^\(?(?:19|20)\d{2}\)?$')
_TRAILING_PART_RE = re.compile(r'[\s:\-–—]*(?:part|cour)\s*(?:\d+|one|1st)$', re.I)


def _trim_title_prefix(full, prefix):
	"""`full` with `prefix` and any separator removed, or None if it is not a prefix."""
	if not full or not prefix: return None
	if not full.lower().startswith(prefix.lower()): return None
	return full[len(prefix):].strip(' :-–—.·|/')


def _short_cour_label(full, base, show_title, cour_season, part, part_count, season_number):
	"""A season-row label with the show name taken off the front.

	LOCAL PATCH 2026-08-27. AniList gives the cour's whole name, which is mostly the
	show's: under Frieren the rows read 'Sousou no Frieren' and 'Sousou no Frieren 2nd
	Season'. The row already sits inside the show, so only the tail carries meaning.

	Trimming the FIRST cour's title first is what makes arc names survive -- Bleach's
	cours differ by 'Sennen Kessen-hen - Ketsubetsu-tan', which is worth showing and
	which a generic 'Part 2' would throw away.

	Falls back to the release season number (season.tvdb, so it matches what the
	episodes inside will be numbered as) rather than TMDb's."""
	candidates = []
	for prefix in (base, show_title):
		trimmed = _trim_title_prefix(full, prefix)
		if trimmed: candidates.append(trimmed)
	# Anything still long is the show's name in another language, not a cour marker.
	num = cour_season if cour_season else season_number
	for c in candidates:
		if len(c) > 40: continue
		# LOCAL PATCH 2026-10-12: a remake's AniList title carries its year ('Ranma1/2 (2024)'), so the trim left '(2024)'.
		# A year on its own says nothing the row needs.
		if _BARE_YEAR_RE.match(c): continue
		# 'Part 2' on its own repeats across seasons (Attack on Titan); named arcs are already unique, so only the bare
		# markers get the season put back in front.
		if _BARE_PART_RE.match(c): return 'Season %s %s' % (num, c)
		# LOCAL PATCH 2026-10-16: an English title that is the show's name plus a number ('Bungo Stray Dogs 3') left a bare '3'
		if c.isdigit() and len(c) <= 2: return 'Season %s' % c
		return c
	# Nothing distinguishing left (usually cour 1, whose title IS the show title).
	if part_count and part_count > 1: return 'Season %s Part %s' % (num, part)
	return 'Season %s' % num


def _warm_season_art(meta, current_date=None, current_time=None):
	"""LOCAL PATCH 2026-10-20: run after a season list is on screen (metadata._DEFERRED) for a show whose fanart.tv / TVDB
	season art was not cached: fetches both at once, so the next visit has them. Nothing is shown from here."""
	try:
		from threading import Thread
		from modules.metadata import is_anime_check
		tvdb_id = meta.get('tvdb_id')
		mode = str(settings.get_setting('deadlight.%s.artwork_provider' % ('anime' if is_anime_check(meta) else 'tvshow'), '0'))
		thread = None
		if mode in ('1', '2', '3'):
			from apis.tvdb_api import season_posters
			thread = Thread(target=season_posters, args=(tvdb_id,))
			thread.start()
		if mode == '3':
			from apis.fanart_api import fanart_season_art
			fanart_season_art(tvdb_id)
		if thread is not None: thread.join(25)
	except Exception: pass

def _queue_episode_warm(meta, list_items):
	"""LOCAL PATCH 2026-10-25: the season most likely opened next -- the one the auto-focus lands on: first aired, not
	fully watched, not special -- has its episodes fetched into the meta cache after this list is on screen
	(metadata._DEFERRED), while the user picks a season. Nothing when that season is cached already."""
	try:
		from modules import metadata as _md
		if _md._DEFERRED is None: return
		season = None
		for _u, _li, _isf in list_items:
			info = _li.getVideoInfoTag()
			t = info.getTitle() or ''
			if info.getPlayCount() > 0 or t.startswith('[COLOR red]') or t == 'Specials' or t.startswith(_SPECIAL_PREFIX): continue
			season = info.getSeason()
			break
		if not season or season < 1: return
		from caches.meta_cache import meta_cache
		if meta_cache.get_season('%s_%s' % (meta['tmdb_id'], season)) is not None: return
		def _warm(meta, current_date=None, current_time=None):
			# LOCAL PATCH 2026-10-26: not when the episode list of this season is already being built -- AF3's combined view (527)
			# asks for the focused season 60-80 ms after this list is on screen, so this warm only duplicated the TMDb request.
			# Waits up to 0.6 s for that request to show up; a view with no episode panel shows none, and the season is warmed.
			try:
				from indexers.episodes import EPISODE_LIST_PROP
				import time
				prop = EPISODE_LIST_PROP % (int(meta['tmdb_id']), int(season))
				for _i in range(6):
					time.sleep(0.1)
					started = kodi_utils.get_property(prop)
					if started and time.time() - float(started) < 30: return
				if meta_cache.get_season('%s_%s' % (meta['tmdb_id'], season)) is not None: return
			except Exception: pass
			try: _md.episodes_meta(season, meta)
			except Exception: pass
		_md._DEFERRED.append((meta, None, None, (_warm,)))
	except Exception: pass

def build_season_list(params):
	def _process():
		for item in season_data:
			try:
				cm = []
				cm_append = cm.append
				listitem = make_listitem()
				set_properties = listitem.setProperties
				item_get = item.get
				overview, poster_path, air_date = item_get('overview'), item_get('poster_path'), item_get('air_date')
				season_number, aired_eps = item_get('season_number'), item_get('episode_count')
				season_special = season_number == 0
				# A cour row carries the TMDb season it lives in plus its slice. Its aired count is settled here, before `unaired`
				# is derived, so a cour that has not started yet is greyed out like an unaired season.
				cour_offset, cour_len = item_get('_cour_offset'), item_get('_cour_len')
				is_cour = cour_offset is not None
				if is_cour and item_get('_special_aired') is not None: aired_eps = item_get('_special_aired')   # LOCAL PATCH 2026-10-17
				elif is_cour:
					aired_eps = max(0, min(cour_len, aired_map.get(season_number, cour_len) - cour_offset))
				else:
					# LOCAL PATCH 2026-09-12: a plain season's aired count is settled here too. TMDb's `episode_count` is the DECLARED
					# length, and an announced-but-unaired season is published with a placeholder count of 1, so `unaired` was never true
					# for one (and it could collide with a cour row's display "Season 2"). The running-total correction below runs too
					# late for the drop test.
					# max(0, ...) like the cour branch: the last season's figure is a subtraction and goes NEGATIVE when TMDb's declared
					# counts overshoot total_aired_eps; unclamped, `aired_eps == 0` would read -2 as "aired".
					aired_eps = max(0, aired_map.get(season_number, aired_eps))
				# LOCAL PATCH 2026-08-26: this season's own trailer when TMDb has one (~54% do), else the show trailer hoisted below.
				season_trailer = season_trailer_for(meta, season_number, trailer)
				if is_cour: title = _soft_caps(item_get('_cour_title'))
				elif use_name: title = _soft_caps(item_get('name', None)) or 'Season %s' % season_number
				else: title = 'Season %s' % season_number
				if custom_order is not None: title = '%s - %s' % (show_title, title)
				# LOCAL PATCH 2026-08-27: a cour gets its own AniList cover, so the cours of one TMDb season are distinguishable.
				poster = 'https://image.tmdb.org/t/p/w500%s' % poster_path if poster_path is not None else show_poster
				# LOCAL PATCH 2026-09-14: TVDB's season poster, when TVDB is the chosen provider. BELOW the AniList cour cover
				# deliberately: a TVDB season poster only identifies the TMDb season the cours share.
				# LOCAL PATCH 2026-09-16: keyed on the COUR's tvdb season when there is one (Re:ZERO: one TMDb season, four cours,
				# Fribb season.tvdb 1,2,2,3,4).
				# LOCAL PATCH 2026-09-26: TVDB and/or fanart.tv, merged in provider order -- see _season_posters. The same cour key
				# picks the season landscape.
				_cs = item_get('_cour_tvdb_season')
				if _season_posters:
					poster = (_season_posters.get(_cs) if _cs is not None else None) 							 or _season_posters.get(season_number) or poster
				season_landscape = ((_season_landscapes.get(_cs) if _cs is not None else None)
									or _season_landscapes.get(season_number) or show_landscape)
				poster = item_get('_cour_poster') or poster
				thumb = poster or show_landscape or show_fanart
				try: year = air_date.split('-')[0]
				except: year = show_year or ''
				plot = overview or show_plot
				try: premiered = adjust_premiered_date(air_date, adjust_hours)[1]
				except: premiered = ''
				unaired = aired_eps == 0
				# LOCAL PATCH 2026-08-29: a season with zero aired episodes is dropped rather than listed unplayable (as the episode
				# list and POV's show_unaired do). Specials are exempt: season 0 holds already-aired OVAs and aired_eps can read 0
				# through missing air dates. continue, NOT return: returning would drop every later season too.
				# LOCAL PATCH 2026-09-12: never drop under custom_order -- that path filters season_data to one season and the caller
				# takes list_items[0] (Trakt lists, Continue Watching), so dropping raises IndexError.
				if unaired and not season_special and not include_unaired and custom_order is None: continue
				# LOCAL PATCH 2026-09-03 (Red Light 2.3.1 port): Specials gets its own branch and counts. The rendered values are
				# `watched`/`unwatched` (see set_properties), which a shared branch left holding the previous iteration's tally.
				# Specials are not zeroed: season 0 holds real, already-aired OVAs that can be watched, so it is counted like any
				# season. Only a genuinely unaired season has nothing to count.
				if unaired:
					progress, playcount, watched, unwatched = 0, 0, 0, aired_eps
					title = '[COLOR red][I]%s[/I][/COLOR]' % title
				elif season_special and not is_cour:
					title = 'Specials'
					playcount, watched, unwatched = get_watched_status_season(watched_info.get(season_number, None), aired_eps)
					progress = get_progress_status_season(watched, aired_eps)
				else:
					if is_cour:
						# watched_info_season() counts per TMDb season and cannot be sliced, so a cour is counted from the per-episode rows.
						playcount, watched, unwatched = get_watched_status_season(
							_cour_watched_count(episode_watched_rows, season_number, cour_offset, cour_len), aired_eps)
					else:
						# LOCAL PATCH 2026-10-15: aired_eps was settled above from aired_map (the running total over the UNSPLIT TMDb
						# seasons). Recomputing it here from a count that only plain rows advanced gave the last season the episodes of
						# earlier seasons shown as cour rows.
						playcount, watched, unwatched = get_watched_status_season(watched_info.get(season_number, None), aired_eps)
					progress = get_progress_status_season(watched, aired_eps)
				visible_progress = 0 if progress == 100 else progress
				_ep_list_params = {'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': season_number}
				# `season` stays the TMDb one -- the cour is expressed as a slice of it.
				if is_cour: _ep_list_params.update({'cour_offset': cour_offset, 'cour_len': cour_len,
					  'cour_title': title, 'cour_poster': item_get('_cour_poster') or ''})
				url_params = build_url(_ep_list_params)
				extras_params = build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'tvshow', 'is_external': is_external, 'season': season_number})
				options_params = build_url({'mode': 'options_menu_choice', 'content': 'season', 'tmdb_id': tmdb_id, 'poster': show_poster, 'is_external': is_external})
				cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
				cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
				# LOCAL PATCH 2026-08-29: cour rows get Mark Watched/Unwatched -- mark_season takes the episode range, so marking one
				# cour does not mark its siblings.
				_mark_params = {'mode': 'watched_status.mark_season', 'title': show_title, 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season_number}
				if is_cour: _mark_params.update({'cour_offset': cour_offset, 'cour_len': cour_len})
				# AniList counts progress WITHIN an entry, and an entry is one cour, so the push needs the entry id and how many
				# episodes complete it. For an unsplit season the entry is the whole season, resolved in mark_season from S/E 1.
				_al = item_get('_cour_anilist')
				if _al: _mark_params['anilist_id'] = _al
				if playcount:
					if hide_watched: continue
				elif not unaired:   # LOCAL PATCH 2026-10-19: specials too -- mark_season takes season 0 now
					cm_append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url(dict(_mark_params, action='mark_as_watched')))])
				if progress:
					cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url(dict(_mark_params, action='mark_as_unwatched')))])
				set_properties({'watchedepisodes': str(watched), 'unwatchedepisodes': str(unwatched)})
				set_properties({'totalepisodes': str(aired_eps), 'watchedprogress': str(visible_progress),
								'deadlight.extras_params': extras_params, 'deadlight.options_params': options_params})
				# LOCAL PATCH 2026-10-27: the season's own IMDb rating (vote-weighted over its episodes; a cour row over its
				# own episodes), for AF3's IMDb chip on a season row in place of the show's
				try:
					from modules.metadata import imdb_season_rating
					if is_cour: _imdb_season = imdb_season_rating(imdb_id, season_number, cour_offset + 1, cour_offset + cour_len)
					else: _imdb_season = imdb_season_rating(imdb_id, season_number)
					if _imdb_season: set_properties({'extra_imdb_rating': _imdb_season})
				except Exception: pass
				if is_external:
					cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
							['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
				if custom_cm_menu:
					try: cm = sorted([i for i in cm if i[0] in cm_sort_order], key=lambda k: cm_sort_order[k[0]])
					except: pass
				cm = [i[1] for i in cm]
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setMediaType('season'), info_tag.setTitle(title), info_tag.setOriginalTitle(orig_title), info_tag.setTvShowTitle(show_title), info_tag.setIMDBNumber(imdb_id)
				# A cour row still lives in its TMDb season, but presents the season number releases use -- both Frieren cours are
				# TMDb season 1.
				_display_season = season_number
				if is_cour and not season_special:
					try:
						from modules.metadata import cour_display_numbers
						_display_season = cour_display_numbers(meta, season_number, cour_offset + 1)[0]
					except Exception: pass
				info_tag.setSeason(_display_season), info_tag.setPlot(plot), info_tag.setDuration(episode_run_time), info_tag.setPlaycount(playcount), info_tag.setGenres(genre)
				info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str_tmdb_id, 'tvdb': str_tvdb_id})
				info_tag.setTvShowStatus(status), info_tag.setFirstAired(premiered), info_tag.setStudios(studio), (year and info_tag.setYear(int(year)))
				info_tag.setRating(rating), info_tag.setVotes(votes), info_tag.setMpaa(mpaa), info_tag.setCountries(country), info_tag.setTrailer(season_trailer)
				info_tag.setCast([kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
				listitem.setLabel(title)
				# LOCAL PATCH 2026-09-14: season./tvshow. art keys dropped, see the note at _art in indexers/episodes.py.
				# LOCAL PATCH 2026-09-15: season rows inherit the show's extra_fanart_list like episode rows, so AF3's artwork gallery
				# is not empty on a season.
				_season_art = {'poster': poster, 'fanart': show_fanart, 'clearlogo': show_clearlogo,
								'landscape': season_landscape, 'thumb': thumb, 'icon': season_landscape}
				for _idx, _bg in enumerate(show_extra_fanart, start=1): _season_art['fanart%d' % _idx] = _bg
				listitem.setArt(_season_art)
				listitem.addContextMenuItems(cm)
				yield (url_params, listitem, True)
			except: kodi_utils.log_row_error('seasons')
	kodi_actor, make_listitem, build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
	poster_empty, fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	watched_indicators, adjust_hours, hide_watched = settings.watched_indicators(), settings.date_offset(), is_external and settings.widget_hide_watched()
	current_date = get_datetime()
	cm_sort_order = settings.cm_sort_order()
	custom_cm_menu = cm_sort_order != settings.cm_default_order()
	rpdb_info = settings.rpdb_info('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	use_name = settings.use_season_name()
	include_unaired = settings.include_unaired_episodes()
	meta = tvshow_meta('tmdb_id', params['tmdb_id'], settings.tmdb_api_key(), settings.mpaa_region(), current_date)
	meta_get = meta.get
	tmdb_id, tvdb_id, imdb_id, show_title, show_year = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id'), meta_get('title'), meta_get('year') or ''
	orig_title, status, show_plot = meta_get('original_title', ''), meta_get('status'), meta_get('plot')
	str_tmdb_id, str_tvdb_id, rating, genre = str(tmdb_id), str(tvdb_id), meta_get('rating'), display_genres(meta)
	cast = meta_get('short_cast', []) or meta_get('cast', []) or []
	mpaa, votes, trailer, studio, country = meta_get('mpaa'), meta_get('votes'), str(meta_get('trailer')), meta_get('studio'), meta_get('country')
	episode_run_time, season_data, total_seasons = meta_get('duration'), meta_get('season_data'), meta_get('total_seasons')
	# LOCAL PATCH 2026-09-14: TVDB season posters, resolved once per list build: two cached requests
	# (/series/{id}/artworks and /series/{id}/extended) cover the whole list. The season number has to come from
	# /extended (artworks carry a seasonId, never a number), and only TVDB's OFFICIAL seasons line up with TMDb numbering.
	_season_posters, _season_landscapes = {}, {}
	try:
		from modules.metadata import is_anime_check
		_kind = 'anime' if is_anime_check(meta) else 'tvshow'
		_mode = str(settings.get_setting('deadlight.%s.artwork_provider' % _kind, '0'))
		# LOCAL PATCH 2026-09-26: fanart.tv's `seasonposter` / `seasonthumb` carry a season number in TVDB numbering. Posters
		# merge in provider order: mode 3 prefers fanart.tv's, the TVDB modes TVDB's, each filling the other's gaps; mode 0
		# keeps TMDb's. seasonthumb is the only per-season landscape any provider has (TVDB season art is posters/banners).
		# LOCAL PATCH 2026-10-19: fanart.tv only in mode 3 -- it almost never has season landscapes, and asking for them alone
		# made the list wait up to 2.5 s. TMDb mode asks no one else here, the TVDB modes TVDB.
		_fanart_season = {'poster': {}, 'landscape': {}}
		# LOCAL PATCH 2026-10-20: fanart.tv and TVDB asked AT THE SAME TIME (three cold connections to different hosts).
		# LOCAL PATCH 2026-10-20 (user's call): only what is ALREADY cached. Uncached season art shows TMDb's posters now and
		# is fetched after the list is on screen (_warm_season_art), for the next visit.
		_cold = False
		if _mode == '3':
			from apis.fanart_api import fanart_season_art_cached
			_cached_fanart = fanart_season_art_cached(tvdb_id)
			if _cached_fanart is None: _cold = True
			else: _fanart_season = _cached_fanart
		_season_landscapes = _fanart_season['landscape']
		# LOCAL PATCH 2026-09-16: mode 3 fetches TVDB's too -- ranked by score, the closest TVDB equivalent to "most liked",
		# for the seasons fanart.tv has no poster for.
		if _mode in ('1', '2', '3'):
			from apis.tvdb_api import season_posters_cached
			_tvdb = season_posters_cached(tvdb_id)
			if _tvdb is None: _cold, _tvdb = True, {}
			# the later dict wins; {**a, **b}, not dict(a, **b), which rejects the int season keys
			_season_posters = {**_tvdb, **_fanart_season['poster']} if _mode == '3' else {**_fanart_season['poster'], **_tvdb}
		if _cold:
			from modules import metadata as _md
			if _md._DEFERRED is not None: _md._DEFERRED.append((meta, None, None, (_warm_season_art,)))
		# DIAGNOSTIC 2026-09-14: logs the season art found, not only a failure, so "nothing found" is distinguishable from
		# "the feature is off". LOCAL PATCH 2026-11-01 (cleanup): only with scrape.diag_timing on.
		if settings.diag_timing(): kodi_utils.logger('season_art', 'kind=%s mode=%s tvdb_id=%s posters=%s landscapes=%s%s'
						  % (_kind, _mode, tvdb_id, sorted(_season_posters), sorted(_season_landscapes), ' (not cached: fetched after the list)' if _cold else ''))
	except Exception as e:
		try: kodi_utils.logger('season_art error', '%s: %s' % (type(e).__name__, str(e)[:160]))
		except Exception: pass
	if rpdb_api_key:
		try: show_poster = meta_get('rpdb_poster') % rpdb_api_key + rpdb_format
		except: show_poster = meta_get('poster') or poster_empty
	else: show_poster = meta_get('poster') or poster_empty
	show_fanart = meta_get('fanart') or fanart_empty
	show_extra_fanart = meta_get('extra_fanart_list') or []   # LOCAL PATCH 2026-09-15
	show_clearlogo, show_landscape = meta_get('clearlogo') or '', meta_get('landscape') or ''
	custom_order = params.get('custom_order', None)
	# LOCAL PATCH 2026-10-17: anime has its own specials setting (settings.anime_specials); 'airing' keeps season 0 here and
	# _special_rows turns it into rows after the cour split below
	_specials = settings.show_specials()
	_anime_specials = None
	if custom_order is None:
		try:
			from modules.metadata import is_anime_check
			if is_anime_check(meta): _anime_specials = settings.anime_specials(); _specials = _anime_specials != 'hidden'
		except Exception: pass
	if custom_order is None and _specials: season_data.sort(key=lambda i: (i['season_number'] == 0, i['season_number']))
	elif custom_order is not None: season_data = [i for i in season_data if i['season_number'] == params['season']]
	else:
		season_data = [i for i in season_data if not i['season_number'] == 0]
		season_data.sort(key=lambda k: k['season_number'])
	watched_info = watched_info_season(tmdb_id, get_database(watched_indicators))
	# Anime whose TMDb seasons bundle several cours get one row per cour. Skipped for custom_order, which renders a single
	# season and returns list_items[0] -- splitting there would silently drop the later cours.
	if custom_order is None: season_data = _expand_anime_cours(meta, season_data)
	if _anime_specials == 'airing': season_data = _special_rows(meta, season_data)
	# LOCAL PATCH 2026-09-12: aired_map is built for EVERY show -- _process needs the true aired count to decide `unaired`
	# for plain seasons too. One pass over season_data, no I/O. Per-episode watched rows stay gated on cours.
	aired_map = _aired_per_season(meta_get('season_data') or [], total_seasons, meta_get('total_aired_eps'))
	if any('_cour_offset' in i for i in season_data):
		episode_watched_rows = watched_info_episode(tmdb_id, get_database(watched_indicators))
	else: episode_watched_rows = []
	list_items = list(list(_process()))
	if custom_order is not None: return (list_items[0], custom_order)
	kodi_utils.add_items(handle, list_items)
	kodi_utils.set_content(handle, 'seasons')
	kodi_utils.set_category(handle, show_title)
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	kodi_utils.set_view_mode('view.seasons', 'seasons', is_external)
	if not is_external: _queue_episode_warm(meta, list_items)
	# LOCAL PATCH 2026-08-09: auto-focus the earliest not-fully-watched season (shares the episodes-list autoscroll
	# setting and firing mechanism).
	if not is_external and settings.autoscroll_unwatched():
		try:
			target = None
			for idx, (_u, _li, _isf) in enumerate(list_items):
				try:
					info = _li.getVideoInfoTag()
					if info.getPlayCount() > 0: continue          # fully-watched season
					t = info.getTitle() or ''
					if t.startswith('[COLOR red]') or t == 'Specials' or t.startswith(_SPECIAL_PREFIX): continue  # unaired / specials
					target = idx
					break
				except: continue
			if target: kodi_utils.autoscroll_focus(target, len(list_items))
		except: pass

def single_seasons(seasons_list):
	season_results = []
	threads = TaskPool().tasks(lambda x: season_results.append(build_season_list(x)), seasons_list, min(len(seasons_list), settings.max_threads()))
	[i.join() for i in threads]
	return [i for i in season_results if i]
