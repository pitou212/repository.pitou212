# created by kodifitzwell for Fenomscrapers
"""
	Fenomscrapers Project
"""

import xml.etree.ElementTree as ET
from magneto.modules import client
from magneto.modules import source_utils
from magneto.modules.provider_base import StremioSource

_TORZNAB = {'torznab': 'http://torznab.com/schemas/2015/feed'}


# LOCAL PATCH 2026-11-01 (cleanup): the sources / sources_packs bodies are provider_base.StremioSource's; this file keeps what
# is bitmagnet's own -- its torznab XML answer and sizes that are the pack's (no true_size).
class source(StremioSource):
	provider = 'bitmagnet'
	pack_true_size = False
	base_link = "https://bitmagnetfortheweebs.midnightignite.me"
	movieSearch_link = '/torznab/api?t=movie&imdbid=%s'
	tvSearch_link = '/torznab/api?t=tvsearch&imdbid=%s&season=%s&ep=%s'

	def _fetch(self, url, data, q):
		return ET.fromstring(client.request(url, timeout=self.timeout))

	def _rows(self, files):
		return files.iter('item') if hasattr(files, 'iter') else ()   # wait_future gives [] on a timeout / failed sources()

	def _parse(self, file):
		attr_dict = {'title': file.find('title').text}
		for attr in file.findall('torznab:attr', _TORZNAB):
			key, val = attr.get('name'), attr.get('value')
			if key: attr_dict[key] = val
		return attr_dict['infohash'], [attr_dict['title']], attr_dict

	def _seeders(self, attr_dict):
		return attr_dict['seeders']

	def _size(self, attr_dict):
		return source_utils.convert_size(float(attr_dict['size']))
