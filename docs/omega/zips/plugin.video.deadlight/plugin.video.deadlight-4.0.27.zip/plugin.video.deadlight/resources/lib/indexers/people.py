# -*- coding: utf-8 -*-
from urllib.parse import unquote
from windows.base_window import open_window
from indexers.images import Images

def tmdb_people(params):
	return Images().run({'mode': 'tmdb_people_list_image_results', 'action': params['action'], 'page_no': 1})

def person_search(key_id=None):
	return Images().run({'mode': 'tmdb_people_search_image_results', 'key_id': unquote(key_id), 'page_no': 1})

def favorite_people():
	return Images().run({'mode': 'favorite_people_list_image_results'})

def person_data_dialog(params):
	if 'key_id' in params: key_id = unquote(params.get('key_id'))
	elif 'query' in params: key_id = unquote(params.get('query'))
	else: key_id = None
	open_window(('windows.people', 'People'), 'people.xml', key_id=key_id, actor_name=params.get('actor_name'), actor_image=params.get('actor_image'),
				actor_id=params.get('actor_id'), reference_tmdb_id=params.get('reference_tmdb_id'), is_external=params.get('is_external', 'false'),
				starting_position=params.get('starting_position', None))

# LOCAL PATCH 2026-11-12: the cast of a title as a plain list, for AF3's playback OSD (Down during playback, window 1141). It
# used TMDb Helper's cast route until the skin dropped TMDb Helper; this reads the cast DeadLight already caches with the
# title's meta (movie_meta / tvshow_meta: name, role, h632 photo), so a title whose details were seen costs no API call.
# Episodes pass the show's id (the player sets the show's tmdb id on an episode). An item opens DeadLight's person window
# by name, with the title as the reference that picks the right person when names clash. xbmcplugin is called directly:
# kodi_utils.add_items / end_directory would note the OSD list as a widget for the reload / prefetch service.
def osd_cast(params):
	import sys
	import xbmcplugin
	from modules import kodi_utils, settings
	from modules.utils import get_datetime
	handle = int(sys.argv[1])
	media_type, tmdb_id = params.get('media_type', 'movie'), params.get('tmdb_id', '')
	cast = []
	if tmdb_id.isdigit():
		from modules.metadata import movie_meta, tvshow_meta
		meta_function = movie_meta if media_type == 'movie' else tvshow_meta
		try: meta = meta_function('tmdb_id', tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime()) or {}
		except Exception: meta = {}
		cast = (meta.get('cast') or meta.get('short_cast') or [])[:30]
	items = []
	for person in cast:
		name = person.get('name') or ''
		if not name: continue
		role, photo = person.get('role') or '', person.get('thumbnail') or ''
		url = kodi_utils.build_url({'mode': 'person_data_dialog', 'query': name, 'actor_name': name, 'actor_image': photo,
									'reference_tmdb_id': tmdb_id})
		listitem = kodi_utils.make_listitem()
		listitem.setLabel(name)
		listitem.setLabel2(role)
		art = photo or 'DefaultActor.png'
		listitem.setArt({'icon': art, 'thumb': art, 'poster': art})
		listitem.setProperty('role', role)
		items.append((url, listitem, False))
	xbmcplugin.addDirectoryItems(handle, items)
	xbmcplugin.setContent(handle, 'actors')
	xbmcplugin.endOfDirectory(handle, cacheToDisc=False)



