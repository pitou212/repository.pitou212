# -*- coding: utf-8 -*-
import os
import re
import sys
import ssl
import json
from threading import Thread
from urllib.request import Request, urlopen
from urllib.parse import parse_qsl, urlparse, unquote
from modules import kodi_utils
from modules.sources import Sources
from modules.settings import download_directory
from modules.source_utils import clean_title
from modules.utils import clean_file_name, safe_string, remove_accents, normalize, safe_filename

def _log(message):
	# LOCAL PATCH 2026-11-07: downloads logged nothing, so a failed one left no trace in kodi.log
	kodi_utils.logger('downloader', message)

# LOCAL PATCH 2026-10-25 (4.0.5): a verifying TLS context. ssl.SSLContext(PROTOCOL_SSLv23) checked no certificate at
# all; certifi's bundle (Kodi ships script.module.certifi) is used when present, the system store otherwise.
def _ssl_context():
	try:
		import certifi
		return ssl.create_default_context(cafile=certifi.where())
	except Exception: return ssl.create_default_context()

def runner(params):
	action = params.get('action')
	if action == 'image':
		for item in ('thumb_url', 'image_url'):
			image_params = params
			image_params['url'] = params.pop(item)
			image_params['media_type'] = item
			Downloader(image_params).run()
	elif action == 'meta.pack':
		from modules.source_utils import find_season_in_release_title
		provider = params['provider']
		# LOCAL PATCH 2026-10-03: same message as Browse Pack, instead of 'No URL found' (sources.debridPacks)
		if str(provider).startswith('Uncached'):
			return kodi_utils.notification('Pack not cached on %s yet' % str(provider).replace('Uncached', '', 1).strip())
		try:
			debrid_files, debrid_function = Sources().debridPacks(provider, params['name'], params['magnet_url'], params['info_hash'], download=True)
			pack_choices = [dict(params, **{'pack_files':item}) for item in debrid_files]
			icon = {'Real-Debrid': 'realdebrid', 'Premiumize.me': 'premiumize', 'AllDebrid': 'alldebrid', 'TorBox': 'torbox'}[provider]   # LOCAL PATCH 2026-10-03: was 'Torbox' -- every TorBox pack download fell into the except
		except: return kodi_utils.notification('No URL found for Download. Pick another Source.')
		default_icon = kodi_utils.get_icon(icon)
		chosen_list = select_pack_item(pack_choices, default_icon)
		if not chosen_list: return
		show_package = json.loads(params['source']).get('package') == 'show'
		meta  = json.loads(chosen_list[0].get('meta'))
		image = meta.get('poster') or kodi_utils.get_icon('box_office')
		default_name = '%s (%s)' % (clean_file_name(get_title(meta)), get_year(meta))
		default_foldername = kodi_utils.kodi_dialog().input('Title', defaultt=default_name)
		multi_downloads = []
		multi_downloads_append = multi_downloads.append
		for item in chosen_list:
			if show_package:
				season = find_season_in_release_title(item['pack_files']['filename'])
				if season:
					meta['season'] = season
					item['meta'] = json.dumps(meta)
					item['default_foldername'] = default_foldername
			multi_downloads_append((Thread(target=Downloader(item).run), clean_file_name(item['pack_files']['filename'])))
		download_threads_manager(multi_downloads, image)
	else: Downloader(params).run()

def download_threads_manager(multi_downloads, image):
	kodi_utils.notification('Multi File Pack Download Started...', 3500, image)
	started_downloads = []
	started_downloads_append = started_downloads.append
	for item in multi_downloads:
		while len([x for x in multi_downloads if x[0].is_alive()]) >= 2:
			kodi_utils.sleep(2000)
			continue
		item[0].start()
		started_downloads_append(item)
		remaining_downloads = [x[1] for x in multi_downloads if not x in started_downloads]
		kodi_utils.set_property('deadlight.active_queued_downloads', json.dumps(remaining_downloads))
	kodi_utils.clear_property('deadlight.active_queued_downloads')

def select_pack_item(pack_choices, icon):
	list_items = [{'line1': '%.2f GB | %s' % (float(item['pack_files']['size'])/1073741824, clean_file_name(item['pack_files']['filename']).upper()), 'icon': icon} \
				for item in pack_choices]
	heading = 'Choose Files to Download - %s' % clean_file_name(json.loads(pack_choices[0].get('source')).get('name'))
	kwargs = {'items': json.dumps(list_items), 'heading': heading, 'enumerate': 'true', 'multi_choice': 'true'}
	return kodi_utils.select_dialog(pack_choices, **kwargs)

def get_title(meta):
	title = meta.get('custom_title', None) or meta.get('english_title') or meta.get('title')	
	return title

def get_year(meta):
	return meta.get('custom_year', None) or meta.get('year')

def get_season(meta):
		season = meta.get('custom_season', None) or meta.get('season')
		return int(season) if season not in (None, '') else None

class Downloader:
	def __init__(self, params):
		self.params = params
		self.params_get = self.params.get

	def run(self):
		# LOCAL PATCH 2026-11-07: a pack's files run in threads, where an exception dies silently. Logged, with a notification.
		try: self._run()
		except Exception as e:
			_log('failed: %s: %s (%s)' % (type(e).__name__, e, self.params_get('name') or ''))
			try:
				if getattr(self, 'final_name', None): self.remove_active_download()   # no dead row left in the manager
			except Exception: pass
			self.return_notification(_notification='Download failed: %s' % type(e).__name__)

	def _run(self):
		self.download_prep()
		if not self.action == 'meta.pack': kodi_utils.show_busy_dialog()
		self.get_url_and_headers()
		if self.url in (None, 'None', ''):
			_log('no url: action %s, provider %s%s' % (self.action, self.provider, ', ' + self.link_error if self.link_error else ''))
			return self.return_notification(_notification='No link for download%s. Pick another source.' % (' (%s)' % self.link_error if self.link_error else ''))
		self.get_filename()
		self.get_extension()
		if not self.download_check():
			if self.media_type == 'thumb_url': return
			return self.return_notification(_ok_dialog='Failed')
		if not self.confirm_download(): return self.return_notification(_notification='Cancelled')
		self.get_download_folder()
		if not self.get_destination_folder(): return self.return_notification(_notification='Cancelled')
		self.download_runner()

	def download_prep(self):
		if 'meta' in self.params:
			self.meta = json.loads(self.params_get('meta'))
			self.meta_get = self.meta.get
			self.media_type = self.meta_get('media_type')
			self.title = clean_file_name(get_title(self.meta))
			self.year = get_year(self.meta)
			self.season = get_season(self.meta)
			self.image = self.meta_get('poster') or kodi_utils.get_icon('box_office')
			self.name = self.params_get('name')
		else:
			self.meta, self.name, self.year, self.season = None, None, None, None
			self.media_type = self.params_get('media_type')
			self.title = clean_file_name(self.params_get('name'))
			self.image = self.params_get('image')
		self.provider = self.params_get('provider')
		self.action = self.params_get('action')
		self.source = self.params_get('source')
		self.final_name = None
		self.link_error, self.last_response_error, self.mb, self.resumable = '', '', 0, False

	def download_runner(self):
		self.final_destination = os.path.join(self.final_destination, self.final_name + self.extension)
		self.add_active_download()
		_log('start: %s (%d MB, resumable %s) -> %s' % (self.final_name, self.mb, self.resumable, self.final_destination))
		# LOCAL PATCH 2026-11-07: nothing said a download had begun (user) -- a notification as it starts, with its size
		if self.action != 'image':
			import time
			kodi_utils.set_property('deadlight.download_started', str(time.time()))
			# LOCAL PATCH 2026-11-08: close the source list it was started from (windows/sources: onInit stores the id, the
			# Download File / Pack choice arms it) -- only that window, and only while it is still showing
			if kodi_utils.get_property('deadlight.close_sources_on_download') == 'true':
				kodi_utils.clear_property('deadlight.close_sources_on_download')
				self.close_source_list(kodi_utils.get_property('deadlight.sources_window_id'))
			kodi_utils.notification('Download started (%d MB): %s' % (self.mb, self.final_name.replace('.', ' ').replace('_', ' ')), 4000, self.image)
		self.start_download()

	def close_source_list(self, window_id):
		"""LOCAL PATCH 2026-11-08: close the source list this download was started from, by pressing Back on it -- the list's own
		onAction then sets its result and close()s, so its doModal() returns and the caller removes the scraping screen. This
		plugin call runs in its own Python interpreter, so the window object is out of reach; and Dialog.Close(id, force) removes
		the window without waking doModal(). Back goes only to a list that is the top window (a stacked dialog is left alone); a
		second Back covers an applied filter, which the first one only clears."""
		import xbmcgui
		try: window_id = int(window_id)
		except (TypeError, ValueError): return _log('no source list recorded')
		for _ in range(3):
			if xbmcgui.getCurrentWindowDialogId() != window_id:
				return _log('closed the source list (%s)' % window_id) if _ else _log('source list not on top (%s)' % window_id)
			kodi_utils.execute_builtin('Action(Back)')
			kodi_utils.sleep(400)
		_log('source list still open after Back x3 (%s)' % window_id)

	def get_active_downloads(self):
		return json.loads(kodi_utils.get_property('deadlight.active_downloads') or '[]')

	def add_active_download(self):
		if self.action == 'image': return
		active_downloads = self.get_active_downloads()
		active_downloads.append(self.final_name)
		kodi_utils.set_property('deadlight.active_downloads', json.dumps(active_downloads))

	def remove_active_download(self):
		if self.action == 'image': return
		active_downloads = self.get_active_downloads()
		try: active_downloads.remove(self.final_name)
		except: pass
		if active_downloads: kodi_utils.set_property('deadlight.active_downloads', json.dumps(active_downloads))
		else: self.clear_active_downloads()

	def clear_active_downloads(self):
		kodi_utils.clear_property('deadlight.active_downloads')

	def set_percent_property(self, percent):
		kodi_utils.set_property('deadlight.%s' % self.final_name, str(percent))

	def check_status(self):
		status = kodi_utils.get_property('deadlight.download_status.%s' % self.final_name)
		if status in ('unpaused', 'cancelled'): kodi_utils.clear_property('deadlight.download_status.%s' % self.final_name)
		return status

	def get_url_and_headers(self):
		self.link_error = ''
		url = self.params_get('url')
		if url in (None, 'None', ''):
			if self.action == 'meta.single':
				try:
					source = json.loads(self.source)
					if source.get('scrape_provider', '') == 'easynews': source['url_dl'] = source['down_url']
					url = Sources().resolve_sources(source, meta=self.meta)
					if 'torbox' in url:
						from apis.torbox_api import TorBoxAPI
						url = TorBoxAPI().add_headers_to_url(url)
				except: pass
			elif self.action == 'meta.pack':
				if self.provider == 'Real-Debrid':
					from apis.real_debrid_api import RealDebridAPI as debrid_function
				elif self.provider == 'Premiumize.me':
					from apis.premiumize_api import PremiumizeAPI as debrid_function
				elif self.provider == 'AllDebrid':
					from apis.alldebrid_api import AllDebridAPI as debrid_function
				elif self.provider == 'TorBox':
					from apis.torbox_api import TorBoxAPI as debrid_function
				url = self.params_get('pack_files')['link']
				if self.provider in ('Real-Debrid', 'AllDebrid'):
					url = debrid_function().unrestrict_link(url)
				elif self.provider == 'Premiumize.me':
					url = debrid_function().add_headers_to_url(url)
				elif self.provider == 'TorBox':
					# LOCAL PATCH 2026-11-07: a refused link is None -- add_headers_to_url(None) raised TypeError; keep TorBox's reason
					tb = debrid_function()
					url = tb.unrestrict_link(url)
					if url: url = tb.add_headers_to_url(url)
					else: self.link_error = str(getattr(tb, 'last_dl_error', '') or 'TorBox refused the link')
		else:
			if self.action.startswith('cloud'):
				if '_direct' in self.action:
					url = self.params_get('url')
				elif 'realdebrid' in self.action:
					from indexers.real_debrid import resolve_rd
					url = resolve_rd(self.params)
				elif 'alldebrid' in self.action:
					from indexers.alldebrid import resolve_ad
					url = resolve_ad(self.params)
				elif 'premiumize' in self.action:
					from apis.premiumize_api import PremiumizeAPI
					url = PremiumizeAPI().add_headers_to_url(url)
				elif 'torbox' in self.action:
					from apis.torbox_api import TorBoxAPI
					from indexers.torbox import resolve_tb
					url = resolve_tb(self.params)
					url = TorBoxAPI().add_headers_to_url(url)
				elif 'easynews' in self.action:
					from indexers.easynews import resolve_easynews
					url = resolve_easynews(self.params)
		if not url:
			self.url, self.headers = None, {}
			return
		try: headers = dict(parse_qsl(url.rsplit('|', 1)[1]))
		except: headers = dict('')
		try: url = url.split('|')[0]
		except: pass
		# LOCAL PATCH 2026-11-07: Direct Streams hosts refuse Python's own User-Agent (HTTP 403 where playback works). A
		# browser one unless the link carries its own (http_streams.direct_url_alive does too).
		if not any(k.lower() == 'user-agent' for k in headers): headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
		self.url = url
		self.headers = headers

	def get_download_folder(self):
		self.down_folder = download_directory(self.media_type)
		if self.media_type == 'thumb_url': self.down_folder = os.path.join(self.down_folder, '.thumbs')
		for level in ['../../../..', '../../..', '../..', '..']:
			try: kodi_utils.make_directory(os.path.abspath(os.path.join(self.down_folder, level)))
			except: pass

	def get_destination_folder(self):
		if self.action == 'image':
			self.final_destination = self.down_folder
		elif self.action in ('meta.single', 'meta.pack'):
			default_name = '%s (%s)' % (self.title, self.year)
			if self.action == 'meta.single': folder_rootname = kodi_utils.kodi_dialog().input('Title', defaultt=default_name)
			else: folder_rootname = self.params_get('default_foldername', default_name)
			if not folder_rootname: return False
			if self.media_type == 'episode':
				inter = os.path.join(self.down_folder, folder_rootname)
				kodi_utils.make_directory(inter)
				self.final_destination = os.path.join(inter, 'Season %02d' %  int(self.season))
			else: self.final_destination = os.path.join(self.down_folder, folder_rootname)
		else: self.final_destination = self.down_folder
		kodi_utils.make_directory(self.final_destination)
		return True

	def get_filename(self):
		if self.final_name: final_name = self.final_name
		elif self.action == 'meta.pack':
			name = self.params_get('pack_files')['filename']
			final_name = os.path.splitext(urlparse(name).path)[0].split('/')[-1]
		elif self.action == 'image':
			final_name = self.title
		else:
			name_url = unquote(self.url)
			file_name = clean_title(name_url.split('/')[-1])
			if clean_title(self.title).lower() in file_name.lower():
				final_name = os.path.splitext(urlparse(name_url).path)[0].split('/')[-1]
			else:
				# LOCAL PATCH 2026-11-07: not self.name (the show's rootname, the same for every episode, so files overwrote each
				# other). The source's release name, else Title SxxEyy.
				release = ''
				try: release = json.loads(self.source).get('name') or ''
				except Exception: pass
				if release: final_name = os.path.splitext(release)[0] if os.path.splitext(release)[1][1:].lower() in kodi_utils.video_extensions() else release
				elif self.media_type == 'episode' and self.meta:
					final_name = '%s S%02dE%02d' % (self.title, int(self.meta_get('season') or 0), int(self.meta_get('episode') or 0))
				else:
					try: final_name = self.name.translate(str.maketrans('', '', r'\/:*?"<>|')).strip('.')
					except: final_name = os.path.splitext(urlparse(name_url).path)[0].split('/')[-1]
		# LOCAL PATCH 2026-10-25 (4.0.5): the name comes from a url / release title -- keep only its last component on
		# either separator (a backslash survived split('/')) and drop '..' and the characters Windows refuses
		final_name = safe_string(remove_accents(final_name))
		self.final_name = safe_filename(final_name.replace('\\', '/').split('/')[-1], 'download')

	def get_extension(self):
		if self.action == 'archive':
			ext = 'zip'
		elif self.action == 'image':
			ext = os.path.splitext(urlparse(self.url).path)[1][1:]
			if not ext in kodi_utils.image_extensions(): ext = 'jpg'
		else:
			# LOCAL PATCH 2026-11-07: a TorBox / debrid link has no extension in its path, so the pack file's own name, then the
			# release name, come before the 'mp4' fallback.
			video_exts = kodi_utils.video_extensions()
			candidates = [urlparse(self.url).path]
			if self.action == 'meta.pack':
				try: candidates.append(self.params_get('pack_files')['filename'])
				except Exception: pass
			try: candidates.append(json.loads(self.source).get('name') or '')
			except Exception: pass
			candidates.append(self.name or '')
			ext = next((e for e in (os.path.splitext(str(c))[1][1:].lower() for c in candidates) if e in video_exts), 'mp4')
		ext = '.%s' % ext
		self.extension = ext

	_CONTENT_TYPE_EXT = {'video/x-matroska': 'mkv', 'video/mp4': 'mp4', 'video/webm': 'webm', 'video/x-msvideo': 'avi', 'video/quicktime': 'mov',
						 'video/mpeg': 'mpg', 'video/x-flv': 'flv', 'video/x-ms-wmv': 'wmv', 'video/mp2t': 'ts'}

	def extension_from_response(self):
		"""LOCAL PATCH 2026-11-08: the host's own word on the container: the file name in Content-Disposition, else Content-Type.
		The guesses in get_extension (url path, pack file, release name) can all come up empty for a TorBox file (no extension
		in the link, '.mkv' stripped from the release name). The guess stays as the fallback; what the host sent is logged."""
		if self.action in ('image', 'archive'): return
		try:
			headers = self.resp.headers
			disposition, ctype = headers.get('Content-Disposition') or '', (headers.get('Content-Type') or '').split(';')[0].strip().lower()
			video_exts = kodi_utils.video_extensions()
			match = re.search(r'''filename\*?=(?:[\w-]+'')?["']?([^"';]+)''', disposition)
			ext = os.path.splitext(unquote(match.group(1)))[1][1:].lower() if match else ''
			if ext not in video_exts: ext = self._CONTENT_TYPE_EXT.get(ctype, '')
			_log('host says: content-type %r, disposition %r -> %s' % (ctype, disposition[:80], ext or 'nothing; keeping ' + self.extension))
			if ext in video_exts: self.extension = '.%s' % ext
		except Exception as e: _log('extension from the response failed: %r' % e)

	def download_check(self):
		self.resp = self.get_response()
		if not self.resp:
			_log('no response from the file host: %s' % self.last_response_error)
			return False
		self.extension_from_response()
		try: self.content = int(self.resp.headers['Content-Length'])
		except: self.content = 0
		try: self.resumable = 'bytes' in self.resp.headers['Accept-Ranges'].lower()
		except: self.resumable = False
		if self.content < 1: return False
		self.size = 1024 * 1024
		self.mb = self.content / (1024 * 1024)
		if self.content < self.size: self.size = self.content
		kodi_utils.hide_busy_dialog()
		return True

	def start_download(self):
		monitor_progress = self.action != 'image'
		total, errors, count, resume, sleep_time  = 0, 0, 0, 0, 0
		f = kodi_utils.open_file(self.final_destination, 'w')
		chunk  = None
		chunks = []
		while True:
			downloaded = total
			for c in chunks: downloaded += len(c)
			percent = min(round(float(downloaded)*100 / self.content), 100)
			if monitor_progress:
				status = self.check_status()
				if status == 'paused':
					while status == 'paused':
						status = self.check_status()
						kodi_utils.sleep(1000)
				if status == 'cancelled': return self.finish_download(status, f)
				if percent % 5 == 0: self.set_percent_property(percent)
			chunk = None
			error = False
			try:        
				chunk  = self.resp.read(self.size)
				if not chunk:
					if percent < 99:
						error = True
					else:
						while len(chunks) > 0:
							c = chunks.pop(0)
							f.write(c)
							del c
						f.close()
						return self.finish_download('success')
			except Exception as e:
				error = True
				sleep_time = 10
				errno = 0
				if hasattr(e, 'errno'):
					errno = e.errno
				if errno == 10035: # 'A non-blocking socket operation could not be completed immediately'
					pass
				if errno == 10054: #'An existing connection was forcibly closed by the remote host'
					errors = 10 #force resume
					sleep_time = 30
				if errno == 11001: # 'getaddrinfo failed'
					errors = 10 #force resume
					sleep_time = 30
			if chunk:
				errors = 0
				chunks.append(chunk)
				if len(chunks) > 5:
					c = chunks.pop(0)
					f.write(c)
					total += len(c)
					del c
			if error:
				errors += 1
				count  += 1
				kodi_utils.sleep(sleep_time*1000)
			if (self.resumable and errors > 0) or errors >= 10:
				if (not self.resumable and resume >= 50) or resume >= 500:
					return self.finish_download('failed', f)
				resume += 1
				errors  = 0
				if self.resumable:
					chunks  = []
					self.resp = self.get_response(total)
				else: pass

	def get_response(self, size=0):
		try:
			headers = self.headers
			if size > 0:
				size = int(size)
				headers['Range'] = 'bytes=%d-' % size
			req = Request(self.url, headers=headers)
			resp = urlopen(req, context=_ssl_context(), timeout=30)
			return resp
		except Exception as e:
			self.last_response_error = '%s: %s' % (type(e).__name__, getattr(e, 'code', '') or getattr(e, 'reason', '') or '')
			return None

	def finish_download(self, status, f=None):
		# LOCAL PATCH 2026-11-07: a cancelled or failed download left the file open and the partial file on disk, and its
		# percent / status properties in Home for good
		if f is not None:
			try: f.close()
			except Exception: pass
		if status != 'success':
			try: kodi_utils.delete_file(self.final_destination)
			except Exception: pass
		if self.action == 'image':
			if self.media_type == 'image_url': return kodi_utils.notification(status.upper(), 2500, self.final_destination)
			else: return
		_log('%s: %s' % (status, self.final_name))
		if status == 'success':   # LOCAL PATCH 2026-11-08: the downloads manager's Completed section (modules/completed_downloads)
			try:
				from modules import completed_downloads
				completed_downloads.add(self.final_name.replace('.', ' ').replace('_', ' '), self.final_destination, self.mb, self.image, self.media_type)
			except Exception as e: _log('completed record failed: %s' % e)
		for prop in ('deadlight.%s' % self.final_name, 'deadlight.download_status.%s' % self.final_name): kodi_utils.clear_property(prop)
		if not kodi_utils.get_visibility('Window.IsActive(fullscreenvideo)'):
			kodi_utils.notification('[B]%s[/B] %s' % (status.upper(), self.final_name.replace('.', ' ').replace('_', ' ')), 2500, self.image)
		self.remove_active_download()

	def confirm_download(self):
		return True if self.action in ('image', 'meta.pack') \
		else kodi_utils.confirm_dialog(heading=self.final_name, text='Complete file is [B]%dMB[/B][CR]Continue with download?' % self.mb)

	def return_notification(self, _notification=None, _ok_dialog=None):
		kodi_utils.hide_busy_dialog()
		if _notification: kodi_utils.notification(_notification, 2500)
		elif _ok_dialog: kodi_utils.ok_dialog(text=_ok_dialog)
		else: return

def viewer(params):
	def _process():
		for info in results:
			try:
				path = info[0]
				url = os.path.join(folder_path, path)
				listitem = kodi_utils.make_listitem()
				listitem.setLabel(clean_file_name(normalize(path)))
				listitem.setArt({'fanart': fanart})
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setPlot(' ')
				yield (url, listitem, info[1])
			except: pass
	handle = int(sys.argv[1])
	fanart = kodi_utils.get_addon_fanart()
	folder_path = download_directory(params['folder_type'])
	dirs, files = kodi_utils.list_dirs(folder_path)
	results = [(i, True) for i in dirs] + [(i, False) for i in files]
	item_list = list(_process())
	kodi_utils.add_items(handle, item_list)
	kodi_utils.set_sort_method(handle, 'files')
	kodi_utils.set_content(handle, '')
	kodi_utils.set_category(handle, params.get('name'))
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.main', '')

def manager(foo=None):
	from windows.base_window import open_window
	kwargs = {}
	return open_window(('windows.downloads_manager', 'DownloadsManager'), 'downloads_manager.xml', **kwargs)
