# -*- coding: utf-8 -*-
"""SmartPlay's release identity and its same-release test (LOCAL PATCH 2026-11-09).

A pin used to be only its name, re-read at every match: a name with no readable group (4KHDHub cuts names at 100
characters; fansub names carry none) skipped the same-release tier, and a cut tail read as a group ('-4kH', '-D',
'-NEW') could never match again. Now the identity is read once, from the best name there is, when the pick is saved,
and a field a name cannot state is UNKNOWN -- never a mismatch.

Imported by modules/sources.py's SmartPlay paths only (list builders read pins through smartplay_utils.pinned_ids)."""
import re
from modules.source_utils import (release_group, same_group, release_source, release_norm, release_service,
	release_dynamic_range, get_release_quality, name_was_cut)

IDENTITY_VERSION = 2   # 2: release_group reads a comma-less bracket tail after a codec ('H.264-VARYG.(...)'); audio upload
# 4KHDHub cuts the release name it lists at 100 characters; an uncut one ends in its extension
HDHUB_CUT = 100
_VIDEO_EXT = re.compile(r'\.(?:mkv|mp4|avi|m4v|ts|m2ts|webm|mov)$', re.I)
# host tags in front of a Direct Streams name, and the ' <host> | <site>' line after it, as rows and pins carried them
# before 4.0.25 ('[PixelDrain] Dead-End.Job.S01E01...', '... FSL-V2 | 4KHDHub')
_HOST_TAGS = re.compile(r'^\s*(?:\[(?:pixeldrain|fsl|fslv2|fsl-v2|hubcdn|hubcloud|gdflix|gofile|direct)\]\s*)+', re.I)
_DECORATION = re.compile(r'\s+\S+\s*\|\s*[^|]*$')
# a site that stamps every file it serves with its own name ('-4kHdHub.Com', '-HDHub4u.Ms'): not a releaser
SITE_GROUPS = frozenset(('4khdhub', 'hdhub4u', 'hdhub'))
_CODEC = (('hevc', re.compile(r' (?:[xh] ?265|hevc) ')), ('avc', re.compile(r' (?:[xh] ?264|avc) ')), ('av1', re.compile(r' av1 ')))
# one group's MULTi and DUAL audio uploads of an episode are different files (VARYG posts both)
# ('Multi-Subs' is subtitles, not the audio upload)
_AUDIO = (('multi', re.compile(r' multi (?!subs? )')), ('dual', re.compile(r' dual (?!subs? )')))


def clean_name(name):
	"""The release name without the host decorations older Direct Streams rows and pins carry."""
	n = _HOST_TAGS.sub('', (name or '').strip())
	if '|' in n: n = _DECORATION.sub('', n)
	return n.strip()


def was_cut(name, provider=''):
	"""True when the name lost its end to 4KHDHub's cut: the old decorated form, or a Direct Streams name of the cut length
	with no extension."""
	if name_was_cut(name): return True
	n = clean_name(name)
	return provider == 'http_streams' and len(n) >= HDHUB_CUT - 1 and not _VIDEO_EXT.search(n)


def _first(table, norm):
	for value, pattern in table:
		if pattern.search(norm): return value
	return ''


def identity(name, provider='', hoster='', file_name=''):
	"""What a release is, as far as its name says. '' = the name does not say (unknown, not different)."""
	n = clean_name(name)
	cut = was_cut(name, provider)
	norm = release_norm(n)
	group = '' if cut else release_group(n)
	if group in SITE_GROUPS: group = ''
	# a debrid pack row is named by the torrent; the file picked inside often names the group the torrent name lacks
	if not group and file_name:
		file_group = release_group(file_name)
		if file_group not in SITE_GROUPS: group = file_group
	rng = release_dynamic_range(n)
	if cut and rng == 'sdr': rng = ''   # the cut usually falls right where DV.HDR would be
	return {'v': IDENTITY_VERSION, 'group': group or '', 'source': release_source(norm), 'quality': get_release_quality(n.lower()) or '',
			'service': release_service(norm), 'range': rng, 'codec': _first(_CODEC, norm), 'audio': _first(_AUDIO, norm), 'provider': provider or '',
			'hoster': (hoster or '').lower(), 'cut': cut}


def of_item(item):
	return identity(item.get('name') or '', item.get('scrape_provider') or '', item.get('hoster') or '', item.get('file_name') or '')


def of_pin(state):
	"""A pin's identity: the one saved with it, or read from its name for a pin saved before identities existed."""
	ident = state.get('identity')
	if isinstance(ident, dict) and ident.get('v') == IDENTITY_VERSION: return ident
	return identity(state.get('last_name') or '', state.get('scrape_provider') or '', state.get('hoster') or '')


def refusal(pin, cand):
	"""'' when `cand` is the pin's release (episode is the caller's test), else the one axis that refused it.

	quality  must be equal.
	group    equal when both names state one (a 3+ character prefix counts, see source_utils.same_group). A group on ONE
	         side only is refused: another releaser's copy is a different release, whatever else agrees (2026-11-09:
	         a VARYG pin whose group did not parse followed the episode to a ToonsHub copy). When NEITHER states one, the
	         release is the same only if the rest pins it down: both name the same service, or the copy comes from the pin's
	         own provider AND host.
	source / service / range   refused only when both names state them and they differ."""
	if pin['quality'] != cand['quality']: return 'quality'
	if pin['group'] or cand['group']:
		if not same_group(pin['group'], cand['group']): return 'group'
	elif not ((pin['service'] and pin['service'] == cand['service'])
			  or (pin['provider'] and pin['provider'] == cand['provider'] and pin['hoster'] and pin['hoster'] == cand['hoster'])):
		return 'group'
	if pin['source'] and cand['source'] and pin['source'] != cand['source']: return 'source'
	if pin['service'] and cand['service'] and pin['service'] != cand['service']: return 'service'
	if pin['range'] and cand['range'] and pin['range'] != cand['range']: return 'dynamic_range'
	return ''


def rank(pin, cand, size):
	"""Sort key among copies of the pin's release, best first with reverse=True: the pin's provider, then its host, then a
	copy that SAYS the pin's HDR format, then its codec (4KHDHub posts every episode as H.264 and H.265), then its audio
	upload (MULTi / DUAL), then its service, then the largest file (the real one, not a sample)."""
	return (bool(pin['provider']) and cand['provider'] == pin['provider'],
			bool(pin['hoster']) and cand['hoster'] == pin['hoster'],
			bool(pin['range']) and cand['range'] == pin['range'],
			bool(pin['codec']) and cand['codec'] == pin['codec'],
			bool(pin.get('audio')) and cand.get('audio') == pin.get('audio'),
			bool(pin['service']) and cand['service'] == pin['service'],
			size or 0)


def fill_from(new, old):
	"""A new pin's unknown fields from the previous pin's, when both are the same kind of release (quality, provider and
	service agree) -- the pin follows each episode, and one cut name must not erase what the earlier ones stated."""
	if not old or old.get('v') != IDENTITY_VERSION: return new
	if (new['quality'], new['provider'], new['service']) != (old.get('quality'), old.get('provider'), old.get('service')): return new
	out = dict(new)
	for key in ('group', 'source', 'range', 'codec', 'audio'):
		if not out.get(key) and old.get(key): out[key] = old[key]
	return out


def describe(ident):
	return 'group=%s source=%s quality=%s service=%s range=%s codec=%s audio=%s%s' % (ident['group'] or '?', ident['source'] or '?',
		ident['quality'] or '?', ident['service'] or '-', ident['range'] or '?', ident['codec'] or '?', ident.get('audio') or '-',
		' cut' if ident['cut'] else '')
