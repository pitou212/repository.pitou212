# -*- coding: utf-8 -*-
import xbmc
import json
import time
from threading import Thread
from apis.trakt_api import make_trakt_slug
from caches.settings_cache import get_setting
from modules import kodi_utils as ku, settings as st, watched_status as ws

def _log_trace(tag, what):
	try:
		import traceback
		ku.logger(tag, '%s: %s' % (what, traceback.format_exc()))
	except Exception: pass

# LOCAL PATCH 2026-08-21: window property bridging "how did playback end?" to the next-episode handler. A property,
# not an attribute: autoplay_nextep_handler runs on a NEW Sources() instance and never sees the player's sources_object.
PLAYBACK_STOPPED_PROP = 'deadlight.playback_user_stopped'
# LOCAL PATCH 2026-08-26: marker for stops WE perform (autoplay handoff, stop-at-credits, failed-resolve teardown).
# Kodi fires onPlayBackStopped for those exactly as for a user Stop; without it our own handoff counted as a user
# stop and suppressed the next-episode play / SmartPlay fallback.
INTERNAL_STOP_PROP = 'deadlight.playback_internal_stop'
# LOCAL PATCH 2026-09-24: seconds from the end at the player loop's LAST sample, published on exit. Tells an episode
# that reached its end from a stream that died partway: Kodi reports a dying stream as onPlayBackEnded, never a Stop.
PLAYBACK_LAST_REMAINING_PROP = 'deadlight.playback_last_remaining'
# A drop in remaining time larger than this between two one-second samples is a jump, not
# playback -- see monitor().
NEXTEP_JUMP_SECONDS = 30
# LOCAL PATCH 2026-10-13: chapter names that mark a skippable segment (see _chapter_segments): exact names after
# trimming -- 'Opening' / 'OP 2' / 'Intro', 'Recap' / 'Previously on ...'. Never 'Prologue' or 'Avant': a cold open
# is the episode itself.
# LOCAL PATCH 2026-10-23: credits too, plus anime spellings ('OP1', 'ED 2', 'Ending: <song>', 'Staff Roll', Japanese).
# A keyword at the start and at most a number or ': title' after it, so 'Preview', 'Eyecatch', 'Chapter 4' never match.
import re
_CHAPTER_NAME_TAIL = r'(?:\s*\d+)?(?:\s*[:\-–—|]\s*.*)?$'
_CHAPTER_SEGMENT_RES = (
	('intro', re.compile(r'^(?:op|opening|intro|introduction|opening (?:credits|titles?|theme|song|sequence)|op (?:song|theme)|'
		r'title sequence|main titles?|オープニング)' + _CHAPTER_NAME_TAIL, re.I)),
	('outro', re.compile(r'^(?:ed|ending|outro|credits|end credits|closing credits|end titles|ending (?:credits|theme|song|sequence)|'
		r'ed (?:song|theme)|staff roll|エンディング|スタッフロール)' + _CHAPTER_NAME_TAIL, re.I)),
	('recap', re.compile(r'^(?:recap|previously(?: on\b.*)?|summary|あらすじ)$', re.I)),
)
# a credits chapter may run long (live-action crawls) or to the end of the file; skipping it never cuts story
_CHAPTER_OUTRO_MAX = 420
# LOCAL PATCH 2026-10-14: a named chapter longer than this is not an opening or a recap. Releases that mark only where
# the intro STARTS leave it running to the next marker (an 'Intro' chapter of 20 minutes). Real openings run ~90 s.
_CHAPTER_SEGMENT_MAX = 240

def _chapter_starts(values, count):
	"""Chapter start positions (percent) from Kodi's Player.Chapters, which is NOT a list of starts: it is start,end PAIRS,
	one per gap between consecutive markers, the first from 0 -- chapters at 0 / 70 s / 1275 s of 1430 s read
	'0,4.9,4.9,89.2'. So the starts are 0 plus every pair's end, de-duplicated; when the first chapter does not begin at 0
	that leading 0 is not a chapter, and Player.ChapterCount tells the two cases apart."""
	markers = sorted(set([0.0] + values[1::2]))
	if count and len(markers) == count + 1: markers = markers[1:]
	return markers


def mark_internal_stop():
	"""Call immediately BEFORE any DeadLight-initiated player.stop()."""
	# LOCAL PATCH 2026-10-18: a timestamp, not 'true'. onPlayBackStopped arrives ~2.5 s after stop(), and
	# clear_playback_properties cleared a bare flag before then, so our own stops were recorded as user stops.
	try: ku.set_property(INTERNAL_STOP_PROP, str(time.time()))
	except: pass

def _internal_stop_recent(window=15.0):
	value = ku.get_property(INTERNAL_STOP_PROP)
	if not value: return False
	try: return time.time() - float(value) < window
	except ValueError: return value == 'true'


_CHAPTER_GAP = 0.3   # % of the bar left empty at each chapter break (~4 px on AF3's OSD bar)
# LOCAL PATCH 2026-10-24: the span names' share of AF3's 1464 px OSD bar -- the widths of its
# extras/progress/label_*.png (RECAP 61, INTRO 57, CREDITS 78 px).
_OSD_LABEL_PCT = {'recap': 4.17, 'intro': 3.89, 'outro': 5.33}
# LOCAL PATCH 2026-10-27: a recap opens an episode; one starting after the first third is a mislabelled segment and is
# dropped from the Skip Recap button and the OSD bar. Judged here because the API layer has no runtime.
_RECAP_MAX_START = 1 / 3.0

def _late_recap(stype, start, total):
	return stype == 'recap' and bool(total) and start is not None and start > total * _RECAP_MAX_START

# LOCAL PATCH 2026-10-28: the credits of THIS file. An outro list holds a second entry only when introdb.app and
# theintrodb.org disagree (introdb_api._alternate_outro), each often timed on another cut. The first wins unless it
# ends past the file and the other fits. Always one entry back, so no reader shows two credits spans or Skip buttons.
def _outro_for_file(segs, total):
	segs = list(segs or [])
	if len(segs) < 2 or not total: return segs
	def fits(seg):
		end = seg[1] if len(seg) > 1 else None
		# LOCAL PATCH 2026-11-07 (Red Light 2.9.9): credits cannot start in the first half of the file
		return seg[0] is not None and total * 0.5 <= seg[0] < total and (end is None or end <= total + 2)
	if fits(segs[0]): return segs[:1]
	return [next((s for s in segs[1:] if fits(s)), segs[0])]
_SNAP_SECONDS = 10   # an intro / credits edge this close to a chapter break is moved onto it


def _snap_to_chapter(chapters, pct, total):
	"""LOCAL PATCH 2026-10-22: a recap / intro / credits edge onto the nearest chapter break within _SNAP_SECONDS, so the
	mark and the chapter agree on the bar instead of being drawn a few seconds apart."""
	limit = _SNAP_SECONDS / float(total) * 100
	best = None
	for a, b in chapters:
		for edge in (a, b):
			if 0 < edge < 100 and abs(edge - pct) <= limit and (best is None or abs(edge - pct) < abs(best - pct)): best = edge
	return pct if best is None else best


def _cut_at_chapters(chapters, start, end, min_piece=0.01):
	"""LOCAL PATCH 2026-10-22: the part of [start%, end%] inside each chapter, one piece per chapter (player.
	_publish_osd_segments), each pulled back half a gap from a chapter break -- the gap is in the numbers, so the skin
	draws plain rectangles: a bordered texture never draws narrower than its two borders (GUITexture.cpp) and spilled a
	short chapter over its own gap. A piece's moving end (the play head, the buffer) is not pulled back. min_piece drops
	slivers: an intro starting 2 s before its chapter would leave a dot."""
	out, half = [], _CHAPTER_GAP / 2
	for a, b in chapters:
		lo, hi = max(a, start), min(b, end)
		if lo == a and a > 0: lo += half
		if hi == b and b < 100: hi -= half
		if hi - lo > min_piece: out.append((lo, hi))
	return out


class DeadLightPlayer(xbmc.Player):
	def __init__ (self):
		xbmc.Player.__init__(self)

	# ── Kodi playback-end callbacks ─────────────────────────────────────────
	# Without these there was no way to tell "user pressed Stop" from "episode reached its end".
	# NOTE: Kodi delivers these ~2.5s after isPlayingVideo() flips, too late to gate autoplay_nextep_handler on their
	# own (that uses a position test). They remain the authoritative verdict for anything that polls, e.g.
	# NextEpisode.monitor() dismissing an open alert on Stop.
	def onPlayBackStopped(self):
		# Fires for BOTH a user pressing Stop and any stop we perform ourselves. Only the
		# former is a real "user stopped" verdict -- see INTERNAL_STOP_PROP above.
		try:
			if _internal_stop_recent():
				ku.clear_property(INTERNAL_STOP_PROP)
				ku.clear_property(PLAYBACK_STOPPED_PROP)
			else:
				ku.set_property(PLAYBACK_STOPPED_PROP, 'true')
		except: pass

	def onPlayBackEnded(self):
		# File played through to its natural end — next-episode alert is wanted.
		try: ku.clear_property(PLAYBACK_STOPPED_PROP)
		except: pass

	def onPlayBackStarted(self):
		# New file started; clear any verdict left over from the previous one.
		try: ku.clear_property(PLAYBACK_STOPPED_PROP)
		except: pass

	def run(self, url=None, obj=None):
		ku.hide_busy_dialog()
		self.clear_playback_properties()
		if not url: return self.run_error()
		try: return self.play_video(url, obj)
		except Exception:
			_log_trace('player.run', 'play_video failed')   # LOCAL PATCH 2026-10-15: was a bare 'Playback Failed' with no reason
			return self.run_error()

	def play_video(self, url, obj):
		self.set_constants(url, obj)
		ku.volume_checker()
		self.play(self.url, self.make_listing())
		if not self.is_generic:
			self.check_playback_start()
			if self.playback_successful: self.monitor()
			else:
				self.sources_object.playback_successful = self.playback_successful
				self.sources_object.cancel_all_playback = self.cancel_all_playback
				# LOCAL PATCH 2026-07-02: propagate user_cancelled distinct from cancel_all_playback so the sticky path can tell
				# "user pressed Back on resolve dialog" from "playback failed silently".
				self.sources_object.user_cancelled = getattr(self, 'user_cancelled', False)
				if self.cancel_all_playback: self.kill_dialog()
				mark_internal_stop()   # LOCAL PATCH 2026-08-26
				self._wait_until_open_settles()
				self.stop()
			try: del self.kodi_monitor
			except: pass

	def _wait_until_open_settles(self, limit=30.0):
		"""LOCAL PATCH 2026-09-27: never stop() while Kodi is still OPENING the file -- a stop() 0.8 s after OpenFile
		(e.g. a Back press on the resolver) freezes Kodi until restarted. So wait until the player has either got the stream
		running or let go of it, then stop. Bounded; a player holding nothing returns at once."""
		waited = 0.0
		try:
			while waited < limit and self.isPlaying() and not self.kodi_monitor.abortRequested():
				try:
					if self.isPlayingVideo() and float(self.getTotalTime() or 0) > 0: break
				except Exception: pass
				ku.sleep(100)
				waited += 0.1
		except Exception: pass
		if waited >= 0.5: ku.logger('playback stop', 'held stop() %.1fs until the file finished opening' % waited)

	def _playback_confirmed(self):
		"""True once Kodi is really PLAYING the file, not merely opening it.
		LOCAL PATCH 2026-09-06: shared by the isPlayingVideo branch and the timeout branch."""
		try:
			return bool(self.isPlayingVideo() and self.getTotalTime() not in ('0.0', '', 0.0, None)
				and ku.get_visibility('Window.IsActive(fullscreenvideo)'))
		except Exception:
			return False

	def check_playback_start(self):
		resolve_percent = 0
		self.user_cancelled = False
		# LOCAL PATCH 2026-09-06: extra loop iterations granted ONLY while Kodi already has the file open --
		# 400 * 50ms = 20s on top of the counter (~21s wall). See the branch below.
		open_grace = 400
		# LOCAL PATCH 2026-11-08: Kodi's busy spinner is closed every 4th tick (200 ms), not every tick.
		_tick = 0
		while self.playback_successful is None:
			if _tick % 4 == 0: ku.hide_busy_dialog()
			_tick += 1
			if not self.sources_object.progress_dialog: self.playback_successful = True
			elif self.sources_object.progress_dialog.skip_resolved(): self.playback_successful = False
			elif self.sources_object.progress_dialog.iscanceled() or self.kodi_monitor.abortRequested():
				# LOCAL PATCH 2026-07-02: user_cancelled True on progress-dialog cancel (Back press); left False on abortRequested
				# -- only sticky-fallback reads it, and that never runs during shutdown.
				self.cancel_all_playback, self.playback_successful, self.user_cancelled = True, False, True
			# LOCAL PATCH 2026-09-06: don't fail outright when the counter runs out. A stop() while the demuxer is still opening
			# deadlocks Kodi, and _playback_confirmed() (isPlayingVideo AND getTotalTime() > 0 AND fullscreenvideo) stays false
			# for many seconds on a healthy-but-slow open. So: if Kodi holds the file open, keep waiting (bounded by open_grace);
			# if the grace runs out while it is STILL open, hand off to monitor() rather than stop() mid-open. Only a player
			# holding nothing is failed here, where stop() has nothing to race.
			elif resolve_percent >= 100:
				if self._playback_confirmed(): self.playback_successful = True
				elif not self.isPlaying(): self.playback_successful = False
				elif open_grace > 0:
					# LOCAL PATCH 2026-09-07: log entry and exhaustion of the grace so a real slow open leaves evidence.
					if open_grace == 400: ku.logger('playback grace', 'resolve counter expired with the file still opening; holding up to 20s instead of stopping')
					open_grace -= 1
					resolve_percent = 99.74
				else:
					ku.logger('playback grace', 'grace exhausted with the file still open; handing to monitor() rather than calling stop()')
					self.playback_successful = True
			elif ku.get_visibility('Window.IsTopMost(okdialog)'):
				ku.execute_builtin('SendClick(okdialog, 11)')
				self.playback_successful = False
			elif self.isPlayingVideo():
				if self._playback_confirmed(): self.playback_successful = True
			resolve_percent = round(resolve_percent + 26.0/100, 1)
			# LOCAL PATCH 2026-09-27: resolve_percent is also this loop's timeout counter, so it keeps its value; the bar SHOWS
			# it mapped onto this source's slice (sources.play_file sets _bar_span), continuing from where the resolve left it.
			_lo, _hi = getattr(self.sources_object, '_bar_span', (0.0, 100.0))
			# the dialog can be gone (the first branch above sets success for exactly that case); an AttributeError here
			# would reach run_error and fail a playing file
			if self.sources_object.progress_dialog:
				# rounded: the bar moves 0.26 a tick, so most ticks would rewrite the same value
				self.sources_object.progress_dialog.update_resolver(percent=round(_lo + (_hi - _lo) * min(resolve_percent, 100.0) / 100.0, 1))
			ku.sleep(50)

	def playback_close_dialogs(self):
		self.sources_object.playback_successful = True
		# LOCAL PATCH 2026-09-15: write the SmartPlay pin here, not when the source was picked: this runs once, from
		# monitor()'s isPlayingVideo() loop, the earliest honest moment to call a source good. Not at playback END: the pin is
		# read by the NEXT episode while monitor() is still running. playing_item is whichever source play_file actually got
		# playing (it falls through the list when a pick fails).
		try:
			_so = self.sources_object
			if getattr(_so, 'sticky_pending', False):
				_so.sticky_pending = False
				_so._sticky_save(getattr(_so, 'playing_item', None))
		except Exception: pass
		self.kill_dialog()
		ku.sleep(200)
		ku.close_all_dialog()

	def monitor(self):
		try:
			ensure_dialog_dead, total_check_time = False, 0
			if self.media_type == 'episode':
				play_random_continual = self.sources_object.random_continual
				play_random = self.sources_object.random
				disable_autoplay_next_episode = self.sources_object.disable_autoplay_next_episode
				if disable_autoplay_next_episode: ku.notification('Scrape with Custom Values - Autoplay Next Episode Cancelled', 4500)
				if any((play_random_continual, play_random, disable_autoplay_next_episode)): self.autoplay_nextep, self.autoscrape_nextep = False, False
				else: self.autoplay_nextep, self.autoscrape_nextep = self.sources_object.autoplay_nextep, self.sources_object.autoscrape_nextep
			else:
				show_stinger, stinger_use_chapters, stingers_percentage_fallback = st.stingers_show(), st.stingers_use_chapters(), st.stingers_percentage()
				play_random_continual, self.autoplay_nextep, self.autoscrape_nextep = False, False, False
			while total_check_time <= 30 and not ku.get_visibility('Window.IsActive(fullscreenvideo)'):
				ku.sleep(100)
				total_check_time += 0.10
			ku.hide_busy_dialog()
			# LOCAL PATCH 2026-09-26: a fixed second. Polling isPlayingVideo() / getTime() > 0 dropped the resolver cover before
			# the first frame was on screen (Kodi reports a position slightly early): a black flash between autoplayed episodes.
			ku.sleep(1000)
			# LOCAL PATCH 2026-09-05: the playback.auto_enable_subs setting is gone (it forced subtitles on for every file and
			# duplicated a near-identically named row); subtitles.auto_enable enables display only when the scraper below
			# actually selected or downloaded a track.
			# LOCAL PATCH 2026-08-30: automatic subtitle download (ported from POV). Threaded and self-gating -- it sleeps 2s
			# before touching subtitle state, so it must not hold up the playback loop. Off unless subtitles.auto_download.
			try:
				from indexers.subtitles import SubtitleScraper
				Thread(target=SubtitleScraper(self, self.meta_get('poster', '')).run).start()
			except Exception: pass
			if self.media_type == 'episode': Thread(target=self._playing_episode_ratings).start()   # LOCAL PATCH 2026-10-22
			last_remaining = None   # LOCAL PATCH 2026-09-24: see NEXTEP_JUMP_SECONDS
			while self.isPlayingVideo():
				try:
					if not ensure_dialog_dead:
						ensure_dialog_dead = True
						self.playback_close_dialogs()
					ku.sleep(1000)
					# 2026-09-26: playback can end during the sleep; asking for the time then makes Kodi log
					# 'EXCEPTION: Kodi is not playing any media file'.
					if not self.isPlayingVideo(): break
					try: self.total_time, self.curr_time = self.getTotalTime(), self.getTime()
					except: ku.sleep(250); continue
					self.current_point = round(float(self.curr_time/self.total_time * 100), 1)
					try: self._check_skip_segments()
					except: pass
					if self.current_point >= self.watched_tick_percent:
						if play_random_continual: self.run_random_continual(); break
						if not self.media_marked: self.media_watched_marker()
					if self.media_type == 'episode':
						if self.autoplay_nextep or self.autoscrape_nextep:
							if not self.nextep_info_gathered: self.info_next_ep()
							# LOCAL PATCH 2026-10-23: info_next_ep() runs ~2 s in, before many streams report their chapters, so the timing
							# fell back to the percentage. Retried once, at 30 s.
							elif not getattr(self, '_nextep_chapter_retry', False) and self.curr_time >= 30:
								self._nextep_chapter_retry = True
								self._retry_nextep_chapter_timing()
							# LOCAL PATCH 2026-09-12: break only when an episode actually followed. start_prep fires scraper_time BEFORE
							# outro_start, so an unconditional break killed the per-second _check_skip_segments before curr_time reached
							# outro_start, and stop_at_credits_no_next could never fire on a finale. Attempted once -- next_episode_info() costs
							# a metadata lookup.
							# LOCAL PATCH 2026-09-24: a near-end reading reached by a JUMP is confirmed on the next sample before it counts. A
							# dying stream makes Kodi report the end (position leaps past start_prep, player already closed on 'eof reading from
							# demuxer'); a real seek near the end is still playing one second later, a dead stream has no next sample.
							remaining = round(self.total_time - self.curr_time)
							jumped = last_remaining is not None and (last_remaining - remaining) > NEXTEP_JUMP_SECONDS
							if not self.nextep_handoff_attempted and remaining <= self.start_prep:
								if jumped:
									ku.logger('NextEp', 'remaining jumped %ss -> %ss; confirming on the next sample' % (last_remaining, remaining))
								else:
									self.nextep_handoff_attempted = True
									# a hand-off leaves this loop while the video still PLAYS, so its
									# position says nothing about how playback ended -- not published
									if self.run_next_ep(): last_remaining = None; break
							last_remaining = remaining
					elif show_stinger and not self.movie_stingers_run: 
						final_chapter = (self.final_chapter(75) or stingers_percentage_fallback) if stinger_use_chapters else stingers_percentage_fallback
						if self.current_point >= final_chapter: self.run_movie_stingers()
				# LOCAL PATCH 2026-10-15: logged, once per distinct error -- a raise in info_next_ep / run_next_ep here silently
				# meant no Next Episode alert and no handoff.
				except Exception as e:
					if repr(e) != getattr(self, '_loop_err', None):
						self._loop_err = repr(e)
						_log_trace('player.monitor', 'monitor tick failed')
			ku.hide_busy_dialog()
			# LOCAL PATCH 2026-09-03: the loop has exited, so playback is OVER -- tell the marker, and refresh here when the
			# mark already landed earlier (at 90%, or from stop-at-credits).
			if not self.media_marked: self.media_watched_marker(playback_over=True)
			else: self._refresh_after_playback()
			self.clear_playback_properties()
			# LOCAL PATCH 2026-09-24: AFTER clear_playback_properties (which also runs at playback start), so the value always
			# belongs to the file that just ended.
			if last_remaining is not None:
				try: ku.set_property(PLAYBACK_LAST_REMAINING_PROP, str(last_remaining))
				except Exception: pass
				ku.logger('NextEp', 'playback loop exit: %ss from the end' % last_remaining)
			if getattr(self, 'active_skip_window', None):
				try: self.active_skip_window.request_close()
				except: pass
				self.active_skip_window = None
		except:
			_log_trace('player.monitor', 'monitor failed')   # LOCAL PATCH 2026-10-25 (4.0.5): was a bare except, no log line
			ku.hide_busy_dialog()
			self.sources_object.playback_successful = False
			self.sources_object.cancel_all_playback = True
			return self.kill_dialog()

	def make_listing(self):
		listitem = ku.make_listitem()
		listitem.setPath(self.url)
		listitem.setContentLookup(False)
		if self.is_generic:
			info_tag = listitem.getVideoInfoTag(True)
			info_tag.setMediaType('video')
			info_tag.setFilenameAndPath(self.url)
		else:
			self.tmdb_id, self.imdb_id, self.tvdb_id = self.meta_get('tmdb_id', ''), self.meta_get('imdb_id', ''), self.meta_get('tvdb_id', '')
			self.media_type, self.title, self.year = self.meta_get('media_type'), self.meta_get('title'), self.meta_get('year')
			self.season, self.episode = self.meta_get('season', ''), self.meta_get('episode', '')
			poster = self.meta_get('poster') or ku.get_icon('box_office')
			fanart = self.meta_get('fanart') or ku.get_addon_fanart()
			clearlogo = self.meta_get('clearlogo') or ''
			from modules.metadata import display_genres   # LOCAL PATCH 2026-10-07: AniList tags on anime
			duration, genre, trailer, mpaa = self.meta_get('duration'), display_genres(self.meta) or '', self.meta_get('trailer'), self.meta_get('mpaa')
			rating, votes = self.meta_get('rating'), self.meta_get('votes')
			premiered, studio, tagline = self.meta_get('premiered'), self.meta_get('studio', ''), self.meta_get('tagline')
			director, writer, country = self.meta_get('director', ''), self.meta_get('writer', ''), self.meta_get('country', '')
			cast = self.meta_get('short_cast', []) or self.meta_get('cast', []) or []
			listitem.setLabel(self.title)
			if self.media_type == 'movie':
				plot = self.meta_get('plot')
				listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo})
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setMediaType('movie'), info_tag.setTitle(self.title), info_tag.setOriginalTitle(self.meta_get('original_title')), info_tag.setPlot(plot)
				info_tag.setYear(int(self.year or 0)), info_tag.setRating(rating), info_tag.setVotes(votes), info_tag.setMpaa(mpaa)
				info_tag.setDuration(duration), info_tag.setCountries(country), info_tag.setTrailer(trailer), info_tag.setPremiered(premiered)
				info_tag.setTagLine(tagline), info_tag.setStudios(studio), info_tag.setIMDBNumber(self.imdb_id), info_tag.setGenres(genre)
				info_tag.setWriters(writer), info_tag.setDirectors(director), info_tag.setUniqueIDs({'imdb': self.imdb_id, 'tmdb': str(self.tmdb_id)})
				info_tag.setCast([ku.kodi_actor()(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
				# LOCAL PATCH 2026-11-11: the movie's IMDb rating for AF3's OSD chip too (deadlight.osd.imdb, as for episodes), from
				# the OMDb ratings in the meta -- TMDb Helper's Player ratings filled it before AF3 dropped TMDb Helper. Always
				# set, so an episode's value never stays behind for a movie. OMDb's missing values arrive as '%' / 'N/A'.
				_movie_imdb = ''
				try:
					_v = float(str(((self.meta_get('extra_ratings') or {}).get('imdb') or {}).get('rating') or 0))
					if _v > 0: _movie_imdb = '%.1f' % _v
				except (TypeError, ValueError): pass
				ku.set_property('deadlight.osd.imdb', _movie_imdb)
			else:
				if st.avoid_episode_spoilers() and int(self.meta_get('playcount') or 0) == 0: plot = self.meta_get('tvshow_plot') or '* Hidden to Prevent Spoilers *'
				else: plot = self.meta_get('plot') or self.meta_get('tvshow_plot')
				# LOCAL PATCH 2026-09-14: no tvshow. art keys -- AF3's OSD and TMDbHelper read Player.Art(poster) / Art(clearlogo).
				listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo})
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setMediaType('episode'), info_tag.setTitle(self.meta_get('ep_name')), info_tag.setOriginalTitle(self.meta_get('original_title'))
				# LOCAL PATCH 2026-08-27: the OSD shows the numbering the viewer recognises. self.season/self.episode stay TMDb's
				# elsewhere -- they key the bookmark, the watched mark and the Trakt/Simkl scrobble.
				try:
					from modules.metadata import cour_display_numbers
					_ds, _de = cour_display_numbers(self.meta, self.season, self.episode)
				except Exception: _ds, _de = self.season, self.episode
				info_tag.setTvShowTitle(self.title), info_tag.setTvShowStatus(self.meta_get('status')), info_tag.setSeason(_ds), info_tag.setEpisode(_de)
				info_tag.setPlot(plot), info_tag.setYear(int(self.year or 0))
				# LOCAL PATCH 2026-10-19: the EPISODE's ratings, not the show's -- AF3's OSD shows VideoPlayer.Rating as the episode
				# chip (show chips come from TMDbHelper.Player.*). Default IMDb, else TMDb, else Trakt; none carries none.
				_ep_ratings = {}
				for _name, _value, _votes in (('imdb', self.meta_get('ep_imdb_rating'), 0), ('tmdb', self.meta_get('ep_rating'), self.meta_get('ep_votes')),
											  ('trakt', self.meta_get('ep_trakt_rating'), 0)):
					try:
						if float(_value or 0) > 0: _ep_ratings[_name] = (float(_value), int(_votes or 0))
					except (TypeError, ValueError): pass
				if _ep_ratings: info_tag.setRatings(_ep_ratings, next(n for n in ('imdb', 'tmdb', 'trakt') if n in _ep_ratings))
				# LOCAL PATCH 2026-10-24: AF3's OSD IMDb chip reads this, not VideoPlayer.Rating(imdb): with no IMDb rating Kodi
				# answers Rating(imdb) with the item's default rating (TMDb's).
				ku.set_property('deadlight.osd.imdb', '%.1f' % _ep_ratings['imdb'][0] if 'imdb' in _ep_ratings else '')
				info_tag.setMpaa(mpaa), info_tag.setDuration(duration), info_tag.setTrailer(trailer), info_tag.setFirstAired(premiered)
				info_tag.setStudios(studio), info_tag.setIMDBNumber(self.imdb_id), info_tag.setGenres(genre), info_tag.setWriters(writer)
				info_tag.setDirectors(director), info_tag.setUniqueIDs({'imdb': self.imdb_id, 'tmdb': str(self.tmdb_id), 'tvdb': str(self.tvdb_id)})
				info_tag.setCast([ku.kodi_actor()(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
				info_tag.setFilenameAndPath(self.url)
			self.set_resume_point(listitem)
			self.set_playback_properties()
		return listitem

	def media_watched_marker(self, force_watched=False, playback_over=False):
		# LOCAL PATCH 2026-10-25 (4.0.5): media_marked is set on success, or on the second attempt whatever happens (the
		# monitor loop calls this every second until it is set), so a raise does not lose the mark silently.
		self._mark_attempts = getattr(self, '_mark_attempts', 0) + 1
		if self._mark_attempts >= 2: self.media_marked = True
		# LOCAL PATCH 2026-09-03: the write below runs in a Thread, so refreshing here would race the DB insert and redraw
		# the STALE indicator. run_media_progress consumes the flag once the write has returned.
		if playback_over and not getattr(self, 'playback_chained', False): self.refresh_when_marked = True
		try:
			# getattr: the generic-video path skips the reset block above.
			if self.current_point >= getattr(self, 'watched_tick_percent', 90) or force_watched:
				watched_function = ws.mark_movie if self.media_type == 'movie' else ws.mark_episode
				watched_params = {'action': 'mark_as_watched', 'tmdb_id': self.tmdb_id, 'title': self.title, 'year': self.year, 'season': self.season, 'episode': self.episode,
									'tvdb_id': self.tvdb_id, 'from_playback': 'true'}
				Thread(target=self.run_media_progress, args=(watched_function, watched_params)).start()
				# LOCAL PATCH 2026-07-29: SIMKL secondary scrobble when SIMKL is authorized, scrobble is on and it is NOT the
				# primary provider -- keeps Trakt/MDBList/local primary while cross-syncing.
				try:
					if st.simkl_user_active() and st.simkl_scrobble_enabled() and st.watched_indicators() != 3:
						Thread(target=self._simkl_scrobble).start()
				except Exception: pass
				# LOCAL PATCH 2026-08-29: AniList anime scrobble, independent of SIMKL (AniList keeps the anime identity SIMKL
				# loses). Self-gates on a Fribb hit, so regular TV costs one offline dict lookup and no thread.
				try:
					if st.anilist_user_active() and st.anilist_scrobble_enabled():
						Thread(target=self._anilist_scrobble).start()
				except Exception: pass
				# LOCAL PATCH 2026-10-02: MyAnimeList, independent of AniList -- own thread, own switch.
				try:
					if st.mal_user_active() and st.mal_scrobble_enabled():
						Thread(target=self._mal_scrobble).start()
				except Exception: pass
			else:
				ku.clear_property('deadlight.random_episode_history')
				if self.current_point >= 5:
					progress_params = {'media_type': self.media_type, 'tmdb_id': self.tmdb_id, 'curr_time': self.curr_time, 'total_time': self.total_time,
									'title': self.title, 'season': self.season, 'episode': self.episode, 'from_playback': 'true'}
					Thread(target=self.run_media_progress, args=(ws.set_bookmark, progress_params)).start()
			self.media_marked = True
		except: _log_trace('player.mark', 'media_watched_marker failed (attempt %d)' % self._mark_attempts)

	def run_media_progress(self, function, params):
		try: function(params)
		except Exception:   # LOCAL PATCH 2026-10-15: a lost watched mark / resume point used to leave no trace
			_log_trace('player.progress', '%s %s failed' % (getattr(function, '__name__', function), params.get('tmdb_id') if isinstance(params, dict) else ''))
		# LOCAL PATCH 2026-09-03: the mark is committed by the call above, so this is the first safe moment to redraw
		# (covers the bookmark branch too).
		if getattr(self, 'refresh_when_marked', False):
			self.refresh_when_marked = False
			self._refresh_after_playback()

	# LOCAL PATCH 2026-09-03: hook for redrawing the container once playback has finished.
	def _refresh_after_playback(self):
		# LOCAL PATCH 2026-11-08: deliberately a no-op (refreshing the list is Kodi's job, not DeadLight's). Kodi rebuilds the
		# list itself on the way back from fullscreen; an extra refresh emptied it as Kodi refocused it (blank screen until a
		# key press). Kept so its callers stay as they are.
		return

	# LOCAL PATCH 2026-07-29: SIMKL side-channel scrobble, mirroring watched_status.mark_* for the primary provider.
	# Only invoked when SIMKL is NOT primary (watched_indicators != 3).
	def _simkl_scrobble(self):
		try:
			from apis.simkl_api import simkl_mark_watched
			if self.media_type == 'movie':
				simkl_mark_watched('movies', 'tmdb', int(self.tmdb_id))
			else:
				try: season, episode = int(self.season), int(self.episode)
				except: return
				seasons = [{'number': season, 'episodes': [{'number': episode}]}]
				simkl_mark_watched('shows', 'tmdb', int(self.tmdb_id), seasons=seasons)
				# LOCAL PATCH 2026-09-19: advance the cour here too (cross-sync path; the primary one is watched_status.mark_episode).
				try:
					from apis.simkl_api import simkl_advance_cour
					simkl_advance_cour(self.tmdb_id, season, episode)
				except Exception: pass
		except Exception: _log_trace('scrobble', 'SIMKL %s failed' % self.tmdb_id)   # LOCAL PATCH 2026-10-25 (4.0.5): was silent

	# LOCAL PATCH 2026-08-29: AniList progress push. Anime only; a Fribb miss means "not anime, do nothing".
	# Routed through Fribb because AniList counts progress WITHIN an entry, and an entry is one cour:
	#   Frieren TMDb S01E30 -> entry 182255, progress 2 (cour 2 restarts at 1)
	def _anime_entry(self):
		"""LOCAL PATCH 2026-10-05: {'anilist', 'mal', 'cour_ep', 'via'} for the episode just watched, or {} (not anime, or
		no entry found). Fribb first; for a show Fribb has not mapped yet, the AniList entry that starts this TMDb season
		(apis.anilist_api.anilist_entry_for_tmdb_episode, the scrape's own fallback)."""
		if self.media_type == 'movie' or not self.tmdb_id: return {}
		try: season, episode = int(self.season), int(self.episode)
		except (TypeError, ValueError): return {}
		if getattr(self, '_anime_entry_memo', None) is not None: return self._anime_entry_memo
		entry = {}
		# LOCAL PATCH 2026-11-01: a special (season 0). Fribb maps none; the Watch Order's air-date mapping, run in reverse,
		# names its entry (anilist_lists.special_entry_for_episode)
		if season == 0:
			try:
				from indexers.anilist_lists import special_entry_for_episode
				entry = special_entry_for_episode(self.tmdb_id, episode) or {}
			except Exception: entry = {}
			self._anime_entry_memo = entry
			return entry
		try:
			from caches import fribb_mappings
			cour = fribb_mappings.find_cour_by_tmdb_coords(int(self.tmdb_id), season, episode) or {}
			# an episode past its entry's length is not in it: TMDb folded a later season in after Fribb mapped it -- the scrape
			# treats it the same way
			try:
				if cour.get('cour_ep') and cour.get('anilist') and int(cour['cour_ep']) > 1:
					from apis.anilist_api import anilist_episode_count
					_len = anilist_episode_count(cour['anilist'])
					if _len and int(cour['cour_ep']) > int(_len): cour = {}
			except Exception: pass
			if cour.get('cour_ep'):
				# LOCAL PATCH 2026-11-07: the entry's own episode number (episode_card.entry_episode): Monogatari S3E6 is 7, not 6
				from modules.episode_card import entry_episode
				ep_in_entry = entry_episode(self.tmdb_id, season, episode, cour, self.meta) or cour['cour_ep']
				entry = {'anilist': cour.get('anilist'), 'mal': cour.get('mal'), 'cour_ep': ep_in_entry,
						 'via': 'fribb' if ep_in_entry == cour['cour_ep'] else 'fribb + TVDB join'}
			else:
				# no Fribb entry for this episode: a show or a season Fribb has not mapped yet (Black Clover's 2nd Season)
				from modules.metadata import is_anime_check
				if is_anime_check(self.meta, self.tmdb_id):
					from apis.anilist_api import anilist_entry_for_tmdb_episode
					got = anilist_entry_for_tmdb_episode(self.meta, season, episode)
					if got.get('anilist'): entry = {'anilist': got['anilist'], 'mal': got.get('mal'), 'cour_ep': got['episode'], 'via': 'anilist air date'}
		except Exception: entry = {}
		self._anime_entry_memo = entry
		return entry

	def _anilist_scrobble(self):
		try:
			entry = self._anime_entry()
			if not entry.get('anilist'): return
			from apis.anilist_api import anilist_set_progress
			ok = anilist_set_progress(entry['anilist'], entry['cour_ep'], raise_only=True)   # LOCAL PATCH 2026-10-02: a rewatch never lowers it
			ku.logger('scrobble', 'AniList %s progress %s (%s): %s' % (entry['anilist'], entry['cour_ep'], entry['via'], 'ok' if ok else 'FAILED'))
		except Exception as e: ku.logger('scrobble', 'AniList: error %r' % e)

	# LOCAL PATCH 2026-10-02: MyAnimeList progress push -- the AniList one above with the MAL id. find_cour_by_tmdb_coords
	# returns both ids and the same cour-relative episode (MAL also keeps one entry per cour). Raise-only, see mal_set_progress.
	def _mal_scrobble(self):
		try:
			entry = self._anime_entry()
			if not entry.get('mal'): return
			from apis.mal_api import mal_set_progress
			ok = mal_set_progress(entry['mal'], entry['cour_ep'], raise_only=True)
			ku.logger('scrobble', 'MAL %s progress %s (%s): %s' % (entry['mal'], entry['cour_ep'], entry['via'], 'ok' if ok else 'FAILED'))
		except Exception as e: ku.logger('scrobble', 'MAL: error %r' % e)

	def run_next_ep(self):
		"""Hand off to the next episode. Returns True only if one actually followed."""
		from modules.episode_tools import EpisodeTools
		self.playback_chained = True   # LOCAL PATCH 2026-09-03: no refresh, another episode follows
		if not self.media_marked: self.media_watched_marker(force_watched=True)
		# LOCAL PATCH 2026-09-12: playback_chained must be set BEFORE the call (playback_prep may not return until the next
		# episode is under way), so clear it again when nothing followed.
		handed_off = EpisodeTools(self.meta, self.nextep_settings).auto_nextep()
		if not handed_off: self.playback_chained = False
		return handed_off

	def run_random_continual(self):
		from modules.episode_tools import EpisodeTools
		self.playback_chained = True   # LOCAL PATCH 2026-09-03: as run_next_ep
		if not self.media_marked: self.media_watched_marker(force_watched=True)
		EpisodeTools(self.meta).play_random_continual(False)

	def run_movie_stingers(self):
		self.movie_stingers_run = True
		stinger_keys = self.meta.get('stinger_keys', None)
		if not stinger_keys:
			try:
				keywords = self.meta.get('keywords', [])
				stinger_keys = [i['name'] for i in keywords['keywords'] if i['name'] in ('duringcreditsstinger', 'aftercreditsstinger')]
				self.meta['stinger_keys'] = stinger_keys
			except: pass
		if stinger_keys:
			from windows.base_window import open_window
			Thread(target=lambda: open_window(('windows.playback_notifications', 'StingersNotification'), 'playback_notifications.xml', meta=self.meta)).start()

	def _playing_episode_ratings(self):
		"""LOCAL PATCH 2026-10-22: fill the playing season's episode ratings (metadata.playing_episode_ratings) and, when
		that found new ones, hand the OSD the rebuilt item. Kodi applies updateInfoTag only to an item with the playing
		file's path and REPLACES the current item with it (Application.cpp, GUI_MSG_UPDATE_ITEM), so it is the full
		make_listing item, not a ratings-only one."""
		try:
			from modules.metadata import playing_episode_ratings
			fields = playing_episode_ratings(self.meta, self.season, self.episode)
			if not fields: return
			if all(str(fields.get(k) or '') == str(self.meta_get(k) or '') for k in ('ep_imdb_rating', 'ep_trakt_rating')): return
			self.meta.update(fields)
			if not self.isPlayingVideo(): return
			listitem = self.make_listing()
			listitem.setPath(self.getPlayingFile())
			self.updateInfoTag(listitem)
			ku.logger('episode ratings', 'playing S%sE%s: imdb=%s trakt=%s' % (self.season, self.episode, fields.get('ep_imdb_rating'), fields.get('ep_trakt_rating')))
		except Exception as e:
			ku.logger('episode ratings', 'playback update failed: %s' % e)

	def set_resume_point(self, listitem):
		if self.playback_percent > 0.0: listitem.setProperty('StartPercent', str(self.playback_percent))

	def info_next_ep(self):
		# LOCAL PATCH 2026-08-25: the single-shot flag is set in `finally`, not before the body -- otherwise an exception left
		# start_prep/nextep_settings unassigned and monitor()'s `remaining <= self.start_prep` raised every tick.
		self.start_prep = None   # LOCAL PATCH 2026-10-15: per gather -- see finally (the player outlives one episode in a chain)
		self._join_skip_segments()   # LOCAL PATCH 2026-11-08: the outro, if the threaded lookup finds one
		try:
			play_type = 'autoplay_nextep' if self.autoplay_nextep else 'autoscrape_nextep'
			nextep_settings = st.auto_nextep_settings(play_type)
			watching_check = nextep_settings['watching_check']
			# LOCAL PATCH 2026-08-25: no +15s bump here -- sources.py already pops the StillWatching dialog on this condition.
			# LOCAL PATCH 2026-07-04 (Plan B: timing precision): the alert fires when `total_time - curr_time <= start_prep`;
			# `window_time` = target seconds-before-end. Priority chain (best signal first):
			#   1. IntroDB outro_end (the credits->next-ep transition)
			#   2. IntroDB outro_start, if outro_end is missing
			#   3. Player.Chapters final_chapter (BluRay/remux: the last chapter is typically the credits)
			#   4. nextep.window_percentage
			# IntroDB path only when skipsegment.outro.mode == 'autoplay_countdown', chapter path only when use_chapters is on.
			window_time = None
			transition_source = None
			# LOCAL PATCH 2026-07-22: prefer outro_START (countdown visible during the outro) UNLESS there is meaningful video
			# after the outro (anime next-ep preview, post-credits scene) -- then fire at outro_END. 30s covers anime previews.
			POST_OUTRO_GAP_THRESHOLD = 30
			try:
				# LOCAL PATCH 2026-08-25: honor skipsegment.outro.mode. It selects who OWNS the outro segment, and the owners are
				# mutually exclusive (not "only 'off' disqualifies" -- that was tried and reverted):
				#   autoplay_countdown -> the ALERT: show at outro_start, count down, autoplay.
				#   auto               -> the SKIPPER: seek past the credits; the file ends and autoplay follows the natural end.
				#                         An alert here would flash and vanish, and the seek looks like a user stop.
				#   manual             -> the USER (Skip button).   off -> nobody.
				# Only the alert-owned mode may drive alert timing; everything else falls through to chapter/percentage.
				outro_mode = get_setting('deadlight.skipsegment.outro.mode', 'autoplay_countdown')
				outro = _outro_for_file((getattr(self, 'skip_segments_data', None) or {}).get('outro'), self.total_time)
				if outro_mode != 'autoplay_countdown': outro = []
				# LOCAL PATCH 2026-08-26: the same bogus-segment guard as _check_skip_segments (min 15s, Red Light 1.6.7). A 5s
				# "outro" is bad IntroDB data (often timings from another cut). Reject and fall through to chapter/percentage.
				MIN_OUTRO_SECONDS = 15
				TRIMMED_CREDITS_WINDOW = 30   # LOCAL PATCH 2026-10-23: see the cut-mismatch rejection below
				if outro and self.total_time:
					outro_start = outro[0][0]
					outro_end = outro[0][1] if len(outro[0]) > 1 else None
					os_valid = outro_start is not None and 0 < outro_start < self.total_time
					oe_valid = outro_end is not None and 0 < outro_end < self.total_time
					# LOCAL PATCH 2026-08-26: cut mismatch. An outro_end beyond the runtime means IntroDB timed a LONGER cut, so
					# neither endpoint is usable; drop the segment. outro_end == total_time is NORMAL (credits run to the file end),
					# so only a mark meaningfully BEYOND the runtime counts.
					if outro_end is not None and outro_end > self.total_time + 2:
						ku.logger('NextEp Timing', 'rejecting outro: end %.0fs exceeds runtime %.0fs (data is for a different cut)'
							% (outro_end, self.total_time))
						os_valid = oe_valid = False
						# LOCAL PATCH 2026-10-23: unless the credits START in the file's last TRIMMED_CREDITS_WINDOW seconds -- the release
						# ends where the credits begin, so the countdown goes in the final seconds instead of the percentage (mid-scene).
						if outro_start is not None and self.total_time - TRIMMED_CREDITS_WINDOW <= outro_start <= self.total_time + 2:
							window_time = TRIMMED_CREDITS_WINDOW
							transition_source = 'introdb_credits_trimmed'
					# LOCAL PATCH 2026-11-07 (Red Light 2.9.9): a credits stamp in the first half of the file is not this file's
					# credits (another cut, or a mis-typed segment) -- fall through to chapter / percentage.
					if os_valid and outro_start < self.total_time * 0.5:
						ku.logger('NextEp Timing', 'rejecting outro: start %.0fs is in the first half of %.0fs' % (outro_start, self.total_time))
						os_valid = oe_valid = False
					if oe_valid and outro_end < self.total_time * 0.5: oe_valid = False
					# Duration check when both ends are known.
					if os_valid and oe_valid and (outro_end - outro_start) < MIN_OUTRO_SECONDS:
						ku.logger('NextEp Timing', 'rejecting outro: duration %.1fs < %ds min'
							% (outro_end - outro_start, MIN_OUTRO_SECONDS))
						os_valid = oe_valid = False
					# The alert also needs to sit far enough from the end to be usable at all.
					if os_valid and (self.total_time - outro_start) < MIN_OUTRO_SECONDS:
						ku.logger('NextEp Timing', 'rejecting outro_start: only %.1fs before end (< %ds min)'
							% (self.total_time - outro_start, MIN_OUTRO_SECONDS))
						os_valid = False
					# Same floor for the outro_end path -- an end mark within seconds of the
					# file end leaves no usable window either.
					if oe_valid and (self.total_time - outro_end) < MIN_OUTRO_SECONDS:
						oe_valid = False
					if os_valid and oe_valid:
						post_outro_gap = self.total_time - outro_end
						# LOCAL PATCH 2026-10-11: <=, not <. A tail of exactly 30 s counts as credits, so the alert comes at the outro start;
						# only a tail LONGER than 30 s holds the alert back.
						if post_outro_gap <= POST_OUTRO_GAP_THRESHOLD:
							# Outro at end of video — fire at outro_start (countdown during outro)
							window_time = max(0, self.total_time - outro_start)
							transition_source = 'introdb_outro_start'
						else:
							# Meaningful post-outro content — fire at outro_end
							window_time = max(0, self.total_time - outro_end)
							transition_source = 'introdb_outro_end'
					elif os_valid:
						# Only outro_start available — use it
						window_time = max(0, self.total_time - outro_start)
						transition_source = 'introdb_outro_start'
					elif oe_valid:
						# Only outro_end available — use it
						window_time = max(0, self.total_time - outro_end)
						transition_source = 'introdb_outro_end'
			except Exception as e:
				ku.logger('IntroDB outro parse error', str(e))
			if window_time is None and nextep_settings['use_chapters']:
				final_chapter = self.final_chapter(90)
				if final_chapter and self.total_time:
					window_time = round(((100 - final_chapter) / 100.0) * self.total_time)
					transition_source = 'chapter'
			if window_time is None:
				percentage = nextep_settings['window_percentage']
				window_time = round((percentage / 100.0) * self.total_time) if self.total_time else 0
				transition_source = 'percentage'
			window_time = round(window_time)
			use_window = nextep_settings['alert_method'] == 0
			default_action = nextep_settings['default_action']
			self.start_prep = nextep_settings['scraper_time'] + window_time
			# LOCAL PATCH 2026-08-25: tier the alert by how much the timing source can be trusted. An IntroDB outro really
			# marks "credits are rolling", so a short countdown then autoplay is right. An arbitrary point is not: LOW confidence
			# keeps the early alert but counts down to the true end and shows the REMAINING TIME, not a countdown to a guess.
			# Consumed by NextEpisode.monitor().
			# LOCAL PATCH 2026-09-05: a final chapter counts as REAL DATA and keeps the countdown (user's releases mark the
			# credits there). A MISSING transition_source reads as low, not high.
			timing_confidence = 'low' if transition_source in (None, 'percentage') else 'high'
			# LOCAL PATCH 2026-10-15: real content after the outro (IntroDB's outro ends more than POST_OUTRO_GAP_THRESHOLD before
			# the file does), read from the raw outro whichever mode owns it. NextEpisode then counts to the REAL end ('to_end')
			# instead of starting the next episode 10 s into the preview.
			content_after = 0
			try:
				_raw = _outro_for_file((getattr(self, 'skip_segments_data', None) or {}).get('outro'), self.total_time)
				if _raw and self.total_time and len(_raw[0]) > 1 and _raw[0][1] is not None:
					_gap = self.total_time - float(_raw[0][1])
					if POST_OUTRO_GAP_THRESHOLD < _gap < self.total_time: content_after = int(round(_gap))
			except Exception: pass
			self.nextep_settings = {'use_window': use_window, 'window_time': window_time, 'default_action': default_action,
									'play_type': play_type, 'watching_check': watching_check,
									'timing_confidence': timing_confidence, 'transition_source': transition_source,
									'total_time': self.total_time, 'content_after': content_after}
			ku.logger('NextEp Timing', 'source=%s confidence=%s window_time=%ss (%.1f%% before end of %ds)%s' % (
				transition_source, timing_confidence, window_time, (window_time / max(self.total_time or 1, 1)) * 100, self.total_time or 0,
				' content_after_outro=%ss' % content_after if content_after else ''))
		except Exception as e:
			ku.logger('NextEp Timing', 'info_next_ep failed: %s' % e)
		finally:
			self.nextep_info_gathered = True
			# LOCAL PATCH 2026-10-15: a failure before start_prep was set left it unassigned, and monitor()'s comparison raised
			# every second, skipping `last_remaining = remaining`. -inf: no handoff for this episode, but the tick still runs.
			if self.start_prep is None:
				self.start_prep = float('-inf')
				ku.logger('NextEp Timing', 'no next-episode timing for this episode -- autoplay will not hand off')

	def _retry_nextep_chapter_timing(self):
		"""LOCAL PATCH 2026-10-23: when info_next_ep() fell back to the percentage only because the chapters were not known
		yet, take the final chapter now -- the same source, rule (>= 90 %) and trust as info_next_ep's chapter branch."""
		settings = getattr(self, 'nextep_settings', None)
		if not settings or self.nextep_handoff_attempted or settings.get('transition_source') != 'percentage': return
		nextep_settings = st.auto_nextep_settings(settings['play_type'])
		if not nextep_settings['use_chapters'] or not self.total_time: return
		final_chapter = self.final_chapter(90)
		if not final_chapter: return
		window_time = round(((100 - final_chapter) / 100.0) * self.total_time)
		self.start_prep = nextep_settings['scraper_time'] + window_time
		settings.update({'window_time': window_time, 'transition_source': 'chapter', 'timing_confidence': 'high'})
		ku.logger('NextEp Timing', 're-timed at 30 s: source=chapter window_time=%ss (%.1f%% before end of %ds)' % (
			window_time, 100 - final_chapter, self.total_time))

	def final_chapter(self, threshhold):
		try:
			final_chapter = float(ku.get_infolabel('Player.Chapters').split(',')[-1])
			if final_chapter >= threshhold: return final_chapter
		except: pass
		return None

	def kill_dialog(self):
		try: self.sources_object._kill_progress_dialog()
		except: ku.close_all_dialog()

	def set_constants(self, url, obj):
		self.url = url
		self.sources_object = obj
		self.is_generic = self.sources_object == 'video'
		if not self.is_generic:
			self.meta = self.sources_object.meta
			self.meta_get, self.kodi_monitor, self.playback_percent = self.meta.get, ku.kodi_monitor(), self.sources_object.playback_percent or 0.0
			self.playing_filename = self.sources_object.playing_filename
			self.media_marked, self.nextep_info_gathered, self.movie_stingers_run = False, False, False
			self._mark_attempts = 0   # LOCAL PATCH 2026-10-25 (4.0.5): see media_watched_marker
			self.nextep_handoff_attempted = False   # LOCAL PATCH 2026-09-12: see monitor()
			self._nextep_chapter_retry = False      # LOCAL PATCH 2026-10-23: see monitor() / _retry_nextep_chapter_timing
			# LOCAL PATCH 2026-09-03: see _refresh_after_playback.
			self.playback_chained, self.refresh_when_marked = False, False
			# LOCAL PATCH 2026-09-03 (Red Light 2.3.6 port): resolved once -- the loop below runs every second.
			self.watched_tick_percent = st.playback_watched_percent()
			self.playback_successful, self.cancel_all_playback = None, False
			self.playing_item = self.sources_object.playing_item
			self._init_skip_segments()

	def _stop_at_credits_if_no_next(self, segments):
		"""LOCAL PATCH 2026-08-25: stop playback at the credits when nothing follows.

		In autoplay_countdown mode the outro segment is normally handed to the autoplay
		flow — but on a finale (or when the next episode hasn't aired) that flow does
		nothing, so the credits just play out to the end. Here we detect that case and
		stop instead. Returns True when it stopped playback, False to leave the normal
		hand-off alone. Gated on skipsegment.stop_at_credits_no_next (default on)."""
		try:
			if get_setting('deadlight.skipsegment.stop_at_credits_no_next', 'true') != 'true': return False
			# Only act once we've actually reached a credible outro start. Same 15s
			# minimum the main skip loop uses, so bogus IntroDB timings (0s->5s) can't
			# kill playback seconds in.
			outro_start = None
			for (start, end) in segments:
				if start is None: continue
				end_eff = end if end is not None else self.total_time
				if end_eff is None or (end_eff - start) < 15: continue
				if self.curr_time >= start:
					outro_start = start
					break
			if outro_start is None: return False
			# Costs a metadata lookup, and this runs every second — resolve once.
			if self.nextep_available is None:
				from modules.episode_tools import next_episode_available
				self.nextep_available = next_episode_available(self.meta)
			if self.nextep_available: return False
			ku.logger('stop-at-credits', 'no next episode — stopping at outro_start=%s' % outro_start)
			self.skip_segments_consumed.add('outro')
			if not self.media_marked: self.media_watched_marker(force_watched=True)
			mark_internal_stop()   # LOCAL PATCH 2026-08-26: our stop, not the user's
			self.stop()
			return True
		except Exception:
			return False   # fail open — never let this break playback

	def _init_skip_segments(self):
		self.skip_segments_data = None
		self.skip_segments_consumed = set()
		self._skip_token, self._skip_thread = None, None   # LOCAL PATCH 2026-11-08: a previous episode's lookup no longer counts
		# LOCAL PATCH 2026-10-22: per episode -- the player outlives one episode in an autoplay chain (_publish_osd_segments)
		self._osd_chapter_list, self._osd_chapter_final, self._osd_written, self._osd_segments_key = None, False, {}, None
		self.nextep_available = None   # LOCAL PATCH 2026-08-25: cached once per playback
		self.active_skip_window = None
		self.active_skip_end = None
		self.active_skip_thread = None
		self.chapter_segments_on = False   # LOCAL PATCH 2026-10-13: see _chapter_segments
		try:
			if not get_setting('deadlight.skipsegment.enabled') == 'true': return
			self.chapter_segments_on = True
			imdb_id, tvdb_id = self.meta_get('imdb_id'), self.meta_get('tvdb_id')
			if not imdb_id and not self.meta_get('tmdb_id'): return   # LOCAL PATCH 2026-10-18: TheIntroDB v4 is asked by TMDb id
			# LOCAL PATCH 2026-08-05: theintrodb.org supports movies too. Episode path passes s/e; movie path passes None+None
			# and only theintrodb.org gets queried (introdb.app is TV-only).
			media_type = self.meta_get('media_type')
			if media_type == 'episode':
				season, episode = self.meta_get('season'), self.meta_get('episode')
				if season is None or episode is None: return
			elif media_type == 'movie':
				season, episode = None, None
			else:
				return
			from apis.introdb_api import fetch_segments
			# LOCAL PATCH 2026-08-27: tmdb_id lets fetch_segments try AniSkip for anime (Fribb yields the MAL id and the
			# cour-relative episode AniSkip is addressed by). A Fribb miss leaves the two IntroDB providers as they are.
			# LOCAL PATCH 2026-11-08: on a thread -- it could take up to ~30 s before play(). info_next_ep waits for it
			# (_join_skip_segments).
			token = self._skip_token = object()
			tmdb_id = self.meta_get('tmdb_id')
			def _fetch():
				try:
					segs = fetch_segments(imdb_id, season, episode, tmdb_id, tvdb_id)
					if not segs or getattr(self, '_skip_token', None) is not token: return
					# a chapter-named segment found meanwhile (_chapter_segments) stays unless the database has that type
					found = self.skip_segments_data or {}
					self.skip_segments_data = dict(segs, **dict((k, v) for k, v in found.items() if k not in segs))
					ku.logger('IntroDB segments', '%s for imdb=%s tvdb=%s s=%s e=%s (%s)' % (list(segs.keys()), imdb_id, tvdb_id, season, episode, media_type))
				except Exception as e:
					ku.logger('IntroDB init error', str(e))
			import threading
			self._skip_thread = threading.Thread(target=_fetch, daemon=True)
			self._skip_thread.start()
		except Exception as e:
			ku.logger('IntroDB init error', str(e))

	def _join_skip_segments(self, timeout=8):
		"""LOCAL PATCH 2026-11-08: wait (bounded) for _init_skip_segments' lookup -- for info_next_ep, which times the alert
		from the outro. A no-op once it has finished."""
		t = getattr(self, '_skip_thread', None)
		if t is None: return
		t.join(timeout)
		if t.is_alive(): ku.logger('IntroDB segments', 'lookup still running after %ds; Next Episode timing uses the percentage' % timeout)
		else: self._skip_thread = None

	def _chapter_segments(self):
		"""LOCAL PATCH 2026-10-13: named-chapter fallback for Skip Intro / Skip Recap. When the chapter now playing is named
		like an intro or recap (_CHAPTER_SEGMENT_RES) and IntroDB / TheIntroDB / AniSkip had nothing of that type, that
		chapter -- its start to the next chapter's start -- becomes the segment, and the usual path takes it from there
		(the type's auto / manual / off mode, the 15 s minimum). Kodi names only the CURRENT chapter (Player.ChapterName),
		so this is read each tick; a database segment always wins. Many anime and remux releases name their chapters;
		most WEB-DLs do not ('Chapter 1', or none), and then nothing happens."""
		if not getattr(self, 'chapter_segments_on', False): return
		name = (ku.get_infolabel('Player.ChapterName') or '').strip()
		if not name: return
		stype = next((t for t, rx in _CHAPTER_SEGMENT_RES if rx.match(name)), None)
		data = self.skip_segments_data or {}
		if not stype or stype in data or stype in self.skip_segments_consumed: return
		try:
			idx = int(ku.get_infolabel('Player.Chapter') or 0)   # 1-based
			values = [float(i) for i in (ku.get_infolabel('Player.Chapters') or '').split(',') if i.strip()]
			starts = _chapter_starts(values, int(ku.get_infolabel('Player.ChapterCount') or 0))
		except ValueError: return
		# the last chapter has no next start to skip to -- except credits, which then run to the end of the file
		if not self.total_time or not (1 <= idx < len(starts) or (stype == 'outro' and idx == len(starts) and idx >= 1)): return
		start = starts[idx - 1] / 100.0 * self.total_time
		end = starts[idx] / 100.0 * self.total_time if idx < len(starts) else self.total_time
		if end - start > (_CHAPTER_OUTRO_MAX if stype == 'outro' else _CHAPTER_SEGMENT_MAX):
			# marked where it starts but not where the episode resumes: skipping to the next marker would cut episode
			self.skip_segments_consumed.add(stype)
			ku.logger('chapter segments', '%s chapter %d %r ignored: %.0f-%.0fs is too long for one' % (stype, idx, name, start, end))
			return
		self.skip_segments_data = dict(data, **{stype: [(start, end)]})
		ku.logger('chapter segments', '%s from chapter %d %r: %.0f-%.0fs' % (stype, idx, name, start, end))
		if stype == 'outro': self._retime_nextep_to_outro(start, end, 'chapter_credits')

	def _retime_nextep_to_outro(self, start, end, source):
		"""LOCAL PATCH 2026-10-23: an outro found after info_next_ep() ran (a credits chapter is only named once it plays)
		moves the next-episode alert onto it, by info_next_ep's own rules: only in 'autoplay_countdown' (the alert owns the
		outro), at the outro START unless more than POST_OUTRO_GAP_THRESHOLD of file follows it (an anime preview), then at
		its END; trusted like an IntroDB outro (countdown, not remaining time). Never after the hand-off."""
		settings = getattr(self, 'nextep_settings', None)
		if not settings or not self.nextep_info_gathered or self.nextep_handoff_attempted: return
		if not (self.autoplay_nextep or self.autoscrape_nextep): return
		if get_setting('deadlight.skipsegment.outro.mode', 'autoplay_countdown') != 'autoplay_countdown': return
		if (settings.get('transition_source') or '').startswith('introdb'): return
		total = float(self.total_time or 0)
		if total <= 0 or total - start < 15: return
		gap = total - end
		content_after = int(round(gap)) if gap > 30 else 0
		window_time = int(round(gap if content_after else total - start))
		scraper_time = st.auto_nextep_settings(settings['play_type'])['scraper_time']
		self.start_prep = scraper_time + window_time
		settings.update({'window_time': window_time, 'transition_source': source, 'timing_confidence': 'high',
						'content_after': content_after})
		ku.logger('NextEp Timing', 're-timed: source=%s window_time=%ss (%.1f%% before end of %ds)%s' % (
			source, window_time, window_time / total * 100, total, ' content_after_outro=%ss' % content_after if content_after else ''))

	def _publish_osd_segments(self):
		"""LOCAL PATCH 2026-10-22: AF3's seek bar, as Kodi's ranges control reads them: 'start%,end%,...' of the duration
		(GUIRangesControl::UpdateInfo takes any info label). Home properties --
		  deadlight.osd.track     the whole bar (one piece)
		  deadlight.osd.segments  the recap / intro / credits spans, their edges snapped to chapter breaks
		Called every second; a property is written only when its value changed. Cleared with the other playback
		properties, and AF3 falls back to its plain bar while they are empty."""
		total = float(getattr(self, 'total_time', 0) or 0)
		if total <= 0: return
		chapters = self._osd_chapters(total)
		# LOCAL PATCH 2026-10-23: one continuous bar -- chapter gaps fragmented it where recap, intro and their chapters sit
		# close together. Chapters still place the amber spans' edges (_snap_to_chapter).
		whole = [(0.0, 100.0)]
		data = self.skip_segments_data or {}
		key = (repr(sorted(data.items())), int(total), tuple(chapters))
		if key != getattr(self, '_osd_segments_key', None):
			self._osd_segments_key = key
			spans, first = [], {}
			for stype in ('recap', 'intro', 'outro'):
				for seg in (_outro_for_file(data.get(stype), total) if stype == 'outro' else data.get(stype)) or []:
					start = seg[0] if seg else None
					end = seg[1] if len(seg) > 1 else None
					if start is None or _late_recap(stype, start, total): continue
					# a span ending past the file is timed for another cut -- the same 2 s rule the next-episode timing uses
					if end is not None and end > total + 2: continue
					end = total if end is None else min(end, total)
					if end <= start: continue
					s_pct, e_pct = _snap_to_chapter(chapters, start / total * 100, total), _snap_to_chapter(chapters, end / total * 100, total)
					if e_pct > s_pct:
						spans += _cut_at_chapters(whole, s_pct, e_pct, 0.3)
						first.setdefault(stype, (s_pct, e_pct))
			self._osd_put('segments', spans)
			self._osd_label_spans = first
			self._osd_put('track', _cut_at_chapters(whole, 0, 100))
		# LOCAL PATCH 2026-10-24: the names over the amber spans (RECAP / INTRO / CREDITS). Kodi cannot place a label at a
		# percentage of a bar, so each name is an image the skin stretches over a range: the image's width on AF3's bar
		# (_OSD_LABEL_PCT), centred on the span's first piece, kept inside the bar; one overlapping the previous is left out.
		# LOCAL PATCH 2026-10-24: a span already played past loses its name (the amber span stays); seeking back restores
		# it. Worked out every call -- _osd_put writes only what changed.
		first = getattr(self, '_osd_label_spans', None) or {}
		try: now = float(self.curr_time or 0) / total * 100
		except (TypeError, ValueError, ZeroDivisionError): now = 0.0
		taken = 0.0
		for stype in ('recap', 'intro', 'outro'):
			label = []
			if stype in first and now <= first[stype][1]:
				w = _OSD_LABEL_PCT[stype]
				mid = sum(first[stype]) / 2
				a = min(max(mid - w / 2, 0.0), 100.0 - w)
				if a >= taken:
					label, taken = [(a, a + w)], a + w + 0.5
			self._osd_put('label_%s' % stype, label)
		# LOCAL PATCH 2026-10-24: no 'played' / 'cache' -- AF3 draws both with plain progress controls (Player.Progress /
		# ProgressCache); a per-second rewrite made their ranges flash white.

	def _osd_chapters(self, total):
		"""The chapters as [(start%, end%)] over the whole bar. Kodi's Player.Chapters lists the ranges up to the last
		chapter's START and leaves the last one out (Slow Horses 6x06, 3 chapters: '0,11.94,11.94,12.86'), so the bar is
		rebuilt from the boundaries. Read for the first 30 s (a stream can report its chapters late), then kept."""
		cached = getattr(self, '_osd_chapter_list', None)
		if cached is not None and (getattr(self, '_osd_chapter_final', False) or float(self.curr_time or 0) < 30): return cached
		bounds = set()
		try:
			for v in (ku.get_infolabel('Player.Chapters') or '').split(','):
				if v.strip():
					f = round(float(v), 3)
					if 0.05 < f < 99.95: bounds.add(f)
		except (TypeError, ValueError): bounds = set()
		points = [0.0] + sorted(bounds) + [100.0]
		chapters = [(points[i], points[i + 1]) for i in range(len(points) - 1) if points[i + 1] - points[i] > 0.01]
		self._osd_chapter_list = chapters
		if float(self.curr_time or 0) >= 30: self._osd_chapter_final = True
		return chapters

	def _osd_put(self, name, ranges):
		value = ','.join('%.2f,%.2f' % r for r in ranges)
		cache = self.__dict__.setdefault('_osd_written', {})
		if cache.get(name) == value: return
		cache[name] = value
		ku.set_property('deadlight.osd.%s' % name, value)

	def _check_skip_segments(self):
		try: self._chapter_segments()
		except Exception as e: ku.logger('chapter segments error', str(e))
		try: self._publish_osd_segments()
		except Exception: pass
		if not self.skip_segments_data: return
		curr = self.curr_time
		if self.active_skip_window:
			if curr >= (self.active_skip_end or float('inf')):
				try: self.active_skip_window.request_close()
				except: pass
				self.active_skip_window = None; self.active_skip_end = None; self.active_skip_thread = None
				return
			if getattr(self.active_skip_window, 'user_clicked', False):
				try: self.seekTime(self.active_skip_end or self.total_time)
				except: pass
				try: self.active_skip_window.request_close()
				except: pass
				self.active_skip_window = None; self.active_skip_end = None; self.active_skip_thread = None
				return
			return
		# LOCAL PATCH 2026-08-05: movies never get the autoplay next-ep flow, so 'autoplay_countdown' outro mode is
		# downgraded to 'manual' for them (they still get a Skip button).
		_media_type = self.meta_get('media_type')
		for stype, segments in self.skip_segments_data.items():
			if stype in self.skip_segments_consumed: continue
			if stype == 'outro': segments = _outro_for_file(segments, self.total_time)
			mode = get_setting('deadlight.skipsegment.%s.mode' % stype) or 'manual'
			if mode == 'off': continue
			# Outro in 'autoplay_countdown' mode: don't skip/show button here; the autoplay flow handles it.
			# BUT movies have no next-ep autoplay flow, so downgrade to 'manual' — user still gets a Skip Credits button.
			if stype == 'outro' and mode == 'autoplay_countdown':
				if _media_type == 'movie':
					mode = 'manual'
				elif self._stop_at_credits_if_no_next(segments):
					# Finale / next-not-yet-aired: nothing will hand off, so we stopped
					# playback at the outro instead of letting the credits run out.
					return
				else:
					# LOCAL PATCH 2026-09-05: do NOT mark the outro consumed here. This runs every second from t=0, so consuming it
					# on the first tick retired the outro long before the credits and stop-at-credits could never fire. `continue`
					# alone keeps the skip/button code off an outro the autoplay flow owns; re-running is cheap (next_episode_available()
					# is cached in self.nextep_available).
					# LOCAL PATCH 2026-10-26: unless real content follows the credits (outro ends more than 30 s -- info_next_ep's
					# POST_OUTRO_GAP_THRESHOLD -- before the file does). The countdown then waits for outro_end, so nothing owned the
					# credits; offer a Skip button to outro_end and the countdown still comes after it.
					if not any(e is not None and self.total_time and self.total_time - e > 30 for (_s, e) in segments): continue
					mode = 'manual'
			for (start, end) in segments:
				# LOCAL PATCH 2026-10-15: an open end means 'to the end of the file' -- right for credits (TheIntroDB's outro end_ms
				# is usually null), wrong for an intro or recap, whose skip would seek to the end of the episode.
				if end is None and stype != 'outro': continue
				if _late_recap(stype, start, self.total_time):
					self.skip_segments_consumed.add(stype)
					ku.logger('IntroDB reject', 'recap at %.0fs is past the first third of %.0fs -- not a recap' % (start, self.total_time))
					continue
				end_eff = end if end is not None else self.total_time
				# LOCAL PATCH 2026-07-10 (port of Red Light 1.6.7): reject bogus IntroDB timings (near-zero segments such as 0s > 5s
				# flash "Skip Intro" and jump a couple of seconds). Intro/outro must be at least 15s (real ones are ~30-90s); recap
				# 8s since some real recaps are short. curr must be at least 3s BEFORE end so a skip moves meaningfully forward.
				min_duration = 8 if stype == 'recap' else 15
				if (end_eff - start) < min_duration:
					self.skip_segments_consumed.add(stype)
					ku.logger('IntroDB reject', 'stype=%s start=%.1f end=%.1f duration=%.1f min=%d' % (stype, start, end_eff, end_eff - start, min_duration))
					continue
				if end_eff - curr < 3:
					self.skip_segments_consumed.add(stype)
					continue
				if start <= curr < end_eff:
					self.skip_segments_consumed.add(stype)
					if mode == 'auto':
						try: self.seekTime(end_eff)
						except Exception as e: ku.logger('IntroDB auto-skip error', str(e))
					elif mode == 'manual':
						self._spawn_skip_window(stype, end_eff)
					return

	def _spawn_skip_window(self, stype, end_time):
		try:
			from windows.base_window import create_window
			labels = {'intro': 'Skip intro', 'outro': 'Skip outro', 'recap': 'Skip recap'}   # 2026-11-08: sentence case (round 5)
			label = labels.get(stype, 'Skip ' + stype.title())
			corner = get_setting('deadlight.skipsegment.button_corner') or 'bottom-right'
			window = create_window(('windows.skip_segment', 'SkipSegment'), 'skip_segment.xml', label=label, corner=corner, end_time=end_time)
			if not window: return
			import threading
			self.active_skip_window = window
			self.active_skip_end = end_time
			t = threading.Thread(target=window.run, daemon=True)
			self.active_skip_thread = t
			t.start()
		except Exception as e:
			ku.logger('IntroDB spawn skip window error', str(e))

	def set_playback_properties(self):
		try:
			trakt_ids = {'tmdb': self.tmdb_id, 'imdb': self.imdb_id, 'slug': make_trakt_slug(self.title)}
			if self.media_type == 'episode': trakt_ids['tvdb'] = self.tvdb_id
			ku.set_property('script.trakt.ids', json.dumps(trakt_ids))
			if self.playing_filename: ku.set_property('subs.player_filename', self.playing_filename)
		except: pass

	def clear_playback_properties(self):
		ku.clear_property('deadlight.window_stack')
		ku.clear_property('script.trakt.ids')
		ku.clear_property('subs.player_filename')
		for _name in ('segments', 'track', 'label_recap', 'label_intro', 'label_outro', 'imdb'): ku.clear_property('deadlight.osd.%s' % _name)   # LOCAL PATCH 2026-10-22: _publish_osd_segments
		# LOCAL PATCH 2026-08-21: reset the stop-vs-end verdict at the start of each playback (run() calls this before
		# play_video) so a Stop on episode N can't suppress the Next Up alert at the end of episode N+1.
		ku.clear_property(PLAYBACK_STOPPED_PROP)
		if not _internal_stop_recent(): ku.clear_property(INTERNAL_STOP_PROP)   # LOCAL PATCH 2026-08-26; 10-18: a stop still due its callback keeps it
		ku.clear_property(PLAYBACK_LAST_REMAINING_PROP)   # LOCAL PATCH 2026-09-24

	def run_error(self):
		try: self.sources_object.playback_successful = False
		except: pass
		self.clear_playback_properties()
		ku.notification('Playback Failed', 3500)
		return False
