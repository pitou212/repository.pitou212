"""
	Fenomscrapers Module
"""

import gzip
from random import choice
import re
import sys
from magneto.modules import dom_parser
import urllib.request as urllib2
from urllib.error import HTTPError


def randomagent():
	# LOCAL PATCH 2026-10-21 (from POV 6.10.17): real browser strings only. The old generator built impossible ones ('Windows
	# NT 11.0' -- Windows 11 still says 10.0 -- Firefox on Trident, stale Chrome) that draw Cloudflare challenges.
	return choice((
		'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
		'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/116.0',
		'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
		'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
		'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.82',
		'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.188',
	))

# LOCAL PATCH 2026-11-01 (cleanup): one agent per process, picked at import. Not cache.get(randomagent, 12): a SQLite read on
# every request.
_UA = randomagent()

# LOCAL PATCH 2026-11-01 (cleanup): request() cut down to what the providers use -- a GET with a timeout, and nekobt's
# ignoreErrors=404 (a 404 whose body is an answer). Returns the body as text (UTF-8, bad bytes dropped, gzip undone), or
# None -- logged -- on any failure. headers= stays for the harness spies (knaben_check.py).
def request(url, timeout='30', ignoreErrors=None, headers=None):
	from magneto.modules import log_utils
	try:
		if not url: return None
		if url.startswith('//'): url = 'http:' + url
		headers = dict(headers or {})
		headers.setdefault('User-Agent', _UA)
		headers.setdefault('Accept-Language', 'en-US')
		headers.setdefault('Accept-Encoding', 'gzip')
		req = urllib2.Request(url)
		req.add_unredirected_header('Host', req.host)
		req.add_unredirected_header('Referer', headers.get('Referer') or '%s://%s/' % (req.type, req.host))
		for key, value in headers.items(): req.add_header(key, value)
		try: response = urllib2.urlopen(req, timeout=int(timeout))
		except HTTPError as error_response:
			response = error_response
			ignore = ignoreErrors if isinstance(ignoreErrors, (list, tuple)) else (ignoreErrors,)
			if int(response.code) not in ignore:
				# LOCAL PATCH 2026-10-25: no challenge solver (cfscrape cannot beat today's Cloudflare). A challenge page is never the
				# provider's answer, so this is the request failing.
				if response.code in (301, 307, 308, 503, 403) and 'cloudflare' in str(response.info()).lower():
					log_utils.log('Cloudflare challenge, not solved: url=%s' % url, level=log_utils.LOGDEBUG)
				else: log_utils.error('Request-Error url=(%s)' % url)
				return None
		result = response.read(5242880)
		if response.headers['Content-Encoding'] == 'gzip': result = gzip.decompress(result)
		response.close()
		return result.decode(encoding='utf-8', errors='ignore')
	except:
		try: _status.last_error = sys.exc_info()[1]   # LOCAL PATCH 2026-10-15: for the reset retry in request() below
		except Exception: pass
		log_utils.error('Request-Error url=(%s)' % url)
		return None

# LOCAL PATCH 2026-09-27 (DeadLight bundle): a per-thread tally of what request() returned, so the scrape can tell
# "provider answered with nothing" from "provider is down" (providers swallow every error and return [] either way).
# scrapers/external.py runs each provider in its own thread, calling reset_status() before and status() after.
import threading as _threading
import time as _time
_status = _threading.local()
_request = request

# LOCAL PATCH 2026-10-15: retry when the connection was RESET, and only while that comes back fast. Some sites (e.g.
# torrentdownload.info) reset ~half their connections from this network; a reset arrives in well under a second, so retries
# fit the 4 s scrape budget. Timeouts, refusals, DNS and HTTP errors are not retried -- another try would not change them.
def _was_reset(error):
	for e in (error, getattr(error, 'reason', None), getattr(error, '__cause__', None), getattr(error, '__context__', None)):
		if isinstance(e, ConnectionResetError) or type(e).__name__ in ('RemoteDisconnected', 'ConnectionResetError'): return True
		if e is not None and ('10054' in str(e) or 'Connection reset' in str(e)): return True
	return False

# LOCAL PATCH 2026-10-24: up to three retries. The resets are the ISP's, keyed on the SNI name, and each try is a coin toss:
# one retry left a quarter of requests failing, four tries miss ~6 %. A reset comes back in ~0.25 s, so all fit in 2 s.
_RESET_RETRIES, _RESET_BUDGET = 3, 2.0

def request(url, *args, **kwargs):
	_status.last_error = None
	_t0 = _time.time()
	try:
		result = _request(url, *args, **kwargs)
		tries = 0
		while result is None and tries < _RESET_RETRIES and _was_reset(getattr(_status, 'last_error', None)) and _time.time() - _t0 < _RESET_BUDGET:
			tries += 1
			# DeadLight's logger (log_utils.log writes through this same logger)
			try:
				from modules.kodi_utils import logger
				logger('magneto reset retry', '%s (try %d)' % (url, tries + 1))
			except Exception: pass
			_status.last_error = None
			result = _request(url, *args, **kwargs)
	except Exception:
		result = None
		raise
	finally:
		_count('failed' if result is None else 'ok')
	return result

# LOCAL PATCH 2026-10-18: the tally is a dict shared with the provider's own worker threads (workers.Thread and counted()
# hand it over), so a provider whose requests all run in child threads reads 'down' when they all fail, not 'none'.
_tally_lock = _threading.Lock()

def _tally():
	t = getattr(_status, 'tally', None)
	if t is None: t = _status.tally = {'ok': 0, 'failed': 0}
	return t

def _count(key):
	t = _tally()
	with _tally_lock: t[key] += 1

def counted(fn):
	"""fn, run against the CALLING thread's tally -- wrap a worker thread's target with it."""
	tally = _tally()
	def run(*args, **kwargs):
		_status.tally = tally
		return fn(*args, **kwargs)
	return run

def reset_status():
	_status.tally = {'ok': 0, 'failed': 0}

def status():
	"""(requests answered, requests failed) in this thread and its counted() workers since reset_status()."""
	t = _tally()
	return t['ok'], t['failed']

def parseDOM(html, name='', attrs=None, ret=False):
	try:
		if attrs:
			attrs = dict((key, re.compile(value + ('$' if value else ''))) for key, value in iter(attrs.items()))
		results = dom_parser.parse_dom(html, name, attrs, ret)
		if ret: results = [result.attrs.get(ret.lower(), '') for result in results]   # LOCAL PATCH 2026-10-21 (POV): an element without that attribute no longer loses the whole list
		else: results = [result.content for result in results]
		return results
	except:
		from magneto.modules import log_utils
		log_utils.error()

# LOCAL PATCH 2026-10-25: class bfcookie (BlazingFast.io cookie challenge) removed: the service is gone.
