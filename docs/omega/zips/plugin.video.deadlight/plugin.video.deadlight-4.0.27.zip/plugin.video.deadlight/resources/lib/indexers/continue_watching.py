# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-29: one Continue Watching widget across movies, TV and anime: everything part-way through, plus
# the next episode of every unfinished show.
# Mixed-media rendering follows trakt_lists.build_trakt_list: each builder runs in its own thread and returns
# [(listitem, order), ...], merged and sorted on `order`. Ordering is assigned here: resume points first (movies and
# episodes together, most recent first), then next-episode rows in the user's nextep order.

import sys
from threading import Thread

from indexers.episodes import build_single_episode, continue_watching_plan
from indexers.movies import Movies
from modules import kodi_utils, settings
from modules import watched_status as ws



def _sort_time(entry):
	"""Best-effort recency key. Providers write ISO8601, the local DB writes
	'YYYY-mm-dd HH:MM:SS'; both sort correctly as plain strings once the 'T' is gone, and
	anything missing sorts last rather than raising."""
	value = entry.get('last_played') or entry.get('date') or ''
	return str(value).replace('T', ' ')


def build_continue_watching(params=None):
	params = params or {}
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	item_list = []
	try:
		watched_indicators = settings.watched_indicators()
		hidden = set(ws.get_hidden_progress_items(watched_indicators) or [])

		# --- resume points -------------------------------------------------------
		# LOCAL PATCH 2026-09-04: pass the hidden set built here, so callees do not derive it again
		# (under SIMKL indicators each derivation is several simkl_list() reads).
		resume_eps, upcoming_eps = continue_watching_plan(watched_indicators, hidden)
		try:
			resume_movies = ws.get_in_progress_movies(None, None) or []
		except Exception:
			resume_movies = []
		resume_movies = [i for i in resume_movies if _int(i.get('media_id')) not in hidden]

		# Movies and episodes are ranked against each other so the widget reflects what you
		# last touched, not which builder produced it.
		mixed = [('movie', i) for i in resume_movies] + [('episode', i) for i in resume_eps]
		mixed.sort(key=lambda kv: _sort_time(kv[1]), reverse=True)

		movie_entries, episode_entries, order = [], [], 0
		for kind, entry in mixed:
			if kind == 'movie':
				tmdb_id = _int(entry.get('media_id'))
				if tmdb_id is not None: movie_entries.append((order, tmdb_id))
			else:
				entry['custom_order'] = order
				episode_entries.append(entry)
			order += 1
		for entry in upcoming_eps:
			entry['custom_order'] = order
			episode_entries.append(entry)
			order += 1

		if not movie_entries and not episode_entries:
			return _finish(handle, [], is_external)

		# --- build both kinds in parallel ----------------------------------------
		def _movies():
			try:
				if movie_entries:
					item_list.extend(Movies({'list': movie_entries, 'custom_order': 'true'}).worker())
			except Exception: pass

		def _episodes():
			try:
				if episode_entries:
					result = build_single_episode('episode.continue', dict(params, prepared=episode_entries))
					if result: item_list.extend(result)
			except Exception: pass

		threads = [Thread(target=_movies), Thread(target=_episodes)]
		[t.start() for t in threads]
		[t.join() for t in threads]
		item_list.sort(key=lambda k: k[1])
		_apply_anilist_covers(item_list, episode_entries, movie_entries)
	except Exception:
		pass
	return _finish(handle, item_list, is_external)


def _int(value):
	try: return int(value)
	except (TypeError, ValueError): return None


def _finish(handle, item_list, is_external):
	# Content type is 'videos' rather than 'movies'/'episodes': the list holds both, and
	# claiming either makes skins apply a layout half the rows do not fit.
	kodi_utils.add_items(handle, [i[0] for i in item_list])
	kodi_utils.set_content(handle, 'videos')
	kodi_utils.set_category(handle, 'Continue Watching')
	kodi_utils.end_directory(handle, cacheToDisc=False)
	kodi_utils.set_view_mode('view.episodes_single', 'videos', is_external)


# LOCAL PATCH 2026-08-29: cour-accurate posters for the anime rows -- TMDb has one poster per show (Fribb maps every
# cour to one TMDb id), AniList keeps art per cour. Batched: one bulk AniList call per load, cached 30 days (AniList
# allows 30 requests a minute, so per-row calls would be throttled).
# Visible only in a Poster layout: AF3's Image_Landscape uses Art(thumb) (the episode still) for episodes. Next
# Episodes / In Progress Episodes skip this for that reason. Do not also set thumb: AF3's landscape chain compares
# thumb with poster to spot a portrait image posing as a still.
def _apply_anilist_covers(item_list, episode_entries, movie_entries):
	try:
		from apis.anilist_api import anilist_covers_bulk
		from caches import fribb_mappings
		from modules import settings
	except Exception:
		return
	# LOCAL PATCH 2026-09-04: gate before the Fribb index load (~124 ms), as seasons.py / tvshows.py do. Spares only
	# users without AniList: the plan entries carry no TMDb keywords to gate on.
	if not settings.anilist_user_active() or not fribb_mappings.is_available(): return
	wanted = {}          # position -> anilist id
	# LOCAL PATCH 2026-10-03: only rows that became items -- episode_entries is the whole plan, mostly dropped, and each
	# lookup can run Fribb's flat-season repair (its memo dies with the process).
	present = {position for _, position in item_list}
	for entry in episode_entries:
		if entry.get('custom_order') not in present: continue
		try:
			tmdb = int(entry['media_ids']['tmdb'])
			season, episode = int(entry['season']), int(entry['episode'])
		except (KeyError, TypeError, ValueError): continue
		# A next-episode row's plan holds the episode LAST WATCHED, while the row renders the next one,
		# possibly in the following cour. Prefer the lookahead when it resolves; for resume rows both agree.
		cour = None
		if entry.get('is_next'):
			cour = fribb_mappings.find_cour_by_tmdb_coords(tmdb, season, episode + 1)
		if not cour:
			cour = fribb_mappings.find_cour_by_tmdb_coords(tmdb, season, episode)
		anilist_id = (cour or {}).get('anilist')
		if anilist_id: wanted[entry.get('custom_order')] = anilist_id
	for position, tmdb_id in movie_entries:
		try: anilist_id = fribb_mappings.anilist_for_tmdb_movie(tmdb_id)
		except Exception: anilist_id = None
		if anilist_id: wanted[position] = anilist_id
	if not wanted: return
	movie_positions = {position for position, _ in movie_entries}
	covers = anilist_covers_bulk(set(wanted.values())) or {}
	for entry, position in item_list:
		cover = covers.get(wanted.get(position))
		if not cover: continue
		# thumb is the EPISODE STILL on an episode row (landscape), so episodes get poster art only.
		# A movie row's thumb IS its poster, so it is safe there.
		art = {'poster': cover}   # LOCAL PATCH 2026-09-14: season./tvshow. keys dropped, see the note at _art in indexers/episodes.py
		if position in movie_positions: art = {'poster': cover, 'thumb': cover}
		try: entry[1].setArt(art)
		except Exception: pass
