# created by Venom for Fenomscrapers
"""
	Fenomscrapers Project
"""

import re
from magneto.modules import anime_utils
from magneto.modules.provider_base import StremioSource, anime_file_reject, anime_pack_reject, tag_batch


def _one_row_per_hash(rows):
	"""LOCAL PATCH 2026-10-21: torrentio can answer one episode with SEVERAL files of the same torrent (the episode and
	an 'Extras/...' file), all carrying the pack's name, so no name filter tells them apart. Keeps each hash's LARGEST
	file (an extra is always smaller than its episode), at the first row's place."""
	best = {}
	for i, row in enumerate(rows):
		key = (row.get('hash') or '').lower()
		if key not in best: best[key] = (i, row)
		elif (row.get('size') or 0) > (best[key][1].get('size') or 0): best[key] = (best[key][0], row)
	return [row for i, row in sorted(best.values(), key=lambda x: x[0])]


# LOCAL PATCH 2026-11-01 (cleanup): the sources / sources_packs bodies are provider_base.StremioSource's; this file keeps what
# is torrentio's own -- the Kitsu paths, its '👤 seeders' info line (at the start of a line, first number on it), the film
# title without the SVU swap and with a year either side, the anime checks and _one_row_per_hash on every answer.
class source(StremioSource):
	provider = 'torrentio'
	base_link = "https://torrentio.strem.fun"
	# LOCAL PATCH 2026-08-09: kitsu path for anime -- cour-scoped at the source, no cross-cour contamination.
	tvSearch_link_kitsu = '/stream/series/kitsu:%s:%s.json'
	_INFO = re.compile(r'👤.*')
	_SEEDERS = re.compile(r'(\d+)')
# Currently supports YTS(+), EZTV(+), RARBG(+), 1337x(+), ThePirateBay(+), KickassTorrents(+), TorrentGalaxy(+), HorribleSubs(+), NyaaSi(+), NyaaPantsu(+), Rutor(+), Comando(+), ComoEuBaixo(+), Lapumia(+), OndeBaixa(+), Torrent9(+).

	def _query(self, data):
		q = super()._query(data)
		q['kitsu_mode'] = q['kitsu_film'] = False
		if not q['tv']:
			q['title'] = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
			q['years'] = [str(int(q['year'])-1), str(q['year']), str(int(q['year'])+1)]
		return q

	def _search_url(self, data, q):
		if q['tv']:
			# LOCAL PATCH 2026-08-09: prefer the kitsu path when DeadLight passed kitsu_id + cour_episode (the imdb path leaks
			# across cours).
			kitsu_id, cour_ep = data.get('kitsu_id'), data.get('cour_episode')
			q['kitsu_mode'] = bool(kitsu_id) and cour_ep is not None
			if q['kitsu_mode']: return '%s%s' % (self.base_link, self.tvSearch_link_kitsu % (kitsu_id, cour_ep))
			return super()._search_url(data, q)
		# LOCAL PATCH 2026-10-06: an anime film with no IMDb id is asked for by its Kitsu id. With an IMDb id, unchanged.
		q['kitsu_film'] = bool(data.get('kitsu_id')) and not anime_utils.real_imdb(q['imdb'])
		return '%s%s' % (self.base_link, self.movieSearch_link % ('kitsu:%s' % data['kitsu_id'] if q['kitsu_film'] else q['imdb']))

	def _lines(self, file):
		return file['title'].split('\n')

	def _info_line(self, lines):
		return [x for x in lines if self._INFO.match(x)][0]

	def _filename(self, file, lines):
		return (file.get('behaviorHints') or {}).get('filename') or (lines[1] if len(lines) > 1 and not self._INFO.match(lines[1]) else '')

	def _episode_ok(self, file, lines, name, data, q):
		# LOCAL PATCH 2026-11-04 (release judge, phase 4b): anime TV rows are judged by modules/release_judge after the cache
		# (release_judge._TAKEN_OVER, 'stremio'). Films and non-anime shows: checked below.
		if q['tv'] and data.get('is_anime'): return True
		# LOCAL PATCH 2026-08-09: no SxxEyy name check in kitsu mode -- the kitsu endpoint already matched the episode (fileIdx
		# points into batches), and anime batch names carry no S01E43, so check_title rejected every kitsu row.
		# LOCAL PATCH 2026-10-06: a Kitsu-asked film is judged by title only: older film releases often carry no year.
		if not (q['kitsu_mode'] or q['kitsu_film']):
			if not self._check_title(name, q): return False
		# LOCAL PATCH 2026-08-27: kitsu mode still checks the SHOW -- a bad id can return the right episode number of a
		# different series. See anime_utils.title_guard.
		elif not anime_utils.title_guard(name, q['title'], anime_utils.alias_titles(data)): return False
		# LOCAL PATCH 2026-10-05: on anime, judge the FILE torrentio picked (behaviorHints.filename) --
		# provider_base.anime_file_reject. Nothing stricter: Kitsu answers are entry-scoped, and reading the file's numbers
		# only lost right rows (SubsPlease's 'Solo Leveling - 13' is S2E1 in its numbering).
		if data.get('is_anime') and anime_file_reject(self._filename(file, lines), lines[0], q['title'], data): return False
		return True

	def _pack_ok(self, file, lines, name, package, data):
		if data.get('is_anime'): return True   # LOCAL PATCH 2026-11-04: the judge's (anime_pack_reject), see _episode_ok
		return not (data.get('is_anime') and anime_pack_reject(lines[0], self._filename(file, lines), package, data))

	def _tag(self, item, name, data, q):
		# LOCAL PATCH 2026-10-03: the size is already the episode file's and torrentio is on the no-divide list (no true_size)
		if q['kitsu_mode']: tag_batch(item, name, data, true_size=False)

	def _finish(self, rows):
		return _one_row_per_hash(rows)
