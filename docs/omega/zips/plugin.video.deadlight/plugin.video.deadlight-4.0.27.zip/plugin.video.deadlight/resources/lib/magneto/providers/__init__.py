# LOCAL PATCH 2026-11-01 (cleanup): emptied -- the provider lists built here (all_providers, total_providers, ...) were read by nothing; magneto.sources() loads the providers.
