# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-07: Trakt per-episode UTC airtimes.
#
# TMDb has only date-precision `air_date`, so the aired-check otherwise assumes "20:00 local" + the user's
# `datetime.offset` -- wrong for streaming drops (midnight PT), US prime time and late-night JST anime. Trakt has UTC
# `first_aired` for ~90% of mainstream shows; used when Trakt is authorized.
#
# API: get_season_air_times(imdb_id, tmdb_id, season) -> {ep_number: iso_utc_str}
#      parse_utc(iso_str) -> naive local datetime (matches DeadLight convention)
#
# Cache: slugs forever (never change); season airtimes 24h so reschedules land within a day.
# All failures are silent -- caller falls back to TMDb behavior.

import time
from datetime import datetime, timezone

from apis.trakt_api import call_trakt, _trakt_rating_acceptable
from caches.trakt_cache import trakt_cache
from modules import settings
from modules.kodi_utils import logger
from modules.utils import safe_err   # LOCAL PATCH 2026-10-25 (4.0.5): request errors logged without their url / query keys


_TTL_SECONDS = 24 * 3600
# LOCAL PATCH 2026-09-26: a finished season keeps its airtimes 30 days (they cannot change; most cached seasons are
# finished). 'Finished' = EVERY episode has a date and the newest is over 14 days old, so a season with a null or
# future episode stays on the 24h refresh.
_FINISHED_TTL_SECONDS = 30 * 24 * 3600
_FINISHED_AFTER_SECONDS = 14 * 24 * 3600


def _ttl_for(cached):
	"""TTL for a cached season row. `_n` is the season's episode count INCLUDING episodes with no
	first_aired, which the stored map leaves out -- without it an unannounced episode is invisible.
	Rows written before `_n` existed get the short TTL and gain it on their next refresh."""
	data, total = cached.get('data') or {}, cached.get('_n')
	if not data or total != len(data): return _TTL_SECONDS
	try:
		newest = max(_utc_from_iso(v).timestamp() for v in data.values())
	except (TypeError, ValueError): return _TTL_SECONDS
	return _FINISHED_TTL_SECONDS if time.time() - newest > _FINISHED_AFTER_SECONDS else _TTL_SECONDS


def _slug_key(tmdb_id):
	return 'trakt_slug_tmdb_%s' % tmdb_id


def _season_air_key(show_id, season):
	return 'trakt_air_%s_S%s' % (show_id or 'x', season)


def _resolve_slug(imdb_id, tmdb_id):
	"""Cached slug lookup. Prefers tmdb-search (works ~100% for shows on Trakt);
	falls back to imdb-search when tmdb_id is missing."""
	if not tmdb_id and not imdb_id: return None
	cache_id = tmdb_id or imdb_id
	cached = trakt_cache.get(_slug_key(cache_id))
	if cached: return cached
	slug = None
	if tmdb_id:
		try:
			res = call_trakt('search/tmdb/%s' % tmdb_id, params={'type': 'show'}, with_auth=False, pagination=False)
			if res and isinstance(res, list) and res:
				slug = res[0].get('show', {}).get('ids', {}).get('slug')
		except Exception: pass
	if not slug and imdb_id:
		try:
			res = call_trakt('search/imdb/%s' % imdb_id, params={}, with_auth=False, pagination=False)
			if res and isinstance(res, list):
				for it in res:
					if it.get('type') == 'show':
						slug = it.get('show', {}).get('ids', {}).get('slug')
						if slug: break
		except Exception: pass
	if slug: trakt_cache.set(_slug_key(cache_id), slug)
	return slug


# LOCAL PATCH 2026-09-04: season map keys back to int on the way out of the cache. metadata.episodes_meta looks it up
# with the int episode number, but JSON stringifies int keys, so a cached row keyed '1' silently misses and the season
# falls back to "TMDb date + 20:00 local". Done here, not in the cache layer, so it works whichever serialisation the
# row was written with (legacy repr rows have real int keys).
def _int_keyed(mapping):
	if not isinstance(mapping, dict): return {}
	out = {}
	for k, v in mapping.items():
		try: out[int(k)] = v
		except (TypeError, ValueError): continue
	return out


def get_season_air_times(imdb_id, tmdb_id, season):
	"""Return {episode_number: '2026-08-07T01:00:00.000Z' (UTC)} for the season.
	Empty dict when Trakt unavailable / show not on Trakt / season not on Trakt.
	Silent — never raises."""
	try:
		if not settings.trakt_user_active(): return {}
	except Exception: return {}
	if season is None: return {}
	try: season_int = int(season)
	except (TypeError, ValueError): return {}
	if season_int <= 0: return {}
	key = _season_air_key(imdb_id or tmdb_id, season_int)
	cached = trakt_cache.get(key)
	if cached and isinstance(cached, dict):
		try:
			if time.time() - cached.get('_ts', 0) < _ttl_for(cached):
				return _int_keyed(cached.get('data'))
		except Exception: pass
	slug = _resolve_slug(imdb_id, tmdb_id)
	if not slug: return {}
	try:
		# /shows/{slug}/seasons/{n}?extended=full,episodes: one call, every episode with first_aired UTC.
		eps = call_trakt('shows/%s/seasons/%s' % (slug, season_int),
						 params={'extended': 'full,episodes'}, with_auth=False, pagination=False)
		if not isinstance(eps, list): return {}
		result, ratings = {}, {}
		for ep in eps:
			try:
				n = int(ep.get('number') or 0)
				fa = ep.get('first_aired')
				if n and fa: result[n] = fa
				# LOCAL PATCH 2026-10-03 (3.0.8): the same reply carries each episode's Trakt rating; kept here so
				# trakt_season_episode_ratings needs no second request.
				if n and _trakt_rating_acceptable(ep.get('rating'), ep.get('votes')): ratings[n] = '%.1f' % round(float(ep['rating']), 1)
			except Exception: continue
		trakt_cache.set(key, {'_ts': time.time(), 'data': result, 'ratings': ratings,
							'_n': sum(1 for ep in eps if isinstance(ep, dict) and ep.get('number'))})
		return result
	except Exception as e:
		logger('trakt_air', 'fetch failed %s S%s: %s' % (slug, season_int, safe_err(e)))
		return {}


def cached_season_ratings(show_id, season):
	"""LOCAL PATCH 2026-10-03 (3.0.8): {episode: '8.3'} from a fresh get_season_air_times row, or None when there is
	no such row (Trakt not signed in, never fetched, expired, or written before ratings were kept). Never a request."""
	try:
		cached = trakt_cache.get(_season_air_key(show_id, int(season)))
		if not isinstance(cached, dict) or 'ratings' not in cached: return None
		if time.time() - cached.get('_ts', 0) >= _ttl_for(cached): return None
		return _int_keyed(cached.get('ratings'))
	except Exception: return None


# LOCAL PATCH 2026-10-03: no datetime.strptime in this module. Kodi's embedded Python raises TypeError("'NoneType'
# object is not callable") from strptime on worker threads (see modules/utils.py), and every caller here runs on a
# TaskPool thread -- so it failed only inside Kodi, never in a harness. Trakt's format is fixed, so read the digits.
def _utc_from_iso(ts):
	"""'2026-10-02T14:40:00.000Z' (fraction and Z optional) -> aware UTC datetime. ValueError on anything else."""
	s = str(ts).strip()
	if len(s) < 19 or s[4] != '-' or s[7] != '-' or s[10] != 'T' or s[13] != ':' or s[16] != ':':
		raise ValueError('not an ISO 8601 UTC timestamp: %r' % ts)
	return datetime(int(s[0:4]), int(s[5:7]), int(s[8:10]), int(s[11:13]), int(s[14:16]), int(s[17:19]), tzinfo=timezone.utc)


def parse_utc_to_local(ts):
	"""Convert Trakt ISO 8601 UTC ('2026-08-07T01:00:00.000Z') to a naive local datetime.

	LOCAL PATCH 2026-08-29: this used to add `deadlight.datetime.offset` to the UTC value,
	treating it as the UTC->local offset in hours. It is not that. settings.date_offset()
	reads the SAME setting as `value + 5` for the 20:00 airtime guess, so the two consumers
	disagree about what it means, and being an integer it cannot express a half-hour zone
	at all. On an IST (UTC+5:30) box with the setting at -4 the result was 9.5 hours early:
	Daemons of the Shadow Realm S01E21 airs 20:00 IST, was computed as 10:30, and so
	appeared in Continue Watching most of a day before airing.

	The system timezone is the correct source and needs no configuration -- it is exact,
	handles half-hour offsets, and follows DST. Kodi's convention here is naive local
	(datetime.now()), so the tzinfo is stripped on the way out.
	"""
	if not ts: return None
	try: return _utc_from_iso(ts).astimezone().replace(tzinfo=None)
	except Exception: return None
