# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-11-08: the downloads manager's Completed section. The downloader writes one record per finished file
# (modules/downloader.finish_download); the manager lists them under the active rows (windows/downloads_manager). A small
# JSON file in the addon profile, newest first: it outlives a restart, unlike the Home properties the active rows use.
import os
import json
import time
from modules import kodi_utils

KEEP = 30   # records kept, newest first

def _path():
	return os.path.join(kodi_utils.addon_profile(), 'completed_downloads.json')

def load():
	"""The records whose file is still there, newest first. A file deleted outside Kodi drops its record on the next save."""
	try:
		with kodi_utils.open_file(_path()) as f: records = json.loads(f.read() or '[]')
	except Exception: return []
	return [r for r in records if isinstance(r, dict) and r.get('path') and kodi_utils.path_exists(r['path'])]

def _save(records):
	try:
		with kodi_utils.open_file(_path(), 'w') as f: f.write(json.dumps(records[:KEEP]))
	except Exception: pass

def add(name, path, size_mb, image='', media_type=''):
	records = [r for r in load() if r.get('path') != path]   # a re-download replaces its old record
	records.insert(0, {'name': name, 'path': path, 'size_mb': int(size_mb or 0), 'finished': int(time.time()),
					   'image': image or '', 'media_type': media_type or ''})
	_save(records)

def remove(path):
	_save([r for r in load() if r.get('path') != path])

def remove_empty_folders(path):
	"""After a file is deleted: its season / show folder if that left it empty, up to (not including) the '... Downloads' root."""
	folder = os.path.dirname(path)
	while folder and not os.path.basename(folder).endswith(' Downloads'):
		try: os.rmdir(folder)   # only succeeds on an empty folder
		except OSError: break
		folder = os.path.dirname(folder)

def detail(record):
	"""'1.0 GB  •  Today 23:41  •  TV Show Downloads' -- size, when, and the downloads folder it went to."""
	mb = record.get('size_mb', 0)
	size = '%.1f GB' % (mb / 1024.0) if mb >= 1024 else '%d MB' % mb
	when = record.get('finished', 0)
	day = time.strftime('%Y-%m-%d', time.localtime(when))
	if day == time.strftime('%Y-%m-%d'): day = 'Today'
	elif day == time.strftime('%Y-%m-%d', time.localtime(time.time() - 86400)): day = 'Yesterday'
	else: day = time.strftime('%d %b', time.localtime(when)).lstrip('0')
	folder = next((p for p in record.get('path', '').replace('\\', '/').split('/') if p.endswith(' Downloads')), '')
	return '  •  '.join(filter(None, (size, '%s %s' % (day, time.strftime('%H:%M', time.localtime(when))), folder)))
