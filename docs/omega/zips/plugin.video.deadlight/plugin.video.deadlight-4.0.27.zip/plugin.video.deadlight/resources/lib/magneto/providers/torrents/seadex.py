# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-27: SeaDex provider -- the curated best release, by ID.
# releases.moe is a small hand-maintained index (~2,800 anime) naming the best release of each anime (group, infoHash,
# full file listing), keyed on AniList id, which scrapers/external.py already passes as data['anilist_id'].
# The other providers sort by seeders (popularity); SeaDex names what to watch, often a release the seeder sort buries,
# and nearly all its picks are already debrid-cached -- the reason it is useful for streaming.
# Releases are cour PACKS; because the API hands over the file list, this provider locates the episode's file up front,
# skipping a release that lacks it (some entries are `incomplete`) and reporting the true file size.
# API: https://releases.moe/api/collections/entries/records?filter=alID=<id>&expand=trs -- no key, no auth.

import re

from magneto.modules import client
from magneto.modules import source_utils

try:
	import json as _json
except ImportError:
	_json = None

_API = ('https://releases.moe/api/collections/entries/records'
		'?filter=alID=%s&expand=trs&perPage=1')

# Trackers a magnet needs to be usable if a debrid service has to fetch it fresh.
# SeaDex stores only the infoHash, so the magnet is assembled here.
_TRACKERS = (
	'http://nyaa.tracker.wf:7777/announce',
	'udp://open.stealth.si:80/announce',
	'udp://tracker.opentrackr.org:1337/announce',
	'udp://exodus.desync.com:6969/announce',
	'udp://tracker.torrent.eu.org:451/announce',
)

_VIDEO = ('.mkv', '.mp4', '.avi', '.m4v', '.ts')

# In the pack but not the show: openings, endings, previews, menus, extras. Kept out
# of episode matching so an "NCOP 01" cannot answer a request for episode 1.
_NOT_AN_EPISODE = re.compile(
	r'(?:^|[^a-z0-9])(?:nc)?(?:op|ed)\d*(?:[^a-z0-9]|$)|'
	r'(?:^|[^a-z0-9])(?:menu|preview|pv|cm|extra|extras|bonus|interview|'
	r'trailer|teaser|creditless|clean|sample|logo|special|specials|'
	r'sp\d+|oad|ova|omake|recap)(?:[^a-z0-9]|$)', re.I)


# LOCAL PATCH 2026-09-24: '<show> - 681 - <title>' -- the episode a name states after a dash, on the space-normalised name.
_DASH_NUMBER = re.compile(r'(?:^| )- ?0*(\d{1,4})(?=[ \[(]|$)')
# LOCAL PATCH 2026-09-24: a bit-depth tag is not an episode number (' 10 bit' answered episode 10). Same rule as
# DeadLight's _RE_BIT_DEPTH.
_BIT_DEPTH = re.compile(r'(?<![a-z0-9])(?:8|10|12) ?bits?(?![a-z0-9])', re.I)


def _episode_in(name, season, episode, bare=True):
	"""True when `name` is episode `episode` (of `season`), on clean digit edges.

	Deliberately narrow: this runs over the files of ONE known anime, so only the number has to be read and the loose
	fallbacks of a search provider (and their false positives) are left out.
	"""
	n = _BIT_DEPTH.sub(' ', re.sub(r'[._]+', ' ', name))
	e2 = '%02d' % episode
	marked = (
		# LOCAL PATCH 2026-09-24: any padding ('S001E001', 'EP0001'); the right edge (?!\d) keeps e0*1 from reading e10.
		# The BARE 'e' form keeps its two digits and may only gain zeros: a CRC32 tag is hex ('[e2ad4da5]' would read
		# episode 2). The shared corpus addon_patches/anime_names keeps this and DeadLight's matcher in step.
		r'\bs0*%d ?e0*%d(?!\d)' % (season, episode),
		r'\be0*%s(?!\d)' % e2,
		r'\bep(?:isode)? ?0*%d(?!\d)' % episode,
		r'(?<!\d)- ?%s(?!\d)' % e2,          # "[Group] Show - 07"
		r'(?<!\d)- ?%d(?!\d)' % episode,     # "- 7" and "- 107"
		r'\[%s\](?!\d)' % e2,
	)
	# LOCAL PATCH 2026-09-24: BARE numbers stand down once the name states a different episode after a dash ('One Piece -
	# 681 - The 500 Million Berry Man!' is not 500). Same rule as DeadLight's seas_ep_filter (string7).
	dash = _DASH_NUMBER.search(n)
	# bare=False: _pick_file found this file outside its pack's dash convention, same stand-down
	if not bare or (dash and int(dash.group(1)) != int(episode)): return any(re.search(p, n, re.I) for p in marked)
	bare = (
		# LOCAL PATCH 2026-09-23: the left edge must be a SPACE, not merely a non-digit: otherwise it reads the tail of an
		# SxxExx tag ('One Piece S10E22 (0358)' answered S01E22 -- SeaDex files One Piece as one whole-run entry) and
		# 'x264 (1080p)' answers episode 264.
		r'(?:(?<= )|^)%s(?!\d)(?= ?[\[(])' % e2,  # "Show 07 [1080p]"
		# LOCAL PATCH 2026-09-22: a bare number between separators, nothing bracketed after it -- 'Naruto.220.v4.480p.DVD...mkv',
		# the usual shape of older DVD batches, which no pattern above reads. Both sides must be a SPACE (dots / underscores are
		# normalised above) so 'v4' and 'x264' cannot answer. Any padding ('Naruto 007'; LOCAL PATCH 2026-09-24: 'One Piece 0500').
		r'(?<= )0*%d(?= )' % episode,
	)
	return any(re.search(p, n, re.I) for p in marked + bare)


def _pick_file(files, candidates):
	"""The file dict for the requested episode, trying candidates in order.

	Highest episode number first, as the debrid resolver does: a pack numbered absolutely DOES hold a file whose number
	matches the cour-relative one -- and it is the wrong episode.
	"""
	usable = [f for f in files
			if isinstance(f, dict)
			and (f.get('name') or '').lower().endswith(_VIDEO)
			and not _NOT_AN_EPISODE.search(f.get('name') or '')]
	if not usable: return None
	# LOCAL PATCH 2026-09-24: the pack's naming convention -- when two thirds of its files (4 or more) state their episode
	# after a dash, one that does not (a recap) answers only through an explicit marker. Same rule as pick_episode_files.
	outside = set()
	if len(usable) >= 4:
		dashed = [bool(_DASH_NUMBER.search(re.sub(r'[._]+', ' ', f['name']))) for f in usable]
		if sum(dashed) * 3 >= len(usable) * 2: outside = set(i for i, d in enumerate(dashed) if not d)
	for season, episode in candidates:
		for i, f in enumerate(usable):
			if _episode_in(f['name'], season, episode, bare=i not in outside): return f
	# A single-file entry for a single episode needs no matching at all.
	# LOCAL PATCH 2026-10-15: only when the RELEASE holds one video, not when one is left after the extras filter (a pack of
	# OVAs, or an incomplete entry, then answered every episode number).
	if len(usable) == 1 and sum(1 for f in files if isinstance(f, dict) and (f.get('name') or '').lower().endswith(_VIDEO)) == 1:
		return usable[0]
	return None


class source:
	# Every SeaDex release is already a pack; there is no separate pack query to make,
	# and DeadLight must not ask for one (there is no sources_packs here).
	pack_capable = False
	hasMovies = False
	hasEpisodes = True

	def __init__(self):
		self.base_link = 'https://releases.moe'
		# SeaDex records no seeder counts and its point is the debrid cache, so seeders gate nothing (no min_seeders).
		# 2026-09-26: set when releases.moe did not answer, so DeadLight does not cache the empty result (same contract as
		# nekobt/animetosho). "No SeaDex entry" (JSON with empty items) is a real answer and stays cacheable.
		self.request_failed = False

	def _candidates(self, data):
		"""(season, episode) numberings to look for, highest episode number first.

		LOCAL PATCH 2026-08-27: reads the list DeadLight publishes (data['episode_candidates']) rather than re-deriving it, so
		this provider and the debrid resolver -- choosing a file out of the same pack -- never disagree about which numbers
		count. The local build is a fallback for direct callers (tests).
		"""
		published = data.get('episode_candidates')
		if published:
			out = []
			for pair in published:
				try: out.append((int(pair[0]), int(pair[1])))
				except (TypeError, ValueError, IndexError): continue
			if out: return out
		def _int(key):
			try: return int(data.get(key))
			except (TypeError, ValueError): return None
		season = _int('season')
		if season is None: season = 1   # not `or 1`: season 0 (specials) is falsy
		cour_season = _int('cour_season') or season
		out = []
		for number, use_season in ((_int('absolute_episode'), season),
						(_int('episode'), season),
						(_int('season_episode'), cour_season),
						(_int('cour_episode'), cour_season)):
			if number and (use_season, number) not in out: out.append((use_season, number))
		out.sort(key=lambda pair: -pair[1])
		return out

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		append = sources.append
		alid = data.get('anilist_id')
		# Without an AniList id there is nothing to look up; those shows are left to the other providers.
		if not alid: return sources
		try:
			response = client.request(_API % alid, timeout=10)
			if not response:
				self.request_failed = True
				return sources
			payload = _json.loads(response)
			items = (payload or {}).get('items') or []
			if not items: return sources
			entry = items[0]
			torrents = (entry.get('expand') or {}).get('trs') or []
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except Exception:
			source_utils.scraper_error('SEADEX')
			return sources

		# Public tracker only: SeaDex also indexes private trackers, whose entries
		# carry no usable infoHash and which no debrid service could fetch anyway.
		nyaa = [t for t in torrents if isinstance(t, dict) and t.get('tracker') == 'Nyaa'
				and len(t.get('infoHash') or '') == 40]
		# `isBest` is SeaDex's verdict; fall back to the rest only when nothing is flagged, so a SEADEX row IS the curated pick.
		best = [t for t in nyaa if t.get('isBest')] or nyaa
		if not best: return sources

		candidates = self._candidates(data)
		incomplete = bool(entry.get('incomplete'))
		seen = set()
		for torrent in best:
			try:
				info_hash = torrent['infoHash'].lower()
				if info_hash in seen: continue
				chosen = _pick_file(torrent.get('files') or [], candidates)
				# No file for this episode (an `incomplete` release, or another season): it would be a source that cannot play.
				if not chosen: continue
				name = source_utils.clean_name(chosen['name'])
				if not name: continue
				name_info = source_utils.info_from_name(
					name, data.get('tvshowtitle') or '', str(data.get('year') or ''),
					season=str(data.get('season') or ''))
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				magnet = 'magnet:?xt=urn:btih:%s&dn=%s%s' % (
					info_hash, name, ''.join('&tr=%s' % t for t in _TRACKERS))
				quality, info = source_utils.get_release_quality(name_info, magnet)
				# The size of the FILE that will play, not of the pack (others can only divide the pack size).
				dsize = round(float(chosen.get('length') or 0) / 1073741824, 2)
				if dsize: info.insert(0, '%.2f GB' % dsize)
				# LOCAL PATCH 2026-08-27: label multi-episode releases as packs. Safe only because seadex is in scrapers/external.py's
				# no-divide list -- otherwise this per-file size would be divided by the season's episode_count.
				videos = [f for f in (torrent.get('files') or [])
						if isinstance(f, dict) and (f.get('name') or '').lower().endswith(_VIDEO)]
				package = 'season' if len(videos) > 1 else None
				if package:
					total = sum(float(f.get('length') or 0) for f in videos) / 1073741824
					if total: info.append('%.1f GB pack' % total)
				group = torrent.get('releaseGroup')
				if group: info.append('SEADEX %s' % group)
				if torrent.get('dualAudio'): info.append('DUAL AUDIO')
				if incomplete: info.append('INCOMPLETE RELEASE')

				seen.add(info_hash)
				item = {'provider': 'seadex', 'source': 'torrent', 'seeders': 0,
						'hash': info_hash, 'name': name, 'name_info': name_info,
						'quality': quality, 'language': 'en', 'url': magnet,
						'info': ' | '.join(info), 'direct': False, 'debridonly': True,
						'size': dsize}
				if package: item['package'] = package
				append(item)
			except Exception:
				source_utils.scraper_error('SEADEX')
				continue
		return sources
