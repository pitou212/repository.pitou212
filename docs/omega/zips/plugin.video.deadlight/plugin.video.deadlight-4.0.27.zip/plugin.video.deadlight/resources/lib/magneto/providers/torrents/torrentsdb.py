# created by kodifitzwell for Fenomscrapers
"""
	Fenomscrapers Project
"""

from magneto.modules.provider_base import StremioSource


# LOCAL PATCH 2026-11-01 (cleanup): the sources / sources_packs bodies are provider_base.StremioSource's; this file keeps what
# is torrentsdb's own -- its address and the stream text in 'title' only.
class source(StremioSource):
	provider = 'torrentsdb'
	base_link = "https://torrentsdb.com"
# Currently supports YTS(+), EZTV(+), 1337x(+), TorrentCSV(+), 1lou(+), Nyaa(+), Sk-CzTorrent(+), 1TamilBlasters(+), LimeTorrent(+), 1TamilMV(+), RARBG(+), Knaben(+), ThePirateBay(+), KickassTorrents(+), AnimeTosho(+), ExtremlymTorrents(+), YggTorrent(+), TokyoTosho(+), Rutor(+), Rutracker(+), Torrent9(+), ilCorSaRoNeRo(+), Manual(+).

	def _lines(self, file):
		return file['title'].split('\n')
