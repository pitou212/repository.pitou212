"""
	Fenomscrapers Module
"""

import importlib
import os
from pkgutil import walk_packages
from magneto.modules.control import setting as getSetting

# LOCAL PATCH 2026-11-01 (cleanup): 'torrents' is the only provider folder, so it is named here instead of walked; the
# unused module-level `debug` flag (a 'debug.enabled' setting DeadLight never had) is gone.
_FOLDER = os.path.join(os.path.dirname(__file__), 'providers', 'torrents')

def sources(specified_folders=None, ret_all=False, only=None):
	# LOCAL PATCH 2026-10-05 (DeadLight): only = the provider names to load, switch or not (the anime list, see
	# modules/sources.external_sources); the others are not even imported.
	# specified_folders is accepted for the callers (modules/sources.py passes ['torrents']) and not needed.
	try:
		sourceDict = []
		for loader, module_name, is_pkg in walk_packages([_FOLDER]):
			if is_pkg: continue
			if only is not None:
				if module_name not in only: continue
			elif not ret_all and not enabledCheck(module_name): continue
			try:
				module = importlib.import_module('.providers.torrents.%s' % module_name, package=__name__)
				sourceDict.append((module_name, module.source))
			except Exception:
				# LOCAL PATCH 2026-10-21 (from POV 6.10.17): error(), not log() -- log() is silent while magneto's debug log
				# is off, so a provider that failed to import simply vanished from every scrape with nothing in kodi.log
				from magneto.modules import log_utils
				log_utils.error('Loading module "%s"' % module_name)
		return sourceDict
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return []

def enabledCheck(module_name):
	try:
		if getSetting('provider.' + module_name) == 'true': return True
		else: return False
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return True
