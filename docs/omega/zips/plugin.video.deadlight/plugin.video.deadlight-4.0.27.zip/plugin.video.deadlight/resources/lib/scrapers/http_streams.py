# -*- coding: utf-8 -*-
# LOCAL PATCH (2026-06-12): HTTP Streams scraper for DeadLight.
# Hosts two direct-URL providers ported from plugin.video.tmdbmovies (Angelitto):
#   - HDHub   (JSON aggregator at hdhub.thevolecitor.qzz.io)
#   - HDHub4u (HDHub4u → MKVCinemas redirect-chain web scraper, movie-only)
#
# The heavy lifting (~2000 lines of regex-driven page parsing, redirect chasing,
# cloud-page processing) lives in `_http_providers_core.py` as a near-verbatim
# extraction of the upstream code. This wrapper does the DeadLight glue:
#   - reads info dict, applies per-provider settings gates
#   - calls into core functions in parallel
#   - converts core's stream dicts to DeadLight's source dict format
#   - external_cache (SQLite) for repeat scrapes
#   - URL hash dedup
import hashlib
import re
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
from caches.settings_cache import get_setting
from modules import source_utils
from modules.settings import filter_by_name
from modules.kodi_utils import make_session

# LOCAL PATCH 2026-08-29: pooled session for the validation probes, as in aiostreams.py -- ~25 probes over a handful
# of hosts; a bare requests.head pays a TCP+TLS handshake each (~25 s vs ~11 s pooled).
_session = make_session('https://')


# LOCAL PATCH 2026-09-26: the display name, without the upstream formatter's debris. HDHub rows glue three layers:
#   '<filename>|^|<squashed tag block>.pad-<source> 📡 <title> • S02E05 🎞️ 4K • MKV ... 🛰️ Source: ... 🎧 Audio: ...'
# Rows with no filename start at the tag block. Kept: the filename, else the description's title, episode and tags.
# Dropped: tag block, bitrate, Source/Audio tail (own columns / extraInfo). Display only -- quality and extraInfo are
# parsed from the full text. Films open the description with 🍿 instead of 📡.
_DESC_START = re.compile('\U0001f4e1|\U0001f37f')  # 📡 episodes / 🍿 films
_DESC_STOP = re.compile(r'(?:\U0001f6f0️?|\U0001f3a7)')  # 🛰️ source / 🎧 audio
_DESC_SPLIT = re.compile(r'\s*(?:•|\U0001f39e️?)\s*')  # • and 🎞️
_BITRATE = re.compile(r'^~?\s*[\d.,]+\s*[kmg]bps$', re.I)
_TAG_BLOCK = re.compile(r'^\S*\.pad-\S+\s*')
# An archive EXTENSION: '.zip' not followed by a word char, dot or dash. Not \b: that hits a title
# word ('The.Zip.Code.S01E01.mkv').
_ZIP = re.compile(r'\.zip(?![\w.-])', re.I)
# a HubCloud link page (hubcloud.ist / .cx / ... /drive/<id>): HTML, not media -- see the 10gbps check
_HUBCLOUD_PAGE = re.compile(r'^https?://(?:[\w-]+\.)*hubcloud\.[a-z]{2,}/drive/', re.I)
_MIRROR = re.compile(r'Source:\s*[^·|\n]*·\s*([A-Za-z0-9][\w.-]*)')  # 'Source: MoviesDrives · FSL' -> FSL


# LOCAL PATCH 2026-11-08: 4KHDHub's own name in a row ('4KHDHub', '4kHdHub.Com'), cut out before the quality parse (_make_item)
_SITE_4K = re.compile(r'4k[\s._-]?hd[\s._-]?hub(?:[\s._-]?(?:com|ms|ist))?', re.I)


def _clean_display(raw):
	raw = (raw or '').strip()
	head, sep, tail = raw.partition('|^|')
	if sep and head.strip(): return head.strip()
	text = tail if sep else raw
	start = _DESC_START.search(text)
	if start:
		desc = _DESC_STOP.split(text[start.end():], 1)[0]
		parts = [p.strip() for p in _DESC_SPLIT.split(desc)]
		parts = [p for p in parts if p and not _BITRATE.match(p)]
		if parts: return ' '.join(parts)
	return _TAG_BLOCK.sub('', text).strip() or raw


# LOCAL PATCH 2026-08-29: the pre-signed expiry helpers live in source_utils (shared with aiostreams).


class source:
	def __init__(self):
		self.scrape_provider = 'http_streams'
		self.sources = []
		self.timeout = 25

	def results(self, info):
		media_type = info.get('media_type')
		tmdb_id = info.get('tmdb_id')
		title = info.get('title') or ''
		year = info.get('year', '')
		season_key = info.get('season') if media_type == 'episode' else ''
		episode_key = info.get('episode') if media_type == 'episode' else ''
		imdb = info.get('imdb_id') or ''

		# Cache lookup (skip if no tmdb_id since cache is keyed by it)
		if tmdb_id:
			try:
				from caches.external_cache import external_cache
				cached = external_cache.get('http_streams', media_type, tmdb_id, title, year, season_key, episode_key)
				if cached is not None:
					self.sources = self._drop_other_titles(cached, info)
					return self._return()
			except Exception: pass

		# Master gate
		if get_setting('deadlight.provider.http_streams', 'false') != 'true':
			return self._return()
		# LOCAL PATCH 2026-09-22: fall back to a `tmdb:` id when TMDb has no IMDb (regional TV, anthology seasons).
		# Both upstreams declare `tmdb:` in their manifests, but HDHub honours it for movies only (series answer 0),
		# hence the series-only skip below. Not the Cinemeta parent-imdb remap (Red Light 2.6.4): these upstreams index
		# a show the way TMDb numbers it, and the remapped id returned nothing where tmdb: did.
		imdb = self._valid_imdb(imdb)
		tmdb_stream_id = 'tmdb:%s' % tmdb_id if tmdb_id else ''
		if not imdb and not tmdb_stream_id:
			return self._return()

		# Translate media_type to upstream content_type ('movie' or 'tv')
		content_type = 'movie' if media_type == 'movie' else 'tv'
		season = info.get('season') if media_type == 'episode' else None
		episode = info.get('episode') if media_type == 'episode' else None

		# Per-provider id. Sootio takes either form for either content type; HDHub takes
		# `tmdb:` for movies only. An empty id means that provider has nothing to ask with.
		sootio_stream_id = imdb or tmdb_stream_id
		hdhub_stream_id = imdb or (tmdb_stream_id if content_type == 'movie' else '')
		# LOCAL PATCH 2026-11-05: the Stremio addons are asked in Cinemeta's numbering (IMDb id : season : episode), not TMDb's
		# -- for anime TMDb often files several cours as one season (MASHLE TMDb S1E13 = Cinemeta 2:1). Anime only (a Fribb
		# row), one query per provider; the pair also joins episode_candidates so the episode and name filters keep its rows.
		pairs = [(season, episode)]
		if season is not None and tmdb_id and imdb:
			# the lookup lives in modules/episode_card.stremio_pair, shared with scrapers/external.py
			try:
				from modules.episode_card import stremio_pair
				mapped, how = stremio_pair(tmdb_id, season, episode, imdb)
				if mapped and mapped != (int(season), int(episode)):
					pairs = [mapped]
					info = dict(info, episode_candidates=list(info.get('episode_candidates') or []) + [mapped])
					from modules.kodi_utils import logger
					logger('http_streams numbering', 'TMDb S%sE%s -> %s:%d:%d (%s)' % (season, episode, imdb, mapped[0], mapped[1], how))
			except Exception: pass

		scrape_ran = False
		failed = False   # LOCAL PATCH 2026-10-15: any provider failed -> results are shown but not cached
		try:
			from scrapers import _http_providers_core as core
			collected = []

			# Providers are Stremio-shaped JSON endpoints; _scrape_json_provider appends
			# /stream/{movie,series}/{imdb}[:s:e].json to whichever base it is handed.
			run_hdhub = get_setting('deadlight.http_streams.hdhub', 'false') == 'true'
			run_sootio = get_setting('deadlight.http_streams.sootio', 'false') == 'true'

			tasks = []
			if run_hdhub and hdhub_stream_id:
				# Generic JSON aggregator at hdhub.thevolecitor.qzz.io
				HDHUB_URL = "https://hdhub.thevolecitor.qzz.io/eyJ0b3Jib3giOiJ1bnNldCIsInF1YWxpdGllcyI6IjIxNjBwLDEwODBwLDcyMHAiLCJzb3J0IjoiZGVzYyJ9"
				for i, (s, e) in enumerate(pairs):
					tasks.append(('HDHub' if not i else 'HDHub S%sE%s' % (s, e), lambda s=s, e=e: core._scrape_json_provider(
						HDHUB_URL, 'stream', 'HDHub',
						hdhub_stream_id, content_type, s, e,
						title_query=title, year_query=year)))

			# LOCAL PATCH 2026-08-29: Sootio (sooti/sootio-stremio-addon) configured for httpstreaming; Stremio-shaped,
			# so HDHub's helper reads it. It resolves the HubCloud interstitial SERVER-side (/resolve/httpstreaming/...
			# 302s to real storage), which the direct path cannot. Self-hosted with its config in the URL path, so the
			# base is a setting (as aiostreams.manifest_url is).
			if run_sootio:
				sootio_url = (get_setting('deadlight.http_streams.sootio_url', '') or '').strip()
				# The configure page hands out .../manifest.json; the helper wants the base.
				if sootio_url.endswith('/manifest.json'): sootio_url = sootio_url[:-len('/manifest.json')]
				sootio_url = sootio_url.rstrip('/')
				# Enabled but unconfigured is a no-op, not a request to a bad base.
				if sootio_url.startswith('http') and sootio_stream_id:
					# LOCAL PATCH 2026-09-26: any Stremio stream addon's manifest works here (pengu.uk, a Sootio
					# instance, ...), so results are labelled 'Stremio'. Setting ids keep the old sootio name.
					for i, (s, e) in enumerate(pairs):
						tasks.append(('Stremio' if not i else 'Stremio S%sE%s' % (s, e), lambda s=s, e=e: core._scrape_json_provider(
							sootio_url, 'stream', 'Stremio',
							sootio_stream_id, content_type, s, e,
							title_query=title, year_query=year)))

			if not tasks:
				return self._return()

			# One worker per provider, capped at 3; fall back to sequential on RuntimeError
			# for embedded-box thread limits.
			# LOCAL PATCH 2026-11-05: a provider has failed only when none of its queries answered with rows (a timeout on
			# the pair it does not index must not keep the other pair's rows out of the cache)
			answered, errored = set(), set()
			def _take(label, res):
				provider = label.split()[0]
				if res is None: errored.add(provider)
				elif res:
					answered.add(provider)
					collected.extend(res)
			try:
				with ThreadPoolExecutor(max_workers=min(3, len(tasks))) as ex:
					futures = [(label, ex.submit(self._run_task, label, fn)) for label, fn in tasks]
					for label, fut in futures:
						try: _take(label, fut.result(timeout=self.timeout))
						except Exception: _take(label, None)
			except RuntimeError:
				for label, fn in tasks:
					try: _take(label, self._run_task(label, fn))
					except Exception: _take(label, None)
			failed = bool(errored - answered)

			# Convert upstream stream dicts → DeadLight source dicts
			# LOCAL PATCH 2026-11-08: with the episode title, as aiostreams / easynews do (Red Light 3.0.1). For an episode,
			# not the four list words that are ordinary title words -- release names may carry an episode title TMDb lacks
			# ('INSIDE THE GARBAGE BAG'). These upstreams are asked for one exact episode (_drop_other_episodes); the
			# unmistakable markers (sample, featurette, trailer, ...) still apply.
			extras = source_utils.extras(title, info.get('ep_name') if media_type == 'episode' else None)
			if media_type == 'episode': extras = tuple(w for w in extras if w not in ('inside', 'extra', 'extras', 'feature'))
			self._unplayable = {}
			self.sources = [s for s in (self._make_item(item, extras) for item in collected) if s]
			# LOCAL PATCH 2026-11-08: the rows _make_item drops as unplayable, logged like every other filter here.
			if self._unplayable:
				from modules.kodi_utils import logger
				logger('http_streams unplayable', '%s: dropped %d of %d (%s)' % (title, sum(len(v) for v in self._unplayable.values()), len(collected),
					'; '.join('%d %s: %s' % (len(v), why, ' | '.join(sorted(set(v))[:2])) for why, v in self._unplayable.items())))
			self.sources = self._drop_expired_presigns(self.sources, collected)
			# Dedup by URL hash
			seen = set()
			deduped = []
			for s in self.sources:
				h = s.get('hash') or ''
				if h and h in seen: continue
				if h: seen.add(h)
				deduped.append(s)
			deduped = self._inherit_prerelease(deduped)
			deduped = self._drop_other_episodes(deduped, info)
			self.sources = self._filter_dead_urls(self._filter_pixeldrain_blocked(deduped))
			scrape_ran = True
		except Exception as e:
			from modules.kodi_utils import logger
			logger('http_streams scraper Exception', str(e))

		# Cache result. HDHub's CDN URLs carry ~1-hour ?token= params (404 once expired), so 30 min on
		# success, 1 hour on empty. Not info['expiry_times']: its 24h default outlasts the tokens.
		if scrape_ran and tmdb_id and not failed:
			try:
				from caches.external_cache import external_cache
				expiry_hours = 0.5 if self.sources else 1
				external_cache.set('http_streams', media_type, tmdb_id, title, year, season_key, episode_key, self.sources, expiry_hours)
			except Exception: pass

		self.sources = self._drop_other_titles(self.sources, info)
		return self._return()

	# LOCAL PATCH 2026-09-22: the flavours of 'no imdb' a truthiness check misses ('tt0000000', 'empty_setting', ...).
	# Same set as Red Light's _INVALID_IMDB.
	_INVALID_IMDB = ('', 'none', 'null', '0', 'tt0000000', 'tt0', 'empty_setting')

	@classmethod
	def _valid_imdb(cls, imdb):
		"""The id in tt-form, or '' when TMDb gave us nothing usable."""
		imdb = str(imdb or '').strip()
		if not imdb or imdb.lower() in cls._INVALID_IMDB: return ''
		if not imdb.startswith('tt'): imdb = 'tt' + imdb
		return '' if imdb.lower() in cls._INVALID_IMDB else imdb

	@staticmethod
	def _drop_expired_presigns(sources, raw_items):
		"""Drop pre-signed URLs past their expiry; mark the rest as needing no probe.

		Reference clock is the aggregator's Date header, carried on the raw items by
		_scrape_json_provider, not the local one -- see source_utils.presign_reference.
		"""
		server_date = next((i.get('server_date') for i in (raw_items or []) if i.get('server_date')), None)
		return source_utils.drop_expired_presigns(sources, server_date)

	# LOCAL PATCH 2026-09-28: drop rows that NAME ANOTHER EPISODE -- HDHub's aggregator matches the episode as a text
	# PREFIX (S20E01 also returns E10-E19). Conservative: a row goes only when its name carries an explicit SxxEyy / NxNN
	# that is neither this episode nor an anime numbering candidate. A name stating no episode contradicts nothing.
	_EPISODE_TAG = re.compile(r'(?i)(?<![a-z0-9])(?:s(\d{1,2})[ ._-]?e(\d{1,4})|(\d{1,2})x(\d{2,4}))(?![0-9])')
	_SEASON_WORD = re.compile(r'(?i)(?<![a-z0-9])season[ ._-]?(\d{1,2})(?![0-9])')

	@classmethod
	def _season_word_names(cls, name):
		"""LOCAL PATCH 2026-11-10: [name] plus, when the name spells out a season its SxxEyy tag disagrees with, the name with
		that tag rewritten to the stated season and the season word taken out ('Dorohedoro.Season2.S01E01' -> also
		'Dorohedoro.S02E01'): check_title reads everything before the episode tag as the title."""
		names = [name]
		for n in set(int(m.group(1)) for m in cls._SEASON_WORD.finditer(name)):
			alt = re.sub(r'(?i)(?<![a-z0-9])s(\d{1,2})([ ._-]?e\d{1,4})(?![0-9])',
				lambda m: m.group(0) if int(m.group(1)) == n else 'S%02d%s' % (n, m.group(2)), name)
			if alt != name: names.append(re.sub(r'\s{2,}|\.{2,}', lambda m: m.group(0)[0], cls._SEASON_WORD.sub('', alt)).strip(' ._-'))
		return names

	# LOCAL PATCH 2026-11-04 (release judge, phase 4b): stays here, not in modules/release_judge -- it runs on EVERY show, and
	# the card and cour data the judge needs are built in the external scrape only. For anime it reads the card's numbers via
	# info['episode_candidates'].
	@classmethod
	def _drop_other_episodes(cls, sources, info):
		if info.get('media_type') != 'episode': return sources
		try: season, episode = int(info.get('season')), int(info.get('episode'))
		except (TypeError, ValueError): return sources
		wanted = [(season, episode)]
		for pair in (info.get('episode_candidates') or []):
			try: wanted.append((int(pair[0]), int(pair[1])))
			except (TypeError, ValueError, IndexError): pass
		kept, dropped = [], []
		for s in sources:
			name = s.get('name') or ''
			# LOCAL PATCH 2026-11-10: a name that also spells out the season ('Dorohedoro.Season2.S01E01...', HDHub) numbers
			# the episode within that season; its tag is read both ways (_season_word_names). Log 2026-11-09: S02E01 dropped 8 of 8.
			tags = [(int(m.group(1) or m.group(3)), int(m.group(2) or m.group(4)))
				for n in cls._season_word_names(name) for m in cls._EPISODE_TAG.finditer(n)]
			if not tags or any(t in wanted for t in tags): kept.append(s)
			else: dropped.append(name)
		if dropped:
			from modules.kodi_utils import logger
			logger('http_streams episode', 'S%02dE%02d: dropped %d of %d naming another episode (%s)'
				% (season, episode, len(dropped), len(sources), ', '.join(sorted(set(n[:40] for n in dropped))[:4])))
		return kept

	# LOCAL PATCH 2026-10-15: 'Filter Results by Name' (check_title) -- the aggregators answer by id but not always with
	# that title. Off by default: a regional release named differently from TMDb's would go too. Applied when results are
	# RETURNED, not before the cache write, so the cache keeps the full set and the setting takes effect at once.
	# LOCAL PATCH 2026-10-16: with the name filter OFF a film still loses rows stating another year
	# (source_utils.year_mismatch) -- a regional name cannot trip it, a different film can. Episodes keep only the episode check.
	@staticmethod
	def _drop_other_titles(sources, info):
		if not sources: return sources
		if not filter_by_name('http_streams'):
			if info.get('media_type') == 'episode': return sources
			year = info.get('year', '')
			kept = [s for s in sources if not source_utils.year_mismatch(s.get('name') or '', year)]
			if len(kept) < len(sources):
				from modules.kodi_utils import logger
				logger('http_streams year', '%s (%s): dropped %d of %d stating another year (%s)' % (info.get('title') or '', year,
					len(sources) - len(kept), len(sources), ', '.join(sorted(set((s.get('name') or '')[:40] for s in sources if s not in kept))[:4])))
			return kept
		title, year = info.get('title') or '', info.get('year', '')
		season = episode = None
		if info.get('media_type') == 'episode':
			try: season, episode = int(info.get('season')), int(info.get('episode'))
			except (TypeError, ValueError): season, episode = info.get('season'), info.get('episode')
		aliases = source_utils.get_aliases_titles(info.get('aliases', []))
		# LOCAL PATCH 2026-11-05: an anime row named by another numbering of this episode passes, as in _drop_other_episodes
		pairs = [(season, episode)]
		for pair in (info.get('episode_candidates') or []):
			try:
				pair = (int(pair[0]), int(pair[1]))
				if 0 < pair[0] < 100 and pair not in pairs: pairs.append(pair)   # real seasons only, not the ABSOLUTE/ANY markers
			except (TypeError, ValueError, IndexError): pass
		def _ok(name):
			# LOCAL PATCH 2026-11-10: and the name read with its spelled-out season ('Season2.S01E01' as S02E01), see _drop_other_episodes
			return any(source_utils.check_title(title, n, aliases, year, s, e, air_date=info.get('premiered'), ep_title=info.get('ep_name'))
				for n in source._season_word_names(name) for s, e in pairs)
		kept = [s for s in sources if _ok(s.get('name') or '')]
		if len(kept) < len(sources):
			from modules.kodi_utils import logger
			logger('http_streams title', '%s: dropped %d of %d naming another title (%s)' % (title, len(sources) - len(kept),
				len(sources), ', '.join(sorted(set((s.get('name') or '')[:40] for s in sources if s not in kept))[:4])))
		return kept

	# LOCAL PATCH 2026-11-02: a cam rip re-listed WITHOUT its tag takes the tag of its tagged copy -- PenguPlay lists one
	# upload once per indexer, and MoviesDrives rebuilds the name from tags and loses the source. Same file = same
	# behaviorHints.videoSize to the byte. Without bytes on both sides the 2-decimal GB size is used, and then only for a
	# row whose name states no source: equal GB alone is too weak.
	_PRERELEASE = ('CAM', 'SCR', 'TELE')
	_SOURCE_TAG = re.compile(r'(?i)(?<![a-z0-9])(?:web[ ._-]?(?:dl|rip)?|blu[ ._-]?ray|bdrip|brrip|remux|hdrip|dvdrip|hdtv|amzn|nf|dsnp|hmax|atvp)(?![a-z0-9])')

	@staticmethod
	def _byte_size(value):
		try: return int(value or 0)
		except (TypeError, ValueError): return 0

	@classmethod
	def _inherit_prerelease(cls, sources):
		if not sources: return sources
		by_bytes, by_gb = {}, {}
		for s in sources:
			if s.get('quality') not in cls._PRERELEASE: continue
			if s.get('video_size'): by_bytes.setdefault(s['video_size'], s['quality'])
			if s.get('size'): by_gb.setdefault(s['size'], s['quality'])
		if not by_bytes and not by_gb: return sources
		changed = []
		for s in sources:
			if s.get('quality') in cls._PRERELEASE: continue
			quality = by_bytes.get(s.get('video_size')) if s.get('video_size') else None
			if not quality and s.get('size') and not cls._SOURCE_TAG.search(s.get('name') or ''):
				quality = by_gb.get(s['size']) if not (s.get('video_size') and by_bytes) else None
			if quality:
				changed.append('%s (%s)' % ((s.get('name') or '')[:40], s.get('size_label') or ''))
				s['quality'] = quality
		if changed:
			from modules.kodi_utils import logger
			logger('http_streams prerelease', '%d untagged copy/copies of a cam / TS release relabelled: %s' % (len(changed), ', '.join(changed[:4])))
		return sources

	_PIXELDRAIN_ID = re.compile(r'pixeldrain\.(?:dev|com)/(?:api/file|u)/([A-Za-z0-9]+)', re.I)

	@staticmethod
	def _filter_pixeldrain_blocked(sources):
		"""LOCAL PATCH 2026-10-11: drop PixelDrain links PixelDrain itself says will not download. Its /api/file/<id>/info
		reports 'availability' (e.g. 'file_rate_limited_captcha_required': too much hotlink bandwidth, a browser captcha
		is wanted) and 'can_download'; such a link answers the player 403 every time. Not the HEAD probe, whose 403s
		PixelDrain also sends under mere concurrency: this is the file's own state, one small request per link, in parallel,
		4 s at most. Unreadable info keeps the link. Only with `http_streams.validate_urls` on (no extra requests otherwise)."""
		if get_setting('deadlight.http_streams.validate_urls', 'false') != 'true': return sources
		ids = {}
		for src in sources or []:
			m = source._PIXELDRAIN_ID.search(src.get('url_dl') or src.get('url') or '')
			if m: ids.setdefault(m.group(1), []).append(src)
		if not ids: return sources
		def _blocked(pd_id):
			try:
				info = _session.get('https://pixeldrain.dev/api/file/%s/info' % pd_id, timeout=4).json()
				if not isinstance(info, dict) or not info.get('success'): return None
				if info.get('availability') or info.get('can_download') is False: return info.get('availability') or 'can_download false'
			except Exception: return None
			return None
		with ThreadPoolExecutor(max_workers=min(4, len(ids))) as pool:
			verdicts = dict(zip(ids, pool.map(_blocked, list(ids))))
		blocked = dict((k, v) for k, v in verdicts.items() if v)
		if not blocked: return sources
		drop = set(id(src) for k in blocked for src in ids[k])
		try:
			from modules.kodi_utils import logger
			logger('http_streams pixeldrain', 'dropped %d link(s) PixelDrain will not serve: %s' % (len(drop),
				', '.join('%s (%s)' % (k, v) for k, v in blocked.items())))
		except Exception: pass
		return [src for src in sources if id(src) not in drop]

	@staticmethod
	def _filter_dead_urls(sources):
		# HEAD-check each URL in parallel; drop ones that 4xx/5xx/timeout/refuse
		# or return a non-video Content-Type (catches expired/CDN-error pages).
		# Gated on `http_streams.validate_urls` (default off) because validation
		# adds up to `validate_timeout` seconds of latency per scrape.
		if get_setting('deadlight.http_streams.validate_urls', 'false') != 'true':
			return sources
		if not sources:
			return sources
		try:
			timeout = max(2, int(get_setting('deadlight.http_streams.validate_timeout', '5') or '5'))
		except Exception:
			timeout = 5

		ok_status = (200, 206)
		ok_ctype_prefixes = (
			'video/',
			'application/octet-stream',
			'application/vnd.apple.mpegurl',
			'application/x-mpegurl',
			'application/dash+xml',
		)

		def _response_ok(r):
			if r is None:
				return False
			if getattr(r, 'status_code', 999) not in ok_status:
				return False
			try:
				ctype = (r.headers.get('Content-Type') or '').lower().split(';', 1)[0].strip()
			except Exception:
				return False
			if not ctype:
				return False
			return any(ctype.startswith(p) for p in ok_ctype_prefixes)

		def is_alive(source):
			# LOCAL PATCH 2026-08-29: already settled by the pre-signed expiry gate (inside
			# its signed window = alive), so a probe can only cost time or invent a failure.
			if source.get('_presign_ok'):
				return source
			# http_streams URLs may have |Header=... suffix appended for Kodi's
			# player; strip it before the HEAD probe so requests doesn't choke.
			url = (source.get('url_dl') or source.get('url') or '').split('|', 1)[0]
			if not url:
				return None
			# LOCAL PATCH 2026-08-29: send NO explicit User-Agent -- not an omission. Some hosts
			# (hcdn.hakunaymatata.com) serve requests' default UA and answer 428 to a browser UA.
			try:
				r = _session.head(url, timeout=timeout, allow_redirects=True)
				if _response_ok(r):
					return source
				# LOCAL PATCH 2026-08-29: retry once on 403 -- PixelDrain rate-limits under concurrency
				# with 403s for links that serve fine a moment later.
				if getattr(r, 'status_code', 0) == 403:
					time.sleep(1.0)
					r = _session.head(url, timeout=timeout, allow_redirects=True)
					if _response_ok(r):
						return source
				# Rate-limited on the HEAD: keep it, and do not spend a GET making it worse.
				if getattr(r, 'status_code', 0) == 429:
					return source
				r = _session.get(url, timeout=timeout, headers={'Range': 'bytes=0-0'}, stream=True)
				if _response_ok(r):
					return source
				if getattr(r, 'status_code', 0) == 403:
					time.sleep(1.0)
					r = _session.get(url, timeout=timeout, headers={'Range': 'bytes=0-0'}, stream=True)
					if _response_ok(r):
						return source
				# LOCAL PATCH 2026-08-29: 429 means US, not the link -- keep the source. Sootio rate-limits
				# /resolve/ (each probe makes its server resolve HubCloud); dropping on 429 would lose more
				# good sources the busier the scrape.
				if getattr(r, 'status_code', 0) == 429:
					return source
			except Exception:
				return None
			return None

		# Cap at 6. DO NOT RAISE: past ~10 workers the load causes timeouts that silently discard
		# WORKING sources (16 workers dropped 2 of 16 good rows), and 6 stays modest for CoreELEC's
		# pid limit. The RuntimeError fallback below degrades to sequential.
		max_workers = max(1, min(len(sources), 6))
		try:
			with ThreadPoolExecutor(max_workers=max_workers) as ex:
				checked = list(ex.map(is_alive, sources))
		except RuntimeError as e:
			from modules.kodi_utils import logger
			logger('http_streams thread pool failed', str(e))
			checked = [is_alive(s) for s in sources]
		return [s for s in checked if s is not None]

	@staticmethod
	def _run_task(label, fn):
		from modules.kodi_utils import logger
		try:
			out = fn() or []
			logger('http_streams %s' % label, 'returned %d streams' % len(out))
			return out
		except Exception as e:
			logger('http_streams %s error' % label, str(e))
			return None   # LOCAL PATCH 2026-10-15: a failure, told apart from an empty answer (see results)

	# LOCAL PATCH 2026-11-08: a row dropped as unplayable, kept by reason for results()' log line
	def _unplayable_row(self, why, item):
		try: self._unplayable.setdefault(why, []).append(' '.join(str(item.get('title') or item.get('name') or '?').split())[:60])   # one log line
		except AttributeError: pass   # _make_item called outside results()
		return None

	# LOCAL PATCH 2026-11-08: one reading of an upstream (Stremio-shaped) row, so its quirks are handled in one place. HDHub's
	# label 'HDHub | 4K 1080p' and info line 'pixeldrain | 4KHDHub' name the SITE, not the file ('4K' there is not the
	# resolution). Returns None for a row with no usable link; 'unplayable' names what kind of non-video row it is.
	_RELEASE_HINT = re.compile(r'\b(19|20)\d{2}\b|\b(?:2160|1080|720|480)p\b|\bS\d{1,3}[.\s-]?E\d{1,4}\b', re.IGNORECASE)
	_RESOLUTION = {'4k': '4K', '2160p': '4K', '1080p': '1080p', '720p': '720p', '480p': 'SD', 'sd': 'SD'}

	@classmethod
	def _normalize(cls, item):
		url = (item.get('url') or '').strip()
		if not url: return None
		url_part = url.split('|', 1)[0]
		if not cls._is_valid_http_url(url_part): return None
		title, name, info = (item.get('title') or '').strip(), (item.get('name') or '').strip(), (item.get('info') or '').strip()
		texts = info + ' ' + name + ' ' + title
		unplayable = None
		# HDHub's '[10Gbps Download Only]' HubCloud rows and a hubcloud /drive/ page are link generators (HTML), not media; its HLS
		# ladder is a transcode (4K-labelled at 8 Mbps); a .zip is a season archive Kodi cannot play.
		if '10gbps' in texts.lower(): unplayable = '10Gbps download page'
		elif _HUBCLOUD_PAGE.search(url_part): unplayable = 'HubCloud drive page'
		elif source_utils.is_transcode_url(url_part): unplayable = 'HLS transcode'
		elif _ZIP.search(texts + ' ' + url_part): unplayable = 'zip archive'
		# The release name: a real filename first; else the info line when it reads as a release (a year, a resolution or an
		# SxxEyy -- 4KHDHub cuts long names before their resolution) and is longer; else the longer of title / name.
		if any(title.lower().endswith(ext) for ext in ('.mkv', '.mp4', '.avi', '.mov', '.ts', '.webm')):
			parse_source = title
		elif cls._RELEASE_HINT.search(info) and len(info) > len(title):
			cleaned = info
			# info is '[host] [size] NAME' then a second line 'host | site': the first line alone when it is the release
			first = info.split('\n', 1)[0]
			if first != info and cls._RELEASE_HINT.search(first): cleaned = first
			while True:   # leading [FSL] / [FSLV2] / [PIXELDRAIN] / [PixelDrain] host tags (a group tag like [SubsPlease] stays)
				m = re.match(r'\s*\[([A-Z][A-Z0-9_-]+)\]\s*', cleaned) or re.match(r'\s*\[pixeldrain\]\s*', cleaned, re.IGNORECASE)
				if not m: break
				cleaned = cleaned[m.end():]
			cleaned = re.sub(r'\[?\s*\U0001f4be\s*[\d.,]+\s*(?:GB|GiB|MB|MiB|TB|TiB)\s*\]?', '', cleaned, flags=re.IGNORECASE)
			cleaned = re.sub(r'\[\s*[\d.,]+\s*(?:GB|GiB|MB|MiB|TB|TiB)\s*\]', '', cleaned, flags=re.IGNORECASE)
			parse_source = re.sub(r'\s+', ' ', cleaned).strip(' |\t\n')
		elif len(title) >= len(name): parse_source = title or name
		else: parse_source = name
		# LOCAL PATCH 2026-11-09: the file's FULL name when its link states it. 4KHDHub cuts the name it lists at 100
		# characters (the tail with codec, audio and group is lost on a long episode title), but an FSL link names the whole
		# file (response-content-disposition). Taken only when it extends the listed name. The merge key stays the LISTED
		# name, the same on every host, so an FSL copy (full name) and its PixelDrain twin (cut, no name in the link) merge.
		release_key = re.sub(r'[^a-z0-9]', '', parse_source.lower())
		full = cls._link_filename(url_part)
		if full and len(full) > len(parse_source) and release_key and re.sub(r'[^a-z0-9]', '', full.lower()).startswith(release_key):
			parse_source = full
		upstream_q = (item.get('quality') or '').strip()
		mirror = _MIRROR.search(texts)
		return {'url': url, 'url_part': url_part, 'unplayable': unplayable, 'title': title, 'name': name, 'info': info,
				'parse_source': parse_source, 'release': _clean_display(parse_source),
				# the site's name ('4KHDHub', '-4kHdHub.Com') is not a resolution
				'parse_text': _SITE_4K.sub(' ', ((parse_source + ' ' + info).strip() if info else parse_source)),
				'resolution': cls._RESOLUTION.get(upstream_q.lower(), upstream_q if upstream_q in ('4K', '1080p', '720p', 'SD') else ''),
				'mirror': mirror.group(1) if mirror else '', 'release_key': release_key}

	_CD_FILENAME = re.compile(r'filename\*?=(?:UTF-8\'\')?"?([^";&]+)', re.I)
	_LINK_VIDEO = re.compile(r'\.(?:mkv|mp4|avi|m4v|ts|webm|mov)$', re.I)

	@classmethod
	def _link_filename(cls, url_part):
		"""LOCAL PATCH 2026-11-09: the file name a direct link states -- its content-disposition query (FSL's signed R2
		links) or a path ending in a video file. '' when it names none (PixelDrain's /api/file/<id>)."""
		try:
			from urllib.parse import parse_qs, unquote
			p = urlparse(url_part)
			cd = (parse_qs(p.query).get('response-content-disposition') or [''])[0]
			m = cls._CD_FILENAME.search(unquote(cd)) if cd else None
			if m and cls._LINK_VIDEO.search(m.group(1).strip()): return m.group(1).strip()
			last = unquote(p.path.rsplit('/', 1)[-1])
			if cls._LINK_VIDEO.search(last): return last
		except Exception: pass
		return ''

	def _make_item(self, item, extras):
		"""Convert upstream stream dict to DeadLight source dict.
		Upstream shape (from _process_resolved_results / _scrape_json_provider):
		    {'name': str (host | size, e.g. "HubCloud | 2.1 GB"),
		     'url': str (with optional |Header=... suffix),
		     'quality': str ('4K'/'1080p'/'720p'/'SD'),
		     'title': str (full filename, e.g. "Movie.2024.1080p.BluRay.x265.HEVC.mkv"),
		     'size': str ('2.1 GB'),
		     'info': str (provider | branch info)}
		"""
		# LOCAL PATCH 2026-11-08: the upstream row is read once, by _normalize (what the row IS: its link, whether it can play,
		# its real release name, the resolution and host it states); what follows is DeadLight's own reading of that.
		try:
			row = self._normalize(item)
			if row is None: return None
			if row['unplayable']: return self._unplayable_row(row['unplayable'], item)
			url, url_part, display_source, parse_source = row['url'], row['url_part'], row['release'], row['parse_source']
			if not display_source: return None
			if any(x in display_source.lower() for x in extras): return None
			# De-dup "HDHub | HDHub ..." in the display when upstream attached the label twice.
			display_name = source_utils.clean_display_name(re.sub(r'\bHDHub\s*\|?\s*HDHub\b', 'HDHub', display_source, flags=re.IGNORECASE))
			size_gb, size_str = self._extract_size(item.get('size'), item.get('info'), row['title'], row['name'])
			# Quality + extraInfo from as much text as there is (the info often carries the codec / HDR / audio tags). An upstream
			# resolution only stands in when the parser finds none (SD).
			fl_quality, details = source_utils.get_file_info(name_info=source_utils.release_info_format(row['parse_text']))
			quality = row['resolution'] if fl_quality == 'SD' and row['resolution'] and row['resolution'] != 'SD' else (fl_quality or row['resolution'] or 'SD')
			langs = self._extract_languages(parse_source, row['info'], row['title'], row['name'])
			extra_info = ' | '.join(x for x in (details, ' | '.join(langs) if langs else '') if x)
			try:
				from scrapers import _http_providers_core as core
				hoster = core._identify_host_from_url(url_part) or ''
			except Exception:
				hoster = ''
			# LOCAL PATCH 2026-10-24: a mirror the URL does not name (an opaque /direct/<token> address) is named by the row's own tag
			netloc = urlparse(url_part).netloc.lower().replace('www.', '')
			if hoster in ('', 'Direct', netloc.split('.')[0].title()) and row['mirror']: hoster = row['mirror']
			url_hash = hashlib.sha1(url_part.encode('utf-8')).hexdigest()[:24]
			return {
				'name': display_source,                 # full filename when available
				'display_name': display_name,
				'quality': quality,
				'size': size_gb,
				'size_label': size_str if size_str else ('%.2f GB' % size_gb if size_gb > 0 else '0.00 GB'),
				'extraInfo': extra_info,
				'url_dl': url,
				'id': url_hash,
				'debrid': self.scrape_provider,
				'scrape_provider': self.scrape_provider,
				'direct': True,
				'direct_debrid_link': True,
				'local': False,
				'source': self.scrape_provider,
				'hash': url_hash,
				'hoster': hoster,                       # PixelDrain / FSL-V2 / etc.; consumed by windows/sources.py
				'release_key': row['release_key'],      # LOCAL PATCH 2026-11-09: the listed name, for _merge_host_copies
				'video_size': self._byte_size(item.get('video_size')),   # LOCAL PATCH 2026-11-02: see _inherit_prerelease
			}
		except Exception:
			from modules.kodi_utils import log_row_error
			return log_row_error('http_streams._make_item')   # LOCAL PATCH 2026-11-08: logged once, the row skipped

	# Common audio-language tokens worth detecting. Order matters — first match
	# wins per language to avoid double-counting. Each entry: (display_label,
	# list-of-lowercase-patterns-to-match-as-whole-words-or-bracketed).
	_LANG_PATTERNS = (
		('HINDI',     ('hindi', 'hin')),
		('ENGLISH',   ('english', 'eng')),
		('TAMIL',     ('tamil', 'tam')),
		('TELUGU',    ('telugu', 'tel')),
		('MALAYALAM', ('malayalam', 'mal')),
		('KANNADA',   ('kannada', 'kan')),
		('BENGALI',   ('bengali', 'ben')),
		('PUNJABI',   ('punjabi', 'pun')),
		('MARATHI',   ('marathi', 'mar')),
		('GUJARATI',  ('gujarati', 'guj')),
		('URDU',      ('urdu', 'urd')),
		('SPANISH',   ('spanish', 'spa', 'esp')),
		('FRENCH',    ('french', 'fre', 'fra')),
		('GERMAN',    ('german', 'ger', 'deu')),
		('ITALIAN',   ('italian', 'ita')),
		('RUSSIAN',   ('russian', 'rus')),
		('JAPANESE',  ('japanese', 'jap', 'jpn')),
		('KOREAN',    ('korean', 'kor')),
		('CHINESE',   ('chinese', 'chi', 'zho')),
		('ARABIC',    ('arabic', 'ara')),
		('TURKISH',   ('turkish', 'tur')),
		('DUTCH',     ('dutch', 'dut', 'nld')),
		('POLISH',    ('polish', 'pol')),
		('PORTUGUESE',('portuguese', 'por')),
	)

	@classmethod
	def _extract_languages(cls, *candidates):
		"""Scan candidate strings for audio-language tokens. Returns a
		deduplicated ordered list of UPPERCASE language labels found.
		Detection uses word-boundary regex against the lowercased input so
		that random substrings (e.g. 'china' inside 'machinaut') don't false-match."""
		import re as _re
		hits = []
		seen = set()
		joined = ' '.join((c or '') for c in candidates if c).lower()
		if not joined: return hits
		for label, pats in cls._LANG_PATTERNS:
			for pat in pats:
				# \b doesn't work next to brackets/punctuation in some cases; use a
				# permissive boundary that accepts start/end/non-letter on each side.
				if _re.search(r'(?<![a-z])' + _re.escape(pat) + r'(?![a-z])', joined):
					if label not in seen:
						hits.append(label)
						seen.add(label)
					break
		return hits

	@staticmethod
	def _extract_size(*candidates):
		"""Best-effort size extractor — try each candidate string for a size pattern
		and return (size_gb_float, size_label_str). Returns (0.0, '') if nothing parses.
		Patterns recognized (case-insensitive):
		    "[2.1 GB]"             — HDHub4u branch format with brackets
		    "💾 9.58 GB"           — Stremio behaviorHints (emoji + size)
		    "Size: 2.1 GB"         — generic label
		    "2.1 GB" / "2.1GB"     — bare format
		    "2100 MB" / "1.2 TB"   — unit variants
		"""
		import re as _re
		# Order patterns by specificity (most specific first to avoid false positives).
		patterns = (
			_re.compile(r'\[([\d.,]+)\s*(GB|GiB|MB|MiB|TB|TiB)\]', _re.IGNORECASE),
			_re.compile(r'💾\s*([\d.,]+)\s*(GB|GiB|MB|MiB|TB|TiB)', _re.IGNORECASE),
			_re.compile(r'(?:size|file\s*size)\s*[:\-]\s*([\d.,]+)\s*(GB|GiB|MB|MiB|TB|TiB)', _re.IGNORECASE),
			_re.compile(r'(?<![A-Za-z0-9])([\d.,]+)\s*(GB|GiB|MB|MiB|TB|TiB)(?![A-Za-z0-9])', _re.IGNORECASE),
		)
		for candidate in candidates:
			if not candidate or not isinstance(candidate, str): continue
			text = candidate.strip()
			if not text: continue
			for pat in patterns:
				m = pat.search(text)
				if not m: continue
				try:
					num = source_utils.size_number(m.group(1))   # LOCAL PATCH 2026-10-19: '2,750 MB' is thousands, '2,75 GB' decimal
					unit = m.group(2).upper().rstrip('B').rstrip('I')  # GB/GIB → G, MB/MIB → M
					if unit == 'G': size_gb = num
					elif unit == 'M': size_gb = num / 1024.0
					elif unit == 'T': size_gb = num * 1024.0
					else: continue
					if size_gb <= 0 or size_gb > 500: continue  # sanity: >500GB is bogus (4K remux ceiling)
					return round(size_gb, 2), '%.2f GB' % size_gb
				except Exception: continue
		return 0.0, ''

	_is_valid_http_url = staticmethod(source_utils.is_valid_http_url)   # LOCAL PATCH 2026-10-19: shared copy

	def _return(self):
		self.sources = self._merge_host_copies(self.sources)
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources

	# LOCAL PATCH 2026-10-24: one row per release, the other hosts kept as fallbacks. The same file is listed on up to three
	# hosts (same name, size and quality); dedup alone would let a dead or capped host fail the release. Copies ride on the
	# kept row as 'url_fallbacks', which sources.resolve_sources tries in order (direct_url_alive). PixelDrain goes last:
	# its free downloads have a daily data cap.
	@staticmethod
	def _is_pixeldrain(src):
		return 'pixeldrain' in ('%s %s' % (src.get('hoster') or '', src.get('url_dl') or src.get('url') or '')).lower()

	@classmethod
	def _merge_host_copies(cls, sources):
		if not sources: return sources
		groups, order = {}, []
		for s in sources:
			# LOCAL PATCH 2026-11-09: keyed on the LISTED name (release_key) -- an FSL copy may carry the file's full name and its
			# PixelDrain twin the cut one; rows cached before it existed have only 'name'
			k = (s.get('quality'), s.get('size'), s.get('release_key') or re.sub(r'[^a-z0-9]', '', str(s.get('name') or '').lower())) if s.get('size') else id(s)
			if k not in groups:
				groups[k] = []
				order.append(k)
			groups[k].append(s)
		out = []
		for k in order:
			group = sorted(groups[k], key=cls._is_pixeldrain)   # stable: the providers' own order, PixelDrain last
			keep = group[0]
			fallbacks = [u for u in ((g.get('url_dl') or g.get('url')) for g in group[1:]) if u and u != keep.get('url_dl')]
			if fallbacks: keep['url_fallbacks'] = fallbacks
			out.append(keep)
		return out

	@staticmethod
	def direct_url_alive(url, timeout=4):
		"""LOCAL PATCH 2026-10-24: does a direct link answer with the file? A 1-byte range request: True for 200 / 206 that
		is not an HTML page (PixelDrain's cap and the hosts' error pages are HTML), else False. A 'url|Header=value'
		link sends its Kodi headers."""
		from urllib.parse import parse_qsl
		base, _, extra = (url or '').partition('|')
		headers = dict(parse_qsl(extra)) if extra else {}
		headers.setdefault('User-Agent', 'Mozilla/5.0')
		headers['Range'] = 'bytes=0-0'
		try:
			r = make_session().get(base, headers=headers, timeout=timeout, stream=True, allow_redirects=True)
			ok = r.status_code in (200, 206) and 'text/html' not in (r.headers.get('Content-Type') or '').lower()
			r.close()
			return ok
		except Exception: return False
