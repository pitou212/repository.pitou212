# -*- coding: utf-8 -*-
"""IntroDB API client. Fetches intro/outro/recap segments by IMDb id + season + episode
(TV mode) or IMDb id alone (movie mode — theintrodb.org only).

Two upstream providers walked in priority order (ported from POV 6.06):

  1. api.introdb.app        — richer: intro AND outro start+end (the alert-at-outro-END
                              autoplay timing relies on it). Preferred when it has data.
                              TV-EPISODE-ONLY (400 on movie queries).
  2. api.theintrodb.org/v4  — sparser: outro end is usually null. Fallback for what
                              introdb.app lacks. **Also supports movies** (LOCAL PATCH
                              2026-08-05) — same response shape without season/episode.

Return shape: {segment_type: [(start_sec, end_sec_or_None), ...]}, segment_type in
{'intro', 'outro', 'recap'}. The cache stores the merged result; a MISS only when every
provider returned nothing.
"""
import json
import threading
import time
from modules.kodi_utils import get_property, set_property, logger, make_session
from modules.utils import safe_err   # LOCAL PATCH 2026-10-25 (4.0.5): request errors logged without their url / query keys
# LOCAL PATCH 2026-10-19: DeadLight's lazy session -- its shared SSL context loads the CA bundle once per process; a
# bare requests.get reloads it per connection (~0.9 s CPU each)
_session = make_session()
from caches.settings_cache import get_setting

_INTRODB_APP = 'https://api.introdb.app/segments'
# LOCAL PATCH 2026-10-18: v4, TheIntroDB's current API (v2 / v3 are frozen, deprecated on 18 Jan 2027). Responses are
# keyed by tvdb_id. Which id is sent with which numbering: _lookup_ident.
_INTRODB_ORG = 'https://api.theintrodb.org/v4/media'
_SEGMENT_KEYS = ('intro', 'outro', 'recap')
_CACHE_PROP_PREFIX = 'deadlight.introdb.cache.'
# How far apart two providers may place the same boundary and still count as agreeing: wider than the spread on
# segments that genuinely match (~1 s), far tighter than the gap between a real segment and a wrong one.
_CORROBORATE_SECONDS = 5

# LOCAL PATCH 2026-08-27: provider 3, anime only: api.aniskip.com, keyed on MAL id + the episode number WITHIN that
# MAL entry. The IntroDB providers address anime correctly (TMDb-style numbering) but have coverage gaps, so this is an
# extra source for the gaps, not a replacement -- see the ordering note in fetch_segments.
_ANISKIP = 'https://api.aniskip.com/v2/skip-times/%s/%s'

# OFF by default: Settings > Playback > Skip Segments > 'Also use AniSkip (anime)'.
def _aniskip_enabled():
	try: return get_setting('deadlight.skipsegment.aniskip') == 'true'
	except Exception: return False

# AniSkip skipType -> DeadLight segment type. `mixed-*` is deliberately second choice: an opening running UNDER episode
# content, overlapping the plain one (op 3-93, mixed-op 59-149); preferring it would skip past the episode's start.
_ANISKIP_TYPES = (('intro', ('op', 'mixed-op')),
				('outro', ('ed', 'mixed-ed')),
				('recap', ('recap',)))


def _cache_key(imdb_id, season, episode):
	# LOCAL PATCH 2026-08-05: 'movie' sentinel for movie queries (season+episode both None).
	if season is None and episode is None:
		return '%s%s_movie' % (_CACHE_PROP_PREFIX, imdb_id)
	# LOCAL PATCH 2026-10-03: the AniSkip toggle is part of the key -- the answer depends on it (a MISS cached with it off
	# would hide AniSkip after switching it on).
	return '%s%s_%s_%s%s' % (_CACHE_PROP_PREFIX, imdb_id, season, episode, '_as' if _aniskip_enabled() else '')


# LOCAL PATCH 2026-08-26: per-type minimum durations, mirroring the consumers' guards (player._check_skip_segments,
# player.info_next_ep). Validating HERE lets the fallback work: a present-but-bogus segment (a 5 s "outro") would
# otherwise block the second provider, which is asked only for missing types.
_MIN_SEGMENT_SECONDS = {'intro': 15, 'outro': 15, 'recap': 8}


def _plausible(stype, segs):
	"""True when the segment list looks like real data. Duration-only -- this layer
	has no runtime, so checks relative to total_time stay with the consumers."""
	try:
		if not segs: return False
		start, end = segs[0][0], segs[0][1] if len(segs[0]) > 1 else None
		if start is None or start < 0: return False
		if end is None: return True          # open-ended (theintrodb.org credits) -- can't judge
		if end <= start: return False
		return (end - start) >= _MIN_SEGMENT_SECONDS.get(stype, 15)
	except Exception:
		return False


# LOCAL PATCH 2026-10-26: introdb.app sometimes runs the outro on over a post-credits scene to the end of the file, so
# the autoplay countdown starts over that scene. When theintrodb.org has the same credits (starts within
# _OUTRO_START_TOLERANCE) ending more than _OUTRO_END_GAP earlier, its end is used. The tolerance is looser than
# _CORROBORATE_SECONDS: the two sites' starts can differ by 6 s on the same credits.
_OUTRO_START_TOLERANCE, _OUTRO_END_GAP = 15, 30

def _closed_outro(segs):
	try: return segs[0][0] is not None and len(segs[0]) > 1 and segs[0][1] is not None
	except (IndexError, TypeError): return False

def _outro_end_from_org(merged, fallback):
	a, b = merged.get('outro'), (fallback or {}).get('outro')
	# LOCAL PATCH 2026-11-05: theintrodb.org's credits with no end run to the END OF THE FILE -- an answer, not missing
	# data (its openapi.yaml: 'end optional/null = end of media'). When it has the same credits (start within
	# _OUTRO_START_TOLERANCE), introdb.app's end is dropped.
	if _closed_outro(a) and b and b[0][0] is not None and (len(b[0]) < 2 or b[0][1] is None) \
			and abs(a[0][0] - b[0][0]) <= _OUTRO_START_TOLERANCE:
		merged['outro'] = [(a[0][0], None)] + list(a[1:])
		logger('IntroDB outro end', 'introdb.app %.0f-%.0f, theintrodb.org %.0f-end of file -> open end'
			% (a[0][0], a[0][1], b[0][0]))
		return
	if not _closed_outro(a) or not _closed_outro(b): return
	(a_start, a_end), (b_start, b_end) = a[0][:2], b[0][:2]
	if abs(a_start - b_start) > _OUTRO_START_TOLERANCE or a_end - b_end <= _OUTRO_END_GAP: return
	if not _plausible('outro', [(a_start, b_end)]): return
	merged['outro'] = [(a_start, b_end)] + list(a[1:])
	logger('IntroDB outro end', 'introdb.app %.0f-%.0f, theintrodb.org ends %.0f -> using %.0f' % (a_start, a_end, b_end, b_end))


# LOCAL PATCH 2026-10-28: when the two describe DIFFERENT credits (starts more than _OUTRO_START_TOLERANCE apart), they
# are often timed on different cuts, and only the player knows which one the file is. theintrodb.org's is kept as a
# second entry; player._outro_for_file takes the first that fits inside the file.
def _alternate_outro(merged, fallback):
	a, b = merged.get('outro'), (fallback or {}).get('outro')
	if not a or not b or a is b: return   # `a is b`: the outro came from theintrodb.org in the first place
	if a[0][0] is None or b[0][0] is None or abs(a[0][0] - b[0][0]) <= _OUTRO_START_TOLERANCE: return
	if not _plausible('outro', b): return
	merged['outro'] = list(a[:1]) + [b[0]]
	logger('IntroDB outro alternative', 'introdb.app starts %.0f, theintrodb.org %.0f -> both kept, the player picks the one '
		'that fits the file' % (a[0][0], b[0][0]))


# LOCAL PATCH 2026-11-05: for anime, AniSkip breaks the tie when _alternate_outro kept two outros ('the first that fits'
# is only the asking order when both fit). The outro AniSkip's ED starts near goes first. Asked even with the AniSkip
# setting off: only a vote, its times are not used. One extra request, only when the two sites disagree on anime.
def _aniskip_outro_vote(merged, cour, ask):
	outros = merged.get('outro') or []
	if len(outros) < 2 or not cour: return
	try: mal_id, cour_ep = int(cour.get('mal')), int(cour.get('cour_ep'))
	except (TypeError, ValueError): return
	ed = (ask(_fetch_aniskip, mal_id, cour_ep).get('outro') or [None])[0]
	if not ed: return
	near = [i for i, seg in enumerate(outros) if abs(seg[0] - ed[0]) <= _OUTRO_START_TOLERANCE]
	if len(near) != 1: return
	if near[0]: merged['outro'] = [outros[near[0]]] + [s for i, s in enumerate(outros) if i != near[0]]
	logger('IntroDB outro vote', 'AniSkip ED starts %.0f -> outro %.0f first (of %s)'
		% (ed[0], outros[near[0]][0], ', '.join('%.0f' % s[0] for s in outros)))


# LOCAL PATCH 2026-11-05: two checks on what AniSkip answered, against the IntroDB pair (e.g. a finale that plays the
# opening song over its ending):
#   outro -- when the two IntroDB sites agree with each other (_corroborated) and AniSkip's ed does not, theirs is used.
#   intro -- an intro that overlaps an outro (AniSkip's own ed, or the one the IntroDB pair agrees on) is not an opening.
def _overlaps(a, b):
	a_end, b_end = a[1] if a[1] is not None else float('inf'), b[1] if b[1] is not None else float('inf')
	return a[0] < b_end and b[0] < a_end

def _aniskip_vs_introdb(merged, app_segs, org_segs):
	a, b = app_segs.get('outro'), org_segs.get('outro')
	agreed = None
	if a and b and _closed_outro(a) and b[0][0] is not None and _corroborated(a, b) and _plausible('outro', a):
		agreed = (a[0][0], a[0][1] if len(b[0]) > 1 and b[0][1] is not None else None)   # open end: see _outro_end_from_org
	ed = (merged.get('outro') or [None])[0]
	if agreed and ed and not _corroborated([ed], [agreed]):
		merged['outro'] = [agreed]
		logger('AniSkip outro', 'ed %s, introdb.app and theintrodb.org agree on %s -> using theirs' % (ed, agreed))
	op = (merged.get('intro') or [None])[0]
	if op:
		for outro in [s for s in (ed, agreed) if s]:
			if _overlaps(op, outro):
				del merged['intro']
				logger('AniSkip intro', 'op %s overlaps the outro %s -> not an opening, dropped' % (op, outro))
				break


def _corroborated(a, b):
	"""True when two providers describe the same segment. Used only to decide whether an
	IntroDB segment may fill a type AniSkip omitted -- see the note in fetch_segments.
	An open end (theintrodb.org credits carry start_ms only) is judged on the start alone,
	since there is nothing on the other side to compare."""
	try:
		a0, b0 = a[0], b[0]
		if abs(a0[0] - b0[0]) > _CORROBORATE_SECONDS: return False
		a1 = a0[1] if len(a0) > 1 else None
		b1 = b0[1] if len(b0) > 1 else None
		if a1 is None or b1 is None: return True
		return abs(a1 - b1) <= _CORROBORATE_SECONDS
	except Exception:
		return False

def _fetch_introdb_app(params):
	"""Provider 1 (rich): api.introdb.app. Returns dict in canonical shape or {} on miss/error."""
	try:
		r = _session.get(_INTRODB_APP, params=params, timeout=8)
		if r.status_code == 404: return {}
		# LOCAL PATCH 2026-10-03 (Batch 3): no answer is None, not {} -- see fetch_segments' _ask
		if r.status_code != 200:
			logger('IntroDB.app: non-200', '%s for %s' % (r.status_code, params))
			return None
		data = r.json()
	except Exception as e:
		logger('IntroDB.app: fetch error', safe_err(e))
		return None
	out = {}
	for stype in _SEGMENT_KEYS:
		seg = data.get(stype)
		if not isinstance(seg, dict): continue
		try:
			start = seg.get('start_sec')
			end = seg.get('end_sec')
			if start is None: continue
			start = float(start)
			end = float(end) if end is not None else None
			out[stype] = [(start, end)]
		except: continue
	return out


def _fetch_aniskip(mal_id, episode):
	"""Provider 3 (anime): api.aniskip.com. Canonical shape, or {} on miss/error.

	episodeLength=0 asks AniSkip not to filter by recorded runtime (a real length returns only
	entries submitted against that exact duration).
	"""
	# LOCAL PATCH 2026-08-27: ask for the three PLAIN types only: a mixed-* type never appeared without its plain
	# counterpart, and _ANISKIP_TYPES prefers the plain one anyway.
	# The retry matters: AniSkip RATE LIMITS and answers a burst with HTTP 500, not 429; one retry turns a transient
	# limit into a hit.
	# episodeLength MUST stay 0 -- a real runtime (tried 24 and 1440) returns HTTP 500.
	data = None
	for _attempt in (1, 2):
		try:
			r = _session.get(_ANISKIP % (mal_id, episode),
							params=[('types[]', t) for t in ('op', 'ed', 'recap')]
									+ [('episodeLength', '0')], timeout=8)
			# 404 is how AniSkip says "nothing submitted for this episode" -- a clean
			# miss, and unlike a 500 it will not change on a retry.
			if r.status_code == 404: return {}
			if r.status_code == 200:
				data = r.json()
				break
			if _attempt == 2:
				logger('AniSkip: non-200', '%s for mal=%s ep=%s' % (r.status_code, mal_id, episode))
		except Exception as e:
			if _attempt == 2: logger('AniSkip: fetch error', safe_err(e))
	if data is None: return None   # LOCAL PATCH 2026-10-03 (Batch 3): no answer, not a miss
	found = {}
	for item in (data.get('results') or []):
		try:
			iv = item.get('interval') or {}
			start, end = iv.get('startTime'), iv.get('endTime')
			if start is None: continue
			found[item.get('skipType')] = (float(start), float(end) if end is not None else None)
		except Exception: continue
	out = {}
	for stype, keys in _ANISKIP_TYPES:
		for k in keys:                     # plain type wins; see _ANISKIP_TYPES
			if k in found:
				out[stype] = [found[k]]
				break
	return out


def _fetch_theintrodb_org(params):
	"""Provider 2 (sparse fallback): api.theintrodb.org. Returns dict in canonical
	shape or {} on miss/error. ms -> sec; 'credits' maps to DeadLight's 'outro', whose end
	is typically null (the autoplay timing falls back to outro_start)."""
	try:
		r = _session.get(_INTRODB_ORG, params=params, timeout=6)
		if r.status_code == 404: return {}
		if r.status_code != 200:
			logger('IntroDB.org: non-200', '%s for %s' % (r.status_code, params))
			return None   # LOCAL PATCH 2026-10-03 (Batch 3)
		data = r.json()
	except Exception as e:
		logger('IntroDB.org: fetch error', safe_err(e))
		return None
	out = {}
	# LOCAL PATCH 2026-10-18: a null start_ms on an intro or recap means 'from the start of the file'. A null credits
	# start cannot be placed and is skipped; a null end is open-ended. 'preview' (after the credits) is not used.
	for key, stype, open_start in (('intro', 'intro', True), ('recap', 'recap', True), ('credits', 'outro', False)):
		try:
			seg = (data.get(key) or [None])[0] or {}
			start_ms, end_ms = seg.get('start_ms'), seg.get('end_ms')
			if start_ms is None:
				if not open_start or end_ms is None: continue
				start_ms = 0
			out[stype] = [(float(start_ms) / 1000.0, float(end_ms) / 1000.0 if end_ms is not None else None)]
		except Exception: pass
	return out


# LOCAL PATCH 2026-10-03 (Batch 3): a MISS is remembered for 3 hours, not the Kodi session, so a segment submitted
# later is seen. A bare legacy 'MISS' counts as expired.
_MISS_TTL = 3 * 3600

def _cached_segments(key):
	"""The window-property cache: segments dict, {} for a recorded MISS, None when not cached."""
	cached = get_property(key)
	if not cached: return None
	if cached.startswith('MISS'):
		try: return {} if time.time() - int(cached.split(':', 1)[1]) < _MISS_TTL else None
		except (IndexError, ValueError): return None
	try: return {k: [tuple(s) for s in v] for k, v in json.loads(cached).items()}
	except: return None

# LOCAL PATCH 2026-09-26: prefetch. A synchronous lookup just before play() cost up to ~3 s; Sources.playback_prep
# starts it once it has the meta, alongside the scrape, and the player's fetch_segments finds the cache warm or waits
# on the in-flight one. The cache is a window property, shared across processes (a background next-episode prescrape
# warms it for the playback process); _INFLIGHT only dedupes in-process.
_INFLIGHT = {}   # cache key -> (Event, Thread)

def prefetch_segments(meta):
	try:
		if get_setting('deadlight.skipsegment.enabled') != 'true': return
		imdb_id, tvdb_id, media_type = meta.get('imdb_id'), meta.get('tvdb_id'), meta.get('media_type')
		ident = _lookup_ident(imdb_id, meta.get('tmdb_id'), tvdb_id)[0]
		if not ident: return
		# Same arguments as DeadLightPlayer._init_skip_segments, or the keys will not match.
		if media_type == 'episode':
			season, episode = meta.get('season'), meta.get('episode')
			if season is None or episode is None: return
		elif media_type == 'movie': season, episode = None, None
		else: return
		key = _cache_key(ident, season, episode)
		if key in _INFLIGHT or _cached_segments(key) is not None: return
		done = threading.Event()
		def _run():
			try: fetch_segments(imdb_id, season, episode, meta.get('tmdb_id'), tvdb_id)
			except Exception as e: logger('IntroDB prefetch error', safe_err(e))
			finally: done.set()
		# daemon: a cancelled scrape must not keep the plugin process alive for the timeouts.
		thread = threading.Thread(target=_run, daemon=True)
		_INFLIGHT[key] = (done, thread)
		thread.start()
	except Exception: pass

def _int_id(value):
	try: value = int(value or 0)
	except (TypeError, ValueError): return 0
	return value if value > 0 else 0


def _lookup_ident(imdb_id, tmdb_id, tvdb_id):
	"""LOCAL PATCH 2026-10-18: (cache ident, theintrodb.org id params, ids for a TVDB-numbered retry), or (None, None, None).

	TheIntroDB v4 reads season / episode in the numbering of the id it is given (openapi.yaml). DeadLight's numbers are
	TMDb's, so tmdb_id goes with them; tvdb_id is never sent with TMDb's numbers (Bleach TMDb S2E1 by tvdb_id answers
	for TVDB's S2E1, a 2005 episode). The TVDB-numbered retry (Fribb's pair) goes by imdb_id (some entries are found only
	that way), by tvdb_id when there is no IMDb id. The cache ident stays the IMDb id where there is one, so earlier keys
	still match."""
	imdb_id = str(imdb_id or '')
	imdb_id = imdb_id if imdb_id.startswith('tt') else ''
	tmdb_id, tvdb_id = _int_id(tmdb_id), _int_id(tvdb_id)
	if tmdb_id: ids = {'tmdb_id': str(tmdb_id)}
	elif imdb_id: ids = {'imdb_id': imdb_id}
	else: return None, None, None
	retry = {'imdb_id': imdb_id} if imdb_id else ({'tvdb_id': str(tvdb_id)} if tvdb_id else None)
	return imdb_id or 'tmdb%d' % tmdb_id, ids, retry


def fetch_segments(imdb_id, season, episode, tmdb_id=None, tvdb_id=None):
	"""Returns dict {segment_type: [(start_sec, end_sec_or_None), ...]} or empty dict on miss/error.
	imdb_id like 'tt0944947'. theintrodb.org is asked by tmdb_id (see _lookup_ident); with no IMDb id only it is asked
	(introdb.app takes IMDb ids only).
	  - Episode mode: pass season + episode (both required, both ints).
	  - Movie mode:   pass season=None + episode=None. Only theintrodb.org is
	    queried (introdb.app is TV-only and 400s on movie queries).
	Walks introdb.app first (TV only), then theintrodb.org for missing segment types."""
	ident, org_ids, retry_ids = _lookup_ident(imdb_id, tmdb_id, tvdb_id)
	if not ident: return {}
	imdb_id = imdb_id if str(imdb_id or '').startswith('tt') else None
	# LOCAL PATCH 2026-08-05: allow movie-mode (both season+episode None).
	is_movie = (season is None and episode is None)
	if not is_movie and (season is None or episode is None): return {}
	key = _cache_key(ident, season, episode)
	cached = _cached_segments(key)
	if cached is not None: return cached
	# LOCAL PATCH 2026-09-26: a prefetch for this key is already running in this process -- wait for its answer.
	inflight = _INFLIGHT.get(key)
	if inflight and inflight[1] is not threading.current_thread():
		inflight[0].wait(30)
		cached = _cached_segments(key)
		if cached is not None: return cached
	# LOCAL PATCH 2026-10-03 (Batch 3): every provider call goes through _ask, which notes the ones that did not
	# answer (timeout, 5xx). A lookup with a non-answer is used for this playback but not cached as a MISS.
	failed = []
	def _ask(fetch, *args):
		result = fetch(*args)
		if result is None:
			failed.append(fetch.__name__.replace('_fetch_', ''))
			return {}
		return result
	if is_movie:
		# Movie: only theintrodb.org accepts the {imdb_id} shape.
		merged = _ask(_fetch_theintrodb_org, dict(org_ids))
		for stype in list(merged):   # LOCAL PATCH 2026-08-26
			if not _plausible(stype, merged[stype]):
				logger('IntroDB.org: implausible %s' % stype, '%s -> discarded' % (merged[stype],))
				del merged[stype]
	else:
		params = {'imdb_id': imdb_id, 'season': str(season), 'episode': str(episode)}
		org_params = dict(org_ids, season=str(season), episode=str(episode))
		# LOCAL PATCH 2026-10-18: the Fribb entry, read once -- AniSkip and the TVDB retry below both need it. A miss is
		# not anime (the index holds only anime): regular TV pays one offline dict lookup.
		cour = {}
		if tmdb_id:
			try:
				from caches import fribb_mappings
				cour = fribb_mappings.find_cour_by_tmdb_coords(tmdb_id, season, episode) or {}
			except Exception as e: logger('IntroDB: Fribb lookup error', safe_err(e))
		def _app():
			return _ask(_fetch_introdb_app, params) if imdb_id else {}   # introdb.app takes IMDb ids only
		# LOCAL PATCH 2026-10-18: theintrodb.org stores TVDB's numbering (v4). For anime TMDb's often differs, so a miss
		# under TMDb's pair is asked again under Fribb's TVDB one (TMDb S5E1 = TVDB S6E1).
		def _org():
			found = _ask(_fetch_theintrodb_org, org_params)
			try: tvdb_pair = (int(cour['cour_season']), int(cour['season_ep']))
			except (KeyError, TypeError, ValueError): tvdb_pair = None
			if not found and retry_ids and tvdb_pair and tvdb_pair != (int(season), int(episode)):
				found = _ask(_fetch_theintrodb_org, dict(retry_ids, season=str(tvdb_pair[0]), episode=str(tvdb_pair[1])))
				logger('IntroDB.org', '%s S%sE%s missed; TVDB S%sE%s: %s' % (ident, season, episode, tvdb_pair[0], tvdb_pair[1],
						list(found) if found else 'nothing'))
			return found
		# LOCAL PATCH 2026-08-27: anime goes to AniSkip first (keyed on the numbering anime uses), then the two IntroDB
		# providers for whatever it did not supply. A Fribb hit IS the anime test and hands back the MAL id and cour_ep,
		# the episode number WITHIN that MAL entry (a cour-2 entry counts from 1 again; TMDb's number would be wrong).
		merged, aniskip_answered = {}, False
		if cour and _aniskip_enabled():
			try:
				mal_id, cour_ep = cour.get('mal'), cour.get('cour_ep')
				if mal_id and cour_ep is not None:
					merged = _ask(_fetch_aniskip, int(mal_id), int(cour_ep))
					for stype in list(merged):
						if not _plausible(stype, merged[stype]):
							logger('AniSkip: implausible %s' % stype, '%s -> discarded' % (merged[stype],))
							del merged[stype]
					if merged: logger('AniSkip segments', '%s for mal=%s ep=%s' % (list(merged), mal_id, cour_ep))
				aniskip_answered = bool(merged)
			except Exception as e:
				logger('AniSkip lookup error', safe_err(e))
				merged = {}
		# LOCAL PATCH 2026-08-27, revised 2026-08-29: AniSkip owns every segment type it answered. A type it OMITTED is
		# filled from IntroDB only when BOTH providers report it and agree within _CORROBORATE_SECONDS at each end:
		# submission count does not separate a wrong single-provider intro from a real one; cross-provider agreement does.
		# AniSkip having NOTHING for the episode is not an answer -- the full IntroDB chain runs as usual.
		if aniskip_answered:
			# Only an intro/outro gap is worth two extra requests: recap is absent from nearly every source. It is still
			# filled below whenever something else opened the payloads.
			missing = [s for s in _SEGMENT_KEYS if s not in merged]
			# LOCAL PATCH 2026-11-05: the IntroDB pair is asked whenever AniSkip has an outro too -- _aniskip_vs_introdb
			# needs it to check that outro (and the intro against it). Two requests per anime episode, in the prefetch.
			if [s for s in missing if s != 'recap'] or 'outro' in merged:
				app_segs = _app()
				org_segs = _org()
				_aniskip_vs_introdb(merged, app_segs, org_segs)
				missing = [s for s in _SEGMENT_KEYS if s not in merged]
				for stype in missing:
					a, b = app_segs.get(stype), org_segs.get(stype)
					if not a or not b:
						if a or b: logger('AniSkip gap %s' % stype, 'only one provider has it -> not corroborated, skipped')
						continue
					if not _corroborated(a, b):
						logger('AniSkip gap %s' % stype, '%s vs %s disagree -> skipped' % (a[0], b[0]))
						continue
					if _plausible(stype, a):
						merged[stype] = a
						logger('AniSkip gap %s' % stype, 'filled from IntroDB %s (corroborated by %s)' % (a[0], b[0]))
		else:
			# Provider 1 (rich).
			if not all(k in merged for k in ('intro', 'outro')):
				for stype, segs in _app().items():
					if stype not in merged: merged[stype] = segs
			# LOCAL PATCH 2026-08-26: discard implausible segments BEFORE deciding whether to consult provider 2.
			for stype in list(merged):
				if not _plausible(stype, merged[stype]):
					logger('IntroDB.app: implausible %s' % stype, '%s -> discarded, trying theintrodb.org' % (merged[stype],))
					del merged[stype]
			# Provider 2 (sparse fallback) — fires when introdb.app is missing a segment type
			# or had one rejected above. Its own segments are validated the same way.
			# LOCAL PATCH 2026-10-26: ...and also whenever introdb.app's outro has an end, to check that end (_outro_end_from_org).
			if not merged or not all(k in merged for k in ('intro', 'outro')) or _closed_outro(merged.get('outro')):
				fallback = _org()
				for stype in _SEGMENT_KEYS:
					if stype in merged or stype not in fallback: continue
					if _plausible(stype, fallback[stype]): merged[stype] = fallback[stype]
					else: logger('IntroDB.org: implausible %s' % stype, '%s -> discarded' % (fallback[stype],))
				_outro_end_from_org(merged, fallback)
				_alternate_outro(merged, fallback)
				_aniskip_outro_vote(merged, cour, _ask)
	if failed:
		logger('IntroDB', 'not cached: %s did not answer (%s)' % (', '.join(failed), key))
		return merged
	try:
		set_property(key, json.dumps(merged) if merged else 'MISS:%d' % int(time.time()))
	except: pass
	return merged
