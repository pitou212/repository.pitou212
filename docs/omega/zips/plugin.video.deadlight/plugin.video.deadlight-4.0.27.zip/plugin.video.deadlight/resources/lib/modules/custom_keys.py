# -*- coding: utf-8 -*-
from urllib.parse import parse_qsl
from modules.kodi_utils import get_infolabel, activate_window, container_update, hide_busy_dialog
from indexers import dialogs

def extras_menu():
	params = get_params('extras_params')
	if params: dialogs.extras_menu_choice(params)

def options_menu():
	params = get_params('options_params')
	if params: dialogs.options_menu_choice(params)

def playback_options():
	params = get_params('playback_options_params')
	if params: dialogs.playback_choice(params)

# LOCAL PATCH 2026-11-01 (cleanup): the six browse_* keys were copies of this; names kept (custom_key.<name> router modes)
def _browse(param_name):
	params = get_params(param_name)
	if params:
		window_function = activate_window if params['is_external'] in (True, 'True', 'true') else container_update
		return window_function(params)

def browse_movie_set(): return _browse('browse_movie_set_params')

def browse_recommended(): return _browse('browse_recommended_params')

def browse_related(): return _browse('browse_related_params')

def browse_more_like_this():
	hide_busy_dialog()
	return _browse('browse_more_like_this_params')

def browse_similar(): return _browse('browse_similar_params')

def browse_in_trakt_list(): return _browse('browse_in_trakt_list_params')

def trakt_manager():
	params = get_params('trakt_manager_params')
	if params: dialogs.trakt_manager_choice(params)

def personal_manager():
	params = get_params('personal_manager_params')
	if params: dialogs.personallists_manager_choice(params)

def tmdb_manager():
	params = get_params('tmdb_manager_params')
	if params: dialogs.tmdblists_manager_choice(params)

def favorites_manager():
	params = get_params('favorites_manager_params')
	if params: dialogs.favorites_manager_choice(params)

def get_params(param_name):
	try: params = dict(parse_qsl(get_infolabel('ListItem.Property(deadlight.%s)' % param_name).split('plugin://plugin.video.deadlight/?')[1], keep_blank_values=True))
	except: params = None
	return params