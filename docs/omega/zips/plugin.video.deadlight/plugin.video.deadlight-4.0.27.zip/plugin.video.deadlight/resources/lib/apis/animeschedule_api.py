# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-10-15: AnimeSchedule.net (api/v3) -- English sub / dub air times for the 'Anime Air Times' choice
(settings anime.airtime_provider; used by metadata._anilist_air_times). Data by AnimeSchedule.net, credited in the setting.

One record per AniList entry (GET /anime?anilist-ids=N), cached 12 h. It carries, per track (Japanese / sub / dub), a
premiere date, a weekly time of day, an 'episodes aired' override and a delay window.

NEEDS THE USER'S OWN TOKEN ('animeschedule.token'): the API terms reserve requests without a Bearer token for the site's
own undocumented 'public endpoints' and tell apps to use the private ones, and a token may not ship in public code -- so
DeadLight cannot carry one. Without a token nothing is asked here and metadata.airtime_source() reads the choice as
AniList. Limit: 120 requests a minute per IP and app, counted down in X-RateLimit-Remaining / -Reset (paced below).

Episode times are AniList's per-episode Japanese schedule SHIFTED by the track's lag (track start - Japanese start),
not a weekly count from the premiere: AniList already carries the breaks, double episodes and
all-at-once drops, and
AnimeSchedule's premiere + weekly time matched AniList to the minute on most shows checked.
The weekly count is the fallback only when AniList has no schedule for the entry."""
import time, datetime
from caches.settings_cache import get_setting
from caches.lists_cache import lists_cache_object
from modules.kodi_utils import logger, make_session, cooldown_active, start_cooldown
# LOCAL PATCH 2026-10-19: DeadLight's lazy session -- its shared SSL context loads the CA bundle once per process; a
# bare requests.get reloaded it for every connection (~0.9 s CPU each).
_session = make_session()

_BASE = 'https://animeschedule.net/api/v3/anime'
_CACHE_HOURS = 12
_COOLDOWN_PROP = 'deadlight.animeschedule_cooldown_until'
_NULL = '0001-01-01'
_WEEK = 7 * 86400


def _token():
	token = get_setting('deadlight.animeschedule.token', '') or ''
	return '' if token in ('', 'empty_setting') else token


def available():
	return bool(_token())


def on_cooldown():
	return cooldown_active(_COOLDOWN_PROP)


def _start_cooldown(secs, reason):
	try:
		start_cooldown(_COOLDOWN_PROP, secs)
		logger('AnimeSchedule', '%s - no requests for %d min' % (reason, max(1, secs // 60)))
	except Exception: pass


def _pace(response):
	"""Stop asking until X-RateLimit-Reset once the window is nearly spent (or spent: a 429), as the terms ask."""
	try:
		remaining = response.headers.get('X-RateLimit-Remaining')
		reset = response.headers.get('X-RateLimit-Reset')
		if remaining is None or reset is None: return
		if int(remaining) <= 2 or response.status_code == 429:
			wait = min(max(float(reset) - time.time(), 5), 3600)
			_start_cooldown(wait, 'rate limit window spent (%s left)' % remaining)
	except Exception: pass


def record_for_anilist(anilist_id):
	"""The AnimeSchedule record for one AniList entry; {} when AnimeSchedule has none, None when it did not answer."""
	try: anilist_id = int(anilist_id)
	except (TypeError, ValueError): return None
	if not available() or on_cooldown(): return None
	def _fetch(_dummy):
		headers = {'User-Agent': 'DeadLight-Kodi', 'Authorization': 'Bearer %s' % _token()}
		try: r = _session.get(_BASE, params={'anilist-ids': anilist_id}, headers=headers, timeout=15)
		except Exception as e:
			_start_cooldown(300, 'unreachable (%s)' % e.__class__.__name__); return None
		_pace(r)
		if r.status_code == 429:
			if not on_cooldown(): _start_cooldown(600, 'rate limited')
			return None
		if r.status_code == 401:
			_start_cooldown(3600, 'token refused (401) - check Settings > Content > Anime > AnimeSchedule Token'); return None
		if r.status_code >= 500: _start_cooldown(600, 'HTTP %s' % r.status_code); return None
		if not r.ok:
			logger('AnimeSchedule', 'HTTP %s for anilist %s' % (r.status_code, anilist_id)); return None
		try: anime = r.json().get('anime') or []
		except ValueError: return None
		return anime[0] if anime else {}
	try: return lists_cache_object(_fetch, 'animeschedule_al_%s' % anilist_id, 1, expiration=_CACHE_HOURS)
	except Exception: return None


def _stamp(text):
	"""ISO 'YYYY-MM-DDTHH:MM:SSZ' -> UTC epoch, None for AnimeSchedule's null date. Not strptime (Kodi's Python 3.8)."""
	if not text or str(text).startswith(_NULL): return None
	try:
		d, t = str(text)[:19].split('T')
		parts = [int(x) for x in d.split('-')] + [int(x) for x in t.split(':')]
		return datetime.datetime(*parts, tzinfo=datetime.timezone.utc).timestamp()
	except Exception: return None


def _time_of_day(text):
	stamp = _stamp(text)
	return None if stamp is None else stamp % 86400


def track_start(record, track):
	"""UTC epoch of episode 1 on 'sub' / 'dub' (or 'jpn'), or None when that track has no date. A sub with no date of its
	own is a simulcast: the Japanese date, at the sub time (the next day when the sub time of day is earlier)."""
	prefix = {'jpn': '', 'sub': 'sub', 'dub': 'dub'}[track]
	premier = _stamp(record.get(prefix + 'Premier' if prefix else 'premier'))
	tod = _time_of_day(record.get(prefix + 'Time' if prefix else 'jpnTime'))
	jp = _stamp(record.get('premier'))
	jp_tod = _time_of_day(record.get('jpnTime'))
	if premier is None:
		if track != 'sub' or jp is None or tod is None: return None
		start = jp + (jp_tod or 0)
		lag = (tod - (jp_tod or 0)) % 86400
		return start + lag
	day = premier - premier % 86400
	return day + (tod if tod is not None else 0)


def _override(record, track):
	prefix = {'jpn': '', 'sub': 'sub', 'dub': 'dub'}[track]
	o = record.get((prefix + 'EpisodeOverride') if prefix else 'episodeOverride') or {}
	try: episode = int(o.get('overrideEpisode') or 0)
	except (TypeError, ValueError): episode = 0
	return episode, _stamp(o.get('overrideDate'))


def _delay(record, track):
	prefix = {'jpn': '', 'sub': 'sub', 'dub': 'dub'}[track]
	key = (lambda k: prefix + k[0].upper() + k[1:]) if prefix else (lambda k: k)
	return _stamp(record.get(key('delayedFrom'))), _stamp(record.get(key('delayedUntil')))


def track_times(record, track, jp_times, numbers):
	"""{episode number: UTC epoch} on the 'sub' / 'dub' track for these episode numbers (numbering within the entry).
	jp_times is AniList's {episode: epoch} for the entry ({} when it has none). Empty when the track has no date."""
	record = record or {}
	start = track_start(record, track)
	if start is None: return {}
	# the track's lag behind Japan, from AnimeSchedule's own two start times.
	# AniList's schedule may begin mid-season, so the lag is not measured against
	# AniList's episode 1 unless the schedule has it.
	# Against AniList's own episode 1 when it has it: AnimeSchedule's Japanese time
	# can sit 30 min off AniList's.
	# 2026-10-16: with no episode 1 in AniList's schedule, episode 1 counted back
	# weekly from the earliest it has, and AnimeSchedule's own Japanese premiere only
	# last -- that premiere can be an advance screening weeks before the weekly run,
	# which would read as a month-long 'lag'.
	known = sorted(n for n in (jp_times or {}) if jp_times.get(n) is not None)
	if jp_times and jp_times.get(1) is not None: jp_start = jp_times[1]
	elif known: jp_start = jp_times[known[0]] - (known[0] - 1) * _WEEK
	else: jp_start = track_start(record, 'jpn')
	lag = (start - jp_start) if jp_start is not None else None
	out = {}
	for n in numbers:
		if lag is not None and jp_times and jp_times.get(n) is not None: out[n] = jp_times[n] + lag   # AniList's time, shifted
		else: out[n] = start + (n - 1) * _WEEK   # no AniList time: weekly from the track's premiere
	o_ep, o_date = _override(record, track)
	if o_ep and o_date:
		# the track runs from the override: episode o_ep at o_date, the rest keep their spacing from it
		base = out.get(o_ep)
		if base is not None:
			shift = o_date - base
			for n in out:
				if n >= o_ep: out[n] += shift
	d_from, d_until = _delay(record, track)
	if d_from and d_until and d_until > d_from:
		weeks = -(-(d_until - d_from) // _WEEK)   # whole weeks, rounded up: the weekday stays
		for n in out:
			if out[n] >= d_from: out[n] += weeks * _WEEK
	return out
