# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-10-19: knaben -- Knaben's JSON search API (api.knaben.org/v2), searched by NAME.

	Back in bitsearch's place (bitsearch.eu: Cloudflare 520 / 7 s timeouts on every TV query, 2026-10-19). The 09-28
	knaben scraped HTML and took seconds per search, so it was dropped for apibay on 09-29. Upstream magneto 6.10.04
	moved it to this API. Timed 2026-10-19: 0.7-1.6 s per query, Oppenheimer 104 rows, The Bear S03 150 rows, the
	Monster: The Lizzie Borden Story S01E01 row (no IMDb id on TMDb -- why name search is bundled at all).

	API: https://api.knaben.org/v2/search?dead&o=date&c=<category>&q=<query>   No key.
	  {'hits': [{'title', 'hash' (upper case), 'seeders', 'bytes', 'tracker', ...}], 'total': {...}}
	  c=3000000 movies, c=2000000 TV. An aggregator: most rows are The Pirate Bay's (so apibay overlaps), plus
	  YTS, 1337x and others. Its matching is loose (The Bear S03E01 also returns 'The Great S03E01 ... the Bear'),
	  so check_title does the real filtering. One answer seen truncated mid-JSON: a parse error is a failed query.

	Laid out like apibay.py (episode / season-pack / show-pack queries, the pack ones in parallel threads), using
	client.request so the loading window's ok / failed tally sees it. LOCAL PATCH 2026-11-01 (cleanup): the bodies are
	provider_base.NameSearchSource's.
"""

import json
from html import unescape
from urllib.parse import quote_plus
from magneto.modules.provider_base import NameSearchSource


class source(NameSearchSource):
	provider = 'knaben'
	base_link = 'https://api.knaben.org'
	# LOCAL PATCH 2026-10-25 (4.0.5): o=seeders, was o=date. A page is capped at 150 rows (size= is ignored), so a big
	# match set lost its oldest rows: Breaking Bad S01 (220 matches) kept 109 seeded rows by date, 131 by seeders --
	# the 720p BluRay season pack among the 22 gained; the 36 rows only date order kept all had 0 seeders.
	search_link = '/v2/search?dead&o=seeders&c=%s&q=%s'
	movie_category, tv_category = '3000000', '2000000'
	name_key, size_key = 'title', 'bytes'

	def _url(self, category, query):
		return '%s%s' % (self.base_link, self.search_link % (category, quote_plus(query)))

	def _rows(self, results):
		rows = json.loads(results).get('hits') or []
		# LOCAL PATCH 2026-10-25 (4.0.5): titles come HTML-escaped ('Fast &amp; Furious 6 ...': 17 of 148 rows), and
		# check_title refused every one -- a name with '&' never matched.
		for row in rows: row['title'] = unescape(row.get('title') or '')
		return rows
