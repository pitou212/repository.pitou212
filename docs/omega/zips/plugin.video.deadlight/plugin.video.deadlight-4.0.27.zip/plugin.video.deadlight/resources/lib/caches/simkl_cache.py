# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-29: SIMKL cache module, same shape as mdblist_cache.py (KV `simkl_data` + watched + progress +
# watched_status tables), selected via watched_indicators == 3 as trakt (1) and mdblist (2) are.
from caches.base_cache import ProviderCache


# LOCAL PATCH 2026-10-19: the class body lives in base_cache.ProviderCache (shared with Trakt / MDBList; adds allow_empty).
# keep_local_progress: SIMKL has no resume-point API (see ProviderCache).
class SimklCache(ProviderCache):
	def __init__(self): ProviderCache.__init__(self, 'simkl_db', 'simkl_data', keep_local_progress=True)


simkl_cache = SimklCache()


# ═══════════════════════════════════════════════════════════════════════════
#  List caching (per-list-type keyed) — populated by indexers/simkl_lists.py
#  Follows mdblist_cache.simkl_cache_object pattern.
# ═══════════════════════════════════════════════════════════════════════════

def simkl_cache_object(function, string, *args, expiration=None):
	"""Read-through cache for arbitrary SIMKL fetches. Same signature as
	trakt_cache.trakt_cache_object so callers stay uniform."""
	result = simkl_cache.get(string)
	if result is not None: return result
	result = function(*args)
	if result is not None:
		simkl_cache.set(string, result)
	return result


# ═══════════════════════════════════════════════════════════════════════════
#  Cache invalidation — called on write ops and by SIMKLMonitor when activity
#  timestamps change.
# ═══════════════════════════════════════════════════════════════════════════

# LOCAL PATCH 2026-11-01 (cleanup): one-liners over ProviderCache.delete / delete_like / delete_all (same rows as before)
def clear_simkl_list(list_type, status=None):
	"""Clear a single cached list. list_type in {movies, shows, anime}. status optional."""
	if status: simkl_cache.delete('simkl_%s_%s' % (list_type, status))
	else: simkl_cache.delete_like('simkl_%s_%%' % list_type)


def clear_simkl_lists_cache():
	"""Nuke all cached lists — called by SIMKLMonitor when /sync/activities
	shows any timestamp change. Preserves watched/progress tables (those are
	rebuilt by the next indicators-sync)."""
	simkl_cache.delete_all()
