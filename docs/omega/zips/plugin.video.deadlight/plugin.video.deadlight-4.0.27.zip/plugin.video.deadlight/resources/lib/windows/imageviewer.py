# -*- coding: utf-8 -*-
import json
import re
from windows.base_window import BaseDialog
from indexers.people import person_data_dialog
from indexers.dialogs import favorites_manager_choice
from modules.settings import download_directory
from modules.kodi_utils import addon_fanart, get_icon, select_dialog


class ThumbImageViewer(BaseDialog):
	glass_full_screen = True # LOCAL PATCH 2026-10-23: text on the background, darker glass (base_window set_glass)
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		# LOCAL PATCH 2026-11-07: grid redesign -- panel 2000 = 2:3 tiles that fill (people), 2001 = whole 16:9 tiles (artwork,
		# stills, files); the header names the set (indexers/images.window_heading)
		self.tile_shape = kwargs.get('tile_shape', 'wide')
		self.window_id = 2000 if self.tile_shape == 'portrait' else 2001
		self.current_page = 1
		self.selected = None
		self.backup_thumbnail = get_icon('empty_person')
		self.list_items = kwargs.get('list_items')
		self.next_page_params = kwargs.get('next_page_params')
		self.ImagesInstance = kwargs.get('ImagesInstance')
		self.heading, self.kind, self.subject_image = kwargs.get('heading', ''), kwargs.get('kind', 'Images'), kwargs.get('subject_image', '')
		# a title's artwork comes in sections (Posters / Fanart / Landscape / Clearlogos): pills 3001-3004 switch them
		self.sections, self.section = kwargs.get('sections') or [], 0
		# before the window shows: panel 2000 is hidden until tile_shape says portrait, and a hidden panel takes no focus
		self.setProperty('tile_shape', self.tile_shape)
		self.set_section_pills()

	def onInit(self):
		self.make_page()

	def run(self):
		self.doModal()
		self.clearProperties()

	def set_section_pills(self):
		self.setProperty('sections', str(len(self.sections)) if len(self.sections) > 1 else '')
		# the chosen section is a lit chip (accent_soft plate, accent label), the rest idle pills: all theme colours, so the
		# focused pill (win.focus, in the XML) stays the only filled one
		soft, accent = self.get_home_property('win.accent_soft'), self.get_home_property('win.accent')
		idle = self.get_home_property('window_theme_contrast') or 'FF4a4347'
		for count, section in enumerate(self.sections[:4], 1):
			chosen = count - 1 == self.section
			self.setProperty('pill%d.label' % count, '%s  %d' % (section['label'], len(section['items'])))
			# colours as Home copies (deadlight.win.*): a window property colour turns white under Kodi's own dialogs
			self.set_colour_property('pill%d.bg' % count, soft if chosen else idle)
			self.set_colour_property('pill%d.fg' % count, accent if chosen else 'FFE8E8EA')

	def onClick(self, controlID):
		if not 3001 <= controlID <= 3004 or controlID - 3001 >= len(self.sections): return
		self.section = controlID - 3001
		section = self.sections[self.section]
		self.reset_window(2000); self.reset_window(2001)
		self.tile_shape, self.list_items = section['shape'], section['items']
		self.window_id = 2000 if self.tile_shape == 'portrait' else 2001
		self.setProperty('tile_shape', self.tile_shape)
		self.set_section_pills()
		self.set_properties()
		self.add_items(self.window_id, self.list_items)

	def onAction(self, action):
		if action in self.closing_actions:
			if self.current_page == 1: return self.close()
			return self.previous_page()
		if 3001 <= self.getFocusId() <= 3004: return   # a section pill: onClick switches
		try:
			position = self.get_position(self.window_id)
			chosen_listitem = self.get_listitem(self.window_id)
		except: return
		if action in self.selection_actions:
			if chosen_listitem.getProperty('next_page_item') == 'true': self.new_page()
			else:
				thumb_params = json.loads(chosen_listitem.getProperty('action'))
				mode = thumb_params['mode']
				if mode == 'imageviewer':
					thumb_params['current_index'] = position
					ending_position = self.ImagesInstance.run(thumb_params)
					self.select_item(self.window_id, ending_position)
				elif mode == 'person_data_dialog':
					person_data_dialog(thumb_params)
		elif action in self.context_actions:
			if chosen_listitem.getProperty('next_page_item') == 'true': return
			in_favorites = chosen_listitem.getProperty('in_favorites') == 'true'
			enable_favorite = chosen_listitem.getProperty('fav_enabled') == 'true' or in_favorites
			choice = self.make_context_menu(enable_delete=chosen_listitem.getProperty('delete') == 'true', enable_favorite=enable_favorite)
			if choice:
				if choice == 'delete_image': return self.reset_after_delete(chosen_listitem, position)
				elif choice == 'download_image':
					name, thumb, path = chosen_listitem.getProperty('name'), chosen_listitem.getProperty('thumb'), chosen_listitem.getProperty('path')
					if not path: return self.notification('No Image Path to Download')
					params = {'mode': 'downloader.runner', 'action': 'image', 'name': name, 'thumb_url': thumb, 'image_url': path, 'media_type': 'image', 'image': path}
					self.execute_code('RunPlugin(%s)' % self.build_url(params))
				elif choice == 'manage_favorite':
					actor_id = chosen_listitem.getProperty('actor_id')
					actor_image = chosen_listitem.getProperty('actor_image') or chosen_listitem.getProperty('path')
					title = '%s|%s|%s' % (chosen_listitem.getProperty('actor_name'), chosen_listitem.getProperty('thumb'), actor_image)
					action = favorites_manager_choice({'media_type': 'people', 'tmdb_id': actor_id, 'title': title, 'refresh': 'false'})
					if in_favorites and action == 'Remove From Favorites?': self.reset_after_favorite_delete(position)
				else:#exit_image
					return self.close()

	def make_page(self):
		try:
			self.set_properties()
			if self.next_page_params.get('page_no', 'final_page') != 'final_page': self.make_next_page()
			self.add_items(self.window_id, self.list_items)
			self.setFocusId(self.window_id)
		except: pass

	def make_context_menu(self, enable_delete, enable_favorite):
		choices = []
		choices_append = choices.append
		if enable_delete: choices_append(('Delete', 'delete_image'))
		else: choices_append(('Download File', 'download_image'))
		if enable_favorite: choices_append(('Favorites Manager', 'manage_favorite'))
		if self.current_page > 1: choices_append(('Exit Images', 'exit_image'))
		list_items = [{'line1': i[0]} for i in choices]
		kwargs = {'items': json.dumps(list_items), 'narrow_window': 'true', 'heading': 'Image'}
		choice = select_dialog([i[1] for i in choices], **kwargs)
		return choice

	def new_page(self):
		try:
			self.current_page += 1
			self.next_page_params['in_progress'] = 'true'
			self.list_items, self.next_page_params = self.ImagesInstance.run(self.next_page_params)
			self.reset_window(self.window_id)
			self.make_page()
		except: self.close()

	def previous_page(self):
		try:
			self.current_page -= 1
			self.next_page_params['page_no'] = self.current_page
			self.next_page_params['in_progress'] = 'true'
			self.list_items, self.next_page_params = self.ImagesInstance.run(self.next_page_params)
			self.reset_window(self.window_id)
			self.make_page()
		except: self.close()

	def make_next_page(self):
		try:
			listitem = self.make_listitem()
			listitem.setProperties({'name': 'Next Page (%s) >>' % str(self.current_page + 1), 'thumb': get_icon('nextpage'), 'next_page_item': 'true'})
			self.list_items.append(listitem)
		except: pass

	def reset_after_delete(self, choice, position):
		self.ImagesInstance.delete_image(choice.getProperty('path'), choice.getProperty('thumb'))
		self.reset_window(self.window_id)
		self.list_items = self.ImagesInstance.browser_image(download_directory('image'), return_items=True)
		self.make_page()
		self.select_item(self.window_id, position)

	def reset_after_favorite_delete(self, position):
		self.reset_window(self.window_id)
		self.list_items = self.ImagesInstance.favorite_people_list_image_results(return_items=True)
		self.make_page()
		self.select_item(self.window_id, position)

	def set_properties(self):
		self.setProperty('page_no', str(self.current_page))
		self.setProperty('item_count', str(len(self.list_items)))
		self.setProperty('fanart', addon_fanart())
		self.setProperty('backup_thumbnail', self.backup_thumbnail)
		self.setProperty('tile_shape', self.tile_shape)
		self.setProperty('heading', self.heading)
		self.setProperty('subject_image', self.subject_image)
		page = '  •  Page %d' % self.current_page if self.current_page > 1 or self.next_page_params.get('page_no', 'final_page') != 'final_page' else ''
		self.setProperty('subline', '%s  •  %d%s' % (self.kind, len(self.list_items), page))


def display_title(title):
	# LOCAL PATCH 2026-11-07: 'Michael C. Hall_001' -> 'Michael C. Hall', 'Inception (2010) _Poster_003' -> 'Inception (2010) · Poster'
	try:
		title = re.sub(r'_?\d{3}$', '', str(title)).strip(' _')
		return re.sub(r'\s*_\s*', '  ·  ', title)
	except: return title

class ImageViewer(BaseDialog):
	glass_full_screen = True # LOCAL PATCH 2026-10-23: text on the background, darker glass (base_window set_glass)
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.window_id = 5000
		self.all_images = kwargs.get('all_images')
		self.index = kwargs.get('index')
		self.position = self.index   # a close not via onAction returns where it started
		self.scroll_ids = (self.left_action, self.right_action)
		self.backup_thumbnail = get_icon('empty_person')
		self.make_items()
		self.set_properties()

	def onInit(self):
		self.add_items(self.window_id, self.item_list)
		self.select_item(self.window_id, self.index)
		self.setFocusId(self.window_id)

	def run(self):
		self.doModal()
		self.clearProperties()   # LOCAL PATCH 2026-10-24: re-sets the glass colours for the close fade (base_window)
		return self.position

	def onAction(self, action):
		if action in self.closing_actions:
			self.position = self.get_position(self.window_id)
			self.close()

	def make_items(self):
		def builder():
			for count, item in enumerate(self.all_images, 1):
				try:
					listitem = self.make_listitem()
					# LOCAL PATCH 2026-11-08: posters at w780 (fills 1080 high); 'original' is often 1-3 MB to fetch and decode on
					# the box. Fanart keeps original; downloads read the grid's path, not this.
					image = item[0].replace('/t/p/original/', '/t/p/w780/') if '_Poster_' in str(item[1]) else item[0]
					listitem.setProperties({'image': image, 'title': display_title(item[1]), 'item_count': '%d / %d' % (count, total_images)})
					yield listitem
				except: pass
		total_images = len(self.all_images)
		self.item_list = list(builder())

	def set_properties(self):
		self.setProperty('item_count', str(len(self.item_list)))
		self.setProperty('fanart', addon_fanart())
		self.setProperty('backup_thumbnail', self.backup_thumbnail)
