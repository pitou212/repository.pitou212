# -*- coding: utf-8 -*-
"""Anime release-name parsing, shared by the magneto providers.

LOCAL PATCH 2026-08-27. Extracted from providers/torrents/nyaa.py so comet's kitsu path shares one copy of these
fiddly regexes. Non-anime matching (source_utils.check_title) is untouched; the names keep their leading
underscores so nyaa.py needed no edits beyond the import.

What this handles that the western matcher cannot:
  - season markers inside brackets: "(Season 3)", "[S01-02]"
  - the absolute-numbering convention: "S03E20.(57)" is ONE episode, not 20-57
  - bare ordinals: "Re:Zero ... 4th - 01~11" is season 4
  - cour/part ranges: "Season 3 Part 2 - 01 ~ 10"
"""
import re
import functools   # LOCAL PATCH 2026-11-04: _clean_for_extract's cache


_TOKEN_STOPWORDS = frozenset((
	'the', 'and', 'of', 'a', 'an', 'in', 'on', 'to', 'for',
	'season', 'part', 'cour', 'movie', 'ova', 'tv', 'anime',
	'no', 'wa', 'ga', 'ni', 'wo', 'ka', 'kara', 'made',
))

_ROMAN_MAP = {'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5}
_WORD_MAP = {'first': 1, 'second': 2, 'third': 3, 'fourth': 4, 'fifth': 5,
			 'sixth': 6, 'seventh': 7, 'eighth': 8}

# Otaku-style: strip quality/codec/audio noise BEFORE regex-extracting season/ep.
_NOISE_PATTERNS = re.compile(
	r'\b(?:360p|480p|576p|720p|1080p|1440p|2160p|4k)(?!\d)'
	r'|\b10\s?bits?\b'
	r'|\b(?:h\.?\s?264|x\.?\s?264|h\.?\s?265|x\.?\s?265|hevc|avc|hls|vp9|av1)(?!\d)'
	r'|\b(?:web-dl|webrip|bluray|hdrip|dvdrip|hdtv|pdtv|cam|screener|bdrip)\b'
	r'|\b(?:hdr10\+?|hdr|sdr|dv|dolby\s?vision|dovi)\b'
	r'|\b(?:mp4|mkv|mpeg|xvid|divx|wmv|flac)\b'
	r'|\b(?:aac|mp3|opus|ddp|dd|ac3|dts(?:-hdma|-hdhr|-x)?|atmos|truehd)(?:\d+(?:\.\d+)?)?\b'
	r'|\b(?:1\.0|2\.0|5\.1|7\.1|2ch|5ch|7ch|8ch)\b'
	r'|\b(?:multi\s?audio|dual\s?audio|dub(?:bed)?|multi\s?sub|subbed|multi[- ]?sub(?:title)?s?)\b'
	, re.I
)


def _tokenize(text):
	"""Lowercase word tokens of length >=3, stopwords removed."""
	if not text: return set()
	words = re.findall(r'[A-Za-z0-9]+', str(text).lower())
	return {w for w in words if len(w) >= 3 and w not in _TOKEN_STOPWORDS}


# LOCAL PATCH 2026-08-27: contiguous title matching. Sharing ANY ONE token with the title set let generic words through
# (Re:ZERO's {zero, world, ...} admitted Fate.Zero, Aldnoah.Zero, The.World's.Finest.Assassin). Overlap SIZE cannot
# separate them (the legitimate romaji also shares just 'zero'); ADJACENCY does -- a real release contains a title
# candidate as consecutive words. Apostrophes are deleted, not separators, so "Journey's End" = "Journeys.End".
_APOS = re.compile('[' + chr(39) + chr(0x2019) + chr(0x02BC) + ']')


def _title_seq(text):
	"""Ordered alphanumeric word run. Keeps short words -- adjacency needs them."""
	return re.findall(r'[a-z0-9]+', _APOS.sub('', str(text or '').lower()))


# What may legally sit next to a title match. Anything else means a DIFFERENT, longer-titled show: 'Boruto - Naruto Next
# Generations' and 'Naruto Shippuden' contain 'Naruto' and are separate TMDb shows.
_TITLE_EDGE_OK = re.compile(
	# LOCAL PATCH 2026-11-10: '1x01' (season x episode: 'One Piece - 1x01 - I'm Luffy!') and the spelled-out languages
	# ('one.piece.english.dub(1-263)', 'One Piece English Dub 1') -- both were read as a longer show's title
	r'^(?:\d+|\d+(?:st|nd|rd|th)|\d{1,2}x\d{1,4}|english|japanese|s\d+\w*|e\d+|v\d+|ep\d*|complete|series|batch|collection|season|seasons|'
	r'part|parts|pt\d*|cour|vol|volume|movie|movies|ova|oad|oav|special|specials|nc\w*|'
	r'bd|bdrip|bdmv|bluray|blu|ray|web|webrip|webdl|dl|dvd|dvdrip|remux|hevc|avc|hdr|'
	r'x264|x265|h264|h265|av1|xvid|aac|flac|opus|ac3|eac3|dts|truehd|dual|multi|'
	r'eng|jpn|jap|esp|ita|fre|ger|por|sub|subs|subbed|subtitle|subtitles|dub|dubbed|'
	r'raw|final|arc|the|and|uncut|uncensored|censored|repack|proper|hi10|10bit|8bit|'
	# LOCAL PATCH 2026-08-27: the same structural words in other release languages ('Naruto (Integrale) VOSTFR').
	r'integrale|integral|integrali|complet|completa|completo|completos|coffret|'
	r'stagione|saison|temporada|staffel|sezon|serie|boxset|vostfr|truefrench|'
	r'castellano|latino|dublado|legendado)$',
	re.I)


def _seq_matches(name_seq, cand_seqs):
	"""True when any candidate matches the row, as consecutive words or joined.

	A match must sit on clean boundaries, or every longer show name containing ours is a hit (Boruto / Shippuden under
	Naruto). Only one candidate has to match cleanly, so 'Attack on Titan (Shingeki no Kyojin) - 01' passes on the alias.

	The joined form covers groups that drop separators ('Attack.on.TitanShingeki...', 'SPYxFAMILY'). It cannot honour
	boundaries, so it needs a length that cannot collide by accident: at 6 'naruto' matched inside
	'borutonarutonextgenerations'; 10 still covers "attackontitan" and "spyxfamily".
	"""
	if not cand_seqs: return True
	# LOCAL PATCH 2026-08-27: a neighbouring word of one of OUR OWN candidate titles is not a different show: names carry the
	# title twice ('Naruto/NARUTO --][001-220TV]'). 'boruto' and 'shippuden' are not Naruto words, so those still reject.
	cand_words = set(w for c in cand_seqs for w in c)
	for cand in cand_seqs:
		n = len(cand)
		if not n or n > len(name_seq): continue
		for i in range(len(name_seq) - n + 1):
			if name_seq[i:i + n] != cand: continue
			before = name_seq[i - 1] if i > 0 else None
			after = name_seq[i + n] if i + n < len(name_seq) else None
			# a short neighbour is noise ('Naruto HD (001-220)'), a long one is a title word
			if before is not None and len(before) >= 4:
				if not _TITLE_EDGE_OK.match(before) and before not in cand_words: continue
			if after is not None and len(after) > 2:
				if not _TITLE_EDGE_OK.match(after) and after not in cand_words: continue
			return True
	joined = ''.join(name_seq)
	for cand in cand_seqs:
		cj = ''.join(cand)
		if len(cj) >= 10 and cj in joined: return True
	return False


_BRACKET_GROUP = re.compile(r'\[(.*?)\]|\((.*?)\)')
# Bracketed episode ranges must survive: '(26-50)' labels a season-2 batch counted from the series start; stripped, the
# row read as a bare batch matching everything. The lookarounds exclude year spans ('2011-2018' would bind '011-201').
# LOCAL PATCH 2026-09-22: the endpoints may carry an 'E' ('(S01) (E01-E12)'), or the group was discarded and the pack
# read as a bare batch.
_RANGEISH = re.compile(r'(?<![\da-z])e?\d{1,3}\s*(?:[-~]|\bto\b)\s*e?\d{1,3}(?!\d)', re.I)
_SEASONISH = re.compile(r'\bseason\b|\bs\d{1,2}|\bcour\b|\bpart\b|\d{1,2}(?:st|nd|rd|th)\s*season', re.I)
# LOCAL PATCH 2026-10-06: 'season' in Italian, French, Spanish / Portuguese, German, Polish / Turkish, Dutch, Swedish, Danish /
# Norwegian, Finnish and Russian, followed by its number (_clean_for_extract); Chinese 第2季 ('season 2').
_FOREIGN_SEASON = re.compile(r'(?<![a-z0-9])(?:stagione|saison|temporada|staffel|sezon|seizoen|s[aä]song|s[aæ]son|kausi|сезон)(?=[\s._-]*\d)', re.I)
_CJK_SEASON = re.compile(r'第\s*(\d{1,2})\s*季')


def _keep_if_seasonish(m):
	"""Keep a bracket group's text when it carries season/part info, else drop it."""
	inner = m.group(1) if m.group(1) is not None else m.group(2)
	if inner and (_SEASONISH.search(inner) or _RANGEISH.search(inner)):
		return ' ' + inner + ' '
	return ' '


# LOCAL PATCH 2026-11-04: remembered -- a str-to-str function the release judge reaches 3-4 times per row. Only for
# hashable names; anything else is cleaned as before.
@functools.lru_cache(maxsize=4096)
def _clean_for_extract_cached(name):
	return _clean_for_extract_uncached(name)

def _clean_for_extract(name):
	if isinstance(name, str): return _clean_for_extract_cached(name)
	return _clean_for_extract_uncached(name)

def _clean_for_extract_uncached(name):
	"""Strip quality/codec/audio noise + brackets so numeric extraction is unambiguous.
	magneto's clean_name has already converted spaces to dots; we normalize back."""
	s = name.lower().replace('.', ' ').replace('_', ' ')
	# LOCAL PATCH 2026-10-06: 'season' in other languages reads as 'season' ('(Stagione.3)' was taken as a season-1 pack).
	# Done before the bracket pass, so '(Stagione.2)' is kept by _SEASONISH like '(Season 2)'.
	s = _FOREIGN_SEASON.sub('season', s)
	s = _CJK_SEASON.sub(lambda m: ' season %s ' % m.group(1), s)
	# LOCAL PATCH 2026-08-27: not a blanket strip of every (...) / [...] group -- many groups write the season in brackets
	# ('... (Season 3) [1080p]'), and with no season parsed the guard in sources() reads 'makes no season claim', so every
	# (Season N) release surfaced under every season. Groups mentioning a season/part/cour keep their contents; the rest are
	# discarded, so quality tags and CRC32 stamps (hex, no 's') cannot leak digits into episode parsing.
	s = _BRACKET_GROUP.sub(_keep_if_seasonish, s)
	# A truncated name can leave an UNCLOSED bracket the pattern cannot remove (comet cuts names at ~70 chars, leaving
	# '(bs11-1920x1080-', read as range 11-1920). Cut from the stray opener on.
	s = re.sub(r'[(\[][^)\]]*$', ' ', s)
	s = _NOISE_PATTERNS.sub(' ', s)
	s = re.sub(r'\s+', ' ', s).strip()
	return s


# Unified extractors — run on the CLEANED text.
_EX_SEASON = re.compile(r'\bs(?:eason)?[ ._-]?(\d{1,2})(?!\d)', re.I)
_EX_SEASON_ORD = re.compile(r'\b(\d{1,2})(?:st|nd|rd|th)\s+season\b', re.I)
# LOCAL PATCH 2026-08-27: bare ordinal season, ONLY as a fallback: releases often drop the word ('Re:Zero ... 4th - 01~11',
# 'Spy x Family 2nd - 01'). The negative lookahead skips non-season ordinals ('10th Anniversary', '2nd Movie').
# LOCAL PATCH 2026-08-27: season RANGE, e.g. '[S01-02]', 'S01-S04', 'S1-S3' -- both endpoints taken and the span
# expanded (_EX_SEASON alone left '-02' to read as episode 2). The dash must follow the season number directly, so
# 'S02E06-08' and 'S01.E01-E14' (episode ranges) are left alone.
# LOCAL PATCH 2026-08-27: a season RANGE needs the 's' on both ends, or no spaces around the separator: otherwise the
# common 'Attack on Titan S3 - 08' read as seasons 3 THROUGH 8 and matched almost any request.
_EX_SEASON_RANGE = re.compile(r'\bs(\d{1,2})(?:\s*[-~]\s*s|[-~])(\d{1,2})\b', re.I)
_EX_SEASON_ORD_BARE = re.compile(r'\b(\d{1,2})(?:st|nd|rd|th)\b(?!\s*(?:anniversary|ann\b|movie|ova|special|plate))', re.I)
_EX_SEASON_ACT = re.compile(r'\bact\s+(i{1,3}v?|iv|v)\b', re.I)
_EX_SEASON_WORD = re.compile(r'\b(first|second|third|fourth|fifth|sixth|seventh|eighth)\s+season\b', re.I)
# Roman numeral as standalone token -- used only when NO other season signal found ("Overlord IV"). Skips bare "I"
# (too false-positive-prone).
_EX_SEASON_ROMAN = re.compile(r'\b(ii|iii|iv|v|vi|vii|viii)\b', re.I)
_EX_PART = re.compile(r'\b(?:part|cour)\s?(\d+)\b', re.I)
_EX_SXX_EYY = re.compile(r's(\d{1,2})e(\d{1,4})', re.I)
# The trailing guard keeps a resolution out of the range ('x264-1920x1080' would read 264-1920).
# LOCAL PATCH 2026-08-27: 'to' joins a range as well as '-' and '~' ('Episodes 031 to 040'); unparsed, the pack fell
# through to the batch rule and answered ANY episode.
# LOCAL PATCH 2026-09-22: optional 'E' on either endpoint ('E01-E12'). The lookbehind stops the first number binding to
# the tail of a word.
_EX_EP_RANGE = re.compile(r'(?<![a-z])e?(\d{1,4})\s*(?:[~\-]|\bto\b)\s*e?(\d{1,4})(?![\dxp])', re.I)
_EX_EP_DASH = re.compile(r'(?:^|\s)-\s*(\d{1,4})(?!\d)')
# LOCAL PATCH 2026-09-22: a span BOUND TO a volume/box/disc word counts volumes, not episodes ('(Vol 01-02)').
# Bound, not name-wide: Naruto's '[193-220TV][BOX8]' carries a REAL episode range in a separate token, so only the digits
# the volume word itself introduces are removed.
_EX_VOLUME_SPAN = re.compile(r'\b(?:vol|volume|box|disc|disk|set)[^a-z0-9]{0,2}\d{1,3}(?:\s*(?:[-~]|\bto\b)\s*\d{1,3})?', re.I)
_EX_EP_PREFIX = re.compile(r'\b(?:episode|ep|e)\s*(\d{1,4})(?!\d)', re.I)


def _strip_season_ranges(text, seasons=None):
	"""Remove genuine season ranges ("S01-02", "S01-S04") and record them.

	Only spans that validate are removed: the pattern also matches a season marker followed by an episode range
	('S2 - 01~10' looks like s=2..01), and removing that destroyed both."""
	out, last = [], 0
	for m in _EX_SEASON_RANGE.finditer(text):
		try: a, b = int(m.group(1)), int(m.group(2))
		except (TypeError, ValueError): continue
		if not (0 < a < b <= 50): continue   # descending or implausible: not a season range
		if seasons is not None: seasons.update(range(a, b + 1))
		out.append(text[last:m.start()]); out.append(' '); last = m.end()
	out.append(text[last:])
	return ''.join(out)


_EX_NXNN = re.compile(r'(?<![0-9a-z])(\d{1,2})x(\d{2,3})(?![0-9a-z])', re.I)   # LOCAL PATCH 2026-11-04: see _extract_meta

def _extract_meta(cleaned):
	"""Return (seasons:set, episodes:set|None, part_nums:set, is_range:bool).
	episodes is None when no episode number could be pulled — bare batches."""
	seasons = set()
	episodes = set()
	parts = set()
	is_range = False

	# LOCAL PATCH 2026-11-04: 'NxNN' is season N episode NN ('Tokyo.Revengers.-.1x02.-.Resist'), not episode 1. A resolution
	# cannot match: the season is 1-2 digits after a non-digit ('1280x720' has none).
	_nx = _EX_NXNN.search(cleaned)
	if _nx: return {int(_nx.group(1))}, {int(_nx.group(2))}, parts, False

	# --- season ---
	# LOCAL PATCH 2026-08-27: ORDER MATTERS. The '<N>th season' / 'second season' / 'act II' forms are read and REMOVED before
	# the plain 'season <N>' scan, or in '2nd Season 1~13' the 1 opening the EPISODE range is read as a second season
	# ({1,2}, passing a season-1 scrape).
	_season_scan = cleaned
	_season_scan = _strip_season_ranges(_season_scan, seasons)
	for m in _EX_SEASON_ORD.finditer(_season_scan):
		try: seasons.add(int(m.group(1)))
		except: pass
	_season_scan = _EX_SEASON_ORD.sub(' ', _season_scan)
	for m in _EX_SEASON_WORD.finditer(_season_scan):
		w = m.group(1).lower()
		if w in _WORD_MAP: seasons.add(_WORD_MAP[w])
	_season_scan = _EX_SEASON_WORD.sub(' ', _season_scan)
	for m in _EX_SEASON_ACT.finditer(_season_scan):
		r = m.group(1).lower()
		if r in _ROMAN_MAP: seasons.add(_ROMAN_MAP[r])
	_season_scan = _EX_SEASON_ACT.sub(' ', _season_scan)
	for m in _EX_SEASON.finditer(_season_scan):
		try: seasons.add(int(m.group(1)))
		except: pass
	# Fallback: bare ordinal ('4th', '2nd') when nothing above claimed a season.
	if not seasons:
		for m in _EX_SEASON_ORD_BARE.finditer(cleaned):
			try:
				seasons.add(int(m.group(1)))
				break   # first hit only, as with the Roman fallback
			except: pass

	# Fallback: standalone Roman numeral only if we found no other season signal.
	if not seasons:
		_ROMAN_STANDALONE = {'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7, 'viii': 8}
		for m in _EX_SEASON_ROMAN.finditer(cleaned):
			r = m.group(1).lower()
			if r in _ROMAN_STANDALONE:
				seasons.add(_ROMAN_STANDALONE[r])
				break   # only take first hit to avoid double-counting "II" + "III"

	# --- parts ---
	for m in _EX_PART.finditer(cleaned):
		try: parts.add(int(m.group(1)))
		except: pass

	# --- episode ---
	# Remove already-consumed markers so digits inside them don't leak as episodes.
	# LOCAL PATCH 2026-08-27: 'S02E06-08' spans three episodes; _EX_SXX_EYY would consume 's02e06' and orphan '-08'.
	# _PK_RNG_SE (as _pack_shape uses) reads it, and deliberately does NOT match the absolute form 'S03E20.(57)'.
	work = cleaned
	for m in _PK_RNG_SE.finditer(cleaned):
		try: a, b = int(m.group(1)), int(m.group(2))
		except: continue
		if 0 < a < b <= 999:
			episodes.update(range(a, b + 1))
			is_range = True
	if is_range: work = _PK_RNG_SE.sub(' ', work)
	work = _EX_SXX_EYY.sub(lambda m: episodes.add(int(m.group(2))) or ' ', work)
	work = _EX_PART.sub(' ', work)
	# LOCAL PATCH 2026-08-27: season markers go too, or their digits read as episodes ('Season 2 - 11' became range 2-11).
	# _EX_SEASON_ORD goes FIRST, as in the season scan: in '2nd Season 1~13' removing 'Season 1' would swallow the 1 that
	# opens the episode range.
	work = _strip_season_ranges(work)   # valid ranges only; see above
	for _rx in (_EX_SEASON_ORD, _EX_SEASON_WORD, _EX_SEASON,
					 _EX_SEASON_ORD_BARE):
		work = _rx.sub(' ', work)

	# A volume/box span is not an episode span -- see _EX_VOLUME_SPAN.
	work = _EX_VOLUME_SPAN.sub(' ', work)

	# episode range like "01-24" or "01~47"
	rng = _EX_EP_RANGE.search(work)
	if rng:
		try:
			a, b = int(rng.group(1)), int(rng.group(2))
			if 0 < a < b <= 9999:
				episodes.update(range(a, b + 1))
				is_range = True
		except: pass

	if not episodes:
		# "- 12", "-12", " 12 "
		for m in _EX_EP_DASH.finditer(work):
			try: episodes.add(int(m.group(1)))
			except: pass
	# always-good prefix: "E12", "Ep 12", "Episode 12"
	for m in _EX_EP_PREFIX.finditer(work):
		try: episodes.add(int(m.group(1)))
		except: pass

	return seasons, (episodes or None), parts, is_range


# LOCAL PATCH 2026-08-27: nyaa.si host order (DNS sinkhole + SNI reset on this network; nyaa.media ignores AND terms and
# mangles OR, so its batch queries collapse) -- see providers/torrents/nyaa.py, where the host list lives.
# LOCAL PATCH 2026-08-27: anime-aware pack shape test. source_utils.filter_season_pack misreads the absolute convention:
# "Attack.on.Titan.S03E20.(57)" is S3E20 (= episode 57 overall), but after release_title_format it reads "s03e20.57" and
# the helper reports "episodes 20 through 57". Most such "season packs" were single episodes, offered for episodes they
# do not hold, so that range is discarded and recomputed here.
_PK_ABS_EP = re.compile(r's\d{1,3}[._ ]?e\d{1,3}[._ ]*[(\[]\d{1,4}[)\]]', re.I)
_PK_RNG_SE = re.compile(r's\d{1,3}[._ ]?e(\d{1,3})[._ ]*[-~][._ ]*e?(\d{1,3})(?![\dp])', re.I)
# The second number sits in a LOOKAHEAD so a junk match ("Part.2.-.01") does not consume the digits that begin the real
# range ("01.~.10").
_PK_RNG_BARE = re.compile(r'(?<![\d])(\d{1,3})[._ ]*[-~][._ ]*(?=(\d{1,3})(?:[\s.\])]|$))')


def _pk_first_valid(rx, text, min_span=1):
	"""First ascending, plausible pair -- earlier matches are often junk."""
	for m in rx.finditer(text):
		try: a, b = int(m.group(1)), int(m.group(2))
		except Exception: continue
		if 0 < a < b <= 999 and (b - a) >= min_span: return a, b
	return 0, 0


# LOCAL PATCH 2026-10-03: shared by every provider so batches are tagged the same way; groups capture the season span.
# 'Season 1 + 2', 'S01-S02', 'Seasons 1-3'. A bare second number only after 'Seasons' or a '+'/'and': in
# 'Season 2 - 01-12' and 'S2 - 05' it is an episode.
_MULTI_SEASON = re.compile(
	r'\bseasons\s*0*(\d{1,2})\s*(?:-|~|\+|&|and)\s*0*(\d{1,2})\b'
	r'|\bseason\s*0*(\d{1,2})\s*(?:\+|&|and)\s*(?:season\s*)?0*(\d{1,2})\b'
	r'|\b(?:season\s*|s)0*(\d{1,2})\s*(?:-|~|\+|&)\s*(?:season\s*|s)0*(\d{1,2})\b', re.I)

def multi_season_span(name):
	"""(first, last) seasons a multi-season batch names, or None."""
	m = _MULTI_SEASON.search(name.replace('.', ' '))
	if not m: return None
	nums = [int(g) for g in m.groups() if g is not None]
	if len(nums) != 2 or not 0 < nums[0] < nums[1] <= 50: return None
	return nums[0], nums[1]

def batch_fields(name, episodes, is_range, season_length=None):
	"""LOCAL PATCH 2026-10-03: the item keys for a batch, {} for a single episode. Inputs are _extract_meta's (episodes,
	is_range), so no name is read differently. DeadLight divides a pack's size by 'pack_episodes': the name's own range,
	else the release season's length (data['season_length']) for a one-season batch; absent, DeadLight uses TMDb's count.
	A multi-season batch is a 'show' pack carrying its seasons, and its range too when it names one ('Seasons 1-3 (001-075)')."""
	if episodes is not None and not is_range: return {}
	span = multi_season_span(name)
	if span:
		out = {'package': 'show', 'first_season': span[0], 'last_season': span[1]}
		if episodes and is_range: out['pack_episodes'] = len(episodes)
		return out
	if episodes and is_range: return {'package': 'season', 'pack_episodes': len(episodes)}
	out = {'package': 'season'}
	try:
		if season_length and int(season_length) > 0: out['pack_episodes'] = int(season_length)
	except (TypeError, ValueError): pass
	return out

def _pack_shape(name):
	"""(is_pack, episode_start, episode_end). 0/0 means a whole-season pack."""
	if _PK_ABS_EP.search(name): return False, 0, 0        # SxxEyy.(abs) -> one episode
	a, b = _pk_first_valid(_PK_RNG_SE, name)
	if a: return True, a, b                               # SxxE06-08 -> real range
	try:
		seasons, episodes, parts, is_range = _extract_meta(_clean_for_extract(name))
	except Exception:
		return True, 0, 0                                 # unparseable: leave it to the caller
	if episodes is None: return True, 0, 0                # no episode at all -> batch
	if is_range: return True, min(episodes), max(episodes)
	a, b = _pk_first_valid(_PK_RNG_BARE, name, min_span=2)
	if a: return True, a, b                               # "01.~.10" style batch
	return False, 0, 0                                    # a single, specific episode

# A film or OVA is not a TV episode. Requiring the ABSENCE of a season marker too keeps show packs that list extras
# ('(S01-S04+OVA+Movie)'), while 'Bleach the Movie' and '[DBD-Raws] Bleach [OVA][01-02]' are dropped.
# What a genuine batch SAYS about itself. Not "any name without an episode number is a batch": films, specials and
# mangled names (e.g. CJK-stripped '_Sousou.no.Frieren][30][') then answer EVERY episode -- most of a comet kitsu scrape.
_BATCH_EVIDENCE = re.compile(
	r'complete|batch|collection|box\s?set|\bbox\b|all\s?episodes|integrale|integral|'
	r'full\s?series|season|seasons|serie|series|temporada|staffel|saison|stagione|'
	r'\bvol\b|volume|bd\s?box|bdmv|\btv\b', re.I)

_MOVIE_OVA = re.compile(r'\b(?:movies?|gekijou?ban|ova|oad|nc(?:op|ed))\b', re.I)


# LOCAL PATCH 2026-09-22: the episode number written straight after the show's own title, with no delimiter
# ('[ShouryuuReppa] Mushoku Tensei: Jobless Reincarnation 13 1080p'). No syntactic rule can read it -- 'Mob Psycho 100'
# has the same shape -- so the discriminator is POSITION RELATIVE TO THE TITLE: 'Mob Psycho 100' spends its 100 as a
# title word.
# THE FIRST CLEAN TITLE MATCH IS FINAL: candidates are tried LONGEST FIRST, and a shorter one (the alias 'Mob Psycho')
# may not re-read digits the title consumed -- prefix aliases are common (make_alias_dict feeds them all). Final even when
# it is the WHOLE name: a candidate that fills the name matches and answers None, never handing over to a shorter alias.
def _title_anchored_episode(cleaned, titles):
	"""The number written immediately after the show's own title, or None.

	`cleaned` is _clean_for_extract output; `titles` is the show title plus its aliases. Boundaries as _seq_matches: a long
	word in FRONT of the match means another show's longer title, unless _TITLE_EDGE_OK allows it or it is our own word.
	"""
	seq = _title_seq(cleaned)
	cands = sorted((c for c in (_title_seq(t) for t in (titles or []) if t) if c),
				   key=len, reverse=True)
	if not seq or not cands: return None
	cand_words = set(w for c in cands for w in c)
	for cand in cands:
		n = len(cand)
		if n > len(seq): continue
		for i in range(len(seq) - n + 1):
			if seq[i:i + n] != cand: continue
			before = seq[i - 1] if i > 0 else None
			if before is not None and len(before) >= 4:
				if not _TITLE_EDGE_OK.match(before) and before not in cand_words: continue
			nxt = seq[i + n] if i + n < len(seq) else None
			# This title match is FINAL: every path below RETURNS, none falls through to a shorter candidate.
			if not nxt or not nxt.isdigit(): return None
			val = int(nxt)
			# Matches _EX_EP_RANGE's ceiling so the two episode readers agree.
			if not 0 < val <= 9999: return None
			# A bare year is not an episode ('Show Name 2016 [BD]'). Tested on the VALUE, so '02016' cannot walk around it. Known
			# cost: a genuine absolute number in this band is refused (long-runners are far below; the bound cannot be 999 because
			# absolute numbering does pass 1000).
			if 1900 <= val <= 2099: return None
			return val
	return None


# LOCAL PATCH 2026-09-23: the episode a WHOLE-RUN release names, for animetosho's eid check. One AniDB entry covering a
# long-runner (One Piece aid 69) has an eid index AnimeTosho fills with other numberings of the same number (arc-relative
# '- 10', TVDB 'S18E01'); only the number written after the title separates them.
# A marker in front ('ep0001', 'e1179', 'episode 1000', 's01e1179') is folded into a bare number for the unchanged reader.
# Directly in front of the digits, season 1 only ('S18E01' is TVDB's season-relative number and stays unread). A bare 'e'
# needs a digit after and a word boundary before ('e-ac3', the 'e' in 's18e01'). 'SE.001' is left alone (Special Edition).
_EP_MARKER = re.compile(r'\b(?:s0*1\s*e|episode\s*|ep\s*|e)(?=\d)', re.I)


def _normalise_episode_marker(cleaned):
	"""Rewrite an episode marker in front of a number into the bare number, for _title_anchored_episode:
	'one piece ep0001' -> 'one piece  0001', 'one piece s01e1179 ...' -> 'one piece  1179 ...'.
	"""
	if not cleaned: return cleaned
	return _EP_MARKER.sub(' ', cleaned)


def whole_run_episode(name, titles):
	"""The absolute episode a release name states for a whole-run show, or None."""
	if not name or not titles: return None
	return _title_anchored_episode(_normalise_episode_marker(_clean_for_extract(name)), titles)


# LOCAL PATCH 2026-09-23: cour_match's step 0, lifted out so animetosho's PACK paths apply it too: packs skip cour_match,
# which let every Thousand-Year Blood War batch (filed under Bleach's aid) through for a Bleach (2004) request.
# LOCAL PATCH 2026-10-01: a cour's IDENTITY read from its name, for providers that search by title (nyaa). A franchise
# whose later seasons are NAMED defeats the season NUMBER: Ace of the Diamond's TMDb seasons are 'Diamond no Ace',
# '...: Second Season', '... act II', '... act II: Second Season', and 'act II' reads as season 2.
# Each cour title yields MARKERS: a short word + numeral ('act ii' -> 'act2') and an ordinal season ('Second Season' ->
# 'S2'). Against its sibling cours a cour has:
#     foreign  -- markers a sibling has and we do not: a name carrying one is that sibling's
#     require  -- for each sibling whose markers are a strict SUBSET of ours, the name must carry one that tells us apart
# A phrase marker is removed from the name before its season is read, so 'act II' is not 'season 2' any more.
_COUR_ROMAN = {'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7, 'viii': 8, 'ix': 9, 'x': 10}
# In a TITLE the word and its numeral are separate words ('act II'): with the separator optional the pattern split inside
# words ('Honki' -> 'honk i'). A name may still glue them ('actII'); name_cour_check matches those per marker.
_COUR_PHRASE = re.compile(r'(?<![a-z0-9])([a-z]{2,4})[\s._\-]+(viii|vii|iii|ii|iv|vi|ix|x|v|i|\d{1,2})(?![a-z0-9])')
_COUR_PHRASE_SKIP = frozenset(('part', 'pt', 'season', 'cour', 'vol', 'ep', 'eps', 'no', 'the', 'of', 'oad', 'ova', 'ona',
	'sp', 'op', 'ed', 'hd', 'sd', 'bd', 'dvd', 'web', 'ver', 'ch', 'arc', 'vs', 'and', 'to', 'ga', 'wa', 'de', 'ni', 'wo', 'mo',
	'na', 'wi', 'ka', 'ne', 'in', 'on', 'at', 'is', 'it', 'or', 'by', 'top', 'aac', 'flac', 'dts'))
_COUR_ORDINAL = {'first': 1, 'second': 2, 'third': 3, 'fourth': 4, 'fifth': 5, 'sixth': 6, 'seventh': 7, 'eighth': 8, 'ninth': 9, 'tenth': 10}
_COUR_SEASON = re.compile(r'(?<![a-z0-9])(?:(\d{1,2})(?:st|nd|rd|th)|(first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth))'
	r'[\s._\-]*season(?![a-z])|(?<![a-z0-9])season[\s._\-]*(\d{1,2})(?![0-9])')


def title_cour_markers(title):
	t = (title or '').lower()
	marks = set()
	for m in _COUR_PHRASE.finditer(t):
		word, num = m.group(1), m.group(2)
		if word in _COUR_PHRASE_SKIP or not set(word) - set('ivx'): continue   # 'iii ii' is no word
		value = _COUR_ROMAN.get(num) or (int(num) if num.isdigit() else None)
		if value: marks.add('%s%d' % (word, value))
	for m in _COUR_SEASON.finditer(t):
		value = int(m.group(1) or m.group(3) or 0) or _COUR_ORDINAL.get(m.group(2) or '')
		if value and value > 1: marks.add('S%d' % value)
	return marks


def cour_marker_plan(own_title, sibling_titles):
	"""The foreign / require / phrase markers of a cour against its siblings, or None when names cannot tell them
	apart this way (every cour without markers, or all alike)."""
	own = title_cour_markers(own_title)
	foreign, require = set(), []
	for title in sibling_titles or ():
		sib = title_cour_markers(title)
		if sib < own:
			group = sorted(own - sib)
			if group not in require: require.append(group)
		elif sib != own: foreign |= (sib - own)
	if not foreign and not require: return None
	phrases = sorted(m for m in (own | foreign) if not m.startswith('S'))
	return {'own': sorted(own), 'foreign': sorted(foreign), 'require': require, 'phrases': phrases}


def plan_own_season(plan):
	"""LOCAL PATCH 2026-10-16: the season number release names give this cour, when the plan knows it ('S5' for Bungou
	Stray Dogs 5th Season) -- or None. It can differ from Fribb's cour_season, which is TVDB's (TVDB files Bungou's
	Seasons 4 and 5 as its season 3)."""
	own = [m for m in ((plan or {}).get('own') or ()) if re.match(r'S\d+$', str(m))]
	return int(own[0][1:]) if len(own) == 1 else None


def name_cour_check(name, plan, cour_season=None, absolute_episode=None, wanted_episodes=()):
	"""(verdict, name_for_matching): False = another cour's release, True = named as ours (the season NUMBER may then
	be the sub-series' own, so cour_match should trust it), None = the markers say nothing. name_for_matching has the
	plan's phrase markers removed, so 'act II' cannot read as season 2 there either."""
	if not plan or not name: return None, name
	present, stripped = set(), name
	for marker in plan.get('phrases') or ():
		mm = re.match(r'([a-z]+)(\d+)$', marker)
		if not mm: continue
		word, value = mm.group(1), int(mm.group(2))
		forms = sorted([str(value)] + [r for r, v in _COUR_ROMAN.items() if v == value], key=len, reverse=True)
		rx = re.compile(r'(?<![a-z0-9])%s[\s._\-]*(?:%s)(?![a-z0-9])' % (re.escape(word), '|'.join(forms)), re.I)
		if rx.search(stripped):
			present.add(marker)
			stripped = rx.sub(' ', stripped)
	seasons, episodes, parts, is_range = _extract_meta(_clean_for_extract(stripped))
	# the absolute number is unique across the run: '- 85' is Season 2 episode 10 whatever else the name says --
	# unless it IS the cour's own number (Season 1 episode 10 is absolute 10), when it proves nothing
	try:
		if (absolute_episode and episodes and int(absolute_episode) in episodes and not is_range
				and int(absolute_episode) not in set(int(x) for x in wanted_episodes if x is not None)): return True, stripped
	except (TypeError, ValueError): pass
	# a franchise PACK that claims our season among others ('S01-S03') holds ours -- a pack only: a single episode listing
	# both numberings does not.
	# LOCAL PATCH 2026-10-16: by the plan's own season number when it has one -- packs name seasons as releases do, not TVDB.
	pack_season = plan_own_season(plan) or cour_season
	if pack_season and len(seasons) > 1 and int(pack_season) in seasons and (episodes is None or is_range): return True, stripped
	present |= set('S%d' % s for s in seasons)
	if present & set(plan.get('foreign') or ()): return False, stripped
	for group in plan.get('require') or ():
		if not (present & set(group)): return False, stripped
	return (True if plan.get('require') else None), stripped


def names_foreign_cour(name, foreign_tokens):
	"""True when the name carries a distinctive word of ANOTHER cour of this TMDb show."""
	if not foreign_tokens or not name: return False
	_nt = set(w for w in re.findall(r'[a-z0-9]+', name.lower()) if len(w) >= 4)
	return bool(_nt & set(foreign_tokens))


def cour_match(name, cour_season=None, cour_episode=None, absolute_episode=None,
               season_episode=None, cour_part=None, foreign_tokens=None, titles=None,
               trust_id=False, cour_part_count=None):
	"""Does this release name hold the wanted episode of the wanted cour?

	LOCAL PATCH 2026-08-27. Anime uses two numberings for the same episode:
	    [Erai-raws] Sousou no Frieren 2nd Season - 02   cour-relative
	    [ANi] Sousou no Frieren S02 - 30                absolute (from series start)
	`cour_season` is the RELEASE season number (Fribb's season.tvdb), not TMDb's: TMDb files every Re:ZERO cour under S1.

	ORDER MATTERS; both alternatives lose results:
	  1. Absolute number first: unique across the series, it identifies an episode with no season marker
	     ("[SubsPlease] Shingeki no Kyojin - 38" is S3E01).
	  2. Season check next: the cour-relative number is ambiguous, so for cour 2+ a name with no season marker is cour 1,
	     not a wildcard ("[aL] Sousou no Frieren (2023) - 02" must not answer cour 2 episode 2).
	  3. Batches only after the season check, or a Season 1 batch passes for cour 2.
	"""
	# 0. a name carrying another cour's distinctive words IS that cour, whatever numbering it uses (TYBW releases call
	#    themselves S01E01 under Bleach's TMDb show; only the title, e.g. 'Sennen Kessen-hen', separates them).
	if names_foreign_cour(name, foreign_tokens): return False
	_cleaned = _clean_for_extract(name)
	seasons, episodes, parts, is_range = _extract_meta(_cleaned)
	# LOCAL PATCH 2026-09-24: a Part number larger than the season has parts is not a cour part (JoJo's 'Part 6: Stone
	# Ocean' is a story arc). Only when the caller knows the count.
	try:
		if parts and cour_part_count and any(int(p) > int(cour_part_count) for p in parts): parts = set()
	except (TypeError, ValueError): pass
	# LOCAL PATCH 2026-09-22: a bare number after the title (_title_anchored_episode), applied ONLY when nothing else found an
	# episode, so it cannot override a delimited number or change a row that parses today.
	if episodes is None and titles:
		_anchored = _title_anchored_episode(_cleaned, titles)
		if _anchored is not None: episodes = set([_anchored])
	# films / OVAs, unless the name also claims a season (then it is a show pack listing its extras).
	# Underscores are word characters, so \b will not fire against them: 'Gekijouban_Bleach_...' is split first
	if not seasons and _MOVIE_OVA.search((name or '').replace('_', ' ')): return False
	def _int(v):
		try: return int(v)
		except (TypeError, ValueError): return None
	cour_season, cour_episode = _int(cour_season), _int(cour_episode)
	absolute_episode, season_episode = _int(absolute_episode), _int(season_episode)
	# The season-relative number is what release names carry when a season is split across cours (Re:ZERO S2 ep 24 =
	# cour 2, cour_ep 12). For a single-cour season the two are identical, so accepting both is free.
	wanted = set(x for x in (season_episode, cour_episode) if x is not None)

	# 1. unambiguous absolute hit (skipped for cour 1, where the two numbers are
	#    the same and a bare number really is ambiguous)
	if (episodes and absolute_episode is not None
			and absolute_episode not in wanted and absolute_episode in episodes):
		return True

	# 2. the release must belong to our cour
	if cour_season and cour_season > 1:
		# LOCAL PATCH 2026-09-22: reject only a name claiming a LATER season than asked. Franchises with named sub-series are
		# numbered twice: databases count across the franchise, release groups within the sub-series (Ace of the Diamond S04 =
		# 'Act II S2'). Mis-filing -- what this reject exists for -- is sequel content under a PREQUEL's id, so a HIGHER claim
		# (Re:ZERO 'S04E01' under S1's ids); sub-series numbering is LOWER and is trusted to the eid. A name with NO season
		# marker is still refused for cour 2+ (docstring point 2). Known cost: a mis-filed row whose sub-series season EQUALS
		# the requested season passes.
		# LOCAL PATCH 2026-09-22: `trust_id` -- the caller identified the episode by an ID, so a name saying nothing about its
		# season contradicts nothing (a mis-file announces itself with a season). Title-searched providers (nyaa, comet) keep
		# the 'no marker = cour 1' rule. Needed for e.g. JoJo Stone Ocean, whose names carry no Sxx token at all.
		if not seasons:
			if not trust_id: return False
		elif cour_season not in seasons and min(seasons) > cour_season: return False
	elif seasons and min(seasons) > 1:
		# LOCAL PATCH 2026-09-21: some groups number a split season's COURS as seasons (Erai-raws 'Mushoku Tensei ... 2nd Season
		# - 02' is S1 cour 2). The tell: the name's number exceeds the episode's real season and equals the cour part we want.
		# Re:ZERO S2 part 2 is NOT caught (cour_season 2, so min(seasons) > cour_season is false).
		# Recorded as a PART, not waved through, so step 3b below stops treating the cour-relative number as ambiguous.
		if (cour_part and cour_season and min(seasons) == int(cour_part)
			and min(seasons) > cour_season):
			parts = set(parts) | {int(cour_part)}
		else:
			return False   # targeting cour 1, name claims a later season

	# 3. a batch of the right cour: caller picks the file inside it. A Part number is the one thing a batch says about
	#    WHICH episodes it holds, so honour it ('(Season 2 Part 01)' cannot hold a Part 2 episode).
	if parts and cour_part and int(cour_part) not in parts: return False
	# No episode number: only a batch if the name claims to be one (_BATCH_EVIDENCE). `seasons` and `parts` count as a
	# claim, and a season pack was already checked against our cour above.
	if episodes is None:
		return bool(seasons or parts or _BATCH_EVIDENCE.search(name or ''))

	# 3b. a split season makes the cour-relative number ambiguous across parts (AoT S3E20 is part 2 episode 8, but part 1
	#     episode 8 is also 'S3 - 08'). With no part marker the bare number reads as part 1, so only the season-relative
	#     and absolute numbers, which cannot collide between parts, may be used.
	# Skipped for an id-keyed caller (the eid already knows the part): JoJo Stone Ocean part 2 episode 1 is named '- 01'.
	if cour_part and int(cour_part) > 1 and not parts and not trust_id:
		unambiguous = set(x for x in (season_episode, absolute_episode) if x is not None)
		return bool(unambiguous & set(episodes))

	# 4. cour-relative number, now that the cour is established
	return bool(wanted & set(episodes))


def real_imdb(imdb):
	"""LOCAL PATCH 2026-10-06: an IMDb id a Stremio addon can answer ('tt5311514'), not '', None, 'tt' or 'tt0000000'.
	torrentio and comet search an anime film with no such id by its Kitsu id instead."""
	imdb = str(imdb or '').strip().lower()
	return imdb.startswith('tt') and imdb.strip('t0') != ''


def title_guard(name, title, aliases):
	"""Does this release name actually belong to the show we asked for?

	LOCAL PATCH 2026-08-27. The Kitsu paths in torrentio and comet skip the normal title check, but an ID does not scope
	the result: comet's kitsu endpoint leaks unrelated shows ('11.22.63' for Naruto), and the ID itself can be wrong
	(ani.zip maps Fairy Tail to kitsu 1, Cowboy Bebop). These are the right episode number of the wrong show, so only the
	title can catch them. Boundary-aware matcher, not source_utils.check_title (which needs an SxxExx token).
	"""
	cands = [_title_seq(t) for t in ([title] + list(aliases or [])) if t]
	cands = [c for c in cands if c]
	if not cands: return True
	# LOCAL PATCH 2026-11-10: and each title's other spellings in release names: without 'the' / 'a' / 'an' when 2+ words stay
	# ('Ace.of.Diamond.S2' is Ace of the Diamond; log 2026-11-10, torrentio / mediafusion dropped its S2 batches), and its
	# words run together ('MARRIAGETOXIN.S01E01', 'ReZero'), 6+ letters: a whole name word must equal it, never a part of one.
	for c in list(cands):
		bare = [w for w in c if w not in _TITLE_ARTICLES]
		if 2 <= len(bare) < len(c) and bare not in cands: cands.append(bare)
		joined = ''.join(c)
		if len(c) >= 2 and len(joined) >= 6 and [joined] not in cands: cands.append([joined])
	return _seq_matches(_title_seq(name), cands)

_TITLE_ARTICLES = frozenset(('the', 'a', 'an'))


def alias_titles(data):
	"""Show title + alias strings from a DeadLight data dict, for title_guard."""
	out = []
	for alias in (data.get('aliases') or []):
		if isinstance(alias, dict):
			if alias.get('title'): out.append(alias['title'])
		elif alias: out.append(str(alias))
	# LOCAL PATCH 2026-09-24: '<show> <TMDb season name>' when DeadLight passes it: groups write it between title and number
	# ('Jojo's Bizarre Adventure Stone Ocean 25'), and _title_anchored_episode reads only right after a candidate. A generic
	# 'Season 2' name is skipped.
	_st, _show = data.get('season_title'), data.get('tvshowtitle')
	if _st and _show and not re.match(r'^\s*season\s*\d+\s*$', str(_st), re.I):
		out.append('%s %s' % (_show, _st))
	return out


# ---------------------------------------------------------------------------------------------
# PACK NAMES
#
# LOCAL PATCH 2026-09-24: moved here from providers/torrents/animetosho.py so every anime name reader lives in this one
# module. The functions take the names a row carries (title, then torrent_name), which animetosho passes in.
# ---------------------------------------------------------------------------------------------

# LOCAL PATCH 2026-09-22: a pack naming itself a numbered SUBDIVISION -- Box 05, Vol 09, Set 1, Part 2, Disc 3 -- holds
# some slice of the run without saying which episodes (see _pack_excludes_episode). Season markers count too ('Naruto
# (2002) - S05' cannot serve episode 220); safe because the file-count test uses min(wanted), so a cour's own season pack
# is never touched.
# LOCAL PATCH 2026-09-22: a pack naming a SIBLING SERIES alongside this one ('Naruto + Naruto Shippuden') holds two
# episode 220s -- a deliberate policy reject, not a mis-filing guard. The words below legitimately follow a '+' without
# naming another series; the list is never complete, so the length floor carries the real weight.
_SIBLING_EXTRAS = frozenset((
	'movie', 'movies', 'film', 'films', 'ova', 'ovas', 'oad', 'oads', 'special',
	'specials', 'extra', 'extras', 'opening', 'openings', 'ending', 'endings',
	'batch', 'complete', 'collection', 'season', 'seasons', 'remux', 'bluray',
	'dual', 'audio', 'project', 'subtitle', 'subtitles', 'uncensored',
))
# Seven, measured: at five, 'season' and 'break' (Re:ZERO Break Time) false-rejected; 'shippuden' still fires. It misses
# short names (Dragon Ball KAI) -- the right direction to fail: a miss keeps today's behaviour.

# LOCAL PATCH 2026-09-23: a MOVIE-numbered range is not an episode range. AnimeTosho files a franchise's films under the
# series aid ('Naruto Shippuden - The Movie 1-8'), and _extract_meta reads '1-8' as episodes.
_SEASON_RANGE = re.compile(r'\b(?:seasons?|s)[^a-z0-9]{0,3}\d{1,2}\s*[-~]\s*\d{1,2}', re.I)

_MOVIE_RANGE = re.compile(
	r'\b(?:movies?|films?|gekijou?ban)\b[^a-z0-9]{0,4}(\d{1,2})\s*[-~]\s*(\d{1,2})', re.I)

# LOCAL PATCH 2026-09-23: a bare episode range wrapped in brackets ('(1086-1155)', '[0207-0336]'), which _extract_meta
# does not read, so such a pack declared nothing and was kept for any episode.
# LOCAL PATCH 2026-09-23 (b): 'to'/'thru' as separator too ('(1001 to 1085)'), only inside brackets, where the whole
# bracket IS the range. An unbracketed compound ('1061, 1062 & 1070 to 1076') stays unread: its range is not its set.
# Unwrapped for _pack_excludes_episode ONLY: teaching _extract_meta a new form would change cour_match for every
# id-keyed provider.
# LOCAL PATCH 2026-09-24: the range may be followed by EXTRAS in the same bracket ('(0001-1071+Movies+Specials)'); extras
# are never more TV episodes. Only a WORD may follow the + or &: '(1070 to 1076 & 1080)' stays unread.
_BRACKETED_RANGE = re.compile(
	r'[\(\[]\s*(\d{1,4})\s*(?:[-~]|[\s._]+(?:to|thru)[\s._]+)\s*(\d{1,4})\s*(?:[\)\]]|(?=[+&]\s*[a-z]))', re.I)


def _unwrap_bracketed_range(name):
	"""'(1086-1155)' -> ' 1086-1155 ', which _extract_meta then reads. Unchanged if none.

	A YEAR span is left wrapped ('(TV; Seasons 1 through 4; 1999-2002)' does hold episode 1): both endpoints plausible
	years and a reach of 30 or less."""
	def _sub(m):
		try: lo, hi = int(m.group(1)), int(m.group(2))
		except (TypeError, ValueError): return m.group(0)
		if 1900 <= lo <= 2099 and 1900 <= hi <= 2099 and 0 <= hi - lo <= 30: return m.group(0)
		return ' %d-%d ' % (lo, hi)
	try: return _BRACKETED_RANGE.sub(_sub, name)
	except Exception: return name


def pack_declares_season_only(names):
	"""True when the names state a SEASON and no episode range at all.

	'Naruto Shippuden Season 3' never says which episodes, so _pack_excludes_episode keeps it (an unreadable name
	contradicts nothing) and a season 17 pack is offered for episode 1. The season number is NOT compared: it is TVDB's,
	not TMDb's. This only reports the shape; DeadLight decides, and only for a pack it cannot verify against a file listing.
	A name stating a range is never flagged ('One Piece (001-746)(Seasons.01-17)').
	"""
	if not (_extract_meta and _clean_for_extract): return False
	names = [n for n in (names or ()) if n]
	if not names: return False
	names = names + [u for u in (_unwrap_bracketed_range(n) for n in names) if u not in names]
	# A SEASON RANGE is a collection: _extract_meta reports 'Season 1-18' as seasons=[1]. The dash must follow the digits
	# directly, so 'Season 17 (Dress Rosa) - Vol.15-22' is not caught.
	if any(_SEASON_RANGE.search(n) for n in names): return False
	seen_season = False
	for name in names:
		try:
			seasons, episodes, _parts, is_range = _extract_meta(_clean_for_extract(name))
		except Exception:
			continue
		if is_range and episodes: return False
		if seasons: seen_season = True
	return seen_season
_SIBLING_MIN_LEN = 7
_SIBLING_JOIN = re.compile(r'[+&]')
_SIBLING_BRACKETS = re.compile(r'\[[^\]]*\]|\([^)]*\)|\{[^}]*\}')

# LOCAL PATCH 2026-09-24: three digits, not two ('[uP] One Piece - Vol.003'), as _SINGLE_VOLUME reads.
_SUBDIVISION = re.compile(r'(?:^|[^a-z0-9])(?:box|vol|volume|set|part|pt|disc|disk|s|season)[^a-z0-9]{0,2}\d{1,3}(?:[^a-z0-9]|$)', re.I)

# LOCAL PATCH 2026-09-24: a pack of FILMS that states no range ('Naruto.Shippuden.-.Movies.[BD-Remux]', 'Bleach -
# Movies'); the listing check cannot drop it (no episode found reads as an unreadable convention), so the name settles it.
# Left alone: a name that also says EPISODES ('[ Episodes + Movies + OVAs ]') or names films as an ADDITION ('+ Movies',
# 'S1+S2+OVAs+Movies'). A films-only pack names them as its SUBJECT: 'Bleach - Movies'.
_MOVIE_WORD = re.compile(r'\b(?:movies?|films?|gekijou?ban)\b', re.I)
_MOVIE_ADDITION = re.compile(r'(?:[+&]|\band\b|\bwith\b)[^a-z0-9]{0,3}(?:the[^a-z0-9]+)?(?:movies?|films?|gekijou?ban)\b', re.I)
_EPISODE_WORD = re.compile(r'\b(?:episodes?|eps?|tv|series|complete|collection|batch|seasons?|integrale|s\d{1,2})\b', re.I)

# LOCAL PATCH 2026-09-22: a pack labelled volume N>1 does not start at episode 1 (the file-count fallback can only say a
# pack cannot REACH an episode). Two guards, from Naruto:
#   - a SPAN is excluded by the lookahead ('Vol.05~12' is eight volumes);
#   - a pack bigger than _MAX_VOLUME_FILES is a box, not a volume ('[uP] Set.5', 130 files).
_SINGLE_VOLUME = re.compile(r'\b(?:vol|volume|box|disc|disk|set)[^a-z0-9]{0,2}(\d{1,3})(?![^a-z0-9]{0,2}[-~]\s*\d)', re.I)
_MAX_VOLUME_FILES = 15


def pack_excludes_episode(names, num_files, wanted):
	"""True only when the names state a range and the wanted episode is outside it."""
	if not (_extract_meta and _clean_for_extract): return False
	# LOCAL PATCH 2026-09-22: read BOTH name fields, not `torrent_name or title`: either may be the informative one (a range
	# in the title only, or an EMPTY torrent_name), so neither can be preferred outright.
	names = [n for n in (names or ()) if n]
	if not names: return False
	# LOCAL PATCH 2026-09-23: add an unwrapped variant of any name carrying a bracketed range. ADDED, never substituted, so
	# nothing that already parsed can parse differently.
	names = names + [u for u in (_unwrap_bracketed_range(n) for n in names) if u not in names]
	# LOCAL PATCH 2026-09-23: a film collection cannot hold a TV episode -- only when the movie range is the ONLY range
	# ('Collection 1-750 + ... + Movies 1-12' is an episode pack). The movie range is stripped and the name re-read.
	if any(_MOVIE_RANGE.search(n) for n in names):
		_leftover = False
		for _n in names:
			try:
				_s, _e, _p, _r = _extract_meta(_clean_for_extract(_MOVIE_RANGE.sub(' ', _n)))
			except Exception:
				continue
			if _r and _e:
				_leftover = True
				break
		if not _leftover: return True
	declared = set()
	for name in names:
		try:
			_seasons, episodes, _parts, is_range = _extract_meta(_clean_for_extract(name))
		except Exception:
			continue
		if is_range and episodes: declared.update(episodes)
	# Any name that states a range is evidence; the union is what the pack can hold.
	if declared:
		return not (wanted & declared)
	# LOCAL PATCH 2026-09-24: films only, no range -- see _MOVIE_WORD. 'Gekijouban_Bleach' is split before \b can see it.
	_flat = [n.replace('_', ' ') for n in names]
	if (any(_MOVIE_WORD.search(_MOVIE_ADDITION.sub(' ', n)) for n in _flat)
			and not any(_EPISODE_WORD.search(n) for n in _flat)):
		return True
	# A single numbered volume cannot hold an episode inside volume 1's span. Only the LOW end is tested: volume sizes vary
	# between groups, so an upper bound from one pack's file count would false-reject.
	for name in names:
		m = _SINGLE_VOLUME.search(name)
		if not m: continue
		try:
			volume = int(m.group(1)); files = int(num_files or 1)
		except (TypeError, ValueError):
			continue
		if volume >= 2 and 1 <= files <= _MAX_VOLUME_FILES and max(wanted) <= files:
			return True

	# No range declared: a numbered subdivision is unverifiable, so use the file count -- fewer than N files cannot reach
	# episode N even numbered from 1 (Box 05 with 27 files cannot serve 212).
	# Against the SMALLEST candidate numbering on purpose: a cour pack holds 12 files while the absolute number is 212, so
	# this only fires for long single-entry shows (Naruto). Accepted cost: Box 8 does hold 212 and is rejected with Box 1,
	# because the name never says; complete-series packs declare 001-220 and still answer.
	if any(_SUBDIVISION.search(n) for n in names):
		try: files = int(num_files or 1)
		except (TypeError, ValueError): return False
		return files < min(wanted)
	return False


def pack_names_sibling_series(names, titles):
	"""The distinguishing word when a '+' segment names another series, else None."""
	if not titles: return None
	# LOCAL PATCH 2026-09-22: both names, as _pack_excludes_episode -- torrent_name is empty or abbreviated on some rows.
	name = ' | '.join(n for n in (names or ()) if n)
	# Bracketed groups carry release tags and fansub names, never a second series.
	body = _SIBLING_BRACKETS.sub(' ', name)
	segments = _SIBLING_JOIN.split(body)
	if len(segments) < 2: return None
	known = set()
	for title in titles:
		known.update(w for w in re.split(r'[^a-z0-9]+', title.lower()) if w)
	for segment in segments[1:]:
		for word in re.split(r'[^a-z0-9]+', segment.lower()):
			if len(word) < _SIBLING_MIN_LEN: continue
			if word in known or word in _SIBLING_EXTRAS: continue
			return word
	return None


# LOCAL PATCH 2026-10-05: stricter anime checks for torrentio and comet. Both answer with the FILE they picked inside each
# torrent (comet as its name; torrentio as title line 2 and behaviorHints.filename), so that file is judged. comet's
# Kitsu endpoint (answers by title) returned image / .zip / .exe collections, subtitle packs, OST rips, scans, BD menus.
_STREMIO_NOT_VIDEO = re.compile(r'\.(?:zip|rar|7z|exe|bat|lnk|flac|mp3|m4a|wav|ogg|png|jpe?g|webp|gif|pdf|cbz|cbr|epub|txt|nfo|'
	r'srt|ass|ssa|sup|cue|log)\s*$', re.I)
_STREMIO_NOT_EPISODE = re.compile(r'(?<![a-z0-9])(?:soundtracks?|osts?|scans?|scanlated|artbooks?|art[\s._-]?book|ai[\s._-]?generated|'
	r'wallpapers?|manga|light[\s._-]?novel|novel|pages|bd[\s._-]?menus?|drama[\s._-]?cd|character[\s._-]?songs?|cue|\d{2,3}[\s._-]?khz|'
	r'subs?[\s._-]?only)(?![a-z0-9])', re.I)
# ' + OVA + Soundtracks + Extras', '.+.NC.OP.&.NC.ED.+.OST': extras bundled with the episodes, not what the torrent is. A '+' with
# no space or dot around it is not a bundle: '[FLAC+CUE+SCANS]' is a music rip.
_STREMIO_BUNDLED = re.compile(r'[\s._][+&][\s._][^+&()\[\]]*$')


def stremio_junk(file_name, titles=()):
	"""Why this file is no episode at all ('.zip', 'soundtrack' ...), or None. A word the show's own title carries is not
	held against it (a show named '... Manga ...')."""
	if not file_name: return None
	m = _STREMIO_NOT_VIDEO.search(file_name)
	if m: return 'not a video (%s)' % m.group(0).strip()
	own = set()
	for t in titles or ():
		if t: own.update(re.findall(r'[a-z0-9]+', str(t).lower()))
	for m in _STREMIO_NOT_EPISODE.finditer(file_name):
		if set(re.findall(r'[a-z0-9]+', m.group(0).lower())) <= own: continue
		if _STREMIO_BUNDLED.search(file_name[:m.start()]): continue
		return 'not an episode (%s)' % m.group(0)
	return None


# LOCAL PATCH 2026-10-06: three kinds of anime row that are no episode of the show, applied to every anime provider
# (scrapers/external.py, cached rows included):
#   a RE-EDIT -- 'Chainsaw.Man.-.The.Compilation.-.01', its 'Part.01' packs, recaps, digests, 総集編;
#   an EXTRA -- 'Creditless.OP.&.ED', NCOP / NCED (bundled ones, '+ NCOP', stay: _STREMIO_BUNDLED);
#   a MANGA volume -- 'vol N' and no sign of video at all (Blu-ray volumes always carry one).
# A word the show's own title carries is not held against it (a show called '... Digest').
_REEDIT = re.compile(r'(?<![a-z0-9])(?:compilation|recaps?|digest|soushuuhen)(?![a-z0-9])|総集編', re.I)
_EXTRA = re.compile(r'(?<![a-z0-9])(?:creditless|nc[\s._-]?(?:op|ed)s?|ncop\d*|nced\d*)(?![a-z0-9])', re.I)
# LOCAL PATCH 2026-10-08: COMMENTARY -- someone talking about the show ('One.Punch.Man.Season.1.Review...'). A '#tag' is a
# social-media clip.
_COMMENTARY = re.compile(r'(?<![a-z0-9])(?:reviews?|reactions?|reacts?|reacting|explained|analysis|breakdown)(?![a-z0-9])|#[a-z]{3,}', re.I)
_VOLUME = re.compile(r'(?<![a-z0-9])vol(?:ume)?[\s._-]?\d', re.I)
_VIDEO_SIGN = re.compile(r'(?<![a-z0-9])(?:\d{3,4}[pi]|\d{3,4}x\d{3,4}|4k|uhd|bd|bdrip|bdremux|blu[\s._-]?ray|web(?:[\s._-]?(?:dl|rip))?|'
	r'hdtv|dvd(?:rip)?|x26[45]|h[\s._]?26[45]|hevc|avc|av1|xvid|divx|hi10p?|10[\s._-]?bit|remux|flac|aac|ac3|e?ac3|dts|opus|'
	r'mkv|mp4|avi|m2ts|ts)(?![a-z0-9])', re.I)


def anime_not_episode(name, titles=()):
	"""Why this anime row is no episode of the show (a re-edit, an extra, a manga volume), or None."""
	if not name: return None
	own = set()
	for t in titles or ():
		if t: own.update(re.findall(r'[a-z0-9]+', str(t).lower()))
	for rx, why in ((_REEDIT, 're-edit'), (_EXTRA, 'extra'), (_COMMENTARY, 'commentary')):
		for m in rx.finditer(name):
			if set(re.findall(r'[a-z0-9]+', m.group(0).lower())) <= own and own: continue
			if why == 'extra' and _STREMIO_BUNDLED.search(name[:m.start()]): continue
			return '%s (%s)' % (why, m.group(0))
	if _VOLUME.search(name) and not _VIDEO_SIGN.search(name): return 'manga volume'
	return None


# Chinese names count episodes as 第13集 / 第13话 / 第13話, which _extract_meta does not read; such single episodes named
# 'S01' read as season packs. A range (第01-04集) does not match and is left to cour_match.
_CJK_EPISODE = re.compile(r'第\s*(\d{1,4})\s*[集话話]')


def cjk_episode(name):
	"""The single episode a 第N集 marker names, or None."""
	m = _CJK_EPISODE.search(name or '')
	return int(m.group(1)) if m else None


def own_cour_words(name, own_tokens):
	"""True when the name carries a word only this cour's titles have (DeadLight's own_cour_tokens)."""
	if not own_tokens or not name: return False
	return bool(set(re.findall(r'[a-z0-9]+', name.lower())) & set(own_tokens))


def other_show_year(name, data):
	"""The year a name writes RIGHT AFTER the show's title when it is not the show's own (+-1), else None.

	LOCAL PATCH 2026-10-05: a remake or live-action series shares the title and says which by its year ('ONE.PIECE.2023.S01'
	under the 1999 anime). Only the TMDb show title is used: the longer aliases carry season names and years.
	Many groups write the SEASON's year ('Vinland Saga (2023) (Season 2)'), so the year is held against the claimed season's
	air year (DeadLight's season_years) or the show's own (Sonarr: 'Attack on Titan (2013) - S03E13'). A name claiming no
	season may carry any season's year, but no other. +-1 throughout (a cour across New Year, a BD date)."""
	try: year = int(str(data.get('year') or '')[:4])
	except (TypeError, ValueError): return None
	own = _title_seq(data.get('tvshowtitle') or '')
	if not own: return None
	seq = _title_seq(name)
	for i in range(len(seq) - len(own)):
		if seq[i:i + len(own)] != own: continue
		nxt = seq[i + len(own)]
		if not (len(nxt) == 4 and nxt.isdigit() and 1900 <= int(nxt) <= 2099): return None
		named = int(nxt)
		years = {}
		for k, v in (data.get('season_years') or {}).items():
			try: years[int(k)] = int(v)
			except (TypeError, ValueError): continue
		seasons = _extract_meta(_clean_for_extract(name))[0]
		if seasons and years:
			known = [years[s] for s in seasons if s in years]
			# that season's year, or the show's own: Sonarr names write 'Attack on Titan (2013) - S03E13'
			if known: return None if any(abs(named - y) <= 1 for y in known + [year]) else named
		allowed = set(years.values()) | {year}
		return None if any(abs(named - y) <= 1 for y in allowed) else named
	return None


def own_season_year(name, data):
	"""LOCAL PATCH 2026-11-10: True when the year written right after the title is the wanted season's and no earlier season's
	(nor the show's own year), +-1 -- the same Crunchyroll naming other_season_year reads, here as THIS season's marker:
	'Dorohedoro.(2026).-.01' is S2E01 (S1 2020, S2 2026). Log 2026-11-09: meteor dropped 4 such rows as first-cour numbering."""
	try: season = int(data.get('season') or 0)
	except (TypeError, ValueError): return False
	years = {}
	for k, v in (data.get('season_years') or {}).items():
		try: years[int(k)] = int(str(v)[:4])
		except (TypeError, ValueError): continue
	if season < 2 or season not in years: return False
	own = _title_seq(data.get('tvshowtitle') or '')
	if not own: return False
	seq = _title_seq(name)
	for i in range(len(seq) - len(own)):
		if seq[i:i + len(own)] != own: continue
		nxt = seq[i + len(own)]
		if not (len(nxt) == 4 and nxt.isdigit()): return False
		named = int(nxt)
		if abs(named - years[season]) > 1: return False
		earlier = [y for s, y in years.items() if 0 < s < season]
		try: earlier.append(int(str(data.get('year') or '')[:4]))
		except (TypeError, ValueError): pass
		return not any(abs(named - y) <= 1 for y in earlier)
	return False

def other_season_year(name, data):
	"""The OTHER TMDb season a name's year points at, when the name claims no season itself, else None.

	LOCAL PATCH 2026-10-08: Crunchyroll names a new season by its year alone ('One.Punch.Man.(2025).-.01' is S3E01), which
	other_show_year lets through. The year is held against ours: the wanted season's, the show's, the episode's own air
	year -- +-1 each; a year only another season has means that season."""
	try:
		year, season = int(str(data.get('year') or '')[:4]), int(data.get('season') or 0)
	except (TypeError, ValueError): return None
	years = {}
	for k, v in (data.get('season_years') or {}).items():
		try: years[int(k)] = int(v)
		except (TypeError, ValueError): continue
	if season < 1 or season not in years or len(years) < 2: return None
	own = _title_seq(data.get('tvshowtitle') or '')
	if not own: return None
	seq = _title_seq(name)
	for i in range(len(seq) - len(own)):
		if seq[i:i + len(own)] != own: continue
		nxt = seq[i + len(own)]
		if not (len(nxt) == 4 and nxt.isdigit() and 1900 <= int(nxt) <= 2099): return None
		named = int(nxt)
		if _extract_meta(_clean_for_extract(name))[0]: return None   # it claims a season: other_show_year's job
		ours = {years[season], year}
		try: ours.add(int(str(data.get('episode_year') or '')[:4]))
		except (TypeError, ValueError): pass
		if any(abs(named - y) <= 1 for y in ours): return None
		other = [s for s, y in sorted(years.items()) if s != season and abs(named - y) <= 1]
		return other[0] if other else None
	return None


# LOCAL PATCH 2026-10-08: a row that is the show's specials and nothing else, for a regular-season scrape -- each holds a
# 'Special 01' the pack file picker would take for episode 1. A '+' / '&' / 'and' before the word bundles the specials
# with the series ('Season.1.+.Specials', '[1-12+Specials]') and stays, as do two seasons before it ('[S1.S2.OVA&ODA]');
# ONE ('[S1].[Ova.720p]') is that season's specials. 'Special Edition' / 'Special Edited Version' is the episodes.
_SPECIALS = re.compile(r"(?<![a-z0-9])(?:specials?(?![\s._-]*edit(?:ion|ed)?)(?![\s._-]*version)|ova'?s?|oads?|oavs?)(?![a-z0-9])", re.I)
_SPECIALS_BUNDLED = re.compile(r'[+&]|(?<![a-z0-9])and(?![a-z0-9])', re.I)
_SPECIALS_SEASON = re.compile(r'(?<![a-z0-9])(?:s\d{1,2}|season[\s._-]?\d{1,2})(?![a-z0-9])', re.I)


def specials_only(name, titles=()):
	"""The specials word ('OVA', 'Specials') when the row is the show's specials and nothing else, or None. A word the
	show's own titles carry is not held against it."""
	if not name: return None
	own = set()
	for t in titles or ():
		if t: own.update(re.findall(r'[a-z0-9]+', str(t).lower()))
	for m in _SPECIALS.finditer(name):
		if own and set(re.findall(r'[a-z0-9]+', m.group(0).lower())) <= own: continue
		before = name[:m.start()]
		if _SPECIALS_BUNDLED.search(before) or len(_SPECIALS_SEASON.findall(before)) >= 2: return None
		return m.group(0)
	return None


def foreign_cour_marked(name, data):
	"""True when the name carries a marker of ANOTHER cour of this show (cour_plan foreign: 'act II' under Ace of the
	Diamond S2). LOCAL PATCH 2026-10-05, for the providers that otherwise read only season numbers."""
	plan = data.get('cour_plan')
	if not plan or not plan.get('foreign') or not name: return False
	# a franchise pack whose season RANGE holds ours names the others too ('Attack on Titan Season 1-4 S01-S04' for S3)
	span, cs = multi_season_span(name), _wanted_release_season(data)
	if span and cs and span[0] <= cs <= span[1]: return False
	return name_cour_check(name, dict(plan, require=[]), _wanted_release_season(data), data.get('absolute_episode'),
		(data.get('season_episode'), data.get('cour_episode')))[0] is False


def _wanted_release_season(data):
	"""The release season wanted: Fribb's cour_season, or TMDb's for the new-season ids (see comet_kitsu_reject)."""
	def _int(v):
		try: return int(v)
		except (TypeError, ValueError): return None
	cs, ce, ab, s = _int(data.get('cour_season')), _int(data.get('cour_episode')), _int(data.get('absolute_episode')), _int(data.get('season'))
	if cs is None and ce is not None and ab is not None and ce != ab and s and s > 1: cs = s
	return cs


def later_season_reject(names, data):
	"""Why a row whose name claims a LATER season than the one asked for is not ours, or None.

	LOCAL PATCH 2026-10-05: torrentio's Kitsu answers are scoped to the entry, but its file matching is not proof (Mushoku
	Tensei II's 'Episode 23' offered for S1E23). `names` is the file first, then the torrent: the first that states a
	season decides. A LOWER claim is not refused (sub-series, cour_match step 2), nor a name with no season.
	One later claim is ours: a split season's second cour shipped as '2nd Season' (cour_match step 2) -- then the number is
	the cour's own, so it must be cour_episode."""
	cs = _wanted_release_season(data)
	if not cs: return None
	for name in names or ():
		if not name: continue
		seasons, episodes, _parts, is_range = _extract_meta(_clean_for_extract(name))
		if not seasons: continue
		if min(seasons) <= cs: return None
		try: part, ce = int(data.get('cour_part') or 0), int(data.get('cour_episode') or 0)
		except (TypeError, ValueError): part, ce = 0, 0
		if part > 1 and min(seasons) == part and episodes and ce in episodes and not is_range: return None
		# LOCAL PATCH 2026-11-07: the same '2nd Season' part shipped as a RANGE in the season's own numbering ('Bungou Stray Dogs
		# 2nd Season - 13 ~ 24'). Only a range that starts where this cour starts in the season and holds the episode.
		try: sep = int(data.get('season_episode') or 0)
		except (TypeError, ValueError): sep = 0
		if (part > 1 and min(seasons) == part and is_range and episodes and sep and ce
				and min(episodes) == sep - ce + 1 and sep in episodes): return None
		if _card_pair(seasons, episodes, data): return None
		return 'season %s, wanted %d' % (','.join(str(s) for s in sorted(seasons)), cs)
	return None


def _card_pair(seasons, episodes, data):
	"""LOCAL PATCH 2026-11-06: the season a name states (and its episode, when it states one) is one of the card's own
	numberings (data['episode_candidates'], DeadLight's episode_card). A flat TMDb season can be counted differently by the
	releases than TVDB's cour_season (Bungou Stray Dogs: one TMDb season; 'S05E01' is the card's (5, 1) for TMDb E50)."""
	try: tmdb_pair = (int(data.get('season')), int(data.get('episode')))
	except (TypeError, ValueError): tmdb_pair = None
	for pair in data.get('episode_candidates') or ():
		try: s, e = int(pair[0]), int(pair[1])
		except (TypeError, ValueError, IndexError): continue
		# a name stating a season only (a pack) is not matched by TMDb's own pair: on a flat TMDb season that is every season
		if not episodes and (s, e) == tmdb_pair: continue
		if s in seasons and (not episodes or e in episodes): return True
	return False


def comet_kitsu_reject(name, data, titles=None):
	"""Why comet's Kitsu-mode row `name` is not the wanted episode, or None to keep it.

	comet's kitsu:<id>:<ep> is not scoped to the entry: it answers with every release of the FRANCHISE whose name carries
	episode <ep>. So comet is judged like nyaa: the cour's markers (cour_plan, name_cour_check) first, then cour_match --
	without its trust in a LOWER season claim (that is for eid-found rows). A lower claim passes only when the name also
	carries this cour's own words (own_cour_tokens): 'Bleach Thousand-Year Blood War S01E01' yes, 'Bleach S01E01 2004' no.

	The season wanted is Fribb's cour_season, or -- for _new_season_ids' ids, which leave it unset -- TMDb's season (that
	entry STARTS this TMDb season). The whole-run path also leaves it unset but asks with the absolute number
	(cour_episode == absolute_episode), which tells it apart."""
	def _int(v):
		try: return int(v)
		except (TypeError, ValueError): return None
	cs, ce = _wanted_release_season(data), _int(data.get('cour_episode'))
	ab, se = _int(data.get('absolute_episode')), _int(data.get('season_episode'))
	later = later_season_reject([name], data)
	if later: return later
	wanted = set(x for x in (ce, se, ab) if x is not None)
	ep = cjk_episode(name)
	if ep is not None and ep not in wanted: return 'names episode %d' % ep
	plan = data.get('cour_plan')
	# LOCAL PATCH 2026-10-05: a marker of ANOTHER cour refuses first, whatever season the name states ('act II' reads as
	# season 2), ahead of the shortcut below
	if foreign_cour_marked(name, data): return 'another cour (markers)'
	named, cm_name = name_cour_check(name, plan, cs, ab, (se, ce))
	seasons = _extract_meta(_clean_for_extract(cm_name))[0]
	# LOCAL PATCH 2026-10-16: when the plan names this cour's season otherwise (plan_own_season), TVDB's number counts only
	# with the episode beside it ('Bungo.Stray.Dogs.S03E24' is Season 5 episode 11; a bare 'S03' is the 2019 Season 3)
	_own = plan_own_season(plan)
	_eps = _extract_meta(_clean_for_extract(cm_name))[1] if (_own and cs and _own != cs) else None
	if cs and cs in seasons and (not _own or _own == cs or (_eps and wanted & set(_eps))):
		# the name states our season outright: 'Ace of the Diamond S04E10' against a plan built from 'act II Second Season',
		# which REQUIRES those markers -- only a missing required marker is overridden, never a foreign one (above)
		named = True
	else:
		if named is False: return 'another cour (markers)'
		if not named and own_cour_words(name, data.get('own_cour_tokens')): named = True
		if cs and cs > 1 and not named:
			seasons, episodes = _extract_meta(_clean_for_extract(cm_name))[:2]
			if seasons and max(seasons) < cs and not (ab is not None and episodes and ab in episodes and ab not in (ce, se)):
				return 'season %s, wanted %d' % (','.join(str(s) for s in sorted(seasons)), cs)
	if not cour_match(cm_name, cs, ce, ab, se, data.get('cour_part'), data.get('foreign_cour_tokens'), titles=titles,
			trust_id=bool(named), cour_part_count=data.get('cour_part_count')):
		return 'cour_match'
	return None
