# -*- coding: utf-8 -*-
from threading import Thread
from urllib.parse import urlencode
from caches.settings_cache import get_setting, set_setting
from caches.main_cache import cache_object, main_cache
from modules.source_utils import supported_video_extensions, extras, pick_episode_file, split_disc, resolve_reporter
from modules.kodi_utils import make_session, kodi_dialog, ok_dialog, notification, confirm_dialog

session = make_session('https://api.torbox.app/v1/api/')

# LOCAL PATCH 2026-10-25 (4.0.5): why the last call gave no JSON, for debrid.TB_check's outage notice. In an outage
# api.torbox.app answers 307 -> status.torbox.app (not JSON), which otherwise looks like nothing cached.
# Module-level: TB_check makes a TorBoxAPI per batch.
LAST_ERROR = {'reason': ''}

def _note_failure(response):
	try:
		from urllib.parse import urlsplit
		host = urlsplit(response.url).netloc
		if response.history and host != 'api.torbox.app': reason = 'redirected to %s%s' % (host, urlsplit(response.url).path)
		else: reason = 'HTTP %s, not JSON' % response.status_code
	except Exception: reason = 'not JSON'
	LAST_ERROR['reason'] = reason

# LOCAL PATCH 2026-10-25 (4.0.6): TorBox stalling. When every call hangs to its 20 s read timeout, each source tried
# waits its own 20 s. Requests with no answer are counted in a window property (shared by every Kodi process), any
# answer clears it; after _STALL_LIMIT in a row, resolve_magnet gives up at once for _STALL_WINDOW seconds from the
# last one. The cache check is left alone: it already gives up.
_STALL_PROP = 'deadlight.tb_stalls'   # '<count> <time of the last>'
_STALL_LIMIT, _STALL_WINDOW = 2, 90

def _stalls():
	try:
		from modules.kodi_utils import get_property
		count, last = (get_property(_STALL_PROP) or '0 0').split()
		return int(count), float(last)
	except Exception: return 0, 0.0

def _note_stall(error):
	try:
		import time
		from modules.kodi_utils import set_property
		set_property(_STALL_PROP, '%d %.0f' % (_stalls()[0] + 1, time.time()))
		LAST_ERROR['reason'] = type(error).__name__
	except Exception: pass

def _note_answer():
	try:
		if _stalls()[0]:
			from modules.kodi_utils import clear_property
			clear_property(_STALL_PROP)
	except Exception: pass

def not_answering():
	"""(count, seconds since the last) while TorBox counts as stalled, else None."""
	import time
	count, last = _stalls()
	since = time.time() - last
	return (count, since) if count >= _STALL_LIMIT and since < _STALL_WINDOW else None

def _request(method, url, **kwargs):
	import requests
	try: response = method(url, **kwargs)
	except requests.exceptions.RequestException as e:
		_note_stall(e)
		raise
	_note_answer()
	return response

class TorBoxAPI:
	def __init__(self):
		self.token = get_setting('deadlight.tb.token')

	def _get(self, url, data={}):
		if self.token in ('empty_setting', ''): return None
		headers = {'Authorization': 'Bearer %s' % self.token}
		url = 'https://api.torbox.app/v1/api/' + url
		response = _request(session.get, url, params=data, headers=headers, timeout=20)
		try: return response.json()
		except ValueError:
			_note_failure(response)
			return None

	def _post(self, url, params=None, json=None, data=None):
		if self.token in ('empty_setting', '') and not 'token' in url: return None
		headers = {'Authorization': 'Bearer %s' % self.token}
		url = 'https://api.torbox.app/v1/api/' + url
		response = _request(session.post, url, params=params, json=json, data=data, headers=headers, timeout=20)
		try: return response.json()
		except ValueError:
			_note_failure(response)
			return None

	def add_headers_to_url(self, url):
		return url + '|' + urlencode({'User-Agent': 'Mozilla/5.0'})

	def account_info(self):
		return self._get('user/me')

	def user_cloud(self):
		string = 'tb_user_cloud'
		url = 'torrents/mylist'
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_usenet(self):
		string = 'tb_user_cloud_usenet'
		url = 'usenet/mylist'
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_info(self, request_id=''):
		string = 'tb_user_cloud_%s' % request_id
		url = 'torrents/mylist?id=%s' % request_id
		return cache_object(self._get, string, url, False, 0.03)

	def user_cloud_info_usenet(self, request_id=''):
		string = 'tb_user_cloud_usenet_%s' % request_id
		url = 'usenet/mylist?id=%s' % request_id
		return cache_object(self._get, string, url, False, 0.03)


	def torrent_info(self, request_id=''):
		url = 'torrents/mylist?id=%s' % request_id
		return self._get(url)

	def delete_torrent(self, request_id=''):
		# LOCAL PATCH 2026-08-31: the id must go out as an INTEGER; from the context menu (plugin url) it is a string and
		# TorBox silently ignores the delete.
		try: request_id = int(request_id)
		except (TypeError, ValueError): pass
		data = {'torrent_id': request_id, 'operation': 'delete'}
		return self._post('torrents/controltorrent', json=data)

	def delete_usenet(self, request_id=''):
		# LOCAL PATCH 2026-08-31: the id must go out as an INTEGER (see delete_torrent).
		try: request_id = int(request_id)
		except (TypeError, ValueError): pass
		data = {'usenet_id': request_id, 'operation': 'delete'}
		return self._post('usenet/controlusenetdownload', json=data)

	def unrestrict_link(self, file_id):
		torrent_id, file_id = file_id.split(',')
		data = {'token': self.token, 'torrent_id': torrent_id, 'file_id': file_id}
		# LOCAL PATCH 2026-10-25 (4.0.5): keep TorBox's own reason for a refused link (resolve_magnet._why reports it).
		try: result = self._get('torrents/requestdl', data=data)
		except Exception as e: result = {'error': type(e).__name__}   # the type only: the request URL carries the token
		try: link = result['data']
		except: link = None
		if not link:
			try: self.last_dl_error = result.get('detail') or result.get('error')
			except: self.last_dl_error = 'no response' if result is None else 'unreadable response'
		return link

	def unrestrict_usenet(self, file_id):
		usenet_id, file_id = file_id.split(',')
		params = {'token': self.token, 'usenet_id': usenet_id, 'file_id': file_id, 'user_ip': True}
		try: return self._get('usenet/requestdl', data=params)['data']
		except: return None

	def add_magnet(self, magnet):
		data = {'magnet': magnet, 'seed': 3, 'allow_zip': False}
		return self._post('torrents/createtorrent', data=data)

	def check_cache(self, hashlist):
		# LOCAL PATCH 2026-09-22: list_files=true adds a `files` array (id, name, short_name, real size) to every CACHED
		# entry; without it the size is only the torrent total. Costs payload, not measurable time. Uncached hashes are
		# absent from the response either way.
		data = {'hashes': hashlist}
		return self._post('torrents/checkcached', params={'format': 'list', 'list_files': 'true'}, json=data)

	def create_transfer(self, magnet_url):
		result = self.add_magnet(magnet_url)
		if not result or not result.get('success'): return ''
		return result['data'].get('torrent_id', '')

	# LOCAL PATCH 2026-08-27: ep_candidates carries the alternate numberings an anime release may use for this episode
	# (source_utils.anime_episode_candidates); empty/None for everything else.
	def resolve_magnet(self, magnet_url, info_hash, store_to_cloud, title, season, episode, ep_candidates=None, ep_name=None):
		# LOCAL PATCH 2026-10-15: say why a resolve gave up, as Real-Debrid's does.
		_why = resolve_reporter('TorBox', info_hash, season, episode, title)
		stalled = not_answering()   # LOCAL PATCH 2026-10-25 (4.0.6): see _STALL_PROP
		if stalled:
			_why('not answering (%d requests in a row timed out, the last %d s ago) -- skipped' % (stalled[0], stalled[1]))
			return None
		try:
			file_url, torrent_id = None, None
			extensions = supported_video_extensions()
			extras_filter = extras()
			extras_filtering_list = tuple(i for i in extras_filter if not i in title.lower())
			import time as _time
			_t = [_time.time()]   # LOCAL PATCH 2026-10-31: the three calls timed, logged with the link (see below)
			torrent = self.add_magnet(magnet_url)
			_t.append(_time.time())
			# LOCAL PATCH 2026-10-25 (4.0.6): no JSON answer is None -- it read as "'NoneType' object is not subscriptable"
			if not torrent:
				_why('no answer when adding the torrent (%s)' % (LAST_ERROR.get('reason') or 'empty'))
				return None
			if not torrent['success']:
				_why('add failed: %s' % (torrent.get('error') or torrent.get('detail')))
				return None
			torrent_id = torrent['data']['torrent_id']
			torrent_files = self.torrent_info(torrent_id)
			# LOCAL PATCH 2026-11-08: straight after createtorrent TorBox can answer 'No torrents found for this user.' --
			# the list is not always readable yet. Ask again, 2 more times, 0.7 s apart.
			for _retry in range(2):
				if not torrent_files or torrent_files.get('data'): break   # no answer = timeout: do not wait again
				_time.sleep(0.7)
				torrent_files = self.torrent_info(torrent_id)
			_t.append(_time.time())
			if not torrent_files or not torrent_files.get('data'):
				if torrent_files: _why('no file list: %s' % (torrent_files.get('detail') or torrent_files.get('error') or 'empty answer'))
				else: _why('no answer for the file list (%s)' % (LAST_ERROR.get('reason') or 'empty'))
				Thread(target=self.delete_torrent, args=(torrent_id,)).start()   # in the background: TorBox may be stalling
				return None
			files = torrent_files['data']['files']
			selected_files = [{'url': '%d,%d' % (torrent_id, item['id']), 'filename': item['short_name'], 'size': item['size']} \
							for item in files if item['short_name'].lower().endswith(tuple(extensions))]
			if not selected_files:
				_why('no video files among %d' % len(files))
				return None
			if season:
				# LOCAL PATCH 2026-11-04: the one shared pick (source_utils.pick_episode_file: largest non-extra hit)
				_pick = pick_episode_file(selected_files, season, episode, 'filename', ep_candidates, title, ep_name)
				selected_files = [_pick] if _pick else []
			else:
				if self._m2ts_check(selected_files):
					_why('disc release split over streams')
					return None
				selected_files = [i for i in selected_files if not any(x in i['filename'] for x in extras_filtering_list)]
				selected_files.sort(key=lambda k: k['size'], reverse=True)
			if not selected_files:
				_why('no file for this episode' if season else 'only extras left')
				return None
			file_key = selected_files[0]['url']
			self.last_dl_error = None
			file_url = self.unrestrict_link(file_key)
			try:
				from modules.kodi_utils import logger
				logger('TorBox resolve timing', 'add %.2f s, file list %.2f s, link %.2f s' % (_t[1] - _t[0], _t[2] - _t[1], _time.time() - _t[2]))
			except Exception: pass
			if not store_to_cloud: Thread(target=self.delete_torrent, args=(torrent_id,)).start()
			# LOCAL PATCH 2026-10-25 (4.0.5): a refused requestdl was the one exit that left no reason.
			if not file_url: _why('no download link for %s: %s' % (selected_files[0]['filename'], self.last_dl_error or 'empty answer'))
			return file_url
		except Exception as e:
			_why('failed: %r' % e)
			# LOCAL PATCH 2026-10-25 (4.0.6): in the background -- after a timeout the delete waited its own 20 s
			if torrent_id: Thread(target=self.delete_torrent, args=(torrent_id,)).start()
			return None

	def display_magnet_pack(self, magnet_url, info_hash, keep=False):
		# LOCAL PATCH 2026-11-07: keep=True for Download Pack: a TorBox file link ('torrent_id,file_id') is requested later
		# (requestdl), so deleting the torrent after listing its files makes every download fail.
		from modules.source_utils import supported_video_extensions
		try:
			torrent_id = None
			extensions = supported_video_extensions()
			torrent = self.add_magnet(magnet_url)
			if not torrent['success']: return None
			torrent_id = torrent['data']['torrent_id']
			torrent_files = self.torrent_info(torrent_id)
			files = torrent_files['data']['files']
			torrent_files = [{'link': '%d,%d' % (torrent_id, item['id']), 'filename': item['short_name'], 'size': item['size']} \
							for item in files if item['short_name'].lower().endswith(tuple(extensions))]
			if not keep: Thread(target=self.delete_torrent, args=(torrent_id,)).start()
			return torrent_files or None
		except Exception:
			if torrent_id: self.delete_torrent(torrent_id)
			return None

	def _m2ts_check(self, folder_items):
		# LOCAL PATCH 2026-09-29: refuse only a disc whose film may be split over streams (source_utils.split_disc)
		return split_disc([(item['filename'], item['size']) for item in folder_items])

	def auth(self):
		# LOCAL PATCH 2026-09-30: a QR code of TorBox's settings page, where the API key is, before the keyboard
		from modules.kodi_utils import qr_dialog
		if not qr_dialog('TorBox Authorize', 'https://torbox.app/settings',
			'Scan the [B]QR code[/B] or open [B]torbox.app/settings[/B] and copy your [B]API Key[/B].[CR]'
			'Press [B]Back[/B], then enter it.'): return
		api_key = kodi_dialog().input('TorBox API Key:')
		if not api_key: return
		try:
			self.token = api_key
			r = self.account_info()
			r['data']['customer']   # an answer without an account raises here (the except reports the failure)
			set_setting('tb.token', api_key)
			set_setting('tb.enabled', 'true')
			message = 'Success'
		except: message = 'An Error Occurred'
		ok_dialog(text=message)

	def revoke(self):
		if not confirm_dialog(): return
		set_setting('tb.token', 'empty_setting')
		set_setting('tb.enabled', 'false')
		notification('TorBox Authorization Reset', 3000)

	def refresh_cloud(self):
		"""Repoint the local cache at TorBox's CURRENT list after a delete.

		LOCAL PATCH 2026-08-31: TWO caches sit between a delete and the listing -- this
		addon's maincache row (108s) and TorBox's own server-side list cache. Clearing only
		the first still refetches a possibly stale list, so items you just deleted kept
		showing for up to two minutes. Verified after a bulk delete: the local row still
		held all 8 entries and simply aged out rather than being replaced.

		bypass_cache=true asks TorBox for the real list rather than its cached one. Writing
		the answer straight into the cache leaves the listing correct on the very next draw
		instead of merely empty until the next fetch.
		"""
		self.clear_cache(clear_hashes=False)
		ok = True
		for key, url in (('tb_user_cloud', 'torrents/mylist?bypass_cache=true'),
						('tb_user_cloud_usenet', 'usenet/mylist?bypass_cache=true')):
			try: main_cache.set(key, self._get(url), expiration=0.03)
			except Exception: ok = False
		return ok

	def clear_cache(self, clear_hashes=True):
		from caches.debrid_cache import clear_account_cache   # LOCAL PATCH 2026-11-01 (cleanup): shared body
		return clear_account_cache('tb', ('tb_user_cloud%',), clear_hashes)

TorBox = TorBoxAPI()

