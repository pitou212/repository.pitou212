# -*- coding: utf-8 -*-
"""Skip Segment overlay: small button shown during intro/credits/recap allowing manual skip."""
import threading, time
import xbmc
from windows.base_window import BaseDialog


class SkipSegment(BaseDialog):
	WIDTH = 260   # the button's width in skip_segment.xml

	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.label = kwargs.get('label', 'Skip')
		self.corner = kwargs.get('corner', 'bottom-right')
		self.user_clicked = False
		self.closed_externally = False
		self.setProperty('label', self.label)
		self.setProperty('corner', self.corner)
		# LOCAL PATCH 2026-11-08: round 5 -- the time left and a fill that runs down (skip_segment.xml images 30 / 31);
		# end_time is the segment's end in player seconds (modules/player._spawn_skip_window)
		self.end_time = kwargs.get('end_time')
		self.closed = False
		self.fill_width = None

	def onInit(self):
		if self.end_time: threading.Thread(target=self.count_down, daemon=True).start()

	def count_down(self):
		player = xbmc.Player()
		try: start = player.getTime()
		except Exception: return
		span = max(1.0, float(self.end_time) - start)
		while not self.closed:
			try: left = max(0.0, float(self.end_time) - player.getTime())
			except Exception: break
			self.setProperty('left', '%d:%02d left' % divmod(int(left + 0.5), 60))
			width = int(self.WIDTH * left / span)
			if width != self.fill_width:
				self.fill_width = width
				for control_id in (30, 31):
					try:
						control = self.getControl(control_id)
						control.setVisible(width >= 20)   # a 10 px-corner image needs 20 px
						if width >= 20: control.setWidth(width)
					except Exception: pass
			time.sleep(0.25)

	def onClick(self, controlID):
		if controlID == 10:
			self.user_clicked = True
			self.closed = True
			self.close()

	def onAction(self, action):
		if action in self.closing_actions:
			self.closed = True
			self.close()

	def request_close(self):
		"""Called from outside (player monitor) when segment ends or playback stops."""
		self.closed_externally = True
		self.closed = True
		try: self.close()
		except: pass

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.user_clicked
