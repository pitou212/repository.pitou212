# LOCAL PATCH 2026-11-01 (cleanup): emptied -- the __all__ built here was read only by ../__init__.py (emptied too); magneto.sources() loads the providers.
