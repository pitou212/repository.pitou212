# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-23: MDBList cache module ported from POV's mdbl_cache.py.
# Mirrors caches/trakt_cache.py 1:1 in shape — same table layout (mdbl_data KV
# blob + watched + progress + watched_status), same set_bulk_* signatures so
# watched_status.py dispatch can call either interchangeably based on
# watched_indicators setting (1=Trakt, 2=MDBList).
import time
from threading import Thread
from caches.base_cache import connect_database, ProviderCache
from modules.kodi_utils import confirm_dialog


# LOCAL PATCH 2026-10-19: the class body lives in base_cache.ProviderCache (shared with Trakt / SIMKL; adds allow_empty).
class MDBLCache(ProviderCache):
	def __init__(self): ProviderCache.__init__(self, 'mdblist_db', 'mdbl_data')


mdbl_cache = MDBLCache()


def cache_mdbl_object(function, string, url, max_age_hours=None):
	# LOCAL PATCH 2026-10-03 (3.0.8): max_age_hours for rows no activity stamp covers -- the contents of a list someone
	# ELSE owns (a liked list) change without this account's list_updated_at moving, so they were never re-read. The
	# write time sits in a sibling row, so rows written before this patch count as expired once and gain one.
	stamp_key = '%s_ts' % string
	cache = mdbl_cache.get(string)
	if cache is not None:
		if not max_age_hours: return cache
		try:
			if time.time() - float(mdbl_cache.get(stamp_key) or 0) < max_age_hours * 3600: return cache
		except (TypeError, ValueError): pass
	result = function(url)
	if result is not None and max_age_hours: mdbl_cache.set(stamp_key, int(time.time()))
	# LOCAL PATCH 2026-09-15: only a real result is stored. A None here means the fetch
	# FAILED (call_mdblist returns None on 429 / timeout / HTTP error); caching it is a
	# pointless write (the same rule apis/tvdb_api._cached_lookup follows). Rows in
	# mdbl_data carry no expiry, so anything stored here lives until the sync sees
	# list_updated_at move or the cache is cleared outright.
	if result is not None: mdbl_cache.set(string, result)
	return result


# ═══════════════════════════════════════════════════════════════════════════
#  Activity pivot — the master sync in mdblist_api reads/writes this record.
# ═══════════════════════════════════════════════════════════════════════════

def get_activity():
	"""LOCAL PATCH 2026-10-03 (3.0.8): the stored activity snapshot, read-only (None when there is none)."""
	try: return mdbl_cache.get('mdbl_get_activity')
	except Exception: return None


def reset_activity(latest_activities):
	return mdbl_cache.reset_activity('mdbl_get_activity', latest_activities, default_activities)


# ═══════════════════════════════════════════════════════════════════════════
#  Cache invalidation — each write op or sync activity change calls these.
# ═══════════════════════════════════════════════════════════════════════════

# LOCAL PATCH 2026-11-01 (cleanup): one-liners over ProviderCache.delete / delete_like (same row patterns as before)
def clear_mdbl_list_data(list_type):
	# list_type = 'collection' | 'watchlist' | 'my_lists' | 'external' | 'hidden_items_dropped'
	mdbl_cache.delete('mdbl_%s' % list_type)


clear_mdbl_collection_watchlist_data = clear_mdbl_list_data


def clear_mdbl_list_contents_data(list_type):
	mdbl_cache.delete_like('mdbl_list_contents_' + list_type + '_%')


def clear_all_mdbl_cache_data(silent=False, refresh=True):
	try:
		start = silent or confirm_dialog()
		if not start: return False
		dbcon = connect_database('mdblist_db')
		# LOCAL PATCH 2026-09-24: carry queued progress saves across the wipe -- they exist
		# nowhere else (see mdblist_api._PENDING_KEY).
		pending = dbcon.execute('SELECT data FROM mdbl_data WHERE id = ?', ('mdbl_pending_progress',)).fetchone()
		for table in ('progress', 'watched', 'watched_status'):
			dbcon.execute('DELETE FROM %s' % table)
		dbcon.execute('DELETE FROM mdbl_data')
		if pending: dbcon.execute('INSERT OR REPLACE INTO mdbl_data (id, data) VALUES (?, ?)', ('mdbl_pending_progress', pending[0]))
		dbcon.execute('VACUUM')
		# LOCAL PATCH 2026-10-03 (Batch 3): the calendar is cached in maincache, not here, and survived the wipe
		try:
			from caches.main_cache import main_cache
			main_cache.delete_like('mdbl_get_my_calendar_%')
		except Exception: pass
		if refresh:
			from apis.mdblist_api import mdbl_sync_activities
			Thread(target=mdbl_sync_activities).start()
		return True
	except: return False


def default_activities():
	# MDBList's sync/last_activities response shape. Any field the server may
	# emit is present here at epoch so first-time diffs always trigger a rebuild.
	return {
		'collected_at':       '2020-01-01T00:00:01.000Z',
		'watchlisted_at':     '2020-01-01T00:00:01.000Z',
		'dropped_at':         '2020-01-01T00:00:01.000Z',
		'list_updated_at':    '2020-01-01T00:00:01.000Z',
		'watched_at':         '2020-01-01T00:00:01.000Z',
		'episode_watched_at': '2020-01-01T00:00:01.000Z',
		'paused_at':          '2020-01-01T00:00:01.000Z',
		'episode_paused_at':  '2020-01-01T00:00:01.000Z',
	}
