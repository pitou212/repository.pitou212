# created by kodifitzwell for Fenomscrapers
"""
	Fenomscrapers Project
"""

from json import loads as jsloads
import time
from threading import Thread
from magneto.modules import client
from magneto.modules.control import setting as getSetting
from magneto.modules import anime_utils
from magneto.modules.provider_base import StremioSource, tag_batch


# LOCAL PATCH 2026-11-01 (cleanup): the sources / sources_packs bodies are provider_base.StremioSource's; this file keeps what
# is comet's own -- its addresses, the Kitsu paths and the Kitsu + IMDb pair of requests, and its anime checks.
class source(StremioSource):
	provider = 'comet'
	_GRACE = 1.5   # LOCAL PATCH 2026-10-07: see the Kitsu + IMDb request in _fetch()
	# LOCAL PATCH 2026-08-27: Kitsu endpoint for anime. Comet answers the TMDb
	# coordinate poorly because nobody names anime that way -- measured on Frieren
	# S1E30 (cour 2 episode 2): imdb tt22248376:1:30 returned 2 streams, while
	# kitsu:49240:2 returned 556.
	tvSearch_link_kitsu = '/stream/series/kitsu:%s:%s.json'

	def __init__(self):
		self.base_link = (
			"https://comet.stremio.ru",
			"https://comet.feels.legal",
			"https://cometfortheweebs.midnightignite.me"
		)[int(getSetting('comet.url', '0'))]

	def _query(self, data):
		q = super()._query(data)
		q['kitsu_mode'] = q['kitsu_film'] = False   # LOCAL PATCH 2026-10-06, kitsu_film set below for a film with no IMDb id
		return q

	def _search_url(self, data, q):
		if q['tv']:
			# DeadLight fills these in for anime only (scrapers/external.py), from the
			# Fribb cour mapping; anime_utils.comet_kitsu_reject reads the rest of them.
			q['kitsu_id'], q['cour_episode'] = data.get('kitsu_id'), data.get('cour_episode')
			q['kitsu_mode'] = bool(q['kitsu_id']) and q['cour_episode'] is not None
			if q['kitsu_mode']: return '%s%s' % (self.base_link, self.tvSearch_link_kitsu % (q['kitsu_id'], q['cour_episode']))
			return super()._search_url(data, q)
		# LOCAL PATCH 2026-10-06: an anime film with no IMDb id is asked for by its Kitsu id (kitsu:937 On Your Mark --
		# 10 rows, none before); judged by the title only below. With an IMDb id the query is unchanged.
		q['kitsu_film'] = bool(data.get('kitsu_id')) and not anime_utils.real_imdb(q['imdb'])
		return '%s%s' % (self.base_link, self.movieSearch_link % ('kitsu:%s' % data['kitsu_id'] if q['kitsu_film'] else q['imdb']))

	def _imdb_url(self, data, q):
		"""The IMDb request asked beside the Kitsu one (anime with a release season), or None."""
		if q['kitsu_mode'] and anime_utils.real_imdb(q['imdb']) and data.get('cour_season') is not None:
			return '%s%s' % (self.base_link, self.tvSearch_link % (q['imdb'], data['cour_season'], data.get('season_episode') or q.get('cour_episode')))
		return None

	# LOCAL PATCH 2026-11-06: comet searches upstream the first time it is asked for an episode and answers late -- Frieren S2E3
	# Kitsu 15.1 s, Rakudai Kenja E9 IMDb 10.9 s, Dandadan S2E5 Kitsu 5.1 s, then 0.3 s each asked again. It finishes a search the
	# client gave up on (8 episodes abandoned at 1 s answered in 0.2-0.3 s 20 s later), and the scrape cannot wait for it: _fetch
	# drops a side still running 1.5 s after the other answered (cold Frieren S2E3 would lose Kitsu's 549 rows) and waits up to
	# 11 s when both are cold. So the episode-list prewarm (modules/scrape_prewarm) asks the scrape's own two URLs here, briefly,
	# and lets comet finish on its side. Returns how many were asked.
	def warm(self, data, timeout=2):
		q = self._query(data)
		urls = [u for u in (self._search_url(data, q), self._imdb_url(data, q)) if u]
		def _ask(u):
			try: client.request(u, timeout=timeout)
			except Exception: pass
		threads = [Thread(target=_ask, args=(u,), daemon=True) for u in urls]
		for t in threads: t.start()
		for t in threads: t.join(timeout + 1)
		return len(urls)

	def _fetch(self, url, data, q):
		# LOCAL PATCH 2026-10-06: on anime ask by Kitsu AND by IMDb at the release season, at the same time (a Stremio
		# request takes one id). comet's Kitsu index lags new seasons -- kitsu:49752:1 (Blue Box Season 2) and
		# kitsu:51005:1 (Reborn as a Space Mercenary) gave 0 streams while tt32639706:2:1 gave 25 and tt41298100:1:1
		# gave 2. The answers are merged by hash and every row is judged like a Kitsu row below (title_guard +
		# comet_kitsu_reject). One side failing leaves the other; both failing is the old failure.
		imdb, kitsu_id, cour_episode = q['imdb'], q.get('kitsu_id'), q.get('cour_episode')
		imdb_ep = data.get('season_episode') or cour_episode
		imdb_url = self._imdb_url(data, q)
		if not imdb_url:
			files = super()._fetch(url, data, q)
			for _f in files or []:
				if isinstance(_f, dict): _f['_found_by'] = 'franchise_id' if q.get('kitsu_mode') else 'series_id'
			return files
		answers, took = {}, {}
		def _fetch(key, u):
			_t0 = time.time()
			try: answers[key] = jsloads(client.request(u, timeout=self.timeout))['streams']
			except Exception: pass
			took[key] = time.time() - _t0
		# Once one side has rows the other gets _GRACE more seconds, not the full timeout: an EMPTY Kitsu answer
		# takes 4.7-5.2 s (live 2026-10-07: kitsu:49752:1, kitsu:51005:1 -- comet searches upstream and finds
		# nothing) while the IMDb side had its rows in 0.5-0.7 s; a Kitsu answer WITH rows took 0.6-1.3 s.
		_threads = [Thread(target=client.counted(_fetch), args=(k, u), daemon=True) for k, u in (('kitsu', url), ('imdb', imdb_url))]
		for _t in _threads: _t.start()
		_deadline, _grace_end = time.time() + self.timeout + 1, None
		while any(_t.is_alive() for _t in _threads) and time.time() < _deadline:
			if _grace_end is None and any(list(answers.values())): _grace_end = time.time() + self._GRACE
			if _grace_end and time.time() >= _grace_end: break
			time.sleep(0.05)
		got = dict(answers)   # a side still running past the grace is left out (snapshot: a late thread still writes to answers)
		if not got: raise Exception('comet: kitsu and imdb requests both failed')
		files, seen = [], set()
		# LOCAL PATCH 2026-11-07 (anime core plan phase 2c): how each row was found, for the release judge's profiles -- in the IMDb
		# answer (series + episode asked; also when Kitsu had it too): 'series_id'; in the Kitsu answer only (kitsu:<id>:<ep> spans
		# the franchise): 'franchise_id'. Read back by _keep_file_name onto the row.
		imdb_hashes = set((_f.get('infoHash') or '').lower() for _f in (got.get('imdb') or []) if isinstance(_f, dict))
		for _f in (got.get('kitsu') or []) + (got.get('imdb') or []):
			_h = (_f.get('infoHash') or '').lower()
			if _h in seen: continue
			seen.add(_h)
			if isinstance(_f, dict): _f['_found_by'] = 'series_id' if _h in imdb_hashes else 'franchise_id'
			files.append(_f)
		try:
			import xbmc as _x
			_x.log('COMET: kitsu:%s:%s %s (%.1f s) + %s:%s:%s %s (%.1f s) -> %d unique' % (kitsu_id, cour_episode,
				len(got['kitsu']) if 'kitsu' in got else ('FAILED' if 'kitsu' in took else 'LATE'), took.get('kitsu', 0), imdb,
				data['cour_season'], imdb_ep, len(got['imdb']) if 'imdb' in got else ('FAILED' if 'imdb' in took else 'LATE'),
				took.get('imdb', 0), len(files)), _x.LOGINFO)
		except Exception: pass
		return files

	# LOCAL PATCH 2026-11-04 (release judge, phase 4b): an anime TV row is judged by modules/release_judge after the cache, like
	# every provider's -- comet's own checks for it (title_guard + comet_kitsu_reject on the Kitsu path, check_title on the IMDb
	# path, stremio_junk / other_show_year / cjk_episode; later_season_reject / foreign_cour_marked / other_show_year on packs)
	# are the judge's now. Measured live over 12 hard episodes before removing them (addon_patches/harness/provider_gap_check.py):
	# old comet vs new comet, both through the judge: +15 rows, -0. The 15 are RIGHT episodes comet's IMDb-path check_title refused
	# for carrying no SxxEyy -- 'Naruto.212.mkv', 'One.Piece.1100.(WEB.1080p)', 'Steins;Gate_0_01', 'Stone.Ocean.25',
	# 'Bakemonogatari.Ep9-13' -- which now list. Comet's former rules are the judge's for COMET's rows only (release_judge._TAKEN_OVER).
	# Not for a film (the judge does not run on films) or a show that is not anime: unchanged below.

	def _episode_ok(self, file, lines, name, data, q):
		if q['tv'] and data.get('is_anime'): return True
		title = q['title']
		if q['kitsu_film']:
			if not anime_utils.title_guard(name, title, anime_utils.alias_titles(data)): return False
		elif not self._check_title(name, q): return False
		# on an anime FILM, drop archives, art, music and scans (anime_utils.stremio_junk) and another show's year
		if data.get('is_anime'):
			if anime_utils.stremio_junk(name, [title] + anime_utils.alias_titles(data)): return False
			if anime_utils.other_show_year(name, data): return False
		return True

	def _pack_ok(self, file, lines, name, package, data):
		return True   # packs are TV only; an anime pack is the judge's (above), any other was never checked here

	def _keep_file_name(self, item, file, lines):
		# LOCAL PATCH 2026-11-07 (phase 2c): and how the row was found (_fetch)
		super()._keep_file_name(item, file, lines)
		try:
			if file.get('_found_by'): item['found_by'] = file['_found_by']
		except Exception: pass

	def sources_packs(self, data, hostDict, *args, **kwargs):
		# LOCAL PATCH 2026-11-07 (phase 2c): a PACK keeps comet's own rules ('franchise_id') whichever answer carried it. Comet's IMDb
		# answer picks the file for a single row, but its packs are whole seasons it never looked into: as 'series_id' the judge
		# kept Re:ZERO 'S02 Part2' / '2nd Season Part 2 - 01 ~ 12' for S1E27 (part 1), Bungou '[TV][1-2 сезон][2016]' for E25 and
		# 'Fate.Stay.night.Unlimited.Blade.Works.S01-02' for the 2006 series (old vs new, 24 cases), which comet's pack rules drop.
		rows = super().sources_packs(data, hostDict, *args, **kwargs)
		for row in rows or []: row.pop('found_by', None)
		return rows

	def _tag(self, item, name, data, q):
		# LOCAL PATCH 2026-10-03: a kitsu-mode batch is tagged as one; true_size because comet's size is the episode file's
		# (live: always equal to behaviorHints.videoSize), so DeadLight must not divide it. Pack rows carry true_size too
		# (pack_true_size): live 2026-10-03, 'Reacher.S02E01...mkv' 17 GB inside a 113 GB torrent.
		if q['kitsu_mode']: tag_batch(item, name, data, true_size=True)
		# 2026-11-07 (phase 2c): a single tagged as a batch just above is judged as comet's pack (see sources_packs)
		if item.get('package'): item.pop('found_by', None)
