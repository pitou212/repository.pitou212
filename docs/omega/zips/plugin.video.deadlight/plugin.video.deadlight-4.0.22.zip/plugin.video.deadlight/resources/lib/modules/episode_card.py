# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-11-04: the anime EPISODE CARD -- every id and numbering of one episode, worked out in one place.

	WHY
	The ids an anime scrape runs on (AniDB aid / eid, AniList, Kitsu, MAL, the cour / season / absolute numbers and the
	episode candidates) were built inline in scrapers/external.py's results(), ~600 lines grown fix by fix: Fribb's cour,
	re-placed by air dates (Tokyo Revengers, Re:ZERO), repaired past an entry's end (Blue Box), ani.zip's whole-run entry
	(Naruto), a new season by air date (Black Clover S2), AniDB by MAL id (Steel Ball Run), specials (Steins;Gate 0). Each
	step writes self.data as it goes, so the ORDER of the steps is spread over the method and no single place says what
	an episode IS. This module is that place: resolve() runs the same steps in one pipeline and returns an EpisodeCard.

	PHASE 1 (2026-11-04, shadow): built beside the inline code and compared field by field -- 17 hard cases and the first
	real scrapes matched. PHASE 2 (2026-11-04, now): external.results() calls resolve() and copies card.fields into
	self.data; the inline steps are gone. The whole data dict of 28 hard cases was byte-identical before and after
	(addon_patches/harness/scrape_data_snapshot.py), save the specials' absolute_episode fix below.

	NOT HERE: the reject words (foreign_cour_tokens, own_cour_tokens, cour_plan) -- they judge RELEASES, not the episode,
	and are built in external.py from card.cour / card.title_key; the pack file pick (modules/pack_pick.py).
"""
from modules import kodi_utils, source_utils

# self.data fields the card owns -- compared in shadow mode, copied from the card in phase 2
ID_FIELDS = ('mal_id', 'kitsu_id', 'anilist_id', 'anidb_aid', 'anidb_eid', 'anidb_part_aids')
NUMBER_FIELDS = ('absolute_episode', 'cour_episode', 'cour_season', 'season_episode', 'season_length', 'cour_part',
				'cour_part_count', 'whole_run', 'episode_candidates')
TITLE_FIELDS = ('season_title', 'mal_title')
CARD_FIELDS = ID_FIELDS + NUMBER_FIELDS + TITLE_FIELDS


class EpisodeCard(object):
	"""One episode: TMDb's pair, every other numbering, every id, and which path found them (`source`) with the notes
	each step left (`trail`). Plain attributes; `fields` holds the self.data-named values."""
	__slots__ = ('tmdb', 'special', 'source', 'fields', 'trail', 'cour', 'title_key', 'stremio_se', 'judge_inputs')

	def __init__(self, tmdb, special):
		self.tmdb, self.special, self.source, self.fields, self.trail = tmdb, special, 'none', {}, []
		# cour: the Fribb cour dict the ids came from (None off the Fribb path); title_key: (id field, id) the cour's titles
		# are keyed by -- id None when the episode is past the entry (no cour title then)
		self.cour, self.title_key = None, None
		# LOCAL PATCH 2026-11-07 (phase 1b/c): the Stremio pair the scrape asks with (external.py's data['stremio_se'], from
		# stremio_pair) and what the release judge reads -- attach_judge_inputs. The card is the judge's one input from here on.
		self.stremio_se, self.judge_inputs = None, None

	def set(self, field, value):
		if value is not None and value != '' and value != []: self.fields[field] = value

	def note(self, text): self.trail.append(text)


class _Scratch(object):
	"""Stands in for the external source when one of its helper methods must run (_new_season_ids, _mal_episode_ids
	write self.data): same meta and ids, its OWN data dict, so the real scrape's data is never touched."""
	def __init__(self, src):
		import types
		self.meta, self.tmdb_id, self.season, self.episode, self.data = src.meta, src.tmdb_id, src.season, src.episode, {}
		cls = type(src)
		self._mal_episode_ids = types.MethodType(cls._mal_episode_ids, self)
		self._new_season_ids = types.MethodType(cls._new_season_ids, self)


def _int(value):
	try: return int(value)
	except (TypeError, ValueError): return None


# ---------------------------------------------------------------- the steps, in the order resolve() runs them

def _cour(src, card, raw_s, raw_e, prefetch=False):
	"""Fribb's cour for the TMDb pair: re-placed by air dates where Fribb's offsets are stale, re-asked with the flat-season
	repair when the episode is past the entry's end, dropped when no entry holds it. None = no cour."""
	from caches import fribb_mappings as _fribb
	dated = None
	try: dated = src._dated_cour(raw_s, raw_e)
	except Exception as e: kodi_utils.logger('scrape.cour_dates', 'tmdb %s S%sE%s: failed: %r' % (src.tmdb_id, raw_s, raw_e, e))
	cour = dated or _fribb.find_cour_by_tmdb_coords(src.tmdb_id, raw_s, raw_e, allow_repair=False)
	if dated:
		card.note('cour placed by air date')
		was = _fribb.find_cour_by_tmdb_coords(src.tmdb_id, raw_s, raw_e, allow_repair=False) or {}
		kodi_utils.logger('scrape.cour_dates', 'tmdb %s S%sE%s: Fribb says AniList %s ep %s; by air date it is AniList %s ep %s' % (
			src.tmdb_id, raw_s, raw_e, was.get('anilist'), was.get('cour_ep'), dated.get('anilist'), dated.get('cour_ep')))
	# every network lookup the steps below may make, started at once (external._prefetch_anime_ids); they then read caches
	if prefetch:
		try: src._prefetch_anime_ids(cour, raw_s, raw_e)
		except Exception: pass
	try:
		cep = int((cour or {}).get('cour_ep') or 0)
		if cep > 1 and cour.get('anilist'):
			from apis.anilist_api import anilist_episode_count
			length = anilist_episode_count(cour['anilist'])
			if length and cep > int(length):
				rep = _fribb.find_cour_by_tmdb_coords(src.tmdb_id, raw_s, raw_e, allow_repair=True) or {}
				rlen = anilist_episode_count(rep['anilist']) if rep.get('anilist') else None
				if (rep.get('row') or {}).get('_synthetic'): rep = {}
				ok = bool(rep.get('anilist')) and rep.get('anilist') != cour.get('anilist') and (not rlen or int(rep.get('cour_ep') or 0) <= int(rlen))
				card.note('past AniList %s (%s eps): %s' % (cour['anilist'], length, 'repaired to %s' % rep.get('anilist') if ok else 'dropped'))
				kodi_utils.logger('scrape.cour', 'tmdb %s S%sE%s is past AniList %s (%s eps; Fribb says ep %s) -- %s' % (src.tmdb_id, raw_s, raw_e,
					cour['anilist'], length, cep, 'repaired: AniList %s ep %s (AniDB %s)' % (rep.get('anilist'), rep.get('cour_ep'), rep.get('anidb'))
					if ok else 'no later Fribb entry: its ids dropped, the new-season lookup picks the entry by air date'))
				cour = rep if ok else None
	except Exception: pass
	return cour, dated


def _candidates(src, info, raw_s, raw_e, dated):
	"""The ordered episode numbers a release / pack file may use for this episode (source_utils.ordered_episode_candidates):
	Fribb's, the dated cour's in place of a stale pair, the entry's own season pair where it differs from TVDB's -- or, for
	a special searched under TVDB's number, that pair alone."""
	if info.get('special_episode'): return [tuple(int(x) for x in info['special_episode'])]
	from caches import fribb_mappings as _fm
	cands = source_utils.anime_episode_candidates(src.meta, src.tmdb_id, raw_s, raw_e)
	if dated:
		stale = _fm.find_cour_by_tmdb_coords(src.tmdb_id, raw_s, raw_e, allow_repair=False) or {}
		drop = set((int(stale['cour_season']), int(n)) for n in (stale.get('season_ep'), stale.get('cour_ep')) if n and stale.get('cour_season'))
		cands = [c for c in cands if c not in drop]
		for n in (dated.get('season_ep'), dated.get('cour_ep')):
			if n and dated.get('cour_season') and not (int(dated['cour_season']) == int(raw_s) and int(n) != int(raw_e)):
				cands.append((int(dated['cour_season']), int(n)))
	try:
		from modules.metadata import cour_display_numbers
		ds, de = (int(x) for x in cour_display_numbers(src.meta, int(raw_s), int(raw_e)))
		tv = _fm.find_cour_by_tmdb_coords(src.tmdb_id, int(raw_s), int(raw_e)) or {}
		if (ds, de) != (int(tv.get('cour_season') or 0), int(tv.get('season_ep') or 0)) and ds != int(raw_s) and (ds, de) not in cands:
			cands.append((ds, de))
			count = next((x.get('episode_count') for x in (src.meta.get('season_data') or []) if x.get('season_number') == int(raw_s)), 0) or 0
			shown = {}
			for e in range(1, int(count) + 1):
				if e != int(raw_e): shown[tuple(int(x) for x in cour_display_numbers(src.meta, int(raw_s), e))] = e
			cands = [c for c in cands if not (isinstance(c[0], int) and c[0] != int(raw_s) and c != (ds, de) and c in shown)]
	except Exception: pass
	# LOCAL PATCH 2026-11-06: a Fribb-mapped special's TVDB / Stremio pair (sources.make_search_info, 'special_alt_pair')
	_alt = info.get('special_alt_pair')
	if _alt and tuple(_alt) not in cands: cands.append(tuple(int(x) for x in _alt))
	# LOCAL PATCH 2026-11-07 (phase 5c): the releases' own pair (TheXEM scene numbering) where it differs from TVDB's -- the release
	# judge's _card_pair and the pack file pick read the candidates. Haikyu!! TVDB S4E14 is the releases' S5E01.
	try:
		rel = release_pair(src.tmdb_id, int(raw_s), int(raw_e), src.meta.get('imdb_id'), src.meta.get('tvdb_id'))
		if rel and rel not in cands: cands.append(rel)
	except Exception: pass
	return source_utils.ordered_episode_candidates(int(raw_s), int(raw_e), cands)


def _cour_ids(src, card, cour, raw_s):
	"""Everything a Fribb cour gives: its ids, its sibling parts' AniDB ids, the release numbering and the AniDB eid."""
	from caches import fribb_mappings as _fribb
	card.source, card.cour = 'fribb', cour
	for key, field in (('mal', 'mal_id'), ('kitsu', 'kitsu_id'), ('anilist', 'anilist_id')):
		if cour.get(key): card.set(field, int(cour[key]))
	try:
		aids, tv = [], cour.get('cour_season')
		for _off, prow in _fribb._season_cour_rows(src.tmdb_id, raw_s, allow_repair=False):
			prow = prow or {}
			if (prow.get('season') or {}).get('tvdb') != tv: continue
			pa = prow.get('anidb_id')
			if pa and int(pa) not in aids: aids.append(int(pa))
		if len(aids) > 1: card.set('anidb_part_aids', aids)
	except Exception: pass
	for key, field in (('cour_ep', 'cour_episode'), ('cour_season', 'cour_season'), ('season_ep', 'season_episode')):
		if cour.get(key) is not None: card.set(field, int(cour[key]))
	try:
		slen = cour.get('season_len')
		if not slen and cour.get('season_start') is not None: slen = int(src.season_divider) - int(cour['season_start'])
		if slen and int(slen) > 0: card.set('season_length', int(slen))
	except Exception: pass
	if cour.get('cour_part') and (cour.get('cour_part_count') or 0) > 1:
		card.set('cour_part', int(cour['cour_part']))
		card.set('cour_part_count', int(cour['cour_part_count']))
	try:
		for sn in (src.meta.get('season_data') or []):
			if int(sn.get('season_number') or -1) == int(raw_s) and sn.get('name'): card.set('season_title', sn['name'])
	except Exception: pass
	try:
		from caches.anizip_mappings import anizip_episode_ids
		ids = anizip_episode_ids(cour.get('anilist'), cour.get('cour_ep'), card.fields.get('absolute_episode'), cour.get('anidb'))
		aid = cour.get('anidb') or ids.get('aid')
		if aid: card.set('anidb_aid', int(aid))
		if ids.get('eid'): card.set('anidb_eid', int(ids['eid']))
		# 2026-11-07 (phase 5b): the eid by the episode's TVDB id when the entry counts episodes TMDb leaves out (joined_eid)
		try:
			from apis.anilist_api import _tmdb_episode_air_date   # TMDb's date for THIS episode (meta['premiered'] may be the show's)
			joined = joined_eid(src.tmdb_id, card.tmdb[0], card.tmdb[1], cour.get('cour_ep'), aid,
								_tmdb_episode_air_date(src.meta, card.tmdb[0], card.tmdb[1]))
			if joined and joined[0] != card.fields.get('anidb_eid'):
				card.note('eid %s / entry ep %s by TVDB id (offset arithmetic gave %s / %s)' % (joined[0], joined[1],
					card.fields.get('anidb_eid'), cour.get('cour_ep')))
				kodi_utils.logger('scrape.eid', 'tmdb %s S%sE%s: AniDB %s ep %s (eid %s) by its TVDB id, not ep %s (eid %s) by offset' % (
					src.tmdb_id, card.tmdb[0], card.tmdb[1], aid, joined[1], joined[0], cour.get('cour_ep'), card.fields.get('anidb_eid')))
				card.set('anidb_eid', joined[0])
				card.set('cour_episode', joined[1])
		except Exception as e: card.note('eid join failed: %r' % e)
		# ani.zip only fills a gap Fribb's row leaves, never overwrites it
		for key, field in (('anilist', 'anilist_id'), ('kitsu', 'kitsu_id'), ('mal', 'mal_id')):
			if ids.get(key) and not card.fields.get(field): card.set(field, int(ids[key]))
	except Exception: pass
	_cour_title(card, cour)


def joined_eid(tmdb_id, season, episode, cour_ep, aid, air_date=None):
	"""LOCAL PATCH 2026-11-07 (anime core plan phase 5b): (AniDB eid, entry episode) for TMDb (season, episode) by its TVDB
	episode id in the entry's ani.zip links, or None to keep the offset arithmetic (entry episode = cour_ep). The entry
	episode replaces cour_ep too: fansubs and Kitsu count the entry as AniDB does -- Monogatari Second Season '- 06' is the
	recap, 'Mayoi Jiangshi (1)' is '- 07'.

	Why: AniDB numbers an entry's episodes its own way. Monogatari Second Season (AniDB 9183) counts three recaps TMDb and TVDB
	leave out, so cour_ep 6 is AniDB ep 6 'Summary 1' (eid 152027) while TMDb S3E6 'Mayoi Jiangshi (1)' is AniDB ep 7 (152026),
	and the shift grows to 3 by S3E23 -- AnimeTosho was asked for the wrong episode (phase 0b; Anime-Lists' own list for 9183
	says the same: ';6-...' summaries to TVDB S0). TMDb's TVDB id for the episode -> ani.zip's episode carrying it gives 7.

	Guard: only when the entry STARTS where Fribb says -- ani.zip's key 1 links to the TVDB id of TMDb (season, episode - cour_ep
	+ 1). ani.zip's Stone Ocean Part 3 (AniDB 17664) carries Part 2's links on keys 1-12 (S5E13-24) and S5E25 on key 13; there
	the offset arithmetic (ep 1, Anime-Lists: offset 24) is right and the join would ask for ep 13. Phase 0b: the join agreed
	with Fribb's entry for 3,927 of 3,927 episodes; this changes only the episode inside an entry."""
	try: cour_ep, episode = int(cour_ep), int(episode)
	except (TypeError, ValueError): return None
	if not aid or cour_ep < 1 or episode - cour_ep + 1 < 1: return None
	from apis.tmdb_api import episode_tvdb_id
	from caches.anizip_mappings import _maps
	tv = episode_tvdb_id(tmdb_id, season, episode)
	if not tv: return None
	maps = _maps('anidb_id', int(aid))
	links = maps.get('tvdb') or {}
	hit = links.get(str(tv))
	if not hit: return None
	# a regular episode of the entry only: ani.zip also links some regular TMDb episodes to AniDB SPECIALS -- Code Geass S1E15
	# 'Cheering Mao' to 4521 'S4', TMDb 76757 S2E5 to 14185 'S5' -- where the offset's regular episode is the right one
	if str(hit[0]) not in set(str(v) for v in (maps.get('eps') or {}).values()): return None
	key1 = str((maps.get('eps') or {}).get('1') or '')
	key1_tvdb = next((t for t, v in links.items() if str(v[0]) == key1), None) if key1 else None
	start_tvdb = episode_tvdb_id(tmdb_id, season, episode - cour_ep + 1)
	if not start_tvdb or str(key1_tvdb) != str(start_tvdb): return None
	# and the episode it lands on airs when TMDb's does (2 days): ani.zip's Off & Monster entry (AniDB 18424) carries TMDb S5E2-4
	# 'Nadeko Draw (1)-(3)' (July 2024) on keys 12-14, 'Shinobu Mustard, Parts 4-6' (October). Both dates are needed.
	from caches.anizip_mappings import air_dates_agree
	key = next((k for k, v in (maps.get('eps') or {}).items() if str(v) == str(hit[0])), None)
	if not air_date or not air_dates_agree((maps.get('dates') or {}).get(key), str(air_date)[:10], 2): return None
	try: return int(hit[0]), int(key)
	except (TypeError, ValueError, IndexError): return None


def entry_episode(tmdb_id, season, episode, cour, meta=None):
	"""LOCAL PATCH 2026-11-07: the number of TMDb (season, episode) inside its AniList / MAL entry, for the progress pushes
	(player._anime_entry, watched_status._anime_entry_ids). Fribb's cour_ep, unless joined_eid places the episode elsewhere
	in the entry by its TVDB id -- then that, when the AniList entry is long enough to hold it.

	Why: AniList and MAL count an entry's episodes as AniDB does. Monogatari Second Season (AniList / MAL 17074, AniDB 9183)
	has 26 there, three of them recaps TMDb leaves out, so TMDb S3E6 'Mayoi Jiangshi (1)' is the entry's episode 7 and S3E23
	its 26th. cour_ep pushed 6 for it (the recap) and 23 at the end: the entry stayed CURRENT at 23 / 26 for good.
	Falls back to cour_ep on any doubt (no AniDB id, no join, a join past the entry's AniList length, an error)."""
	try: cour_ep = int((cour or {}).get('cour_ep') or 0)
	except (TypeError, ValueError): return None
	if not cour_ep: return None
	aid, al = cour.get('anidb'), cour.get('anilist')
	if not aid or not al: return cour_ep
	try:
		from apis.anilist_api import _tmdb_episode_air_date, anilist_episode_count
		if not meta or not meta.get('season_data'):
			from modules.metadata import tvshow_meta
			from modules.settings import tmdb_api_key, mpaa_region
			from modules.utils import get_datetime
			meta = tvshow_meta('tmdb_id', int(tmdb_id), tmdb_api_key(), mpaa_region(), get_datetime())
		joined = joined_eid(tmdb_id, season, episode, cour_ep, aid, _tmdb_episode_air_date(meta, season, episode))
		if not joined or joined[1] == cour_ep: return cour_ep
		length = anilist_episode_count(al)
		if not length or joined[1] > int(length): return cour_ep
		kodi_utils.logger('anime.entry_ep', 'tmdb %s S%sE%s: entry %s ep %s by its TVDB id, not %s by offset' % (
			tmdb_id, season, episode, al, joined[1], cour_ep))
		return joined[1]
	except Exception as e:
		kodi_utils.logger('anime.entry_ep', 'tmdb %s S%sE%s: join failed (%r), offset %s kept' % (tmdb_id, season, episode, e, cour_ep))
		return cour_ep


def _cour_title(card, cour):
	"""The cour's romaji title (AniList), by its AniList id, else its MAL id; none when the episode is past the entry."""
	try:
		from apis.anilist_api import anilist_romaji_for_mal, anilist_romaji_for_id, anilist_episode_count
		al, mal = cour.get('anilist'), cour.get('mal')
		own = al or mal
		card.title_key = ('anilist_id', al) if al else ('mal_id', mal)
		cep = int(cour.get('cour_ep') or 0)
		if al and cep > 1:
			length = anilist_episode_count(al)
			if length and cep > int(length):
				own = None
				card.title_key = (card.title_key[0], None)
				kodi_utils.logger('scrape.cour', 'S%sE%s is cour ep %s of AniList %s, which has %s: cour mapping off, no cour title'
					% (card.tmdb[0], card.tmdb[1], cep, al, length))
		if own:
			title = anilist_romaji_for_id(al) if al else anilist_romaji_for_mal(mal)
			if title: card.set('mal_title', title)
	except Exception: pass


def _special_ids(src, card, info):
	"""A special Fribb does not map: no whole-run or new-season ids (TMDb's S0En has no place in either numbering) -- only
	its own AniDB ids from ani.zip (sources.make_search_info), the aid only when it ships in the season's packs."""
	card.source = 'special'
	kodi_utils.logger('scrape.special', 'tmdb %s S0E%s: a special with no Fribb row -- no whole-run / new-season ids' % (src.tmdb_id, card.tmdb[1]))
	sp = info.get('special_anidb')
	if sp:
		card.set('anidb_eid', int(sp[1]))
		if sp[2]: card.set('anidb_aid', int(sp[0]))
		card.source = 'special+anizip'
		_special_judge_facts(card, info, sp)


def _special_judge_facts(card, info, sp):
	"""LOCAL PATCH 2026-11-06: what the release judge needs to read a special's releases, from its ani.zip entry (cached by
	anizip_special_ids just before): 'special_numbers' -- the TVDB / Stremio pair it is searched as, TMDb's own, its episode in
	the AniDB entry, the series absolute -- and 'special_titles' -- the entry's AniList romaji and its part before the colon.
	Attack on Titan's 'The Final Chapters Special (1)' (TMDb S0E36) is searched as S04E29, AniDB 17303 ep 1, absolute 88: with
	no romaji title 'Shingeki.no.Kyojin.-.The.Final.Season.Part.3.-.01' was 'another show', and with no numbers 'Part 3 - 02',
	'S04E30' and 'S04E28' were kept. Read by release_judge only; no provider query changes."""
	try:
		from caches.anizip_mappings import _maps
		maps = _maps('anidb_id', int(sp[0]))
		if not maps: return
		eid = int(sp[1])
		def _key_of(table):
			return next((int(k) for k, v in (maps.get(table) or {}).items() if str(v) == str(eid)), None)
		pair = info.get('special_episode')
		card.set('special_numbers', {'pair': [int(pair[0]), int(pair[1])] if pair else None, 'tmdb': [0, int(card.tmdb[1])],
									'entry_episode': _key_of('eps'), 'absolute': _key_of('abs')})
		titles = []
		if maps.get('anilist'):
			from apis.anilist_api import anilist_romaji_for_id
			romaji = anilist_romaji_for_id(maps['anilist'])
			if romaji: titles += [romaji, romaji.split(':')[0].strip()]
		titles += [t for t in (maps.get('titles') or []) if len(t.split()) >= 2]   # not 'snk6'
		card.set('special_titles', list(dict.fromkeys(t for t in titles if t)))
	except Exception as e:
		kodi_utils.logger('scrape.special', 'judge facts failed: %s' % type(e).__name__)


def _whole_run_ids(src, card):
	"""A show Fribb has no row for, when ONE ani.zip entry covers the whole run (Naruto 220/220): its ids, paired with the
	series-absolute number. True when it applied."""
	absolute = card.fields.get('absolute_episode')
	if not absolute: return False
	from caches.anizip_mappings import anizip_whole_run_ids, anizip_episode_ids
	run = anizip_whole_run_ids(src.tmdb_id, src.meta.get('total_aired_eps'))
	if run.get('kitsu') and int(absolute) > int(run.get('count') or 0):
		card.note('absolute %s past the whole-run entry (%s eps)' % (absolute, run.get('count')))
		kodi_utils.logger('scrape.new_season', 'tmdb %s: absolute %s is past the %s episodes of ani.zip\'s whole-run entry (AniDB %s) -- '
			'not the whole run' % (src.tmdb_id, absolute, run.get('count'), run.get('aid')))
		run = {}
	if not run.get('kitsu'): return False
	card.source = 'whole_run'
	card.set('kitsu_id', int(run['kitsu']))
	card.set('cour_episode', int(absolute))
	for key, field in (('mal', 'mal_id'), ('anilist', 'anilist_id'), ('aid', 'anidb_aid')):
		if run.get(key): card.set(field, int(run[key]))
	card.set('whole_run', True)
	try:
		eids = anizip_episode_ids(run.get('anilist'), absolute, anidb_id=run.get('aid')) or {}
		if eids.get('eid'): card.set('anidb_eid', int(eids['eid']))
	except Exception: pass
	return True


def _new_season(src, card, raw_s, raw_e):
	"""A season Fribb has not mapped yet: the AniList entry that starts it by air date, its ani.zip / MAL ids
	(external._new_season_ids, run on a scratch copy)."""
	scratch = _Scratch(src)
	try: scratch._new_season_ids(raw_s, raw_e)
	except Exception as e: card.note('new season lookup failed: %r' % e)
	if scratch.data:
		card.source = 'new_season'
		for field, value in scratch.data.items():
			if field in CARD_FIELDS: card.set(field, value)
		# LOCAL PATCH 2026-11-07 (anime core plan phase 5a): what the Fribb path gives a release judge and this path did not.
		# The entry found here is the one that STARTS this TMDb season, so TMDb's episode number IS the release-season number
		# (external._new_season_ids: 'Black Clover S02E01') -- season_episode, as Fribb's season_ep. And the entry's romaji title,
		# as Fribb's mal_title. Without them Steel Ball Run S6E4 (AniList 210482, Fribb row not yet) was judged on the absolute
		# number 194 alone: every right 'JoJos.Bizarre.Adventure.S06E04' was 'names episode 4' and 'JoJo no Kimyou na Bouken:
		# Steel Ball Run - 04' was 'another show' (torrentio 33 -> 1, mediafusion 9 -> 0; baselines 2026-11-07).
		try:
			if 'season_episode' not in card.fields and _int(raw_e): card.set('season_episode', int(raw_e))
			if 'mal_title' not in card.fields and card.fields.get('anilist_id'):
				from apis.anilist_api import anilist_romaji_for_id
				title = anilist_romaji_for_id(card.fields['anilist_id'])
				if title: card.set('mal_title', title)
			# and the AniDB entry's own titles (ani.zip en / x-jat, cached with its ids): AniList calls SBR's part 'JoJo no Kimyou na
			# Bouken: Steel Ball Run - 2nd & 3rd STAGE', AniDB 19287 'Steel Ball Run: JoJo no Kimyou na Bouken' -- as many release
			# names do. Read by release_judge.Context (as a special's own titles are).
			if card.fields.get('anidb_aid'):
				from caches.anizip_mappings import anizip_entry_titles
				titles = [t for t in ((anizip_entry_titles(anidb_id=card.fields['anidb_aid']) or {}).get('titles') or []) if len(t.split()) >= 2]
				if titles: card.set('entry_titles', titles)
		except Exception as e: card.note('new season judge facts failed: %r' % e)


# ---------------------------------------------------------------- the TVDB / Stremio pair
# LOCAL PATCH 2026-11-07 (anime core plan phase 1a): the episode's number in TVDB's / Stremio's (Cinemeta's) numbering, worked
# out HERE for every caller. It was three copies: external.py (MediaFusion on anime, 11-07), http_streams.py (Direct Streams,
# 11-05) and sources.make_search_info (specials, 11-03 / 11-06). The callers keep their own conditions, logging and what they
# do with the pair -- moved code, same answers. The order follows phase 0b (handover/2026-11-06-anime-core-plan.md, 0c): the
# TVDB episode id first (TMDb's record -> Cinemeta's episode carrying it; 0 disagreements with Fribb over 2,966 episodes, and
# it answers the whole-run shows Fribb cannot), Fribb's cour season / episode only when that join has no answer (TMDb lacks
# the TVDB ids for a few shows: Fate/stay night 2006, Dororo).

def stremio_pair(tmdb_id, season, episode, imdb):
	"""((season, episode) ints, 'cinemeta' | 'fribb') for an episode Fribb places in a cour, else (None, None). Returned even
	when it equals TMDb's pair -- the caller decides whether a different pair matters. Raises on a failed lookup (the
	callers log it their own way)."""
	from caches import fribb_mappings
	cour = fribb_mappings.find_cour_by_tmdb_coords(int(tmdb_id), int(season), int(episode)) or {}
	if not cour: return None, None
	from apis.tmdb_api import episode_tvdb_id
	from modules.cinemeta import stremio_episode
	pair = stremio_episode(imdb, episode_tvdb_id(tmdb_id, season, episode))
	if pair: return pair, 'cinemeta'
	if cour.get('cour_season') is not None and cour.get('season_ep') is not None:
		return (int(cour['cour_season']), int(cour['season_ep'])), 'fribb'
	return None, None


def release_pair(tmdb_id, season, episode, imdb, tvdb_show_id):
	"""LOCAL PATCH 2026-11-07 (phase 5c): (season, episode) in the RELEASES' numbering (TheXEM scene numbering, caches.
	thexem_mappings) for a regular episode Fribb places in a cour, when it differs from TVDB's; else None. TVDB's pair is
	stremio_pair's (the episode's TVDB id in Cinemeta, else Fribb's)."""
	if not tvdb_show_id or int(season) <= 0: return None
	tv, _how = stremio_pair(tmdb_id, season, episode, imdb)
	if not tv: return None
	from caches.thexem_mappings import scene_pair
	rel = scene_pair(tvdb_show_id, tv[0], tv[1])
	return rel if rel and rel != tuple(int(x) for x in tv) else None


def special_tvdb_id(tmdb_id, episode):
	"""TMDb's TVDB episode id for its special S0E<episode> (cached 720 h), or None."""
	from apis.tmdb_api import episode_tvdb_id
	return episode_tvdb_id(tmdb_id, 0, episode)


def special_pair(imdb, premiered, ep_name, tvdb_id):
	"""A TMDb special's (season, episode) STRINGS in Stremio's numbering (cinemeta.special_episode: by TVDB episode id, then
	title, then date, among season 0), or None."""
	from modules.cinemeta import special_episode
	return special_episode(imdb, premiered, ep_name, tvdb_id)


# ---------------------------------------------------------------- what the judge reads
# LOCAL PATCH 2026-11-07 (anime core plan phase 1b/c): release_judge.context_for built its Context from the scraper object
# (src.data, src.title, src.season, the season's TMDb names, src._other_season_words). They are attached to the card once the
# scrape setup is done, and context_for reads them from here -- the same objects (data is the scrape's own dict, not a copy),
# so every decision stays the same. Phase 2 judges by how a row was found; phase 5 replaces the loose numbers with the card's
# pairs (Steel Ball Run S6E4 and Monogatari S3E6-23, plan 0b / 0c).

def attach_judge_inputs(card, src):
	"""Record on the card what the release judge needs about this episode (Context's arguments) and the Stremio pair."""
	card.stremio_se = src.data.get('stremio_se')
	try: season = int(src.season)
	except (TypeError, ValueError): season = 0
	names = [sn.get('name') or '' for sn in (src.meta.get('season_data') or []) if str(sn.get('season_number')) == str(season)]
	card.judge_inputs = (src.data, src.title, season, names, src._other_season_words(season))


# ---------------------------------------------------------------- the pipeline

def resolve(src, info, prefetch=False):
	"""The EpisodeCard for the anime episode an external source is about to scrape. `src` supplies meta, tmdb_id and
	season_divider and its date / new-season / prefetch helpers; `info` is sources.search_info (the special's remap and
	AniDB ids). prefetch: start the network lookups in parallel first (the scrape; the harness may skip it)."""
	raw_s, raw_e = src.meta.get('season', src.season), src.meta.get('episode', src.episode)
	card = EpisodeCard((_int(raw_s), _int(raw_e)), str(raw_s) == '0')
	# 1. the series-absolute number (TMDb's season_data alone). Not for a special: series_absolute_episode hands TMDb's S0En
	# back unchanged, and 'absolute 1' for Steins;Gate 0's Valentine OVA made every '- 01' name an acceptable number to the
	# providers' name checks (anime_utils.cour_match takes absolute_episode as one of the episode's numbers).
	if not card.special:
		try:
			from modules.metadata import series_absolute_episode
			absolute = series_absolute_episode(src.meta, raw_s, raw_e)
			if absolute: card.set('absolute_episode', int(absolute))
		except Exception: pass
	# 2. which cour
	cour, dated = _cour(src, card, raw_s, raw_e, prefetch)
	# 3. the numbers a release may use
	try: card.set('episode_candidates', _candidates(src, info, raw_s, raw_e, dated))
	except Exception: pass
	# 4. the ids, from the first path that knows the episode
	if cour: _cour_ids(src, card, cour, raw_s)
	elif card.special: _special_ids(src, card, info)
	elif not _whole_run_ids(src, card): _new_season(src, card, raw_s, raw_e)
	return card
