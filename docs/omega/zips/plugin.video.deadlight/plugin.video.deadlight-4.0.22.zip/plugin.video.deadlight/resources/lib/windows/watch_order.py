# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-11-01: the Watch Order window. The context menu's 'Watch Order' used to open a Kodi folder
# (anilist_lists.build_anilist_watch_order), where the skin decides the layout: the numbering and the 'or watch this
# instead' branches were faked with spaces in the label and the notes were colour codes in the title. Here DeadLight draws
# it (watch_order.xml): a numbered timeline on the left -- a dot per step coloured by the user's AniList status, an
# alternative hanging off its step -- and the focused step's art, facts and progress on the right, with Open / Play and
# the Anime List Manager for that exact entry. Rows come from anilist_lists.watch_order_rows.
from windows.base_window import BaseDialog
from modules import kodi_utils

# dot colour per AniList status ('' = not on the list, None = no account signed in)
_DOT = {'done': 'FF4CAF50', 'partial': 'FFFFB300', 'planned': 'FF64B5F6', 'dropped': 'FFE57373', '': 'FF5A5D66', None: 'FF5A5D66'}
_OPEN_LABEL = {'play': 'Play Film', 'search': 'Search AniList'}


def _open_label(row):
	"""LOCAL PATCH 2026-11-01: an announced step ('plan') offers to put it on the list, or says it is there already; without
	an account it stays a search."""
	if row['action'] == 'plan':
		if row['status'] is None: return 'Search AniList'
		return 'In Your List' if row['status'] else 'Plan to Watch'
	return row.get('open_label') or _OPEN_LABEL.get(row['action'], 'Open %s' % row['where'])


def _short_titles(rows):
	"""Timeline labels without the franchise name every later step repeats: 'Re:ZERO -Starting Life in Another World-
	Season 2' is cut off before 'Season 2' in a 600 px row. The first row keeps the full name; the detail panel always does."""
	base = rows[0]['title'] if rows else ''
	out = []
	for i, r in enumerate(rows):
		t = r['title']
		rest = t[len(base):].strip(' -:~') if i and base and t.startswith(base) else ''
		# a remainder with no letter says nothing alone ('JUJUTSU KAISEN 0' -> '0'): the full name then
		out.append(rest if any(c.isalpha() for c in rest) else t)
	return out


def _progress_text(row):
	status, progress, total = row['status'], row['progress'], row['episodes']
	if status is None: return ''
	if status == 'done': return 'Completed on AniList'
	if status == 'partial':
		return 'Watching on AniList: ep %s%s' % (progress, ' of %s' % total if total else '') if progress else 'Watching on AniList'
	if status == 'planned': return 'Planned on AniList'
	if status == 'dropped': return 'Dropped on AniList' + (' at ep %s' % progress if progress else '')
	return 'Not on your AniList'


class WatchOrder(BaseDialog):
	list_id, open_id, manager_id = 2000, 10, 11

	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.rows = kwargs.get('rows') or []
		self.short_titles = _short_titles(self.rows)
		self.start_index = kwargs.get('start_index') or 0
		self.is_external = kwargs.get('is_external', 'true')
		self.selected = None
		self.setProperty('heading', 'Watch Order  ·  %s' % (kwargs.get('heading') or ''))
		self.setProperty('manager', 'true' if kwargs.get('manager_enabled') else 'false')

	def onInit(self):
		self.add_items(self.list_id, [self._make_listitem(i, r) for i, r in enumerate(self.rows)])
		self.setFocusId(self.list_id)
		try: self.get_control(self.list_id).selectItem(self.start_index)
		except Exception: pass

	def run(self):
		self.doModal()
		self.clearProperties()
		if self.selected: self.execute_code(self.selected)

	def _make_listitem(self, index, row):
		listitem = self.make_listitem()
		alternative = row['kind'] == 'alternative'
		line2 = ' · '.join(x for x in (row['note'] if row['kind'] != 'main' else '', _progress_text(row) if row['status'] == 'partial' else '') if x)
		progress = _progress_text(row)
		props = {'title': row['title'], 'short_title': self.short_titles[index], 'number': '' if alternative or not row['number'] else str(row['number']),
			'alternative': 'true' if alternative else '', 'alt_or': 'or  ' if alternative else '', 'line2': line2, 'short_facts': row['short_facts'], 'facts': row['facts'],
			'note': row['note'], 'progress': progress, 'dot_colour': _DOT.get(row['status'], _DOT['']),
			'upcoming': 'true' if row['kind'] == 'upcoming' else '', 'first': 'true' if index == 0 else '',
			'last': 'true' if index == len(self.rows) - 1 else '', 'open_label': _open_label(row),
			'fanart': row['fanart'], 'cover': row['cover'], 'clearlogo': row['clearlogo']}
		for k, v in props.items(): listitem.setProperty(k, v or '')
		return listitem

	def _row(self):
		try: return self.rows[self.get_position(self.list_id)]
		except Exception: return None

	def onClick(self, controlID):
		if controlID in (self.list_id, self.open_id): return self._open()
		if controlID == self.manager_id: return self._manager()

	def onAction(self, action):
		if action in self.closing_actions: return self.close()
		if action in self.context_actions and self.getFocusId() == self.list_id: return self._manager()

	def _open(self):
		row = self._row()
		if not row: return
		if row['action'] == 'plan' and row['status'] is not None:
			return self._manager() if row['status'] else self._plan(row)
		if row['action'] == 'play': self.selected = 'RunPlugin(%s)' % row['url']
		elif self.is_external == 'true': self.selected = 'ActivateWindow(Videos,%s,return)' % row['url']
		else: self.selected = 'Container.Update(%s)' % row['url']
		self.close()

	def _plan(self, row):
		"""LOCAL PATCH 2026-11-01: Plan to Watch for an announced step -- Planning on AniList and MAL (whichever are signed in),
		then the dots redrawn. No picker: the step is the exact entry."""
		from apis import anilist_api, mal_api
		from modules import settings
		done = []
		if settings.anilist_user_active() and anilist_api.anilist_set_status(row['anilist_id'], 'PLANNING'): done.append('AniList')
		if row.get('mal_id') and settings.mal_user_active() and mal_api.mal_set_status(row['mal_id'], 'plan_to_watch'): done.append('MAL')
		kodi_utils.notification('%s: Plan to Watch' % ' + '.join(done) if done else 'Plan to Watch failed', 3000)
		if done:
			kodi_utils.refresh_after_edit('anilist.list.', 'mal.list.')
			self._refresh_status()

	def _manager(self):
		"""The Anime List Manager for this exact step (its AniList / MAL ids), then the row's status redrawn."""
		row = self._row()
		if not row or self.getProperty('manager') != 'true': return
		from indexers.dialogs import anilist_manager_choice
		anilist_manager_choice({'anilist_id': row['anilist_id'], 'mal_id': row['mal_id'] or '', 'title': row['title'],
			'icon': row['cover'], 'media_type': 'movie' if row['action'] == 'play' else 'tvshow'})
		self._refresh_status()

	def _refresh_status(self):
		from apis import anilist_api
		from indexers.anilist_lists import _WO_STATUS
		if not anilist_api.anilist_user_active(): return
		try: on_list = anilist_api.anilist_media_list_all() or {}
		except Exception: return
		position = self.get_position(self.list_id)
		for row in self.rows:
			entry = on_list.get(int(row['anilist_id'])) or {}
			row['status'], row['progress'] = _WO_STATUS.get(entry.get('status'), ''), entry.get('progress') or 0
		self.reset_window(self.list_id)
		self.add_items(self.list_id, [self._make_listitem(i, r) for i, r in enumerate(self.rows)])
		try: self.get_control(self.list_id).selectItem(position)
		except Exception: pass
