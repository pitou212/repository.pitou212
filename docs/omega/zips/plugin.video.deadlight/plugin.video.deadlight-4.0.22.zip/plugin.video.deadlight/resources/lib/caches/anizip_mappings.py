# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-27: ani.zip -> AniDB episode ids.
#
# WHY THIS EXISTS
# Every anime scraping bug fought in this codebase comes from one root choice:
# releases are identified by PARSING THEIR NAMES. That cannot be made correct,
# because the same episode legitimately ships under several different numbers.
# Bleach's Thousand-Year Blood War premiere is on nyaa as BOTH "S01E01" (the arc's
# own numbering) and "S17E01" (Bleach counted continuously). Re:ZERO's TMDb episode
# 50 is named "Season 2 - 24". AoT S3E20 is "S03E20 (57)". No regex is right about
# all of these, and each rule added to cover one convention re-opens another.
#
# AniDB assigns every episode a stable numeric id (eid), and AnimeTosho tags the
# torrents it mirrors from nyaa with that eid. So an eid turns "which torrents are
# this episode?" from a parsing problem into a lookup. ani.zip is the free, keyless
# bridge from an AniList id (which Fribb already gives us offline) to those eids.
#
# This module is ONLY the mapping. It never decides anything about a release.
#
# Endpoint: https://api.ani.zip/mappings?anilist_id=<id>   (no key, no rate limit
# published; we cache anyway so a scrape costs at most one call per show per day).

from datetime import datetime, timedelta, timezone
from caches.lists_cache import lists_cache
from modules.kodi_utils import make_session

_ANIZIP_URL = 'https://api.ani.zip/mappings'

session = make_session(_ANIZIP_URL)

# Airing shows gain an episode a week, so this cannot be cached indefinitely, but
# an episode's eid never changes once assigned -- a day is a safe compromise.
_CACHE_HOURS = 24
# LOCAL PATCH 2026-10-10: 'anizip2_' -- the cached shape gained 'se', 'dates' and 'tmdb' (the air-date checks in
# scrapers/external.py). An entry cached before has none of them, which would skip those checks for a day.
# LOCAL PATCH 2026-11-04: 'anizip3_' -- and 'tvdb' (anizip_special_ids). Same reason: an older entry would find no special.
_CACHE_KEY = 'anizip4_%s_%s'   # LOCAL PATCH 2026-11-04: 'anizip4_' -- + 'cjk' titles (the release judge's CJK cour words)
# LOCAL PATCH 2026-10-19: an entry whose every episode aired over a month ago cannot gain one, so it keeps 30 days (82%
# of the cached entries were re-fetched daily for nothing); ani.zip's real 'no such entry' is kept 7 days as a marker
# (as an empty answer it was kept 18 minutes, base_cache.cache_ttl); a failed fetch is not stored at all.
_FINISHED_HOURS, _NONE_HOURS, _FINISHED_DAYS = 720, 168, 30
_NONE = {'_none': 1}


def _hours(maps):
	if maps.get('_none'): return _NONE_HOURS
	dates, count = maps.get('dates') or {}, maps.get('count') or 0
	if not count or len(dates) < count: return _CACHE_HOURS
	cutoff = (datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=_FINISHED_DAYS)).strftime('%Y-%m-%d')
	return _FINISHED_HOURS if max(dates.values()) < cutoff else _CACHE_HOURS


def _maps(key, value):
	"""The cached _fetch answer for one lookup pair, or {} (none / failed)."""
	string = _CACHE_KEY % (key, value)
	maps = lists_cache.get(string)
	if maps is None:
		maps = _fetch('%s=%s' % (key, value))
		if maps is None: return {}
		lists_cache.set(string, maps, expiration=_hours(maps))
	return {} if not maps or maps.get('_none') else maps


def _fetch(query):
	"""Compact {episode_key: eid} maps for one anime entry, plus its ids.

	`query` is a full lookup pair, e.g. 'anilist_id=154587' or 'anidb_id=19873'.

	Deliberately reshaped rather than cached whole: the raw response carries
	per-episode overviews, images and titles in seven languages, which is ~50x the
	bytes of the four fields used here and would bloat the cache db for nothing.
	"""
	try:
		r = session.get('%s?%s' % (_ANIZIP_URL, query), timeout=10)
		if r.status_code == 404: return _NONE
		if r.status_code != 200: return None
		data = r.json()
	except Exception: return None
	if not isinstance(data, dict): return None
	by_ep, by_abs, by_se, by_date, by_tvdb = {}, {}, {}, {}, {}
	for key, ep in (data.get('episodes') or {}).items():
		if not isinstance(ep, dict): continue
		eid = ep.get('anidbEid')
		if not eid: continue
		# LOCAL PATCH 2026-11-04: every episode WITH its TVDB episode id, specials and OVAs included ('S1', 'O1'), for
		# anizip_special_ids. Keyed by that id, a special cannot collide with a regular episode the way an 'S1' key in
		# `eps` could -- each TVDB episode has its own id.
		if ep.get('tvdbId'): by_tvdb[str(ep['tvdbId'])] = [eid, ep.get('seasonNumber'), ep.get('episodeNumber')]
		# `key` is the entry-local number ("1".."28"), or "S1" for a special. Specials
		# are kept out: our episode numbers never address them, and a stray "S1" key
		# colliding with a real episode would silently scrape the wrong thing.
		if key.isdigit():
			by_ep[key] = eid
			if ep.get('airDateUtc') or ep.get('airdate'): by_date[key] = (ep.get('airDateUtc') or ep.get('airdate'))[:10]
			# LOCAL PATCH 2026-10-10: TVDB season/episode + air date, for anizip_mal_episode_ids
			if ep.get('seasonNumber') is not None and ep.get('episodeNumber') is not None:
				by_se['%sx%s' % (ep['seasonNumber'], ep['episodeNumber'])] = (eid, (ep.get('airDateUtc') or ep.get('airdate') or '')[:10])
		abs_no = ep.get('absoluteEpisodeNumber')
		if abs_no is not None: by_abs[str(abs_no)] = eid
	if not by_ep and not by_abs: return _NONE
	mappings = data.get('mappings') or {}
	# LOCAL PATCH 2026-10-17: the entry's English / romaji titles and episode 1's English title, for _season0_rows' title
	# pass (Zoku Owarimonogatari: ep 1 'Complete Movie', Parts 1-6 at 2-7). Not a new cache key -- an entry cached before
	# simply has no titles until it expires (a day), and the title pass then finds nothing, as before.
	titles = [t for t in ((data.get('titles') or {}).get(k) for k in ('en', 'x-jat')) if t]
	# LOCAL PATCH 2026-11-04: and the CJK titles, for release_judge.build_reject_words: '[NC-Raws] BLEACH 死神 千年血戰篇 - 01' is
	# Thousand-Year Blood War episode 1, which no latin word in the name says (it listed for Bleach S1E1)
	cjk = dict((k, (data.get('titles') or {}).get(k)) for k in ('ja', 'zh-Hant', 'zh-Hans', 'ko') if (data.get('titles') or {}).get(k))
	ep1 = ((data.get('episodes') or {}).get('1') or {}).get('title') or {}
	# `count` is the number of real (non-special) episodes in this entry. It is what
	# tells a whole-series entry from a single cour -- see anizip_whole_run_ids below.
	return {'eps': by_ep, 'abs': by_abs, 'se': by_se, 'dates': by_date, 'tvdb': by_tvdb, 'count': len(by_ep),
			'titles': titles, 'cjk': cjk, 'ep1_title': (ep1.get('en') if isinstance(ep1, dict) else '') or '',
			'anidb': mappings.get('anidb_id'), 'anilist': mappings.get('anilist_id'),
			'kitsu': mappings.get('kitsu_id'), 'mal': mappings.get('mal_id'), 'tmdb': mappings.get('themoviedb_id')}


def anizip_episode_ids(anilist_id, cour_episode=None, absolute_episode=None, anidb_id=None):
	"""Ids for one episode as a dict: aid, eid, anilist, kitsu, mal. Any may be None.

	A dict rather than a tuple because callers want different subsets of it -- the
	animetosho provider needs the eid, seadex needs the AniList id, and the Kitsu
	paths in torrentio/comet need the Kitsu id -- and a 5-tuple would be unreadable
	at every call site.

	`cour_episode` is the episode's index within the entry, which is exactly how
	ani.zip keys its `episodes` map -- so it is tried first. `absolute_episode` is the
	fallback for shows whose entry covers the whole run (Boruto is one entry, so its
	episode 220 is both).

	LOCAL PATCH 2026-08-27: falls back to looking up by AniDB id. Fribb's rows are not
	uniformly populated -- Chainsmoker Cat has anidb=19873 but no anilist/mal/kitsu at
	all -- and without an AniList id there was nothing to query, so animetosho got no
	eid and seadex got no key. Querying by anidb_id is the same lookup at the same
	granularity (Fribb's anidb IS this cour's AniDB anime, so the episode keys line up
	with cour_episode exactly as the AniList path does), and it also RECOVERS the
	AniList id that Fribb was missing, which is what lets seadex work for these shows.
	5 anime in the current library are in this state.

	Deliberately NOT extended to ani.zip's themoviedb_id lookup, which also works but
	is not safe here: for a show TMDb splits into seasons, ani.zip reports seasonNumber
	1 for the whole run, and its absoluteEpisodeNumber is missing (Naruto, One Piece)
	or disagrees with its own episode key (Fairy Tail: key 881 vs absolute 865 -- two
	different episodes). Guessing between them risks playing the wrong one.
	"""
	queries = []
	try:
		if anilist_id: queries.append(('anilist_id', int(anilist_id)))
	except (TypeError, ValueError): pass
	try:
		if anidb_id: queries.append(('anidb_id', int(anidb_id)))
	except (TypeError, ValueError): pass
	if not queries: return {}

	maps = {}
	for key, value in queries:
		maps = _maps(key, value)
		if maps: break
	if not maps: return {}
	found = {'aid': maps.get('anidb'), 'eid': None,
			'anilist': maps.get('anilist') or anilist_id,
			'kitsu': maps.get('kitsu'), 'mal': maps.get('mal')}
	for table, number in (('eps', cour_episode), ('abs', absolute_episode)):
		if number is None: continue
		eid = (maps.get(table) or {}).get(str(number))
		if eid:
			found['eid'] = eid
			break
	return found


def anizip_special_ids(tmdb_id, tvdb_episode_id, max_entries=16):
	"""LOCAL PATCH 2026-11-04: {'aid', 'eid', 'season', 'episode'} for a TMDb SPECIAL Fribb does not map, found by its TVDB
	episode id (apis.tmdb_api.episode_tvdb_id) among ani.zip's entries for this show, or {}.

	The eid is what AnimeTosho files a special's releases under, whatever they are named: Steins;Gate 0's Valentine OVA
	(TMDb S0E1, TVDB 6947967) is AniDB eid 200213, and ?eid=200213 returns 14 rows, every one the OVA -- named
	'Steins;Gate 0 - 24 (OVA)', which no S00E02 / S00E01 search can match. 'season' / 'episode' are TVDB's pair (S0E2
	there; Monogatari's 'Tsubasa Cat (3)', TMDb S0E2, is S1E13), a second source beside Cinemeta's.

	Asked of the entry ani.zip gives for the TMDb id first (the show's first cour -- where Monogatari's and Steins;Gate 0's
	specials sit), then of every Fribb entry of the show, at most max_entries, until one holds the id. Each answer is the
	same cached lookup the cour path makes (a day, 30 days once the entry has finished airing).

	ONLY for a special Fribb's season-0 map does not place (sources.make_search_info's guard) -- ani.zip's TVDB links are
	themselves a mapping and can be shifted: for Nekomonogatari Kuro (AniDB 9453) it ties TVDB 4450835, TMDb S0E6 'Tsubasa
	Family (1)', to AniDB ep 1 (the whole TV special) instead of ep 2 'Part 1 of 4', which Fribb's map gets right."""
	try: tmdb_id, tvdb_episode_id = int(tmdb_id), int(tvdb_episode_id or 0)
	except (TypeError, ValueError): return {}
	if not tmdb_id or not tvdb_episode_id: return {}
	queries = [('themoviedb_id', tmdb_id)]
	try:
		from caches.fribb_mappings import tmdb_tv_to_fribb_rows
		for row in (tmdb_tv_to_fribb_rows(tmdb_id) or []):
			if row.get('anilist_id'): queries.append(('anilist_id', int(row['anilist_id'])))
			elif row.get('anidb_id'): queries.append(('anidb_id', int(row['anidb_id'])))
	except Exception: pass
	seen = set()
	for key, value in queries:
		if (key, value) in seen: continue
		seen.add((key, value))
		if len(seen) > max_entries: break
		maps = _maps(key, value)
		hit = (maps.get('tvdb') or {}).get(str(tvdb_episode_id))
		if hit and maps.get('anidb'):
			return {'aid': int(maps['anidb']), 'eid': int(hit[0]), 'season': hit[1], 'episode': hit[2]}
	return {}


def anizip_mal_episode_ids(mal_id, tmdb_id, season, episode, air_date=None):
	"""LOCAL PATCH 2026-10-10: {'aid', 'eid'} for TMDb episode (season, episode) from ani.zip's entry for a MAL id, or {}.

	For a season Fribb has not mapped, the AniList entry is found by air date, but ani.zip may know nothing of it either:
	JoJo's Steel Ball Run 2nd & 3rd STAGE (AniList 210482) had no ani.zip mapping at all its first weeks, so animetosho was
	skipped. Its MAL id (61469) is shared with the 1st STAGE entry -- MAL, like AniDB, keeps Steel Ball Run as ONE entry --
	and ani.zip answers for it: AniDB 19287, eid 313678 for S6E4, the eid AnimeTosho files the releases under.

	The MAL entry can be wider than the AniList one (here it holds the 1st STAGE too: AniList's 'ep 3' is its E04), so the
	entry-local number is never used. The episode is matched by TVDB season/episode, accepted only when the mapping names
	this TMDb show and the air dates agree within 2 days (when both are known) -- a TVDB season TMDb numbers differently
	fails one of the two. Only aid + eid are returned: the mapping's AniList / Kitsu ids belong to the wider entry."""
	try: mal_id, tmdb_id, season, episode = int(mal_id), int(tmdb_id), int(season), int(episode)
	except (TypeError, ValueError): return {}
	maps = _maps('mal_id', mal_id)
	if not maps or not maps.get('anidb'): return {}
	try:
		if int(maps.get('tmdb') or 0) != tmdb_id: return {}
	except (TypeError, ValueError): return {}
	hit = (maps.get('se') or {}).get('%sx%s' % (season, episode))
	if not hit: return {}
	eid, their_date = hit
	if not air_dates_agree(their_date, air_date): return {}
	return {'aid': maps['anidb'], 'eid': eid}


def air_dates_agree(a, b, days=2):
	"""LOCAL PATCH 2026-10-10: two 'YYYY-MM-DD...' air dates within `days` of each other (ani.zip's are UTC, TMDb's local,
	so a day either way is normal). True when either is unknown -- a missing date is no evidence; False when unreadable."""
	if not a or not b: return True
	from datetime import date
	try: return abs((date(*map(int, str(a)[:10].split('-'))) - date(*map(int, str(b)[:10].split('-')))).days) <= days
	except (TypeError, ValueError): return False


def anizip_eid_air_date(anilist_id, eid):
	"""LOCAL PATCH 2026-10-10: ani.zip's air date for an eid of an AniList entry (from the cached lookup), or None."""
	try: anilist_id = int(anilist_id)
	except (TypeError, ValueError): return None
	maps = _maps('anilist_id', anilist_id)
	for their_eid, their_date in ((maps or {}).get('se') or {}).values():
		if their_eid == eid: return their_date or None
	return None


def anizip_entry_dates(anilist_id=None, anidb_id=None):
	"""LOCAL PATCH 2026-10-10: {entry-local episode number: 'YYYY-MM-DD' (UTC)} for one ani.zip entry, or {}. Asked in
	anizip_episode_ids' order (AniList id, then AniDB id) so it reads the answer that lookup already cached."""
	for key, value in (('anilist_id', anilist_id), ('anidb_id', anidb_id)):
		try: value = int(value)
		except (TypeError, ValueError): continue
		maps = _maps(key, value)
		if maps: return dict((int(k), v) for k, v in (maps.get('dates') or {}).items())
	return {}


def anizip_entry_titles(anilist_id=None, anidb_id=None):
	"""LOCAL PATCH 2026-10-17: {'titles': [en, x-jat], 'ep1_title', 'count'} for one ani.zip entry (the lookup
	anizip_entry_dates already cached), or {}."""
	for key, value in (('anilist_id', anilist_id), ('anidb_id', anidb_id)):
		try: value = int(value)
		except (TypeError, ValueError): continue
		maps = _maps(key, value)
		if maps: return {'titles': maps.get('titles') or [], 'cjk': maps.get('cjk') if isinstance(maps.get('cjk'), dict) else {}, 'ep1_title': maps.get('ep1_title') or '', 'count': maps.get('count') or 0}
	return {}


def anizip_whole_run_ids(tmdb_id, total_aired_eps):
	"""Ids for a show Fribb has no row for, but ONLY if one entry covers the whole run.

	LOCAL PATCH 2026-08-27. 16 anime in the current library have no Fribb cour row at
	all -- Naruto, Naruto Shippuden, Hunter x Hunter, Fairy Tail, One Piece and other
	long-runners. They therefore get no kitsu_id and no cour_episode, so the Kitsu
	paths in torrentio and comet never engage and they fall back to title searching,
	which is what this whole effort exists to avoid.

	ani.zip answers a themoviedb_id lookup for them and supplies the Kitsu id. The
	episode number to pair it with is the series-absolute one, which external.py
	already computes from TMDb's season_data for every anime.

	THE GUARD IS THE WHOLE POINT. An absolute number is only meaningful against an
	entry that covers the entire series; against a single cour it addresses a
	completely different episode. Comparing ani.zip's episode count with TMDb's total
	aired count separates the two cleanly, measured:

	    Naruto            220 vs 220   whole run  -> safe
	    Naruto Shippuden  500 vs 500   whole run  -> safe
	    Hunter x Hunter   148 vs 148   whole run  -> safe
	    Fairy Tail         26 vs 328   one cour   -> REJECTED
	    One Piece        1180 vs 1100  mismatch   -> REJECTED

	One Piece is arguably whole-run and is rejected anyway. That is the intended bias:
	a show left on the title-search path merely scrapes the way it always did, while a
	wrong guess here plays the wrong episode.

	Returns {} when there is no entry, no Kitsu id, or the counts disagree.
	"""
	if not tmdb_id: return {}
	try:
		tmdb_id, total_aired_eps = int(tmdb_id), int(total_aired_eps)
	except (TypeError, ValueError): return {}
	if total_aired_eps < 1: return {}
	maps = _maps('themoviedb_id', tmdb_id)
	if not maps or not maps.get('kitsu'): return {}
	count = maps.get('count') or 0
	# 5%, floored at 5 episodes: specials and recap numbering differ slightly between
	# TMDb and AniDB even for entries that genuinely cover the same run.
	if abs(count - total_aired_eps) > max(5, total_aired_eps * 0.05): return {}
	return {'kitsu': maps.get('kitsu'), 'mal': maps.get('mal'),
			'anilist': maps.get('anilist'), 'aid': maps.get('anidb'), 'count': count}
