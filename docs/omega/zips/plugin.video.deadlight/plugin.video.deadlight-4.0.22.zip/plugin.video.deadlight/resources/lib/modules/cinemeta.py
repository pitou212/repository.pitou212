# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-10-25 (4.0.5): the Stremio episode number of a date-released show, by air date.

	TMDb and Stremio number a daily show differently: Jeopardy! 2026-10-23 is TMDb S43E30 but Cinemeta (and so torrentio,
	comet, mediafusion and the other id-searched providers) S2026E177, so asking them for tt0159881:43:30 found nothing
	while tt0159881:2026:177 held the release. Both sides agree on the air date, so the date is the key.

	Cinemeta's 'released' is the US air time written at a fixed UTC-8 (no daylight saving): Jeopardy! 03:00Z (7 pm),
	The Daily Show 07:00Z (11 pm), Fallon 07:30Z (11:30 pm), every episode -- so released - 8 h is the US air date.
	The meta is large (Jeopardy!: 7.5 MB, 9646 episodes), so only a date -> [season, episode] map of the last ~400 days is
	kept, in main_cache for a day, and fetched again at most hourly when asked for a date it does not hold yet.
	Season 0 is skipped (a special can share a day with an episode: 0:71 and 2026:176 on 10-22).

	Red Light's native_torrents._cinemeta_map_episode solves a different case (no IMDb id: maps the season only).
"""
import time
from datetime import datetime, timedelta, timezone
from caches.main_cache import main_cache
from modules.kodi_utils import logger, make_session

_META_URL = 'https://v3-cinemeta.strem.io/meta/series/%s.json'
_KEEP_DAYS = 400
_REFETCH_SECONDS = 3600
_session = make_session('https://v3-cinemeta.strem.io')

def _us_air_date(released):
	"""'2026-10-24T03:00:00.000Z' -> '2026-10-23'. Hand-parsed: datetime.strptime fails in Kodi after its first call."""
	try:
		r = str(released)
		stamp = datetime(int(r[0:4]), int(r[5:7]), int(r[8:10]), int(r[11:13] or 0), int(r[14:16] or 0))
		return (stamp - timedelta(hours=8)).strftime('%Y-%m-%d')
	except (TypeError, ValueError, IndexError): return ''

def _fetch(imdb_id):
	"""{air date: [[season, episode], ...]} for the last _KEEP_DAYS days and ahead, or None on any failure."""
	try:
		response = _session.get(_META_URL % imdb_id, timeout=8)
		if not response.ok: return None
		videos = (response.json().get('meta') or {}).get('videos') or []
	except Exception as e:
		logger('cinemeta', '%s: fetch failed: %s' % (imdb_id, type(e).__name__))
		return None
	cutoff = (datetime.now(timezone.utc) - timedelta(days=_KEEP_DAYS)).strftime('%Y-%m-%d')   # LOCAL PATCH 2026-11-01: utcnow() is deprecated since Python 3.12 (Kodi 22 ships 3.14)
	dates = {}
	for v in videos:
		try: season, episode = int(v.get('season')), int(v.get('episode'))
		except (TypeError, ValueError): continue
		if season <= 0: continue
		day = _us_air_date(v.get('released') or v.get('firstAired') or '')
		if day and day >= cutoff: dates.setdefault(day, []).append([season, episode])
	for pairs in dates.values(): pairs.sort()
	return dates

def daily_episode(imdb_id, air_date):
	"""(season, episode) as strings in Stremio's numbering for the episode that aired on air_date ('YYYY-MM-DD'), or None.
	Two episodes on one day: the first (lower) one, logged."""
	if not imdb_id or not str(imdb_id).startswith('tt') or len(str(air_date or '')) < 10: return None
	air_date = str(air_date)[:10]
	key = 'cinemeta_dates_%s' % imdb_id
	cached = main_cache.get(key)
	if not isinstance(cached, dict) or (air_date not in (cached.get('dates') or {}) and time.time() - cached.get('ts', 0) > _REFETCH_SECONDS):
		dates = _fetch(imdb_id)
		# a failed fetch is stamped too (the older map kept), so a down Cinemeta is asked again in an hour, not every scrape
		cached = {'ts': int(time.time()), 'dates': dates if dates is not None else ((cached or {}).get('dates') or {})}
		main_cache.set(key, cached, expiration=24)
	pairs = ((cached or {}).get('dates') or {}).get(air_date)
	if not pairs: return None
	if len(pairs) > 1: logger('cinemeta', '%s %s: %d episodes that day, using S%sE%s' % (imdb_id, air_date, len(pairs), pairs[0][0], pairs[0][1]))
	return str(pairs[0][0]), str(pairs[0][1])


# LOCAL PATCH 2026-11-03: a SPECIAL's number in Stremio's (= TVDB's) numbering, which release groups use. TMDb and TVDB number
# specials independently: Steins;Gate 0's 'Valentine's of Crystal Polymorphism' OVA (2018-12-21) is TMDb S0E1 but TVDB /
# Cinemeta S0E2 -- their S0E1 is the 2015 'Open the Missing Link - Divide By Zero', so a scrape for S00E01 found and played
# that instead. And TVDB files some of TMDb's specials as REGULAR episodes: Monogatari's 'Tsubasa Cat (3)-(5)' (TMDb
# S0E2-4) are TVDB S01E13-15, Owarimonogatari's second season (TMDb S0E35-41) is TVDB S05E01-07.
# Matched by the TVDB episode id first (an exact join, any season), then -- season 0 only -- by title (punctuation dropped:
# ' -Bittersweet Intermedio-' vs ': Bittersweet Intermedio'; or one title inside the other, once), then by date (ONE special
# within a day of TMDb's; Cinemeta dated the OVA 2018-12-20). Anything less certain: None, and TMDb's number stands.
# Cached a day per show.
def _norm_title(text):
	return ''.join(ch for ch in str(text or '').lower() if ch.isalnum())

def _fetch_numbering(imdb_id):
	"""[[season, episode, 'YYYY-MM-DD', title, tvdb_id], ...] of every Cinemeta episode, or None on any failure."""
	try:
		response = _session.get(_META_URL % imdb_id, timeout=8)
		if not response.ok: return None
		videos = (response.json().get('meta') or {}).get('videos') or []
	except Exception as e:
		logger('cinemeta', '%s: numbering fetch failed: %s' % (imdb_id, type(e).__name__))
		return None
	out = []
	for v in videos:
		try:
			out.append([int(v.get('season')), int(v.get('episode')), str(v.get('released') or v.get('firstAired') or '')[:10],
						v.get('name') or v.get('title') or '', int(v.get('tvdb_id') or 0)])
		except (TypeError, ValueError): continue
	return out

def _numbering(imdb_id):
	key = 'cinemeta_numbering_%s' % imdb_id
	videos = main_cache.get(key)
	if not isinstance(videos, list):
		videos = _fetch_numbering(imdb_id)
		if videos is None: return None
		main_cache.set(key, videos, expiration=24)
	return videos

# LOCAL PATCH 2026-11-05: any episode's number in Stremio's numbering, by its TVDB episode id only (an exact join, or None).
# The Stremio addons (HDHub, pengu.uk) are asked tt:season:episode in Cinemeta's numbering: MASHLE TMDb S1E13 (TMDb files both
# cours as one season) = tvdb 10213859 = tt21209804:2:1. Asked with TMDb's 1:13 they answered 0 / timed out.
def stremio_episode(imdb_id, tvdb_id):
	if not imdb_id or not str(imdb_id).startswith('tt') or not tvdb_id: return None
	videos = _numbering(imdb_id)
	by_id = [v for v in (videos or []) if v[4] == int(tvdb_id)]
	return (int(by_id[0][0]), int(by_id[0][1])) if len(by_id) == 1 else None

def special_episode(imdb_id, air_date, title, tvdb_id=None):
	"""(season, episode) as strings in Stremio's numbering for a TMDb special, or None. First by the TVDB episode id TMDb
	records for it (apis.tmdb_api.episode_tvdb_id), which Cinemeta's videos carry too -- the only rule that settles
	Monogatari's four 'Tsubasa Family' parts sharing one day (TMDb S0E7 = tvdb 4450836 = S0E4), and the only one that finds
	a special TVDB numbers as a regular episode. Then title, then date, among season 0."""
	if not imdb_id or not str(imdb_id).startswith('tt'): return None
	videos = _numbering(imdb_id)
	if videos is None: return None
	def _pair(v): return str(v[0]), str(v[1])
	if tvdb_id:
		by_id = [v for v in videos if v[4] == int(tvdb_id)]
		if len(by_id) == 1: return _pair(by_id[0])
	specials = [v for v in videos if v[0] == 0]
	want = _norm_title(title)
	if want:
		named = [v for v in specials if _norm_title(v[3]) == want]
		if len(named) == 1: return _pair(named[0])
		# one title inside the other, once: TMDb 'Koyomimonogatari: Koyomi Stone' is Cinemeta's 'Koyomi Stone' (S0E21; the date
		# alone was ambiguous -- Kizumonogatari I is dated a day earlier). Without it TMDb S0E22 stayed 22 while S0E23 'Koyomi
		# Flower' mapped to 22 too: two specials searched as one.
		def _inside(v):
			got = _norm_title(v[3])
			return len(got) >= 6 and len(want) >= 6 and (got in want or want in got)
		named = [v for v in specials if _inside(v)]
		if len(named) == 1: return _pair(named[0])
	try:
		day = datetime(int(air_date[0:4]), int(air_date[5:7]), int(air_date[8:10]))
		def _near(v):
			try: return abs((datetime(int(v[2][0:4]), int(v[2][5:7]), int(v[2][8:10])) - day).days) <= 1
			except (TypeError, ValueError, IndexError): return False
		near = [v for v in specials if _near(v)]
	except (TypeError, ValueError, IndexError): return None
	return _pair(near[0]) if len(near) == 1 else None
