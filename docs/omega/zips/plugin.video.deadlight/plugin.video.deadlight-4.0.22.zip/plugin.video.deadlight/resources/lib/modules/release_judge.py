# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-11-04: the anime RELEASE JUDGE -- is this release the episode on the card? One answer for every
	provider, with the reason.

	WHY
	Today each provider judges its own rows, each its own way: animetosho runs cour_match (trusting its eid) and its own
	pack checks, nekobt reads the file listing, seadex keeps its own matcher, comet has comet_kitsu_reject, torrentio its
	Kitsu path, http_streams _drop_other_episodes; then external._drop_not_episodes applies four more checks to all of
	them. The same question asked in seven places drifts: a fix lands in the provider where the bug showed (the Off &
	Monster rows were Comet's) and the others keep the hole.

	THE CHECKS, in order -- the first that fires is the reason:
	  1-4  external._drop_not_episodes' four, unchanged: not an episode (anime_utils.anime_not_episode: compilations,
	       creditless OP/ED, manga volumes), another TMDb season by its NAME, another season by its YEAR, specials only.
	  5    a single episode must hold THIS episode in a numbering the card knows (anime_utils.cour_match: absolute, the
	       release season + its episode, the cour episode, the cour part, another cour's words) -- the check animetosho
	       alone applied. A row found by id (animetosho's eid, seadex's AniList pick) is trusted: its name is only read for
	       a contradiction (cour_match trust_id), as animetosho does.
	  6    a pack must not name another cour (anime_utils.names_foreign_cour) -- animetosho's pack check.

	PHASE 3 (2026-11-04) -- shadow, over 1681 rows cached in external.db (addon_patches/harness/judge_shadow_check.py). The
	first run would have dropped 53, and was wrong twice: check 5 without trust_id read every 'Tokyo Revengers - Seiya
	Kessen-hen - 01' (S1E25, cour 2) as cour 1, and check 6 dropped a 'Season 1 2 3' batch that names the arcs it holds.
	Both fixed (below), and the reader bug under a third ('1x02' read as episode 1, anime_utils._extract_meta). Then 21,
	every one another season / arc or episode.
	PHASE 4 (2026-11-04, now) -- external._drop_not_episodes IS the judge (its four checks are 1-4 here, unchanged; the
	reasons are logged as 'anime.not_episode'). The providers' OWN name checks stay: they run before the cache on rows the
	judge never sees, so whether the judge covers each of them can only be measured by having the providers hand it the rows
	they drop -- the next step, provider by provider, each removal checked against the corpus.

	PHASE 4b, provider by provider (_TAKEN_OVER). 2026-11-04 COMET: its anime TV checks removed; its rules apply here to its rows
	(_taken_over_numbers). Measured live over 12 hard episodes (addon_patches/harness/provider_gap_check.py, provider_survivors.py):
	old comet vs new comet through the judge +15 / -0, every one a right episode its check_title refused. The same day check 5 for
	the other title providers became _contradicts (drop only on what a name READS): cour_match, even with trust_id, refused names
	it could not read (meteor's 'Bakemonogatari.13.mkv'), live since phase 4a.
	2026-11-04 TORRENTIO + METEOR: their anime TV checks removed; their rows carry the file they picked (row['file_name'], from
	provider_base._keep_file_name) and face their former rules here ('stremio'). Old module vs new through the judge: torrentio
	+0 / -0, meteor +6 / -0 (six right 'Stone Ocean 25' rows for S5E25).
	2026-11-04 ANIMETOSHO: its three NAME checks on eid rows are here (checks 5 / 6 for id rows, the whole-run one) -- old vs new
	+0 / -0, after the collection rule in _own_words (without it 8 TYBW part 2 / 3 batches reached part 1). Its aid reject and
	pack range / sibling / part checks read row ids and file counts and stay. NEKOBT and SEADEX make no name checks (nekoBT's
	own episode mapping, the pack listing) -- nothing to move. HTTP_STREAMS' _drop_other_episodes stays (see its note).
	Cleanup the same day: build_reject_words moved here from external.py (snapshot identical), and external's
	foreign_season_tokens built from _other_season_words (one list; Monogatari lost 'monogatari', its own title word).
"""
import re
from modules import kodi_utils

# rows whose provider found them by an id, not a name -- the name is only read for a contradiction
_ID_PROVIDERS = ('animetosho', 'seadex')


# LOCAL PATCH 2026-11-06: words an alternative adaptation's title may carry that release names use for anything (build_reject_words)
_GENERIC_WORDS = frozenset(('first', 'second', 'third', 'last', 'final', 'extra', 'extras', 'special', 'specials', 'movie', 'movies',
	'film', 'films', 'complete', 'collection', 'batch', 'edition', 'version', 'remake', 'origin', 'zero', 'part', 'season', 'series',
	'story', 'stories', 'chapter', 'episode', 'world', 'new', 'the', 'and'))


def _short_vowels(title):
	"""'Dr. STONE: Ryuusui' -> 'Dr. STONE: Ryusui', 'Bungou' -> 'Bungo': romaji long vowels (uu, ou, oo) written short, or None when
	the title has none."""
	import re
	if not title: return None
	short = re.sub(r'(?i)(?<=[a-z])(uu|ou|oo)', lambda m: m.group(1)[0], title)
	return short if short != title else None


def _colon_head(title):
	"""'JoJo no Kimyou na Bouken: Steel Ball Run' -> 'JoJo no Kimyou na Bouken': the part before the first ': ' when 2+ words stay,
	else None. 2026-11-07 (phase 5d)."""
	if not title or ': ' not in title: return None
	head = title.split(': ', 1)[0].strip()
	return head if len(head.split()) >= 2 else None


def _subpart_off(title):
	"""'JoJo no Kimyou na Bouken: Steel Ball Run - 2nd & 3rd STAGE' -> 'JoJo no Kimyou na Bouken: Steel Ball Run': a romaji title
	with its part after the LAST ' - ' cut, when 3+ words stay; else None. 2026-11-07 (phase 5a)."""
	if not title or ' - ' not in title: return None
	main = title.rsplit(' - ', 1)[0].strip()
	return main if len(main.split()) >= 3 else None


def _season_marker_off(title):
	"""'Bungou Stray Dogs 5th Season' -> 'Bungou Stray Dogs' (also 'Season 2', 'S2', 'Part 2', 'Cour 2', a closing roman numeral);
	None when the title carries no marker or too little would be left."""
	import re
	if not title: return None
	bare = re.sub(r'(?i)[\s:.-]+(?:\d+(?:st|nd|rd|th)\s+season|season\s*\d+|s\d+|part\s*\d+|cour\s*\d+|(?:ii|iii|iv|v|vi)(?![a-z]))\s*$', '', title).strip()
	return bare if bare != title and len(bare.split()) >= 2 else None


class Context(object):
	"""What the judge needs about the episode, worked out once per provider batch."""
	__slots__ = ('data', 'titles', 'season', 'special_titles', 'other_seasons', 'numbered', 'bare')

	def __init__(self, data, title, season, season_names, other_seasons):
		from magneto.modules.anime_utils import alias_titles
		self.data, self.season, self.other_seasons = data, season, other_seasons or []
		self.titles = [title] + list(alias_titles(data) or [])
		# LOCAL PATCH 2026-11-07 (phase 5d): every alias with its long vowels written short too, as the romaji title below: TMDb lists
		# 'JoJo no Kimyou na Bouken' for JoJo, and 'JoJo.no.Kimyo.na.Boken.S06E04' (Steel Ball Run E4) was 'another show'
		for _t in list(self.titles):
			_s = _short_vowels(_t)
			if _s and _s not in self.titles: self.titles.append(_s)
		# LOCAL PATCH 2026-11-04: and the cour's romaji title, so a name written in it can be read: 'Shigatsu.wa.Kimi.no.Uso.01' is
		# Your Lie in April episode 1, which cour_match could not read and AnimeTosho's eid row was dropped (Kodi log 14:16)
		if data.get('mal_title') and data['mal_title'] not in self.titles: self.titles.append(data['mal_title'])
		# LOCAL PATCH 2026-11-06: and the romaji with its long vowels written short, as most release names do: AniList's 'Dr. STONE:
		# Ryuusui' is 'Dr. STONE - Ryusui' / 'Dr.Stone.Ryusui.2022' in every release, which were 'another show'
		_short = _short_vowels(data.get('mal_title'))
		if _short and _short not in self.titles: self.titles.append(_short)
		# LOCAL PATCH 2026-11-07 (phase 5a): and the romaji without a sub-part after ' - ', which release names leave out: AniList's
		# 'JoJo no Kimyou na Bouken: Steel Ball Run - 2nd & 3rd STAGE' is 'JoJo.no.Kimyou.na.Bouken:.Steel.Ball.Run.-.04' in releases
		_main = _subpart_off(data.get('mal_title'))
		if _main and _main not in self.titles: self.titles.append(_main)
		# LOCAL PATCH 2026-11-07 (phase 5d): and the part before a colon (the franchise), with long vowels short, as a special's own
		# titles already are: 'JoJo no Kimyou na Bouken: Steel Ball Run ...' -> 'JoJo no Kimyou na Bouken' / 'JoJo no Kimyo na Boken'
		# ('JoJo.no.Kimyo.na.Boken.S06E04' was 'another show'). 2+ words only, so 'Re:Zero kara ...' gives nothing.
		for _t in [data.get('mal_title')] + list(data.get('entry_titles') or []):
			_head = _colon_head(_t)
			for _v in (_head, _short_vowels(_head)):
				if _v and _v not in self.titles: self.titles.append(_v)
		# LOCAL PATCH 2026-11-06: a special's own entry titles (episode_card._special_judge_facts): it has no Fribb row, so no mal_title
		for _t in data.get('special_titles') or []:
			if _t not in self.titles: self.titles.append(_t)
		# LOCAL PATCH 2026-11-07 (phase 5a): a new-season entry's own AniDB titles (episode_card._new_season), with long vowels short
		for _t in data.get('entry_titles') or []:
			for _v in (_t, _short_vowels(_t)):
				if _v and _v not in self.titles: self.titles.append(_v)
		# LOCAL PATCH 2026-11-06: and that title without its season marker, for the show check of an id-scoped provider only
		# (judge, 'stremio': torrentio / meteor). A later cour's MAL title carries one ('Bungou Stray Dogs 5th Season') and TMDb spells
		# the show 'Bungo', so 'Bungou.Stray.Dogs.S05E01' and 'Bungou.Stray.Dogs.-.50' were 'another show' for every cour past the
		# first (whose MAL title is plain 'Bungou Stray Dogs'); Re:ZERO S1E27 gains 4 right rows the same way. Not for comet: its
		# Kitsu answers span the franchise, and the bare title let through 23 Re:ZERO rows the title had kept out -- a doujin .zip,
		# .ass subtitles, an OST .rar, part-2 episodes 39-49 (provider_gap_check, 12 cases, old vs new).
		self.bare = _season_marker_off(data.get('mal_title'))
		if self.bare in self.titles: self.bare = None
		# specials are judged only for a regular season whose TMDb name is not itself an OVA / specials run
		self.special_titles = self.titles + list(season_names or []) if season > 0 else None
		# check 5 needs a numbering to hold the name against: a release season, or an absolute number
		self.numbered = data.get('cour_season') is not None or bool(data.get('absolute_episode'))


# Providers whose OWN name checks the judge has taken over (phase 4b, one at a time). Their rows face that provider's former
# rules here, and only theirs: comet's rules read rows the way comet's Kitsu answers are named (as nyaa's), and run over
# torrentio's and meteor's rows they dropped dozens of right ones -- the Bakemonogatari / Steins;Gate 0 BD packs, meteor's
# 'Bakemonogatari.13.mkv' and 'Tokyo Revengers Seiya Kessen Hen 01' (the 4b check, 2026-11-04). Every other provider keeps the
# phase-4a judge below unchanged.
# provider -> whose former rules: 'comet' (comet's Kitsu-answer rules), 'stremio' (torrentio's and meteor's: an id-scoped answer,
# so the show, then the FILE the provider picked -- provider_base.anime_file_reject / anime_pack_reject)
_TAKEN_OVER = {'comet': 'comet', 'torrentio': 'stremio', 'meteor': 'stremio',
	'mediafusion': 'stremio'}   # 2026-11-07 (phase 2b): its check_title for anime TV moved here, see mediafusion._episode_ok

# LOCAL PATCH 2026-11-07 (anime core plan phase 2a): the judge picks its rules by HOW A ROW WAS FOUND, not by which provider
# brought it. Same four profiles as the two tables above, named for what they mean:
#   episode_id   -- found by the episode's own id (AnimeTosho's AniDB eid / aid, SeaDex's pick): trusted, dropped only on a
#                   contradiction (the by_id rules)
#   series_id    -- the provider was asked for the series + episode and picked the file (torrentio, meteor): the show, then the
#                   picked file (the 'stremio' rules)
#   franchise_id -- the answer spans the franchise (comet's kitsu:<id>:<ep>): strict (the 'comet' rules)
#   title_search -- found by title (nekobt, mediafusion, every other provider): only what the name reads against the episode
# A provider that finds rows more than one way may tag each row (row['found_by']); otherwise its profile below applies.
FOUND_BY_PROFILES = ('episode_id', 'series_id', 'franchise_id', 'title_search')
_PROVIDER_FOUND_BY = dict([(p, 'episode_id') for p in _ID_PROVIDERS] + [(p, {'stremio': 'series_id', 'comet': 'franchise_id'}[t])
	for p, t in _TAKEN_OVER.items()])
_PROFILE_RULES = {'series_id': 'stremio', 'franchise_id': 'comet'}


def found_by(row, provider):
	"""The profile a row is judged by: its own tag, else its provider's, else title_search."""
	tag = row.get('found_by')
	return tag if tag in FOUND_BY_PROFILES else _PROVIDER_FOUND_BY.get(provider, 'title_search')
# stremio_junk reasons that hold for a PACK's name too: a file no video pack is, or a word no video pack carries ('Drama.CD',
# 'Scanlated' manga -- not 'Scans', which a BD collection's name may list among its extras)
_PACK_JUNK = ('not a video', 'novel', 'epub', 'drama.cd', 'scanlat', 'cue')   # 'cue': 'BLEACH OP&ED Remix Collection [CD][FLAC+CUE+LOG]'


def judge(row, provider, ctx):
	"""(keep, reason) for one source row. reason is None when kept. `provider` is the provider's name or, since phase 2a, a
	found_by profile (FOUND_BY_PROFILES) -- a name is turned into the row's profile by found_by()."""
	import re
	from magneto.modules.anime_utils import anime_not_episode, other_season_year, specials_only, cour_match, names_foreign_cour, title_guard, stremio_junk, other_show_year
	name = row.get('name') or ''
	package = row.get('package')
	data = ctx.data
	profile = provider if provider in FOUND_BY_PROFILES else found_by(row, provider)
	by_id = profile == 'episode_id'
	taken = _PROFILE_RULES.get(profile)
	# another cour's CJK title in the name or the file (data['foreign_cjk'], build_reject_words): '[NC-Raws] BLEACH 死神 千年血戰篇 - 01'
	# is Thousand-Year Blood War episode 1 -- comet listed it for Bleach S1E1; the cleaned name ('BLEACH...-.01') had lost the CJK
	cjk = _foreign_cjk_hit(name, row.get('file_name'), data)
	if cjk: return False, 'another cour by its name (%s)' % cjk
	# 0 (4b): a taken-over provider's row must be this show -- comet's former title_guard / stremio_junk / other_show_year. The
	# gap run over 12 live comet scrapes found 1482 rows comet refused that the judge kept: other series (Property Brothers, The
	# Snoopy Show for One Piece), the 2023 live-action One Piece, Steins;Gate (2011) for Steins;Gate 0, soundtracks, .ass
	# subtitles, an epub. The show check covers packs too: comet tags a name with no episode number as a batch (tag_batch) after
	# its title_guard ran, so without it '11.22.63.S01' reached the judge as a Naruto 'season' pack. The junk check covers a pack
	# only when its NAME is a file no video pack is (an archive / image / ebook: '...(Bakemonogatari).zip', a poster .JPG, a light
	# novel), not by the word list -- 'Scans' in a 'Monogatari Series Collection' BD pack's name.
	if taken == 'stremio':
		# torrentio's and meteor's former checks: the show (title_guard -- their id-mode check; the IMDb path's check_title is
		# replaced by it plus the number checks below), then the FILE the provider picked inside the torrent (row['file_name'],
		# provider_base._keep_file_name): junk, a later season, another cour's markers, another show's year
		from magneto.modules.provider_base import anime_file_reject, anime_pack_reject
		if not _is_this_show(name, ctx, bare=True): return False, 'another show'
		file_name = row.get('file_name') or ''
		# LOCAL PATCH 2026-11-07: not when the row states one of the card's own pairs: in a TVDB-order episode group Bungou Stray Dogs
		# TMDb E50 is S3E14, and 'Bungo.Stray.Dogs.S03E14' read as release season 3's markers (another cour)
		if not package and anime_file_reject(file_name, name, ctx.titles[0], data) and not _states_own_pair(file_name or name, data, ctx.titles):
			return False, 'the file (junk / later season / another cour or show)'
		# LOCAL PATCH 2026-11-07: unless the FILE the provider picked states this episode's own pair and nothing contradicts it -- a
		# collection names its other works too: torrentio's 'Fate.Stay.Night.+.OVAs.+.Movies ... Unlimited.Blade.Works.Movie |
		# Heaven's.Feel' picked 'FateStay Night - S01E01 - The First Day.mkv' for Fate/stay night (2006) S1E1
		if package and anime_pack_reject(name, file_name, package, data) and not (file_name and _states_own_pair(file_name, data, ctx.titles)):
			return False, 'the pack (later season / another cour or show)'
		# 2026-11-07: and the picked FILE must be an episode at all (creditless OP / ED, PV, menu, recap -- check 1 reads only the
		# release name): MediaFusion picked '[DB]Tokyo Revengers Seiya Kessen-hen_-_NCOP_(...)' inside a Season 1-3 batch for S1E25
		if not package and file_name:
			why = anime_not_episode(file_name, ctx.titles)
			if why: return False, 'the file: %s' % why
		# LOCAL PATCH 2026-11-07 (phase 2b): and what the picked file's NAME reads against this episode, as a single release's name
		# is read (_contradicts) -- MediaFusion picked '[MTBB] Owarimonogatari S1 - 13' inside 'Monogatari.Series.(BD.1080p)' for
		# Monogatari S1E13 and '[Anime Time] Black Clover - 001.mkv' inside an S01-S04 batch for Black Clover S2E1. Only when the
		# release's own name states no episode (a batch / season name): a name that does is read by check 5 below, and its file may
		# count differently -- torrentio's 'Bungou.Stray.Dogs.Season.5.-.01(51)' is TMDb E50, its file '[LoliHouse] ... - 51' counts
		# the OVA (measured old vs new, 24 cases: that row was the only one the file check cost torrentio / meteor).
		if not package and file_name and ctx.numbered and not _names_an_episode(name):
			why = _contradicts(file_name, data, ctx.titles)
			if why: return False, 'the file: %s' % why
	if taken == 'comet':
		if not _is_this_show(name, ctx): return False, 'another show'
		junk = stremio_junk(name, ctx.titles)
		if junk and package and not any(w in str(junk).lower() for w in _PACK_JUNK): junk = None
		if junk: return False, junk if isinstance(junk, str) else 'not a video'
		year = other_show_year(name, data)
		if year: return False, 'another show (%s)' % year if isinstance(year, str) else 'another show (year)'
	# 1-4: external._drop_not_episodes' four checks. A SPECIAL's own file found by id is not a re-edit of it: Monogatari's TMDb
	# S0E1 'Ghostory (Monstory)' is Bakemonogatari's Episode 5.5 recap (TVDB 3406651), AnimeTosho's eid 106165 returned exactly
	# 'Bakemonogatari_5.5_Special_Recap', and check 1 dropped it as 're-edit (Recap)' (Kodi log 2026-11-04 13:09).
	if not (ctx.season == 0 and by_id and not package):
		why = anime_not_episode(name, ctx.titles)
		if why: return False, why
	if ctx.other_seasons and not package:
		words = set(re.findall(r'[a-z0-9]+', name.lower()))
		hit = next((n for n, ws in ctx.other_seasons if ws <= words), None)
		# unless it names THIS cour too: 'Bakemonogatari+Nisemonogatari.[Complete]' holds Bakemonogatari (the 4b check, 2026-11-04)
		if hit is not None and not _own_words(name, data): return False, 'season %s by its name' % hit
	other = other_season_year(name, data)
	if other: return False, 'season %s by its year' % other
	if ctx.special_titles is not None:
		sp = specials_only(name, ctx.special_titles)
		if sp: return False, 'specials (%s)' % sp
	# LOCAL PATCH 2026-11-06: a special's single release found by title must not name another episode (_special_contradicts)
	if not package and not by_id and data.get('special_numbers'):
		why = _special_contradicts(name, data)
		if why: return False, why
	if taken == 'comet':
		why = _taken_over_numbers(name, package, data, ctx)
		if why: return False, why
	elif not package and by_id and data.get('whole_run') and _whole_run_off(name, data, ctx.titles):
		# a whole-run show's id row must STATE its absolute number: AnimeTosho's eid index for One Piece files arc-relative
		# releases under the same eid -- ?eid=977 (episode 10) carried 'Gyojin Tou-hen - 10' and 'One Piece Log: Fish-Man Island
		# Saga - 10' beside one real episode 10 (animetosho's own check from 2026-09-23, here since 4b)
		return False, 'not this episode (whole run: names %s, not %s)' % _whole_run_off(name, data, ctx.titles)
	elif not package and ctx.numbered and by_id:
		# 5 (a row found by id): its name must not contradict this episode's numbers -- cour_match's trust_id reading, the one
		# animetosho applies to its own eid rows
		if not cour_match(name, cour_season=data.get('cour_season'), cour_episode=data.get('cour_episode'),
						absolute_episode=data.get('absolute_episode'), season_episode=data.get('season_episode'),
						cour_part=data.get('cour_part'), foreign_tokens=data.get('foreign_cour_tokens'), titles=ctx.titles,
						trust_id=True, cour_part_count=data.get('cour_part_count')) and not _names_card_pair(name, data):
			return False, 'not this episode by its numbers'
	elif not package and ctx.numbered:
		# 5 (a title-searching provider not taken over): drop only on what the name READS against this episode -- another cour's
		# words, a range without it, an episode number that is none of its numbers, cour-1 numbering for a later cour. A name read
		# as nothing contradicts nothing. cour_match, even with trust_id, refused names it could not read: meteor's
		# 'Bakemonogatari.13.mkv' x12 and torrentio's 'Bakemonogatari.Ep9-13' / 'One.Piece.S01E1097-E1108' for the episode they
		# hold (the 4b check, 2026-11-04) -- live since phase 4a that day, which the cached rows had not shown.
		why = _contradicts(name, data, ctx.titles)
		# LOCAL PATCH 2026-11-07: a name stating NO episode is the torrent's (a pack's) name; the provider's picked file says which
		# episode the row plays. MediaFusion's 'ReLIFE.S01+OVAs.(COMPLETE)' picked '[RigAV1] ReLIFE - S00E01' for S0E1 (S00E02 /
		# S00E03 for the others) and was dropped as 'names S1 E-, not S00E01'. Only when the file names an episode and agrees.
		if why:
			fn = row.get('file_name') or ''
			if fn and not _names_an_episode(name) and _names_an_episode(fn) and not _contradicts(fn, data, ctx.titles): why = None
		if why: return False, why
	# 2026-11-07 (phase 2d): AnimeTosho's own pack rejects, which ran in the provider before every check here
	if package and by_id and row.get('pack_facts'):
		why = _id_pack_reject(row, data)
		if why: return False, why
	# an id provider's PACK that declares other seasons only: AnimeTosho's pack query trusts the AniDB id, and Bleach is ONE
	# 366-episode AniDB entry, so Disney+'s 'BLEACH.S14 [DSNP]' / 'S09' / 'S10' came back for Bleach S1E1. A pack that also
	# states this season ('Bleach (Season 1 & 2)') stays; a show with no release season (a whole-run entry) is not asked.
	if package and by_id and data.get('cour_season') is not None:
		declared = _declared_seasons(name)
		# this cour's own words count as declaring it: 'BLEACH: Thousand-Year Blood War S01 [DSNP]' is TYBW's own season 1, TVDB 17
		# (another part's batch still goes by its own words, check 6)
		from magneto.modules.anime_utils import own_cour_words
		from magneto.modules.anime_utils import _card_pair
		# LOCAL PATCH 2026-11-06: nor when a declared season is the card's own (Bungou Stray Dogs TMDb E50: 'Season 5' BD pack, the
		# release numbering, against cour_season 3, TVDB's; anime_utils._card_pair)
		if declared and data['cour_season'] not in declared and not own_cour_words(name, data.get('own_cour_tokens')) and not _card_pair(set(declared), (), data):
			return False, 'another season (the pack declares %s)' % ','.join(str(x) for x in sorted(declared))
		# with this cour's own words, a declared season is the sub-series' own PART number: 'Bleach Thousand Year Blood War S02 2023'
		# is TYBW part 2, offered by AnimeTosho for part 1 (its 'S01' stays for part 1)
		try: _part, _count = int(data.get('cour_part') or 0), int(data.get('cour_part_count') or 0)
		except (TypeError, ValueError): _part = _count = 0
		if declared and _part and _count > 1 and _part not in declared and data['cour_season'] not in declared and all(x <= _count for x in declared):
			return False, 'another part (the pack declares %s, this is part %d)' % (','.join(str(x) for x in sorted(declared)), _part)
	# an id provider's pack whose name states an episode range without this episode: 'Bleach.[2004-2012].[001-366].[JPBD]' (the
	# original series, under TYBW's AniDB id) holds 1-366, not TYBW episode 1 = absolute 367. The range is held against the
	# absolute number unless the name states this season (_wanted_numbers), so a cour-relative '1' does not pass it.
	if package and by_id:
		span = _episode_range(name) or _bare_range(name)
		wanted = _wanted_numbers(data, name)
		if span and wanted and not any(span[0] <= w <= span[1] for w in wanted):
			return False, 'a range without this episode (%d-%d)' % span
		# 2026-11-07: and an explicit episode LIST ('- 06 & 07', '- 01 + 02'), read like a range: 'Re:Zero ... 2nd Season - 06 & 07 -
		# Batch' is no pack of S2E2 (_extract_meta reads only the 6; it went through once the entry's own titles stopped the sibling
		# check misfiring on 'hajimeru'), '... - 01 & 02 - Batch' is
		listed = _episode_list(name) if not span else None
		if listed and wanted and not (listed & wanted):
			return False, 'a list without this episode (%s)' % ', '.join(str(x) for x in sorted(listed))
		# a 'pack' whose name states exactly ONE episode is that episode (AnimeTosho calls any multi-file torrent a pack):
		# 'Bleach - S17E44 - The Perfect Crimson - 2160p' listed for TYBW S2E1 (S17E01)
		if not span:
			one = _single_episode(name)
			if one is not None and data.get('cour_season') is not None:
				ws = set(x for x in (data.get('season_episode'), data.get('cour_episode'), data.get('absolute_episode')) if x is not None)
				try: ws = set(int(x) for x in ws)
				except (TypeError, ValueError): ws = set()
				if one[0] == int(data['cour_season']) and ws and one[1] not in ws:
					return False, 'names episode S%02dE%02d' % one
	# 6: a pack naming another cour is that cour -- unless it also DECLARES this episode's release season: a multi-season batch
	# names the arcs it holds ('Tokyo.Revengers.(Season.1.2.3)...(Batch).(Tokyo.Revengers.Seiya.Kessen-hen.Tenjiku-hen)' holds
	# season 1 and was dropped for S1E1 by the first shadow run). 'Christmas Showdown Season 2 (S02)' still goes for season 1.
	# Nor when it names THIS cour's own words too: 'Monogatari.Series.Complete.(BDRip).[Bakemonogatari.-.Zoku.Owarimonogatari]'
	# holds Bakemonogatari.
	if package and names_foreign_cour(name, data.get('foreign_cour_tokens')) and not _own_words(name, data) and not _this_season_first(name, data):
		# a multi-season batch only (2+ seasons): TYBW's own 'BLEACH: Thousand-Year Blood War S01' declares 1 = original Bleach's
		# season by coincidence and listed for Bleach S1E1
		_dec = _declared_seasons(name)
		if data.get('cour_season') is None or len(_dec) < 2 or data.get('cour_season') not in _dec:
			return False, 'another cour by its name'
	return True, None


def _id_pack_reject(row, data):
	"""LOCAL PATCH 2026-11-07 (anime core plan phase 2d): AnimeTosho's four pack-NAME rejects, moved here unchanged from its
	sources_packs (same anime_utils readers, same order, same numbers). They read what only the provider knows, handed over on
	the row as row['pack_facts']: both names (title, torrent_name), the file count, whether the row came from THIS part's aid
	query ('own') and how many AniDB parts were merged ('parts'). The reason a pack is not this episode, or None.

	Why each one exists (the provider's measured notes, kept):
	- wanted numbers: any of cour / season / absolute (a cour pack says 1-12 while the absolute number is 41) -- but for a row
	  from a SIBLING part's query the cour-relative number is dropped: every part restarts at 1, and Re:ZERO S2 part 2 E1 let
	  part 1's '01~12' packs through on cour_episode 1 (of 22 packs a blanket drop rejected, 13 under part 2's own aid were
	  right, 9 under part 1's were not).
	- the part a pack NAMES outranks the aid it is filed under: AnimeTosho cross-files (TTGA / EMBER 'Season 2 Part 02' under
	  Re:ZERO part 1's aid, Peekaboo 'Part 1 - 1-13' under part 2's). A name stating only another part is that part; one stating
	  only ours is read in our numbering. Only for a merged split season and plausible part numbers (1..parts) -- JoJo's 'Part 6:
	  Stone Ocean' is the story arc.
	- a declared range without the episode (pack_excludes_episode, with the file count).
	- a pack spanning a sibling series (pack_names_sibling_series) against the show title + its aliases.
	- a pack naming another cour of this TMDb show: ?aid=2369 (Bleach 2004) returned 180 of 225 rows as Thousand-Year Blood War;
	  'Sennen Kessen Hen - 01 ~ 13' holds a 1, so only the name tells it apart."""
	facts = row.get('pack_facts')
	if not facts: return None
	from magneto.modules.anime_utils import pack_excludes_episode, pack_names_sibling_series, names_foreign_cour, alias_titles, _extract_meta, _clean_for_extract
	names, parts = facts.get('names') or [], int(facts.get('parts') or 1)
	def _num(key):
		try:
			v = data.get(key)
			return None if v is None else int(v)
		except (TypeError, ValueError): return None
	wanted = set(x for x in (_num('cour_episode'), _num('season_episode'), _num('absolute_episode')) if x is not None)
	wanted_sibling = set(x for x in (_num('season_episode'), _num('absolute_episode')) if x is not None) if parts > 1 else wanted
	w = wanted if facts.get('own') else wanted_sibling
	try: want_part = int(data.get('cour_part') or 0) or None
	except (TypeError, ValueError): want_part = None
	if want_part and parts > 1:
		declared = set()
		for n in names:
			try: declared |= set(int(p) for p in (_extract_meta(_clean_for_extract(n))[2] or ()))
			except Exception: continue
		if not (declared and all(1 <= p <= parts for p in declared)): declared = set()
		if declared and want_part not in declared:
			return 'another part (the pack names %s, this is part %d)' % (','.join(str(p) for p in sorted(declared)), want_part)
		if declared == set([want_part]): w = wanted
	if w and pack_excludes_episode(names, facts.get('num_files'), w): return 'a range without this episode'
	try: titles = [t for t in ([data.get('tvshowtitle')] + alias_titles(data)) if t]
	except Exception: titles = []
	# 2026-11-07: and the ENTRY's own titles (a special's, the cour's romaji, a new-season entry's) -- ReLIFE's finale 'Kanketsu-hen'
	# is TMDb S0E1-4 (AniDB 13123): its own packs 'Relife + Kanketsu-hen [BDRip]' were 'another series (kanketsu)' against the
	# show title alone
	titles += [t for t in list(data.get('special_titles') or []) + [data.get('mal_title')] + list(data.get('entry_titles') or []) if t]
	# 2026-11-07: neither when the name states this release season (or '<show> +') before the foreign words (_this_season_first)
	first = any(_this_season_first(n, data) for n in names)
	sibling = pack_names_sibling_series(names, titles)
	if sibling and not first: return 'another series (%s)' % sibling if isinstance(sibling, str) else 'another series'
	if names_foreign_cour(' | '.join(names), data.get('foreign_cour_tokens')) and not first: return 'another cour by its name'
	return None


def _this_season_first(name, data):
	"""2026-11-07: a name that names ANOTHER cour (foreign_cour_tokens) but states THIS release season, or '<show title> +', BEFORE
	the first foreign word -- a collection of this season plus that arc. ReLIFE S1E1: 'ReLIFE.(ReLIFE.+.Kanketsu-hen).[BD]',
	'ReLIFE.S01...-YURASUKA.(ReLIFE.Kanketsu-hen)', 'ReLIFE.S01+OVAs+Specials.(COMPLETE)...| ReLIFE: ...' hold season 1 (files
	'ReLIFE - 01', 'S01E01') and were 'another cour by its name'. Not 'BLEACH: Thousand-Year Blood War S01' for Bleach S1E1 (the
	foreign words come first: TYBW's own season 1), nor 'ReLIFE - Kanketsu-hen [1080p]' (no season, no '+')."""
	import re
	try: cs = int(data.get('cour_season'))
	except (TypeError, ValueError): return False
	low = (name or '').lower()
	hits = [m.start() for t in (data.get('foreign_cour_tokens') or []) if t
			for m in [re.search(r'(?<![a-z0-9])%s(?![a-z0-9])' % re.escape(str(t).lower()), low)] if m]
	if not hits: return False
	prefix = (name or '')[:min(hits)]
	# the part before must also be THIS show by one of its titles: 'Fate.strange.Fake.-.S01+Movie' declares S01 before 'movie' (a
	# Heaven's Feel word) for Fate/stay night 2006 -- another series, whose sibling check this exemption would otherwise silence
	from magneto.modules.anime_utils import alias_titles
	flat = re.sub(r'[^a-z0-9]+', '', prefix.lower())
	try: titles = [data.get('tvshowtitle')] + list(alias_titles(data) or [])
	except Exception: titles = [data.get('tvshowtitle')]
	titles += [data.get('mal_title')] + list(data.get('special_titles') or []) + list(data.get('entry_titles') or [])
	if not any(len(t) >= 4 and t in flat for t in (re.sub(r'[^a-z0-9]+', '', str(x or '').lower()) for x in titles)): return False
	if cs in _declared_seasons(prefix): return True
	return bool(re.search(r'[\s._(][+&][\s._]', prefix))


def _episode_list(name):
	"""The episode numbers a name lists after a dash -- '... - 06 & 07 - Batch', '... - 01 + 02 + 03' -- as a set of 2+, else None.
	2026-11-07. Only after ' - ' so a title's own '&' (or 'S01+S02' seasons) is not read as episodes."""
	import re
	m = re.search(r'(?:^|[\s._])-[\s._]+((?:\d{1,4})(?:[\s._]*[&+][\s._]*\d{1,4})+)(?![\d])', name or '')
	if not m: return None
	nums = set(int(x) for x in re.findall(r'\d{1,4}', m.group(1)))
	return nums if len(nums) >= 2 else None


def _names_an_episode(name):
	"""True when a release name states an episode number of its own (_extract_meta: 'S05E01', 'Season 5 - 01', '- 25'), False
	for a batch / season name ('Monogatari.Series.(BD.1080p)', 'Black.Clover.S01-S04'). 2026-11-07 (phase 2b)."""
	from magneto.modules.anime_utils import _extract_meta, _clean_for_extract
	try: return bool(_extract_meta(_clean_for_extract(name))[1])
	except Exception: return True


def _whole_run_off(name, data, titles):
	"""(number the name states, the absolute wanted) when a whole-run single states another number than its absolute, else None."""
	from magneto.modules.anime_utils import whole_run_episode
	try: want = int(data.get('absolute_episode'))
	except (TypeError, ValueError): return None
	got = whole_run_episode(name, titles)
	return None if got == want else (got, want)


_COLLECTION = None

_LEAD_TAGS = _EPISODE_WORD = None

def _special_contradicts(name, data):
	"""LOCAL PATCH 2026-11-06: why a single release of a SPECIAL names another episode, or None. A special has no cour numbers,
	so check 5 never ran: for Attack on Titan's 'The Final Chapters Special (1)' (TMDb S0E36 = TVDB S4E29 = AniDB 17303 ep 1 =
	absolute 88) 'Part 3 - 02', 'S04E30' and 'S04E28' were kept. A name with a season must state one of the special's pairs
	(TVDB's, TMDb's S0); one without, an episode that is the entry's, TVDB's or the absolute number. A name reading no number
	contradicts nothing."""
	from magneto.modules.anime_utils import _extract_meta, _clean_for_extract
	sn = data.get('special_numbers') or {}
	try: seasons, episodes = _extract_meta(_clean_for_extract(name))[:2]
	except Exception: return None
	import re
	# a number straight after 'Special' / 'OVA' / 'OAD' names that special ('The.Final.Chapters.Special.2' is Special (2)); any
	# other number in a name carrying the word is the group's own count -- Steins;Gate 0's Valentine OVA is
	# 'Steins;Gate 0 - 24 (OVA)' (AniDB's absolute is 25) -- and is not judged
	m = re.search(r'(?i)(?<![a-z])(?:special|ova|oad)[ ._-]*0*(\d{1,2})(?![\dp])', name)
	if m: seasons, episodes = None, {int(m.group(1))}
	elif not episodes or re.search(r'(?i)(?<![a-z])(?:specials?|ova|oad)(?![a-z])', name): return None
	episodes = set(int(e) for e in episodes)
	# TVDB's / Stremio's pair -- the one the releases use; TMDb's own only when there is none: Steins;Gate 0's OVA is TMDb S0E1
	# and TVDB S0E2, and 'S00E01' is the 2015 prologue
	pairs = [tuple(sn['pair'])] if sn.get('pair') else ([tuple(sn['tmdb'])] if sn.get('tmdb') else [])
	if seasons:
		seasons = set(int(s) for s in seasons)
		if any(s in seasons and e in episodes for s, e in pairs): return None
		return 'names S%s E%s, the special is %s' % (','.join(str(s) for s in sorted(seasons)), ','.join(str(e) for e in sorted(episodes)),
			' / '.join('S%02dE%02d' % p for p in pairs))
	bare = set(x for x in (sn.get('entry_episode'), sn.get('absolute')) if x) | set(e for _s, e in pairs[:1])
	if bare and not episodes & bare: return 'names episode %s, the special is %s' % (','.join(str(e) for e in sorted(episodes)),
		' / '.join(str(x) for x in sorted(bare)))
	return None


def _names_card_pair(name, data):
	"""LOCAL PATCH 2026-11-06: the name states a season AND an episode that are one of the card's own pairs (episode_candidates):
	AnimeTosho's eid rows for Bungou Stray Dogs TMDb E50 -- 'Season.5.-.01(51)', '5th Season - 01' -- failed cour_match against
	cour_season 3 (TVDB's numbering) though the card holds (5, 1)."""
	from magneto.modules.anime_utils import _extract_meta, _clean_for_extract, _card_pair
	try: seasons, episodes = _extract_meta(_clean_for_extract(name))[:2]
	except Exception: return False
	return bool(seasons and episodes) and _card_pair(set(seasons), set(episodes), data)


def _is_this_show(name, ctx, bare=False):
	"""anime_utils.title_guard, as comet / torrentio / meteor ran it, with two readings it lacked (Kodi log 2026-11-04 13:42-13:45,
	right rows dropped as 'another show' once the judge applied their rules to cached rows too -- fresh scrapes had refused them
	all along): the cour's romaji title is a candidate ('Bleach: Sennen Kessen Hen - 01 ~ 13' for TYBW, whose aliases held only
	'Bleach Thousand-Year Blood War'), and the name is also read without leading [group] tags and a bare 'Episode' before the
	number ('[Erai-raws] One Piece - 1100', 'One.Piece.Episode-.196.-.Emergency.Announcement!'). 'One Piece Episode of Sabo',
	'One Piece Film Red' and a name with no title at all are still another show."""
	import re
	from magneto.modules.anime_utils import title_guard
	global _LEAD_TAGS, _EPISODE_WORD
	if _LEAD_TAGS is None:
		_LEAD_TAGS = re.compile(r'^\s*(?:\[[^\]]*\]\s*)+')
		_EPISODE_WORD = re.compile(r'(?i)(?<![a-z])episode(?![ ._-]*of)[ ._-]*(?=\d)')
	titles = list(ctx.titles)
	if ctx.data.get('mal_title') and ctx.data['mal_title'] not in titles: titles.append(ctx.data['mal_title'])
	if bare and ctx.bare: titles.append(ctx.bare)   # LOCAL PATCH 2026-11-06: torrentio / meteor only, see Context
	if title_guard(name, titles[0], titles[1:]): return True
	read = _EPISODE_WORD.sub(' ', _LEAD_TAGS.sub('', name))
	return read != name and title_guard(read, titles[0], titles[1:])


def _own_words(name, data):
	"""The name carries this cour's own words (anime_utils.own_cour_words over data['own_cour_tokens']) AND says it is a
	collection (complete / collection / integrale / box / full series / '+' / '&'): 'Bakemonogatari+Nisemonogatari.[Complete]',
	'Monogatari.Series.Complete...[Bakemonogatari.-.Zoku.Owarimonogatari]' hold this cour beside others. Own words alone are not
	enough: the parts of one season share them -- 'Bleach: Sennen Kessen Hen - Ketsubetsu Tan - 01 ~ 13' (TYBW part 2) carries
	part 1's 'sennen kessen', and 8 such batches reached part 1 when AnimeTosho's own foreign-cour check went (4b, 2026-11-04)."""
	import re
	global _COLLECTION
	from magneto.modules.anime_utils import own_cour_words
	try:
		if not own_cour_words(name, data.get('own_cour_tokens')): return False
	except Exception: return False
	if _COLLECTION is None: _COLLECTION = re.compile(r'(?i)(?<![a-z])(?:complete|collection|integrale|box|full[ ._]series)(?![a-z])|[+&]')
	return bool(_COLLECTION.search(name))


_N_OF_M = re.compile(r'[\[\(][\s._]*(\d{1,4})[\s._]*of[\s._]*(\d{1,4})[\s._]*[\]\)]', re.I)
_PART_N = re.compile(r'(?:^|[\s._\-\[\(])(?:part|p)[\s._]?0*(\d{1,2})(?=$|[\s._\-\]\)])', re.I)
_COMPLETE = re.compile(r'(?:^|[\s._\-\[\(])(?:complete|completa|completo|completed|integrale|int[eé]grale)(?=$|[\s._\-\]\)])', re.I)
_YEAR = re.compile(r'(?:^|[^0-9])((?:19|20)\d{2})(?=[^0-9]|$)')
_VOLUME = re.compile(r'(?:^|[\s._\-\[\(])v(?:ol(?:ume)?)?[\s._]?\d', re.I)

# on the RAW name: the number straight after the season marker, then a separator, a bracket or the file extension -- on the
# cleaned name the tags between are gone ('Tokyo.Revengers.S01.BluRay.1080p.FLAC.2.0' read 's01 2 0', 'S1E2')
# disc extras a name can carry beside an episode-like number ('S3 [SP00] Menu - 14')
_EXTRA_WORDS = re.compile(r'(?i)(?<![a-z])(?:menu|sp\d{2}|nc(?:op|ed)|creditless|preview|trailer|teaser|cm|pv)(?![a-z])')
_S_BARE = re.compile(r'(?i)(?:^|[\s._\-\[\(])s0*(\d{1,2})[\s._]+0*(\d{1,3})(?=(?:\.(?:mkv|mp4|avi|m4v))?$|[\s_\-\[\(]|\.(?!\d))')

def _season_bare_number(name, data):
	"""LOCAL PATCH 2026-11-07: why a name reading 'S<n> <number>' (and no episode by _extract_meta) is not this episode, or None."""
	from magneto.modules.anime_utils import _extract_meta, _clean_for_extract
	try: seasons, episodes = _extract_meta(_clean_for_extract(name))[:2]
	except Exception: return None
	if not seasons or episodes: return None
	m = _S_BARE.search(name)
	if not m: return None
	s, e = int(m.group(1)), int(m.group(2))
	pairs = set()
	for p in (data.get('episode_candidates') or ()):
		try: pairs.add((int(p[0]), int(p[1])))
		except (TypeError, ValueError, IndexError): pass
	if (s, e) in pairs: return None
	nums = set()
	for k in ('episode', 'cour_episode', 'season_episode', 'absolute_episode'):
		try: nums.add(int(data.get(k)))
		except (TypeError, ValueError): pass
	if e in nums and s in set(p[0] for p in pairs): return None
	return 'names S%dE%d (season and a bare number)' % (s, e)


def _states_own_pair(text, data, titles):
	"""LOCAL PATCH 2026-11-07: the release / file name states one of the card's own (season, episode) pairs, nothing in it
	contradicts this episode, and it is no junk or disc extra. Such a row is this episode whatever another cour's markers say:
	in a TVDB-order episode group Bungou Stray Dogs TMDb E50 is S3E14, and 'Bungo.Stray.Dogs.S03E14' read as release season 3;
	a collection's picked file 'FateStay Night - S01E01 - The First Day.mkv' sits in a pack naming UBW and Heaven's Feel. Never
	past the junk / extras reading: comet's '[Moozzi2] Bungou Stray Dogs S3 [SP00] Menu - 14' reads (3, 14) too."""
	from magneto.modules.anime_utils import stremio_junk, anime_not_episode
	return bool(text and _names_card_pair(text, data) and not _contradicts(text, data, titles) and not _EXTRA_WORDS.search(text)
				and not stremio_junk(text, titles) and not anime_not_episode(text, titles))


def _comet_pack_holds(name, data, titles):
	"""LOCAL PATCH 2026-11-07: why a comet PACK holds this episode by its own name's statement, or None. comet's pack rule
	(comet_kitsu_reject -> cour_match) reads a pack by its season / episode numbers, so four kinds of right pack were refused:
	  A an absolute range from 1 holding the absolute number, its seasons (if named) this one's
	    'Tokyo Revengers 01-50 (Season 1+2+3) (... Seiya Kessen-hen+Tenjiku-hen)' for S1E25 (abs 25) -- it names a later cour too
	  B '[N of M]' (a running season's pack): M = the TMDb season's length, this episode <= N
	    Frieren '[22 of 28]' for S1E15 ('[12 of 28]' does not hold it)
	  C 'Part N' / 'PNN' beside this cour's own words, N = this cour's part   'Bleach - Thousand-Year Blood War P01' for S2E1
	  D a complete-season word with the show's own year, no season and no episode named
	    'Steins.Gate.0.(2018.ITA/JAP).[COMPLETA]' for S1E1
	Each needs the name to SAY so; the pack's contents are still checked after the judge (external's pack_contents).
	Guards, from the A/B over every comet case (+22 rows, 4 of them wrong before these): A, B and D need every word of one of
	the show's Latin-script titles in the name ('Steins_Gate 01-24END+OVA' is the 2011 show, not Steins;Gate 0); no volume
	marker ('Re:ZERO v01-27 [Yen Press]', 'Bungo Stray Dogs v01-24 (Digital)' are books); A needs a real range (2+ episodes)
	and no other cour's name unless this cour's own words are there too ('Fate Stay night Unlimited Blade Works S01-02 ...
	Ep.01.avi' for Fate/stay night 2006 S1E1)."""
	from magneto.modules.anime_utils import _extract_meta, _clean_for_extract, own_cour_words, names_foreign_cour
	def _int(v):
		try: return int(v)
		except (TypeError, ValueError): return None
	if _VOLUME.search(name): return None
	season, episode, ab = _int(data.get('season')), _int(data.get('episode')), _int(data.get('absolute_episode'))
	cs, part, length = _int(data.get('cour_season')), _int(data.get('cour_part')), _int(data.get('season_length'))
	seasons, episodes, _parts, is_range = _extract_meta(_clean_for_extract(name))
	seasons, episodes = set(seasons or ()), set(episodes or ())
	ours = set(s for s in (season, cs) if s)
	words = set(re.findall(r'[a-z0-9]+', name.lower()))
	titled = any(tw and tw <= words for tw in (set(re.findall(r'[a-z0-9]+', str(t).lower())) for t in (titles or ())))
	own = own_cour_words(name, data.get('own_cour_tokens'))
	# A
	if (titled and is_range and ab and len(episodes) > 1 and min(episodes) == 1 and ab in episodes and (not seasons or seasons & ours)
			and (own or not names_foreign_cour(name, data.get('foreign_cour_tokens')))):
		return 'absolute range 1-%d' % max(episodes)
	# B
	m = _N_OF_M.search(name)
	if titled and m and episode and length and not seasons:
		n, of = int(m.group(1)), int(m.group(2))
		if of == length and n <= of and episode <= n: return '%d of %d' % (n, of)
	# C
	if part and not episodes and own:
		p = _PART_N.search(name)
		if p and int(p.group(1)) == part: return 'part %d by its own words' % part
	# D
	if titled and not seasons and not episodes and _COMPLETE.search(name):
		years = set(int(y) for y in _YEAR.findall(name))
		show_year = _int(data.get('year'))
		if show_year and years and years <= {show_year}: return 'complete, the show\'s year %d' % show_year
	return None


def _taken_over_numbers(name, package, data, ctx):
	"""The number / season rules a taken-over provider applied to its own rows (comet: comet_kitsu_reject, its pack checks),
	with what its 4b measurement added. Why the row is not this episode, or None."""
	from magneto.modules.anime_utils import comet_kitsu_reject, later_season_reject, foreign_cour_marked, names_foreign_cour
	if package and ctx.numbered and _comet_pack_holds(name, data, ctx.titles): return None   # LOCAL PATCH 2026-11-07
	# LOCAL PATCH 2026-11-07: 'S<n> <number>' with nothing between (a file name): _extract_meta reads 'Re:Zero.S2..17.mkv' as season
	# 2 and NO episode, so comet's 'S2 .. 17' was kept (single and pack) for Re:ZERO S2E2 (TMDb S1E27). It must be one of the
	# card's pairs, or name one of the episode's numbers.
	if ctx.numbered:
		why = _season_bare_number(name, data)
		if why: return why
	if package:
		# comet ran comet_kitsu_reject on these before tag_batch made them packs (it reads batches: the season test first, then a
		# batch is accepted), and later_season_reject / foreign_cour_marked in _pack_ok ('act II' packs under Ace S2)
		# (a pack naming no season and no episodes is refused here, as comet always did: it cannot be told from a film or another adaptation
		# -- the Naruto movies and the 2021 live-action Tokyo Revengers passed for episodes when it was let through, 2026-11-04)
		if ctx.numbered:
			why = comet_kitsu_reject(name, data, titles=ctx.titles)
			if why: return 'not this season (%s)' % why
		later = later_season_reject([name], data) if package == 'season' else None
		if later: return 'a later season (%s)' % later if isinstance(later, str) else 'a later season'
		if foreign_cour_marked(name, data): return 'another cour (markers)'
		return None
	if not ctx.numbered: return None
	# LOCAL PATCH 2026-11-07: a single naming one of the card's own pairs is this episode (_states_own_pair; Bungou TMDb E50 in a
	# TVDB-order group: 'S03E14', and the releases' 'S05E01' / '5th Season - 01', were 'another cour (markers)' / cour_match)
	if _states_own_pair(name, data, ctx.titles): return None
	# a single row whose name states an episode RANGE is one file of a pack: 'Bakemonogatari.Ep9-13', 'Episodios.208.a.220' --
	# a range holding this episode passes, one that does not is not this episode
	span = _episode_range(name)
	wanted = _wanted_numbers(data, name)
	if span and wanted:
		if not any(span[0] <= w <= span[1] for w in wanted): return 'a range without this episode (%d-%d)' % span
		if names_foreign_cour(name, data.get('foreign_cour_tokens')): return 'another cour by its name'
		return None
	# a name carrying the episode's own title (3+ words) is not contradicted by an odd number
	if _names_own_title(name, data.get('title')): return None
	why = comet_kitsu_reject(name, data, titles=ctx.titles)
	if why: return 'not this episode (%s)' % why
	# a later PART of a split season, named by the part's own number with no part marker: releases count the season through,
	# so a bare 'Stone Ocean 01' is part 1 episode 1, not S5E25 (part 3 ep 1, released as 'Stone Ocean 25') -- the one wrong row
	# the comet measurement found; Re:ZERO S2 part 2 is '2nd Season - 14' / 'Part 2 - 01' the same way
	return _bare_part_number(name, data, ctx.titles)


def _contradicts(name, data, titles):
	"""Why a single episode's name contradicts this episode, or None. Reads, in order: another cour's words; an episode range
	(_episode_range); an episode number (_extract_meta, else the number straight after a title of ours); and only then holds
	the season: a cour-relative number for release season 2+ needs a season marker or this cour's own words, else it is the
	first cour's (Tokyo_Revengers_[01] is S1E1, not S1E25 = Christmas Showdown 01; 'Seiya Kessen Hen 01' is)."""
	from magneto.modules.anime_utils import names_foreign_cour, _extract_meta, _clean_for_extract, whole_run_episode, own_cour_words
	if names_foreign_cour(name, data.get('foreign_cour_tokens')) and not _own_words(name, data) and not _this_season_first(name, data):
		return 'another cour by its name'
	if _names_own_title(name, data.get('title')): return None
	def _int(v):
		try: return int(v)
		except (TypeError, ValueError): return None
	ce, se, ab, cs = _int(data.get('cour_episode')), _int(data.get('season_episode')), _int(data.get('absolute_episode')), _int(data.get('cour_season'))
	span = _episode_range(name)
	if span:
		wanted = _wanted_numbers(data, name)
		if wanted and not any(span[0] <= w <= span[1] for w in wanted): return 'a range without this episode (%d-%d)' % span
		return None
	try: seasons, episodes, parts = _extract_meta(_clean_for_extract(name))[:3]
	except Exception: return None
	# LOCAL PATCH 2026-11-06: a special Fribb maps (release season 0). A name stating a season must state one of the card's pairs --
	# TMDb's own S0 number left out when TVDB / Stremio number it differently: Dr. STONE 'Special Episode - RYUSUI' is TMDb S0E3,
	# 'S00E02' in every release, and S00E01 / S00E03 are other specials. The checks below were skipped for it: 'cs and ...' reads
	# season 0 as none, so 'S00E01' (the entry's own episode 1) and 'S03E01' passed while 'S00E02' was 'names episode 2'.
	if cs == 0 and seasons:
		_pairs = set(tuple(int(x) for x in p) for p in (data.get('episode_candidates') or ()) if len(p) == 2 and str(p[0]).lstrip('-').isdigit())
		# TMDb's own pair goes when the candidates hold another season-0 pair (episode_card._candidates adds TVDB's / Stremio's)
		_tmdb = (0, _int(data.get('episode')))
		if any(p[0] == 0 and p != _tmdb for p in _pairs): _pairs.discard(_tmdb)
		_eps = set(int(e) for e in (episodes or ()))
		if any(s in seasons and (not _eps or e in _eps) for s, e in _pairs): return None
		return 'names S%s E%s, not %s' % (','.join(str(s) for s in sorted(seasons)), ','.join(str(e) for e in sorted(_eps)) or '-',
			' / '.join('S%02dE%02d' % p for p in sorted(_pairs)))
	# another PART of a split season, by its marker: 'Bleach.Thousand-Year.Blood.War.Part.2.E01' is part 2's first episode, not
	# TYBW part 1's (meteor kept it for S2E1). Only a part number within the season's count -- JoJo's story 'Part 6' is no cour part.
	_part, _count = _int(data.get('cour_part')), _int(data.get('cour_part_count'))
	if _part and _count and parts and _part not in parts and all(x <= _count for x in parts):
		return 'part %s, wanted part %d' % (','.join(str(x) for x in sorted(parts)), _part)
	if not episodes:
		anchored = whole_run_episode(name, titles)
		# not the number of a season the name declares: '...Boku.no.Hero.Academia.5th.Season' is season 5, no episode 5
		episodes = {anchored} if anchored is not None and anchored not in (seasons or ()) else None
	if not episodes: return None
	wanted = set(x for x in (ce, se, ab) if x is not None)
	if not episodes & wanted: return 'names episode %s' % ','.join(str(e) for e in sorted(episodes))
	if ab is not None and ab in episodes and ab not in (ce, se): return None   # the absolute number is the series' own
	# a lower season claim stands when the name carries this cour's own words: Thousand-Year Blood War releases number their
	# own 'S01E01', which is TVDB season 17 episode 1 (comet_kitsu_reject's rule)
	# not when the season and episode are one of the card's own numberings: Bungou Stray Dogs E50 is TVDB S3E14 and the releases'
	# S5E1 (anime_utils._card_pair, 2026-11-06)
	from magneto.modules.anime_utils import _card_pair
	if cs and seasons and cs not in seasons and not own_cour_words(name, data.get('own_cour_tokens')) and not _card_pair(seasons, episodes, data):
		return 'season %s, wanted %d' % (','.join(str(x) for x in sorted(seasons)), cs)
	if cs and cs > 1 and not seasons and not own_cour_words(name, data.get('own_cour_tokens')):
		return 'first-cour numbering (no season marker or cour words for release season %d)' % cs
	return None


_CJK_RUN = None

# generic words a franchise's titles share: 'series' / 'season' -- not a cour's own (Monogatari's '〈物語〉シリーズ' collection holding
# 化物語 was dropped by シリーズ, as 'series' once did in the latin list)
_CJK_GENERIC = frozenset((u'シリーズ', u'시리즈', u'シーズン', u'시즌', u'系列'))
_KANJI = None

def _cjk_runs(text):
	"""The runs of CJK characters (kana, kanji, hangul) in a title that can name a cour: 2+ characters with a kanji in them, else
	3+ (a 2-character kana / hangul run like 'オフ' would match inside unrelated words), less the generic words."""
	import re
	global _CJK_RUN, _KANJI
	if _CJK_RUN is None:
		_CJK_RUN = re.compile(u'[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uac00-\ud7af]{2,}')
		_KANJI = re.compile(u'[\u3400-\u4dbf\u4e00-\u9fff]')
	return set(r for r in _CJK_RUN.findall(text or '') if r not in _CJK_GENERIC and (_KANJI.search(r) or len(r) >= 3))


def _foreign_cjk_hit(name, file_name, data):
	"""The first of data['foreign_cjk'] in the name or the picked file, else None."""
	words = data.get('foreign_cjk')
	if not words: return None
	text = (name or '') + ' ' + (file_name or '')
	# a run ONLY this entry's titles have names this cour (or a collection holding it): '... 化物語,偽物語,猫物語 ...' for
	# Bakemonogatari. Bleach's '死神' does not count -- TYBW's titles carry it too.
	if any(w in text for w in (data.get('own_cjk') or [])): return None
	return next((w for w in words if w in text), None)


def build_foreign_cjk(src, card):
	"""LOCAL PATCH 2026-11-04: data['foreign_cjk'] -- the CJK title runs of the OTHER Fribb entries of this TMDb show (ani.zip's ja /
	zh-Hant / zh-Hans / ko titles), less every run this entry's own titles have. Bleach (2004) owns '死神'; TYBW's '死神 千年血戰篇' gives
	'千年血戰篇' (and 千年血戦篇 / 千年血战篇 / 천년혈전 from its other languages); for TYBW part 1, part 2's '訣別譚' is foreign while the
	shared '千年血戦篇' is not. The latin words (foreign_cour_tokens) never held these: a release named only in Chinese passed as
	this cour. Every lookup is the ani.zip entry the cour path already caches (30 days once finished), at most 16 entries."""
	from caches import fribb_mappings as _fribb
	from caches.anizip_mappings import anizip_entry_titles
	cour = card.cour or {}
	own_ids = (cour.get('anilist'), cour.get('anidb'))
	if not any(own_ids): return
	# per LANGUAGE, and only the languages this entry has a title in: TYBW part 2 has no Korean title, so part 1's '블리치 천년혈전'
	# ('Bleach' + 'Thousand-Year Blood War') would have made the Korean for 'Bleach' itself foreign
	# the entries to ask about, then ALL the lookups at once: one after another they held the scrape's setup 3.0 s on a show's first
	# scrape (Monogatari: 11 ani.zip requests before any provider started; Bleach 5, 0.5 s) -- 0.02 s once cached
	siblings, seen = [], set()
	for row in (_fribb.tmdb_tv_to_fribb_rows(src.tmdb_id) or [])[:16]:
		ids = (row.get('anilist_id'), row.get('anidb_id'))
		if not any(ids) or ids in seen: continue
		seen.add(ids)
		if (ids[0] and ids[0] == own_ids[0]) or (ids[1] and ids[1] == own_ids[1]): continue
		siblings.append(ids)
	lookups = [own_ids] + siblings
	answers = {}
	def _get(ids):
		try: answers[ids] = (anizip_entry_titles(ids[0], ids[1]) or {}).get('cjk') or {}
		except Exception: answers[ids] = {}
	if len(lookups) > 1:
		import threading
		threads = [threading.Thread(target=_get, args=(ids,)) for ids in lookups]
		for t in threads: t.start()
		for t in threads: t.join(10)
	else: _get(own_ids)
	own_titles = answers.get(own_ids) or {}
	own = dict((lang, _cjk_runs(t)) for lang, t in own_titles.items())
	own_all = set().union(*own.values()) if own else set()
	foreign, every = set(), set()
	for ids in siblings:
		for lang, t in (answers.get(ids) or {}).items():
			every |= _cjk_runs(t)
			if lang in own: foreign |= _cjk_runs(t) - own[lang]
	sibling_all = every
	foreign = set(w for w in foreign - own_all if not any(w in o for o in own_all))
	if foreign: src.data['foreign_cjk'] = sorted(foreign, key=lambda w: (-len(w), w))
	# and this entry's OWN distinctive runs -- in none of the other entries' titles (any language)
	own_distinct = set(w for w in own_all if not any(w in o for o in sibling_all))   # inside a sibling's run: shared (死神 in TYBW's)
	if own_distinct: src.data['own_cjk'] = sorted(own_distinct, key=lambda w: (-len(w), w))


def build_reject_words(src, card):
	"""LOCAL PATCH 2026-11-04 (cleanup): the words a RELEASE is judged by, built from the cour's sibling titles -- data['foreign_cour_tokens']
	(another cour's words, romaji and acronyms; anime_utils.names_foreign_cour / cour_match step 0), data['own_cour_tokens'] (this
	cour's own: comet_kitsu_reject, own_cour_words) and data['cour_plan'] (cour_marker_plan). Moved unchanged from scrapers/external.py
	(they judge releases, not the episode, so they are neither on the episode card nor in the scrape setup); the scrape-setup snapshot
	of 28 hard cases was byte-identical before and after the move. Writes src.data; needs card.cour and card.title_key."""
	from caches import fribb_mappings as _fribb
	try: build_foreign_cjk(src, card)
	except Exception: pass
	cour_info = card.cour
	if cour_info and card.title_key:
		try:
			from apis.anilist_api import anilist_romaji_bulk, anilist_romaji_by_ids
			_id_field, own_id = card.title_key
			al_here, mt = cour_info.get('anilist'), src.data.get('mal_title')
			_bulk_titles = {}
			if own_id:
				# every sibling cour's title in one request (cached; the prefetch has usually fetched it already)
				try:
					sibling_ids = [r.get(_id_field) for r in _fribb.tmdb_tv_to_fribb_rows(src.tmdb_id) if r.get(_id_field)]
					if al_here: _bulk_titles = anilist_romaji_by_ids(sibling_ids + [al_here]) or {}
					elif len(sibling_ids) > 1: _bulk_titles = anilist_romaji_bulk(sibling_ids) or {}
				except Exception: pass
				# LOCAL PATCH 2026-08-27: reject tokens from the OTHER cours of this same TMDb
				# show, in ROMAJI. foreign_season_tokens above is built from TMDb season names,
				# so it only ever knows the English form: for Bleach it holds {thousand, year,
				# blood, war} and catches nothing titled 'Sennen Kessen-hen', which is how most
				# Thousand-Year Blood War releases are actually named. The sibling titles are
				# already in hand from the bulk warm above, so this costs no extra request.
				try:
					import re as _re2
					def _ftok(t): return set(w for w in _re2.findall(r'[a-z0-9]+', (t or '').lower()) if len(w) >= 4)
					_mine = _ftok(mt) | _ftok(src.title)
					_same_ids = set()
					# LOCAL PATCH 2026-09-24: 'ours' must not hang on AniList knowing this cour. It has
					# no entry for JoJo Stone Ocean Part 3 (MAL 53273 -> Not Found), so mt was empty,
					# _mine held only the TMDb show title, and parts 1 and 2 donated stone/ocean/kimyou/
					# bouken as FOREIGN words -- both real S05E25 singles and all 16 Stone Ocean packs were
					# rejected for part 3, and the scrape found nothing. Two sources are ours whatever
					# AniList says: TMDb's name for THIS season, which every cour in it shares ('STONE
					# OCEAN'), and a word in every KNOWN title of a cour in this same TMDb season ('jojo
					# kimyou bouken stone ocean', from parts 1 and 2). Same-season, not every sibling:
					# Fribb maps Kishibe Rohan (MAL 33191) to JoJo's TMDb show too, and it shares no
					# word with the rest. When our own title is known the intersection is a subset of it
					# and changes nothing. Raw TMDb season, not an episode group's: the scrape can run as
					# S10E25 for a TMDb S5E25.
					try:
						_own_s = int(src.meta.get('season', src.season))
						for _sn in (src.meta.get('season_data') or []):
							if int(_sn.get('season_number') or -1) == _own_s: _mine |= _ftok(_sn.get('name'))
						_same = []
						for _off, _prow in _fribb._season_cour_rows(src.tmdb_id, _own_s, allow_repair=False):
							try: _sid = int((_prow or {}).get(_id_field) or 0)
							except (TypeError, ValueError): _sid = 0
							_same_ids.add(_sid)
							_t = (_bulk_titles or {}).get(_sid)
							if _t: _same.append(_ftok(_t))
						if _same: _mine |= set.intersection(*_same)
					except Exception: pass
					_foreign = set()
					for _mid, _mtitle in (_bulk_titles or {}).items():
						try:
							if int(_mid) == int(own_id): continue
						except (TypeError, ValueError): pass
						_foreign |= _ftok(_mtitle)
						# Also the acronym: 'Thousand-Year Blood War' is released as 'Bleach TYBW',
						# which shares no whole word with any title we know. Four letters or more
						# only, so it cannot collide with an ordinary word by accident.
						try:
							_words = [w for w in _re2.findall(r'[A-Za-z]+', _mtitle or '') if len(w) > 2]
							_acr = ''.join(w[0] for w in _words).lower()
							if len(_acr) >= 4: _foreign.add(_acr)
						except Exception: pass
					# Fold in the English-named ones too. foreign_season_tokens is only applied
					# by the scrapers when the release makes no season claim of its own, and a
					# TYBW release labels ITSELF S01E01 -- so that guard never fires on exactly
					# the rows that need it. Here the cour is known outright, so the release's
					# own numbering carries no weight and the tokens can be applied unconditionally.
					_foreign |= set(src.data.get('foreign_season_tokens') or [])
					# ...and the acronyms of the OTHER TMDb season names, for the same reason:
					# 'Bleach TYBW - Pt1' names the arc by initials only.
					try:
						for _sn in (src.meta.get('season_data') or []):
							try:
								if int(_sn.get('season_number') or 0) in (0, int(src.season)): continue
							except (TypeError, ValueError): continue
							_w = [w for w in _re2.findall(r'[A-Za-z]+', _sn.get('name') or '') if len(w) > 2]
							_a = ''.join(w[0] for w in _w).lower()
							if len(_a) >= 4: _foreign.add(_a)
					except Exception: pass
					# LOCAL PATCH 2026-11-06: and the words of AniList's ALTERNATIVE adaptations of this cour (anilist_api.anilist_alternatives),
					# which Fribb maps to their own TMDb entries, not to this show: Fate/stay night (2006) knew 'unlimited blade works' from
					# the 2010 film Fribb puts under it, but not Heaven's Feel, whose collections were kept as S1E1 packs.
					if al_here:
						try:
							from apis.anilist_api import anilist_alternatives
							# not the words release names use for anything: 'Fate/Grand Order: First Order' and 'Fate/EXTRA Last Encore' gave
							# 'first' / 'last' / 'extra', and 'first' dropped 'Fate Series First Batch (Fate Stay 2006 ...)', which holds S1E1
							for _alt in anilist_alternatives(al_here) or []: _foreign |= _ftok(_alt) - _GENERIC_WORDS
						except Exception: pass
					_foreign -= _mine
					# LOCAL PATCH 2026-09-24: structural words are not a cour's identity. A sibling's
					# title contributes 'part' whenever OUR title lacks it, and it never tells two parts
					# apart -- both are 'Part 01' and 'Part 02'. Re:ZERO S2 part 1 is '2nd Season', part 2
					# '2nd Season Part 2', so part 1's list held 'part' and every 'Season 2 Part 01' pack
					# was rejected as naming another cour: 33 on a live S2E2 scrape, TTGA's BDRemux among
					# them. S1's list held 'season' the same way. Part NUMBERS are compared elsewhere
					# (cour_match step 3b, animetosho's declared-part check). Ordinals and 'final' are
					# NOT here: 'The Final Season' does name a cour.
					_foreign -= {'part', 'parts', 'season', 'seasons', 'cour', 'cours', 'series'}   # LOCAL PATCH 2026-11-04: + 'series' -- 'Monogatari Series' names the whole franchise in release names; from 'Monogatari Series: Second Season' it made every 'Monogatari.Series.Complete' BD pack 'another cour' for Bakemonogatari
					if _foreign: src.data['foreign_cour_tokens'] = sorted(_foreign)
					# LOCAL PATCH 2026-10-05: the words only THIS TMDb season's cours are named with -- 'sennen kessen
					# thousand blood' for Bleach S2, 'stone ocean' for JoJo S5. comet's Kitsu answers are not scoped to
					# the entry (Black Clover's 2nd Season id returned only Season 1 episode 1), so comet refuses a name
					# claiming an earlier season unless it carries one of these: a sub-series counts its own seasons
					# ('Bleach TYBW S01E01' is TVDB season 17). Words a cour of ANOTHER TMDb season shares are left
					# out -- Mushoku Tensei S1 and S2 are both 'Isekai Ittara Honki Dasu'. See anime_utils.comet_kitsu_reject.
					try:
						_other = set()
						for _mid, _mtitle in (_bulk_titles or {}).items():
							try:
								if int(_mid) == int(own_id) or int(_mid) in _same_ids: continue
							except (TypeError, ValueError): pass
							_other |= _ftok(_mtitle)
						_own = (_mine - _ftok(src.title) - _other) - {'part', 'parts', 'season', 'seasons', 'cour', 'cours',
							'first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth', 'final',
							'from', 'with', 'into', 'that', 'this', 'over', 'your', 'their', 'what', 'when', 'after', 'before'}
						_own = set(w for w in _own if not w.isdigit())
						if _own: src.data['own_cour_tokens'] = sorted(_own)
						# LOCAL PATCH 2026-11-04: and the words only THIS PART of a split season has -- less the other same-season parts' titles and
						# the TMDb season's name, which every part shares. TYBW part 2: {'ketsubetsu'} (not sennen / kessen / thousand / blood / year).
						# release_judge._part_marked reads them: 'Bleach: Sennen Kessen Hen - Ketsubetsu Tan - 01 ~ 13' marks part 2 as 'Part 2' would.
						try:
							_sib_words, _sn_words = set(), set()
							for _mid, _mtitle in (_bulk_titles or {}).items():
								try:
									if int(_mid) != int(own_id) and int(_mid) in _same_ids: _sib_words |= _ftok(_mtitle)
								except (TypeError, ValueError): pass
							for _sn in (src.meta.get('season_data') or []):
								if str(_sn.get('season_number')) == str(src.meta.get('season', src.season)): _sn_words |= _ftok(_sn.get('name'))
							_own_part = set(_own) - _sib_words - _sn_words
							if _own_part and _sib_words: src.data['own_part_tokens'] = sorted(_own_part)
						except Exception: pass
					except Exception: pass
					# LOCAL PATCH 2026-10-01: each cour's identity markers ('act II', 'Second Season') against its
					# siblings, for the providers that search by title (magneto anime_utils.cour_marker_plan)
					try:
						from magneto.modules.anime_utils import cour_marker_plan
						_sibs = [t for _mid, t in (_bulk_titles or {}).items() if t and str(_mid) != str(own_id)]
						_plan = cour_marker_plan(mt, _sibs) if mt else None
						if _plan: src.data['cour_plan'] = _plan
					except Exception: pass
				except Exception: pass
		except Exception: pass


_RANGE = None

def _episode_range(name):
	"""(first, last) of an episode range a name states, or None: 'Ep9-13', 'S01E1097-E1108', 'S01E1096-1110', 'E01~E12',
	'Episodes 208 to 220', 'Episodios 208 a 220'. anime_utils._extract_meta reads none of these as a range."""
	import re
	global _RANGE
	if _RANGE is None:
		# a word connector ('to', Spanish 'a' / 'al') needs a separator on both sides, and the range ends at a boundary: the
		# CRC '[E26A5977]' is not 'episodes 26 to 5977' (the first comet run read it so)
		_RANGE = re.compile(r'(?:(?<![a-z0-9])s\d{1,2}[ ._]?e|(?<![a-z0-9])(?:ep|eps|episodes?|episodios?|e))[ ._]?(\d{1,4})'
							r'(?:[ ._]*[-~][ ._]*|[ ._]+(?:to|a|al)[ ._]+)(?:e|ep)?[ ._]?(\d{1,4})(?![0-9a-z])', re.I)
	m = _RANGE.search(name)
	if not m: return None
	lo, hi = int(m.group(1)), int(m.group(2))
	return (lo, hi) if lo < hi else None


_ONE_EP = None

def _single_episode(name):
	"""(season, episode) when a name states exactly one SxxEyy and no second episode ('S17E01-E13' and 'S17E01E02' are not one)."""
	import re
	global _ONE_EP
	if _ONE_EP is None: _ONE_EP = re.compile(r'(?i)(?<![a-z0-9])s(\d{1,2})[ ._]?e(\d{1,4})(?![0-9])([ ._]?[-~&+e][ ._]?e?\d)?')
	hits = list(_ONE_EP.finditer(name or ''))
	if len(hits) != 1 or hits[0].group(3): return None
	return int(hits[0].group(1)), int(hits[0].group(2))


_BARE_RANGE = None
_BRACKET_RANGE = None

def _bare_range(name):
	"""(first, last) of a bare number range in a pack name ('[001-366]', '01 ~ 13'), or None. Not a pair of years ('[2004-2012]')."""
	import re
	global _BARE_RANGE
	if _BARE_RANGE is None: _BARE_RANGE = re.compile(r'(?<![0-9a-z])(\d{2,4})[ ._]*[-~][ ._]*(\d{2,4})(?![0-9a-z])', re.I)
	for m in _BARE_RANGE.finditer(name or ''):
		lo, hi = int(m.group(1)), int(m.group(2))
		if 1900 <= lo <= 2100 and 1900 <= hi <= 2100: continue
		# not a range of volumes / discs / seasons / parts: 'Sousou.no.Frieren.(Vol.01-03)' is three BD volumes, not episodes 1-3
		if re.search(r'(?i)(?:vol(?:ume)?s?|box(?:es)?|dis[ck]s?|sets?|seasons?|parts?|cours?|s)[ ._(\[]*$', (name or '')[:m.start()]): continue
		if lo < hi: return lo, hi
	# in brackets a range may start with ONE digit -- 'BLEACH (Bleach) (1-366) (Mandarin Chinese + Cantonese Dub)', the original
	# series offered for TYBW S2E1 (absolute 367). Not outside brackets: 'H.264-1080p' must not read as episodes 264-1080.
	global _BRACKET_RANGE
	if _BRACKET_RANGE is None: _BRACKET_RANGE = re.compile(r'[(\[][ ._]*(\d{1,4})[ ._]*[-~][ ._]*(\d{2,4})[ ._]*[)\]]')
	for m in _BRACKET_RANGE.finditer(name or ''):
		lo, hi = int(m.group(1)), int(m.group(2))
		if 1900 <= lo <= 2100 and 1900 <= hi <= 2100: continue
		if lo < hi: return lo, hi
	return None


def _wanted_numbers(data, name):
	"""The numbers a RANGE in this name may hold this episode by: the absolute always; the cour's / season's own number only
	where that numbering is the name's -- release season 1 (or none known), or the name states this season or carries this
	cour's own words. 'Black.Clover.E001-E051' holds Season 1's episode 1, not Season 2's (the first comet run kept it)."""
	from magneto.modules.anime_utils import own_cour_words
	def _int(v):
		try: return int(v)
		except (TypeError, ValueError): return None
	out = set(x for x in (_int(data.get('absolute_episode')),) if x is not None)
	cs = _int(data.get('cour_season'))
	if cs is None or cs <= 1 or cs in _declared_seasons(name) or own_cour_words(name, data.get('own_cour_tokens')) or _names_season_name(name, data):
		out |= set(x for x in (_int(data.get('season_episode')),) if x is not None)
		# the part's own number only where it cannot be part 1's: not in a later part of a split season, unless the name marks the
		# part -- 'Bleach: Sennen Kessen Hen - 01 ~ 13' is TYBW part 1, not part 2's first episode (season episode 14)
		_part = _int(data.get('cour_part')) or 1
		if _part <= 1 or _part_marked(name, _part, _int(data.get('cour_part_count')), data): out |= set(x for x in (_int(data.get('cour_episode')),) if x is not None)
	return out


def _names_season_name(name, data):
	"""LOCAL PATCH 2026-11-07 (phase 5d): the name carries this TMDb season's own NAME (data['season_title'], 2+ words, not a
	generic 'Season N' / 'Part N' / 'Specials'), so a range in it counts in that season's numbering. Haikyu!! S4 is 'TO THE TOP':
	AnimeTosho's 'Haikyuu!!.To.The.Top.(01-25)' and 'TO.THE.TOP.-.14-25' hold S4E14 (season episode 14) and were held against
	the absolute 74 only; own_cour_tokens is empty there, both parts sharing the words. 'Bleach.[001-366]' names no TYBW word."""
	import re
	title = data.get('season_title') or ''
	words = re.findall(r'[a-z0-9]+', title.lower())
	if len(words) < 2 or words[0] in ('season', 'series', 'part', 'specials', 'special', 'cour', 'book', 'arc'): return False
	return ''.join(words) in re.sub(r'[^a-z0-9]+', '', (name or '').lower())


def _part_marked(name, part, count, data=None):
	"""The name marks this PART of the season ('Part 2', 'Cour 2', 'P2'), by anime_utils._extract_meta's part reading."""
	from magneto.modules.anime_utils import _extract_meta, _clean_for_extract
	try: parts = _extract_meta(_clean_for_extract(name))[2]
	except Exception: parts = None
	if part in (parts or ()): return True
	# or by the part's own words (data['own_part_tokens']: 'Ketsubetsu' names TYBW part 2)
	import re
	words = set(re.findall(r'[a-z0-9]+', (name or '').lower()))
	return bool(words & set((data or {}).get('own_part_tokens') or ()))


def _names_own_title(name, title):
	"""The release name carries the episode's own title, when that title is 3+ words ('The Long-Awaited Reunion')."""
	import re
	words = re.findall(r'[a-z0-9]+', str(title or '').lower())
	if len(words) < 3: return False
	return ' %s ' % ' '.join(words) in ' %s ' % ' '.join(re.findall(r'[a-z0-9]+', name.lower()))


def _bare_part_number(name, data, titles):
	"""Why a single episode of a later part (2+) of a split season names only the PART's own number, or None. Only when the
	season count differs from the part count (season_episode != cour_episode) and the name carries no part marker. The
	number is _extract_meta's, else the one written straight after a title of ours ('Stone Ocean 01' has no '- 01' marker
	for _extract_meta: anime_utils.whole_run_episode's reader, the one cour_match falls back to)."""
	from magneto.modules.anime_utils import _extract_meta, _clean_for_extract, whole_run_episode
	try: part, ce, se = int(data.get('cour_part') or 0), int(data.get('cour_episode')), int(data.get('season_episode'))
	except (TypeError, ValueError): return None
	if part < 2 or int(data.get('cour_part_count') or 0) < 2 or ce == se: return None
	try: _seasons, episodes, parts, _range = _extract_meta(_clean_for_extract(name))
	except Exception: return None
	if parts: return None
	if not episodes:
		anchored = whole_run_episode(name, titles)
		episodes = {anchored} if anchored is not None else None
	if not episodes or ce not in episodes or se in episodes: return None
	return 'part 1 numbering (episode %d, no part marker; part %d episode %d is %d of the season)' % (ce, part, ce, se)


_SEASON_LIST = None

def _declared_seasons(name):
	"""Every season a release name declares: anime_utils' readers (S01-S03, 'Seasons 1-3', '2nd Season') plus a list
	('Season 1 2 3', 'Seasons 1, 2 & 3'), which neither reads."""
	import re
	global _SEASON_LIST
	from magneto.modules.anime_utils import _extract_meta, _clean_for_extract, multi_season_span
	out = set()
	try: out |= set(_extract_meta(_clean_for_extract(name))[0] or ())
	except Exception: pass
	span = multi_season_span(name)
	if span: out |= set(range(span[0], span[1] + 1))
	if _SEASON_LIST is None: _SEASON_LIST = re.compile(r'seasons?[ ._(]*((?:\d{1,2}[ ._,&+]+(?:and[ ._]+)?)+\d{1,2})(?![0-9])', re.I)
	for m in _SEASON_LIST.finditer(name):
		out |= set(int(n) for n in re.findall(r'\d{1,2}', m.group(1)))
	return out


def context_for(src):
	"""The Context for an external source's current anime scrape, or None when the judge does not apply."""
	if not getattr(src, '_is_anime', False): return None
	# LOCAL PATCH 2026-11-07 (phase 1b/c): from the episode card (episode_card.attach_judge_inputs) when the scrape built one --
	# every anime TV episode; an anime film has no card and keeps the reading below
	inputs = getattr(getattr(src, '_episode_card', None), 'judge_inputs', None)
	if inputs: return Context(*inputs)
	try: season = int(src.season)
	except (TypeError, ValueError): season = 0
	names = [sn.get('name') or '' for sn in (src.meta.get('season_data') or []) if str(sn.get('season_number')) == str(season)]
	return Context(src.data, src.title, season, names, src._other_season_words(season))
