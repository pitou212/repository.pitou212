"""
	Fenomscrapers Module
"""

import html
import re
import unicodedata


def _fold(text):
	"""LOCAL PATCH 2026-10-21 (with POV 6.10.17's NFKD release names, source_utils.strip_non_ascii_and_unprintable): letters
	reduced to their base form -- 'Amélie' -> 'Amelie', fullwidth 'ＳＰＹ' -> 'SPY' -- so a searched title matches release
	names, which are folded the same way. Other scripts are kept as they were (only combining marks go)."""
	return ''.join(c for c in unicodedata.normalize('NFKD', text) if not unicodedata.combining(c))

def get(title):
	try:
		if not title: return
		title = _fold(html.unescape(title))   # LOCAL PATCH 2026-10-21: named entities too ('&eacute;', '&#39;'), then folded
		title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title) # fix html codes with missing semicolon between groups
		title = re.sub(r'&#(\d+);', '', title).lower()
		title = title.replace('&quot;', '\"').replace('&amp;', '&').replace('&nbsp;', '')
		title = re.sub(r'\([^\d]*(\d+)[^\d]*\)', '', title) #eliminate all numbers between ()
		title = re.sub(r'[<\[{].*?[}\]>]|[^\w0-9]|[_]', '', title)
		return title
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return title

# LOCAL PATCH 2026-11-01 (cleanup): get_simple removed (no callers).

def geturl(title):
	if not title: return
	try:
		title = title.lower().rstrip()
		#try: title = title.translate(None, ':*?"\'\.<>|&!,')
		try:title = title.translate(str.maketrans('', '', ':*?"\'\\.<>|&!,'))
		except:
			#try: title = title.translate(title.maketrans('', '', ':*?"\'\.<>|&!,'))
			try: title = title.translate(title.maketrans('', '', ':*?"\'\\.<>|&!,'))
			except:
				for c in ':*?"\'\\.<>|&!,': title = title.replace(c, '')
		title = title.replace('/', '-').replace(' ', '-').replace('--', '-').replace('–', '-').replace('!', '')
		return title
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return title

def normalize(title):
	try:
		import unicodedata
		title = ''.join(c for c in unicodedata.normalize('NFKD', title) if unicodedata.category(c) != 'Mn')
		return str(title)
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return title
