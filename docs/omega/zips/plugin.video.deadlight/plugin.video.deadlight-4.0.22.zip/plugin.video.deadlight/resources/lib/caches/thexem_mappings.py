# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-11-07 (anime core plan phase 5c): the RELEASES' own season / episode numbering, from TheXEM (thexem.info,
	the scene-numbering map Sonarr uses).

	WHY
	Three numberings disagree for some anime: TMDb's, TVDB's (= Stremio / Cinemeta, Fribb's cour_season) and the one release
	names use. Bungou Stray Dogs is one 60-episode TMDb season, TVDB has 24 + 12 + 24, and releases count 12 + 12 + 12 + 13 + 11
	-- TheXEM maps it exactly (scene S1-S5 = TMDb E1-12, 13-24, 25-36, 37-49, 50-60; phase 0b). Haikyu!! TVDB S4E14 is the
	releases' S5E01. The episode card adds the scene pair to its episode candidates, which the release judge (anime_utils.
	_card_pair) and the pack file pick already read.

	COST (measured 2026-11-07): one 'which shows have a map' list (19 KB, 1,911 TVDB ids), and per mapped show one request
	(0.4-0.9 s, 9-75 KB) -- each cached a week. Only the episodes whose scene numbering DIFFERS are kept. A show TheXEM does not
	map never sends a request. A failed fetch is not cached and answers None, so the scrape goes on as before.
"""
from caches.lists_cache import lists_cache
from modules.kodi_utils import make_session

_BASE = 'https://thexem.info'
# an honest client name: requests' default 'python-requests/x.y' gets Cloudflare's 403 challenge page there (2026-11-07)
session = make_session(_BASE, headers={'User-Agent': 'DeadLight (Kodi add-on; anime scene numbering)'})
_HOURS = 168
_HAVE_KEY = 'thexem1_havemap_tvdb'
_MAP_KEY = 'thexem1_map_tvdb_%s'


def _get_json(path):
	try:
		r = session.get('%s/%s' % (_BASE, path), timeout=8)
		if r.status_code != 200: return None
		data = r.json()
		return data if isinstance(data, dict) and data.get('result') == 'success' else None
	except Exception: return None


def _mapped_shows():
	"""The TVDB show ids TheXEM has a map for (a set of strings), or None when the list could not be had."""
	cached = lists_cache.get(_HAVE_KEY)
	if not isinstance(cached, dict):
		data = _get_json('map/havemap?origin=tvdb')
		if data is None: return None
		cached = {'ids': [str(x) for x in (data.get('data') or [])]}
		lists_cache.set(_HAVE_KEY, cached, expiration=_HOURS)
	return set(cached.get('ids') or [])


def scene_map(tvdb_show_id):
	"""{'season:episode' (TVDB): [scene season, scene episode]} for the episodes whose scene numbering differs, {} for a show
	with no map or no difference, None when TheXEM could not be asked."""
	try: tvdb_show_id = str(int(tvdb_show_id))
	except (TypeError, ValueError): return {}
	mapped = _mapped_shows()
	if mapped is None: return None
	if tvdb_show_id not in mapped: return {}
	cached = lists_cache.get(_MAP_KEY % tvdb_show_id)
	if not isinstance(cached, dict):
		data = _get_json('map/all?id=%s&origin=tvdb' % tvdb_show_id)
		if data is None: return None
		diff = {}
		for row in data.get('data') or []:
			try:
				tv, sc = row['tvdb'], row['scene']
				t, s = (int(tv['season']), int(tv['episode'])), (int(sc['season']), int(sc['episode']))
			except (KeyError, TypeError, ValueError): continue
			if t != s: diff['%d:%d' % t] = [s[0], s[1]]
		cached = {'diff': diff}
		lists_cache.set(_MAP_KEY % tvdb_show_id, cached, expiration=_HOURS)
	return cached.get('diff') or {}


def scene_pair(tvdb_show_id, season, episode):
	"""(scene season, scene episode) for TVDB (season, episode) when the releases number it differently, else None."""
	got = scene_map(tvdb_show_id)
	if not got: return None
	try: pair = got.get('%d:%d' % (int(season), int(episode)))
	except (TypeError, ValueError): return None
	return (int(pair[0]), int(pair[1])) if pair else None
