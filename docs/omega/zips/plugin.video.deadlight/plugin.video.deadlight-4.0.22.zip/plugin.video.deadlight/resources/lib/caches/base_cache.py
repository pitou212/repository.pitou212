# -*- coding: utf-8 -*-
import time
import json
from ast import literal_eval
from contextlib import contextmanager
from os import path
import threading
import sqlite3 as database
from modules import kodi_utils
logger = kodi_utils.logger

def table_creators():
	return {
'navigator_db': (
'CREATE TABLE IF NOT EXISTS navigator (list_name text, list_type text, list_contents text, unique (list_name, list_type))',),
'watched_db': (
'CREATE TABLE IF NOT EXISTS watched \
(db_type text not null, media_id text not null, season integer, episode integer, last_played text, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS progress \
(db_type text not null, media_id text not null, season integer, episode integer, resume_point text, curr_time text, \
last_played text, resume_id integer, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS watched_status (db_type text not null, media_id text not null, status text, unique (db_type, media_id))'),
'favorites_db': (
'CREATE TABLE IF NOT EXISTS favourites (db_type text not null, tmdb_id text not null, title text not null, unique (db_type, tmdb_id))',),
'settings_db': (
'CREATE TABLE IF NOT EXISTS settings (setting_id text not null unique, setting_type text, setting_default text, setting_value text)',),
'trakt_db': (
'CREATE TABLE IF NOT EXISTS trakt_data (id text unique, data text)',
'CREATE TABLE IF NOT EXISTS watched \
(db_type text not null, media_id text not null, season integer, episode integer, last_played text, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS progress \
(db_type text not null, media_id text not null, season integer, episode integer, resume_point text, curr_time text, \
last_played text, resume_id integer, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS watched_status (db_type text not null, media_id text not null, status text, unique (db_type, media_id))'),
# LOCAL PATCH 2026-07-23: MDBList integration mirrors trakt_db 1:1 — KV blob for
# activities/list-cache + watched/progress/watched_status tables so mdblist can be
# selected via watched_indicators == 2 the same way trakt is via == 1.
'mdblist_db': (
'CREATE TABLE IF NOT EXISTS mdbl_data (id text unique, data text)',
'CREATE TABLE IF NOT EXISTS watched \
(db_type text not null, media_id text not null, season integer, episode integer, last_played text, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS progress \
(db_type text not null, media_id text not null, season integer, episode integer, resume_point text, curr_time text, \
last_played text, resume_id integer, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS watched_status (db_type text not null, media_id text not null, status text, unique (db_type, media_id))'),
# LOCAL PATCH 2026-07-29: SIMKL integration — same-shape KV+watched+progress schema
# as trakt_db / mdblist_db. Selected via watched_indicators == 3. SIMKL supports
# a first-class "On Hold" status which the other providers lack.
'simkl_db': (
'CREATE TABLE IF NOT EXISTS simkl_data (id text unique, data text)',
'CREATE TABLE IF NOT EXISTS watched \
(db_type text not null, media_id text not null, season integer, episode integer, last_played text, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS progress \
(db_type text not null, media_id text not null, season integer, episode integer, resume_point text, curr_time text, \
last_played text, resume_id integer, title text, unique (db_type, media_id, season, episode))',
'CREATE TABLE IF NOT EXISTS watched_status (db_type text not null, media_id text not null, status text, unique (db_type, media_id))'),
'maincache_db': (
'CREATE TABLE IF NOT EXISTS maincache (id text unique, data text, expires integer)',),
'metacache_db': (
'CREATE TABLE IF NOT EXISTS metadata (db_type text not null, tmdb_id text not null, imdb_id text, tvdb_id text, meta text, expires integer, unique (db_type, tmdb_id))',
'CREATE TABLE IF NOT EXISTS season_metadata (tmdb_id text not null unique, meta text, expires integer)',
'CREATE TABLE IF NOT EXISTS function_cache (string_id text not null unique, data text, expires integer)',
# LOCAL PATCH 2026-08-26 (perf): meta_cache.get() interpolates id_type into its WHERE
# clause, so imdb/tvdb lookups could only use the (db_type, tmdb_id) unique index by its
# db_type prefix -- a narrowed scan, measured 2.0ms vs 0.35ms. Used whenever a Trakt or
# MDBList row carries no TMDb id.
'CREATE INDEX IF NOT EXISTS idx_metadata_imdb ON metadata (db_type, imdb_id)',
'CREATE INDEX IF NOT EXISTS idx_metadata_tvdb ON metadata (db_type, tvdb_id)'),
'debridcache_db': (
# LOCAL PATCH 2026-09-22: `files` holds the per-file listing a cache check returned, as
# JSON, so a pack's real episode size survives into later scrapes. Appended LAST on
# purpose -- cached_check and friends read rows positionally (i[0], i[1], i[2]), so a
# new column anywhere else would silently renumber them. Existing installs get it via
# DebridCache._ensure_files_column; this line only covers a fresh database.
'CREATE TABLE IF NOT EXISTS debrid_data (hash text not null, debrid text not null, cached text, expires integer, files text, unique (hash, debrid))',),
'lists_db': (
'CREATE TABLE IF NOT EXISTS lists (id text unique, data text, expires integer)',),
'external_db': (
'CREATE TABLE IF NOT EXISTS results_data (provider text not null, db_type text not null, tmdb_id text not null, title text, year integer, season text, episode text, results text, \
expires integer, unique (provider, db_type, tmdb_id, title, year, season, episode))',),
'discover_db': (
'CREATE TABLE IF NOT EXISTS discover (id text not null unique, db_type text not null, data text)',),
'episode_groups_db': (
'CREATE TABLE IF NOT EXISTS groups_data (tmdb_id text not null unique, data text)',),
'personal_lists_db': (
'CREATE TABLE IF NOT EXISTS personal_lists \
(name text, contents text, total integer, created text, sort_order integer, description text, seen text, poster text, fanart text, author text, updated text, unique (name, author))',),
'tmdb_lists_db': (
'CREATE TABLE IF NOT EXISTS tmdb_lists (id text unique, data text, expires integer)',),
'random_widgets_db': (
'CREATE TABLE IF NOT EXISTS random_widgets (id text unique, data text, expires integer)',)
		}

def locations():
	return {
'navigator_db': 'navigator.db', 'watched_db': 'watched.db', 'favorites_db': 'favourites.db', 'settings_db': 'settings.db', 'trakt_db': 'traktcache.db',
'mdblist_db': 'mdblistcache.db',
'simkl_db': 'simklcache.db',
'maincache_db': 'maincache.db', 'metacache_db': 'metacache.db', 'debridcache_db': 'debridcache.db', 'lists_db': 'lists.db', 'tmdb_lists_db': 'tmdb_lists.db',
'discover_db': 'discover.db', 'external_db': 'external.db', 'episode_groups_db': 'episode_groups.db', 'personal_lists_db': 'personal_lists.db',
'random_widgets_db': 'random_widgets.db'
			}

USER_DATA_DBS = frozenset(('settings_db', 'watched_db', 'favorites_db', 'personal_lists_db', 'navigator_db'))

def database_locations(database_name):
	return kodi_utils.translate_path(path.join(path.join(kodi_utils.addon_profile(), 'databases'), locations()[database_name]))

def make_database(database_name):
	dbcon = database.connect(database_locations(database_name))
	all_commands = table_creators()[database_name]
	for command in all_commands: dbcon.execute(command)
	dbcon.close()

def make_databases():
	databases_path = path.join(kodi_utils.addon_profile(), 'databases/')
	if not kodi_utils.path_exists(databases_path): kodi_utils.make_directory(databases_path)
	all_locations = locations()
	for database_name in all_locations: make_database(database_name)

# LOCAL PATCH 2026-08-26 (perf): per-thread connection reuse.
# This opened a NEW sqlite connection AND re-ran all four PRAGMAs on every one of its
# ~107 call sites. Measured on the live metacache: 50 metadata lookups cost 51.6ms with
# a fresh connection each vs 9.2ms reusing one -- 5.6x, the connect+PRAGMA preamble
# alone being 0.66ms a call. A 50-item page pays that per item.
#
# Cached per THREAD, not once globally: TaskPool fans list building across up to
# max_threads workers, and one shared connection would serialise their reads and undo
# that parallelism. threading.local() also disposes as workers exit.
#
# Safe here: check_same_thread=False was already set; isolation_level=None means
# autocommit, so there is no long-lived read transaction and other connections' writes
# stay visible; and with reuselanguageinvoker=false the process dies each plugin
# invocation, so nothing leaks across calls.
#
# _conn_generation guards the one case a liveness ping cannot: check_databases_integrity
# DELETES a database file and rebuilds it, and a cached handle to a deleted file happily
# keeps answering queries against the orphaned inode. Comparing a generation stamp
# invalidates EVERY thread's cache at once -- which thread-local storage alone cannot do
# -- and costs an int compare instead of a round trip.
_thread_conns = threading.local()
_conn_generation = 0
# LOCAL PATCH 2026-09-27: every pooled handle, whatever thread opened it, so a call can close them all
# before it ends (close_all_connections). Otherwise the main thread's handles are closed by Kodi's
# interpreter teardown -- a native dump of a hung Kodi (21:10) caught one call's teardown inside sqlite
# while another's teardown held the GIL waiting on a lock: Kodi's Python 3.8 deadlocked on it.
_all_conns = []
_all_conns_lock = threading.Lock()


def reset_connections():
	"""Invalidate every cached connection in every thread. Call after deleting or
	recreating a database file."""
	global _conn_generation
	_conn_generation += 1


def connect_database(database_name):
	try:
		cache = _thread_conns.conns
	except AttributeError:
		cache = _thread_conns.conns = {}
	entry = cache.get(database_name)
	if entry is not None:
		if entry[0] == _conn_generation: return entry[1]
		try: entry[1].close()
		except Exception: pass
	dbcon = database.connect(database_locations(database_name), timeout=20, isolation_level=None, check_same_thread=False)
	# LOCAL PATCH 2026-10-25 (4.0.5): the user-data databases (settings + tokens, watched, favourites, personal lists,
	# menus) get a rollback journal and NORMAL sync -- with journal OFF a crash or power cut mid-write corrupts the
	# file, and the integrity check then rebuilt it empty. Not WAL: settings_backup zips the raw .db files and WAL
	# would leave committed rows in a -wal file. The caches keep OFF/OFF; they can always be refetched.
	if database_name in USER_DATA_DBS:
		dbcon.execute('PRAGMA synchronous = NORMAL')
		dbcon.execute('PRAGMA journal_mode = DELETE')
	else:
		dbcon.execute('PRAGMA synchronous = OFF')
		dbcon.execute('PRAGMA journal_mode = OFF')
	# LOCAL PATCH 2026-06-20 (perf): memory-mapped I/O + in-memory temp tables.
	# external.db can balloon past 200MB over months; 256MB mmap lets SQLite seek
	# pages directly via OS page cache instead of pread() per row. temp_store=MEMORY
	# keeps sort/group/JOIN scratch in RAM. Both are safe (no durability tradeoff
	# beyond what synchronous=OFF / journal_mode=OFF already concede).
	dbcon.execute('PRAGMA mmap_size = 268435456')
	dbcon.execute('PRAGMA temp_store = MEMORY')
	cache[database_name] = (_conn_generation, dbcon)
	# LOCAL PATCH 2026-10-15: each handle is listed with its thread, and a dead thread's handles are closed here. The
	# list only ever grew -- close_all_connections runs at the end of a plugin call, never in the long-lived service,
	# where every short-lived sync / TaskPool thread left an open handle (and its 256 MB mmap) for the whole session.
	# A thread's handles are its own (thread-local cache), so once it has ended nothing else can be using them.
	me = threading.current_thread()
	with _all_conns_lock:
		dead = [c for t, c in _all_conns if not t.is_alive()]
		if dead: _all_conns[:] = [(t, c) for t, c in _all_conns if t.is_alive()]
		_all_conns.append((me, dbcon))
	for c in dead:
		try: c.close()
		except Exception: pass
	return dbcon


def close_all_connections():
	"""Close every pooled connection this process opened. For the very end of a plugin call, after the
	last database use; a later connect_database would open a fresh handle (the stale entry is replaced)."""
	global _conn_generation
	with _all_conns_lock:
		conns, _all_conns[:] = list(_all_conns), []
	for _t, dbcon in conns:
		try: dbcon.close()
		except Exception: pass
	_conn_generation += 1   # any thread's cached entry now reconnects instead of using a closed handle

def get_timestamp(offset=0):
	# Offset is in HOURS multiply by 3600 to get seconds
	return int(time.time()) + (offset*3600)

def _is_locked(error):
	return 'locked' in str(error).lower() or 'busy' in str(error).lower()

def _set_aside(database_location, keep=2):
	import os, glob
	if not os.path.exists(database_location): return
	target = '%s.corrupt-%s' % (database_location, time.strftime('%Y%m%d-%H%M%S'))
	os.replace(database_location, target)
	for suffix in ('-journal', '-wal', '-shm'):   # a stale journal must not be replayed into the rebuilt file
		try: os.remove(database_location + suffix)
		except OSError: pass
	for old in sorted(glob.glob(glob.escape(database_location) + '.corrupt-*'))[:-keep]:
		try: os.remove(old)
		except OSError: pass

def check_databases_integrity(silent=False):
	integrity_check = {
	'settings_db': 1,              'navigator_db': 1,              'watched_db': 3,              'favorites_db': 1,              'trakt_db': 4,
	'mdblist_db': 4,
	'simkl_db': 4,
	'maincache_db': 1,             'metacache_db': 3,              'lists_db': 1,                'tmdb_lists_db': 1,             'discover_db': 1,
	'debridcache_db': 1,           'external_db': 1,               'episode_groups_db': 1,       'personal_lists_db': 1,         'random_widgets_db': 1
			}
	def _process(database_name, tables):
		cursor, error = None, False
		reason = []
		# LOCAL PATCH 2026-08-31: dbcon and database_location were bound only inside the try,
		# so when database.connect() itself failed -- the 'too corrupt to even open' case this
		# function exists to recover from -- the error branch raised NameError on dbcon.close(),
		# which the bare except swallowed, skipping BOTH the delete and reset_connections().
		dbcon, database_location = None, None
		try:
			database_location = database_locations(database_name)
			# LOCAL PATCH 2026-10-15: the same 20 s wait connect_database uses (sqlite's default is 5 s), and a LOCKED database
			# is skipped, not deleted. This runs 15 s after boot and after every playback stop, while widget and plugin
			# processes write the same files; any error -- 'database is locked' included -- deleted the file and rebuilt it
			# empty: watched history and the Trakt / MDBList / SIMKL mirrors gone until the next full sync.
			dbcon = database.connect(database_location, timeout=20)
			cursor = dbcon.cursor()
		except Exception as e:
			if _is_locked(e): return
			error = True
			reason.append('open failed: %s' % e)
		if cursor:
			try:
				cursor.execute('PRAGMA integrity_check')
				result = cursor.fetchone()
				if not 'ok' in result:
					error = True
					reason.append('integrity_check: %s' % (result,))
			except Exception as e:
				if _is_locked(e):
					try: dbcon.close()
					except Exception: pass
					return
				error = True
				reason.append('integrity_check failed: %s' % e)
			try:
				cursor.execute('SELECT name FROM sqlite_master WHERE type="table";')
				current_tables = len([i[0] for i in cursor.fetchall()])
				if current_tables != tables:
					error = True
					reason.append('%d tables, expected %d' % (current_tables, tables))
			except Exception as e:
				if _is_locked(e):
					try: dbcon.close()
					except Exception: pass
					return
				error = True
				reason.append('table count failed: %s' % e)
		if error:
			database_errors.append(database_name)
			# LOCAL PATCH 2026-10-25 (4.0.5): the bad file was DELETED without a log line -- settings.db (every setting and
			# token), watched.db, favourites and personal lists included. It is now set aside as
			# <name>.corrupt-<YYYYmmdd-HHMMSS> (the newest 2 kept per database) and logged, then rebuilt as before.
			try:
				if dbcon is not None: dbcon.close()
			except Exception: pass
			try:
				if database_location: _set_aside(database_location)
			except Exception as e:
				logger('check_databases_integrity', '%s: could not set aside %s: %s' % (database_name, database_location, e))
			logger('check_databases_integrity', '%s rebuilt (%s)' % (database_name, '; '.join(reason) or 'unknown'))
			reset_connections()
	database_errors = []
	for database_name, tables in integrity_check.items(): _process(database_name, tables)
	if database_errors:
		make_databases()
		if not silent: kodi_utils.ok_dialog(text='[B]Following Databases Rebuilt:[/B][CR][CR]%s' % ', '.join(database_errors))
	elif not silent: kodi_utils.notification('No Corrupt or Missing Databases', time=3000)

def get_size(file):
	with kodi_utils.open_file(file) as f: s = f.size()
	return s

# LOCAL PATCH 2026-09-26: expired rows were only ever removed by Tools > Clean Databases, run by
# hand; lists.db held 201 expired rows of 427 (1.34 of 1.87 MB), 131 of them type-ahead TMDb search
# prefixes. The service now runs this weekly (service.py DatabaseMaintenance).
#   - No VACUUM: it runs in the background while widgets may be building, and the journal-less
#     databases would lock for the whole rewrite. Freed pages are reused by later inserts.
#   - `expires > 0`: tmdb_lists keeps list sort orders with expires 0 meaning 'forever', and its own
#     clean_database would delete them. It is left out here entirely, as is random_widgets.db
#     (its cleaner names a `data` table that database does not have).
_PURGE_TABLES = (('external_db', ('results_data',)), ('maincache_db', ('maincache',)), ('lists_db', ('lists',)),
				('metacache_db', ('metadata', 'function_cache', 'season_metadata')), ('debridcache_db', ('debrid_data',)))

def purge_expired_rows():
	now, removed = get_timestamp(), 0
	for database_name, tables in _PURGE_TABLES:
		try:
			dbcon = connect_database(database_name)
			for table in tables:
				removed += dbcon.execute('DELETE FROM %s WHERE CAST(expires AS INT) > 0 AND CAST(expires AS INT) <= ?' % table, (now,)).rowcount
		except Exception as e: logger('purge_expired_rows', '%s: %s' % (database_name, e))
	return removed

def clean_databases():
	from caches.external_cache import external_cache
	from caches.main_cache import main_cache
	from caches.lists_cache import lists_cache
	from caches.tmdb_lists import tmdb_lists_cache   # LOCAL PATCH 2026-10-18: this row cleaned lists.db twice; its clean keeps sort orders
	from caches.meta_cache import meta_cache
	from caches.debrid_cache import debrid_cache
	from caches.random_widgets_cache import RandomWidgets
	clean_cache_list = (('EXTERNAL CACHE', external_cache, database_locations('external_db')),
						('MAIN CACHE', main_cache, database_locations('maincache_db')), ('LISTS CACHE', lists_cache, database_locations('lists_db')),
						('TMDB LISTS CACHE', tmdb_lists_cache, database_locations('tmdb_lists_db')), ('META CACHE', meta_cache, database_locations('metacache_db')),
						('DEBRID CACHE', debrid_cache, database_locations('debridcache_db')),
						('RANDOM WIDGETS CACHE', RandomWidgets(), database_locations('random_widgets_db')))   # LOCAL PATCH 2026-10-03 (Batch 3): was debrid_cache
	results = []
	append = results.append
	for item in clean_cache_list:
		name, function, location = item
		start_bytes = get_size(location)
		result = function.clean_database()
		if not result:
			append('[B]%s: [COLOR red]FAILED[/COLOR][/B]' % name)
			continue
		end_bytes = get_size(location)
		saved_bytes = start_bytes - end_bytes
		append('[B]%s: [COLOR green]SUCCESS[/COLOR][/B][CR]    [B]Saved Size: %sMB[/B][CR]    Start Size/End Size: %sMB/%sMB' \
		% (name, round(float(saved_bytes)/1024/1024, 2), round(float(start_bytes)/1024/1024, 2), round(float(end_bytes)/1024/1024, 2)))
	return kodi_utils.show_text('Cache Clean Results', text='[CR]----------------------------------[CR]'.join(results), font_size='large')

def clear_cache(cache_type, silent=False, clear_hashes=True):
	def _confirm(): return silent or kodi_utils.confirm_dialog()
	success = True
	if cache_type == 'meta':
		from caches.meta_cache import delete_meta_cache
		success = delete_meta_cache(silent=silent)
	elif cache_type == 'internal_scrapers':
		if not _confirm(): return
		from apis import easynews_api
		results = []
		results.append(easynews_api.clear_media_results_database())
		# LOCAL PATCH 2026-09-26: clear_hashes=False. This branch runs on every 'Rescrape & Select
		# Source' (dialogs.py) and each cloud clear it fans out to also dropped the debrid hash
		# verdicts for EVERY title -- all 58 rows in debridcache were found written within the same
		# ~9 minutes, i.e. re-checked from scratch after one rescrape. 'Clear Debrid Cache & Show
		# Results' exists for a deliberate re-check, 'Clear Scrapers Cache' still clears the table via
		# external_scrapers below, and the per-service 'Clear <Debrid> Cache' entries still default True.
		for item in ('pm_cloud', 'rd_cloud', 'ad_cloud', 'tb_cloud', 'folders'): results.append(clear_cache(item, silent=True, clear_hashes=False))
		success = False not in results
	elif cache_type == 'external_scrapers':
		from caches.external_cache import external_cache
		from caches.debrid_cache import debrid_cache
		results = []
		for item in (external_cache, debrid_cache): results.append(item.clear_cache())
		success = False not in results
	elif cache_type == 'trakt':
		from caches.trakt_cache import clear_all_trakt_cache_data
		success = clear_all_trakt_cache_data(silent=silent)
	elif cache_type == 'imdb':
		if not _confirm(): return
		from apis.imdb_api import clear_imdb_cache
		success = clear_imdb_cache()
	elif cache_type == 'pm_cloud':
		if not _confirm(): return
		from apis.premiumize_api import Premiumize
		success = Premiumize.clear_cache(clear_hashes=clear_hashes)
	elif cache_type == 'rd_cloud':
		if not _confirm(): return
		from apis.real_debrid_api import RealDebrid
		success = RealDebrid.clear_cache(clear_hashes=clear_hashes)
	elif cache_type == 'ad_cloud':
		if not _confirm(): return
		from apis.alldebrid_api import AllDebrid
		success = AllDebrid.clear_cache(clear_hashes=clear_hashes)
	# LOCAL PATCH 2026-09-26 / 2026-10-25: an unknown cache_type falls through to `else:# main`, which empties the main cache
	# (fanart.tv / TVDB artwork, IMDb data, search history). 'ed_cloud' once did that on every rescrape; EasyDebrid is
	# removed now, so no caller may pass a type without a branch here.
	elif cache_type == 'tb_cloud':
		if not _confirm(): return
		from apis.torbox_api import TorBox
		success = TorBox.clear_cache(clear_hashes=clear_hashes)
	elif cache_type == 'folders':
		if not _confirm(): return
		from caches.main_cache import main_cache
		success = main_cache.delete_all_folderscrapers()
	elif cache_type == 'list':
		if not _confirm(): return
		from caches.lists_cache import lists_cache
		success = lists_cache.delete_all_lists()
	elif cache_type == 'ai_functions':
		if not _confirm(): return
		from caches.lists_cache import lists_cache
		success = lists_cache.delete_all_ai_lists()
	elif cache_type == 'tmdb_list':
		if not _confirm(): return
		from caches.tmdb_lists import tmdb_lists_cache
		success = tmdb_lists_cache.clear_all()
	else:# main
		if not _confirm(): return
		from caches.main_cache import main_cache
		success = main_cache.delete_all()
	if not silent and success: kodi_utils.notification('Success')
	return success

def clear_all_cache():
	if not kodi_utils.confirm_dialog(): return
	progressDialog = kodi_utils.progress_dialog()
	line = 'Clearing....[CR]%s'
	caches = (('meta', 'Meta Cache'), ('internal_scrapers', 'Internal Scrapers Cache'), ('external_scrapers', 'External Scrapers Cache'), ('trakt', 'Trakt Cache'),
			('imdb', 'IMDb Cache'), ('list', 'List Data Cache'), ('ai_functions', 'AI Data Cache'), ('tmdb_list', 'TMDb Personal List Cache'), ('main', 'Main Cache'),
			('pm_cloud', 'Premiumize Cloud'), ('rd_cloud', 'Real Debrid Cloud'), ('ad_cloud', 'All Debrid Cloud'),
			('tb_cloud', 'TorBox Cloud'))
	for count, cache_type in enumerate(caches, 1):
		try:
			progressDialog.update(line % (cache_type[1]), int(float(count) / float(len(caches)) * 100))
			clear_cache(cache_type[0], silent=True)
			kodi_utils.sleep(1000)
		except: pass
	progressDialog.close()
	kodi_utils.sleep(100)
	kodi_utils.ok_dialog(text='Success')

def refresh_cached_data(meta):
	from caches.meta_cache import meta_cache
	media_type, tmdb_id, imdb_id = meta['mediatype'], meta['tmdb_id'], meta['imdb_id']
	try: meta_cache.delete(media_type, 'tmdb_id', tmdb_id, meta)
	except: return kodi_utils.notification('Error')
	from apis.imdb_api import refresh_imdb_meta_data
	refresh_imdb_meta_data(imdb_id)
	kodi_utils.notification('Success')
	kodi_utils.kodi_refresh()


# LOCAL PATCH 2026-09-04 (perf): JSON instead of repr()/eval() for BaseCache blobs, porting
# the meta_cache change of 2026-08-26 to the four caches this class backs -- lists_cache
# (lists.db), main_cache (maincache.db), tmdb_lists and random_widgets_cache.
#
# lists.db is the WIDGET LIST-PAGE cache: the blob a warm widget refresh reads. Measured on
# the live rows, top-20 blobs: eval 119.9 ms vs json.loads 9.1 ms (13.2x), and per widget
# that is 6-20 ms -- an 80 KB AniList page goes 15.6 -> 0.8 ms, a 112 KB MDBList page
# 20.1 -> 1.0 ms. It also stops eval()-ing stored data, which is the safer outcome.
#
# Audited against every live blob in all four DBs first, because JSON forces two shape
# changes (int dict keys become strings; tuples become lists):
#   * lists.db: only `anilist_epcounts_*` has int keys. apis.anilist_api.
#     anilist_episode_counts now normalises them back to int on the way out.
#   * maincache.db: one tuple, `imdb_extras_*`, whose consumer immediately subscripts [0] --
#     a list behaves identically (same call as meta['studio'] in the 08-26 round).
#   * tmdb_lists.db and random_widgets.db: clean.
# NOT ported to trakt_cache/mdblist_cache/simkl_cache/navigator_cache: they have their own
# get/set, and traktcache.db in particular holds 673 int-keyed `trakt_air_*` season maps.
# apis.trakt_air is defensively format-agnostic now, but the switch there is a separate job.
#
# _loads falls back to ast.literal_eval for rows written before this patch -- no migration,
# they age out. literal_eval rather than eval because it cannot execute code, and it only
# runs on legacy rows so its extra cost (measured SLOWER than eval) is transitional.
# LOCAL PATCH 2026-11-01 (cleanup): the read side is kv_decode's (JSON, then literal_eval); the write sides stay apart --
# _dumps always writes JSON (default=str), kv_encode falls back to repr() -- so rows on disk keep their formats.
def _loads(text):
	if not text: return None
	try: return kv_decode(text)
	except Exception: return None


def _dumps(obj):
	return json.dumps(obj, default=str)


# LOCAL PATCH 2026-10-02: the key/value stores of mdblist_cache, trakt_cache and simkl_cache wrote repr() and read eval():
# 20-25 ms to eval the 123 KB 'Latest TV Shows' MDBList blob on every open, 0.6 ms as JSON. JSON is written only when the
# value comes back IDENTICAL -- 70 of 122 trakt_data rows (trakt_air_*) hold tuples or int keys that JSON would turn into
# lists and str keys -- and otherwise repr() as before. Reading tries JSON first: a repr() that parses as JSON (numbers,
# lists of numbers) means the same value. The fallback is literal_eval, not the old eval: every stored row (mdblist,
# trakt, simkl, 132 rows on 10-02) is a plain literal, and literal_eval cannot run code.
def kv_encode(data):
	try:
		text = json.dumps(data)
		if json.loads(text) == data: return text
	except (TypeError, ValueError): pass
	return repr(data)


@contextmanager
def write_transaction(dbcon):
	"""LOCAL PATCH 2026-10-03 (Batch 2): one IMMEDIATE transaction around a read-modify-rewrite.

	Connections are autocommit (isolation_level=None), so a sync's SELECT -> DELETE -> INSERT ran as
	separate statements: a mark landing between the SELECT and the DELETE was wiped, and a widget reading
	mid-rewrite saw an empty or half-filled table. BEGIN IMMEDIATE takes the write lock up front; readers
	keep the old pages until COMMIT. journal_mode is OFF, which makes ROLLBACK undefined -- so this always
	COMMITs, and only conflict-free statements (no network) go inside. A nested use is a no-op. If COMMIT
	itself fails the handle is in an unknown state: close it and make every thread reconnect."""
	if dbcon.in_transaction:
		yield dbcon
		return
	dbcon.execute('BEGIN IMMEDIATE')
	try: yield dbcon
	finally:
		try: dbcon.execute('COMMIT')
		except Exception as e:
			_log('write_transaction', 'COMMIT failed: %s' % e)
			try: dbcon.close()
			except Exception: pass
			reset_connections()
			raise


def _log(label, text):
	try:
		from modules.kodi_utils import logger
		logger(label, text)
	except Exception: pass


def sync_since():
	"""LOCAL PATCH 2026-10-03 (Batch 2): the moment a provider sync starts, in the format local marks are
	stamped with (watched_status.get_last_played_value). Taken BEFORE the activity poll and handed to the
	bulk setters: a local row stamped at or after it was written while the sync was downloading, so the
	download may not hold it. Comparing against the newest server stamp in the download (the first fix)
	mixed two clocks -- a provider clock a few minutes ahead swallowed every mark made in those minutes."""
	return time.strftime('%Y-%m-%dT%H:%M:%S.000Z', time.gmtime())


# LOCAL PATCH 2026-10-03 (Batch 2): tombstones for local removals, in the provider db's watched_status table.
# An unmark (or a cleared resume point) deletes the local row, and a sync whose download was taken before
# the provider heard about it put the row straight back. Each removal leaves db_type 'unwatched' /
# 'unprogress', media_id tomb_key(...), status = the removal time. A tombstone applies only to a sync
# that started BEFORE the removal (removed_at > since, local clock against local clock); a download taken
# after it is authoritative, so a genuine re-add on another device is never hidden. They are pruned by age
# only, never by `since`: a widget sync and the service's sync can overlap and finish in either order.
TOMB_KINDS = ('unwatched', 'unprogress')
_TOMB_TTL = 24 * 3600


def tomb_key(db_type, media_id, season='', episode=''):
	def _n(value):
		if value in ('', None): return ''
		try: return int(value)
		except (TypeError, ValueError): return value
	return '%s|%s|%s|%s' % (db_type, media_id, _n(season), _n(episode))


def set_tombstones(dbcon, kind, rows, removed_at):
	"""rows: (db_type, media_id, season, episode, ...) tuples."""
	dbcon.executemany('INSERT OR REPLACE INTO watched_status VALUES (?, ?, ?)', [(kind, tomb_key(*r[:4]), removed_at) for r in rows])


def clear_tombstones(dbcon, kind, rows):
	dbcon.executemany('DELETE FROM watched_status WHERE db_type = ? AND media_id = ?', [(kind, tomb_key(*r[:4])) for r in rows])


def _tombstones(dbcon, kind, db_type, since):
	if not since: return set()
	return set(i[0] for i in dbcon.execute('SELECT media_id FROM watched_status WHERE db_type = ? AND status > ? AND media_id LIKE ?',
										(kind, since, db_type + '|%')).fetchall())


def _prune_tombstones(dbcon):
	cutoff = time.strftime('%Y-%m-%dT%H:%M:%S.000Z', time.gmtime(time.time() - _TOMB_TTL))
	dbcon.execute('DELETE FROM watched_status WHERE db_type IN (?, ?) AND status < ?', TOMB_KINDS + (cutoff,))


def replace_watched_rows(dbcon, db_type, insert_list, since=None):
	"""LOCAL PATCH 2026-10-03: a provider sync's full rewrite of `watched` for one db_type, minus the race.

	The sync downloads the whole history, then DELETEs every row and inserts the download. A mark made
	between the two was wiped locally while the provider kept it: Ace of the Diamond S2E2, marked at
	17:26:30 while the widget sync started by the S2E1 mark (17:26:24) was still paging MDBList, came back
	in Continue Watching. Local rows stamped at or after `since` (the sync's start, see sync_since) are
	carried over; without `since`, rows newer than everything in the download. An unmark made after
	`since` drops its row from the download (tombstones above). All of it runs in one transaction."""
	newest = max((row[4] for row in insert_list if row[4]), default='')
	floor = since or newest
	with write_transaction(dbcon):
		_prune_tombstones(dbcon)
		gone = _tombstones(dbcon, 'unwatched', db_type, floor)
		if gone: insert_list = [r for r in insert_list if tomb_key(*r[:4]) not in gone]
		kept = dbcon.execute('SELECT * FROM watched WHERE db_type = ? AND last_played >= ?', (db_type, floor)).fetchall() if floor else []
		dbcon.execute('DELETE FROM watched WHERE db_type = ?', (db_type,))
		dbcon.executemany('INSERT OR IGNORE INTO watched VALUES (?, ?, ?, ?, ?, ?)', insert_list)
		if kept: dbcon.executemany('INSERT OR IGNORE INTO watched VALUES (?, ?, ?, ?, ?, ?)', kept)
	if kept or gone:
		_log('watched sync', '%s: kept %d local mark(s) since %s, held back %d unmarked' % (db_type, len(kept), floor, len(gone)))
	return len(kept)


def replace_progress_rows(dbcon, db_type, insert_list, since=None, keep_local=False):
	"""LOCAL PATCH 2026-10-03 (Batch 2): the same for `progress`, which every sync rewrote with a bare
	DELETE + INSERT. Kept: rows stamped at or after `since`, and with keep_local every row DeadLight wrote
	itself (resume_id 0 and a real curr_time -- provider rows always carry curr_time '0'). keep_local is
	SIMKL's: it has no resume-point API, so its resume points exist only here, and each playback rebuild
	wiped all of them. A kept row the download also holds loses to the download when the download's is
	newer; otherwise it stays and takes the download's resume_id, so clearing it later reaches the provider
	instead of sending id 0. A resume point cleared after `since` is held back like an unmark."""
	newest = max((row[6] for row in insert_list if row[6]), default='')
	floor = since or newest
	with write_transaction(dbcon):
		_prune_tombstones(dbcon)
		gone = _tombstones(dbcon, 'unprogress', db_type, floor)
		if gone: insert_list = [r for r in insert_list if tomb_key(*r[:4]) not in gone]
		clauses, args = [], [db_type]
		if floor:
			clauses.append('last_played >= ?')
			args.append(floor)
		if keep_local: clauses.append("(resume_id = 0 AND curr_time NOT IN ('0', ''))")
		kept = dbcon.execute('SELECT * FROM progress WHERE db_type = ? AND (%s)' % ' OR '.join(clauses), args).fetchall() if clauses else []
		twins = dict((tomb_key(*r[:4]), r) for r in insert_list)
		merged = []
		for row in kept:
			twin = twins.get(tomb_key(*row[:4]))
			if twin is None: merged.append(row)
			elif (twin[6] or '') > (row[6] or ''): continue
			else: merged.append(tuple(row[:7]) + (twin[7],) + tuple(row[8:]))
		dbcon.execute('DELETE FROM progress WHERE db_type = ?', (db_type,))
		dbcon.executemany('INSERT OR IGNORE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', insert_list)
		if merged: dbcon.executemany('INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', merged)
	if merged or gone:
		_log('progress sync', '%s: kept %d local resume point(s), held back %d cleared' % (db_type, len(merged), len(gone)))
	return len(merged)


def kv_decode(text):
	try: return json.loads(text)
	except ValueError: return literal_eval(text)


# LOCAL PATCH 2026-10-03 (Batch 3): one rule for how long a fetched answer is kept, shared by
# lists_cache_object, main_cache.cache_object and meta_cache.cache_function. A refusal is never stored: a
# TMDb {"success": false, "status_code": 7} body or an HTML error page used to sit in the cache for the
# caller's full lifetime (a day, a month) as if it were the answer. An empty answer is kept for at most
# 18 minutes -- long enough to stop a widget hammering the API, short enough that a transient empty
# (rate limit, half-up server) heals by itself. Everything else keeps the caller's lifetime.
EMPTY_RESULTS = ([], {}, '[]', '{}', '', None)
EMPTY_TTL_HOURS = 0.3


def is_failed_result(result):
	if isinstance(result, dict) and result.get('success') is False: return True
	if isinstance(result, str) and result.lstrip().startswith('<'): return True
	return False


def cache_ttl(result, expiration):
	"""Hours to cache `result` for; 0 means do not store it."""
	if is_failed_result(result): return 0
	if result in EMPTY_RESULTS: return min(expiration or EMPTY_TTL_HOURS, EMPTY_TTL_HOURS)
	return expiration


# LOCAL PATCH 2026-10-19: the watched-provider caches (trakt_cache, mdblist_cache, simkl_cache) held three copies of this
# class, differing only in database and table. They had drifted: Trakt's bulk writers took allow_empty (10-18) and the
# MDBList / SIMKL copies did not, so the last watched mark or resume point removed on those services stayed here.
class ProviderCache(object):
	"""A provider's key/value table (get / set / delete) and its watched / progress tables (the set_bulk_* writers).

	set_bulk_*: an empty insert_list keeps what is stored unless allow_empty -- the caller fetched successfully and the
	service really holds none (a failed fetch must reach here as 'do not call', never as []).
	keep_local_progress: SIMKL has no resume-point API, so the resume points only DeadLight holds are kept
	(base_cache.replace_progress_rows keep_local; simkl_api.simkl_progress_* rows keep curr_time '0', resume_id 0)."""
	def __init__(self, db, table, keep_local_progress=False):
		self._db, self._table, self._keep_local = db, table, keep_local_progress

	def get(self, string):
		result = None
		try:
			dbcon = connect_database(self._db)
			cache_data = dbcon.execute('SELECT data FROM %s WHERE id = ?' % self._table, (string,)).fetchone()
			if cache_data: result = kv_decode(cache_data[0])   # LOCAL PATCH 2026-10-02, see kv_encode
		except: pass
		return result

	def set(self, string, data):
		try:
			dbcon = connect_database(self._db)
			dbcon.execute('INSERT OR REPLACE INTO %s (id, data) VALUES (?, ?)' % self._table, (string, kv_encode(data)))
		except: return None

	def delete(self, string):
		try:
			dbcon = connect_database(self._db)
			dbcon.execute('DELETE FROM %s WHERE id = ?' % self._table, (string,))
		except: pass

	# LOCAL PATCH 2026-11-01 (cleanup): the hand-written clear_* helpers of trakt / mdblist / simkl_cache are one-liners over these
	def delete_like(self, pattern):
		try:
			dbcon = connect_database(self._db)
			dbcon.execute('DELETE FROM %s WHERE id LIKE ?' % self._table, (pattern,))
		except: pass

	def delete_all(self):
		try:
			dbcon = connect_database(self._db)
			dbcon.execute('DELETE FROM %s' % self._table)
		except: pass

	def reset_activity(self, string, latest_activities, default):
		"""Store latest_activities under `string`; return what was stored before (default() when nothing or on error).
		No DELETE first (set is INSERT OR REPLACE): a reader between the two got default() -- 2020 stamps -- and ran a full
		resync of every list and the whole watched history."""
		try:
			dbcon = connect_database(self._db)
			data = dbcon.execute('SELECT data FROM %s WHERE id = ?' % self._table, (string,)).fetchone()
			cached_data = kv_decode(data[0]) if data else default()
			self.set(string, latest_activities)
		except: cached_data = default()
		return cached_data

	# LOCAL PATCH 2026-10-03: replace_*_rows keep marks / resume points saved while the sync was downloading (since).
	def set_bulk_movie_watched(self, insert_list, since=None, allow_empty=False):
		if not insert_list and not allow_empty: return
		replace_watched_rows(connect_database(self._db), 'movie', insert_list, since)

	def set_bulk_tvshow_watched(self, insert_list, since=None, allow_empty=False):
		if not insert_list and not allow_empty: return
		replace_watched_rows(connect_database(self._db), 'episode', insert_list, since)

	def set_bulk_movie_progress(self, insert_list, since=None, allow_empty=False):
		if not insert_list and not allow_empty: return
		replace_progress_rows(connect_database(self._db), 'movie', insert_list, since, keep_local=self._keep_local)

	def set_bulk_tvshow_progress(self, insert_list, since=None, allow_empty=False):
		if not insert_list and not allow_empty: return
		replace_progress_rows(connect_database(self._db), 'episode', insert_list, since, keep_local=self._keep_local)


class BaseCache(object):
	def __init__(self, dbfile, table):
		self.table = table
		self.dbfile = dbfile

	def get(self, string):
		result = None
		try:
			current_time = get_timestamp()
			dbcon = connect_database(self.dbfile)
			cache_data = dbcon.execute('SELECT expires, data FROM %s WHERE id = ?' % self.table, (string,)).fetchone()
			if cache_data:
				if cache_data[0] > current_time:
					result = _loads(cache_data[1])
				else: self.delete(string)
		except: pass
		return result

	def set(self, string, data, expiration=720):
		try:
			dbcon = connect_database(self.dbfile)
			expires = get_timestamp(expiration)
			dbcon.execute('INSERT OR REPLACE INTO %s(id, data, expires) VALUES (?, ?, ?)' % self.table, (string, _dumps(data), int(expires)))
		except: return None

	def delete(self, string):
		try:
			dbcon = connect_database(self.dbfile)
			dbcon.execute('DELETE FROM %s WHERE id = ?' % self.table, (string,))
		except: pass

	def delete_like(self, string):
		try:
			dbcon = connect_database(self.dbfile)
			dbcon.execute('DELETE FROM %s WHERE id LIKE ?' % self.table, (string,))
		except: pass

	def manual_connect(self, dbfile):
		return connect_database(dbfile)

	# LOCAL PATCH 2026-10-19: lists_cache, main_cache and random_widgets_cache held this with only the names changed
	# (tmdb_lists keeps its own: its sort orders are stored with expires 0 and must stay).
	def clean_database(self):
		try:
			dbcon = self.manual_connect(self.dbfile)
			dbcon.execute('DELETE from %s WHERE CAST(expires AS INT) <= ?' % self.table, (get_timestamp(),))
			dbcon.execute('VACUUM')
			return True
		except: return False
