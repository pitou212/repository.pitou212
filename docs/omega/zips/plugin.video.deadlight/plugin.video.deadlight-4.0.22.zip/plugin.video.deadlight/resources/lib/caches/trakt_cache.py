# -*- coding: utf-8 -*-
from threading import Thread
from caches.base_cache import connect_database, kv_decode, ProviderCache, is_failed_result
from modules.kodi_utils import confirm_dialog

# LOCAL PATCH 2026-10-19: both class bodies live in base_cache.ProviderCache (shared with MDBList / SIMKL). TraktWatched's
# set_bulk_tvshow_status / set_tvshow_status were never called (trakt_tvshow_status is never read) and are gone.
class TraktCache(ProviderCache):
	def __init__(self): ProviderCache.__init__(self, 'trakt_db', 'trakt_data')

trakt_cache = TraktCache()

# LOCAL PATCH 2026-11-01 (cleanup): TraktWatched was the same class on the same db / table -- kept as aliases.
TraktWatched = TraktCache
trakt_watched_cache = trakt_cache

def cache_trakt_object(function, string, url):
	cache = trakt_cache.get(string)
	if cache is not None: return cache
	result = function(url)
	# LOCAL PATCH 2026-10-03 (Batch 3): these rows never expire (only Trakt activity clears them), so a failure
	# (None) or a refusal body must never be stored.
	if result is None or is_failed_result(result): return None
	trakt_cache.set(string, result)
	return result

def set_list_custom_sort(list_id, data):
	string = 'trakt_list_custom_sort_%s' % list_id
	try:
		dbcon = connect_database('trakt_db')
		dbcon.execute('INSERT OR REPLACE INTO trakt_data (id, data) VALUES (?, ?)', (string, repr(data)))
		return True
	except: return False

def delete_list_custom_sort(list_id):
	string = 'trakt_list_custom_sort_%s' % list_id
	try:
		dbcon = connect_database('trakt_db')
		dbcon.execute('DELETE FROM trakt_data WHERE id=?', (string,))
		return True
	except: return False

def get_list_custom_sort(list_id):
	string = 'trakt_list_custom_sort_%s' % list_id
	try:
		dbcon = connect_database('trakt_db')
		cache_data = dbcon.execute('SELECT data FROM trakt_data WHERE id = ?', (string,)).fetchone()
		return kv_decode(cache_data[0])
	except: return {}

def get_all_lists_custom_sort():
	try:
		dbcon = connect_database('trakt_db')
		all_cache_data = dbcon.execute('SELECT data FROM trakt_data WHERE id LIKE %s' % "'trakt_list_custom_sort_%'").fetchall()
		all_cache_data = (kv_decode(i[0]) for i in all_cache_data)
		return dict([(i['list_id'], {'sort_by': i['sort_by'], 'sort_how': i['sort_how']}) for i in all_cache_data])
	except: return {}

def reset_activity(latest_activities):
	return trakt_cache.reset_activity('trakt_get_activity', latest_activities, default_activities)

def clear_daily_cache():
	clear_trakt_calendar()
	clear_trakt_list_data('my_lists')
	clear_trakt_list_data('liked_lists')
	clear_trakt_list_data('user_lists')
	clear_trakt_list_contents_data('my_lists')
	clear_trakt_list_contents_data('liked_lists')
	clear_trakt_list_contents_data('user_lists')

# LOCAL PATCH 2026-11-01 (cleanup): one-liners over ProviderCache.delete / delete_like (same row patterns as before)
def clear_trakt_hidden_data(list_type):
	trakt_cache.delete('trakt_hidden_items_%s' % list_type)

def clear_trakt_collection_watchlist_data(list_type, media_type):
	if media_type == 'movies': media_type = 'movie'
	if media_type in ('tvshows', 'shows'): media_type = 'tvshow'
	trakt_cache.delete('trakt_%s_%s' % (list_type, media_type))

def clear_trakt_calendar():
	trakt_cache.delete_like('trakt_get_my_calendar_%')

def clear_trakt_list_contents_data(list_type):
	trakt_cache.delete_like('trakt_list_contents_' + list_type + '_%')

def clear_trakt_list_data(list_type):
	trakt_cache.delete('trakt_%s' % list_type)

def clear_trakt_recommendations():
	trakt_cache.delete_like('trakt_recommendations_%')

def clear_trakt_favorites():
	trakt_cache.delete_like('trakt_favorites_%')

def clear_all_trakt_cache_data(silent=False, refresh=True):
	try:
		start = silent or confirm_dialog()
		if not start: return False
		from caches.main_cache import main_cache
		main_cache_dbcon = connect_database('maincache_db')
		lists_with_media = main_cache_dbcon.execute('SELECT id FROM maincache WHERE id LIKE %s' % "'trakt_lists_with_media_%'").fetchall()
		for item in lists_with_media:
			try: main_cache.delete(item[0])
			except: pass
		main_cache.clean_database()
		dbcon = connect_database('trakt_db')
		for table in ('progress', 'watched', 'watched_status'): dbcon.execute('DELETE FROM %s' % table)
		# LOCAL PATCH 2026-10-25 (4.0.5): the queued writes Trakt refused (trakt_api._PENDING_KEY) exist nowhere else -- kept
		dbcon.execute('DELETE FROM trakt_data WHERE id NOT LIKE %s AND id != ?' % "'trakt_list_custom_sort_%'", ('trakt_pending_writes',))
		dbcon.execute('VACUUM')
		if refresh:
			from apis.trakt_api import trakt_sync_activities
			Thread(target=trakt_sync_activities).start()
		return True
	except: return False

def default_activities():
	return {
			'all': '2024-01-22T00:22:21.000Z',
			'movies':
				{
				'watched_at': '2020-01-01T00:00:01.000Z',
				'collected_at': '2020-01-01T00:00:01.000Z',
				'rated_at': '2020-01-01T00:00:01.000Z',
				'watchlisted_at': '2020-01-01T00:00:01.000Z',
				'favorited_at': '2020-01-01T00:00:01.000Z',
				'recommendations_at': '2020-01-01T00:00:01.000Z',
				'commented_at': '2020-01-01T00:00:01.000Z',
				'paused_at': '2020-01-01T00:00:01.000Z',
				'hidden_at': '2020-01-01T00:00:01.000Z'
				},
			'episodes':
				{
				'watched_at': '2020-01-01T00:00:01.000Z',
				'collected_at': '2020-01-01T00:00:01.000Z',
				'rated_at': '2020-01-01T00:00:01.000Z',
				'watchlisted_at': '2020-01-01T00:00:01.000Z',
				'commented_at': '2020-01-01T00:00:01.000Z',
				'paused_at': '2020-01-01T00:00:01.000Z'
				},
			'shows':
				{
				'rated_at': '2020-01-01T00:00:01.000Z',
				'watchlisted_at': '2020-01-01T00:00:01.000Z',
				'favorited_at': '2020-01-01T00:00:01.000Z',
				'recommendations_at': '2020-01-01T00:00:01.000Z',
				'commented_at': '2020-01-01T00:00:01.000Z',
				'dropped_at': '2020-01-01T00:00:01.000Z'
				},
			'seasons':
				{
				'rated_at': '2020-01-01T00:00:01.000Z',
				'watchlisted_at': '2020-01-01T00:00:01.000Z',
				'commented_at': '2020-01-01T00:00:01.000Z',
				'hidden_at': '2020-01-01T00:00:01.000Z'
				},
			'comments':
				{
				'liked_at': '2020-01-01T00:00:01.000Z',
				'blocked_at': '2020-01-01T00:00:01.000Z'
				},
			'lists':
				{
				'liked_at': '2020-01-01T00:00:01.000Z',
				'updated_at': '2020-01-01T00:00:01.000Z',
				'commented_at': '2020-01-01T00:00:01.000Z'
				},
			'watchlist':
				{
				'updated_at': '2020-01-01T00:00:01.000Z'
				},
			'favorites':
				{
				'updated_at': '2020-01-01T00:00:01.000Z'
				},
			'recommendations':
				{
				'updated_at': '2020-01-01T00:00:01.000Z'
				},
			'collaborations':
				{
				'updated_at': '2020-01-01T00:00:01.000Z'
				},
			'account':
				{
				'settings_at': '2020-01-01T00:00:01.000Z',
				'followed_at': '2020-01-01T00:00:01.000Z',
				'following_at': '2020-01-01T00:00:01.000Z',
				'pending_at': '2020-01-01T00:00:01.000Z',
				'requested_at': '2020-01-01T00:00:01.000Z'
				},
			'saved_filters':
				{
				'updated_at': '2020-01-01T00:00:01.000Z'
				},
			'notes':
				{
				'updated_at': '2020-01-01T00:00:01.000Z'
				}
			}
	