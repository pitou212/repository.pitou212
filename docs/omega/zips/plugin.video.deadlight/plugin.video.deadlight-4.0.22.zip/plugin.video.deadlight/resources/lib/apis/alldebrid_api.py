# -*- coding: utf-8 -*-
import re
import time
from threading import Thread
from urllib.parse import quote
from caches.main_cache import cache_object
from caches.settings_cache import get_setting, set_setting
from modules.utils import copy2clip, make_qrcode, make_tinyurl
from modules.source_utils import supported_video_extensions, seas_ep_filter, extras, pick_episode_files, pick_episode_file
from modules.kodi_utils import progress_dialog, notification, hide_busy_dialog, show_busy_dialog, sleep, ok_dialog, progress_dialog, \
								notification, hide_busy_dialog, make_session
# from modules.kodi_utils import logger

# LOCAL PATCH 2026-06-20 (perf): pooled HTTP session reuses TCP connections across AllDebrid calls.
session = make_session('https://api.alldebrid.com/')

class AllDebridAPI:
	def __init__(self):
		self.token = get_setting('deadlight.ad.token', 'empty_setting')
		self.break_auth_loop = False
		self.base_url = 'https://api.alldebrid.com/v4/'
		self.user_agent = 'DeadLight for Kodi'

	def auth(self):
		self.token = ''
		url = self.base_url + 'pin/get?agent=%s' % self.user_agent
		response = session.get(url, timeout=20).json()
		response = response['data']
		expires_in = int(response['expires_in'])
		poll_url = response['check_url']
		user_code = response['pin']
		auth_url = 'https://alldebrid.com/pin?pin=%s' % user_code
		qr_code = make_qrcode(auth_url) or ''
		short_url = make_tinyurl(auth_url)
		copy2clip(auth_url)
		if short_url: p_dialog_insert = 'OR visit this URL: [B]%s[/B][CR]OR Enter this Code: [B]%s[/B]' % (short_url, user_code)
		else: p_dialog_insert = 'OR Enter this Code: [B]%s[/B]' % user_code
		sleep_interval = 5
		content = 'Please Scan the QR Code%s[CR]' % p_dialog_insert
		progressDialog = progress_dialog('All Debrid Authorize', qr_code)
		progressDialog.update(content, 0)
		start, time_passed = time.time(), 0
		sleep(2000)
		while not progressDialog.iscanceled() and time_passed < expires_in and not self.token:
			sleep(1000 * sleep_interval)
			response = session.get(poll_url, timeout=20).json()
			response = response['data']
			activated = response['activated']
			if not activated:
				time_passed = time.time() - start
				progress = int(100 * time_passed/float(expires_in))
				progressDialog.update(content, progress)
				continue
			try:
				progressDialog.close()
				self.token = str(response['apikey'])
				set_setting('ad.token', self.token)
			except:
				ok_dialog(text='Error')
				break
		try: progressDialog.close()
		except: pass
		if self.token:
			sleep(2000)
			account_info = self._get('user')
			set_setting('ad.account_id', str(account_info['user']['username']))
			set_setting('ad.enabled', 'true')
			ok_dialog(text='Success')

	def revoke(self):
		set_setting('ad.token', 'empty_setting')
		set_setting('ad.account_id', 'empty_setting')
		set_setting('ad.enabled', 'false')
		notification('All Debrid Authorization Reset', 3000)

	def account_info(self):
		response = self._get('user')
		return response

	def check_cache(self, hashes):
		data = {'magnets[]': hashes}
		response = self._post('magnet/instant', data)
		return response

	def user_cloud(self):
		url = 'magnet/status'
		string = 'ad_user_cloud'
		return cache_object(self._get, string, url, False, 0.03)

	def history(self):
		url = 'user/history'
		string = "ad_user_history"
		return cache_object(self._get, string, url, False, 0.03)

	def user_links(self):
		url = 'user/links'
		string = "ad_user_links"
		return cache_object(self._get, string, url, False, 0.03)

	def unrestrict_link(self, link):
		url = 'link/unlock'
		url_append = '&link=%s' % quote(link)
		response = self._get(url, url_append)
		try: return response['link']
		except: return None

	def create_transfer(self, magnet):
		url = 'magnet/upload'
		url_append = '&magnet=%s' % magnet
		result = self._get(url, url_append)
		if 'error' in result: return None
		return result['magnets'][0].get('id', None)

	def list_transfer(self, transfer_id):
		url = 'magnet/status'
		url_append = '&id=%s' % transfer_id
		result = self._get(url, url_append)
		return result['magnets']

	def delete_transfer(self, transfer_id):
		url = 'magnet/delete'
		url_append = '&id=%s' % transfer_id
		result = self._get(url, url_append)
		return result.get('message', '') == 'Magnet was successfully deleted'

	def correct_files_list(self, files_list):
		results = []
		while files_list:
			info = files_list.pop()
			if not isinstance(info, dict): continue
			if 'e' in info: files_list.extend(info['e'])
			elif info.get('l'): results.append(info)
		return results

	# LOCAL PATCH 2026-08-27: ep_candidates carries the alternate numberings an anime
	# release may use for this episode (see source_utils.anime_episode_candidates).
	# Empty/None for everything else, so non-anime resolution is byte-for-byte as before.
	# _matched is the numbering that actually found the file; the split=True call below
	# MUST reuse it, because with split=True a miss raises instead of returning False.
	def resolve_magnet(self, magnet_url, info_hash, store_to_cloud, title, season, episode, ep_candidates=None, ep_name=None):
		file_url, media_id, transfer_id = None, None, None
		# LOCAL PATCH 2026-10-25 (4.0.5): every failed exit says why, as TorBox and Real-Debrid do -- in the log and on screen
		# (sources.RESOLVE_REASON_PROP). It returned None silently, and a None from unrestrict_link raised on .lower().
		def _why(reason):
			try:
				from modules.kodi_utils import logger, set_property
				from modules.utils import redact_url
				reason = redact_url(str(reason))
				logger('AllDebrid resolve', '%s S%sE%s %s: %s' % (info_hash, season, episode, title, reason))
				set_property('deadlight.resolve_reason', 'AllDebrid: %s' % reason)
			except Exception: pass
		try:
			extensions = supported_video_extensions()
			correct_files = []
			transfer_id, links = self.parse_magnet(magnet_url=magnet_url)
			if not transfer_id:
				_why('magnet not accepted')
				return None
			if not links: _why('not ready (not cached on AllDebrid)')
			valid_results = [i for i in links if any(i.get('n').lower().endswith(x) for x in extensions) and not i.get('l', '') == '']
			if links and not valid_results: _why('no video file among %d files' % len(links))
			if valid_results:
				if season:
					# LOCAL PATCH 2026-11-04: the one shared pick (source_utils.pick_episode_file: largest non-extra hit)
					_pick = pick_episode_file(valid_results, season, episode, 'n', ep_candidates, title, ep_name)
					media_id = _pick.get('l') if _pick else None
				else: media_id = max(valid_results, key=lambda x: x.get('s')).get('l', None)
			if not store_to_cloud: Thread(target=self.delete_transfer, args=(transfer_id,)).start()
			if media_id:
				file_url = self.unrestrict_link(media_id)
				if not file_url: _why('no download link (unlock refused)')
				elif not any(file_url.lower().endswith(x) for x in extensions):
					_why('unlocked link is not a playable video')
					file_url = None
			elif valid_results: _why('no file for this episode among %d video files' % len(valid_results) if season else 'no file picked')
			return file_url
		except Exception as e:
			_why('failed: %s' % type(e).__name__)
			if transfer_id:
				try:self.delete_transfer(transfer_id)
				except: pass
			return None
	
	def display_magnet_pack(self, magnet_url, info_hash):
		from modules.source_utils import supported_video_extensions
		transfer_id = None
		try:
			extensions = supported_video_extensions()
			transfer_id, links = self.parse_magnet(magnet_url=magnet_url)
			if not transfer_id: return None
			end_results = [{'link': i['l'], 'filename': i['n'], 'size': i['s']} for i in links
							if any(i.get('n').lower().endswith(x) for x in extensions) and not i.get('l', '') == '']
			self.delete_transfer(transfer_id)
			return end_results
		except:
			try:
				if transfer_id: self.delete_transfer(transfer_id)
			except: pass
			return None

	def parse_magnet(self, magnet_url=None, transfer_id=None):
		if magnet_url:
			transfer_id = self.create_transfer(magnet_url)
			if not transfer_id: return None, []
		# LOCAL PATCH 2026-10-25 (4.0.5): was a fixed sleep(1000) before one status read. Read at once; while AllDebrid still
		# reports in progress (statusCode 0 queued, 1 downloading, 2 compressing, 3 uploading; 4 = ready, 5+ = error), re-read
		# every 250 ms up to the same ~1 s. A cached magnet is ready on the first read.
		transfer_info = self.list_transfer(transfer_id)
		if magnet_url:
			deadline = time.time() + 1.0
			while transfer_info.get('statusCode') in (0, 1, 2, 3) and time.time() < deadline:
				sleep(250)
				transfer_info = self.list_transfer(transfer_id)
		if transfer_info['statusCode'] != 4: return transfer_id, []
		links = self.correct_files_list(transfer_info.get('files', []))
		return transfer_id, links

	def _get(self, url, url_append=''):
		result = None
		try:
			if self.token in ('empty_setting', ''): return None
			url = self.base_url + url + '?agent=%s&apikey=%s' % (self.user_agent, self.token) + url_append
			if 'magnet/status' in url: url = url.replace('v4', 'v4.1')
			result = session.get(url, timeout=20).json()
			if result.get('status') == 'success' and 'data' in result: result = result['data']
		except: pass
		return result

	def _post(self, url, data={}):
		result = None
		try:
			if self.token in ('empty_setting', ''): return None
			url = self.base_url + url + '?agent=%s&apikey=%s' % (self.user_agent, self.token)
			result = session.post(url, data=data, timeout=20).json()
			if result.get('status') == 'success' and 'data' in result: result = result['data']
		except: pass
		return result

	def clear_cache(self, clear_hashes=True):
		from caches.debrid_cache import clear_account_cache   # LOCAL PATCH 2026-11-01 (cleanup): shared body
		return clear_account_cache('ad', ('ad_user_%', 'ad_list_transfer_%'), clear_hashes)


AllDebrid = AllDebridAPI()