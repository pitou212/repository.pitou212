# -*- coding: utf-8 -*-
# LOCAL PATCH: SmartPlay sticky-source management helpers.
# Module-level utilities for inspecting / clearing the JSON dict stored in
# the `deadlight.smartplay.state` setting. Used by:
#   - dialogs.playback_choice() — per-title "Clear SmartPlay Sticky" entry inside Playback Options
#   - dialogs.clear_all_sticky_sources_choice() — "Clear All" settings button
import json
from caches.settings_cache import get_setting, set_setting
from modules import kodi_utils

def load_all():
	"""Return the full sticky-source dict from settings, or {} on any error."""
	try:
		raw = get_setting('deadlight.smartplay.state', '')
		if not raw or raw == 'empty_setting': return {}
		data = json.loads(raw)
		return data if isinstance(data, dict) else {}   # LOCAL PATCH 2026-11-01 (cleanup): as sources.py's copy did
	except Exception:
		return {}

def save_all(data):
	"""Persist the sticky-source dict. Empty dict → wipe the setting."""
	try:
		set_setting('smartplay.state', json.dumps(data) if data else 'empty_setting')
		return True
	except Exception:
		return False

def clear_one(tmdb_id):
	"""Remove the sticky entry for one show (keyed by tmdb_id). Returns True
	if an entry was removed, False if no entry existed or save failed."""
	if not tmdb_id: return False
	data = load_all()
	key = str(tmdb_id)
	if key not in data: return False
	data.pop(key, None)
	return save_all(data)

def clear_all():
	"""Wipe the entire sticky-source state. Returns True on success."""
	return save_all({})

def pinned_ids():
	"""LOCAL PATCH 2026-09-27: every tmdb_id with a pin, as strings -- read ONCE per listing so the per-item
	context menu entry (Clear SmartPlay Pin) costs a set lookup, not a JSON parse per row."""
	return set(load_all())   # load_all never raises and always returns a dict


def count():
	"""Number of sticky entries currently stored."""
	return len(load_all())
