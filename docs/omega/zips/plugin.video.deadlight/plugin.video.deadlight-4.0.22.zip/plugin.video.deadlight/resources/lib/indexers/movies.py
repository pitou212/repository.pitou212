# -*- coding: utf-8 -*-
import sys
import json
import time
from modules.metadata import movie_meta, movieset_meta, light_meta, cached_meta, release_label, in_cinemas
from modules.metadata import is_anime_meta
from modules.utils import get_datetime, get_current_timestamp, jsondate_to_datetime, manual_function_import, extra_rating_props
from modules import kodi_utils, settings, watched_status
from indexers.media_list_base import MediaListBase

class Movies(MediaListBase):   # LOCAL PATCH 2026-10-19: context_menu, paginate_list, _size_pool_for_cold_page
	# LOCAL PATCH 2026-08-05 (POV 6.08 P1 port): tmdb_movies_trending added as Trakt-independent trending source
	main = ('tmdb_movies_popular', 'tmdb_movies_popular_today', 'tmdb_movies_trending', 'tmdb_movies_blockbusters','tmdb_movies_in_theaters', 'tmdb_movies_upcoming',
	'tmdb_movies_latest_releases', 'tmdb_movies_premieres', 'tmdb_movies_oscar_winners')
	special = ('tmdb_movies_languages', 'tmdb_movies_providers', 'tmdb_movies_year', 'tmdb_movies_decade', 'tmdb_movies_certifications', 'tmdb_movies_recommendations',
	'tmdb_movies_genres', 'tmdb_movies_companies', 'tmdb_movies_search', 'tmdb_movie_keyword_results', 'tmdb_movie_keyword_results_direct', 'ai_similar', 'anilist_recommended')
	personal = {'in_progress_movies': ('modules.watched_status', 'get_in_progress_movies'), 'favorites_movies': ('modules.favorites', 'get_favorites'),
	'watched_movies': ('modules.watched_status', 'get_watched_items'), 'recent_watched_movies': ('modules.watched_status', 'get_recently_watched'),
	'dropped_movies': ('modules.watched_status', 'get_dropped_items')}   # LOCAL PATCH 2026-10-06
	trakt_main = ('trakt_movies_trending', 'trakt_movies_trending_recent', 'trakt_movies_most_watched', 'trakt_movies_most_favorited', 'trakt_movies_top10_boxoffice')
	trakt_personal = ('trakt_collection', 'trakt_watchlist', 'trakt_collection_lists', 'trakt_watchlist_lists', 'trakt_favorites')

	def __init__(self, params):
		self.params = params
		self.params_get = self.params.get
		self.category_name = self.params_get('category_name', None) or self.params_get('name', None) or 'Movies'
		self.id_type, self.list, self.action = self.params_get('id_type', 'tmdb_id'), self.params_get('list', []), self.params_get('action', None)
		self.tmdb_api_key = settings.tmdb_api_key()
		self.items, self.new_page, self.total_pages, self.is_external = [], {}, None, kodi_utils.external()
		if self.is_external:
			self.widget_hide_next_page = settings.widget_hide_next_page()
			# LOCAL PATCH 2026-10-27: searches keep watched titles (AF3's search rows are widgets, so the setting hid them);
			# show_watched is the AniList search row (anilist_lists._render).
			self.widget_hide_watched = self.action not in ('watched_movies', 'recent_watched_movies', 'tmdb_movies_search') \
				and self.params_get('show_watched') != 'true' and settings.widget_hide_watched()
		else: self.widget_hide_next_page, self.widget_hide_watched = False, False
		self.playback_key = settings.playback_key()
		self.play_mode = 'playback.%s' % settings.playback_key()
		self.custom_order = self.params_get('custom_order', 'false') == 'true'
		self.paginate_start = int(self.params_get('paginate_start', '0'))
		self.append = self.items.append
		self.movieset_list_active = False
		# LOCAL PATCH 2026-10-19: anime films out of the movie catalogues (user's call: anime only in the anime catalogues,
		# as tvshows.TVShows._is_tv_catalogue) while 'Include anime in TV lists' is off. Not the personal lists -- there is no
		# anime twin of Movies > Watched -- nor a search, Recommended, keyword or AI Similar list.
		action = self.action or ''
		self.hide_anime = not settings.include_anime_tvshow() and (action in self.main or action in self.trakt_main or action in self.special) \
			and action not in ('tmdb_movies_search', 'tmdb_movies_recommendations', 'tmdb_movie_keyword_results',
								'tmdb_movie_keyword_results_direct', 'ai_similar', 'anilist_recommended')

	def fetch_list(self):
		handle = int(sys.argv[1])
		from modules.page_prefetch import page_marks, log_page   # LOCAL PATCH 2026-10-16: ###page timing###
		_marks, _rows_start = page_marks(), None
		try:
			try: page_no = int(self.params_get('new_page', '1'))
			except: page_no = self.params_get('new_page')
			if self.action in self.personal: var_module, import_function = self.personal[self.action]
			else: var_module, import_function = 'apis.%s_api' % self.action.split('_')[0], self.action
			try: function = manual_function_import(var_module, import_function)
			except: pass
			# LOCAL PATCH 2026-10-02: search results show TMDb art at once; TVDB / fanart.tv fill in afterwards
			if self.action == 'tmdb_movies_search':
				from modules.metadata import defer_artwork
				from apis.tmdb_api import SEARCH_POOL
				defer_artwork()
				self.search_pool = SEARCH_POOL   # see tmdb_api.SEARCH_POOL
			if page_no == 1 and not self.is_external: kodi_utils.set_property('deadlight.exit_params', kodi_utils.folder_path())
			if self.action in self.main:
				data = function(page_no)
				self._size_pool_for_cold_page()   # LOCAL PATCH 2026-10-03 (3.0.8)
				results = data['results']
				self.list = [i['id'] for i in results]
				if data['total_pages'] > page_no: self.new_page = {'new_page': str(data['page'] + 1)}
				self._prefetch(lambda: [i['id'] for i in function(page_no + 1)['results']])
			elif self.action in self.special:
				key_id = self.params_get('key_id') or self.params_get('query')
				if not key_id: return
				short = False
				if self.action in ('tmdb_movies_search', 'tmdb_tv_search'):   # LOCAL PATCH 2026-10-06: tmdb_api.search_superseded / short_search_filter
					from apis.tmdb_api import search_superseded, short_search_filter, light_search
					if self.is_external: light_search()   # LOCAL PATCH 2026-10-06: light rows fetch no details -- no details warm-ups
					from time import perf_counter
					_t0 = perf_counter()
					if search_superseded(key_id, self.is_external): data, short = {'results': [], 'total_pages': 1, 'page': 1}, True
					else:
						_t1 = perf_counter()
						data, short = short_search_filter(key_id, function(key_id, page_no))
						# LOCAL PATCH 2026-10-06: timed for the 'search.rows' line logged once the rows are built
						self._search_log, self._light_hits = {'query': key_id, 't0': _t0, 'wait': _t1 - _t0, 'search': perf_counter() - _t1}, []
					# LOCAL PATCH 2026-10-06: a skin search row is built from the search answer (metadata.light_meta)
					if self.is_external: self.light_rows = {i['id']: light_meta('movie', i) for i in data.get('results') or []}
				else: data = function(key_id, page_no)
				self._size_pool_for_cold_page()   # LOCAL PATCH 2026-10-03 (3.0.8)
				results = data['results']
				self.list = [i['id'] for i in results]
				if data['total_pages'] > page_no: self.new_page = {'new_page': str(data['page'] + 1), 'key_id': key_id}
				if not short: self._prefetch(lambda: [i['id'] for i in function(key_id, page_no + 1)['results']])
			elif self.action in self.personal:
				full = function('movie', page_no)
				data, total_pages = self.paginate_list(full, page_no)
				self.list = [i['media_id'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}
				self._prefetch(lambda: [i['media_id'] for i in self.paginate_list(full, page_no + 1)[0]])   # LOCAL PATCH 2026-10-25: local lists too
			elif self.action in self.trakt_main:
				self.id_type = 'trakt_dict'
				data = function(page_no)
				try: self.list = [i['movie']['ids'] for i in data]
				except: self.list = [i['ids'] for i in data]
				if self.action not in ('trakt_movies_top10_boxoffice', 'trakt_recommendations'): self.new_page = {'new_page': str(page_no + 1)}
				self._prefetch(lambda: [i['movie']['ids'] if 'movie' in i else i['ids'] for i in function(page_no + 1)])
			elif self.action in self.trakt_personal:
				self.id_type = 'trakt_dict'
				full = data = function('movies', page_no)
				if self.action in ('trakt_collection_lists', 'trakt_watchlist_lists', 'trakt_favorites'): total_pages = 1
				else: data, total_pages = self.paginate_list(data, page_no)
				self.list = [i['media_ids'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}
				except: pass
				self._prefetch(lambda: [i['media_ids'] for i in self.paginate_list(full, page_no + 1)[0]])   # LOCAL PATCH 2026-10-25
			elif self.action == 'trakt_recommendations':
				self.id_type = 'trakt_dict'
				full = function('movies')
				data, total_pages = self.paginate_list(full, page_no)
				self.list = [i['ids'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}
				except: pass
				self._prefetch(lambda: [i['ids'] for i in self.paginate_list(full, page_no + 1)[0]])   # LOCAL PATCH 2026-10-25
			elif self.action == 'tmdb_movies_discover':
				url = self.params_get('url')
				data = function(url, page_no)
				results = data['results']
				self.list = [i['id'] for i in results]
				if data['total_pages'] > page_no: self.new_page = {'url': url, 'new_page': str(data['page'] + 1)}
				self._prefetch(lambda: [i['id'] for i in function(url, page_no + 1)['results']])
			elif self.action  == 'tmdb_movies_sets':
				self.movieset_list_active = True
				data = sorted(movieset_meta(self.params_get('key_id'), self.tmdb_api_key)['parts'], key=lambda k: k['release_date'] or '2050')
				self.list = [i['id'] for i in data]
			elif self.action == 'trakt_movies_related':
				self.id_type = 'trakt_dict'
				key_id = self.params_get('key_id')
				if not key_id.startswith('tt'): key_id = movie_meta('tmdb_id', key_id, self.tmdb_api_key, settings.mpaa_region(), get_datetime())['imdb_id']
				data = function(key_id)
				self.list = [i['ids'] for i in data]
			elif self.action == 'imdb_more_like_this':
				from apis.imdb_api import imdb_more_like_this
				self.id_type = 'imdb_id'
				key_id = self.params_get('key_id')
				if self.params_get('get_imdb'):
					key_id = movie_meta('tmdb_id', key_id, self.tmdb_api_key, settings.mpaa_region(), get_datetime(), get_current_timestamp())['imdb_id']
				self.list = imdb_more_like_this(key_id)
			_rows_start = time.time()
			kodi_utils.add_items(handle, self.worker())
			if getattr(self, '_search_log', None):   # LOCAL PATCH 2026-10-06: one line per search row
				from time import perf_counter
				_sl = self._search_log
				kodi_utils.logger('search.rows', 'movies %r: %d rows (%d light) -- wait %.2fs, search %.2fs, total %.2fs' % (_sl['query'], len(self.items),
					len(getattr(self, '_light_hits', [])), _sl['wait'], _sl['search'], perf_counter() - _sl['t0']))
			if self.total_pages and self.total_pages > 2 and settings.jump_to_enabled() and not self.is_external:
				url_params = json.dumps({**self.new_page, **{'mode': 'build_movie_list', 'action': self.action, 'category_name': self.category_name}})
				kodi_utils.add_dir(handle, {'mode': 'navigate_to_page_choice', 'current_page': page_no, 'total_pages': self.total_pages, 'url_params': url_params},
											'Jump To...', 'item_jump', kodi_utils.get_icon('item_jump_landscape'), isFolder=False)
			if self.new_page and not self.widget_hide_next_page:
				self.new_page.update({'mode': 'build_movie_list', 'action': self.action, 'category_name': self.category_name})
				kodi_utils.add_dir(handle, self.new_page, 'Next Page (%s) >>' % self.new_page['new_page'], 'nextpage', kodi_utils.get_icon('nextpage_landscape'))
		except: pass
		kodi_utils.set_content(handle, 'movies')
		kodi_utils.set_category(handle, self.category_name)
		kodi_utils.end_directory(handle, cacheToDisc=False if self.is_external else True)
		if not self.is_external:
			log_page('movie', self.action, self.params_get('new_page', '1'), len(getattr(self, 'items', None) or []), _marks, _rows_start)
			kodi_utils.set_view_mode('view.movies', 'movies', self.is_external, refreshed=self.params_get('refreshed') == 'true')
		
	def _prefetch(self, fetch_ids):
		# LOCAL PATCH 2026-10-02: warm the next page once this one is on screen; see modules/page_prefetch.py
		if not self.new_page or self.is_external or self.action == 'tmdb_movies_search': return
		from modules.page_prefetch import queue
		queue('movie', self.id_type, fetch_ids)

	def build_movie_content(self, _position, _id):
		try:
			# LOCAL PATCH 2026-10-06: see metadata.light_meta. Only search rows have light_rows, keyed by TMDb id; most lists
			# hand their ids as DICTS (trakt_dict ...), which a dict lookup cannot hash -- the TypeError, swallowed by this
			# builder's except, emptied every Trakt / MDBList / AniList widget until the lookup was made search-only.
			_lr = getattr(self, 'light_rows', None)
			light = _lr.get(_id) if _lr and not isinstance(_id, dict) else None
			if light:
				meta = cached_meta('movie', _id, self.current_time) or light
				if meta is light: getattr(self, '_light_hits', []).append(_id)
			else: meta = movie_meta(self.id_type, _id, self.tmdb_api_key, self.mpaa_region, self.current_date, self.current_time)
			if not meta or 'blank_entry' in meta: return
			if self.hide_anime and is_anime_meta(meta): return   # LOCAL PATCH 2026-10-19, see __init__
			listitem = self.make_listitem()
			cm = []
			cm_append = cm.append
			set_properties = listitem.setProperties
			clearprog_params, watched_status_params = '', ''
			meta_get = meta.get
			premiered = meta_get('premiered')
			# LOCAL PATCH 2026-10-25: no year until it is released ('' -- setYear only for a real one). The stand-in was '2050',
			# which AF3 showed as the year: 'Bride of the Barrier Master 2050 - 1 Season' on Airing Next Season.
			title, year = meta_get('title'), meta_get('year') or ''
			# LOCAL PATCH 2026-10-25: an anime film TMDb has no date for yet takes AniList's start (anilist_lists._start_date)
			if isinstance(_id, dict):
				_start = _id.get('anilist_start') or ''
				if _start and not year: year = _start[:4]
				if len(_start) == 10 and not premiered: premiered = _start
			tmdb_id, imdb_id = meta_get('tmdb_id'), meta_get('imdb_id')
			str_tmdb_id = str(tmdb_id)
			if self.rpdb_api_key:
				try: poster = meta_get('rpdb_poster') % self.rpdb_api_key + self.rpdb_format
				except: poster = meta_get('poster') or self.poster_empty
			else: poster = meta_get('poster') or self.poster_empty
			fanart = meta_get('fanart') or self.fanart_empty
			clearlogo, landscape = meta_get('clearlogo') or '', meta_get('landscape') or ''
			thumb = poster or landscape or fanart
			movieset_id, movieset_name = meta_get('extra_info').get('collection_id', None), meta_get('extra_info').get('collection_name', None)
			first_airdate = jsondate_to_datetime(premiered, '%Y-%m-%d', True)
			duration = meta_get('duration')
			if not first_airdate or self.current_date < first_airdate: unaired = True
			else: unaired = False
			progress = watched_status.get_progress_status_movie(self.bookmarks, str_tmdb_id)
			playcount = watched_status.get_watched_status_movie(self.watched_info, str_tmdb_id)
			# LOCAL PATCH 2026-09-04: bail here, not 50 lines down. playcount is known at this
			# point, but the hide-watched check used to sit after 15 build_url() calls (each a
			# urlencode) and ~20 string formats had already been built for an item that is
			# then discarded. On a mostly-watched "hide watched" widget that was most of the
			# per-item cost. build_episode_list already short-circuits at the same point.
			if playcount and self.widget_hide_watched: return
			play_params = self.build_url({'mode': self.play_mode, 'media_type': 'movie', 'tmdb_id': tmdb_id, self.playback_key: self.playback_key})
			extras_params = self.build_url({'mode': 'extras_menu_choice', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'is_external': self.is_external})
			options_params = self.build_url({'mode': 'options_menu_choice', 'content': 'movie', 'tmdb_id': tmdb_id, 'poster': poster, 'is_external': self.is_external})
			playback_options_params = self.build_url({'mode': 'playback_choice', 'media_type': 'movie', 'meta': tmdb_id})
			belongs_to_movieset = 'true' if all([movieset_id, movieset_name]) else 'false'
			movieset_active = self.open_movieset and belongs_to_movieset == 'true'
			if self.open_extras or movieset_active: cm_append(['extras', ('[B]Play[/B]', 'RunPlugin(%s)' % play_params)])
			if not self.open_extras or movieset_active: cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
			if movieset_active: url_params = self.build_url({'mode': 'open_movieset_choice', 'key_id': movieset_id, 'name': movieset_name, 'is_external': self.is_external})
			elif self.open_extras: url_params = extras_params
			else: url_params = play_params
			cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
			cm_append(['playback_options', ('[B]Play Options[/B]', 'RunPlugin(%s)' % playback_options_params)])
			if str(tmdb_id) in self.pinned: cm_append(['playback_options', ('[B]Clear SmartPlay Pin[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'clear_smartplay_pin_choice', 'tmdb_id': tmdb_id}))])
			if belongs_to_movieset == 'true' and not self.movieset_list_active and not self.open_movieset:
				browse_movie_set_params = self.build_url({'mode': 'build_movie_list', 'action': 'tmdb_movies_sets', 'key_id': movieset_id,
										'name': movieset_name, 'is_external': self.is_external})
				cm_append(['browse_movie_set', ('[B]Browse Movie Set[/B]', self.window_command % browse_movie_set_params)])
			else: browse_movie_set_params = ''
			mark_entries = []
			if playcount:
				mark_entries.append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'watched_status.mark_movie', 'action': 'mark_as_unwatched',
											'tmdb_id': tmdb_id, 'title': title}))])
			elif not unaired:
				mark_entries.append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'watched_status.mark_movie', 'action': 'mark_as_watched',
											'tmdb_id': tmdb_id, 'title': title}))])
			if progress:
				mark_entries.append(['mark_watched', ('[B]Clear Progress[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'movie',
											'tmdb_id': tmdb_id, 'refresh': 'true'}))])
			# LOCAL PATCH 2026-11-01 (cleanup): Browse Recommended .. Reload Widgets are MediaListBase._shared_cm, shared with TVShows
			shared_props = self._shared_cm(cm, meta, 'movie', title, tmdb_id, imdb_id, 'None', poster, premiered,
										mark_entries=mark_entries, exit_label='[B]Exit Movie List[/B]')
			cm = self.context_menu(cm)
			info_tag = listitem.getVideoInfoTag(True)
			info_tag.setMediaType('movie'), info_tag.setTitle(title), info_tag.setOriginalTitle(meta_get('original_title')), info_tag.setGenres(meta_get('genre'))
			info_tag.setDuration(duration), info_tag.setPlaycount(playcount), info_tag.setPlot(meta_get('plot'))
			info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str_tmdb_id}), info_tag.setIMDBNumber(imdb_id), info_tag.setPremiered(premiered)
			(year and info_tag.setYear(int(year))), info_tag.setRating(meta_get('rating')), info_tag.setVotes(meta_get('votes')), info_tag.setMpaa(meta_get('mpaa'))
			info_tag.setCountries(meta_get('country')), info_tag.setTrailer(meta_get('trailer'))
			info_tag.setTagLine(meta_get('tagline')), info_tag.setStudios(meta_get('studio'))
			info_tag.setWriters(meta_get('writer')), info_tag.setDirectors(meta_get('director'))
			cast = meta_get('short_cast', []) or meta_get('cast', []) or []
			info_tag.setCast([self.kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
			if progress:
				info_tag.setResumePoint(watched_status.get_resume_seconds(progress, duration))
				set_properties({'WatchedProgress': progress})
			listitem.setLabel(title)
			listitem.addContextMenuItems(cm)
			# LOCAL PATCH 2026-08-06: extra_fanart_list from meta feeds AF3's fanart cycler
			# (Includes_DialogInfo.xml wires ListItem.Art(fanart1)..(fanart20)).
			# LOCAL PATCH 2026-09-15: no cap here -- metadata._EXTRA_FANART_CAP bounds the list
			# when it is built, so a future change to it needs no edit in the indexers.
			art = {'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo, 'landscape': landscape, 'thumb': thumb}
			try:
				for _idx, _bg in enumerate(meta_get('extra_fanart_list') or [], start=1):
					art['fanart%d' % _idx] = _bg
			except Exception: pass
			listitem.setArt(art)
			set_properties({
				'belongs_to_collection': belongs_to_movieset,
				'deadlight.extras_params': extras_params,
				'deadlight.options_params': options_params,
				'deadlight.playback_options_params': playback_options_params,
				'deadlight.browse_movie_set_params': browse_movie_set_params,
				**shared_props
				})
			extra_props = extra_rating_props(meta) or {}
			_release = release_label(premiered)   # LOCAL PATCH 2026-10-25: AF3's facts line shows it in place of the year
			if _release: extra_props['deadlight.release'] = _release
			if in_cinemas(premiered, meta_get('digital_release')): extra_props['deadlight.in_cinemas'] = 'true'   # LOCAL PATCH 2026-10-25: AF3's CINEMA flag
			if extra_props: set_properties(extra_props)
			self.append(((url_params, listitem, False), _position))
		except: kodi_utils.log_row_error('movies')

	def worker(self):
		self.kodi_actor, self.make_listitem, self.build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
		self.poster_empty, self.fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
		self.current_date, self.current_time, self.watched_indicators = get_datetime(), get_current_timestamp(), settings.watched_indicators()
		self.cm_sort_order = settings.cm_sort_order()
		self.custom_cm_menu = self.cm_sort_order != settings.cm_default_order()
		from modules.smartplay_utils import pinned_ids
		self.pinned = pinned_ids()   # LOCAL PATCH 2026-09-27: Clear SmartPlay Pin on the context menu
		self.mpaa_region = settings.mpaa_region()
		self.ai_model_active = settings.ai_model_active()
		rpdb_info = settings.rpdb_info('movie')
		self.rpdb_api_key, self.rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
		watched_db = watched_status.get_database(self.watched_indicators)
		self.watched_info, self.bookmarks = watched_status.watched_info_movie(watched_db), watched_status.get_bookmarks_movie(watched_db)
		self.window_command = 'ActivateWindow(Videos,%s,return)' if self.is_external else 'Container.Update(%s)'
		open_action = settings.media_open_action('movie')
		self.open_movieset = open_action in (2, 3) and not self.movieset_list_active
		self.open_extras = open_action in (1, 3)
		return self._run_builders(self.build_movie_content)

