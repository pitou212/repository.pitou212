# created by kodifitzwell for Fenomscrapers
"""
	Fenomscrapers Project
"""

import re
from magneto.modules import anime_utils
from magneto.modules.provider_base import StremioSource, anime_file_reject, anime_pack_reject, tag_batch


# LOCAL PATCH 2026-11-01 (cleanup): the sources / sources_packs bodies are provider_base.StremioSource's; this file keeps what
# is meteor's own -- its address, the AniList path, its '👥 seeders' info and the anime checks.
class source(StremioSource):
	provider = 'meteor'
	base_link = "https://meteorfortheweebs.midnightignite.me"
	# LOCAL PATCH 2026-10-27: AniList endpoint for anime. Meteor maps every id it takes (tt / kitsu / anilist / mal / anidb)
	# to one entry, so the answer is the same rows whichever id asks -- measured on 16 later cours and seasons and 12 shows
	# airing now (Fall 2026), 0.4-0.5 s each. AniList over Kitsu: Meteor's Kitsu map lags new entries -- kitsu ids for
	# Black Clover Season 2 and Dragon Ball Super: Beerus gave 0 streams where anilist / anidb / mal / IMDb gave 39 each.
	# A film is episode 1 of its entry ('anilist:1047:1', On Your Mark: 7 rows); bare movie/anilist:1047 finds nothing.
	animeSearch_link = '/stream/anime/anilist:%s:%s.json'
	_SEEDERS = re.compile(r'👥\s*(\d+)')

	def _query(self, data):
		q = super()._query(data)
		q['anilist_mode'] = q['anilist_film'] = False
		return q

	def _search_url(self, data, q):
		if q['tv']:
			# LOCAL PATCH 2026-10-27: DeadLight passes anilist_id + cour_episode (the entry's own episode, the absolute one for
			# a whole-run entry: anilist:21:1100 is One Piece 1100) for anime only (scrapers/external.py). Without both, IMDb.
			anilist_id, cour_ep = data.get('anilist_id'), data.get('cour_episode')
			q['anilist_mode'] = bool(data.get('is_anime')) and bool(anilist_id) and cour_ep is not None
			if q['anilist_mode']: return '%s%s' % (self.base_link, self.animeSearch_link % (anilist_id, cour_ep))
			return super()._search_url(data, q)
		# LOCAL PATCH 2026-10-27: an anime film keeps its IMDb id when it has one -- by IMDb Your Name gave 74 rows and Mugen
		# Train 87, by anilist:<id>:1 0 and 12. Only a film with no IMDb id is asked for by its AniList id.
		q['anilist_film'] = bool(data.get('anilist_id')) and not anime_utils.real_imdb(q['imdb'])
		return '%s%s' % (self.base_link, self.animeSearch_link % (data['anilist_id'], 1) if q['anilist_film'] else self.movieSearch_link % q['imdb'])

	def _episode_ok(self, file, lines, name, data, q):
		# LOCAL PATCH 2026-11-04 (release judge, phase 4b): an anime TV row is judged by modules/release_judge after the cache --
		# this provider's former checks for it (title_guard / check_title, anime_file_reject on the file it picked) are the judge's
		# rules for its rows now (release_judge._TAKEN_OVER, 'stremio'). Films and shows that are not anime: unchanged below.
		if q['tv'] and data.get('is_anime'): return True
		# LOCAL PATCH 2026-10-27: judged like torrentio's Kitsu path. Meteor's AniList answer is scoped to the entry, and
		# anime names carry no S01E05 ('[Erai-raws] One Piece - 1100'), which check_title demands -- so the SHOW is checked
		# (anime_utils.title_guard), then the file Meteor picked for junk, a later season, another cour, another show's year
		if not (q['anilist_mode'] or q['anilist_film']):
			if not self._check_title(name, q): return False
		elif not anime_utils.title_guard(name, q['title'], anime_utils.alias_titles(data)): return False
		if data.get('is_anime') and anime_file_reject(self._filename(file, lines), lines[0], q['title'], data): return False
		return True

	def _pack_ok(self, file, lines, name, package, data):
		if data.get('is_anime'): return True   # LOCAL PATCH 2026-11-04: the judge's (anime_pack_reject), see _episode_ok
		# LOCAL PATCH 2026-10-27: Meteor runs on anime now (source_utils.ANIME_PROVIDERS) -- torrentio's pack checks
		return not (data.get('is_anime') and anime_pack_reject(lines[0], self._filename(file, lines), package, data))

	def _tag(self, item, name, data, q):
		# LOCAL PATCH 2026-10-27: a batch ('[DB] Mob Psycho 100 III [BD1080p]') is tagged as one, like comet's Kitsu rows
		# (anime_utils.batch_fields); true_size because Meteor's size is the episode file's (source_utils.pack_size_divider)
		if q['anilist_mode']: tag_batch(item, name, data, true_size=True)
