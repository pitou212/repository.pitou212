"""
	Fenomscrapers Module

	LOCAL PATCH 2026-11-01 (cleanup): log() writes through DeadLight's logger (modules.kodi_utils) into kodi.log. It used to
	return at once unless magneto's 'debug.enabled' setting was on -- a setting DeadLight never had -- so it logged nothing,
	and source_utils.scraper_error() (which went through it) hid every provider failure. The magneto.log file it could write
	instead (debug.location / debug.reversed), clear_logFile and view_LogFile (which imported a textviewer that is not
	bundled) are gone.
"""

LOGDEBUG = 0
LOGINFO = 1
LOGWARNING = 2
LOGERROR = 3
LOGFATAL = 4


def log(msg, caller=None, level=LOGINFO):
	"""One '###magneto###' line in kodi.log; LOGDEBUG lines only with Kodi's own debug logging on (kodi_utils.logger_debug)."""
	try:
		from modules.kodi_utils import logger, logger_debug
		if isinstance(msg, bytes): msg = msg.decode('utf-8', errors='replace')
		msg = str(msg)
		if caller: msg = '%s: %s' % (caller, msg)
		(logger_debug if level == LOGDEBUG else logger)('magneto', msg)
	except Exception as e:
		import xbmc
		xbmc.log('[ DeadLight magneto ] log_utils.log() Logging Failure: %s' % (e), LOGERROR)

def error(message=None, exception=True):
	try:
		import sys
		if exception:
			type, value, traceback = sys.exc_info()
			# LOCAL PATCH 2026-10-09: bundled in DeadLight (resources/lib/magneto) since 3.0.0 the path has no
			# 'script.module.magneto' in it, so split(...)[1] raised IndexError and every provider error since 2026-09-26
			# surfaced only as 'log_utils.error() Logging Failure: list index out of range'. Take the part after either.
			filename = (traceback.tb_frame.f_code.co_filename).replace('\\', '/')
			for addon in ('script.module.magneto', 'resources/lib/magneto'):
				if addon in filename:
					filename = filename.split(addon)[-1]
					break
			# the frame that raised, not the provider's outer try
			last = traceback
			while last.tb_next: last = last.tb_next
			name = traceback.tb_frame.f_code.co_name
			linenumber = traceback.tb_lineno
			errortype = type.__name__
			errormessage = value or value.message
			if str(errormessage) == '': return
			if message: message += ' -> '
			else: message = ''
			message += str(errortype) + ' -> ' + str(errormessage)
			# LOCAL PATCH 2026-10-09: one line in kodi.log, where the provider was and the line that raised -- DeadLight's
			# ###row error### idea. (LOCAL PATCH 2026-11-01 (cleanup): always; the magneto debug-log branch it stood beside is gone.)
			import xbmc
			xbmc.log('###magneto error###: %s %s() line %s: %s (raised at %s:%s)' % (filename, name, linenumber, message,
				last.tb_frame.f_code.co_filename.replace('\\', '/').split('/')[-1], last.tb_lineno), LOGERROR)
			del(type, value, traceback, last) # So we don't leave our local labels/objects dangling
		elif message: log(message, level=LOGERROR)
	except Exception as e:
		import xbmc
		xbmc.log('[ DeadLight magneto ] log_utils.error() Logging Failure: %s' % (e), LOGERROR)

# LOCAL PATCH 2026-10-25 (4.0.5): upload_LogFile deleted -- never called, and it used source_utils.copy2clip (shell injection).
