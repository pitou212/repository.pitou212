# -*- coding: utf-8 -*-
import xbmcgui
import re
import json
from threading import Thread
from modules import kodi_utils, settings
from caches.settings_cache import get_setting, restore_setting_default
from modules.utils import manual_function_import

# LOCAL PATCH 2026-09-26: minidom is only needed by the font/skin-folder scans below, which run
# on a skin or font change -- not on every window open. Imported on first call.
def mdParse(source):
	from xml.dom.minidom import parse
	return parse(source)

def open_window(import_info, skin_xml, **kwargs):
	'''
	import_info: ('module', 'function')
	'''
	try:
		from modules.busy_guard import paused   # LOCAL PATCH 2026-11-01: a context action's spinner steps aside for the window
		xml_window = create_window(import_info, skin_xml, **kwargs)
		with paused(): choice = xml_window.run()
		del xml_window
		return choice
	except Exception as e:
		kodi_utils.logger('error in open_window', str(e))

def create_window(import_info, skin_xml, **kwargs):
	'''
	import_info: ('module', 'function')
	'''
	try:
		# LOCAL PATCH 2026-10-22: the windows' rounded textures live in media/deadlight_live/, built for Window Corners
		from modules.corner_style import ensure as ensure_corners
		ensure_corners()
		function = manual_function_import(*import_info)
		args = (skin_xml, kodi_utils.addon_path())
		xml_window = function(*args, **kwargs)
		return xml_window
	except Exception as e:
		kodi_utils.logger('error in create_window', str(e))
		return kodi_utils.notification('Error')

# LOCAL PATCH 2026-10-19: shared by window_manager and window_player -- window_player's runner called close() too, which
# only window_manager defined, so a failing Extras / person dialog after a trailer raised NameError and left the stack set.
def _close_windows(obj):
	obj.close()
	kodi_utils.clear_property('deadlight.window_loaded')
	kodi_utils.clear_property('deadlight.window_stack')

# LOCAL PATCH 2026-11-01 (cleanup): window_manager and window_player shared these as two nested copies
def _monitor(obj):
	timer = 0
	while not kodi_utils.get_property('deadlight.window_loaded') == 'true' and timer <= 5:
		kodi_utils.sleep(50)
		timer += 0.05
	kodi_utils.hide_busy_dialog()
	obj.close()
	kodi_utils.clear_property('deadlight.window_loaded')

def _run(obj, params, any_mode_is_person=False):
	"""window_manager closes on a mode it does not know; window_player opens the person dialog for any other mode."""
	try:
		mode = params['mode']
		if mode == 'extras_menu_choice':
			from indexers.dialogs import extras_menu_choice
			extras_menu_choice(params)
		elif any_mode_is_person or mode == 'person_data_dialog':
			from indexers.people import person_data_dialog
			person_data_dialog(params)
		else: _close_windows(obj)
	except: _close_windows(obj)

def window_manager(obj):
	def close(): _close_windows(obj)

	def get_stack():
		try: window_stack = json.loads(kodi_utils.get_property('deadlight.window_stack'))
		except: window_stack = []
		return window_stack

	def add_to_stack(params):
		window_stack.append(params)
		kodi_utils.set_property('deadlight.window_stack', json.dumps(window_stack))

	def remove_from_stack():
		previous_params = window_stack.pop()
		kodi_utils.set_property('deadlight.window_stack', json.dumps(window_stack))
		return previous_params
	kodi_utils.show_busy_dialog()
	try:
		kodi_utils.clear_property('deadlight.window_loaded')
		current_params = obj.current_params
		new_params = obj.new_params
		window_stack = get_stack()
		if current_params: add_to_stack(current_params)
		if new_params:
			Thread(target=_monitor, args=(obj,)).start()
			_run(obj, new_params)
		elif window_stack:
			previous_params = remove_from_stack()
			if previous_params:
				Thread(target=_monitor, args=(obj,)).start()
				_run(obj, previous_params)
		else: close()
	except: close()
	kodi_utils.hide_busy_dialog()

def window_player(obj):
	try:
		window_player_url = obj.window_player_url
		if 'plugin.video.youtube' in window_player_url:
			if not kodi_utils.addon_installed('plugin.video.youtube') or not kodi_utils.addon_enabled('plugin.video.youtube'):
				return kodi_utils.notification('Youtube Plugin needed for playback')
		kodi_utils.clear_property('deadlight.window_loaded')
		current_params = obj.current_params
		player = kodi_utils.kodi_player()
		player.play(window_player_url)
		kodi_utils.sleep(2000)
		# capped: a trailer the YouTube addon cannot resolve never starts, and this spun until Kodi quit
		waited = 0
		while not player.isPlayingVideo() and waited < 30000:
			kodi_utils.sleep(100)
			waited += 100
		if not player.isPlayingVideo(): return kodi_utils.hide_busy_dialog()
		obj.close()
		while player.isPlayingVideo(): kodi_utils.sleep(100)
		kodi_utils.show_busy_dialog()
		kodi_utils.sleep(1000)
		Thread(target=_monitor, args=(obj,)).start()
		_run(obj, current_params, any_mode_is_person=True)
	except: obj.close()
	kodi_utils.hide_busy_dialog()

# LOCAL PATCH 2026-10-24: Kodi resolves a colour's $INFO (colordiffuse, textcolor, focusedcolor) against the ACTIVE window,
# not the window the control is in -- visibility conditions and image paths use the control's own window. So when one of
# Kodi's dialogs opens over a DeadLight window (the number pad of a settings row, the keyboard, a context menu), every
# Window.Property colour read that dialog's empty property and drew white: the full-screen tint and the panel turned the
# whole screen white while the dialog faded in and out (screen recording 2026-10-24 11:54, frames 788 and 913-920).
# The colours are therefore read from Home copies, deadlight.win.<name>, which hold the top DeadLight window's values;
# when it closes, the one under it publishes its own again (BaseDialog.clearProperties).
_GLASS_STACK = []
_GLASS_COLOURS = ('deadlight.glass_tint', 'deadlight.fanart_dim', 'deadlight.panel', 'deadlight.focus', 'deadlight.focus_text',
				  'deadlight.focus_text2', 'deadlight.focus_icon', 'deadlight.focus_fill', 'deadlight.accent', 'deadlight.accent_soft')
_GLASS_WINDOW = ('deadlight.glass', 'deadlight.glass_fanart', 'deadlight.glass_tint')   # read by visibility and image paths

def _publish_glass_colours(properties):
	for k, v in properties:
		if k in _GLASS_COLOURS: kodi_utils.set_property(k.replace('deadlight.', 'deadlight.win.', 1), v)

class BaseDialog(xbmcgui.WindowXMLDialog):
	def __init__(self, *args):
		xbmcgui.WindowXMLDialog.__init__(self, args)
		self.args = args
		self.player = kodi_utils.kodi_player()
		self.left_action = 1
		self.right_action = 2
		self.up_action = 3
		self.down_action = 4
		self.info_action = 11
		self.selection_actions = (7, 100)
		self.closing_actions = (9, 10, 13, 92)
		self.context_actions = (101, 108, 117)
		self.set_glass()

	# LOCAL PATCH 2026-10-23 / 2026-10-24: glass, as AF3 draws it behind its dialogs (Glass_Backdrop, Includes_Search.xml).
	# Window properties the XML reads:
	#   deadlight.glass         the blurred artwork (AF3's order: the title's, the last search's, the simple background's)
	#   deadlight.glass_fanart  the focused item's fanart, laid over the blur at 40 percent (a Heavy blur is one flat colour)
	#   deadlight.glass_tint    the black layer over both, measured per image (modules/glass.py) so a white blur and a
	#                           black one end at the same brightness; darker where text sits on the background itself
	#   deadlight.fanart_dim    the same darkening as a colordiffuse, for a window's own fanart layer and the sources window
	#   deadlight.panel         the theme colour at the Window theme opacity setting's level
	#   deadlight.focus*        the focused plate and what sits on it
	# No blur over video, visualisations or slideshows -- Kodi cannot blur the live picture -- and then the windows are as
	# before. AF3's Glass style is not followed: every DeadLight label is light, so only a dark tint suits them.
	glass_full_screen = False   # True on the windows with text on the background (scraping screen, extras, people, viewers)
	# LOCAL PATCH 2026-10-24: the least the window's own SHARP fanart is darkened (sources windows). fanart_dim is measured on
	# TMDbHelper's blur -- the focused item's, not necessarily this title's, and darker than a sharp fanart -- so a bright
	# fanart got the 12 percent minimum (Eternally Yours' red, screenshot 345: deadlight.win.fanart_dim FFE0E0E0).
	glass_fanart_floor = 0.0

	def set_glass(self):
		from modules import glass as glass_mod
		glass = ''
		theme = kodi_utils.get_property('deadlight.window_theme') or 'CC1F2020'
		over_video = kodi_utils.get_visibility('Window.IsVisible(fullscreenvideo) | Window.IsVisible(visualisation) | Window.IsVisible(slideshow)')
		# Settings > General > Window Theme > Glass Background (window_glass): Auto (0) whenever the skin has a blur, Off (1)
		if get_setting('deadlight.window_glass', '0') != '1' and not over_video:
			for prop in ('TMDbHelper.ListItem.Current.BlurImage', 'Search.Backdrop', 'TMDbHelper.SimpleBackground.BlurImage'):
				glass = kodi_utils.get_infolabel('Window(Home).Property(%s)' % prop)
				if glass: break
		# LOCAL PATCH 2026-11-07: no sharp fanart over the blur any more (was the focused item's fanart at 40 percent): every
		# dialog loaded and drew two full-screen images; the blur alone, as AF3's own dialogs. The property stays, empty, so the
		# XML's layer is simply hidden.
		fanart = ''
		opacity = None
		if glass:
			try: opacity = glass_mod.dim(glass, glass_mod.TARGET_TEXT if self.glass_full_screen else glass_mod.TARGET_PANELS)
			except Exception: opacity = None
			if opacity is None: opacity = 0.45 if self.glass_full_screen else 0.2
		tint = glass_mod.black(opacity) if opacity else ''
		fanart_dim = glass_mod.grey(max(opacity, self.glass_fanart_floor)) if opacity else 'FFFFFFFF'
		# LOCAL PATCH 2026-11-07: Glass Background Off, or no blur to be had -> a plain background in the theme colour, the same
		# in every window (was black, black + a 25 percent fanart, or a dim layer over the skin, window by window). It goes in
		# the glass slot every window already draws: a white image under an opaque tint of the theme over black -- darker in a
		# dialog (0.55) so its own theme panel still stands out, 0.8 where text sits on the background. Never over video: a
		# pop-up during playback keeps the picture behind it.
		if not glass and not over_video:
			try: rgb_theme = tuple(int(theme[-6:][i:i + 2], 16) for i in (0, 2, 4))
			except ValueError: rgb_theme = (0x1F, 0x20, 0x20)
			k = (0.8 if self.glass_full_screen else 0.55) * int(theme[:2], 16) / 255.0 if len(theme) == 8 else 0.8
			# a full path: the XML loads this slot with background="true", which reads a file, not a skin media name
			glass, tint = 'special://home/addons/plugin.video.deadlight/resources/skins/Default/media/deadlight_common/white.png','FF%02X%02X%02X' % tuple(int(round(c * k)) for c in rgb_theme)
		self.glass_panel = theme
		# Glass Highlight (window_glass_focus): Follow Skin (0) = AF3's Focus style Glass (Skin.HasSetting(Glass.Focus)),
		# On (1), Off (2). Glass: the focused plate is the skin's focus colour (or white) at 35 percent and what sits on it
		# turns light; otherwise DeadLight's own near-white plate and dark text.
		focus_mode = get_setting('deadlight.window_glass_focus', '0')
		name = kodi_utils.get_infolabel('Skin.String(focuscolor.name)')
		rgb = name[2:].upper() if len(name) == 8 else ''
		light_text = ('FFE8E8EA', 'B3E8E8EA', 'FFE8E8EA', '59FFFFFF')
		if focus_mode == '1' or (focus_mode == '0' and kodi_utils.get_visibility('Skin.HasSetting(Glass.Focus)')):
			focus = ('59' + (rgb or 'FFFFFF'),) + light_text
		# LOCAL PATCH 2026-10-24: Follow Skin with AF3's solid Focus style -- its plate in the skin's highlight colour (was always
		# DeadLight's near-white: a white bar under AF3's yellow), dark text unless the skin reverts selected text (ColorSelected)
		elif focus_mode == '0' and rgb:
			focus = ('FF' + rgb,) + (light_text if kodi_utils.get_visibility('Skin.HasSetting(RevertSelectedText)') else ('FF141517', 'FF4a4347', 'FF1F2020', '40000000'))   # fill: the countdown over a focused button, a darker shade of any colour
		else: focus = ('FFE8E8EA', 'FF141517', 'FF4a4347', 'FF1F2020', 'FFB4B5BA')
		# LOCAL PATCH 2026-11-07: the amber marks (rings, bars, 'known for' chips) follow the chosen highlight too: the skin's
		# focus colour when there is one, DeadLight's amber otherwise (accent_soft = the same at 18 percent, chip plates)
		accent = rgb or 'E5B93C'
		self.glass_properties = (('deadlight.glass', glass), ('deadlight.glass_fanart', fanart), ('deadlight.glass_tint', tint),
			('deadlight.fanart_dim', fanart_dim), ('deadlight.panel', theme), ('deadlight.accent', 'FF' + accent),
			('deadlight.accent_soft', '2E' + accent)) +			tuple(zip(('deadlight.focus', 'deadlight.focus_text', 'deadlight.focus_text2', 'deadlight.focus_icon', 'deadlight.focus_fill'), focus))
		self._set_window_glass()
		_GLASS_STACK.append(self)
		_publish_glass_colours(self.glass_properties)

	# Every window clears its properties as soon as doModal() returns, while Kodi is still drawing its close fade: without
	# these the panel turned white (an empty colour) and the glass black for those frames. They stay.
	def clearProperties(self):
		xbmcgui.WindowXMLDialog.clearProperties(self)
		self._set_window_glass()
		# the window under this one gets its own colours back (Home copies, see _publish_glass_colours)
		if self in _GLASS_STACK: _GLASS_STACK.remove(self)
		if _GLASS_STACK: _publish_glass_colours(_GLASS_STACK[-1].glass_properties)

	def _set_window_glass(self):
		for k, v in self.glass_properties:
			if k in _GLASS_WINDOW: self.setProperty(k, v)

	def set_colour_property(self, name, value):
		"""A colour the window's XML reads: as a Home copy, deadlight.win.<name> (see _publish_glass_colours: a colour's
		$INFO follows the active window, so a window property went white under Kodi's dialogs)."""
		kodi_utils.set_property('deadlight.win.%s' % name, value)

	def get_setting(self, setting_id, setting_default=''):
		return get_setting(setting_id, setting_default)

	def restore_setting_default(self, params):
		restore_setting_default(params)

	def make_listitem(self):
		return kodi_utils.make_listitem()

	def build_url(self, params):
		return kodi_utils.build_url(params)

	def execute_code(self, command, block=False):
		return kodi_utils.execute_builtin(command, block)
	
	def get_position(self, window_id):
		return self.get_control(window_id).getSelectedPosition()

	def get_listitem(self, window_id):
		return self.get_control(window_id).getSelectedItem()

	def add_items(self, _control, _items):
		self.get_control(_control).addItems(_items)

	def select_item(self, _control, _item):
		self.get_control(_control).selectItem(_item)

	def set_image(self, _control, _image):
		self.get_control(_control).setImage(_image)

	def set_label(self, _control, _label):
		self.get_control(_control).setLabel(_label)

	def set_text(self, _control, _text):
		self.get_control(_control).setText(_text)

	def set_percent(self, _control, _percent):
		self.get_control(_control).setPercent(_percent)

	def reset_window(self, _control):
		self.get_control(_control).reset()

	def get_control(self, control_id):
		return self.getControl(control_id)


	def get_infolabel(self, label):
		return kodi_utils.get_infolabel(label)

	def get_visibility(self, command):
		return kodi_utils.get_visibility(command)
	
	def open_window(self, import_info, skin_xml, **kwargs):
		return open_window(import_info, skin_xml, **kwargs)

	# LOCAL PATCH 2026-11-08: the info panel shown while a poster row has focus (Extras, People) has two lines of the focused
	# title's plot in font12 across 1180 px: about 75-85 characters a line, so 150 keeps the '...' on line two. Kodi cannot end
	# a label with an ellipsis, so the text is cut here, at a word.
	PANEL_PLOT_CHARS = 150

	@staticmethod
	def fit_text(text, limit):
		text = ' '.join((text or '').split())
		if len(text) <= limit: return text
		return text[:limit - 3].rsplit(' ', 1)[0].rstrip(' ,;:-.') + '...'

	@classmethod
	def panel_plot(cls, text):
		return cls.fit_text(text, cls.PANEL_PLOT_CHARS)

	def track_buttons(self, buttons):
		"""LOCAL PATCH 2026-11-07: dialog buttons read their colours from Home copies deadlight.win.dlg<id>.bg / .fg (gen_dialogs.py,
		restyle_small.py). One colour only (user: a yellow 'last used' button next to the white focused one was confusing): every
		button the same grey, the focused one white (its focus texture)."""
		self._lb_buttons, self._lb_focus, self._lb_last = tuple(buttons), None, None
		self._paint_buttons()

	_lb_follow_focus = False   # True brings back the yellow 'last used' button (onFocus)

	def _paint_buttons(self):
		accent = kodi_utils.get_property('deadlight.win.focus') or 'FFE5B93C'
		accent_text = kodi_utils.get_property('deadlight.win.focus_text') or 'FF141517'
		idle = kodi_utils.get_property('deadlight.window_theme_contrast') or 'FF4a4347'   # the setting's own default
		for b in self._lb_buttons:
			last = b == self._lb_last
			self.set_colour_property('dlg%d.bg' % b, accent if last else idle)
			self.set_colour_property('dlg%d.fg' % b, accent_text if last else 'FFE8E8EA')

	def onFocus(self, controlId):
		buttons = getattr(self, '_lb_buttons', None)
		if not buttons or not self._lb_follow_focus: return
		previous = self._lb_focus
		if previous in buttons and previous != controlId and self._lb_last != previous:
			self._lb_last = previous
			self._paint_buttons()
		self._lb_focus = controlId

	def start_with_tasks(self):
		"""The onInit of Extras and People: mark the window loaded, start its background tasks, focus (or return to the saved spot)."""
		self.set_home_property('window_loaded', 'true')
		for i in self.tasks: Thread(target=i).start()
		self.set_default_focus()
		if self.starting_position:
			try: self.set_returning_focus(*self.starting_position)
			except: self.set_default_focus()

	def ensure_focus(self, control_id, tries=10):
		"""LOCAL PATCH 2026-11-07: a window opened while the busy spinner is up loses its focus when the spinner closes (the
		select after Download Pack, Watch Order: Kodi log 'Control ... has been asked to focus, but it can't', the first key
		presses went nowhere). Focus again until it holds."""
		for _ in range(tries):
			self.sleep(100)
			if self.getFocusId() == control_id: return True
			try: self.setFocusId(control_id)
			except Exception: pass
		return False

	def sleep(self, time):
		kodi_utils.sleep(time)

	def get_release_year(self, release_data):
		# the year of a 'YYYY-MM-DD' date, 'N/A' when there is none (Extras and People both list titles by year)
		try:
			if release_data in ('', None): release_data = 'N/A'
			else: release_data = release_data.split('-')[0]
		except: pass
		return release_data

	def set_home_property(self, prop, value):
		kodi_utils.set_property('deadlight.%s' % prop, value)

	def get_home_property(self, prop):
		return kodi_utils.get_property('deadlight.%s' % prop)

	def clear_home_property(self, prop):
		return kodi_utils.clear_property('deadlight.%s' % prop)

	def clear_modals(self):
		try: del self.player
		except: pass

	def notification(self, text, duration=3000):
		return kodi_utils.notification(text, duration)

class FontUtils:
	def execute_custom_fonts(self, skin_files=[]):
		if not skin_files and not self.skin_change_check(): return
		replacement_values, skin_font_xml = [], ''
		replacement_values_append = replacement_values.append
		skin_folder = self.get_skin_folder()
		if skin_folder: skin_font_xml = kodi_utils.translate_path('special://skin/%s/Font.xml' % skin_folder)
		if skin_font_xml: self.skin_font_info = self.get_font_info(skin_font_xml) or self.default_font_info()
		else: self.skin_font_info = self.default_font_info()
		for item in ((21, False, 'font10'), (26, False, 'font12'), (30, False, 'font13'), (33, False, 'font14'), (38, False, 'font16'), (60, True, 'font60')):
			replacement_values_append(self.match_font(*item))
		if not skin_files:
			kodi_utils.set_property('deadlight.current_skin', self.current_skin)
			kodi_utils.set_property('deadlight.current_font', self.current_font)
		skin_files = skin_files or kodi_utils.list_dirs(kodi_utils.translate_path('special://home/addons/plugin.video.deadlight/resources/skins/Default/1080i/'))[1]
		for item in skin_files: self.replace_font(item, replacement_values)

	def get_skin_folder(self):
		folder_options = ('xml', '1080', '720', '1080p', '720p', '1080i', '720i', '16x9')
		skin_folder = None
		try:
			skin_folder = mdParse(kodi_utils.translate_path('special://skin/addon.xml')).getElementsByTagName('extension')[0].getElementsByTagName('res')[0].getAttribute('folder')
			if not skin_folder:
				s_folder = kodi_utils.list_dirs(kodi_utils.translate_path('special://skin'))[0]
				skin_folder = [i for i in s_folder if i in folder_options][0]
		except: pass
		return skin_folder

	def skin_change_check(self):
		self.current_skin, self.current_font = kodi_utils.current_skin(), kodi_utils.jsonrpc_get_system_setting('lookandfeel.font', 'Default')
		if self.current_skin != kodi_utils.get_property('deadlight.current_skin') or self.current_font != kodi_utils.get_property('deadlight.current_font'): return True
		return False

	def match_font(self, size, bold, fallback):
		font_tag = 'DEADLIGHT_%s%s' % (size, '_BOLD' if bold else '')
		size_range = range(int(size * 0.75), int(size * 1.25))
		compatibility_range = range(int(size * 0.50), int(size * 1.50))
		compatibility_fonts = [i['name'] for i in self.skin_font_info if i['name'] == fallback and i['size'] in compatibility_range]
		if compatibility_fonts: return (font_tag, compatibility_fonts[0])
		sized_fonts = [i for i in self.skin_font_info if i['size'] in size_range]
		if not sized_fonts: return fallback
		fonts = [i for i in sized_fonts if i['bold'] == bold and not i['extra_styles']] or [i for i in sized_fonts if i['bold'] == bold] \
				or [i for i in sized_fonts if not i['extra_styles']] or sized_fonts
		return (font_tag, [i['name'] for i in fonts if i['size'] == min([i['size'] for i in fonts], key=lambda k: abs(k-size))][0])

	def get_font_info(self, skin_font_xml):
		extras_keys = ('upper', 'uppercase', 'italic', 'capitalize', 'black', 'mono', 'symbol')
		results = []
		if not skin_font_xml: return results
		results_append = results.append
		try:
			all_fonts = mdParse(skin_font_xml).getElementsByTagName('fontset')
			try: fontset = [i for i in all_fonts if i.getAttribute('id').lower() == self.current_font.lower()][0]
			except: fontset = all_fonts[0]
			font_element = fontset.getElementsByTagName('font')
			for item in font_element:
				try: name = item.getElementsByTagName('name')[0].firstChild.data
				except: continue
				try: size = int(item.getElementsByTagName('size')[0].firstChild.data)
				except: continue
				try: style = item.getElementsByTagName('style')[0].firstChild.data.lower()
				except: style = ''
				name_compare = name.lower()
				bold = any('bold' in item for item in (name_compare, style))
				extra_styles = any(item in style for item in extras_keys)
				if not extra_styles: extra_styles = any(item in name_compare for item in extras_keys)
				results_append({'name': name, 'size': size, 'bold': bold, 'extra_styles': extra_styles})
		except: pass
		return results

	def replace_font(self, window, replacement_values):
		file = kodi_utils.translate_path('special://home/addons/plugin.video.deadlight/resources/skins/Default/1080i/' + window)
		with kodi_utils.open_file(file) as f: content = f.read()
		original = content
		for item in replacement_values:
			try: content = re.sub(r'<font>(.*?)</font> <\!-- %s -->' % item[0], '<font>%s</font> <!-- %s -->' % (item[1], item[0]), content)
			except: pass
		# LOCAL PATCH 2026-10-02: write only a changed file. Every boot rewrote all ~20 skin XMLs (the service clears
		# deadlight.current_skin, so the skin always looks changed) while the home widgets were loading.
		if content == original: return
		with kodi_utils.open_file(file, 'w') as f: f.write(content)

	def default_font_info(self):
		return [{'name': 'font10', 'size': 21, 'bold': False, 'extra_styles': False},
				{'name': 'font12', 'size': 26, 'bold': False, 'extra_styles': False},
				{'name': 'font13', 'size': 30, 'bold': False, 'extra_styles': False},
				{'name': 'font14', 'size': 33, 'bold': False, 'extra_styles': False},
				{'name': 'font16', 'size': 38, 'bold': False, 'extra_styles': False},
				{'name': 'font45', 'size': 45, 'bold': False, 'extra_styles': False},
				{'name': 'font60', 'size': 60, 'bold': False, 'extra_styles': False}]


# one ratings slot of the Extras header (windows/base_window.ExtrasUtils.prefix_template): @PROP@ = the rating name, @N@ = 1..7
_RATING_SLOT = '''\
                    <control type="grouplist">
                        <width max="160">auto</width>
                        <height>44</height>
                        <orientation>horizontal</orientation>
                        <itemgap>8</itemgap>
                        <visible>String.IsEqual(Window.Property(@PROP@_rating),true)</visible>
                        <control type="image" id="410@N@">
                            <width>52</width>
                            <height>44</height>
                            <aspectratio>keep</aspectratio>
                            <aligny>center</aligny>
                        </control>
                        <control type="label" id="400@N@">
                            <width max="90">auto</width>
                            <height>44</height>
                            <font>font13</font> <!-- DEADLIGHT_30 -->
                            <textcolor>FFE8E8EA</textcolor>
                            <aligny>center</aligny>
                        </control>
                    </control>
'''
# one pill button of the Extras button row: @ID@, @B1@ / @B2@ (bold tags), @TC@ (text colour)
_PILL_BUTTON = '''\
                        <control type="button" id="@ID@">
                            <visible>!String.IsEmpty(Window.Property(button@ID@.label))</visible>
                            <onup>{last_container}</onup>
                            <ondown>{first_container}</ondown>
                            <width min="110" max="360">auto</width>
                            <height>60</height>
                            <label>@B1@$INFO[Window.Property(button@ID@.label)]@B2@</label>
                            <textoffsetx>24</textoffsetx>
                            <font>font12</font> <!-- DEADLIGHT_26 -->
                            <textcolor>@TC@</textcolor>
                            <focusedcolor>$INFO[Window(Home).Property(deadlight.win.focus_text)]</focusedcolor>
                            <texturefocus colordiffuse="$INFO[Window(Home).Property(deadlight.win.focus)]" border="30">deadlight_common/pill-60.png</texturefocus>
                            <texturenofocus colordiffuse="$INFO[Window(Home).Property(deadlight.window_theme_contrast)]" border="30">deadlight_common/pill-60.png</texturenofocus>
                            <align>center</align>
                            <aligny>center</aligny>
                        </control>
'''
# one cell of the Extras Details grid: @N@ = 1..6, @LEFT@ / @TOP@
_DETAIL_CELL = '''\
                    <control type="group">
                        <left>@LEFT@</left>
                        <top>@TOP@</top>
                        <visible>!String.IsEmpty(Window.Property(detail@N@.v))</visible>
                        <control type="label">
                            <width>370</width>
                            <height>26</height>
                            <font>font10</font> <!-- DEADLIGHT_21 -->
                            <textcolor>8CFFFFFF</textcolor>
                            <label>$INFO[Window.Property(detail@N@.k)]</label>
                        </control>
                        <control type="label">
                            <top>26</top>
                            <width>370</width>
                            <height>40</height>
                            <font>font13</font> <!-- DEADLIGHT_30 -->
                            <textcolor>FFE8E8EA</textcolor>
                            <label>[B]$INFO[Window.Property(detail@N@.v)][/B]</label>
                        </control>
                    </control>
'''

def _rating_slots():
	return ''.join(_RATING_SLOT.replace('@PROP@', prop).replace('@N@', str(n)) for n, prop in enumerate(['metascore', 'tomatometer', 'tomatousermeter', 'imdb', 'tmdb', 'anilist', 'myanimelist'], 1))

def _pill_buttons():
	# the first button (10) is the primary one: bold label, accent text; the others are plain
	return ''.join(_PILL_BUTTON.replace('@ID@', str(i)).replace('@B1@', '[B]' if i == 10 else '').replace('@B2@', '[/B]' if i == 10 else '')
				   .replace('@TC@', '$INFO[Window(Home).Property(deadlight.win.accent)]' if i == 10 else 'FFE8E8EA') for i in [10, 11, 12, 13, 14, 15, 16, 17])

def _detail_cells():
	return ''.join(_DETAIL_CELL.replace('@N@', str(n)).replace('@LEFT@', left).replace('@TOP@', top) for n, (left, top) in enumerate([('40', '24'), ('430', '24'), ('820', '24'), ('40', '106'), ('430', '106'), ('820', '106')], 1))


class ExtrasUtils:
	def __init__(self):
		self.media_heading = '[B]{label}[/B]  [COLOR 80FFFFFF]$INFO[Window.Property({label_lookup}.number)][/COLOR]'   # LOCAL PATCH 2026-11-07: 'Cast  13', not 'Cast x13'
		self.wide_thumb_highlight = '[B]{label} | [/B]$INFO[ListItem.Property(name)]'
		self.extras_items = {
		# LOCAL PATCH 2026-11-07: the header shows three lines of plot and the Details grid; this row has the whole plot
		2050: {'insert_values': {'heading_label': '[B]Plot[/B]', 'active_lookup': 'plot_enabled'},
								'template': self.details_template()},
		2051: {'insert_values': {'heading_label': self.media_heading.format(label='Cast', label_lookup='cast')},
								'template': self.cast_template()},   # LOCAL PATCH 2026-11-07: round faces with names
		2052: {'insert_values': {'heading_label': self.media_heading.format(label='Recommended', label_lookup='recommended')},
								'template': self.thumb_media_template()},
		2053: {'insert_values': {'heading_label': self.media_heading.format(label='Related', label_lookup='related')},
								'template': self.thumb_media_template()},
		2054: {'insert_values': {'heading_label': self.media_heading.format(label='More Like This', label_lookup='more_like_this')},
								'template': self.thumb_media_template()},
		2055: {'insert_values': {'heading_label': self.media_heading.format(label='Similar', label_lookup='ai_similar')},
								'template': self.thumb_media_template()},
		2056: {'insert_values': {'heading_label': self.media_heading.format(label='Reviews', label_lookup='imdb_reviews')},
								'template': self.text_media_template()},
		2057: {'insert_values': {'heading_label': self.media_heading.format(label='Comments', label_lookup='trakt_comments')},
								'template': self.text_media_template()},
		2058: {'insert_values': {'heading_label': self.media_heading.format(label='Trivia', label_lookup='imdb_trivia')},
								'template': self.text_media_template()},
		2059: {'insert_values': {'heading_label': self.media_heading.format(label='Blunders', label_lookup='imdb_blunders')},
								'template': self.text_media_template()},
		2060: {'insert_values': {}, 'template': self.parentsguide_template()},
		2061: {'insert_values': {'heading_label': self.media_heading.format(label='In Trakt Lists', label_lookup='trakt_in_lists')},
								'template': self.in_lists_template()},
		2062: {'insert_values': {'heading_label': self.media_heading.format(label='Videos', label_lookup='youtube_videos'),
								'highlight_label': self.wide_thumb_highlight.format(label='Videos')},
								'template': self.wide_thumb()},
		2063: {'insert_values': {'heading_label': self.media_heading.format(label='More from Year', label_lookup='more_from_year')},
								'template': self.thumb_media_template()},
		2064: {'insert_values': {'heading_label': self.media_heading.format(label='More from Genres', label_lookup='more_from_genres')},
								'template': self.thumb_media_template()},
		2065: {'insert_values': {'heading_label': self.media_heading.format(label='More from Networks', label_lookup='more_from_networks')},
								'template': self.thumb_media_template()},
		2066: {'insert_values': {}, 'template': self.collection_template()},
		# LOCAL PATCH 2026-10-09: AniList users' recommendations, anime only (windows/extras.make_anilist_recommended)
		2067: {'insert_values': {'heading_label': self.media_heading.format(label='AniList Recommended', label_lookup='anilist_recommended')},
								'template': self.thumb_media_template()}
						
						}

	def run(self):
		finished_templates = []
		skin_file = 'extras.xml'
		file = kodi_utils.translate_path('special://home/addons/plugin.video.deadlight/resources/skins/Default/1080i/%s' % skin_file)
		media_list = settings.extras_order()
		media_list_length = len(media_list)
		first_container = media_list[0]
		last_container = media_list[media_list_length - 1]
		for index, item in enumerate(media_list):
			if index == 0: previous_item = 9   # the button row (LOCAL PATCH 2026-11-07: Extras redesign)
			else: previous_item = media_list[index - 1]
			if index == media_list_length - 1: next_item = 9
			else: next_item = media_list[index + 1]
			item_values = self.extras_items[item]
			template = item_values['template']
			insert_values = item_values['insert_values']
			insert_values.update({'container_no': item, 'scrollbar_no': item + 2000, 'p_container_no': previous_item, 'n_container_no': next_item})
			template = template.format(**insert_values)
			finished_templates.append(template)
		body = ''.join(finished_templates)
		content = self.prefix_template().format(first_container=first_container, last_container=last_container) + body + self.suffix_template()
		# LOCAL PATCH 2026-10-02: write only when the layout changed. The file on disk carries the skin's font names (the
		# font pass below fills them in), so compare with the <font> values blanked out; the font pass then writes only if
		# the fonts themselves changed (replace_font).
		try:
			with kodi_utils.open_file(file) as f: on_disk = f.read()
		except Exception: on_disk = None
		if on_disk is None or re.sub(r'<font>.*?</font>', '', on_disk) != re.sub(r'<font>.*?</font>', '', content):
			with kodi_utils.open_file(file, 'w') as f: f.write(content)
		FontUtils().execute_custom_fonts(skin_files=[skin_file])

	def thumb_media_template(self):
		# LOCAL PATCH 2026-11-08: Extras 'D' (addon_patches/people_mockups/round4.html): the focused poster's name, year, rating and
		# plot are in ONE panel at the top (prefix_template), so the heading stays plain; the posters are as before.
		return  '''\
				<control type="group">
				    <visible>Integer.IsGreater(Container({container_no}).NumItems,0)</visible>
				    <height>890</height>
				    <control type="group">
				        <top>8</top>   <!-- LOCAL PATCH 2026-11-07: clear of the rows' clipping edge -->
				        <control type="label">
				            <width min="30" max="1160">auto</width>
				            <height>20</height>
				            <font>font14</font> <!-- DEADLIGHT_33 -->
				            <textcolor>FFE8E8EA</textcolor>
				            <label>{heading_label}</label>
				            <animation effect="fade" start="100" end="60" time="150" condition="!Control.HasFocus({container_no})">Conditional</animation>
				        </control>
				        <control type="image">
				            <!-- LOCAL PATCH 2026-11-08: Extras 'D': AF3's thin rule under the heading -->
				            <top>46</top>
				            <width>1180</width>
				            <height>2</height>
				            <texture colordiffuse="1FFFFFFF">deadlight_common/white.png</texture>
				        </control>
				        <control type="fixedlist" id="{container_no}">
				            <animation effect="slide" end="-472,0" time="0" condition="Integer.IsEqual(Container({container_no}).NumItems,1) | Integer.IsEqual(Container({container_no}).NumItems,2)">Conditional</animation>
				            <animation effect="slide" end="-236,0" time="0" condition="Integer.IsEqual(Container({container_no}).NumItems,3) | Integer.IsEqual(Container({container_no}).NumItems,4)">Conditional</animation>
				            <pagecontrol>{scrollbar_no}</pagecontrol>
				            <top>60</top>
				            <width>1180</width>
				            <height>360</height>
				            <onup>{p_container_no}</onup>
				            <ondown>{scrollbar_no}</ondown>
				            <orientation>horizontal</orientation>
				            <scrolltime tween="sine">500</scrolltime>
				            <focusposition>2</focusposition>
				            <movement>2</movement>
				            <itemlayout height="360" width="236">
				                <control type="image">
				                    <left>8</left>
				                    <top>8</top>
				                    <height>330</height>
				                    <width>220</width>
				                    <aspectratio scalediffuse="false">scale</aspectratio>
				                    <texture diffuse="deadlight_live/poster-50.png" background="true">$INFO[ListItem.Property(thumbnail)]</texture>
				                </control>
				            </itemlayout>
				            <focusedlayout height="360" width="236">
				                <control type="image">
				                    <left>8</left>
				                    <top>8</top>
				                    <height>330</height>
				                    <width>220</width>
				                    <aspectratio scalediffuse="false">scale</aspectratio>
				                    <texture diffuse="deadlight_live/poster-50.png" background="true">$INFO[ListItem.Property(thumbnail)]</texture>
				                </control>
				                <control type="image">
				                    <animation effect="fade" start="100" end="60" condition="Control.HasFocus({scrollbar_no})">Conditional</animation>
				                    <animation type="Focus" reversible="false">
				                        <effect type="zoom" end="105" time="75" tween="sine" easing="out" center="auto" />
				                        <effect type="zoom" end="95" time="225" tween="sine" delay="100" easing="out" center="auto" />
				                    </animation>
				                    <left>6</left>
				                    <top>6</top>
				                    <height>334</height>
				                    <width>224</width>
				                    <texture colordiffuse="$INFO[Window(Home).Property(deadlight.win.focus)]" border="24">deadlight_common/ring-hug.png</texture>
				                    <visible>Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})</visible>
				                </control>
				            </focusedlayout>
				        </control>
				        <control type="scrollbar" id="{scrollbar_no}">
				            <left>5</left>
				            <top>432</top>
				            <width>1170</width>
				            <height>15</height>
				            <onup>{container_no}</onup>
				            <ondown>{n_container_no}</ondown>
				            <texturesliderbackground colordiffuse="14FFFFFF">deadlight_common/white.png</texturesliderbackground>
				            <texturesliderbar colordiffuse="59FFFFFF">deadlight_common/white.png</texturesliderbar>
				            <texturesliderbarfocus colordiffuse="FFE8E8EA">deadlight_common/white.png</texturesliderbarfocus>
				            <showonepage>false</showonepage>
				            <orientation>Horizontal</orientation>
				            <visible>String.IsEqual(Window.Property(enable_scrollbars),true) + [Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})]</visible>
				        </control>
				        <control type="image">
				            <top>215</top>
				            <left>20</left>
				            <width>25</width>
				            <height>25</height>
				            <texture colordiffuse="CCCCCCCC" background="true">deadlight_common/arrow_left.png</texture>
				            <visible>[Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})] + Container({container_no}).HasPrevious</visible>
				        </control>
				        <control type="image">
				            <top>215</top>
				            <left>1135</left>
				            <width>25</width>
				            <height>25</height>
				            <texture colordiffuse="CCCCCCCC" background="true" flipx="true">deadlight_common/arrow_left.png</texture>
				            <visible>[Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})] + Container({container_no}).HasNext</visible>
				        </control>
				    </control>
				</control>
'''

	def text_media_template(self):
		return '''\
				<control type="group">
				    <visible>Integer.IsGreater(Container({container_no}).NumItems,0)</visible>
				    <height>890</height>
				    <control type="group">
				        <top>8</top>   <!-- LOCAL PATCH 2026-11-07: clear of the rows' clipping edge -->
				        <control type="image">
				            <!-- LOCAL PATCH 2026-11-08: AF3's thin rule under the row heading -->
				            <top>46</top>
				            <width>1180</width>
				            <height>2</height>
				            <texture colordiffuse="1FFFFFFF">deadlight_common/white.png</texture>
				        </control>
				        <control type="label">
				            <width max="1160">auto</width>
				            <height>20</height>
				            <font>font14</font> <!-- DEADLIGHT_33 -->
				            <textcolor>FFE8E8EA</textcolor>
				            <align>left</align>
				            <aligny>bottom</aligny>
				            <label>{heading_label}</label>
				        </control>
				        <control type="panel" id="{container_no}">
				            <pagecontrol>{scrollbar_no}</pagecontrol>
				            <top>60</top>
				            <width>1180</width>
				            <height>360</height>
				            <onup>{p_container_no}</onup>
				            <ondown>{scrollbar_no}</ondown>
				            <orientation>horizontal</orientation>
				            <scrolltime tween="sine">500</scrolltime>
				            <itemlayout height="380" width="590">
				                <!-- refresh: shadow -->
				                <control type="image">
				                    <left>-1</left>
				                    <top>-1</top>
				                    <width>582</width>
				                    <height>362</height>
				                    <texture colordiffuse="26FFFFFF" border="16">deadlight_live/rounded-16.png</texture>
				                </control>
				                <control type="image">
				                    <height>360</height>
				                    <width>580</width>
				                    <texture colordiffuse="$INFO[Window(10000).Property(deadlight.window_theme.extras)]" border="16">deadlight_live/rounded-16.png</texture>
				                </control>
				                <control type="textbox">
				                    <top>15</top>
				                    <left>20</left>
				                    <width>540</width>
				                    <height>308</height>
				                    <font>font12</font> <!-- DEADLIGHT_26 -->
				                    <align>center</align>
				                    <aligny>top</aligny>
				                    <textcolor>FFE8E8EA</textcolor>
				                    <label>$INFO[ListItem.Property(text)]</label>
				                    <autoscroll>false</autoscroll>
				                </control>
				            </itemlayout>
				            <focusedlayout height="380" width="590">
				                <control type="image">
				                    <height>360</height>
				                    <width>580</width>
				                    <texture colordiffuse="$INFO[Window(10000).Property(deadlight.window_theme.extras)]" border="16">deadlight_live/rounded-16.png</texture>
				                </control>
				                <control type="image">
				                    <height>360</height>
				                    <width>580</width>
				                    <texture colordiffuse="$INFO[Window(Home).Property(deadlight.win.focus)]" border="16">deadlight_live/outline-16.png</texture>
				                </control>
				                <control type="textbox">
				                    <top>15</top>
				                    <left>20</left>
				                    <width>540</width>
				                    <height>308</height>
				                    <font>font12</font> <!-- DEADLIGHT_26 -->
				                    <align>center</align>
				                    <aligny>top</aligny>
				                    <textcolor>FFE8E8EA</textcolor>
				                    <label>$INFO[ListItem.Property(text)]</label>
				                    <autoscroll>false</autoscroll>
				                </control>
				            </focusedlayout>
				        </control>
				        <control type="scrollbar" id="{scrollbar_no}">
				            <top>432</top>
				            <width>1170</width>
				            <height>15</height>
				            <onup>{container_no}</onup>
				            <ondown>{n_container_no}</ondown>
				            <texturesliderbackground colordiffuse="14FFFFFF">deadlight_common/white.png</texturesliderbackground>
				            <texturesliderbar colordiffuse="59FFFFFF">deadlight_common/white.png</texturesliderbar>
				            <texturesliderbarfocus colordiffuse="FFE8E8EA">deadlight_common/white.png</texturesliderbarfocus>
				            <showonepage>false</showonepage>
				            <orientation>Horizontal</orientation>
				            <visible>String.IsEqual(Window.Property(enable_scrollbars),true) + [Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})]</visible>
				        </control>
				        <control type="image">
				            <top>225</top>
				            <left>20</left>
				            <width>25</width>
				            <height>25</height>
				            <texture colordiffuse="CCCCCCCC" background="true">deadlight_common/arrow_left.png</texture>
				            <visible>[Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})] + Container({container_no}).HasPrevious</visible>
				        </control>
				        <control type="image">
				            <top>225</top>
				            <left>1125</left>
				            <width>25</width>
				            <height>25</height>
				            <texture colordiffuse="CCCCCCCC" background="true" flipx="true">deadlight_common/arrow_left.png</texture>
				            <visible>[Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})] + Container({container_no}).HasNext</visible>
				        </control>
				    </control>
				</control>
'''

	def details_template(self):
		# LOCAL PATCH 2026-11-07: Extras redesign -- the Details grid moved under the buttons; this row shows the whole plot
		# (the header has three lines of it). Plain text, an accent edge on focus; OK opens the reader (show_plot).
		return '''\
                <control type="group">
                    <visible>String.IsEqual(Window.Property({active_lookup}),true)</visible>
                    <height>780</height>
                    <control type="group">
                        <top>8</top>   <!-- LOCAL PATCH 2026-11-07: clear of the rows' clipping edge -->
                        <control type="label">
                            <width max="1160">auto</width>
                            <height>20</height>
                            <font>font14</font> <!-- DEADLIGHT_33 -->
                            <textcolor>FFE8E8EA</textcolor>
                            <align>left</align>
                            <aligny>bottom</aligny>
                            <label>{heading_label}</label>
                        </control>
                        <control type="button" id="{container_no}">
                            <top>50</top>
                            <width>1180</width>
                            <height>230</height>
                            <onup>{p_container_no}</onup>
                            <ondown>{n_container_no}</ondown>
                            <texturefocus colordiffuse="$INFO[Window(Home).Property(deadlight.win.accent_soft)]" border="16">deadlight_live/rounded-16.png</texturefocus>
                            <texturenofocus />
                        </control>
                        <control type="image">
                            <top>50</top>
                            <width>6</width>
                            <height>230</height>
                            <texture colordiffuse="$INFO[Window(Home).Property(deadlight.win.focus)]">deadlight_common/white.png</texture>
                            <visible>Control.HasFocus({container_no})</visible>
                        </control>
                        <control type="textbox">
                            <left>32</left>
                            <top>65</top>
                            <width>1120</width>
                            <height>200</height>
                            <font>font13</font> <!-- DEADLIGHT_30 -->
                            <textcolor>DBFFFFFF</textcolor>
                            <label>$INFO[Window.Property(plot)]</label>
                            <autoscroll>false</autoscroll>
                        </control>
                    </control>
                </control>
'''

	def cast_template(self):
		# LOCAL PATCH 2026-11-07: Extras redesign -- round faces with the actor and role under them, an accent ring on focus.
		# A plain list (not a fixedlist at focusposition 2), so the row starts at the left edge.
		return '''\
				<control type="group">
				    <visible>Integer.IsGreater(Container({container_no}).NumItems,0)</visible>
				    <height>830</height>
				    <control type="group">
				        <top>8</top>   <!-- LOCAL PATCH 2026-11-07: clear of the rows' clipping edge -->
				        <control type="image">
				            <!-- LOCAL PATCH 2026-11-08: AF3's thin rule under the row heading -->
				            <top>46</top>
				            <width>1180</width>
				            <height>2</height>
				            <texture colordiffuse="1FFFFFFF">deadlight_common/white.png</texture>
				        </control>
				        <control type="label">
				            <width min="30" max="1160">auto</width>
				            <height>20</height>
				            <font>font14</font> <!-- DEADLIGHT_33 -->
				            <textcolor>FFE8E8EA</textcolor>
				            <label>{heading_label}</label>
				        </control>
				        <control type="list" id="{container_no}">
				            <pagecontrol>{scrollbar_no}</pagecontrol>
				            <top>60</top>
				            <width>1240</width>
				            <height>290</height>
				            <onup>{p_container_no}</onup>
				            <ondown>{scrollbar_no}</ondown>
				            <orientation>horizontal</orientation>
				            <scrolltime tween="sine">400</scrolltime>
				            <itemlayout height="290" width="236">
				                <control type="image">
				                    <left>38</left>
				                    <top>10</top>
				                    <width>160</width>
				                    <height>160</height>
				                    <aspectratio scalediffuse="false">scale</aspectratio>
				                    <texture diffuse="deadlight_common/circle-256.png" background="true">$INFO[ListItem.Property(thumbnail)]</texture>
				                </control>
				                <control type="label">
				                    <top>186</top>
				                    <width>236</width>
				                    <height>30</height>
				                    <font>font10</font> <!-- DEADLIGHT_21 -->
				                    <textcolor>FFE8E8EA</textcolor>
				                    <align>center</align>
				                    <label>[B]$INFO[ListItem.Property(actor)][/B]</label>
				                </control>
				                <control type="label">
				                    <top>216</top>
				                    <width>236</width>
				                    <height>30</height>
				                    <font>font10</font> <!-- DEADLIGHT_21 -->
				                    <textcolor>8CFFFFFF</textcolor>
				                    <align>center</align>
				                    <label>$INFO[ListItem.Property(role)]</label>
				                </control>
				            </itemlayout>
				            <focusedlayout height="290" width="236">
				                <control type="image">
				                    <left>28</left>
				                    <top>0</top>
				                    <width>180</width>
				                    <height>180</height>
				                    <texture colordiffuse="$INFO[Window(Home).Property(deadlight.win.focus)]">deadlight_common/ring-256.png</texture>
				                    <visible>Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})</visible>
				                </control>
				                <control type="image">
				                    <left>38</left>
				                    <top>10</top>
				                    <width>160</width>
				                    <height>160</height>
				                    <aspectratio scalediffuse="false">scale</aspectratio>
				                    <texture diffuse="deadlight_common/circle-256.png" background="true">$INFO[ListItem.Property(thumbnail)]</texture>
				                </control>
				                <control type="label">
				                    <top>186</top>
				                    <width>236</width>
				                    <height>30</height>
				                    <font>font10</font> <!-- DEADLIGHT_21 -->
				                    <textcolor>FFE8E8EA</textcolor>
				                    <align>center</align>
				                    <label>[B]$INFO[ListItem.Property(actor)][/B]</label>
				                </control>
				                <control type="label">
				                    <top>216</top>
				                    <width>236</width>
				                    <height>30</height>
				                    <font>font10</font> <!-- DEADLIGHT_21 -->
				                    <textcolor>8CFFFFFF</textcolor>
				                    <align>center</align>
				                    <label>$INFO[ListItem.Property(role)]</label>
				                </control>
				            </focusedlayout>
				        </control>
				        <control type="scrollbar" id="{scrollbar_no}">
				            <left>5</left>
				            <top>362</top>
				            <width>1230</width>
				            <height>15</height>
				            <onup>{container_no}</onup>
				            <ondown>{n_container_no}</ondown>
				            <texturesliderbackground colordiffuse="14FFFFFF">deadlight_common/white.png</texturesliderbackground>
				            <texturesliderbar colordiffuse="59FFFFFF">deadlight_common/white.png</texturesliderbar>
				            <texturesliderbarfocus colordiffuse="FFE8E8EA">deadlight_common/white.png</texturesliderbarfocus>
				            <showonepage>false</showonepage>
				            <orientation>Horizontal</orientation>
				            <visible>String.IsEqual(Window.Property(enable_scrollbars),true) + [Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})]</visible>
				        </control>
				    </control>
				</control>
'''

	def prefix_template(self):
		# LOCAL PATCH 2026-11-07: Extras redesign 'A' (addon_patches/extras_mockups): the fanart is the whole screen, pushed right
		# behind left / bottom scrims; no poster (it repeated the logo and the fanart); a left-aligned header -- logo, one facts
		# line, an amber status pill, tagline, three lines of plot -- over ONE row of buttons: slot 1 (button 10) filled with the
		# accent, slots 2-8 (11-17) as smaller pills; a slot set to 'None (hidden)' takes no room. Focused = white.
		# The header fades and the rows slide up when focus leaves the buttons; a compact header (small logo + facts) stays.
		return '''\
<?xml version="1.0" encoding="UTF-8"?>
<window>
    <defaultcontrol always="true">10</defaultcontrol>
    <controls>
        <control type="group">
            <width>1920</width>
            <height>1080</height>
            <control type="image">
                <texture colordiffuse="FF06090B">deadlight_common/white.png</texture>
            </control>
            <control type="image" id="202">
                <left>360</left>
                <width>1920</width>
                <height>1080</height>
                <aspectratio>scale</aspectratio>
                <animation effect="fade" start="0" end="100" time="400">WindowOpen</animation>
                <animation effect="fade" start="100" end="45" time="300" condition="!ControlGroup(9).HasFocus">Conditional</animation>
            </control>
            <control type="image">
                <width>1500</width>
                <height>1080</height>
                <texture>deadlight_common/scrim-left.png</texture>
            </control>
            <control type="image">
                <top>560</top>
                <height>520</height>
                <texture>deadlight_common/scrim-bottom.png</texture>
            </control>
            <control type="image">
                <height>200</height>
                <texture>deadlight_common/scrim-top.png</texture>
            </control>
            <control type="image" id="200">
                <visible>false</visible>
            </control>
        </control>
        <control type="group">
            <animation effect="fade" end="100" time="200" delay="400">WindowOpen</animation>
            <control type="group">
                <left>5</left>
                <control type="image">
                    <top>5</top>
                    <width>60</width>
                    <height>60</height>
                    <aspectratio aligny="top">keep</aspectratio>
                    <texture>$INFO[Window(10000).Property(deadlight.addon_icon_mini)]</texture>
                </control>
                <control type="group">
                    <visible>String.IsEqual(ListItem.Property(info_alert),)</visible>
                    <control type="label">
                        <top>20</top>
                        <left>1590</left>
                        <width max="300">auto</width>
                        <height>20</height>
                        <font>font37</font> <!-- DEADLIGHT_38 -->
                        <textcolor>FFE8E8EA</textcolor>
                        <align>right</align>
                        <aligny>center</aligny>
                        <label>[B]$INFO[System.Time][/B]</label>
                    </control>
                    <control type="label">
                        <top>50</top>
                        <left>1540</left>
                        <width max="350">auto</width>
                        <height>20</height>
                        <font>font10</font> <!-- DEADLIGHT_21 -->
                        <textcolor>FFE8E8EA</textcolor>
                        <align>right</align>
                        <aligny>center</aligny>
                        <label>$INFO[System.Date]</label>
                    </control>
                </control>
                <control type="group">
                    <left>1250</left>
                    <top>25</top>
                    <control type="image">
                        <top>0</top>
                        <left>610</left>
                        <width>35</width>
                        <height>35</height>
                        <aspectratio>keep</aspectratio>
                        <texture>deadlight_common/info.png</texture>
                        <visible>!String.IsEqual(ListItem.Property(info_alert),)</visible>
                    </control>
                    <control type="label">
                        <width max="600">auto</width>
                        <height>20</height>
                        <font>font10</font> <!-- DEADLIGHT_21 -->
                        <textcolor>FFE8E8EA</textcolor>
                        <align>right</align>
                        <aligny>bottom</aligny>
                        <label>$INFO[ListItem.Property(info_alert)]</label>
                        <visible>!String.IsEqual(ListItem.Property(info_alert),)</visible>
                    </control>
                </control>
            </control>
            <!-- compact header, while the rows have focus (not a poster row: the panel below takes its place) -->
            <control type="grouplist">
                <visible>!ControlGroup(9).HasFocus + ![Control.HasFocus(2052) | Control.HasFocus(2053) | Control.HasFocus(2054) | Control.HasFocus(2055) | Control.HasFocus(2063) | Control.HasFocus(2064) | Control.HasFocus(2065) | Control.HasFocus(2066) | Control.HasFocus(2067)]</visible>
                <animation effect="fade" time="250">VisibleChange</animation>
                <left>96</left>
                <top>40</top>
                <width>1300</width>
                <height>100</height>
                <orientation>horizontal</orientation>
                <itemgap>28</itemgap>
                <control type="image">
                    <width>260</width>
                    <height>100</height>
                    <aspectratio align="left">keep</aspectratio>
                    <texture>$INFO[Window.Property(clearlogo_path)]</texture>
                    <visible>!String.IsEqual(Window.Property(clearlogo),false)</visible>
                </control>
                <control type="label">
                    <width max="600">auto</width>
                    <height>100</height>
                    <font>font16</font> <!-- DEADLIGHT_38 -->
                    <textcolor>FFE8E8EA</textcolor>
                    <aligny>center</aligny>
                    <label>[B]$INFO[Window.Property(title)][/B]</label>
                    <visible>String.IsEqual(Window.Property(clearlogo),false)</visible>
                </control>
                <control type="label">
                    <width max="1000">auto</width>
                    <height>100</height>
                    <font>font12</font> <!-- DEADLIGHT_26 -->
                    <textcolor>FFE8E8EA</textcolor>
                    <aligny>center</aligny>
                    <label>$INFO[Window.Property(facts_plain)]</label>
                </control>
            </control>
            <!-- LOCAL PATCH 2026-11-08: Extras 'D' (addon_patches/people_mockups/round4.html): ONE panel for the focused poster while a
                 poster row has focus, as AF3 Home does: title bold, 'year * rating' bold white, two grey lines of plot. ListItem.* is the
                 focused row's selected poster, so Kodi fills it with no Python while moving; windows/extras.panel_plot cuts the plot. -->
            <control type="group">
                <visible>[Control.HasFocus(2052) | Control.HasFocus(2053) | Control.HasFocus(2054) | Control.HasFocus(2055) | Control.HasFocus(2063) | Control.HasFocus(2064) | Control.HasFocus(2065) | Control.HasFocus(2066) | Control.HasFocus(2067)]</visible>
                <animation effect="fade" time="200">VisibleChange</animation>
                <left>96</left>
                <control type="label">
                    <top>72</top>
                    <width>1180</width>
                    <height>50</height>
                    <font>font16</font> <!-- DEADLIGHT_38 -->
                    <textcolor>FFFFFFFF</textcolor>
                    <label>[B]$INFO[ListItem.Property(name)][/B]</label>
                </control>
                <control type="label">
                    <top>128</top>
                    <width>1180</width>
                    <height>36</height>
                    <font>font13</font> <!-- DEADLIGHT_30 -->
                    <textcolor>FFFFFFFF</textcolor>
                    <label>[B]$INFO[ListItem.Property(release_date)]$INFO[ListItem.Property(vote_average), • ][/B]</label>
                </control>
                <control type="label">
                    <!-- two lines: a Kodi label draws every line whose TOP is inside it, so 48 px keeps line 2 and drops line 3 for any
                         line pitch from 24 to 47 px (font12 measured 28.6 on the laptop) -->
                    <top>176</top>
                    <width>1180</width>
                    <height>48</height>
                    <font>font12</font> <!-- DEADLIGHT_26 -->
                    <textcolor>9EFFFFFF</textcolor>
                    <wrapmultiline>true</wrapmultiline>
                    <label>$INFO[ListItem.Property(plot)]</label>
                </control>
            </control>
            <!-- full header + buttons -->
            <control type="grouplist">
                <animation effect="fade" start="100" end="0" time="250" condition="!ControlGroup(9).HasFocus">Conditional</animation>
                <left>96</left>
                <top>64</top>
                <width>1180</width>
                <height>800</height>
                <orientation>vertical</orientation>
                <itemgap>16</itemgap>
                <control type="group">
                    <height>200</height>
                    <control type="image" id="201">
                        <width>560</width>
                        <height>200</height>
                        <aspectratio align="left" aligny="bottom">keep</aspectratio>
                    </control>
                    <control type="label">
                        <top>100</top>
                        <width>1180</width>
                        <height>100</height>
                        <font>font60</font> <!-- DEADLIGHT_60_BOLD -->
                        <textcolor>FFE8E8EA</textcolor>
                        <aligny>bottom</aligny>
                        <label>[B]$INFO[Window.Property(title)][/B]</label>
                        <visible>String.IsEqual(Window.Property(clearlogo),false)</visible>
                    </control>
                </control>
                <control type="grouplist">
                    <!-- LOCAL PATCH 2026-11-07: the ratings (slots 4001-4007) lead the facts line; one rating uses icon 203 instead -->
                    <height>44</height>
                    <orientation>horizontal</orientation>
                    <itemgap>14</itemgap>
                    <control type="image" id="203">
                        <visible>!String.IsEmpty(Window.Property(facts_icon))</visible>
                        <width>44</width>
                        <height>44</height>
                        <aspectratio>keep</aspectratio>
                        <align>center</align>
                        <aligny>center</aligny>
                    </control>
''' + _rating_slots() + '''\
                    <control type="label" id="2001">
                        <width max="760">auto</width>
                        <height>44</height>
                        <font>font13</font> <!-- DEADLIGHT_30 -->
                        <textcolor>FFE8E8EA</textcolor>
                        <aligny>center</aligny>
                    </control>
                </control>
                <control type="grouplist">
                    <height>50</height>
                    <orientation>horizontal</orientation>
                    <visible>!String.IsEmpty(Window.Property(status_pill))</visible>
                    <control type="button">
                        <width min="80" max="1000">auto</width>
                        <height>50</height>
                        <enable>false</enable>
                        <textoffsetx>22</textoffsetx>
                        <font>font12</font> <!-- DEADLIGHT_26 -->
                        <disabledcolor>FFF2CC5C</disabledcolor>
                        <texturenofocus colordiffuse="$INFO[Window(Home).Property(deadlight.win.accent_soft)]" border="25">deadlight_common/pill-50.png</texturenofocus>
                        <texturefocus colordiffuse="$INFO[Window(Home).Property(deadlight.win.accent_soft)]" border="25">deadlight_common/pill-50.png</texturefocus>
                        <label>[B]$INFO[Window.Property(status_pill)][/B]</label>
                        <align>center</align>
                        <aligny>center</aligny>
                    </control>
                </control>
                <control type="label">
                    <width>1100</width>
                    <height>40</height>
                    <font>font13</font> <!-- DEADLIGHT_30 -->
                    <textcolor>BFFFFFFF</textcolor>
                    <label>[I]$INFO[Window.Property(tagline)][/I]</label>
                    <visible>!String.IsEmpty(Window.Property(tagline))</visible>
                </control>
                <control type="textbox">
                    <width>1020</width>
                    <height>114</height>
                    <font>font13</font> <!-- DEADLIGHT_30 -->
                    <textcolor>DBFFFFFF</textcolor>
                    <label>$INFO[Window.Property(plot_body)]</label>
                    <autoscroll>false</autoscroll>
                </control>
                <control type="grouplist" id="9">
                    <!-- LOCAL PATCH 2026-11-07: every slot in one row of smaller pills; a slot set to 'None (hidden)' takes no room -->
                    <height>60</height>
                    <width>1720</width>
                    <orientation>horizontal</orientation>
                    <itemgap>12</itemgap>
                    <!-- each button carries its own up / down: Kodi 21 does not hand a nested grouplist's to its children -->
''' + _pill_buttons() + '''\
                </control>
                <control type="group">
                    <!-- LOCAL PATCH 2026-11-07: the Details grid sits under the buttons (windows/extras.set_infoline2 fills detail1-6), in
                         the boxed look of the first Details row: a soft panel with an accent bar; one or two rows tall -->
                    <height>214</height>
                    <visible>!String.IsEmpty(Window.Property(detail1.v))</visible>
                    <control type="image">
                        <width>1180</width>
                        <height>214</height>
                        <texture colordiffuse="14FFFFFF" border="16">deadlight_live/rounded-16.png</texture>
                        <visible>!String.IsEmpty(Window.Property(detail4.v))</visible>
                    </control>
                    <control type="image">
                        <width>1180</width>
                        <height>114</height>
                        <texture colordiffuse="14FFFFFF" border="16">deadlight_live/rounded-16.png</texture>
                        <visible>!!String.IsEmpty(Window.Property(detail4.v))</visible>
                    </control>
                    <control type="image">
                        <width>6</width>
                        <height>214</height>
                        <texture colordiffuse="$INFO[Window(Home).Property(deadlight.win.focus)]">deadlight_common/white.png</texture>
                        <visible>!String.IsEmpty(Window.Property(detail4.v))</visible>
                    </control>
                    <control type="image">
                        <width>6</width>
                        <height>114</height>
                        <texture colordiffuse="$INFO[Window(Home).Property(deadlight.win.focus)]">deadlight_common/white.png</texture>
                        <visible>!!String.IsEmpty(Window.Property(detail4.v))</visible>
                    </control>
''' + _detail_cells() + '''\
                </control>
            </control>
            <control type="grouplist">
                <animation effect="slide" end="0,-740" time="300" tween="sine" easing="out" reversible="true" condition="!ControlGroup(9).HasFocus">Conditional</animation>
                <!-- LOCAL PATCH 2026-11-08: Extras 'D': a poster row has focus: the rows start under the info panel (190 -> 310) -->
                <animation effect="slide" end="0,120" time="300" tween="sine" easing="out" reversible="true" condition="[Control.HasFocus(2052) | Control.HasFocus(2053) | Control.HasFocus(2054) | Control.HasFocus(2055) | Control.HasFocus(2063) | Control.HasFocus(2064) | Control.HasFocus(2065) | Control.HasFocus(2066) | Control.HasFocus(2067)]">Conditional</animation>
                <!-- LOCAL PATCH 2026-11-07: the rows start right under the header: up by each header part this title lacks -->
                <animation effect="slide" end="0,-66" time="0" condition="ControlGroup(9).HasFocus + String.IsEmpty(Window.Property(status_pill))">Conditional</animation>
                <animation effect="slide" end="0,-56" time="0" condition="ControlGroup(9).HasFocus + String.IsEmpty(Window.Property(tagline))">Conditional</animation>
                <animation effect="slide" end="0,-230" time="0" condition="ControlGroup(9).HasFocus + String.IsEmpty(Window.Property(detail1.v))">Conditional</animation>
                <animation effect="slide" end="0,-100" time="0" condition="ControlGroup(9).HasFocus + !String.IsEmpty(Window.Property(detail1.v)) + String.IsEmpty(Window.Property(detail4.v))">Conditional</animation>
                <top>930</top>
                <left>96</left>
                <width>1240</width>
                <height>890</height>
                <orientation>vertical</orientation>
                <scrolltime tween="sine">500</scrolltime>
                <itemgap>-430</itemgap>   <!-- LOCAL PATCH 2026-11-07: each row is its content + 20 + an invisible 430 (cancelled here), so the focused row scrolls to the top and the row above is never half cut -->
                <usecontrolcoords>true</usecontrolcoords>

'''

	def suffix_template(self):
		return '''/
            </control>
        </control>
    </controls>
</window>

'''

	def collection_template(self):
		return '''\
                <control type="group">
                    <visible>Integer.IsGreater(Container({container_no}).NumItems,0)</visible>
                    <height>890</height>
                    <control type="group">
                        <top>8</top>   <!-- LOCAL PATCH 2026-11-07: clear of the rows' clipping edge -->
                        <control type="image">
                            <!-- LOCAL PATCH 2026-11-08: AF3's thin rule under the row heading -->
                            <top>46</top>
                            <width>1180</width>
                            <height>2</height>
                            <texture colordiffuse="1FFFFFFF">deadlight_common/white.png</texture>
                        </control>
                        <control type="label">
                            <width min="30" max="1160">auto</width>
                            <height>20</height>
                            <font>font14</font> <!-- DEADLIGHT_33 -->
                            <textcolor>FFE8E8EA</textcolor>
                            <label>[B]$INFO[Window.Property(more_from_collection.name)][/B]  [COLOR 80FFFFFF]$INFO[Window.Property(more_from_collection.number)][/COLOR]</label>
                            <!-- LOCAL PATCH 2026-11-08: the focused film is in the top info panel now (prefix_template), so one plain heading -->
                            <animation effect="fade" start="100" end="60" time="150" condition="!Control.HasFocus({container_no})">Conditional</animation>
                        </control>
                        <control type="group">
                            <top>60</top>
                            <!-- refresh: shadow -->
                            <control type="image">
                                <visible>Integer.IsGreater(Container({container_no}).NumItems,1)</visible>
                                <left>-24</left>
                                <top>-16</top>
                                <width>981</width>
                                <height>408</height>
                                <texture border="40">deadlight_live/shadow-16.png</texture>
                            </control>
                            <control type="image">
                                <visible>Integer.IsGreater(Container({container_no}).NumItems,1)</visible>
                                <left>-1</left>
                                <top>-1</top>
                                <width>935</width>
                                <height>362</height>
                                <texture colordiffuse="26FFFFFF" border="16">deadlight_live/rounded-16.png</texture>
                            </control>
                            <control type="image">
                                <height>360</height>
                                <width>933</width>
                                    <texture colordiffuse="$INFO[Window(10000).Property(deadlight.window_theme.extras)]" border="16">deadlight_live/rounded-16.png</texture>
                                <visible>Integer.IsGreater(Container({container_no}).NumItems,1)</visible>
                            </control>
                            <!-- refresh: shadow -->
                            <control type="image">
                                <visible>Integer.IsGreater(Container({container_no}).NumItems,2)</visible>
                                <left>-24</left>
                                <top>-16</top>
                                <width>1217</width>
                                <height>408</height>
                                <texture border="40">deadlight_live/shadow-16.png</texture>
                            </control>
                            <control type="image">
                                <visible>Integer.IsGreater(Container({container_no}).NumItems,2)</visible>
                                <left>-1</left>
                                <top>-1</top>
                                <width>1171</width>
                                <height>362</height>
                                <texture colordiffuse="26FFFFFF" border="16">deadlight_live/rounded-16.png</texture>
                            </control>
                            <control type="image">
                                <height>360</height>
                                <width>1169</width>
                                    <texture colordiffuse="$INFO[Window(10000).Property(deadlight.window_theme.extras)]" border="16">deadlight_live/rounded-16.png</texture>
                                <visible>Integer.IsGreater(Container({container_no}).NumItems,2)</visible>
                            </control>
                            <control type="image">
                                <left>6</left>
                                <top>6</top>
                                <width>224</width>
                                <height>348</height>
                                <aspectratio>keep</aspectratio>
                                <texture diffuse="deadlight_live/poster-50.png" background="true">$INFO[Window.Property(more_from_collection.poster)]</texture>
                            </control>
                            <control type="textbox">
                                <left>235</left>
                                <top>6</top>
                                <width>218</width>
                                <height>348</height>
                                <font>font12</font> <!-- DEADLIGHT_26 -->
                                <align>center</align>
                                <aligny>center</aligny>
                                <textcolor>FFE8E8EA</textcolor>
                                <label>$INFO[Window.Property(more_from_collection.overview)]</label>
                                <autoscroll time="1500" delay="6000" repeat="3000">true</autoscroll>
                            </control>
                        </control>
                        <control type="fixedlist" id="{container_no}">
                            <animation effect="slide" end="-236,0" time="0" condition="Integer.IsEqual(Container({container_no}).NumItems,2)">Conditional</animation>
                            <pagecontrol>{scrollbar_no}</pagecontrol>
                            <top>60</top>
                            <left>460</left>
                            <width>708</width>
                            <height>360</height>
                            <onup>{p_container_no}</onup>
                            <ondown>{scrollbar_no}</ondown>
                            <orientation>horizontal</orientation>
                            <scrolltime tween="sine">500</scrolltime>
                            <focusposition>1</focusposition>
                            <movement>1</movement>
                            <itemlayout height="360" width="236">
                                <control type="image">
                                    <left>8</left>
                                    <top>8</top>
                                    <height>330</height>
                                    <width>220</width>
                                    <aspectratio scalediffuse="false">scale</aspectratio>
                                    <texture diffuse="deadlight_live/poster-50.png" background="true">$INFO[ListItem.Property(thumbnail)]</texture>
                                </control>
                            </itemlayout>
                            <focusedlayout height="360" width="236">
                                <control type="image">
                                    <left>8</left>
                                    <top>8</top>
                                    <height>330</height>
                                    <width>220</width>
                                    <aspectratio scalediffuse="false">scale</aspectratio>
                                    <texture diffuse="deadlight_live/poster-50.png" background="true">$INFO[ListItem.Property(thumbnail)]</texture>
                                </control>
                                <control type="image">
                                    <animation effect="fade" start="100" end="60" condition="Control.HasFocus({scrollbar_no})">Conditional</animation>
                                    <animation type="Focus" reversible="false">
                                        <effect type="zoom" end="105" time="75" tween="sine" easing="out" center="auto" />
                                        <effect type="zoom" end="95" time="225" tween="sine" delay="100" easing="out" center="auto" />
                                    </animation>
                                    <left>6</left>
                                    <top>6</top>
                                    <height>334</height>
                                    <width>224</width>
                                    <texture colordiffuse="$INFO[Window(Home).Property(deadlight.win.focus)]" border="24">deadlight_common/ring-hug.png</texture>
                                    <visible>Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})</visible>
                                </control>
                            </focusedlayout>
                        </control>
                        <control type="scrollbar" id="{scrollbar_no}">
                            <top>432</top>
                            <width>1170</width>
                            <height>15</height>
                            <onup>{container_no}</onup>
                            <ondown>{n_container_no}</ondown>
                            <texturesliderbackground colordiffuse="14FFFFFF">deadlight_common/white.png</texturesliderbackground>
                            <texturesliderbar colordiffuse="59FFFFFF">deadlight_common/white.png</texturesliderbar>
                            <texturesliderbarfocus colordiffuse="FFE8E8EA">deadlight_common/white.png</texturesliderbarfocus>
                            <showonepage>false</showonepage>
                            <orientation>Horizontal</orientation>
                            <visible>String.IsEqual(Window.Property(enable_scrollbars),true) + [Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})]</visible>
                        </control>
                        <control type="image">
                            <top>215</top>
                            <left>480</left>
                            <width>25</width>
                            <height>25</height>
                            <texture colordiffuse="CCCCCCCC" background="true">deadlight_common/arrow_left.png</texture>
                            <visible>[Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})] + Container({container_no}).HasPrevious</visible>
                        </control>
                        <control type="image">
                            <top>215</top>
                            <left>1120</left>
                            <width>25</width>
                            <height>25</height>
                            <texture colordiffuse="CCCCCCCC" background="true" flipx="true">deadlight_common/arrow_left.png</texture>
                            <visible>[Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})] + Container({container_no}).HasNext</visible>
                        </control>
                    </control>
                </control>
'''

	def wide_thumb(self):
		return '''\
                <control type="group">
                    <visible>Integer.IsGreater(Container({container_no}).NumItems,0)</visible>
                    <height>890</height>
                    <control type="group">
                        <top>8</top>   <!-- LOCAL PATCH 2026-11-07: clear of the rows' clipping edge -->
                        <control type="image">
                            <!-- LOCAL PATCH 2026-11-08: AF3's thin rule under the row heading -->
                            <top>46</top>
                            <width>1180</width>
                            <height>2</height>
                            <texture colordiffuse="1FFFFFFF">deadlight_common/white.png</texture>
                        </control>
                        <control type="label">
                            <width min="30" max="1160">auto</width>
                            <height>20</height>
                            <font>font14</font> <!-- DEADLIGHT_33 -->
                            <textcolor>FFE8E8EA</textcolor>
                            <label>{heading_label}</label>
                            <visible>!Control.HasFocus({container_no})</visible>
                        </control>
                        <control type="label">
                            <width min="30" max="1160">auto</width>
                            <height>20</height>
                            <font>font14</font> <!-- DEADLIGHT_33 -->
                            <textcolor>FFE8E8EA</textcolor>
                            <label>{highlight_label}</label>
                            <visible>Control.HasFocus({container_no})</visible>
                        </control>
                        <control type="fixedlist" id="{container_no}">
                            <animation effect="slide" end="-392,0" time="0" condition="Integer.IsEqual(Container({container_no}).NumItems,1) | Integer.IsEqual(Container({container_no}).NumItems,2)">Conditional</animation>
                            <pagecontrol>{scrollbar_no}</pagecontrol>
                            <top>60</top>
                            <width>1180</width>
                            <height>360</height>
                            <onup>{p_container_no}</onup>
                            <ondown>{scrollbar_no}</ondown>
                            <orientation>horizontal</orientation>
                            <scrolltime tween="sine">500</scrolltime>
                            <focusposition>1</focusposition>
                            <movement>1</movement>
                            <itemlayout height="360" width="392">
                                <control type="image">
                                    <left>8</left>
                                    <top>74</top>
                                    <height>212</height>
                                    <width>376</width>
                                    <aspectratio scalediffuse="false">scale</aspectratio>
                                    <texture diffuse="deadlight_live/landscape.png" background="true">$INFO[ListItem.Property(thumbnail)]</texture>
                                </control>
                            </itemlayout>
                            <focusedlayout height="360" width="392">
                                <control type="image">
                                    <left>8</left>
                                    <top>74</top>
                                    <height>212</height>
                                    <width>376</width>
                                    <aspectratio scalediffuse="false">scale</aspectratio>
                                    <texture diffuse="deadlight_live/landscape.png" background="true">$INFO[ListItem.Property(thumbnail)]</texture>
                                </control>
                                <control type="image">
                                    <animation effect="fade" start="100" end="60" condition="Control.HasFocus({scrollbar_no})">Conditional</animation>
                                    <animation type="Focus" reversible="false">
                                        <effect type="zoom" end="105" time="75" tween="sine" easing="out" center="auto" />
                                        <effect type="zoom" end="95" time="225" tween="sine" delay="100" easing="out" center="auto" />
                                    </animation>
                                    <left>6</left>
                                    <top>72</top>
                                    <height>216</height>
                                    <width>380</width>
                                    <texture colordiffuse="$INFO[Window(Home).Property(deadlight.win.focus)]" border="24">deadlight_common/ring-hug.png</texture>
                                    <visible>Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})</visible>
                                </control>
                            </focusedlayout>
                        </control>
                        <control type="scrollbar" id="{scrollbar_no}">
                            <left>5</left>
                            <top>432</top>
                            <width>1165</width>
                            <height>15</height>
                            <onup>{container_no}</onup>
                            <ondown>{n_container_no}</ondown>
                            <texturesliderbackground colordiffuse="14FFFFFF">deadlight_common/white.png</texturesliderbackground>
                            <texturesliderbar colordiffuse="59FFFFFF">deadlight_common/white.png</texturesliderbar>
                            <texturesliderbarfocus colordiffuse="FFE8E8EA">deadlight_common/white.png</texturesliderbarfocus>
                            <showonepage>false</showonepage>
                            <orientation>Horizontal</orientation>
                            <visible>String.IsEqual(Window.Property(enable_scrollbars),true) + [Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})]</visible>
                        </control>
                        <control type="image">
                            <top>230</top>
                            <left>20</left>
                            <width>25</width>
                            <height>25</height>
                            <texture colordiffuse="CCCCCCCC" background="true">deadlight_common/arrow_left.png</texture>
                            <visible>[Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})] + Container({container_no}).HasPrevious</visible>
                        </control>
                        <control type="image">
                            <top>230</top>
                            <left>1125</left>
                            <width>25</width>
                            <height>25</height>
                            <texture colordiffuse="CCCCCCCC" background="true" flipx="true">deadlight_common/arrow_left.png</texture>
                            <visible>[Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})] + Container({container_no}).HasNext</visible>
                        </control>
                    </control>
                </control>
'''

	def in_lists_template(self):
		return '''\
                <control type="group">
                    <visible>Integer.IsGreater(Container({container_no}).NumItems,0)</visible>
                    <height>890</height>
                    <control type="group">
                        <top>8</top>   <!-- LOCAL PATCH 2026-11-07: clear of the rows' clipping edge -->
                        <control type="image">
                            <!-- LOCAL PATCH 2026-11-08: AF3's thin rule under the row heading -->
                            <top>46</top>
                            <width>1180</width>
                            <height>2</height>
                            <texture colordiffuse="1FFFFFFF">deadlight_common/white.png</texture>
                        </control>
                        <control type="label">
                            <width max="1160">auto</width>
                            <height>20</height>
                            <font>font14</font> <!-- DEADLIGHT_33 -->
                            <textcolor>FFE8E8EA</textcolor>
                            <align>left</align>
                            <aligny>bottom</aligny>
                            <label>{heading_label}</label>
                        </control>
                        <control type="fixedlist" id="{container_no}">
                            <animation effect="slide" end="-472,0" time="0" condition="Integer.IsEqual(Container({container_no}).NumItems,1) | Integer.IsEqual(Container({container_no}).NumItems,2)">Conditional</animation>
                            <animation effect="slide" end="-236,0" time="0" condition="Integer.IsEqual(Container({container_no}).NumItems,3) | Integer.IsEqual(Container({container_no}).NumItems,4)">Conditional</animation>
                            <pagecontrol>{scrollbar_no}</pagecontrol>
                            <top>60</top>
                            <width>1180</width>
                            <height>360</height>
                            <onup>{p_container_no}</onup>
                            <ondown>{scrollbar_no}</ondown>
                            <orientation>horizontal</orientation>
                            <scrolltime tween="sine">500</scrolltime>
                            <focusposition>2</focusposition>
                            <movement>2</movement>
                            <itemlayout height="360" width="236">
                                <!-- refresh: shadow -->
                                <control type="image">
                                    <left>-1</left>
                                    <top>-1</top>
                                    <width>232</width>
                                    <height>362</height>
                                    <texture colordiffuse="26FFFFFF" border="16">deadlight_live/rounded-16.png</texture>
                                </control>
                                <control type="image">
                                    <height>360</height>
                                    <width>230</width>
                                    <texture colordiffuse="$INFO[Window(10000).Property(deadlight.window_theme.extras)]" border="16">deadlight_live/rounded-16.png</texture>
                                </control>
                                <control type="image">
                                    <left>-35</left>
                                    <top>20</top>
                                    <width>300</width>
                                    <height>300</height>
                                    <align>center</align>
                                    <aligny>center</aligny>
                                    <aspectratio>scale</aspectratio>
                                    <texture colordiffuse="0DFFFFFF">$INFO[ListItem.Property(thumbnail)]</texture>
                                </control>
                                <control type="textbox">
                                    <left>5</left>
                                    <top>10</top>
                                    <width>220</width>
                                    <height>340</height>
                                    <font>font12</font> <!-- DEADLIGHT_26 -->
                                    <align>center</align>
                                    <aligny>center</aligny>
                                    <textcolor>FFE8E8EA</textcolor>
                                    <label>$INFO[ListItem.Property(name)]</label>
                                    <autoscroll>false</autoscroll>
                                </control>
                                <control type="image">
                                    <top>-300</top>
                                    <left>90</left>
                                    <width>50</width>
                                    <aspectratio>keep</aspectratio>
                                    <texture colordiffuse="red">deadlight_common/overlay_selected.png</texture>
                                    <visible>String.IsEqual(ListItem.Property(liked_status),true)</visible>
                                </control>
                            </itemlayout>
                            <focusedlayout height="360" width="236">
                                <control type="image">
                                    <width>230</width>
                                    <height>360</height>
                                    <texture colordiffuse="$INFO[Window(10000).Property(deadlight.window_theme.extras)]" border="16">deadlight_live/rounded-16.png</texture>
                                    <visible>Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})</visible>
                                    <animation effect="fade" start="100" end="60" condition="Control.HasFocus({scrollbar_no})">Conditional</animation>
                                </control>
                                <control type="image">
                                    <width>230</width>
                                    <height>360</height>
                                    <texture colordiffuse="$INFO[Window(Home).Property(deadlight.win.focus)]" border="16">deadlight_live/outline-16.png</texture>
                                    <visible>Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})</visible>
                                    <animation effect="fade" start="100" end="60" condition="Control.HasFocus({scrollbar_no})">Conditional</animation>
                                </control>
                                <!-- refresh: shadow -->
                                <control type="image">
                                    <visible>![Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})]</visible>
                                    <left>-1</left>
                                    <top>-1</top>
                                    <width>232</width>
                                    <height>362</height>
                                    <texture colordiffuse="26FFFFFF" border="16">deadlight_live/rounded-16.png</texture>
                                </control>
                                <control type="image">
                                    <height>360</height>
                                    <width>230</width>
                                    <texture colordiffuse="$INFO[Window(10000).Property(deadlight.window_theme.extras)]" border="16">deadlight_live/rounded-16.png</texture>
                                    <visible>![Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})]</visible>
                                </control>
                                <control type="image">
                                    <left>-35</left>
                                    <top>20</top>
                                    <width>300</width>
                                    <height>300</height>
                                    <align>center</align>
                                    <aligny>center</aligny>
                                    <aspectratio>scale</aspectratio>
                                    <texture colordiffuse="1A1F2020">$INFO[ListItem.Property(thumbnail)]</texture>
                                </control>
                                <control type="textbox">
                                    <left>5</left>
                                    <top>10</top>
                                    <width>220</width>
                                    <height>340</height>
                                    <font>font12</font> <!-- DEADLIGHT_26 -->
                                    <align>center</align>
                                    <aligny>center</aligny>
                                    <textcolor>FFE8E8EA</textcolor>
                                    <label>$INFO[ListItem.Property(name)]</label>
                                    <autoscroll>false</autoscroll>
                                    <visible>Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})</visible>
                                </control>
                                <control type="textbox">
                                    <left>5</left>
                                    <top>10</top>
                                    <width>220</width>
                                    <height>340</height>
                                    <font>font12</font> <!-- DEADLIGHT_26 -->
                                    <align>center</align>
                                    <aligny>center</aligny>
                                    <textcolor>FFE8E8EA</textcolor>
                                    <label>$INFO[ListItem.Property(name)]</label>
                                    <autoscroll>false</autoscroll>
                                    <visible>![Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})]</visible>
                                </control>
                                <control type="image">
                                    <top>-300</top>
                                    <left>90</left>
                                    <width>50</width>
                                    <aspectratio>keep</aspectratio>
                                    <texture colordiffuse="red">deadlight_common/overlay_selected.png</texture>
                                    <visible>String.IsEqual(ListItem.Property(liked_status),true)</visible>
                                </control>
                            </focusedlayout>
                        </control>
                        <control type="scrollbar" id="{scrollbar_no}">
                            <left>5</left>
                            <top>432</top>
                            <width>1170</width>
                            <height>15</height>
                            <onup>{container_no}</onup>
                            <ondown>{n_container_no}</ondown>
                            <texturesliderbackground colordiffuse="14FFFFFF">deadlight_common/white.png</texturesliderbackground>
                            <texturesliderbar colordiffuse="59FFFFFF">deadlight_common/white.png</texturesliderbar>
                            <texturesliderbarfocus colordiffuse="FFE8E8EA">deadlight_common/white.png</texturesliderbarfocus>
                            <showonepage>false</showonepage>
                            <orientation>Horizontal</orientation>
                            <visible>String.IsEqual(Window.Property(enable_scrollbars),true) + [Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})]</visible>
                        </control>
                        <control type="image">
                            <top>215</top>
                            <left>20</left>
                            <width>25</width>
                            <height>25</height>
                            <texture colordiffuse="CCCCCCCC" background="true">deadlight_common/arrow_left.png</texture>
                            <visible>[Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})] + Container({container_no}).HasPrevious</visible>
                        </control>
                        <control type="image">
                            <top>215</top>
                            <left>1135</left>
                            <width>25</width>
                            <height>25</height>
                            <texture colordiffuse="CCCCCCCC" background="true" flipx="true">deadlight_common/arrow_left.png</texture>
                            <visible>[Control.HasFocus({container_no}) | Control.HasFocus({scrollbar_no})] + Container({container_no}).HasNext</visible>
                        </control>
                    </control>
                </control>
'''

	def parentsguide_template(self):
		return '''\
                <control type="group">
                    <visible>Integer.IsGreater(Container(2060).NumItems,0)</visible>
                    <height>890</height>
                    <control type="group">
                        <top>8</top>   <!-- LOCAL PATCH 2026-11-07: clear of the rows' clipping edge -->
                        <control type="image">
                            <!-- LOCAL PATCH 2026-11-08: AF3's thin rule under the row heading -->
                            <top>46</top>
                            <width>1180</width>
                            <height>2</height>
                            <texture colordiffuse="1FFFFFFF">deadlight_common/white.png</texture>
                        </control>
                        <control type="label">
                            <width max="1160">auto</width>
                            <height>20</height>
                            <font>font14</font> <!-- DEADLIGHT_33 -->
                            <textcolor>FFE8E8EA</textcolor>
                            <align>left</align>
                            <aligny>bottom</aligny>
                            <label>[B]Parental Guide $INFO[Window.Property(imdb_parentsguide.number)][/B]</label>
                        </control>
                        <control type="panel" id="2060">
                            <top>60</top>
                            <width>1180</width>
                            <height>360</height>
                            <onup>{p_container_no}</onup>
                            <ondown>{n_container_no}</ondown>
                            <orientation>horizontal</orientation>
                            <scrolltime tween="sine">500</scrolltime>
                            <itemlayout height="360" width="236">
                                <!-- refresh: shadow -->
                                <control type="image">
                                    <left>-1</left>
                                    <top>-1</top>
                                    <width>232</width>
                                    <height>362</height>
                                    <texture colordiffuse="26FFFFFF" border="16">deadlight_live/rounded-16.png</texture>
                                </control>
                                <control type="image">
                                    <height>360</height>
                                    <width>230</width>
                                    <texture colordiffuse="$INFO[Window(10000).Property(deadlight.window_theme.extras)]" border="16">deadlight_live/rounded-16.png</texture>
                                </control>
                                <control type="image">
                                    <left>6</left>
                                    <top>40</top>
                                    <width>224</width>
                                    <height>320</height>
                                    <aspectratio>scale</aspectratio>
                                    <texture colordiffuse="FFCCCCCC" border="30">$INFO[ListItem.Property(thumbnail)]</texture>
                                </control>
                                <control type="textbox">
                                    <left>6</left>
                                    <top>6</top>
                                    <width>224</width>
                                    <height>75</height>
                                    <font>font12</font> <!-- DEADLIGHT_26 -->
                                    <align>center</align>
                                    <aligny>center</aligny>
                                    <textcolor>FFE8E8EA</textcolor>
                                    <label>$INFO[ListItem.Property(name)]</label>
                                    <autoscroll>false</autoscroll>
                                </control>
                                <control type="textbox">
                                    <left>6</left>
                                    <top>280</top>
                                    <width>224</width>
                                    <height>75</height>
                                    <font>font12</font> <!-- DEADLIGHT_26 -->
                                    <align>center</align>
                                    <aligny>center</aligny>
                                    <textcolor>FFE8E8EA</textcolor>
                                    <label>$INFO[ListItem.Property(ranking)]</label>
                                    <autoscroll>false</autoscroll>
                                </control>
                            </itemlayout>
                            <focusedlayout height="360" width="236">
                                <control type="image">
                                    <width>230</width>
                                    <height>360</height>
                                    <texture colordiffuse="$INFO[Window(10000).Property(deadlight.window_theme.extras)]" border="16">deadlight_live/rounded-16.png</texture>
                                </control>
                                <control type="image">
                                    <width>230</width>
                                    <height>360</height>
                                    <texture colordiffuse="$INFO[Window(Home).Property(deadlight.win.focus)]" border="16">deadlight_live/outline-16.png</texture>
                                </control>
                                <control type="image">
                                    <left>6</left>
                                    <top>40</top>
                                    <width>224</width>
                                    <height>320</height>
                                    <aspectratio>scale</aspectratio>
                                    <texture colordiffuse="FF1F2020" border="30">$INFO[ListItem.Property(thumbnail)]</texture>
                                </control>
                                <control type="textbox">
                                    <left>6</left>
                                    <top>6</top>
                                    <width>224</width>
                                    <height>75</height>
                                    <font>font12</font> <!-- DEADLIGHT_26 -->
                                    <align>center</align>
                                    <aligny>center</aligny>
                                    <textcolor>FFE8E8EA</textcolor>
                                    <label>$INFO[ListItem.Property(name)]</label>
                                    <autoscroll>false</autoscroll>
                                </control>
                                <control type="textbox">
                                    <left>6</left>
                                    <top>280</top>
                                    <width>224</width>
                                    <height>75</height>
                                    <font>font12</font> <!-- DEADLIGHT_26 -->
                                    <align>center</align>
                                    <aligny>center</aligny>
                                    <textcolor>FFE8E8EA</textcolor>
                                    <label>$INFO[ListItem.Property(ranking)]</label>
                                    <autoscroll>false</autoscroll>
                                </control>
                            </focusedlayout>
                        </control>
                    </control>
                </control>
'''