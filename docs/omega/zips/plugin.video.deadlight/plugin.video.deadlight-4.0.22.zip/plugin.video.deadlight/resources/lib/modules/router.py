# -*- coding: utf-8 -*-
from xbmc import getInfoLabel
from urllib.parse import parse_qsl
from modules.kodi_utils import external, get_property
# from modules.kodi_utils import logger

def sys_exit_check():
	if get_property('deadlight.reuse_language_invoker') == 'false': return False
	return external()

# LOCAL PATCH 2026-10-25 (4.0.5): a mode naming a private function ('x._helper') is refused -- dispatch is getattr on the
# mode's own text, so any plugin:// url could otherwise call a module's internals. And a listing that raises now ends
# its directory as failed (traceback logged) instead of leaving Kodi waiting on a handle nobody closes.
def routing(sys):
	try: handle = int(sys.argv[1])
	except Exception: handle = -1
	try: return _routing(sys)
	except Exception:
		import traceback
		from xbmc import log
		text = traceback.format_exc()
		try:
			from modules.utils import redact_url
			text = redact_url(text)
		except Exception: pass
		log('###DeadLight router###: %s' % text, 3)
		if handle >= 0 and 'play' not in (dict(parse_qsl(sys.argv[2][1:])).get('mode') or ''):
			try:
				from xbmcplugin import endOfDirectory
				endOfDirectory(handle, succeeded=False)
			except Exception: pass

# LOCAL PATCH 2026-07-23 / 07-29 / 07-28 / 08-29 / 10-02: the account-provider families, matched in this order. 'mal.' is a
# prefix test, not `in`: it is a substring of words like 'normal.'.
def _provider_family(mode):
	for family in ('trakt', 'mdblist', 'simkl', 'anilist'):
		if family + '.' in mode: return family
	if mode.startswith('mal.'): return 'mal'
	return None

def _routing(sys):
	params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
	params.pop('reload', None)   # LOCAL PATCH 2026-11-01: AF3's per-widget reload token (kodi_utils.reload_widgets), not a list setting
	mode = params.get('mode', 'navigator.main')
	if any(i.startswith('_') for i in mode.split('.')):
		from modules.kodi_utils import logger
		return logger('DeadLight router', 'refused mode %r' % mode[:80])
	if mode == 'page_prefetch.warm_widget_pages':   # LOCAL PATCH 2026-10-25 (4.0.5): started by the service, see page_prefetch
		from modules.page_prefetch import warm_widget_pages
		return warm_widget_pages(params)
	if 'navigator.' in mode:
		from indexers.navigator import Navigator
		func = getattr(Navigator(params), mode.split('.')[1], None)
		if func: return func()
	elif 'menu_editor.' in mode:
		from modules.menu_editor import MenuEditor
		func = getattr(MenuEditor(params), mode.split('.')[1], None)
		if func: return func()
	elif 'personal_lists.' in mode:
		from indexers import personal_lists
		func = getattr(personal_lists, mode.split('.')[1], None)
		if func: return func(params)
	elif 'tmdblist.' in mode:
		from indexers import tmdb_lists
		func = getattr(tmdb_lists, mode.split('.')[1], None)
		if func: return func(params)
	elif 'easynews.' in mode:
		from indexers import easynews
		func = getattr(easynews, mode.split('.')[1], None)
		if func: return func(params)
	elif 'playback.' in mode:
		from modules.kodi_utils import player_check
		return player_check(mode, params)
	elif 'choice' in mode:
		from indexers import dialogs
		func = getattr(dialogs, mode, None)
		if func: return func(params)
	elif 'custom_key.' in mode:
		from modules import custom_keys
		func = getattr(custom_keys, mode.split('custom_key.')[1], None)
		if func: return func()
	# LOCAL PATCH 2026-11-01 (cleanup): trakt / mdblist / simkl / anilist / mal in one branch (_provider_family above). Was
	# five copies: <family>.list.<func> -> indexers.<family>_lists, else <family>.<func> -> apis.<family>_api.
	elif (family := _provider_family(mode)):
		from importlib import import_module
		if (mode.startswith('mal.list.') if family == 'mal' else '.list' in mode):
			func = getattr(import_module('indexers.%s_lists' % family), mode.split('.')[2], None)
			if func: return func(params)
		func = getattr(import_module('apis.%s_api' % family), mode.split('.')[1], None)
		if func: return func(params)
	elif 'build' in mode:
		if mode == 'build_movie_list':
			from indexers.movies import Movies
			return Movies(params).fetch_list()
		elif mode == 'build_tvshow_list':
			from indexers.tvshows import TVShows
			return TVShows(params).fetch_list()
		elif mode == 'build_season_list':
			from indexers.seasons import build_season_list
			return build_season_list(params)
		elif mode == 'build_episode_list':
			from indexers.episodes import build_episode_list
			return build_episode_list(params)
		elif mode == 'build_in_progress_episode':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.progress', params)
		# LOCAL PATCH 2026-08-29: Continue Watching -- movies, TV and anime in one widget.
		elif mode == 'build_continue_watching':
			from indexers.continue_watching import build_continue_watching
			return build_continue_watching(params)
		elif mode == 'build_recently_watched_episode':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.recently_watched', params)
		elif mode == 'build_next_episode':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.next', params)
		elif mode == 'build_my_calendar':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.trakt', params)
		# LOCAL PATCH 2026-08-05 (POV 6.08 P2 port): MDBList Calendar as a separate router entry
		elif mode == 'build_mdbl_calendar':
			from indexers.episodes import build_single_episode
			return build_single_episode('episode.mdblist', params)
		elif mode == 'build_next_episode_manager':
			from modules.episode_tools import build_next_episode_manager
			return build_next_episode_manager()
		elif mode == 'build_tmdb_people':
			from indexers.people import tmdb_people
			return tmdb_people(params)
		elif 'random.' in mode:
			from indexers.random_lists import RandomLists
			return RandomLists(params).run_random()
	elif 'watched_status.' in mode:
		if mode == 'watched_status.mark_episode':
			from modules.watched_status import mark_episode
			return mark_episode(params)
		elif mode == 'watched_status.mark_season':
			from modules.watched_status import mark_season
			return mark_season(params)
		elif mode == 'watched_status.mark_tvshow':
			from modules.watched_status import mark_tvshow
			return mark_tvshow(params)
		elif mode == 'watched_status.mark_movie':
			from modules.watched_status import mark_movie
			return mark_movie(params)
		elif mode == 'watched_status.erase_bookmark':
			from modules.watched_status import erase_bookmark
			return erase_bookmark(params.get('media_type'), params.get('tmdb_id'), params.get('season', ''), params.get('episode', ''), params.get('refresh', 'false'))
		elif mode == 'watched_status.unmark_previous_episode':
			from modules.watched_status import unmark_previous_episode
			return unmark_previous_episode(params)
	elif 'search.' in mode:
		if mode == 'search.get_key_id':
			from modules.search import get_key_id
			return get_key_id(params)
		elif mode == 'search.clear_search':
			from modules.search import clear_search
			return clear_search()
		elif mode == 'search.remove':
			from modules.search import remove_from_search
			return remove_from_search(params)
		elif mode == 'search.clear_all':
			from modules.search import clear_all
			return clear_all(params.get('setting_id'), params.get('refresh', 'false'))
	elif 'real_debrid' in mode:
		if mode == 'real_debrid.rd_cloud':
			from indexers.real_debrid import rd_cloud
			return rd_cloud()
		elif mode == 'real_debrid.rd_downloads':
			from indexers.real_debrid import rd_downloads
			return rd_downloads()
		elif mode == 'real_debrid.browse_rd_cloud':
			from indexers.real_debrid import browse_rd_cloud
			return browse_rd_cloud(params.get('id'))
		elif mode == 'real_debrid.resolve_rd':
			from indexers.real_debrid import resolve_rd
			return resolve_rd(params)
		elif mode == 'real_debrid.rd_account_info':
			from indexers.real_debrid import rd_account_info
			return rd_account_info()
		elif mode == 'real_debrid.authenticate':
			from apis.real_debrid_api import RealDebridAPI
			return RealDebridAPI().auth()
		elif mode == 'real_debrid.revoke_authentication':
			from apis.real_debrid_api import RealDebridAPI
			return RealDebridAPI().revoke()
		elif mode == 'real_debrid.delete_all':
			from indexers.real_debrid import rd_delete_all
			return rd_delete_all(params.get('cache_type'))
		elif mode == 'real_debrid.delete':
			from indexers.real_debrid import rd_delete
			return rd_delete(params.get('id'), params.get('cache_type'))
	elif 'premiumize' in mode:
		if mode == 'premiumize.pm_cloud':
			from indexers.premiumize import pm_cloud
			return pm_cloud(params.get('id', None), params.get('folder_name', None))
		elif mode == 'premiumize.pm_transfers':
			from indexers.premiumize import pm_transfers
			return pm_transfers()
		elif mode == 'premiumize.pm_account_info':
			from indexers.premiumize import pm_account_info
			return pm_account_info()
		elif mode == 'premiumize.authenticate':
			from apis.premiumize_api import PremiumizeAPI
			return PremiumizeAPI().auth()
		elif mode == 'premiumize.revoke_authentication':
			from apis.premiumize_api import PremiumizeAPI
			return PremiumizeAPI().revoke()
		elif mode == 'premiumize.rename':
			from indexers.premiumize import pm_rename
			return pm_rename(params.get('file_type'), params.get('id'), params.get('name'))
		elif mode == 'premiumize.delete':
			from indexers.premiumize import pm_delete
			return pm_delete(params.get('file_type'), params.get('id'))
	elif 'alldebrid' in mode:
		if mode == 'alldebrid.ad_cloud':
			from indexers.alldebrid import ad_cloud
			return ad_cloud(params.get('id', None))
		elif mode == 'alldebrid.ad_downloads':
			from indexers.alldebrid import ad_downloads
			return ad_downloads()
		elif mode == 'alldebrid.ad_saved_links':
			from indexers.alldebrid import ad_saved_links
			return ad_saved_links()
		elif mode == 'alldebrid.browse_ad_cloud':
			from indexers.alldebrid import browse_ad_cloud
			return browse_ad_cloud(params.get('id'))
		elif mode == 'alldebrid.resolve_ad':
			from indexers.alldebrid import resolve_ad
			return resolve_ad(params)
		elif mode == 'alldebrid.ad_account_info':
			from indexers.alldebrid import ad_account_info
			return ad_account_info()
		elif mode == 'alldebrid.authenticate':
			from apis.alldebrid_api import AllDebridAPI
			return AllDebridAPI().auth()
		elif mode == 'alldebrid.revoke_authentication':
			from apis.alldebrid_api import AllDebridAPI
			return AllDebridAPI().revoke()
		elif mode == 'alldebrid.delete':
			from indexers.alldebrid import ad_delete
			return ad_delete(params.get('id'))
	elif 'torbox' in mode:
		if mode == 'torbox.tb_cloud':
			from indexers.torbox import tb_cloud
			return tb_cloud()
		elif mode == 'torbox.browse_tb_cloud':
			from indexers.torbox import browse_tb_cloud
			return browse_tb_cloud(params.get('folder_id'), params.get('media_type'))
		elif mode == 'torbox.resolve_tb':
			from indexers.torbox import resolve_tb
			return resolve_tb(params)
		elif mode == 'torbox.tb_account_info':
			from indexers.torbox import tb_account_info
			return tb_account_info()
		elif mode == 'torbox.authenticate':
			from apis.torbox_api import TorBoxAPI
			return TorBoxAPI().auth()
		elif mode == 'torbox.revoke_authentication':
			from apis.torbox_api import TorBoxAPI
			return TorBoxAPI().revoke()
		elif mode == 'torbox.delete_all':
			from indexers.torbox import tb_delete_all
			return tb_delete_all()
		elif mode == 'torbox.delete':
			from indexers.torbox import tb_delete
			return tb_delete(params.get('folder_id'), params.get('media_type'))
	elif 'tmdblist_api' in mode:
		if mode == 'tmdblist_api.authenticate':
			from apis.tmdblist_api import TMDbListAPI
			return TMDbListAPI().auth()
		elif mode == 'tmdblist_api.revoke_authentication':
			from apis.tmdblist_api import TMDbListAPI
			return TMDbListAPI().revoke()
	elif '_cache' in mode:
		from caches import base_cache
		if mode == 'clear_cache':
			return base_cache.clear_cache(params.get('cache'))
		elif mode == 'clear_all_cache':
			return base_cache.clear_all_cache()
		elif mode == 'clean_databases_cache':
			return base_cache.clean_databases()
		elif mode == 'check_databases_integrity_cache':
			return base_cache.check_databases_integrity()
	elif '_image' in mode:
		from indexers.images import Images
		return Images().run(params)
	elif '_text' in mode:
		if mode == 'show_text':
			from modules.kodi_utils import show_text
			return show_text(params.get('heading'), params.get('text', None), params.get('file', None),
							params.get('font_size', 'small'), params.get('kodi_log', 'false') == 'true')
	elif 'settings_manager.' in mode:
		from caches import settings_cache
		func = getattr(settings_cache, mode.split('.')[1], None)
		if func: return func(params)
	elif 'downloader.' in mode:
		from modules import downloader
		func = getattr(downloader, mode.split('.')[1], None)
		if func: return func(params)
	elif 'updater' in mode:
		from modules import updater
		func = getattr(updater, mode.split('.')[1], None)
		if func: return func()
	##EXTRA modes##
	elif mode == 'sync_settings':
		from caches.settings_cache import sync_settings
		return sync_settings(params)
	elif mode == 'kodi_refresh':
		from modules.kodi_utils import kodi_full_refresh   # 'Reload Widgets' in a context menu: every widget
		return kodi_full_refresh()
	elif mode == 'refresh_widgets':
		from modules.kodi_utils import refresh_widgets
		return refresh_widgets()
	elif mode == 'person_data_dialog':
		from indexers.people import person_data_dialog
		return person_data_dialog(params)
	elif mode == 'favorite_people':
		from indexers.people import favorite_people
		return favorite_people()
	elif mode == 'manual_add_magnet_to_cloud':
		from modules.debrid import manual_add_magnet_to_cloud
		return manual_add_magnet_to_cloud(params)
	elif mode == 'upload_logfile':
		from modules.kodi_utils import upload_logfile
		return upload_logfile(params)
	elif mode == 'debrid.browse_packs':
		from modules.sources import Sources
		return Sources().debridPacks(params.get('provider'), params.get('name'), params.get('magnet_url'), params.get('info_hash'))
	elif mode == 'open_settings':
		from modules.kodi_utils import open_settings
		return open_settings()
	elif mode == 'hide_unhide_progress_items':
		from modules.watched_status import hide_unhide_progress_items
		return hide_unhide_progress_items(params)
	elif mode == 'trakt_drop_show':
		from modules.trakt_drop import drop_show
		return drop_show(params)
	elif mode == 'clear_all_sticky_sources':
		from indexers.dialogs import clear_all_sticky_sources_choice
		return clear_all_sticky_sources_choice(params)
	elif mode == 'clean_stale_thumbnails':
		from modules.thumbnails_cleaner import clear_stale_thumbnails
		return clear_stale_thumbnails()
	elif mode == 'open_external_scraper_settings':
		from modules.kodi_utils import external_scraper_settings
		return external_scraper_settings()
	elif mode == 'resolve_yt_trailer':
		# LOCAL PATCH 2026-08-26: lazy season-trailer lookup -- only runs when the
		# viewer presses play, so browsing costs nothing.
		from apis.youtube_api import play_resolved_trailer
		return play_resolved_trailer(params)
