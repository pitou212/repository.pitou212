# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-11-18: HDHub4u (hdhub4u.*) EPISODES, one of Direct Streams' providers (scrapers/http_streams, setting
http_streams.hdhub4u). Films are left to the HDHub aggregator, which already lists HDHub4u's own film files (Animal 2023:
21 rows, PixelDrain / R2) but not its series episodes (Panchayat S04E01: 2 SD transcodes).

The site, as read 2026-11-18:
  - the domain moves (new2.hdhub4u.free is gone, new15.hdhub4u.cl now); the site's own lookup answers the current one
    (_host). Post permalinks keep the old domain: only their path is used.
  - search is a Typesense index (search.pingora.fyi) with an imdb_id field: posts are found by the exact IMDb id.
  - a season post ('Panchayat (Season 4) ... ALL Episodes') lists per episode a 'Drive' link,
      hubcloud.*/drive/search-recover.php?from_ac=<token>&q=<base64 'Panchayat S04 Episode 1'>
    a page that searches HubCloud's file index for that query (JSON: ?api=search&q=..&page=..&from_ac=..). Its hits are
    every upload of that name -- HDHub4u's own episode files among them, each a hubcloud.*/drive/<id> page, resolved at
    play time (scrapers/hubcloud). Only the post's own query is asked: the page marks it locked (the server does not
    enforce that; DeadLight keeps to it).
  - not used: 'Instant' hubcdn.* links (every one tried: 'File is Deleted or UnAvailable'), and the film qualities behind
    the greenmotors.club link protector."""
import base64
import html
import re
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
from modules.kodi_utils import logger
from modules.source_utils import get_aliases_titles
from scrapers._site_common import get as _get, episode_tag as _episode_tag, site_host, norm_title as _norm, title_prefix_ok
from scrapers.hubcloud import recover_query as _query_text, recover_hits as _recover_hits

LABEL = 'HDHub4u'
_SEARCH = 'https://search.pingora.fyi/collections/post/documents/search'
# the site's own 'where is HDHub4u now' endpoints (its home page tries them in turn); each answers {"c": base64 url}
_HOST_LOOKUPS = ('https://dns.pingora.fyi/v2/host', 'https://h4.suncdn.org/host/', 'https://ml.theapii.org/host/')
_HOST_FALLBACK = 'https://new15.hdhub4u.cl'
_SEASONS = re.compile(r'\bSeason\s*(\d{1,2})(?:\s*(?:-|–|&|to)\s*(\d{1,2}))?', re.I)
_DRIVE = re.compile(r'''href=["'](https?://hubcloud\.[a-z]+/drive/search-recover\.php\?[^"']+)["']''', re.I)
_QUERY_EPISODE = re.compile(r'\bS(\d{1,2})\s*(?:E|Ep(?:isode)?\.?\s*)(\d{1,3})\b', re.I)


def scrape(info):
	"""Stremio-shaped rows (http_streams._make_item reads them) for info's episode. Raises on a failed request, so
	http_streams counts the provider as failed and does not cache the empty answer."""
	if info.get('media_type') != 'episode': return []
	imdb = str(info.get('imdb_id') or '')
	if not imdb.startswith('tt'): return []
	try: season, episode = int(info.get('season')), int(info.get('episode'))
	except (TypeError, ValueError): return []
	if season < 1: return []
	title = info.get('title') or ''
	wanted = [(season, episode)] + [(int(s), int(e)) for s, e in (info.get('episode_candidates') or []) if 0 < int(s) < 100]
	# the index answers 403 without the site as Referer + Origin, so the host comes first (kept 12 h after one lookup)
	host = _host()
	# num_typos 0: with typo tolerance the id of a show it lacks matched a near one (Marriage Toxin tt39122769 -> Happy Raj tt39122419)
	hits = _get(_SEARCH, referer=host + '/', origin=host,
				params={'q': imdb, 'query_by': 'imdb_id', 'limit': 50, 'highlight_fields': 'none', 'num_typos': 0}).json().get('hits') or []
	posts = []
	for h in hits:
		doc = h.get('document') or {}
		if doc.get('imdb_id') != imdb: continue
		seasons = set()
		for m in _SEASONS.finditer(doc.get('post_title') or ''):
			seasons.update(range(int(m.group(1)), int(m.group(2) or m.group(1)) + 1))
		if any(s in seasons for s, _e in wanted): posts.append((doc, seasons))
	if not posts:
		logger('HDHub4u', '%s S%02dE%02d: no season post (%d post(s) for %s)' % (title, season, episode, len(hits), imdb))
		return []
	names = set(n for n in (_norm(t) for t in [title] + get_aliases_titles(info.get('aliases', []))) if n)
	for doc, seasons in posts:
		path = urlparse(doc.get('permalink') or '').path
		page = _get(host + path, referer=host + '/').text
		files, how = {}, ''
		# older posts (to 2024): the episode's HubDrive pages; posts with per-quality HubDrive packs (Crystal Lake, 2026): the
		# pack's file for the episode; newer ones: the episode's HubCloud search
		drives = _hubdrive_links(page, [e for s, e in wanted if s in seasons]) or _pack_files(page, wanted)
		if drives:
			with ThreadPoolExecutor(max_workers=min(4, len(drives))) as ex:
				for hit in ex.map(_hubdrive_file, drives):
					if hit: files.setdefault(hit['url'], hit)
			how = '%d HubDrive page(s)' % len(drives)
		else:
			queries = {}
			for m in _DRIVE.finditer(page):
				url = html.unescape(m.group(1))
				q = _query_text(url)
				n = _QUERY_EPISODE.search(q or '')
				if n and (int(n.group(1)), int(n.group(2))) in wanted: queries.setdefault(q, url)
			for q, url in queries.items():
				for hit in _recover_hits(url):
					files.setdefault(hit.get('url'), hit)
			how = 'the search %s' % ', '.join(repr(q) for q in queries) if queries else ''
		if not how: continue
		rows = _rows(files.values(), wanted, names)
		logger('HDHub4u', '%s S%02dE%02d: %d file(s) of %d from %s, post %r' % (title, season, episode, len(rows), len(files), how, (doc.get('post_title') or '')[:70]))
		return rows
	logger('HDHub4u', '%s S%02dE%02d: no link for it on %d season post(s)' % (title, season, episode, len(posts)))
	return []


# an episode's section in an older post: '<strong>EPiSODE 1</strong>' (2024) or 'E01 &#8211; <a ...>Drive</a>' (2020)
_EPISODE_HEAD = re.compile(r'>\s*(?:EPiSODE|EP|E)\s*0*(\d{1,3})\s*(?:<|&#8211;|–|-|:)', re.I)
_HUBDRIVE = re.compile(r'''href=["'](https?://hubdrive\.[a-z]+/file/\d+)["']''', re.I)
_HUBDRIVE_NAME = re.compile(r'<h6[^>]*>\s*([^<]+\.(?:mkv|mp4|avi|ts|webm))\s*</h6>', re.I)
_HUBDRIVE_SIZE = re.compile(r'File\s*Size\s*</td>\s*<td[^>]*>\s*([\d.,]+\s*[KMGT]i?B)', re.I)
_HUBDRIVE_CLOUD = re.compile(r'''href=["'](https?://hubcloud\.[a-z]+/drive/[\w-]+)["']''', re.I)


def _hubdrive_links(page, episodes):
	"""The HubDrive links in the wanted episodes' sections (an older post's layout), each section running to the next episode
	marker; the season-pack links above the first episode are left out. _rows checks every file's own SxxEyy after."""
	heads = list(_EPISODE_HEAD.finditer(page or ''))
	links = []
	for i, h in enumerate(heads):
		if int(h.group(1)) not in episodes: continue
		chunk = page[h.end():heads[i + 1].start() if i + 1 < len(heads) else len(page)]
		links += [u for u in _HUBDRIVE.findall(chunk) if u not in links]
	return links


_HUBDRIVE_PACK = re.compile(r'''href=["'](https?://hubdrive\.[a-z]+/packs/[\w-]+)["']''', re.I)
# a pack page's entry: <div class="pack-clean-file" onclick="window.open('/file/1799256861', ...)"> ... <div class="pack-clean-title"> NAME
_PACK_ENTRY = re.compile(r'''window\.open\(\s*['"](/file/\d+)['"].{0,600}?pack-clean-title[^>]*>\s*([^<]+?)\s*<''', re.I | re.S)


def _pack_files(page, wanted):
	"""HubDrive file pages for the wanted episodes, out of the post's per-quality packs ('720p EP - PACK' -> hubdrive.*/packs/<id>,
	a page listing each episode's file). [] when the post has no packs or none lists the episode."""
	packs = list(dict.fromkeys(_HUBDRIVE_PACK.findall(page or '')))
	if not packs: return []
	tags = [_episode_tag(s, e) for s, e in wanted]
	def entries(pack):
		try: text = _get(pack).text
		except Exception: return []
		base = '%s://%s' % (urlparse(pack).scheme, urlparse(pack).netloc)
		return [base + path for path, name in _PACK_ENTRY.findall(text) if any(t.search(html.unescape(name)) for t in tags)]
	with ThreadPoolExecutor(max_workers=min(3, len(packs))) as ex:
		return list(dict.fromkeys(u for found in ex.map(entries, packs) for u in found))


def _hubdrive_file(url):
	"""A HubDrive page as a search hit: its file name, size and HubCloud link. None when it has no HubCloud link."""
	try: page = _get(url).text
	except Exception: return None
	name, size, cloud = _HUBDRIVE_NAME.search(page), _HUBDRIVE_SIZE.search(page), _HUBDRIVE_CLOUD.search(page)
	if not (name and cloud): return None
	return {'file_name': html.unescape(name.group(1)).strip(), 'size': size.group(1) if size else '', 'url': cloud.group(1), 'mimeType': 'video'}


def _host():
	"""The site's current address (scheme + host): its own lookup endpoints, kept 12 h (_site_common.site_host)."""
	def find():
		for lookup in _HOST_LOOKUPS:
			try:
				c = _get(lookup, params={'v': '1a' + time.strftime('%Y%m%d%H')}).json().get('c')
				p = urlparse(base64.b64decode(c).decode('utf-8'))
				if p.scheme in ('http', 'https') and p.netloc: return '%s://%s' % (p.scheme, p.netloc)
			except Exception: continue
		return None
	return site_host('deadlight.hdhub4u.host', find, _HOST_FALLBACK)


def _rows(hits, wanted, names):
	tags = [_episode_tag(s, e) for s, e in wanted]
	rows = []
	for hit in hits:
		name, url = (hit.get('file_name') or '').strip(), hit.get('url') or ''
		if 'video' not in (hit.get('mimeType') or '') or '/drive/' not in url: continue
		tag = next((m for m in (t.search(name) for t in tags) if m), None)
		if not tag: continue
		if not title_prefix_ok(name, tag.start(), names): continue   # the query's other shows
		rows.append({'name': '%s | HubCloud' % LABEL, 'title': name, 'url': url, 'size': hit.get('size') or '',
					 'info': LABEL, 'resolver': 'hubcloud'})
	return rows
