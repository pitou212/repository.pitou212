# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-11-18: MoviesDrive (moviesdrive.*), films and episodes, one of Direct Streams' providers
(scrapers/http_streams, setting http_streams.moviesdrive).

The site, as read 2026-11-18:
  - moviesdrives.bid is a landing page; the site itself moves (new1.moviesdrive.christmas -> new3.moviesdrive.cyou). The
    landing page names the current one in base64 (atob('...')); the cdn.mdrivecdn.net/host/ lookup it also tries is gone.
  - search.php?q=<IMDb id> answers Typesense JSON with an imdb_id per post: posts are taken by the exact id.
  - a post lists its files as mdrive.lol/archive/<id> pages, one per quality: '2160p [19GB]' for a film, '720p Single
    Episode' / '4K 2160p Single Episode' for a season (a post may hold two seasons: the page title says which), 'Zip' packs.
  - an archive page names the release in its <title> and lists the files with plain hubcloud.*/drive/ links -- one for a
    film, 'EP01 - 2160p [7.36 GB] HubCloud | GDFliX' per episode. No link protector. HubCloud is resolved at play time
    (scrapers/hubcloud), which also gives each row its real file name and size. GDFlix is not used (its 'Instant DL'
    answered 500, 2026-11-18)."""
import base64
import html
import re
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
from modules.kodi_utils import logger
from modules.source_utils import get_aliases_titles
from scrapers._site_common import get, with_site_host, episode_tag, norm_title, title_prefix_ok
from scrapers.hubcloud import recover_query, recover_hits

LABEL = 'MoviesDrive'
_LANDINGS = ('https://moviesdrives.bid/', 'https://moviesdrives.mov/')
_HOST_FALLBACK = 'https://new3.moviesdrive.cyou'
_SEASONS = re.compile(r'\bSeason\s*(\d{1,2})(?:\s*(?:-|–|&|to)\s*(\d{1,2}))?|\bS(\d{2})\b', re.I)
_ARCHIVE = re.compile(r'''<a[^>]+href=["'](https?://mdrive\.[a-z]+/archive/\d+/?)["'][^>]*>(.*?)</a>''', re.I | re.S)
_HUBCLOUD = re.compile(r'''href=["'](https?://hubcloud\.[a-z]+/drive/[\w-]+)["']''', re.I)
_RECOVER = re.compile(r'''href=["'](https?://hubcloud\.[a-z]+/drive/search-recover\.php\?[^"']+)["']''', re.I)
_EPISODE = re.compile(r'\b(?:EP|Episode|E)\s*0*(\d{1,3})\b', re.I)
_SIZE = re.compile(r'\[\s*([\d.,]+\s*[KMGT]i?B)\s*\]', re.I)
_TITLE = re.compile(r'<title>\s*([^<]+?)\s*</title>', re.I)
_MAX_ARCHIVES = 8


def scrape(info):
	"""Stremio-shaped rows (http_streams._make_item reads them). Raises on a failed request, so http_streams counts the
	provider as failed and does not cache the empty answer."""
	media_type = info.get('media_type')
	imdb = str(info.get('imdb_id') or '')
	if media_type not in ('movie', 'episode') or not imdb.startswith('tt'): return []
	season = episode = None
	if media_type == 'episode':
		try: season, episode = int(info.get('season')), int(info.get('episode'))
		except (TypeError, ValueError): return []
		if season < 1: return []
	title = info.get('title') or ''
	# the last known address at once; the slow lookup (_find_host) only when it stops answering
	host, hits = with_site_host('deadlight.moviesdrive.host', _find_host, _HOST_FALLBACK,
		lambda h: get(h + '/search.php', params={'q': imdb, 'page': '1'}, referer=h + '/', accept='application/json').json().get('hits') or [])
	posts = [h['document'] for h in hits if (h.get('document') or {}).get('imdb_id') == imdb]
	what = '%s (%s)' % (title, info.get('year', '')) if season is None else '%s S%02dE%02d' % (title, season, episode)
	if season is not None:
		posts = [p for p in posts if not _seasons(p.get('post_title')) or season in _seasons(p.get('post_title'))]
	if not posts:
		logger('MoviesDrive', '%s: no post (%d hit(s) for %s)' % (what, len(hits), imdb))
		return []
	links, queries = {}, {}
	for post in posts[:2]:
		page = get(host + urlparse(post.get('permalink') or '').path, referer=host + '/').text
		since = 0
		for m in _ARCHIVE.finditer(page):
			url, label = m.group(1), ' '.join(html.unescape(re.sub(r'<[^>]+>', ' ', m.group(2))).split())
			# the release heading above the link names its season ('MobLand (Season 2) [Hindi - English] 4K 2160p ... [7GB/E]'):
			# another season's archives are not fetched (a two-season post: 4 pages instead of 8)
			heading = ' '.join(html.unescape(re.sub(r'<[^>]+>', ' ', page[since:m.start()])).split())
			since = m.end()
			if re.search(r'(?i)\bzip\b|\bpack\b', label): continue
			if season is not None:
				if not re.search(r'(?i)episode', label): continue   # season pages: 'Single Episode' archives
				if _seasons(heading[-200:]) and season not in _seasons(heading[-200:]): continue
			links.setdefault(url, (label, _seasons(post.get('post_title'))))
		# older posts (Animal, 2023) link each quality to HubCloud's search instead: one query per quality ('Animal 2023 1080p')
		for url in _RECOVER.findall(page):
			url = html.unescape(url)
			q = recover_query(url)
			if season is None or _query_is_episode(q, season, episode): queries.setdefault(q, url)
	archives = list(links.items())[:_MAX_ARCHIVES]
	if not archives and not queries:
		logger('MoviesDrive', '%s: no file page on %d post(s)' % (what, len(posts)))
		return []
	found = []
	if archives:
		with ThreadPoolExecutor(max_workers=min(4, len(archives))) as ex:
			found = [f for files in ex.map(lambda a: _archive_files(a[0], a[1][1], season, episode), archives) for f in files]
	searched = _searched_files(list(queries.values()), info, season, episode) if queries else []
	rows = _rows(found, season, episode, title if season is not None else '%s (%s)' % (title, info.get('year', ''))) + searched
	logger('MoviesDrive', '%s: %d file(s) from %d archive page(s) and %d HubCloud search(es), post %r' % (what, len(rows), len(archives), len(queries),
		(posts[0].get('post_title') or '')[:70]))
	return rows


def _query_is_episode(query, season, episode):
	"""A season post's search query for this episode ('MobLand S01E05 720p', 'Panchayat S04 Episode 1')."""
	m = re.search(r'\bS0*(\d{1,2})\s*(?:E|Ep(?:isode)?\.?\s*)0*(\d{1,3})\b', query or '', re.I)
	return bool(m) and (int(m.group(1)), int(m.group(2))) == (season, episode)


def _searched_files(urls, info, season, episode):
	"""Rows from HubCloud search-recover queries: video files of this film (its year, ±1, after its title) or this episode
	(its SxxEyy after the show's title). The search also returns other films and shows; those are left out."""
	titles = set(t for t in (norm_title(x) for x in [info.get('title') or ''] + get_aliases_titles(info.get('aliases', []))) if t)
	tag = episode_tag(season, episode) if season is not None else None
	try: year = int(info.get('year') or 0)
	except (TypeError, ValueError): year = 0
	with ThreadPoolExecutor(max_workers=min(3, len(urls))) as ex:
		hits = dict((h.get('url'), h) for found in ex.map(recover_hits, urls) for h in found if h.get('url'))
	rows = []
	for hit in hits.values():
		name = (hit.get('file_name') or '').strip()
		if 'video' not in (hit.get('mimeType') or '') or '/drive/' not in hit['url']: continue
		if tag: m = tag.search(name)
		else: m = next((y for y in re.finditer(r'(?<!\d)((?:19|20)\d{2})(?!\d)', name) if not year or abs(int(y.group(1)) - year) <= 1), None)
		if not m or not title_prefix_ok(name, m.start(), titles): continue
		rows.append({'name': '%s | HubCloud' % LABEL, 'title': name, 'url': hit['url'], 'size': hit.get('size') or '', 'info': LABEL, 'resolver': 'hubcloud'})
	return rows


def _find_host():
	"""The site's current 'https://host': the first base64 address on the landing page that answers as MoviesDrive (the
	redirect it may lead to followed). None when none does."""
	for landing in _LANDINGS:
		try: text = get(landing).text
		except Exception: continue
		for b in re.findall(r'''atob\(\s*['"]([A-Za-z0-9+/=]{16,})['"]\s*\)''', text):
			try: url = base64.b64decode(b).decode('utf-8', 'ignore').strip()
			except Exception: continue
			if not url.startswith('http') or 'moviesdrive' not in url.lower() or 'moviesdrives.' in url.lower(): continue
			try:
				r = get(url)
				if 'moviesdrive' in r.text[:3000].lower():
					p = urlparse(r.url)
					return '%s://%s' % (p.scheme, p.netloc)
			except Exception: continue
	return None


def _seasons(text):
	found = set()
	for m in _SEASONS.finditer(text or ''):
		if m.group(3): found.add(int(m.group(3)))
		else: found.update(range(int(m.group(1)), int(m.group(2) or m.group(1)) + 1))
	return found


def _archive_files(url, post_seasons, season, episode):
	"""[(HubCloud link, size stated, release title)] on one archive page: its one link for a film; for an episode, the link
	whose 'EP<n>' line is the episode, on a page of that season (its title names the season, or the post holds only it)."""
	try: page = get(url).text
	except Exception: return []
	title = html.unescape((_TITLE.search(page) or [None, ''])[1] or '')
	if season is None:
		m = _HUBCLOUD.search(page)
		size = _SIZE.search(title)
		return [(m.group(1), size.group(1) if size else '', title)] if m else []
	page_seasons = _seasons(title) or post_seasons
	if page_seasons and season not in page_seasons: return []
	files, since = [], 0
	for link in _HUBCLOUD.finditer(page):
		text = html.unescape(re.sub(r'<[^>]+>', ' ', page[since:link.start()]))
		since = link.end()
		eps, size = _EPISODE.findall(text), _SIZE.findall(text)
		if eps and int(eps[-1]) == episode: files.append((link.group(1), size[-1] if size else '', title))
	return files


def _rows(found, season, episode, show):
	"""One row per HubCloud file, named after its archive page's title -- the release as the site describes it, quality,
	source, SDR/HDR and codec included ('Dune: Part Two (2024) [Hindi.DDP5.1 + English.DDPA5.1] 2160p AMZN WEB-DL SDR H.265'),
	with 'S02E01' in place of '(Season 2)' for an episode, and the title in front when the archive leaves it out
	('Season 4 [Hindi (DD5.1)] 480p x264' -> 'Panchayat S04E01 ...': the name filter reads it). Not each HubCloud page's file
	name: that was one more request per row (2026-11-18); the page is opened at play time anyway."""
	rows = []
	for url, size, title in dict((f[0], f) for f in found).values():
		name = re.sub(r'\s*\[[^\]]*\d\s*[KMGT]i?B[^\]]*\]\s*$', '', title).strip()   # its trailing size ('[19GB]', '[7GB/E]')
		# and a leading 'Download ' ('Download Dupahiya (Season 1) WEB-DL ...'): the name filter refused all 4 Dupahiya S01E06
		# rows over it (Kodi log 2026-11-18 15:55)
		name = re.sub(r'(?i)^\s*download\s+', '', name)
		if season is not None:
			tag = 'S%02dE%02d' % (season, episode)
			name, n = re.subn(r'\(\s*Season\s*\d{1,2}\s*\)|\bSeason\s*\d{1,2}\b', tag, name, count=1, flags=re.I)
			if not n: name = re.sub(r'^(.*?)(\s*[\[(]|\s+\d{3,4}p\b|$)', lambda m: '%s %s%s' % (m.group(1), tag, m.group(2)), name, count=1)
		if show and norm_title(show) not in norm_title(name): name = '%s %s' % (show, name)
		rows.append({'name': '%s | HubCloud' % LABEL, 'title': name + '.mkv', 'url': url, 'size': size,
					 'info': LABEL, 'resolver': 'hubcloud'})
	return rows
