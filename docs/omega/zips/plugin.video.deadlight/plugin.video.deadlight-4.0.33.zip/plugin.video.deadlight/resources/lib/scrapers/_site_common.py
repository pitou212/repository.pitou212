# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-11-18: what the site scrapers under Direct Streams share (animedubhindi, hdhub4u, moviesdrive): one pooled
session (kodi_utils.make_session: the shared SSL context), a GET that sends the player's browser User-Agent plus the
Referer / Accept / Origin a site wants and raises on an HTTP error (http_streams then counts the provider as failed and
does not cache its empty answer), the single-episode name tag, and a site address kept in a window property."""
import re
import time
from modules.kodi_utils import make_session, stream_request_parts, get_property, set_property

TIMEOUT = 10
_session = make_session('https://')


def get(url, referer=None, accept=None, origin=None, timeout=TIMEOUT, **kwargs):
	_link, headers = stream_request_parts(url)
	if referer: headers['Referer'] = referer
	if accept: headers['Accept'] = accept
	if origin: headers['Origin'] = origin
	r = _session.get(url, headers=headers, timeout=timeout, **kwargs)
	r.raise_for_status()
	return r


def episode_tag(season, episode):
	"""S04E01 / S04.E01 / S4 E1 in a file name -- one episode, not a range ('Ep.01-08', 'E01-E08')."""
	return re.compile(r'(?i)(?<![a-z0-9])S0*%d[ ._-]?E0*%d(?![0-9])(?!\s*[-–~]\s*E?\d)' % (season, episode))


def norm_title(text):
	"""A title as clean_title reads it: lower case, no punctuation, bracketed tags ('(Movies4u.Foo)') and accents dropped."""
	import html
	from modules.source_utils import clean_title, normalize
	return clean_title(normalize(html.unescape(text or ''))) or ''


def title_prefix_ok(name, end, titles):
	"""Does the release name before position `end` (where its episode tag or year starts) name one of `titles` (norm_title'd)?
	Either may start the other: files shorten long titles ('Scam.1992.S01.E02' for 'Scam 1992: The Harshad Mehta Story').
	A search over a file index also returns other shows and films; this keeps them out. True when there are no titles."""
	prefix = norm_title(name[:end])
	return not titles or (len(prefix) >= 3 and any(t.startswith(prefix) or prefix.startswith(t) for t in titles))


def with_site_host(prop, find, fallback, call):
	"""call(host) on the site's last known address (window property `prop`, else `fallback`) at once; only when that fails is
	the address looked up again (find(): 'https://host' or None) and call() retried there. For a site whose lookup is slow
	(MoviesDrive's: its landing page, then the homepage it points to, ~2-5 s) and whose old address keeps working a while."""
	known = (get_property(prop) or '').split('|')[0]
	host = known if known.startswith('http') else fallback
	try: result = call(host)
	except Exception:
		fresh = None
		try: fresh = find()
		except Exception: pass
		if not fresh or fresh == host: raise
		host = fresh
		result = call(host)
	if host != known: set_property(prop, '%s|%d' % (host, time.time()))
	return host, result


def site_host(prop, find, fallback, ttl=12 * 3600):
	"""A site's current 'https://host', kept `ttl` in window property `prop`. find() works it out (None on failure); the last
	known one, else `fallback`, when it cannot."""
	cached = (get_property(prop) or '').split('|')
	if len(cached) == 2 and cached[1].isdigit() and time.time() - int(cached[1]) < ttl: return cached[0]
	try: host = find()
	except Exception: host = None
	if host:
		set_property(prop, '%s|%d' % (host, time.time()))
		return host
	return cached[0] if cached[0].startswith('http') else fallback
