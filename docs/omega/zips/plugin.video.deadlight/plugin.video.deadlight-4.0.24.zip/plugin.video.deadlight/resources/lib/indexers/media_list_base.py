# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-19: the methods indexers/movies.Movies and indexers/tvshows.TVShows held byte-identical copies of.
# fetch_list / worker / _prefetch / __init__ are NOT here: the two have drifted on purpose (TV's is_random guard on Next
# Page, its exit_params handling, movie sets), see the 10-19 audit.
import json
from threading import Thread
from modules import kodi_utils, settings
from modules.utils import paginate_list, TaskPool


class MediaListBase:
	def _size_pool_for_cold_page(self):
		"""LOCAL PATCH 2026-10-03 (3.0.8): a TMDb list page that was not cached warmed SEARCH_POOL connections while it was
		fetched (tmdb_api._list_data); its details then use that many workers, as a search does."""
		try:
			from apis import tmdb_api
			if tmdb_api.LAST_LIST_COLD: self.search_pool = tmdb_api.SEARCH_POOL
		except Exception: pass

	def context_menu(self, context_menu_items):
		if self.custom_cm_menu:
			try: context_menu_items = sorted([i for i in context_menu_items if i[0] in self.cm_sort_order], key=lambda k: self.cm_sort_order[k[0]])
			except: pass
		return [i[1] for i in context_menu_items]

	def paginate_list(self, data, page_no):
		if settings.paginate(self.is_external):
			limit = settings.page_limit(self.is_external)
			data, total_pages = paginate_list(data, page_no, limit, self.paginate_start)
			if self.is_external: self.paginate_start = limit
		else: total_pages = 1
		return data, total_pages

	# LOCAL PATCH 2026-11-01 (cleanup): the thread-pool tail of Movies.worker / TVShows.worker
	def _run_builders(self, function):
		# LOCAL PATCH 2026-11-08: the page's cached metas in one query before the pool (caches.meta_cache.prefetch)
		id_type = getattr(self, 'id_type', None)
		if id_type in ('tmdb_id', 'trakt_dict'):   # a trakt_dict row is read by its 'tmdb' id when it has one (metadata.*_meta)
			try:
				from caches.meta_cache import meta_cache
				ids = self.list if id_type == 'tmdb_id' else [i.get('tmdb') for i in self.list if isinstance(i, dict)]
				meta_cache.prefetch('movie' if function.__name__ == 'build_movie_content' else 'tvshow', ids)
			except Exception: pass
		size = min(len(self.list), settings.max_threads(), getattr(self, 'search_pool', 99))
		threads = (TaskPool().tasks if self.custom_order else TaskPool().tasks_enumerate)(function, self.list, size)
		[i.join() for i in threads]
		if not self.custom_order:
			self.items.sort(key=lambda k: k[1])
			self.items = [i[0] for i in self.items]
		return self.items

	# LOCAL PATCH 2026-11-01 (cleanup): the context-menu entries Movies and TVShows share, Browse Recommended to Reload Widgets,
	# appended to cm in the same order as before. after: {key: [entries]} go right after that key's entry (TV's AniList manager
	# after trakt_manager, Drop Show after simkl_manager); mark_entries go before Exit. Each URL keeps the keys, in the order,
	# each class used. Returns the listitem properties for those URLs.
	def _shared_cm(self, cm, meta, media_type, title, tmdb_id, imdb_id, tvdb_id, poster, premiered, after=None, mark_entries=(), exit_label=''):
		from modules.metadata import is_anime_meta
		after = after or {}
		movie = media_type == 'movie'
		build_url, window_command, is_external = self.build_url, self.window_command, self.is_external
		list_mode, tmdb_type = ('build_movie_list', 'movies') if movie else ('build_tvshow_list', 'tv')
		recommended = {'mode': list_mode, 'action': 'tmdb_%s_recommendations' % tmdb_type}
		if movie: recommended.update({'is_external': is_external, 'key_id': tmdb_id})
		else: recommended.update({'key_id': tmdb_id, 'is_external': is_external})
		recommended['name'] = 'Recommended based on %s' % title
		browse_recommended_params = build_url(recommended)
		browse_related_params = build_url({'mode': list_mode, 'action': 'trakt_%s_related' % tmdb_type, 'key_id': imdb_id, 'is_external': is_external,
									'name': 'Related to %s' % title})
		browse_more_like_this_params = build_url({'mode': list_mode, 'action': 'imdb_more_like_this', 'key_id': imdb_id, 'is_external': is_external,
									'name': 'More Like This based on %s' % title})
		browse_similar_params = build_url({'mode': list_mode, 'action': 'ai_similar', 'is_external': is_external,
									'key_id': '%s|%s' % (media_type, tmdb_id), 'name': 'Similar based on %s' % title})
		browse_in_trakt_list_params = build_url({'mode': 'trakt.list.in_trakt_lists', 'media_type': media_type, 'imdb_id': imdb_id, 'is_external': is_external,
									'category_name': '%s In Trakt Lists' % title})
		trakt_manager_params = build_url({'mode': 'trakt_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': media_type, 'icon': poster})
		personal_manager_params = build_url({'mode': 'personallists_manager_choice', 'list_type': media_type, 'tmdb_id': tmdb_id, 'title': title,
									'premiered': premiered, 'current_time': self.current_time, 'icon': poster})
		tmdb_manager_params = build_url({'mode': 'tmdblists_manager_choice', 'media_type': 'movie' if movie else 'tv', 'tmdb_id': tmdb_id, 'icon': poster})
		favorites_manager_params = build_url({'mode': 'favorites_manager_choice', 'media_type': media_type, 'tmdb_id': tmdb_id, 'title': title})
		def add(key, entry):
			cm.append([key, entry])
			cm.extend(after.get(key, ()))
		add('recommended', ('[B]Browse Recommended[/B]', window_command % browse_recommended_params))
		add('related', ('[B]Browse Related[/B]', window_command % browse_related_params))
		add('more_like_this', ('[B]Browse More Like This[/B]', window_command % browse_more_like_this_params))
		if self.ai_model_active: add('similar', ('[B]Browse Similar[/B]', window_command % browse_similar_params))
		if is_anime_meta(meta):
			# LOCAL PATCH 2026-10-09: AniList users' recommendations, anime only (apis/anilist_api.anilist_recommended)
			add('anilist_recommended', ('[B]Browse AniList Recommended[/B]', window_command % build_url(
				{'mode': list_mode, 'action': 'anilist_recommended', 'key_id': '%s|%s' % (media_type, tmdb_id), 'is_external': is_external,
				'name': 'AniList Recommended based on %s' % title})))
			# LOCAL PATCH 2026-10-27 / 2026-10-31: the franchise's watch order (anilist_lists.build_anilist_watch_order); for a film
			# the builder finds its AniList entry from the TMDb / IMDb id
			# LOCAL PATCH 2026-11-01: opens the Watch Order window (dialogs.watch_order_choice); the folder mode still works
			if movie: watch_order = {'mode': 'watch_order_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'media_type': 'movie', 'title': title}
			else: watch_order = {'mode': 'watch_order_choice', 'tmdb_id': tmdb_id, 'title': title}
			watch_order['is_external'] = is_external
			add('watch_order', ('[B]Watch Order[/B]', 'RunPlugin(%s)' % build_url(watch_order)))
		add('in_trakt_list', ('[B]In Trakt Lists[/B]', window_command % browse_in_trakt_list_params))
		add('trakt_manager', ('[B]Trakt Lists Manager[/B]', 'RunPlugin(%s)' % trakt_manager_params))
		# LOCAL PATCH 2026-07-23: MDBList Manager context-menu entry (TV: with Toggle Drop built into the manager dialog).
		add('mdblist_manager', ('[B]MDBList Manager[/B]', 'RunPlugin(%s)' % build_url(
			{'mode': 'mdblist_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': media_type, 'icon': poster})))
		# LOCAL PATCH 2026-07-30: SIMKL Manager context-menu entry.
		add('simkl_manager', ('[B]SIMKL Manager[/B]', 'RunPlugin(%s)' % build_url(
			{'mode': 'simkl_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'media_type': media_type, 'icon': poster})))
		add('personal_manager', ('[B]Personal Lists Manager[/B]', 'RunPlugin(%s)' % personal_manager_params))
		add('tmdb_manager', ('[B]TMDb Lists Manager[/B]', 'RunPlugin(%s)' % tmdb_manager_params))
		add('favorites_manager', ('[B]Favorites Manager[/B]', 'RunPlugin(%s)' % favorites_manager_params))
		cm.extend(mark_entries)
		if not is_external: cm.append(['exit', (exit_label, 'RunPlugin(%s)' % build_url({'mode': 'navigator.exit_media_menu'}))])
		else:
			cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
					['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
		return {
			'deadlight.browse_recommended_params': browse_recommended_params,
			'deadlight.browse_related_params': browse_related_params,
			'deadlight.browse_more_like_this_params': browse_more_like_this_params,
			'deadlight.browse_similar_params': browse_similar_params,
			'deadlight.browse_in_trakt_list_params': browse_in_trakt_list_params,
			'deadlight.trakt_manager_params': trakt_manager_params,
			'deadlight.personal_manager_params': personal_manager_params,
			'deadlight.tmdb_manager_params': tmdb_manager_params,
			'deadlight.favorites_manager_params': favorites_manager_params}


# LOCAL PATCH 2026-11-01 (cleanup): the films + shows tail the list builders each held a copy of (trakt_lists, tmdb_lists,
# personal_lists x2, mdblist_lists, simkl_lists, anilist_lists).
def render_mixed(movie_list=None, tvshow_list=None, extra_jobs=()):
	"""Movies(movie_list).worker() and TVShows(tvshow_list).worker() in parallel, plus any (function, list_params) of extra_jobs
	(function(list_params) returns rows). A list_params whose 'list' is empty is skipped. Returns the builders' (row, position)
	pairs sorted by position -- each caller numbers its lists so that positions do not collide."""
	from indexers.movies import Movies
	from indexers.tvshows import TVShows
	jobs = [(lambda l: Movies(l).worker(), movie_list), (lambda l: TVShows(l).worker(), tvshow_list)] + list(extra_jobs)
	threads, item_list = [], []
	def _process(function, _list):
		try: item_list.extend(function(_list))
		except Exception: kodi_utils.log_row_error('render_mixed')
	for function, _list in jobs:
		if not _list or not _list.get('list'): continue
		threaded_object = Thread(target=_process, args=(function, _list))
		threaded_object.start()
		threads.append(threaded_object)
	[i.join() for i in threads]
	item_list.sort(key=lambda k: k[1])
	return item_list

def add_page_dirs(handle, new_params, page_no, total_pages, jump_to=False, next_page=True):
	"""Jump To... (jump_to and more than 2 pages), then Next Page (N) >> (next_page and a page after this one)."""
	if total_pages > 2 and jump_to:
		kodi_utils.add_dir(handle, {'mode': 'navigate_to_page_choice', 'current_page': page_no, 'total_pages': total_pages, 'url_params': json.dumps(new_params)},
									'Jump To...', 'item_jump', kodi_utils.get_icon('item_jump_landscape'), isFolder=False)
	if total_pages > page_no and next_page:
		new_page = str(page_no + 1)
		new_params['new_page'] = new_page
		kodi_utils.add_dir(handle, new_params, 'Next Page (%s) >>' % new_page, 'nextpage', kodi_utils.get_icon('nextpage_landscape'))

def finish_dir(handle, content, name, is_external, view=None, refreshed=False):
	"""set_content, set_category, end_directory (not cached to disc for a widget), then the view type -- 'view.<content>' unless
	view is given; set_view_mode does nothing for a widget."""
	kodi_utils.set_content(handle, content)
	kodi_utils.set_category(handle, name)
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	if not is_external: kodi_utils.set_view_mode(view or 'view.%s' % content, content, is_external, refreshed=refreshed)
