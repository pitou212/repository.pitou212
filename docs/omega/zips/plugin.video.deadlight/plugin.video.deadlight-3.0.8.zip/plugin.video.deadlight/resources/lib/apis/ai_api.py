# -*- coding: utf-8 -*-
from apis import google_api
from apis.tmdb_api import tmdb_movies_search, tmdb_tv_search
from caches.base_cache import get_timestamp
from caches.lists_cache import lists_cache, lists_cache_object
from modules.metadata import movie_meta, tvshow_meta
from modules.kodi_utils import notification
from modules.utils import TaskPool, normalize, get_datetime, get_current_timestamp
from modules.settings import ai_model_order, ai_model_limit, max_threads, tmdb_api_key, mpaa_region
# from modules.kodi_utils import logger


def ai_similar(media_info, dummy=None):
	def _fetch_similar(dummy):
		try:
			data = ai_similar_call(media_type, tmdb_id, meta, limit)
			data = data.get('recommendations') or data.get('recs') or []
			if not isinstance(data, list) or not data: return []
			recommendations = data[:limit]
			threads = TaskPool().tasks_enumerate(_process_results, recommendations, min(len(recommendations), max_threads()))
			[i.join() for i in threads]
			recommendations_list.sort(key=lambda k: k['order'])
			return {'results': recommendations_list, 'page': 1, 'total_pages': 1}
		except: return []
	def _process_results(count, item):
		title = item['title'].strip()
		if not title: return
		year = item['year']
		if not year: return
		try:
			year = int(str(year).strip())
			if 2100 < year < 1800: year = None
		except: year = None
		if item['type'] != media_type: return
		data = pick_best_tmdb_match(tmdb_simplified(title, media_type), title, year)
		if not data: return
		title, year, tmdb_id = data['title'], data['year'], data['tmdb_id']
		recommendations_list.append({'title': title, 'year': year, 'media_type': media_type, 'id': tmdb_id, 'order': count})
	recommendations_list = []
	media_type, tmdb_id = media_info.split('|')
	meta_function = movie_meta if media_type == 'movie' else tvshow_meta
	meta = meta_function('tmdb_id', tmdb_id, tmdb_api_key(), mpaa_region(), get_datetime(), get_current_timestamp())
	limit = ai_model_limit()
	media_type = "Movie" if media_type == 'movie' else "Show"
	string = 'ai_similar_%s_%s_%s' % (media_type, tmdb_id, limit)
	return lists_cache_object(_fetch_similar, string, 'foo', expiration=168)

def tmdb_simplified(title, media_type):
	function = tmdb_movies_search if media_type == 'Movie' else tmdb_tv_search
	try: data = function(title, 1)['results']
	except: return []
	results = []
	for item in data:
		year = None
		title = item['title' if media_type == 'Movie' else 'name']
		release_date = item['release_date' if media_type == 'Movie' else 'first_air_date']
		if not release_date: continue
		year = int(release_date.split('-')[0])
		results.append({'tmdb_id': item.get('id'), 'title': title, 'year': year})
	return results

def pick_best_tmdb_match(results, title, year):
	if not results: return None
	compare_title, compare_year = normalize(title), int(year) if year else None
	if compare_year is not None:
		for item in results:
			title = normalize(item['title'])
			year = item['year']
			if title == compare_title and year == compare_year: return item
			if title == compare_title and year is not None and abs(year - compare_year) == 1: return item
	return results[0]

# LOCAL PATCH 2026-10-09: 'ai_model_failed' holds fail counters (timeout_ends 0) and 24 h bans (timeout_ends in the
# future). The old prune dropped counters as 'ended', so a non-429 error never reached 3 fails and ai_similar_call
# recursed on the same model until the recursion limit (a retired model = hundreds of requests). Now counters survive,
# a success clears its counter, and a failure moves on to the next model in the same call.
def _failed_records():
	now = get_timestamp()
	return [i for i in (lists_cache.get('ai_model_failed') or []) if not i['timeout_ends'] or i['timeout_ends'] > now]

def get_currently_active_model(skip=()):
	try:
		if google_api.get_api() in (None, 'None', '', 'empty_setting'): return None
		now = get_timestamp()
		banned = [i['model_id'] for i in _failed_records() if i['timeout_ends'] > now]
		return next((i for i in ai_model_order() if i not in banned and i not in skip), None)
	except: return None

def set_currently_active_models(model_id, status_code):
	# 404 (retired) and 429 (quota) ban at once; anything else bans on the 3rd failure in a row. Bans last 24 h.
	try:
		records = _failed_records()
		current = next((i for i in records if i['model_id'] == model_id), {})
		records = [i for i in records if i is not current]
		fails, timeout_ends = current.get('fails', 0) + 1, 0
		if status_code in (404, 429) or fails >= 3:
			fails, timeout_ends = 0, get_timestamp(24)
			notification('Disabling %s: Error Code %s' % (model_id, status_code))
		records.append({'model_id': model_id, 'fails': fails, 'timeout_ends': timeout_ends})
		lists_cache.set('ai_model_failed', records, 24*365)
	except: pass

def _clear_fail_count(model_id):
	try:
		records = _failed_records()
		kept = [i for i in records if not (i['model_id'] == model_id and not i['timeout_ends'])]
		if len(kept) != len(records): lists_cache.set('ai_model_failed', kept, 24*365)
	except: pass

def ai_similar_call(media_type, tmdb_id, meta, limit, timeout=30):
	# LOCAL PATCH 2026-09-26: imported here, not at module level -- windows/extras.py imports this
	# module on every Extras open, and `requests` is ~0.4 s of import on Kodi's bundled copy.
	import requests
	tried = []
	while True:
		model_id = get_currently_active_model(tried)
		if not model_id: return {}
		tried.append(model_id)
		model_info = google_api.model_info(model_id, media_type, meta, limit)['similar']
		try:
			response = requests.post(model_info['url'], headers=model_info['headers'], json=model_info['payload'], timeout=timeout)
			status_code = response.status_code
		except: status_code = 0
		if status_code == 200:
			_clear_fail_count(model_id)
			return model_info['parse'](response.json())
		set_currently_active_models(model_id, status_code)
