# -*- coding: utf-8 -*-
import re
import time
import json
import random
from threading import Thread, Lock
from caches.external_cache import external_cache
from caches.settings_cache import get_setting
from modules import kodi_utils, source_utils
from modules.debrid import RD_check, PM_check, AD_check ,TB_check, query_local_cache, query_local_cache_files
from modules.utils import clean_file_name
from modules.source_utils import ANIME_PROVIDERS, is_anime_meta, anime_providers_to_run
# logger = kodi_utils.logger

# LOCAL PATCH 2026-09-24: the listing readers used by _real_pack_sizes' probe
# (listing_episode_numbers, listing_episode_pairs) live in source_utils beside the matcher.

# LOCAL PATCH 2026-10-01: the display name blanked every '+', so 'HDR10.HDR10+.Dolby.Vision' read
# 'HDR10 HDR10  Dolby Vision' beside an (accurate) HDR10+ chip. '+' is still a separator ('Dub.+.MVO'),
# except where it is part of the tag: HDR10+, DD+, TV+ / Disney+ / Paramount+.
_PLUS_SEPARATOR = re.compile(r'(?i)(?<!hdr10)(?<!dd)(?<!tv)(?<!disney)(?<!paramount)\+')
# LOCAL PATCH 2026-10-05: an episode range in a FILE name ('S01E12-E17', 'E12~E17'), see _real_pack_sizes
_RE_FILE_RANGE = re.compile(r'(?i)(?<![a-z0-9])(?:s\d{1,2})?e(\d{1,4})(?:[-~]e?|\s*[-~]\s*e)(\d{1,4})(?!\d)')

def _info_score(item):
	"""LOCAL PATCH 2026-10-02: which copy of a hash several providers listed is kept (see _process_duplicates).
	Higher wins; equal scores keep the copy that arrived first. Every copy is the SAME torrent, so only what the
	provider says about it differs: item['extraInfo'] ('HEVC | WEB | DD+ | 6CH', the tags read from its name),
	item['name'], item['size'] (GB, float), item.get('seeders') (absent on some providers)."""
	# tags first (more read from the name = more told), then the longer name: it usually still carries the group
	# ('AOC' was lost when MediaFusion's shorter copy won, screenshot 120)
	tags = len([t for t in (item.get('extraInfo') or '').split(' | ') if t])
	return (tags, len(item.get('name') or ''))

class source:
	def __init__(self, meta, source_dict, active_debrid, external_cache_check, internal_scrapers, prescrape_sources, progress_dialog, disabled_ext_ignored=False,
				 count_filter=None, all_scrapers=False):
		self.monitor = kodi_utils.kodi_monitor()
		self.scrape_provider = 'external'
		self.progress_dialog = progress_dialog
		self.external_cache_check = external_cache_check
		# LOCAL PATCH 2026-10-03 (Batch 3): "Disable All Filters" scrapes neither read nor write the results cache. They
		# read it, so the provider's FILTERED rows came back and the option did nothing for 1-30 days; and an unfiltered
		# result written there would be served to the next normal scrape.
		self.filterless = kodi_utils.get_property('fs_filterless_search') == 'true'
		self.meta = meta
		self.background = self.meta.get('background', False)
		self.active_debrid = active_debrid
		self.source_dict, self.host_dict = source_dict, []
		self.sources, self.all_internal_sources, self.processed_internal_scrapers = [], [], []
		self.processed_internal_scrapers_append = self.processed_internal_scrapers.append
		self.internal_scrapers, self.prescrape_sources = internal_scrapers, prescrape_sources
		self.internal_activated, self.internal_prescraped = len(self.internal_scrapers) > 0, len(self.prescrape_sources) > 0
		self.processed_prescrape, self.threads_completed = False, False
		self.provider_counts = {}   # LOCAL PATCH 2026-09-27: per-provider rows in the loading window
		self.provider_failed = set()   # LOCAL PATCH 2026-09-27: providers that came back empty because they FAILED (_scrape)
		self.timeout = 60 if disabled_ext_ignored else int(get_setting('deadlight.results.timeout', '20'))
		self.all_scrapers = all_scrapers   # LOCAL PATCH 2026-10-04: 'Rescrape With All Scrapers' only (sources.all_scrapers_retry), see _is_not_for_anime_skipped
		self.sources_total = self.sources_4k = self.sources_1080p = self.sources_720p = self.sources_sd = 0
		self.final_total = self.final_4k = self.final_1080p = self.final_720p = self.final_sd = 0
		# LOCAL PATCH 2026-09-30: the window counts each release once and only what the list will show; the search
		# phase and the cache-check phase count separately (source_utils.WindowCounter, sources._window_countable)
		self.counter, self.counter_final = source_utils.WindowCounter(count_filter), source_utils.WindowCounter(count_filter)
		self.count_tuple = (('sources_4k', '4K', self._quality_length), ('sources_1080p', '1080p', self._quality_length), ('sources_720p', '720p', self._quality_length),
							('sources_sd', '', self._quality_length_sd), ('sources_total', '', self.quality_length_final))
		self.count_tuple_final = (('final_4k', '4K', self._quality_length), ('final_1080p', '1080p', self._quality_length), ('final_720p', '720p', self._quality_length),
									('final_sd', '', self._quality_length_sd), ('final_total', '', self.quality_length_final))
		self.debrid_runners = {'Real-Debrid': ('Real-Debrid', RD_check), 'Premiumize.me': ('Premiumize.me', PM_check),
							'AllDebrid': ('AllDebrid', AD_check),'TorBox': ('TorBox', TB_check)}

	def results(self, info):
		if not self.source_dict: return
		_t_setup = time.perf_counter()   # LOCAL PATCH 2026-10-02: scrape.diag_timing, see the line before get_sources below
		try:
			self.media_type, self.tmdb_id, self.orig_title = info['media_type'], str(info['tmdb_id']), info['title']
			self.season, self.episode, self.total_seasons = info['season'], info['episode'], info['total_seasons']
			self.title, self.year = source_utils.normalize(info['title']), info['year']
			ep_name, aliases = source_utils.normalize(info['ep_name']), info['aliases']
			self.single_expiry, self.season_expiry, self.show_expiry = info['expiry_times']
			self._season_counts = {}   # LOCAL PATCH 2026-10-03: set for TV below; read by process_sources for every media type
			if self.media_type == 'movie':
				self.season_divider, self.show_divider = 0, 0
				self.data = {'imdb': info['imdb_id'], 'title': self.title, 'aliases': aliases, 'year': self.year}
				# LOCAL PATCH 2026-09-23: anime FILMS are mapped too, and nothing here ever asked.
				#
				# Every Fribb lookup in this method sits in the TV branch below, so a film's data was
				# imdb/title/aliases/year and no more -- while Fribb's slim list, already loaded and
				# indexed, holds 1363 rows with a TMDb MOVIE id. Chainsaw Man - The Movie: Reze Arc
				# (tmdb 1218925) is one: anidb 18324, anilist 171627. ani.zip files it as a one-episode
				# MOVIE entry, episode key '1', eid 294424 -- so a film HAS an eid and animetosho serves
				# it like any other, despite its hasMovies=False (nothing in this dispatch reads that
				# flag; only magneto's health.py does).
				#
				# Measured on eid 294424: 58 rows, every one single-file. The aid query returns 50 with
				# two multi-file scene rows, and is missing the 2160p HEVC, the 1604p AV1 HDR10+ and the
				# DS4K AV1 releases -- 9 rows the eid has and the aid does not, against 1 the other way.
				# aid= lists torrents attributed wholly to the AniDB entry; eid= lists every file matched
				# to the episode, which also reaches inside multi-anime batches. So the eid is worth the
				# lookup, and the lookup is cached 24h -- one request per film per day, not per scrape.
				#
				# anilist_id is set as well because ani.zip hands it back and it is seadex's ONLY key.
				# For the 77 movie rows Fribb gives no anilist_id, the anidb_id query recovers it.
				# No anidb_aid: a film has no pack query, so nothing here would read it.
				try:
					from caches import fribb_mappings as _fribb
					_mk = _fribb.query_ids_for_tmdb_movie(self.tmdb_id)
					if _mk:
						from caches.anizip_mappings import anizip_episode_ids
						# cour_episode=1: the film is the single entry-local episode of its own AniDB entry.
						_ids = anizip_episode_ids(_mk.get('anilist_id'), cour_episode=1,
							anidb_id=_mk.get('anidb_id')) or {}
						if _ids.get('eid'): self.data['anidb_eid'] = int(_ids['eid'])
						if _ids.get('anilist'): self.data['anilist_id'] = int(_ids['anilist'])
						# LOCAL PATCH 2026-10-06: torrentio and comet search a film by it when it has no IMDb id (53 anime films in
						# Fribb, 50 with a Kitsu id); with one they keep the IMDb query
						if _mk.get('kitsu_id'): self.data['kitsu_id'] = int(_mk['kitsu_id'])
						kodi_utils.logger('scrape.anime_gate', 'movie tmdb=%s anidb=%s eid=%s anilist=%s kitsu=%s'
							% (self.tmdb_id, _mk.get('anidb_id'), self.data.get('anidb_eid'), self.data.get('anilist_id'), self.data.get('kitsu_id')))
				except Exception: pass
			else:
				try: self.season_divider = [int(x['episode_count']) for x in self.meta['season_data'] if int(x['season_number']) == int(self.meta['season'])][0]
				except: self.season_divider = 1
				self.show_divider = int(self.meta['total_aired_eps'])
				# LOCAL PATCH 2026-10-03: episodes per season, so a show pack of S01-S02 is divided by those two seasons
				# (source_utils.pack_size_divider), not by every aired episode of the show.
				try: self._season_counts = {int(x['season_number']): int(x['episode_count']) for x in self.meta['season_data'] if int(x['season_number']) != 0}
				except Exception: self._season_counts = {}
				# LOCAL PATCH 2026-06-23: add total_seasons to TV data dict. POV-style magneto
				# scrapers (e.g. torrentio.py) read data['total_seasons'] directly with bracket
				# access for season/show pack detection; without this key they raise KeyError
				# on every TV episode scrape -> scraper_error -> silent zero results. self.total_seasons
				# is already populated at line 42 from info['total_seasons']; just propagate.
				self.data = {'imdb': info['imdb_id'], 'tvdb': info['tvdb_id'], 'tvshowtitle': self.title, 'aliases': aliases,'year': self.year,
							'title': ep_name, 'season': str(self.season), 'episode': str(self.episode),
							'total_seasons': self.total_seasons}
				# LOCAL PATCH 2026-08-07: cross-season contamination filter data. Extract
				# tokens from OTHER seasons' TMDb names so scrapers can reject torrents
				# labeled as other seasons/arcs (e.g. Bleach S1 target → reject torrents
				# containing "Thousand-Year Blood War" tokens from Bleach S2).
				try:
					import re as _re
					# LOCAL PATCH 2026-08-09: ordinals + generic season descriptors are
					# NOT distinguishing arc tokens — release groups use them freely for
					# any anime with multiple seasons. Extracting them into
					# foreign_season_tokens caused false rejects. Example: TMDb Ace of
					# Diamond has S4 name "Act II -Second Season-"; "second" leaked as a
					# reject token even for the show's own S2 "Season 2", killing many
					# legit torrents like "Ace of Diamond Second Season - 15".
					_STOP = {
						'season', 'the', 'of', 'a', 'an', 'and', 'part', 'cour', 'arc',
						# ordinal words — generic descriptors, not arc-specific
						'first', 'second', 'third', 'fourth', 'fifth', 'sixth',
						'seventh', 'eighth', 'ninth', 'tenth', 'final', 'last',
						# other generic
						'series', 'saga', 'chapter',
					}
					target_s = int(self.season)
					title_lc = self.title.lower()
					foreign_tokens = set()
					for sn in (self.meta.get('season_data') or []):
						try: n = int(sn.get('season_number', -1))
						except (TypeError, ValueError): continue
						if n == target_s or n == 0: continue  # skip target + specials
						name = (sn.get('name') or '').lower().strip()
						if not name: continue
						# Skip generic "Season N" / show-title-identical names — no distinguishing tokens
						if _re.match(r'^season\s+\d+$', name): continue
						if name == title_lc: continue
						for w in _re.findall(r'[a-z0-9]+', name):
							if len(w) >= 4 and w not in _STOP: foreign_tokens.add(w)
					if foreign_tokens:
						self.data['foreign_season_tokens'] = sorted(foreign_tokens)
				except Exception: pass
				# LOCAL PATCH 2026-08-09: anime scoping via Fribb. Look up which specific
				# anime cour our (tmdb, season, episode) maps to and pass the cour's
				# MAL/kitsu IDs + cour-relative episode number to magneto scrapers.
				# torrentio uses `kitsu:<id>:<cour_ep>` path which is cour-scoped at
				# the source — no cross-cour contamination possible. nyaa gets an
				# additional romaji title alias for better search recall.
				try:
					from modules.metadata import is_anime_check, series_absolute_episode
					if is_anime_check(self.meta, self.tmdb_id):
						self.data['is_anime'] = True   # LOCAL PATCH 2026-10-05: torrentio's and comet's anime-only checks (anime_utils.stremio_junk)
						# LOCAL PATCH 2026-10-05: each TMDb season's air year, for anime_utils.other_show_year
						try:
							self.data['season_years'] = dict((int(_sn['season_number']), int(str(_sn['air_date'])[:4]))
								for _sn in (self.meta.get('season_data') or []) if _sn.get('air_date') and int(_sn.get('season_number') or 0) > 0)
						except Exception: pass
						# LOCAL PATCH 2026-10-08: the episode's own air year, for anime_utils.other_season_year
						try: self.data['episode_year'] = int(str(self.meta.get('premiered') or '')[:4])
						except (TypeError, ValueError): pass
						# LOCAL PATCH 2026-09-02: series-absolute episode number, set for EVERY anime --
						# it needs only TMDb's season_data, not a Fribb cour. It used to sit inside the
						# `if cour_info:` block below, so a long-running show whose Fribb row carries no
						# season at all (Naruto is ONE entry covering all 220 episodes) got nothing.
						#
						# Supersedes the 2026-08-27 version, which computed `sum(earlier episode_count) +
						# episode` with no guard and justified itself by claiming TMDb offers 'Naruto S04E01'
						# where releases say 159. That premise was false: TMDb's Naruto S1 ends at
						# episode_number 52 and its S4 STARTS at 159, so TMDb was already absolute and the
						# sum pushed 159 to 317. See metadata.series_absolute_episode for the measured list
						# and the two-signal test.
						#
						# The RAW TMDb pair is used deliberately. meta['season']/['episode'] come from the
						# route params (sources.py, read BEFORE check_episode_group runs), while self.season/
						# self.episode carry an assigned episode group's rewrite. Mixing them is what made a
						# One Piece scrape for TMDb S6E157 compute 263 + 14 = 277 -- the TVDB Order group had
						# turned it into S9E14, and 277 is a real, different episode. Feeding the helper TMDb
						# coordinates against TMDb season_data makes the answer identical with or without a
						# group. Falls back to the scrape pair for the _prefetched_meta path, which may not
						# carry season/episode.
						# LOCAL PATCH 2026-09-22: the raw TMDb pair, named once. self.season/self.episode carry
						# an assigned episode group's rewrite; everything below that consults TMDb's own
						# season_data or Fribb's TMDb-keyed table needs the numbers TMDb actually files this
						# episode under, or it asks about an episode that does not exist. See the two notes
						# below for what each consumer lost.
						_raw_s = self.meta.get('season', self.season)
						_raw_e = self.meta.get('episode', self.episode)
						_pm = [('setup', time.perf_counter())]   # LOCAL PATCH 2026-10-09: scrape.prep, per-step ms of the anime id work
						try:
							_abs = series_absolute_episode(self.meta, _raw_s, _raw_e)
							if _abs: self.data['absolute_episode'] = int(_abs)
						except Exception: pass
						try: kodi_utils.logger('scrape.absolute', 'tmdb=%s raw=S%sE%s scrape=S%sE%s abs=%s' % (self.tmdb_id, self.meta.get('season'), self.meta.get('episode'), self.season, self.episode, self.data.get('absolute_episode')))
						except Exception: pass
						_pm.append(('absolute', time.perf_counter()))
						# LOCAL PATCH 2026-08-27: publish the ordered numbering candidates ONCE so the
						# providers do not each re-derive them. seadex carried its own copy of this
						# ordering and said so in its own docstring; two copies of a rule this subtle
						# drift apart. It is the same list the debrid layer uses to pick a file out of a
						# pack, so a provider and the resolver can no longer disagree about which numbers
						# count for this episode.
						# LOCAL PATCH 2026-09-22: raw coords here too. anime_episode_candidates spends the pair
						# on series_absolute_episode and on find_cour_by_tmdb_coords, both of which read TMDb
						# numbering, so a group's rewrite produced a FABRICATED absolute (episodes before the
						# group's season, plus the group's episode) and lost the pair releases actually use.
						# Measured 2026-09-22 over the 9 group-assigned shows: 132 of 1968 episode mappings got
						# an out-of-range candidate tried FIRST -- Re:ZERO raw S1E27 read as group S2E2 gave
						# [(2, 87), (2, 2)] for an 85-episode show, with (2, 1) = 'S2 - 01' absent. Raw gives
						# [(1, 27), (2, 1)]. The group pair is deliberately NOT kept as well: (2, 2) would match
						# a real S02E02 file, which is TMDb episode 28 -- the wrong episode, which is the one
						# outcome ordered_episode_candidates' docstring calls worse than finding nothing.
						try:
							_cands = source_utils.anime_episode_candidates(
								self.meta, self.tmdb_id, _raw_s, _raw_e)
							self.data['episode_candidates'] = source_utils.ordered_episode_candidates(
								int(_raw_s), int(_raw_e), _cands)
						except Exception: pass
						_pm.append(('candidates', time.perf_counter()))
						from caches import fribb_mappings as _fribb
						# LOCAL PATCH 2026-09-05: allow_repair=False. The flat-season repair
						# invents cour boundaries from a TMDb episode group for shows Fribb
						# files flat, which is right for LABELLING an episode but wrong for
						# FINDING one: it hands providers a cour-relative episode plus a
						# cour_season that the groups releasing these shows do not use.
						# Scrapers get Fribb's raw coordinates -- for a flat show, TMDb's own
						# numbers. The episode list keeps its cour split.
						# LOCAL PATCH 2026-09-22: the RAW TMDb pair, for the same reason series_absolute_episode
						# above uses it. find_cour_by_tmdb_coords is keyed on TMDb coordinates -- its own
						# docstring says so -- while self.season/self.episode carry an assigned episode group's
						# rewrite, so for any show with a group the lookup was asking for coordinates TMDb does
						# not have and getting None back. Measured 2026-09-22 on Re:ZERO (tmdb 65942, group
						# 'Seasons'): TMDb files all 85 episodes under season 1, the group splits them into
						# S1-S4, and S1E27/S1E39/S1E51 were asked for as S2E2/S2E14/S3E1 -- all three None.
						# Episode 1 was the ONLY one that worked, because there alone the two numberings
						# coincide. With cour_info empty the whole block below is skipped, so the scrape lost
						# anidb_eid and anidb_aid (animetosho logs 'SKIPPED, no anidb_eid (aid=None)' and
						# returns nothing), anilist_id (seadex's only key), kitsu_id (comet's cour path),
						# cour_season/season_episode/cour_part and the romaji alias nyaa searches with.
						# 9 shows in this library have a group assigned, so this was never Re:ZERO-only.
						cour_info = _fribb.find_cour_by_tmdb_coords(self.tmdb_id, _raw_s, _raw_e, allow_repair=False)
						_pm.append(('fribb', time.perf_counter()))
						try: self._prefetch_anime_ids(cour_info, _raw_s, _raw_e)
						except Exception: pass
						_pm.append(('prefetch', time.perf_counter()))
						# LOCAL PATCH 2026-10-05: an episode past its entry's length means TMDb folded a later season into this
						# one after Fribb mapped it -- Blue Box is now one TMDb season of 37 and The Ramparts of Ice one of 28,
						# while Fribb still files their second seasons under a TMDb season 2 that no longer exists. S1E26 became
						# 'episode 26' of Blue Box S1's 25-episode entry: no AniDB eid (animetosho skipped), and S1's Kitsu id
						# with episode 26. Only then ask again with the flat-season repair, which splits TMDb's season at an
						# episode group's boundaries (TMDb's own 'Seasons' group: 25 + 12), and take it if it lands on another
						# entry that is long enough. allow_repair stays False otherwise -- see the note above.
						try:
							_cep = int((cour_info or {}).get('cour_ep') or 0)
							if _cep > 1 and cour_info.get('anilist'):
								from apis.anilist_api import anilist_episode_count
								_len = anilist_episode_count(cour_info['anilist'])
								if _len and _cep > int(_len):
									_rep = _fribb.find_cour_by_tmdb_coords(self.tmdb_id, _raw_s, _raw_e, allow_repair=True) or {}
									_rlen = anilist_episode_count(_rep['anilist']) if _rep.get('anilist') else None
									_ok = bool(_rep.get('anilist')) and _rep.get('anilist') != cour_info.get('anilist') \
										and (not _rlen or int(_rep.get('cour_ep') or 0) <= int(_rlen))
									kodi_utils.logger('scrape.cour', 'tmdb %s S%sE%s is ep %s of AniList %s (%s eps) -- repaired: %s' % (self.tmdb_id,
										_raw_s, _raw_e, _cep, cour_info['anilist'], _len, 'AniList %s ep %s (AniDB %s)' % (_rep.get('anilist'),
										_rep.get('cour_ep'), _rep.get('anidb')) if _ok else 'no better entry, kept'))
									if _ok: cour_info = _rep
									# no Fribb row for the folded season at all (A Wild Last Boss Appeared: S1 is AniList 180523, 12 episodes;
									# TMDb S1E13 is its 2nd Season, 204389, which Fribb lacks) -- the short entry's ids would only search for an
									# episode that does not exist, so drop them; _new_season_ids below finds the next entry by air date
									else: cour_info = None
						except Exception: pass
						_pm.append(('repair', time.perf_counter()))
						if cour_info:
							if cour_info.get('mal'): self.data['mal_id'] = int(cour_info['mal'])
							if cour_info.get('kitsu'): self.data['kitsu_id'] = int(cour_info['kitsu'])
							if cour_info.get('anilist'): self.data['anilist_id'] = int(cour_info['anilist'])
							# LOCAL PATCH 2026-09-22: every part of this season, so the pack query can ask for
							# its siblings too.
							#
							# A split season is several AniDB entries, and a pack covering the WHOLE season is
							# filed under the FIRST part's aid -- that is AniDB's main entry for the season. So
							# a pack query made from part 2's aid never sees it, though it plainly contains part
							# 2's episodes. Measured 2026-09-22, packs found per part:
							#   JoJo Stone Ocean   p1 12   p2 2   p3 1
							#   Mushoku Tensei S1  p1 83   p2 13
							#   Mushoku Tensei S2  p1 39   p2 6
							# Six times as many under part 1 in all three, and part 1's biggest row is the giveaway
							# every time: 46 files for a 38-episode Stone Ocean, 250 for Mushoku S02. Those are
							# whole-season releases, not part-1 releases.
							#
							# Only the aids are published; whether to ask for them is the provider's business, and
							# every row it gets back still faces the same per-row validation.
							# ONLY rows of the same season.tvdb. _season_cour_rows returns every cour of a TMDb
							# season, and for a show TMDb files flat that means several REAL seasons, not parts:
							# Apothecary S1 returns four rows with season.tvdb 1, 2, 3, 4 (offsets 0/24/48/72),
							# which are its seasons 1-4. JoJo's three rows are all season.tvdb 5, offsets 0/12/24 --
							# genuinely one season split in three. cour_season IS season.tvdb, so matching on it is
							# the distinction already used everywhere else here. Without this a Apothecary S1 scrape
							# would query four aids and merge three other seasons' packs into the result.
							try:
								_part_aids, _tv = [], cour_info.get('cour_season')
								for _off, _prow in _fribb._season_cour_rows(self.tmdb_id, _raw_s, allow_repair=False):
									_prow = _prow or {}
									if (_prow.get('season') or {}).get('tvdb') != _tv: continue
									_pa = _prow.get('anidb_id')
									if _pa and int(_pa) not in _part_aids: _part_aids.append(int(_pa))
								if len(_part_aids) > 1: self.data['anidb_part_aids'] = _part_aids
							except Exception: pass
							if cour_info.get('cour_ep') is not None: self.data['cour_episode'] = int(cour_info['cour_ep'])
							# LOCAL PATCH 2026-08-27: the season number RELEASES use (season.tvdb),
							# which is what a scraper has to compare an "S02"/"2nd Season" marker
							# against. TMDb files every Re:ZERO cour under season 1, so self.season
							# cannot be used for that check.
							if cour_info.get('cour_season') is not None: self.data['cour_season'] = int(cour_info['cour_season'])
							# LOCAL PATCH 2026-08-27: the number releases actually use. A tvdb season can
							# span several Fribb cours, and groups keep counting across them: Re:ZERO S2 is
							# two cours, so TMDb ep 50 is cour_ep 12 but is named '2nd Season - 24'. Same
							# for AoT S3E20 (cour_ep 8). cour_episode still drives the kitsu query, which
							# IS cour-scoped; season_episode is for matching release names.
							if cour_info.get('season_ep') is not None: self.data['season_episode'] = int(cour_info['season_ep'])
							# LOCAL PATCH 2026-10-03: episodes in that release season, for sizing a batch that names no range.
							# The last season has no later cour to end it, so TMDb's season count bounds it there.
							try:
								_slen = cour_info.get('season_len')
								if not _slen and cour_info.get('season_start') is not None:
									_slen = int(self.season_divider) - int(cour_info['season_start'])
								if _slen and int(_slen) > 0: self.data['season_length'] = int(_slen)
							except Exception: pass
							# Which part of the season this cour is, passed only when the season really
							# is split -- otherwise a lone 'Part 2' in a name would be read as a mismatch.
							if (cour_info.get('cour_part') and (cour_info.get('cour_part_count') or 0) > 1):
								self.data['cour_part'] = int(cour_info['cour_part'])
								# LOCAL PATCH 2026-09-24: and how many parts there are, so a 'Part N' in a name
								# larger than that is known NOT to be a cour part. JoJo names its story arcs
								# 'Part 6: Stone Ocean', and cour_match read that as cour part 6 against the 3
								# Stone Ocean has, rejecting '[Anime Chap] ... Part 6: Stone Ocean S05E25'.
								self.data['cour_part_count'] = int(cour_info['cour_part_count'])
							# LOCAL PATCH 2026-09-24: TMDb's name for this season, so the title-anchored episode
							# reader has '<show> <season>' as a candidate. '[Some-Stuffs] Jojo's Bizarre Adventure
							# Stone Ocean 25' has no number straight after the show title -- 'Stone Ocean' sits
							# between -- so it read as no episode at all and was rejected. Raw TMDb season, not an
							# episode group's.
							try:
								for _sn in (self.meta.get('season_data') or []):
									if int(_sn.get('season_number') or -1) == int(_raw_s) and _sn.get('name'):
										self.data['season_title'] = _sn['name']
							except Exception: pass
							# LOCAL PATCH 2026-08-27: AniDB episode id, for the animetosho provider.
							#
							# This is the one piece of scrape data that identifies the episode WITHOUT
							# reference to how anyone chose to name it. Everything else passed to the
							# scrapers above (cour_season, season_episode, cour_part, absolute_episode) is
							# raw material for guessing at filenames; those guesses are why a Bleach scrape
							# had to be taught that 'S01E01' and 'S17E01' can be the same episode. An eid
							# just is that episode, so animetosho needs no naming rules at all.
							#
							# Best-effort by design. A missing eid costs nothing -- animetosho returns no
							# sources and every other provider scrapes exactly as before.
							try:
								from caches.anizip_mappings import anizip_episode_ids
								_ids = anizip_episode_ids(
									cour_info.get('anilist'), cour_info.get('cour_ep'),
									self.data.get('absolute_episode'), cour_info.get('anidb'))
								# The AniDB id from Fribb is offline and authoritative; prefer it and let
								# ani.zip's only fill in when Fribb's row has no anidb_id.
								_aid = cour_info.get('anidb') or _ids.get('aid')
								if _aid: self.data['anidb_aid'] = int(_aid)
								if _ids.get('eid'): self.data['anidb_eid'] = int(_ids['eid'])
								# LOCAL PATCH 2026-08-27: Fribb's rows are unevenly populated -- some carry an
								# anidb id but none of the others. ani.zip returns them all, so a lookup made
								# by anidb id hands back the ids Fribb was missing: anilist is seadex's only
								# key, and kitsu is what makes torrentio's and comet's cour-scoped Kitsu paths
								# engage at all. 5 anime in this library are in that state, Chainsmoker Cat
								# among them. Only ever fill a gap -- never overwrite Fribb's own value.
								for _key, _field in (('anilist', 'anilist_id'), ('kitsu', 'kitsu_id'), ('mal', 'mal_id')):
									if _ids.get(_key) and not self.data.get(_field):
										self.data[_field] = int(_ids[_key])
							except Exception: pass
							# LOCAL PATCH 2026-08-10: romaji title now comes from AniList, not the
							# retired anime_mappings DB (upstream frozen 2026-05-31; it was missing
							# mal_title for ~30% of current-season anime — precisely the shows most
							# likely to be scraped). Cached 30 days, and we bulk-warm every cour of
							# this show in one request so other episodes/seasons never pay the call.
							try:
								from apis.anilist_api import anilist_romaji_for_mal, anilist_romaji_bulk, anilist_romaji_by_ids, anilist_romaji_for_id
								mal_here = cour_info.get('mal')
								# LOCAL PATCH 2026-10-03 (Batch 4): titles by the cour's AniList id whenever Fribb has one, and the
								# sibling titles keyed the same way. By MAL id, Steel Ball Run S6E1 was searched as '2nd & 3rd STAGE':
								# MAL 61469 is two AniList entries and the MAL lookup kept the later one. MAL only for a cour with no
								# AniList id. _bulk_titles and own_id use ONE kind of id -- the two number spaces overlap.
								al_here = cour_info.get('anilist')
								_id_field, own_id = ('anilist_id', al_here) if al_here else ('mal_id', mal_here)
								# LOCAL PATCH 2026-10-03 (Batch 4 follow-up): an episode past its AniList entry's length means Fribb
								# filed it under the wrong cour. Steel Ball Run's 2nd & 3rd STAGE row has no TMDb id, so Fribb puts
								# all of S6 on the 1-episode 1st STAGE entry: S6E3 was searched as '1st STAGE', and the real cour's
								# words counted as a foreign cour's. No cour title and no sibling tokens then -- the scrape runs on
								# the TMDb titles, as for a show Fribb does not know. Same test as the AniList progress push.
								try:
									_cep = int(cour_info.get('cour_ep') or 0)
									if al_here and _cep > 1:
										from apis.anilist_api import anilist_episode_count
										_len = anilist_episode_count(al_here)
										if _len and _cep > int(_len):
											kodi_utils.logger('scrape.cour', 'tmdb %s S%sE%s is cour ep %s of AniList %s, which has %s: '
												'cour mapping off, no cour title' % (self.tmdb_id, self.season, self.episode, _cep, al_here, _len))
											own_id = None
								except Exception: pass
								_bulk_titles = {}
								if own_id:
									# Warm all sibling cours of this TMDb show in a single request.
									try:
										sibling_ids = [r.get(_id_field) for r in _fribb.tmdb_tv_to_fribb_rows(self.tmdb_id) if r.get(_id_field)]
										if al_here: _bulk_titles = anilist_romaji_by_ids(sibling_ids + [al_here]) or {}
										elif len(sibling_ids) > 1: _bulk_titles = anilist_romaji_bulk(sibling_ids) or {}
									except Exception: pass
									mt = anilist_romaji_for_id(al_here) if al_here else anilist_romaji_for_mal(mal_here)
									if mt: self.data['mal_title'] = mt
									# LOCAL PATCH 2026-08-27: reject tokens from the OTHER cours of this same TMDb
									# show, in ROMAJI. foreign_season_tokens above is built from TMDb season names,
									# so it only ever knows the English form: for Bleach it holds {thousand, year,
									# blood, war} and catches nothing titled 'Sennen Kessen-hen', which is how most
									# Thousand-Year Blood War releases are actually named. The sibling titles are
									# already in hand from the bulk warm above, so this costs no extra request.
									try:
										import re as _re2
										def _ftok(t): return set(w for w in _re2.findall(r'[a-z0-9]+', (t or '').lower()) if len(w) >= 4)
										_mine = _ftok(mt) | _ftok(self.title)
										_same_ids = set()
										# LOCAL PATCH 2026-09-24: 'ours' must not hang on AniList knowing this cour. It has
										# no entry for JoJo Stone Ocean Part 3 (MAL 53273 -> Not Found), so mt was empty,
										# _mine held only the TMDb show title, and parts 1 and 2 donated stone/ocean/kimyou/
										# bouken as FOREIGN words -- both real S05E25 singles and all 16 Stone Ocean packs were
										# rejected for part 3, and the scrape found nothing. Two sources are ours whatever
										# AniList says: TMDb's name for THIS season, which every cour in it shares ('STONE
										# OCEAN'), and a word in every KNOWN title of a cour in this same TMDb season ('jojo
										# kimyou bouken stone ocean', from parts 1 and 2). Same-season, not every sibling:
										# Fribb maps Kishibe Rohan (MAL 33191) to JoJo's TMDb show too, and it shares no
										# word with the rest. When our own title is known the intersection is a subset of it
										# and changes nothing. Raw TMDb season, not an episode group's: the scrape can run as
										# S10E25 for a TMDb S5E25.
										try:
											_own_s = int(self.meta.get('season', self.season))
											for _sn in (self.meta.get('season_data') or []):
												if int(_sn.get('season_number') or -1) == _own_s: _mine |= _ftok(_sn.get('name'))
											_same = []
											for _off, _prow in _fribb._season_cour_rows(self.tmdb_id, _own_s, allow_repair=False):
												try: _sid = int((_prow or {}).get(_id_field) or 0)
												except (TypeError, ValueError): _sid = 0
												_same_ids.add(_sid)
												_t = (_bulk_titles or {}).get(_sid)
												if _t: _same.append(_ftok(_t))
											if _same: _mine |= set.intersection(*_same)
										except Exception: pass
										_foreign = set()
										for _mid, _mtitle in (_bulk_titles or {}).items():
											try:
												if int(_mid) == int(own_id): continue
											except (TypeError, ValueError): pass
											_foreign |= _ftok(_mtitle)
											# Also the acronym: 'Thousand-Year Blood War' is released as 'Bleach TYBW',
											# which shares no whole word with any title we know. Four letters or more
											# only, so it cannot collide with an ordinary word by accident.
											try:
												_words = [w for w in _re2.findall(r'[A-Za-z]+', _mtitle or '') if len(w) > 2]
												_acr = ''.join(w[0] for w in _words).lower()
												if len(_acr) >= 4: _foreign.add(_acr)
											except Exception: pass
										# Fold in the English-named ones too. foreign_season_tokens is only applied
										# by the scrapers when the release makes no season claim of its own, and a
										# TYBW release labels ITSELF S01E01 -- so that guard never fires on exactly
										# the rows that need it. Here the cour is known outright, so the release's
										# own numbering carries no weight and the tokens can be applied unconditionally.
										_foreign |= set(self.data.get('foreign_season_tokens') or [])
										# ...and the acronyms of the OTHER TMDb season names, for the same reason:
										# 'Bleach TYBW - Pt1' names the arc by initials only.
										try:
											for _sn in (self.meta.get('season_data') or []):
												try:
													if int(_sn.get('season_number') or 0) in (0, int(self.season)): continue
												except (TypeError, ValueError): continue
												_w = [w for w in _re2.findall(r'[A-Za-z]+', _sn.get('name') or '') if len(w) > 2]
												_a = ''.join(w[0] for w in _w).lower()
												if len(_a) >= 4: _foreign.add(_a)
										except Exception: pass
										_foreign -= _mine
										# LOCAL PATCH 2026-09-24: structural words are not a cour's identity. A sibling's
										# title contributes 'part' whenever OUR title lacks it, and it never tells two parts
										# apart -- both are 'Part 01' and 'Part 02'. Re:ZERO S2 part 1 is '2nd Season', part 2
										# '2nd Season Part 2', so part 1's list held 'part' and every 'Season 2 Part 01' pack
										# was rejected as naming another cour: 33 on a live S2E2 scrape, TTGA's BDRemux among
										# them. S1's list held 'season' the same way. Part NUMBERS are compared elsewhere
										# (cour_match step 3b, animetosho's declared-part check). Ordinals and 'final' are
										# NOT here: 'The Final Season' does name a cour.
										_foreign -= {'part', 'parts', 'season', 'seasons', 'cour', 'cours'}
										if _foreign: self.data['foreign_cour_tokens'] = sorted(_foreign)
										# LOCAL PATCH 2026-10-05: the words only THIS TMDb season's cours are named with -- 'sennen kessen
										# thousand blood' for Bleach S2, 'stone ocean' for JoJo S5. comet's Kitsu answers are not scoped to
										# the entry (Black Clover's 2nd Season id returned only Season 1 episode 1), so comet refuses a name
										# claiming an earlier season unless it carries one of these: a sub-series counts its own seasons
										# ('Bleach TYBW S01E01' is TVDB season 17). Words a cour of ANOTHER TMDb season shares are left
										# out -- Mushoku Tensei S1 and S2 are both 'Isekai Ittara Honki Dasu'. See anime_utils.comet_kitsu_reject.
										try:
											_other = set()
											for _mid, _mtitle in (_bulk_titles or {}).items():
												try:
													if int(_mid) == int(own_id) or int(_mid) in _same_ids: continue
												except (TypeError, ValueError): pass
												_other |= _ftok(_mtitle)
											_own = (_mine - _ftok(self.title) - _other) - {'part', 'parts', 'season', 'seasons', 'cour', 'cours',
												'first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth', 'final',
												'from', 'with', 'into', 'that', 'this', 'over', 'your', 'their', 'what', 'when', 'after', 'before'}
											_own = set(w for w in _own if not w.isdigit())
											if _own: self.data['own_cour_tokens'] = sorted(_own)
										except Exception: pass
										# LOCAL PATCH 2026-10-01: each cour's identity markers ('act II', 'Second Season') against its
										# siblings, for the providers that search by title (magneto anime_utils.cour_marker_plan)
										try:
											from magneto.modules.anime_utils import cour_marker_plan
											_sibs = [t for _mid, t in (_bulk_titles or {}).items() if t and str(_mid) != str(own_id)]
											_plan = cour_marker_plan(mt, _sibs) if mt else None
											if _plan: self.data['cour_plan'] = _plan
										except Exception: pass
									except Exception: pass
							except Exception: pass
						else:
							# LOCAL PATCH 2026-08-27: shows Fribb has no row for AT ALL -- Naruto, Naruto
							# Shippuden, Hunter x Hunter and 13 others in this library. They get no kitsu_id
							# and no cour_episode, so the Kitsu paths in torrentio and comet never engage and
							# they fall back to title searching, the very thing this work exists to avoid.
							#
							# ani.zip answers a themoviedb_id lookup for them and hands back the Kitsu id. The
							# number to pair it with is the series-absolute one, already computed above.
							# anizip_whole_run_ids only answers when its episode count matches TMDb's total
							# aired count -- an absolute number against a single-cour entry addresses a
							# completely different episode, so that guard is the whole safety argument.
							#
							# cour_episode is deliberately set to the absolute number. For a whole-run entry
							# the cour IS the whole show, so the two are the same value and both providers
							# engage unchanged. cour_season is left unset so cour_match() skips its strict
							# season test, which is correct for releases carrying no season marker.
							try:
								_abs = self.data.get('absolute_episode')
								if _abs:
									from caches.anizip_mappings import anizip_whole_run_ids
									_run = anizip_whole_run_ids(self.tmdb_id, self.meta.get('total_aired_eps'))
									# LOCAL PATCH 2026-10-04: an episode past the entry's own count is not in it. The count check
									# above allows 5 episodes of slack, so the day a new season starts the FIRST season's entry
									# passes as the whole run: Aoashi S1 is 24 episodes, TMDb had aired 25 with S2E1, and the scrape
									# got S1's AniDB 16358 + Kitsu 44629 for 'episode 25', which does not exist -- animetosho had no
									# eid and the new-season lookup below never ran, a Kitsu id being set. Naruto 220/220 unaffected.
									if _run.get('kitsu') and int(_abs) > int(_run.get('count') or 0):
										kodi_utils.logger('scrape.new_season', 'tmdb %s: absolute %s is past the %s episodes of ani.zip\'s whole-run entry '
											'(AniDB %s) -- not the whole run' % (self.tmdb_id, _abs, _run.get('count'), _run.get('aid')))
										_run = {}
									if _run.get('kitsu'):
										self.data['kitsu_id'] = int(_run['kitsu'])
										self.data['cour_episode'] = int(_abs)
										for _k, _f in (('mal', 'mal_id'), ('anilist', 'anilist_id'), ('aid', 'anidb_aid')):
											if _run.get(_k): self.data[_f] = int(_run[_k])
										# LOCAL PATCH 2026-09-23: say so explicitly. animetosho's sources() then requires a
										# single-file row's NAME to state this absolute episode, because a whole-run eid
										# index carries recap/arc-relative releases under the same aid (see whole_run_episode
										# in magneto's anime_utils). Inferring it from cour_episode == absolute_episode would
										# also work today, but would break silently the first time that equality changes.
										self.data['whole_run'] = True
										# LOCAL PATCH 2026-09-23: the EID as well, which this branch never asked for.
										#
										# Without it animetosho logs 'sources SKIPPED, no anidb_eid' and can only offer packs,
										# and a pack cannot carry a CURRENT episode because no batch exists yet. One Piece
										# 1179 scraped to a single result for exactly that reason.
										#
										# The eid is available, just not where the cour path looks. anizip_episode_ids tries
										# ('eps', cour_episode) then ('abs', absolute_episode); with no cour mapping the first
										# is skipped and only the `abs` table is read -- and ani.zip fills
										# absoluteEpisodeNumber for 22 of One Piece's 1184 episodes against 1184 `eps` keys.
										# Passing the absolute as cour_episode reads the table that is actually populated.
										#
										# WHICH FIELD IS TMDb's NUMBER was checked against TMDb itself, because the two
										# disagree and anizip_episode_ids' docstring warns about guessing between them. The
										# KEY is TMDb's; absoluteEpisodeNumber is TVDB's and is not:
										#     key 10 -> 'The Weirdest Guy Ever! Jango the Hypnotist!'  = TMDb S1E10
										#     key 22 -> 'The Strongest Pirate Fleet! Commodore Don Krieg!' = TMDb S1E22
										#     key 10's absoluteEpisodeNumber is 18, which is a different episode entirely
										# Verified across the season boundary too -- keys 61, 62 and 63 are TMDb S1E61, S2E62
										# and S2E63. So the key is the series-absolute number this branch already computes.
										#
										# Safe for the same reason as the rest of this branch: anizip_whole_run_ids answers
										# only when its episode count matches TMDb's total aired count, so the entry covers
										# the whole series. Against a single-cour entry an absolute number would address a
										# different episode, which is why this sits inside that guard rather than beside it.
										#
										# What this does NOT fix is the quality of AnimeTosho's own file matching. Measured:
										# eid 315480 (ep 1179) returns 16 correct weekly releases, eid 440 (ep 1) returns 69
										# rows, eid 3860 (ep 22) returns none at all, and eid 977 (ep 10) returns Fish-Man
										# Island episode 10 -- a wrong match upstream. This provider trusts the index by
										# design, which is right until the index is wrong; that is a separate problem and is
										# not a reason to withhold the eid, since without one the provider returns nothing.
										try:
											from caches.anizip_mappings import anizip_episode_ids
											_eids = anizip_episode_ids(_run.get('anilist'), _abs,
														anidb_id=_run.get('aid')) or {}
											if _eids.get('eid'): self.data['anidb_eid'] = int(_eids['eid'])
										except Exception: pass
							except Exception: pass
							# LOCAL PATCH 2026-10-04: neither Fribb nor a whole-run entry -- a season Fribb has not mapped yet
							if not self.data.get('kitsu_id'):
								try: self._new_season_ids(_raw_s, _raw_e)
								except Exception as e: kodi_utils.logger('scrape.new_season', 'tmdb %s S%sE%s: failed: %r' % (self.tmdb_id, _raw_s, _raw_e, e))
						_pm.append(('ids', time.perf_counter()))
						kodi_utils.logger('scrape.prep', 'tmdb %s S%sE%s: %s, total %dms' % (self.tmdb_id, _raw_s, _raw_e, ', '.join('%s %dms' % (_pm[i][0],
							(_pm[i][1] - _pm[i - 1][1]) * 1000) for i in range(1, len(_pm))), (_pm[-1][1] - _t_setup) * 1000))
				except Exception: pass
		except: return []
		if get_setting('deadlight.scrape.diag_timing', 'false') == 'true':
			kodi_utils.logger('scrape.timing', 'setup external ids and data: %dms' % int((time.perf_counter() - _t_setup) * 1000))
		# LOCAL PATCH 2026-10-06: modules/scrape_prewarm stops here -- the id lookups above have filled their caches, no provider runs
		if getattr(self, 'warm_only', False): return self.data
		return self.get_sources()

	def _prefetch_anime_ids(self, cour_info, season, episode):
		"""LOCAL PATCH 2026-10-09: start every network lookup the anime id block below may make, all at once, and wait for
		them. The block itself is unchanged and reads each answer from the cache its function already keeps.

		It used to make them one after another, each waiting on the last, before any provider could start: JoJo S5E24 was
		AniList count -> ani.zip -> AniList titles (3.0 s in the harness, 5.4 s in Kodi beside the widgets), S6E4 was AniList
		count -> ani.zip whole run -> 2 AniList season searches -> ani.zip (3.0 s / 4.1 s, and ~9 s in the scrape of 16:13).
		The Fribb row is local, so which entries to ask about is known up front. The whole-run and new-season fallbacks are
		asked for only when Fribb has no cour, or once the entry's count says the episode is past it (Steel Ball Run S6E4
		sits on the 1-episode 1st STAGE entry) -- that test runs on its own thread, so it overlaps the other lookups without
		adding a request the serial code would not make. Guessing them up front doubled the AniList requests per scrape."""
		import threading
		from apis.anilist_api import anilist_episode_count, anilist_romaji_by_ids, anilist_romaji_bulk, anilist_romaji_for_mal, \
			anilist_entry_for_tmdb_episode
		from caches.anizip_mappings import anizip_episode_ids, anizip_whole_run_ids
		from caches import fribb_mappings as _fribb
		def _run(job):
			try: job()
			except Exception: pass

		jobs = []
		al = (cour_info or {}).get('anilist')
		cep = int((cour_info or {}).get('cour_ep') or 0)

		def _new_season():
			got = anilist_entry_for_tmdb_episode(self.meta, season, episode) or {}
			if got.get('anilist'): anizip_episode_ids(got['anilist'], cour_episode=got['episode'])

		def _fallbacks():   # the whole-run and new-season lookups side by side (the block asks for them in that order)
			t = threading.Thread(target=_run, args=(_new_season,))
			t.start()
			if self.data.get('absolute_episode'): _run(lambda: anizip_whole_run_ids(self.tmdb_id, self.meta.get('total_aired_eps')))
			t.join(20)

		def _count_then_fallbacks():
			n = anilist_episode_count(al)
			if not n or cep <= int(n): return
			rep = _fribb.find_cour_by_tmdb_coords(self.tmdb_id, season, episode, allow_repair=True) or {}
			if rep.get('anilist') and rep['anilist'] != al: anilist_episode_count(rep['anilist'])
			_fallbacks()

		if cour_info:
			if al and cep > 1: jobs.append(_count_then_fallbacks)
			jobs.append(lambda: anizip_episode_ids(al, cour_info.get('cour_ep'), self.data.get('absolute_episode'), cour_info.get('anidb')))
			if al:
				siblings = [r.get('anilist_id') for r in _fribb.tmdb_tv_to_fribb_rows(self.tmdb_id) if r.get('anilist_id')]
				jobs.append(lambda: anilist_romaji_by_ids(siblings + [al]))
			elif cour_info.get('mal'):   # a cour with no AniList id is named by MAL id (Stone Ocean's part 3, S5E38)
				mal = cour_info['mal']
				mal_siblings = [r.get('mal_id') for r in _fribb.tmdb_tv_to_fribb_rows(self.tmdb_id) if r.get('mal_id')]
				def _mal_titles():
					if len(mal_siblings) > 1: anilist_romaji_bulk(mal_siblings)
					anilist_romaji_for_mal(mal)
				jobs.append(_mal_titles)
		else: jobs.append(_fallbacks)
		if len(jobs) < 2: return
		threads = [threading.Thread(target=_run, args=(job,)) for job in jobs]
		for t in threads: t.start()
		for t in threads: t.join(20)

	def _new_season_ids(self, season, episode):
		"""LOCAL PATCH 2026-10-04: the anime ids for an episode of a season Fribb has not mapped yet, from AniList (the entry
		that starts this TMDb season, apis.anilist_api.anilist_for_tmdb_season) and ani.zip (that entry's AniDB, Kitsu and
		MAL ids and this episode's AniDB eid). Fills what the Fribb branch would: anilist_id (seadex), anidb_aid/anidb_eid
		(animetosho), kitsu_id + cour_episode (torrentio's and comet's Kitsu paths), mal_id.

		Black Clover's 2026 Season 2 is TMDb 73223 S2 but had no Fribb row the day it aired (nor did Aoashi's, TMDb 126437 S2):
		no ids, so the anime providers found nothing and, before the anime list was enforced without ids, comet's IMDb 'S02E01'
		brought the 2017 run's episode 52. TMDb's episode number is used as the entry's own because the match is by the date
		the season STARTS -- episode N of the season is episode N of the entry, as long as the entry is that long; a TMDb season
		that runs past it (two cours as one TMDb season) is another entry, so then nothing is set. cour_season is left unset,
		as in the whole-run branch, so name matching makes no strict season test. Not used: SIMKL, which still files this
		season under the TMDb id TMDb deleted (336735), and the Anime-Lists XML, a 3.5 MB download (the user's call)."""
		from apis.anilist_api import anilist_entry_for_tmdb_episode
		got = anilist_entry_for_tmdb_episode(self.meta, season, episode)
		if got.get('exhausted'):
			gone = got['exhausted']
			return kodi_utils.logger('scrape.new_season', 'tmdb %s S%sE%s -> AniList %s (from %s): episode past its %s, and no next entry to '
				'try -- no ids' % (self.tmdb_id, season, episode, gone.get('anilist'), gone.get('start'), gone.get('episodes')))
		if not got.get('anilist'): return
		found, offset, episode = got, got['offset'], got['episode']
		where = 'tmdb %s S%sE%s -> AniList %s (from %s)' % (self.tmdb_id, season, int(episode) + offset, found['anilist'], found.get('start'))
		if offset: where += ', ep %s there' % episode
		from caches.anizip_mappings import anizip_episode_ids
		ids = anizip_episode_ids(found['anilist'], cour_episode=episode) or {}
		self.data['anilist_id'] = int(found['anilist'])
		for key, field in (('mal', 'mal_id'), ('kitsu', 'kitsu_id'), ('aid', 'anidb_aid'), ('eid', 'anidb_eid')):
			value = ids.get(key) or (found.get('mal') if key == 'mal' else None)
			if value: self.data[field] = int(value)
		if self.data.get('kitsu_id'): self.data['cour_episode'] = episode
		kodi_utils.logger('scrape.new_season', '%s: kitsu %s ep %s, anidb %s eid %s' % (where, self.data.get('kitsu_id'),
			self.data.get('cour_episode'), self.data.get('anidb_aid'), self.data.get('anidb_eid')))

	def get_sources(self):
		# LOCAL PATCH 2026-09-26: 50 ms polls with the sleep at the TOP of the loop, instead of a fixed
		# 200 ms lead-in and 100 ms polls at the bottom. A fully cached scrape finishes in ~30 ms of CPU
		# but waited 200-300 ms here for its first check. The sleep has to stay outside the try: the
		# old lead-in also covered update_scraper raising before the progress window is up, and with
		# the sleep inside the try an exception would skip it and spin the loop.
		def _scraperDialog():
			kodi_utils.hide_busy_dialog()
			start_time = time.time()
			while not self.progress_dialog.iscanceled() and not self.monitor.abortRequested():
				kodi_utils.sleep(50)
				try:
					alive_threads = [x.getName() for x in self.threads if x.is_alive()]
					if self.internal_activated or self.internal_prescraped: alive_threads.extend(self.process_internal_results())
					percent = (max((time.time() - start_time), 0)/float(self.timeout))*100
					# LOCAL PATCH 2026-09-27: the bar shows providers DONE; the timer keeps driving the exit below
					rows = self._provider_rows()
					done = len([r for r in rows if r[2] != 'running'])
					left = max(0, int(round(self.timeout - (time.time() - start_time))))
					shown = percent if len(rows) <= 1 else (100.0 * done / len(rows) if rows else 0)
					self.progress_dialog.update_scraper(self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total, '', shown,
						providers=rows, phase='Searching Providers', detail='%d of %d done  ·  %ds left' % (done, len(rows), left) if rows else '%ds left' % left,
						time_pct=None if len(rows) <= 1 else percent, late=left <= 3, hidden=self.counter.line())
					if self.threads_completed:
						len_alive_threads = len(alive_threads)
						if len_alive_threads == 0 or percent >= 100: break
						# LOCAL PATCH 2026-09-05: stop waiting on stragglers once the result
						# set is already good. See the note in _load_scrape_extras -- this
						# DISCARDS whatever the remaining providers would have returned, so
						# all three gates have to hold. Off when the setting is 0.
						if self._early_exit_sources and percent >= 50:
							_have = len(self.sources)
							if _have >= self._early_exit_sources:
								kodi_utils.logger('scrape.early_exit', '%d sources at %d%% of budget, dropping: %s'
													% (_have, int(percent), ', '.join(alive_threads) or 'none'))
								break
					elif percent >= 100: break
				except: pass
			try:   # LOCAL PATCH 2026-09-27: whoever is still running when the wait ends has timed out
				rows = self._provider_rows(final=True)
				if any(r[2] == 'timeout' for r in rows):
					self.progress_dialog.update_scraper(self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total, '', 100,
						providers=rows, time_pct=100, late=True, hidden=self.counter.line())
			except: pass
			return
		# LOCAL PATCH 2026-09-26: poll at 200 ms and judge once every provider thread has been LAUNCHED
		# (threads_completed, set by process_*_threads), instead of a fixed 1.5 s sleep then 1 s polls.
		# The 1.5 s only existed because self.threads fills in gradually -- judged at t=0 it is empty and
		# '<= 5 alive' passes at once. That floor cost at least 2.5 s on every next-episode prescrape,
		# even when every provider answered from cache.
		# Corrected the same day: upstream's fixed sleeps were ALSO the whole wait budget whenever the
		# provider set itself has <= 5 members (this install: 5 general, 1 anime), because '<= 5 alive'
		# is then true from the first poll and a cold scrape returned nothing but cache hits. So: exit
		# at once only when every thread has finished (the cached fast path), and apply the straggler
		# rules only after the 2.5 s upstream floor, counted from threads_completed.
		def _background():
			end_time = time.time() + self.timeout + 1.5
			floor = None
			while time.time() < end_time:
				kodi_utils.sleep(200)
				if not self.threads_completed: continue
				if floor is None: floor = time.time() + 2.5
				len_alive_threads = len([x for x in self.threads if x.is_alive()])
				if len_alive_threads == 0: return
				if time.time() < floor: continue
				if len_alive_threads <= 5: return
				if len(self.sources) >= 100 * len_alive_threads: return
		self.threads = []
		self.threads_append = self.threads.append
		self._prefetch_threads, self._prefetch_seen, self._prefetch_lock = [], set(), Lock()
		self._prefetch_pending, self._prefetch_running = [], False
		if self.media_type == 'movie': Thread(target=self.process_movie_threads).start()
		else:
			self.source_dict = [i for i in self.source_dict if i[1].hasEpisodes]
			self.season_packs, self.show_packs = source_utils.pack_enable_check(self.meta, self.season, self.episode)
			if self.season_packs:
				self.source_dict = [(i[0], i[1], '') for i in self.source_dict]
				pack_capable = [i for i in self.source_dict if i[1].pack_capable]
				if pack_capable:
					self.source_dict.extend([(i[0], i[1], 'Season') for i in pack_capable])
					if self.show_packs: self.source_dict.extend([(i[0], i[1], 'Show') for i in pack_capable])
					random.shuffle(self.source_dict)
					self.source_dict.sort(key=lambda k: k[2])
			Thread(target=self.process_episode_threads).start()
		if self.background: _background()
		else: _scraperDialog()
		current_results = list(self.sources)
		if current_results: return self.process_results(current_results)
		return []

	def _load_scrape_extras(self):
		# LOCAL PATCH 2026-07-10 (B+C): cache the blocklist + DIAG toggle once per scrape
		# instead of hitting get_setting per-provider. Called from both dispatch entry
		# points so the two threading paths share the same policy per scrape.
		if getattr(self, '_scrape_extras_loaded', False): return
		raw = (get_setting('deadlight.scrape.provider_blocklist', '') or '').strip()
		self._blocked_providers = {p.strip().lower() for p in raw.split(',') if p.strip()}
		self._diag_timing = get_setting('deadlight.scrape.diag_timing', 'false') == 'true'
		# LOCAL PATCH 2026-07-23: anime-only providers — skipped entirely when the
		# current content isn't anime. Saves ~2-3s per scrape by dropping the parallel
		# HTTP queries to Nyaa (which returns nothing for Western TV/movies anyway).
		anime_only_raw = (get_setting('deadlight.scrape.anime_only_providers', 'nyaa,animetosho,seadex,nekobt') or '').strip()
		self._anime_only_providers = {p.strip().lower() for p in anime_only_raw.split(',') if p.strip()}
		self._is_anime = self._detect_anime_content()
		# LOCAL PATCH 2026-09-22: the mirror image of anime_only_providers above. That one keeps
		# the anime-aware scrapers OFF non-anime; nothing kept the general-purpose ones off
		# ANIME, so every provider enabled for western content also ran on every anime scrape.
		# magneto's toggles are global -- 26 of them -- so there was no way to have, say,
		# aiostreams for films without it answering anime queries too.
		#
		# A WHITELIST, and it can only ever SKIP: a provider whose magneto toggle is off is
		# never dispatched in the first place, so listing it here does not enable it. nyaa in
		# particular needs provider.nyaa=true in magneto to be dispatched at all.
		# SUPERSEDED 2026-10-05: on anime modules/sources.external_sources loads THIS list, switch or not, so a tick here
		# is the provider's anime switch and magneto.provider.<id> only covers Movies & TV.
		#
		# EXTERNAL providers only. DeadLight's own internal scrapers (easynews, the four debrid
		# clouds, folders, aiostreams, http_streams) are dispatched by modules.sources through
		# remove_scrapers, which prescrape logic also writes to, so gating them there is a
		# separate job. http_streams is internal and individually toggled, which is why it is
		# not in the default below despite belonging to the intended anime set.
		#
		# Empty disables the restriction entirely.
		anime_raw = (get_setting('deadlight.scrape.anime_providers', 'animetosho,seadex,nyaa,nekobt') or '').strip()
		self._anime_providers = {p.strip().lower() for p in anime_raw.split(',') if p.strip()}
		# LOCAL PATCH 2026-09-23 -- SUPERSEDED 2026-10-04: the list now applies without ids too (see
		# _is_not_for_anime_skipped); _has_anime_keys below is kept for the diag line only. The reasoning was:
		# the whitelist above may only apply when the whitelisted providers have something to key on.
		#
		# animetosho queries by anidb_eid/anidb_aid and seadex by anilist_id -- those ids are
		# their ONLY keys, and both log a skip and return nothing without them. So for a scrape
		# that carries no anime id, restricting to the whitelist does not narrow the result set,
		# it empties it: the id-keyed providers cannot answer and the title-searching ones
		# (torrentio, mediafusion, meteor, torrentsdb, aiostreams) were skipped to make room for
		# them. Zero sources -- and an empty scrape result is then cached for an hour.
		#
		# Two ways a scrape arrives here with no ids, both of them normal:
		#   1. A NEW or UNAIRED anime show has no Fribb row yet, so find_cour_by_tmdb_coords
		#      returns nothing. Cyberpunk: Edgerunners 2 (tmdb 326788, airs 2026-10-20) carries
		#      the anime keyword with no Fribb rows, no imdb_id and no tvdb_id.
		#   2. EVERY anime MOVIE. The id enrichment in results() sits inside the TV branch; a
		#      movie's self.data is imdb/title/aliases/year and nothing ever adds an anime id.
		#      animetosho and seadex are hasMovies=False besides, so the whitelist was reducing
		#      every anime film to three providers that structurally cannot serve it.
		#
		# ANY id counts, deliberately. Mapping each whitelisted provider to the key it needs
		# would cover slightly more ground (a show holding only a kitsu_id), but it means a
		# second copy of magneto's provider internals living here, and a copy of a rule this
		# subtle drifts from the original -- the same reason episode_candidates is published
		# once rather than re-derived per provider.
		_d = getattr(self, 'data', None) or {}
		self._has_anime_keys = any(_d.get(_k) for _k in ('anidb_aid', 'anidb_eid', 'anilist_id'))
		if self._anime_only_providers or self._anime_providers:
			kodi_utils.logger('scrape.anime_gate', 'is_anime=%s anime_keys=%s anime_only=%s anime_providers=%s'
				% (self._is_anime, self._has_anime_keys, sorted(self._anime_only_providers), sorted(self._anime_providers) or '-'))
		# LOCAL PATCH 2026-09-05: early exit for the FOREGROUND scrape.
		#
		# The dialog loop waited for the slowest provider every time. Measured here: comet
		# returned 111 sources in 770 ms while torrentio took 3070 ms to add 18, so the
		# scrape sat idle for 2.3 s for a 16% larger result set. The BACKGROUND path has had
		# an early exit since forever (_background below); the foreground never did.
		#
		# THIS IS A COMPLETENESS TRADE-OFF, NOT A FREE WIN -- the straggler's sources are
		# lost, and they may be the good ones. So it is gated three ways and every gate must
		# hold: enough sources already in hand, at least half the budget spent (so a fast
		# provider is never cut off), and the dispatcher finished handing out work.
		# scrape.early_exit_sources = 0 disables it entirely.
		try: self._early_exit_sources = int(get_setting('deadlight.scrape.early_exit_sources', '0') or 0)
		except (TypeError, ValueError): self._early_exit_sources = 0
		self._scrape_extras_loaded = True

	def _detect_anime_content(self):
		# LOCAL PATCH 2026-10-05: the test moved to source_utils.is_anime_meta, shared with modules/sources.external_sources
		# (which loads the anime list instead of the switched-on providers) and the Options menu's Anime Scrapers.
		return is_anime_meta(self.meta)

	def _is_blocked(self, provider):
		if not self._blocked_providers: return False
		if provider.lower() in self._blocked_providers:
			kodi_utils.logger('scrape.blocklist', 'skip %s (in blocklist)' % provider)
			return True
		return False

	def _is_not_for_anime_skipped(self, provider):
		# Skip a provider that may not run on anime when the content IS anime.
		if not self._is_anime: return False
		# LOCAL PATCH 2026-10-04: on anime only ANIME_PROVIDERS ever run -- the ticked ones, or all six on 'Rescrape With All
		# Scrapers' (which also loads the switched-off ones, magneto_sources(ret_all=True)). The list applies with or without
		# an anime id: from 2026-09-23 to 10-04 a scrape with no id let EVERY provider run, since the id-keyed providers had
		# nothing to search by -- and the general ones brought the old numbering's same-named episodes: Black Clover's new
		# Season 2 (no Fribb row yet) got comet's IMDb 'S02E01' Blu-ray, which is the 2017 run's episode 52. An unmapped anime
		# now shows only what these find, possibly nothing; _has_anime_keys is still logged by _load_scrape_extras. An empty
		# list no longer means "no restriction": the selector cannot save one.
		# LOCAL PATCH 2026-10-05: 'all' is every anime provider but source_utils.ANIME_ALL_SKIPPED (Nyaa), from the menu too
		allowed = set(anime_providers_to_run(self.all_scrapers)) if self.all_scrapers else self._anime_providers & set(ANIME_PROVIDERS)
		if provider.lower() in allowed: return False
		kodi_utils.logger('scrape.anime_gate', 'skip %s (%s)' % (provider,
			'not an anime provider' if provider.lower() not in ANIME_PROVIDERS else 'not on the anime provider list'))
		return True

	def _is_anime_only_skipped(self, provider):
		# Skip providers marked anime-only when the current content isn't anime.
		if not self._anime_only_providers: return False
		if provider.lower() in self._anime_only_providers and not self._is_anime:
			kodi_utils.logger('scrape.anime_gate', 'skip %s (anime-only, content is not anime)' % provider)
			return True
		return False

	def process_movie_threads(self):
		self._load_scrape_extras()
		for i in self.source_dict:
			provider, module = i[0], i[1]
			if (self._is_blocked(provider) or self._is_anime_only_skipped(provider)
				or self._is_not_for_anime_skipped(provider)):
				try: self.remainingProviders.remove(provider)
				except: pass
				continue
			threaded_object = Thread(target=self.get_movie_source, args=(provider, module), name=provider)
			threaded_object.start()
			self.threads_append(threaded_object)
		self.threads_completed = True

	def process_episode_threads(self):
		self._load_scrape_extras()
		for i in self.source_dict:
			provider, module = i[0], i[1]
			try: pack_arg = i[2]
			except: pack_arg = ''
			if pack_arg: provider_display = '%s (%s)' % (i[0], i[2])
			else: provider_display = provider
			if (self._is_blocked(provider) or self._is_anime_only_skipped(provider)
				or self._is_not_for_anime_skipped(provider)):
				try: self.remainingProviders.remove(provider_display)
				except: pass
				continue
			threaded_object = Thread(target=self.get_episode_source, args=(provider, module, pack_arg), name=provider_display)
			threaded_object.start()
			self.threads_append(threaded_object)
		self.threads_completed = True

	def _has_imdb(self):
		imdb = str((getattr(self, 'data', None) or {}).get('imdb') or '').strip().lower()
		return imdb.startswith('tt') and imdb.strip('t0') != ''

	def _scrape(self, provider, scraper, method, *args, **kwargs):
		"""LOCAL PATCH 2026-09-27: run one provider call and note whether an empty answer was an OUTAGE. Two signals:
		the provider's own request_failed (animetosho / seadex / nekobt set it), or -- for every provider that fetches
		through magneto's client -- at least one request failed and none answered in this thread. A provider that
		answered with nothing stays 'none'. The episode and pack threads of one provider share the key; the row still
		shows its count when any of them found something (_provider_rows checks the count first)."""
		try:
			from magneto.modules import client as _client
			_client.reset_status()
		except Exception: _client = None
		sources = method(*args, **kwargs)
		if not sources:
			failed = getattr(scraper, 'request_failed', False)
			if not failed and _client is not None:
				ok, bad = _client.status()
				failed = bad > 0 and ok == 0
			# LOCAL PATCH 2026-09-28: with NO IMDb id a failed request is not an outage. Seven of the bundled providers
			# key their query on it (bitmagnet, comet, mediafusion, meteor, torrentio, torrentsdb, torz); given '' they
			# ask for '/stream/series/:1:1.json', the server rejects it, and the row turned red 'down' although the
			# server was fine -- Monster: The Lizzie Borden Story (tmdb 299939, no imdb): mediafusion, torz and meteor
			# 'down' on every scrape. Any provider, no list: it is shown as no results and cached like one.
			if failed and not self._has_imdb():
				kodi_utils.logger('scrape.provider_down', '%s: request failed, but there is no IMDb id to search by -- shown as no results, not down' % provider)
				failed = False
			if failed:
				self.provider_failed.add(provider)
				kodi_utils.logger('scrape.provider_down', '%s: no answer (request failed), empty result not cached' % provider)
		return sources

	def _prefetch_debrid(self, sources):
		"""LOCAL PATCH 2026-10-02: check this provider's hashes with the debrid service NOW, while slower providers are still
		searching, instead of all of them after the last one. The checks write their verdicts to the local debrid cache, and
		process_results' own check sends only hashes that cache does not know -- so it is left with the stragglers' hashes.
		Measured before (2026-10-02, 7 movie scrapes): 0.6-1.8 s between the last provider finishing and the results.
		Each hash is handed out ONCE: debrid_data is unique (hash, debrid) with a plain INSERT, so a hash two threads both
		wrote would fail the whole batch, silently. Real-Debrid and AllDebrid are left to the final check -- theirs is gated on
		external_cache_check and takes more arguments."""
		# 2026-10-02, second version: ONE worker, one call in flight. The first version started a check per provider thread --
		# up to 9 TorBox calls at once on an episode (episode + season pack per provider) -- and on 09:04:22 one of them hung
		# for the full 10 s cap. The worker sends whatever is waiting as one batch; hashes arriving meanwhile go in the next.
		try:
			hashes = set(i['hash'] for i in sources or [] if len(i.get('hash') or '') == 40)
			if not hashes: return
			runners = [self.debrid_runners[item][1] for item in self.active_debrid if item not in ('Real-Debrid', 'AllDebrid')]
			if not runners: return
			with self._prefetch_lock:
				hashes -= self._prefetch_seen
				if not hashes: return
				self._prefetch_seen |= hashes
				self._prefetch_pending.extend(hashes)
				if self._prefetch_running: return
				self._prefetch_running = True
			def _worker():
				while True:
					with self._prefetch_lock:
						batch, self._prefetch_pending[:] = self._prefetch_pending[:], []
						if not batch:
							self._prefetch_running = False
							return
					for function in runners:
						try: function(batch, query_local_cache(batch))
						except Exception: pass
			_thread = Thread(target=_worker, name='debrid prefetch')
			self._prefetch_threads.append(_thread)
			_thread.start()
		except Exception: pass

	def get_movie_source(self, provider, module):
		if self._diag_timing: _t0 = time.perf_counter()
		sources = None if self.filterless else external_cache.get(provider, self.media_type, self.tmdb_id, self.title, self.year, '', '')
		_from_cache = sources is not None
		if sources == None:
			scraper = module()
			sources = self.process_sources(provider, self._scrape(provider, scraper, scraper.sources, self.data, self.host_dict))
			if not sources: expiry_hours = 1
			else: expiry_hours = self.single_expiry
			# LOCAL PATCH 2026-09-26: see get_episode_source -- a failed request is not cached.
			if (sources or provider not in self.provider_failed) and not self.filterless:
				external_cache.set(provider, self.media_type, self.tmdb_id, self.title, self.year, '', '', sources, expiry_hours)
		sources = self._drop_not_episodes(provider, sources)   # LOCAL PATCH 2026-10-06
		if sources:
			if not self.background: self.process_quality_count(sources)
			self.sources.extend(sources)
		self.provider_counts[provider] = self.provider_counts.get(provider, 0) + len(sources or [])
		self._prefetch_debrid(sources)
		if self._diag_timing:
			# LOCAL PATCH 2026-10-02: '(cache)' -- a cache hit is not a fast provider
			kodi_utils.logger('scrape.timing', '%s: %dms (%d sources)%s' % (provider, int((time.perf_counter() - _t0) * 1000), len(sources) if sources else 0,
				' (cache)' if _from_cache else ''))
		del module

	def get_episode_source(self, provider, module, pack):
		if self._diag_timing: _t0 = time.perf_counter()
		if pack in ('Season', 'Show'):
			if pack == 'Show': s_check = ''
			else: s_check = self.season
			e_check = ''
			# LOCAL PATCH 2026-09-24: an ANIME pack result depends on the episode asked for, so it
			# cannot be shared across the season. The anime providers filter packs BEFORE this
			# cache sees them -- animetosho's range reject against cour/season/absolute numbers,
			# and its foreign-cour reject, whose token list differs per cour. TMDb Bleach S2 holds
			# all four TYBW cours under one key: scraping S2E1 first cached a pack set with every
			# Ketsubetsu-tan/Soukoku-tan batch rejected, and S2E14 then read that row for 30 days.
			# Shippuden's S5 row was likewise filtered for whichever S5 episode came first.
			# The P prefix keeps a pack row from colliding with the single-episode row.
			if getattr(self, "_is_anime", False): e_check = 'P%s' % self.episode
		else: s_check, e_check = self.season, self.episode
		sources = None if self.filterless else external_cache.get(provider, self.media_type, self.tmdb_id, self.title, self.year, s_check, e_check)
		_from_cache = sources is not None
		if sources == None:
			scraper = module()
			if pack == 'Show':
				expiry_hours = self.show_expiry
				sources = self._scrape(provider, scraper, scraper.sources_packs, self.data, self.host_dict, search_series=True, total_seasons=self.total_seasons)
			elif pack == 'Season':
				expiry_hours = self.season_expiry
				sources = self._scrape(provider, scraper, scraper.sources_packs, self.data, self.host_dict)
			else:
				expiry_hours = self.single_expiry
				sources = self._scrape(provider, scraper, scraper.sources, self.data, self.host_dict)
			sources = self.process_sources(provider, sources)
			if not sources: expiry_hours = 1
			# LOCAL PATCH 2026-09-26: a provider that sets request_failed (magneto's nekobt, on a
			# timeout / 5xx / error payload) returned [] because it FAILED, not because the tracker
			# has nothing -- caching that hid the episode for an hour after one stall. Providers
			# without the attribute are unaffected.
			if (sources or provider not in self.provider_failed) and not self.filterless:
				external_cache.set(provider, self.media_type, self.tmdb_id, self.title, self.year, s_check, e_check, sources, expiry_hours)
		sources = self._drop_not_episodes(provider, sources)   # LOCAL PATCH 2026-10-06
		if sources:
			if pack == 'Season': sources = [i for i in sources if not 'episode_start' in i or i['episode_start'] <= self.episode <= i['episode_end']]
			elif pack == 'Show': sources = [i for i in sources if i['last_season'] >= self.season]
			if not self.background: self.process_quality_count(sources)
			self.sources.extend(sources)
		self.provider_counts[provider] = self.provider_counts.get(provider, 0) + len(sources or [])
		self._prefetch_debrid(sources)
		if self._diag_timing:
			pack_tag = ('-%s' % pack) if pack else ''
			kodi_utils.logger('scrape.timing', '%s%s: %dms (%d sources)%s' % (provider, pack_tag, int((time.perf_counter() - _t0) * 1000), len(sources) if sources else 0,
				' (cache)' if _from_cache else ''))
		del module

	def process_results(self, results):
		# LOCAL PATCH 2026-10-02: a hash several providers list is MERGED, not dropped. Upstream kept the first
		# copy to arrive and threw the rest away -- 169 of 665 hashes (25 %) over four cached titles came from 2-4
		# providers, and the row named only one. The kept copy is the most informative (_info_score); every
		# provider that listed the hash goes on it as 'providers', kept one first, for 'COMET +2' and the filters.
		def _process_duplicates(all_results):
			unique_urls, groups, order = set(), {}, []
			for item in all_results:
				try:
					url = item['url'].lower()
					if url in unique_urls: continue
					unique_urls.add(url)
					_hash = item.get('hash')
					if _hash is None:
						order.append(item)
						continue
					if len(_hash) != 40: continue
					if _hash in groups: groups[_hash].append(item)
					else:
						groups[_hash] = [item]
						order.append(_hash)
				except: order.append(item)
			for entry in order:
				if not isinstance(entry, str):
					yield entry
					continue
				copies = groups[entry]
				if len(copies) == 1:
					yield copies[0]
					continue
				best = max(copies, key=_info_score)   # max keeps the FIRST of equal scores: arrival order breaks ties
				names = [best['provider']] + [c['provider'] for c in copies if c is not best]
				merged = dict(best, providers=list(dict.fromkeys(names)))
				# LOCAL PATCH 2026-10-03: the winner is picked for its tags, so it can be the copy that does not know the
				# torrent is a pack -- comet names a pack by the episode file inside it (live: 'Reacher.S02E01...mkv' in a
				# 113 GB torrent). Another provider's pack fields go onto it so playback still takes the pack path. The
				# size stays the winner's: a per-file size beats any copy's divided estimate.
				if 'package' not in merged:
					donor = next((c for c in copies if 'package' in c), None)
					if donor:
						for key in ('package', 'pack_episodes', 'episode_start', 'episode_end', 'first_season', 'last_season'):
							if key in donor: merged[key] = donor[key]
				yield merged
		# LOCAL PATCH 2026-09-22: a cached pack's REAL per-episode size.
		# A pack row shows total_size / num_files, and num_files counts subtitles, creditless
		# OP/ED and extras -- accurate at ~1.0x for a tidy pack but badly understated when a
		# release ships extras ('[JP-EN] Apothecary COMPLETE', 326 files, 61.10 GB, shown as
		# 0.19 GB: 13.6x low). The index genuinely cannot do better; it publishes num_files and
		# total_size and no per-file data at all. The debrid cache check does: TorBox returns a
		# real file listing for every CACHED hash, and that check already runs on every hash
		# before this window opens.
		#
		# The file is chosen with pick_episode_files, the same function all five debrid modules
		# route through, keyed on short_name exactly as TorBoxAPI.resolve_magnet keys it, and
		# fed self.data['episode_candidates'] -- so the size shown is the size of the file that
		# will actually play, and cannot drift from what the resolver later picks.
		#
		# Cached packs only. An uncached hash is absent from TorBox's reply, so it keeps the
		# estimate; a single-file row already shows its true size and is left alone.
		def _real_pack_sizes(provider, cached):
			"""({hash: real GB}, {hashes to drop}) for cached packs whose listing we hold."""
			out, drops = {}, set()
			if provider != 'TorBox' or self.media_type != 'episode' or not self.season: return out, drops
			try:
				listings = query_local_cache_files(list(cached), 'tb')
				if not listings: return out, drops
				extensions = tuple(source_utils.supported_video_extensions())
				candidates = self.data.get('episode_candidates') or None
				for i in results:
					_hash = i.get('hash')
					if _hash not in listings: continue
					# LOCAL PATCH 2026-09-27: a torrent named like ONE episode can still be a pack. MediaFusion's
					# DMM/Zilean hashlist rows carry the torrent's first file as the title and its TOTAL size
					# (description and behaviorHints.videoSize alike): Reacher S02E01 showed
					# 'Reacher.S02E01...-PTHD.mkv' at 38.57GB. The listing tells: more than one video file means a
					# pack, and the file the matcher picks gives the real size. Such a row is never DROPPED here --
					# it was not offered as a pack, so a miss says nothing new.
					is_pack = 'package' in i
					try: _files = json.loads(listings[_hash])
					except Exception: continue
					usable = [{'filename': f['name'], 'size': f['size']} for f in _files
						if f.get('name') and f.get('size') and str(f['name']).lower().endswith(extensions)]
					if not usable: continue
					if not is_pack and len(usable) < 2: continue
					try: hits, _matched = source_utils.pick_episode_files(usable, self.season, self.episode, 'filename', candidates, self.title)
					except Exception: continue
					if hits:
						out[_hash] = float(hits[0]['size']) / 1073741824.0
						# LOCAL PATCH 2026-10-05: one FILE holding several episodes ('[anonymous] Mushoku Tensei S01E12-E17 (1080p
						# BD Remux).mkv', a disc remux, 37.05 GB) is shown per episode, like a pack: its size over the range it states
						try:
							_rng = _RE_FILE_RANGE.search(str(hits[0]['filename']))
							if _rng:
								_a, _b = int(_rng.group(1)), int(_rng.group(2))
								if _a < _b and _b - _a < 60: out[_hash] /= (_b - _a + 1)
						except Exception: pass
						continue
					if not is_pack: continue
					# LOCAL PATCH 2026-09-22: the pack does not hold this episode -- drop the row.
					#
					# _pack_excludes_episode can only read a range a NAME declares; a pack that says
					# nothing sails through, and the failure surfaces as playback that quietly does
					# nothing because the debrid file filter matches no file. The cache check now hands
					# us the real contents, so it can be settled before the row is ever offered.
					# Measured against the live debrid cache asking for Apothecary S01E20: 4 of 30
					# cached packs held nothing playable -- two Beatrice-Raws Vol 01-02 (1-12), a
					# 5-episode [Spoony] pack and a CRUCiBLE S01P01 (1-12).
					#
					# A MISS IS ONLY EVIDENCE IF THE MATCHER CAN READ THIS PACK. 'No file matched
					# episode 20' and 'this pack has no episode 20' are different claims, and the first
					# is also what an unreadable naming convention produces. So the row is dropped only
					# once the same matcher has found some OTHER episode in the same listing: then it
					# has shown it understands the convention and a miss really is absence. A pack it
					# cannot read is left alone, which is also what stops an absolute-numbered pack
					# (Naruto 193-220) being thrown away on a cour-relative probe.
					#
					# Runs only where the wanted episode already missed, and stops at the first episode
					# it does find, so the common path pays nothing.
					#
					# UNVERIFIED: this judges on the checkcached listing while resolve_magnet picks from
					# torrent_info after adding the magnet. They are expected to agree but could not be
					# compared -- the TorBox cloud was empty and confirming it would mean adding a
					# torrent. If they ever diverge, this drops a playable row.
					# LOCAL PATCH 2026-09-24: plus the numbers the listing itself writes, so a pack
					# numbered above 60 can prove it is readable too. Measured 2026-09-24: over every
					# episode of Shippuden and Bleach against the 17 real TorBox listings this flips,
					# 2909 (pack, episode) pairs that HOLD the episode stayed kept and 4384 that lack it
					# are now dropped; over 73 per-season-numbered anime with an absolute pack, all 1916
					# held episodes were hit by the (season, absolute) candidate before any probe ran.
					# Safe for the reason above: the probe only runs after the wanted episode missed.
					_readable = False
					# LOCAL PATCH 2026-09-24: the listing prepared ONCE for every probe below -- they all
					# pass candidates, so all match strict. See source_utils.prepare_episode_files.
					try: _prep = source_utils.prepare_episode_files(usable, 'filename', self.title, strict=True)
					except Exception: _prep = None
					# LOCAL PATCH 2026-09-26: the numbers the files actually write go FIRST, then the rest of
					# 1..60. Same set of probes and the answer is 'any hit', so the outcome cannot change --
					# only how soon a readable pack proves itself. In order, a pack holding 13-24 missed
					# twelve picks before its first hit; the scrape log showed these drops at 22-68 ms each
					# on Windows (13:41:05), and an order of magnitude more is plausible on the ARM box.
					_listed = source_utils.listing_episode_numbers(usable)
					_probes = _listed + [p for p in range(1, 61) if p not in _listed]
					for _probe in _probes:
						if _probe == self.episode: continue
						try: _h, _m = source_utils.pick_episode_files(usable, self.season, _probe, 'filename', [(int(self.season), _probe)], self.title, prepared=_prep)
						except Exception: break
						if _h:
							_readable = True
							break
					# LOCAL PATCH 2026-09-24: then the pairs the files name themselves -- see
					# source_utils.listing_episode_pairs. At most 5 picks, and only for a pack the probe above found
					# unreadable, so the measured ~27ms of a missing pack's probe loop barely moves.
					if not _readable:
						for _pair in source_utils.listing_episode_pairs(usable):
							if _pair == (int(self.season), int(self.episode)): continue
							try: _h, _m = source_utils.pick_episode_files(usable, _pair[0], _pair[1], 'filename', [_pair], self.title, prepared=_prep)
							except Exception: break
							if _h:
								_readable = True
								break
					if _readable:
						drops.add(_hash)
						kodi_utils.logger('scrape.pack_contents', 'drop %s (%d files, no episode %s)' % (_hash[:10], len(usable), self.episode))
			except Exception: pass
			return out, drops
		# LOCAL PATCH 2026-09-28: a cached torrent with NO video file in it is dropped. Heart of the Beast (2026),
		# still in cinemas: all six rows left after the quality filter were '...WEB-DL.DDP5.1.x265-FLUX' and
		# the like holding a lone '.exe' of about 1 GB, and each failed resolve_magnet's own extension test
		# one after another (09:28:41-48) with nothing in the log. The listing is the one the cache check
		# already fetched (list_files=true, kept in debridcache) -- no extra request -- and the test is
		# resolve_magnet's: short_name ends with a supported video extension. Only ZERO video files counts; a
		# stray .exe / .txt beside a real .mkv stays, since the resolver picks the video anyway. A hash with
		# no listing (uncached, or TorBox sent none) is left alone: absence of a listing is not evidence.
		def _no_video_hashes(provider, cached):
			drops = set()
			if provider != 'TorBox' or not cached: return drops
			try:
				listings = query_local_cache_files(list(cached), 'tb')
				if not listings: return drops
				extensions = tuple(source_utils.supported_video_extensions())
				for _hash, blob in listings.items():
					try: _names = [str(f.get('name') or '') for f in json.loads(blob)]
					except Exception: continue
					if not _names or any(n.lower().endswith(extensions) for n in _names): continue
					drops.add(_hash)
					kodi_utils.logger('fake filter', 'drop %s: no video file (%s)' % (_hash[:10], ', '.join(_names[:3])))
			except Exception: pass
			return drops
		def _process_cache_check(provider, function):
			if provider in ('Real-Debrid', 'AllDebrid'):
				if self.external_cache_check: cached = function(hash_list, cached_hashes, self.data, self.active_debrid)
				else: cached = hash_list
			else: cached = function(hash_list, cached_hashes)
			if self._diag_timing: _t_pack = time.perf_counter()
			_real, _drop = _real_pack_sizes(provider, cached)
			_fake = _no_video_hashes(provider, cached)
			if self._diag_timing:
				kodi_utils.logger('scrape.timing', '%s pack + fake tests: %dms (%d cached, %d dropped)'
					% (provider, int((time.perf_counter() - _t_pack) * 1000), len(cached), len(_drop | _fake)))
			# LOCAL PATCH 2026-09-30: counted AFTER the listing tests, so a fake or a pack without the episode is not
			# counted as a cached source -- it never reaches the list
			if not self.background:
				self.counter_final.hide('wrong pack', len(_drop - _fake))
				self.counter_final.hide('fake', len(_fake))
				self.process_quality_count_final([i for i in results if i['hash'] in cached and i['hash'] not in _drop and i['hash'] not in _fake])
			_drop = _drop | _fake
			# built locally and extended in ONE call: with several debrids enabled these run in
			# parallel threads, and a per-item append would interleave the providers' rows.
			_batch = []
			for i in results:
				# a cached pack the listing proves does not hold this episode never reaches
				# the picker -- it could only fail at playback, silently.
				if i.get('hash') in _drop: continue
				# LOCAL PATCH 2026-09-23: an UNVERIFIABLE season-only pack goes too.
				#
				# animetosho flags a pack whose name states a season and no episodes ('One Piece
				# Season 17 (Dress Rosa) - Vol.15-22', 'Naruto Shippuden Season 3'). Nothing in the
				# name contradicts the episode asked for, so the provider rightly keeps it -- and a
				# season 17 pack is then offered for episode 1. 46 such rows on one Shippuden scrape.
				#
				# The listing above settles it when we have one: _drop already removes a CACHED pack
				# proven not to hold the episode. TorBox returns no listing for an uncached hash, so
				# those rows survive on a technicality -- unverifiable, not verified.
				#
				# Uncached is what makes this cheap. The row could not have played without a download
				# first, so dropping it costs a possibility rather than a result. A cached season-only
				# pack is untouched here and is judged on its real contents like any other.
				if i.get('season_only') and i.get('hash') not in cached: continue
				_row = dict(i, **{'cache_provider': provider if i['hash'] in cached else 'Uncached %s' % provider, 'debrid': provider})
				_size = _real.get(i.get('hash'))
				if _size is not None: _row.update({'size': round(_size, 2), 'size_label': '%.2f GB' % _size})
				_batch.append(_row)
			final_results.extend(_batch)
		def _debrid_check_dialog():
			self.progress_dialog.reset_is_cancelled()
			start_time, timeout = time.time(), 20
			# LOCAL PATCH 2026-09-26: same shape as _scraperDialog -- 50 ms, sleep outside the try.
			# The alive-count used to be taken BEFORE the sleep, so a check that had already
			# finished still cost one more 100 ms round before the break.
			while not self.progress_dialog.iscanceled() and not self.monitor.abortRequested():
				kodi_utils.sleep(50)
				try:
					remaining_debrids = [x.getName() for x in debrid_check_threads if x.is_alive() is True]
					current_progress = max((time.time() - start_time), 0)
					percent = int((current_progress/float(timeout))*100)
					rows = [(x.getName(), source_utils.provider_panel_name(x.getName()), 'checking' if x.is_alive() else 'done', 0) for x in debrid_check_threads]
					done = len([r for r in rows if r[2] == 'done'])
					left = max(0, int(round(timeout - current_progress)))
					shown = percent if len(rows) <= 1 else 100.0 * done / len(rows)
					# LOCAL PATCH 2026-09-30: the search phase's counts stay up until a debrid has answered. The cached counts
					# start with the internal sources alone (no cache check), so shown at once they fell -- 24 to 9 on Modha
					# Rathri, screenshot 86 -- and then rose again as the torrents came back cached.
					if done: counts, hidden = (self.final_sd, self.final_720p, self.final_1080p, self.final_4k, self.final_total), self.counter_final.line()
					else: counts, hidden = (self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total), self.counter.line()
					self.progress_dialog.update_scraper(*counts, '', shown,
						providers=rows, phase='Checking Debrid Cache', detail='%d of %d done  ·  %ds left' % (done, len(rows), left),
						time_pct=None if len(rows) <= 1 else percent, late=left <= 3, hidden=hidden)
					if len(remaining_debrids) == 0: break
					if percent >= 100: break
				except: pass
		try:
			if not self.background and self.all_internal_sources: self.process_quality_count_final(self.all_internal_sources)
			final_results = []
			results = list(_process_duplicates(results))
			hash_list = list(set([i['hash'] for i in results]))
			# LOCAL PATCH 2026-10-02: see _prefetch_debrid. Bounded: a stuck check costs at most 5 s, after which the final
			# check simply asks for whatever is still unknown (a hash still in flight is then asked twice, and the later of
			# the two cache writes fails on the unique key -- the verdicts returned are right either way).
			_t_check = time.perf_counter()
			_deadline = time.time() + 5
			for _thread in list(getattr(self, '_prefetch_threads', [])):
				_thread.join(max(0, _deadline - time.time()))
			if self._diag_timing:
				kodi_utils.logger('scrape.timing', 'debrid prefetch wait: %dms (%d prefetched of %d hashes)'
					% (int((time.perf_counter() - _t_check) * 1000), len(getattr(self, '_prefetch_seen', ())), len(hash_list)))
			cached_hashes = query_local_cache(hash_list)
			debrid_check_threads = [Thread(target=_process_cache_check, args=self.debrid_runners[item], name=item) for item in self.active_debrid]
			[i.start() for i in debrid_check_threads]
			if self.background: [i.join() for i in debrid_check_threads]
			else: _debrid_check_dialog()
			if self._diag_timing:
				kodi_utils.logger('scrape.timing', 'debrid check: %dms (%d results)' % (int((time.perf_counter() - _t_check) * 1000), len(final_results)))
			return final_results
		except: return []

	def _drop_not_episodes(self, provider, sources):
		"""LOCAL PATCH 2026-10-06: anime rows that are no episode of the show -- re-edits ('The Compilation'), extras
		(creditless OP/ED), manga volumes (anime_utils.anime_not_episode) -- from every provider, applied after the cache so
		rows cached before this are dropped too. Chainsaw Man S1E1 carried 17 'The Compilation' rows (AnimeTosho, Comet), Hunter
		x Hunter S1E1 seven manga volumes as season packs (Comet).
		LOCAL PATCH 2026-10-08: plus another season's release named by its year alone, and specials-only rows (both in
		anime_utils) -- One Punch Man S1E1 listed S3's 'One.Punch.Man.(2025).-.01' and 'One.Punch.Man.[S1].[Ova.720p]'."""
		if not sources or not getattr(self, '_is_anime', False): return sources
		try:
			from magneto.modules.anime_utils import anime_not_episode, alias_titles, other_season_year, specials_only
			titles = [self.title] + list(alias_titles(self.data) or [])
			# specials are judged only for a regular season whose TMDb name is not itself an OVA / specials run
			try: _season = int(self.season)
			except (TypeError, ValueError): _season = 0
			_season_names = [sn.get('name') or '' for sn in (self.meta.get('season_data') or []) if str(sn.get('season_number')) == str(_season)]
			_special_titles = titles + _season_names if _season > 0 else None
			kept, dropped = [], []
			for i in sources:
				_name = i.get('name') or ''
				why = anime_not_episode(_name, titles)
				if not why:
					_other = other_season_year(_name, self.data)
					if _other: why = 'season %s by its year' % _other
				if not why and _special_titles is not None:
					_sp = specials_only(_name, _special_titles)
					if _sp: why = 'specials (%s)' % _sp
				if why: dropped.append('%s: %s' % (why, (i.get('name') or '')[:70]))
				else: kept.append(i)
			if dropped: kodi_utils.logger('anime.not_episode', '%s: dropped %d -- %s' % (provider, len(dropped), ' | '.join(dropped[:3])))
			return kept
		except Exception: return sources

	def process_sources(self, provider, sources):
		try:
			for i in sources:
				try:
					i_get = i.get
					size, size_label, divider = 0, None, None
					if 'hash' in i:
						_hash = i_get('hash').lower()
						i['hash'] = str(_hash)
					display_name = source_utils.clean_display_name(source_utils.normalize(_PLUS_SEPARATOR.sub(' ', i['name'].replace('html', ' ')).replace('-', ' ')))
					if 'name_info' in i: quality, extraInfo = source_utils.get_file_info(name_info=i_get('name_info'))
					else: quality, extraInfo = source_utils.get_file_info(url=i_get('url'))
					try:
						size = i_get('size')
						# LOCAL PATCH 2026-08-27: animetosho and seadex added to the no-divide list.
						# The divider below is the TMDb season's episode_count, which for anime is
						# routinely unrelated to what a pack actually holds -- TMDb files every
						# Re:ZERO cour under season 1, giving episode_count 85 against a 12-file
						# cour pack, so a 65GB BD remux displayed as 0.77GB and sorted near the
						# bottom. Both providers know their pack's real contents (animetosho from
						# num_files, seadex from the API's per-file listing) and report a correct
						# per-episode size themselves, so dividing it again would only re-break it.
						# LOCAL PATCH 2026-09-25: nekobt too -- it divides by the pack's own episode count.
						# LOCAL PATCH 2026-10-03: the rule moved to source_utils.pack_size_divider -- adds true_size (per-file
						# providers), a pack's own count ('pack_episodes'), the anime release season's length, and a show
						# pack's own seasons. The no-divide list above is source_utils.PER_EPISODE_PROVIDERS.
						divider = source_utils.pack_size_divider(i, provider, self.season_divider, self.show_divider,
							self._season_counts, self.data.get('season_length'), self.total_seasons)
						if divider: size = float(size) / divider
						size_label = '%.2f GB' % size
					except: pass
					i.update({'provider': provider, 'display_name': display_name, 'external': True, 'scrape_provider': self.scrape_provider, 'extraInfo': extraInfo,
							'quality': quality, 'size_label': size_label, 'size': round(size, 2)})
				except: pass
		except: pass
		return sources

	def process_quality_count(self, sources):
		sources = self.counter.keep(sources)
		for item in self.count_tuple: setattr(self, item[0], getattr(self, item[0]) + item[2](sources, item[1]))

	def process_quality_count_final(self, sources):
		sources = self.counter_final.keep(sources)
		for item in self.count_tuple_final: setattr(self, item[0], getattr(self, item[0]) + item[2](sources, item[1]))

	def _provider_rows(self, final=False):
		"""LOCAL PATCH 2026-09-27: one row per provider for the loading window -- pack threads ('comet (Season)')
		fold into their provider; internal scrapers count as done once their results were read."""
		rows, seen = [], {}
		for t in list(self.threads):
			base = t.getName().split(' (')[0]
			seen[base] = seen.get(base, False) or t.is_alive()
		for base, alive in seen.items():
			n = self.provider_counts.get(base, 0)
			state = ('timeout' if final else 'running') if alive else ('done' if n else ('failed' if base in self.provider_failed else 'none'))
			rows.append((base, source_utils.provider_panel_name(base), state, n))
		for i in self.internal_scrapers:
			done = i in self.processed_internal_scrapers
			n = self.provider_counts.get(i, 0)
			state = ('done' if n else 'none') if done else ('timeout' if final else 'running')
			rows.append((i, source_utils.provider_panel_name(i), state, n))
		return rows

	def process_internal_results(self):
		if self.internal_prescraped and not self.processed_prescrape:
			self.all_internal_sources += self.prescrape_sources
			self.process_quality_count(self.prescrape_sources)
			self.processed_prescrape = True
		for i in self.internal_scrapers:
			win_property = kodi_utils.get_property('deadlight.internal_results.%s' % i)
			if win_property in ('checked', '', None): continue
			try: internal_sources = json.loads(win_property)
			except: continue
			kodi_utils.set_property('deadlight.internal_results.%s' % i, 'checked')
			self.all_internal_sources += internal_sources
			self.processed_internal_scrapers_append(i)
			self.provider_counts[i] = len(internal_sources)
			self.process_quality_count(internal_sources)
		return [i for i in self.internal_scrapers if not i in self.processed_internal_scrapers]

	def _quality_length(self, items, quality):
		return len([i for i in items if i['quality'] == quality])

	def _quality_length_sd(self, items, dummy):
		return len([i for i in items if i['quality'] in ('SD', 'CAM', 'TELE', 'SYNC')])

	def quality_length_final(self, items, dummy):
		return len(items)