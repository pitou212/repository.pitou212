# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-09: Fribb anime-lists -- MAL ID -> TMDb coordinates lookup with the `episode_offset` support the
# Otaku-Mappings DB lacks. SIMKL exposes anime as per-cour entries with their own MAL IDs; Fribb gives the TMDb
# (show_id, season, episode_offset), so multi-cour anime like Slime S1-S5 all land on TMDb 82684 with correct S/E.
#
# Source:
#   https://raw.githubusercontent.com/Fribb/anime-lists/master/anime-list-full.json    (~7.5 MB)
#
# JSON row shape (anime-list-full.json):
#   {"mal_id": 41487, "anidb_id": ..., "themoviedb_id": {"tv": 82684},
#    "season": {"tvdb": 3, "tmdb": 3}, "episode_offset": {"tvdb": 12, "tmdb": 12}, ...}
#   Some rows lack `season`/`episode_offset` -- treat missing as {} (no offset).
#
# In-memory index built once per PROCESS, not per Kodi session: reuselanguageinvoker=false makes every plugin call
# (every widget refresh) a fresh interpreter. ~43k rows, ~150 ms and ~26 MB from the full file -- why callers gate
# before asking, and why _load_index is locked.

import os
import time
import json
import re
import threading

from modules.kodi_utils import translate_path, addon_info, logger, logger_debug, notification

_MAPPINGS_URL = 'https://raw.githubusercontent.com/Fribb/anime-lists/master/anime-list-full.json'
_MAPPINGS_DIR = translate_path(addon_info('profile'))
_MAPPINGS_FILE = os.path.join(_MAPPINGS_DIR, 'fribb_anime_list_full.json')
# LOCAL PATCH 2026-09-04: slim projection of the full file -- see _write_slim below.
# LOCAL PATCH 2026-10-27: _v2 -- film rows keep imdb_id (see _INDEX_BY_IMDB_MOVIE). A new name makes every install
# rebuild it once from the full file; the old slim file (and its .idx.pkl) is no longer read.
_SLIM_FILE = os.path.join(_MAPPINGS_DIR, 'fribb_anime_list_slim_v2.json')
# The ONLY row fields any caller reads (every .get() here plus external consumers of a raw row). `simkl_id` is the
# non-obvious one: indexers/anilist_lists.py reads it for the Simkl resolve tier, and dropping it would silently
# degrade that tier into a slower TMDb title search.
_SLIM_FIELDS = ('mal_id', 'anilist_id', 'themoviedb_id', 'kitsu_id', 'anidb_id',
				'season', 'episode_offset', 'simkl_id')
# LOCAL PATCH 2026-09-26: 7 days, not 30 (a 30-day copy missed new cours' ids for airing shows). Since 2026-10-05 the
# refresh follows Fribb's Tuesday release instead (_latest_release_cutoff below).

_INDEX_BY_MAL = None      # dict: mal_id (int) -> row dict
_INDEX_BY_ANILIST = None  # dict: anilist_id (int) -> row dict
_INDEX_BY_TMDB_TV = None  # dict: tmdb_tv_id (int) -> list of row dicts (one per cour)
# LOCAL PATCH 2026-08-29: reverse movie index for the AniList backfill. themoviedb_id.movie is a LIST upstream (one
# AniDB movie entry can map to several TMDb movie ids, see _row_tmdb), so every id in it points at the same row.
_INDEX_BY_TMDB_MOVIE = None  # dict: tmdb_movie_id (int) -> row dict
# LOCAL PATCH 2026-10-27: films by IMDb id, the fallback when the TMDb movie id finds nothing. Fribb files many films
# under the SERIES' TMDb TV id (TMDb lists them as its specials) with no TMDb movie id (most MOVIE rows). An IMDb id
# shared by two or more MOVIE rows (compilations and the like) is left out -- an ambiguous id must not pick a film.
_INDEX_BY_IMDB_MOVIE = None  # dict: 'tt...' -> row dict
# LOCAL PATCH 2026-09-01: memo for the flat-season repair below, keyed (tmdb_id, season). [] is a cached negative --
# the repair is attempted at most once per show per session.
_FLAT_PAIRS_CACHE = {}
# LOCAL PATCH 2026-09-04: memo for _season_cour_rows, keyed (tmdb_id, season). See there.
_SEASON_ROWS_CACHE = {}
# LOCAL PATCH 2026-09-12: memo for _tmdb_season_numbers, keyed tmdb_id. SUCCESSES ONLY --
# see the note there on why a failed lookup must not be remembered.
_TMDB_SEASONS_CACHE = {}
# LOCAL PATCH 2026-09-04: lock for the lazy index loader -- see _load_index.
_INDEX_LOCK = threading.Lock()
_ROWS_IN_PROGRESS = threading.local()   # LOCAL PATCH 2026-10-19: see _season_cour_rows


# ═══════════════════════════════════════════════════════════════════════════
#  Download / refresh -- sole anime mapping source
# ═══════════════════════════════════════════════════════════════════════════

# LOCAL PATCH 2026-10-05: refresh on Fribb's own schedule, not 7 days from our last download. Fribb publishes on
# Tuesdays around 16:10 UTC, so the copy is replaced once it is older than the latest Tuesday 18:00 UTC -- one download
# a week, the day the new list exists. A byte-identical download (release late) keeps the copy with its old date, and
# the next try is 12 h later.
_RELEASE_WEEKDAY, _RELEASE_HOUR_UTC = 1, 18   # time.gmtime: Monday is 0
_UNCHANGED_RETRY_SECONDS = 12 * 3600
_UNCHANGED_MARK = _MAPPINGS_FILE + '.unchanged'


def _latest_release_cutoff(now=None):
	"""Epoch of the most recent Tuesday 18:00 UTC at or before `now`. time.gmtime, not strptime (Kodi worker threads)."""
	now = time.time() if now is None else now
	t = time.gmtime(now)
	midnight = now - (t.tm_hour * 3600 + t.tm_min * 60 + t.tm_sec)
	cutoff = midnight - ((t.tm_wday - _RELEASE_WEEKDAY) % 7) * 86400 + _RELEASE_HOUR_UTC * 3600
	return cutoff - 7 * 86400 if cutoff > now else cutoff


def _needs_download(path):
	if not os.path.exists(path): return True
	try:
		if os.path.getmtime(path) >= _latest_release_cutoff(): return False
		try:
			if time.time() - os.path.getmtime(_UNCHANGED_MARK) < _UNCHANGED_RETRY_SECONDS: return False
		except OSError: pass
		return True
	except Exception: return True


def download_mappings(force=False, silent=True):
	"""Fetch the Fribb full mapping file. Returns True on new-fetch success."""
	need_full = force or _needs_download(_MAPPINGS_FILE)
	if not need_full: return False
	try:
		if not os.path.isdir(_MAPPINGS_DIR):
			os.makedirs(_MAPPINGS_DIR, exist_ok=True)
		tmp = _MAPPINGS_FILE + '.tmp'
		# 60s timeout -- 7.5 MB should easily fit on any reasonable link.
		# LOCAL PATCH 2026-09-26: imported here -- every TV/list page imports this module and urllib.request costs ~80 ms;
		# only this weekly download needs it.
		import urllib.request
		with urllib.request.urlopen(_MAPPINGS_URL, timeout=60) as resp:
			data = resp.read()
		# LOCAL PATCH 2026-10-05: the same bytes as our copy = Fribb has not published this week's list yet (see
		# _needs_download). Keep the copy and its date, so it still counts as older than the release; retry in 12 h.
		if not force and os.path.exists(_MAPPINGS_FILE) and os.path.getsize(_MAPPINGS_FILE) == len(data):
			with open(_MAPPINGS_FILE, 'rb') as f: same = f.read() == data
			if same:
				with open(_UNCHANGED_MARK, 'w') as f: f.write(str(int(time.time())))
				logger_debug('fribb_mappings', 'unchanged since our copy -- this week\'s list is not out yet; next try in 12 h')
				return False
		with open(tmp, 'wb') as f:
			f.write(data)
		os.replace(tmp, _MAPPINGS_FILE)
		try: os.remove(_UNCHANGED_MARK)
		except OSError: pass
		# LOCAL PATCH 2026-09-04: drop the slim projection whenever the full file is replaced -- it is DERIVED data, and a
		# surviving slim file would silently shadow the new mappings. _load_index regenerates it on the next load.
		if need_full:
			try:
				if os.path.exists(_SLIM_FILE): os.remove(_SLIM_FILE)
			except Exception as e:
				logger('fribb_mappings', 'could not remove stale slim index: %s' % e)
		clear_cache()
		size_mb = os.path.getsize(_MAPPINGS_FILE) / 1024 / 1024 if os.path.exists(_MAPPINGS_FILE) else 0
		logger('fribb_mappings', 'downloaded (%.1f MB full)' % size_mb)
		if not silent: notification('Fribb anime mappings updated', 3000)
		return True
	except Exception as e:
		logger('fribb_mappings', 'download failed: %s' % e)
		try:
			if os.path.exists(_MAPPINGS_FILE + '.tmp'): os.remove(_MAPPINGS_FILE + '.tmp')
		except Exception: pass
		return False


def clear_cache():
	# LOCAL PATCH 2026-08-31: _INDEX_BY_TMDB_MOVIE must be in this global list, or the reset binds a throwaway local.
	global _INDEX_BY_MAL, _INDEX_BY_ANILIST, _INDEX_BY_TMDB_TV, _INDEX_BY_TMDB_MOVIE, _INDEX_BY_IMDB_MOVIE
	global _IS_AVAILABLE
	_INDEX_BY_MAL = None
	_INDEX_BY_ANILIST = None
	_INDEX_BY_TMDB_TV = None
	_INDEX_BY_TMDB_MOVIE = None
	_INDEX_BY_IMDB_MOVIE = None
	# LOCAL PATCH 2026-09-04: reset the memoised availability too -- download_mappings calls clear_cache() right after
	# replacing the file, which is exactly when it flips.
	_IS_AVAILABLE = None
	global _DB_KEY, _DB_LOCAL   # LOCAL PATCH 2026-11-08: the SQLite index is re-checked against the new slim file
	_DB_KEY, _DB_LOCAL = None, threading.local()
	_ROW_MEMO.clear()
	_FLAT_PAIRS_CACHE.clear()
	_SEASON_ROWS_CACHE.clear()
	_TMDB_SEASONS_CACHE.clear()


# LOCAL PATCH 2026-09-04: memoised -- called per ITEM by the cour-numbering gate (metadata.cour_display_numbers). The
# answer cannot change within one invocation unless we download the file, and clear_cache() resets it.
# LOCAL PATCH 2026-09-04: accepts EITHER file: _load_index prefers the slim projection, so testing only the full file
# could disagree with what the loader would serve.
_IS_AVAILABLE = None
def is_available():
	global _IS_AVAILABLE
	if _IS_AVAILABLE is None:
		_IS_AVAILABLE = any(os.path.exists(f) and os.path.getsize(f) > 500_000
							for f in (_SLIM_FILE, _MAPPINGS_FILE))
	return _IS_AVAILABLE


# ═══════════════════════════════════════════════════════════════════════════
#  Lazy index loaders
# ═══════════════════════════════════════════════════════════════════════════

# LOCAL PATCH 2026-09-04: double-checked lock. The globals are assigned only after the whole parse, so under a thread
# pool (build_tvshow_content fans out over TaskPool) every thread saw None and parsed the file itself -- ~10x slower
# plus a memory spike. The GIL does not help: CPython's C JSON scanner never releases it.
# The fast path stays lock-free: once the globals are set, readers never touch the lock.
def _load_index():
	if _INDEX_BY_MAL is not None: return
	with _INDEX_LOCK:
		if _INDEX_BY_MAL is not None: return
		_load_index_locked()

def prebuild_index():
	"""LOCAL PATCH 2026-11-28: build the slim file, the pickle and the SQLite index NOW -- the service calls this after its
	hourly download check, so after a new weekly list no plugin call (a click, a list page) pays the rebuild (~0.6 s on the
	PC over two calls, several seconds on a weak device). Two passes, as two calls would make them: the full-file parse
	writes the slim file (no key yet), the slim parse writes the pickle and the index. The in-memory indexes are dropped
	afterwards: the service lives for weeks and never looks anything up itself. True when the index is current."""
	def _current():
		try: return os.path.exists(_SLIM_FILE) and _db_is_current(_source_key(_SLIM_FILE))
		except Exception: return False
	if _current(): return True
	if not is_available() and not os.path.exists(_MAPPINGS_FILE): return False
	try:
		for _ in range(2):
			clear_cache()
			_load_index()
			if _current(): return True
		return False
	finally: clear_cache()

# LOCAL PATCH 2026-09-04: write a slim projection of the full file. Upstream ships 16 fields per row and we read 8
# (_SLIM_FIELDS); since every plugin process rebuilds the index, the slim file is ~3.7x less work. Index cardinalities
# are identical -- only rows with no usable id are dropped.
# Written as a side effect of the first full-file load, so existing installs get it without waiting for a download.
# Best-effort: a read-only profile keeps using the full file. tmp + os.replace so a concurrent process never reads a
# half-written file.
def _write_slim(data):
	try:
		slim = []
		for row in data:
			d = {k: row[k] for k in _SLIM_FIELDS if row.get(k) is not None}
			if row.get('type') == 'MOVIE' and row.get('imdb_id'):   # LOCAL PATCH 2026-10-27: _INDEX_BY_IMDB_MOVIE
				d['type'], d['imdb_id'] = 'MOVIE', row['imdb_id']
			if d.get('mal_id') is None and d.get('anilist_id') is None and not d.get('themoviedb_id') and not d.get('imdb_id'):
				continue
			slim.append(d)
		tmp = _SLIM_FILE + '.tmp'
		with open(tmp, 'w', encoding='utf-8') as f:
			json.dump(slim, f, separators=(',', ':'))
		os.replace(tmp, _SLIM_FILE)
		logger_debug('fribb_mappings', 'wrote slim index (%d of %d rows, %.2f MB)'
				% (len(slim), len(data), os.path.getsize(_SLIM_FILE) / 1024 / 1024))
	except Exception as e:
		logger('fribb_mappings', 'slim write failed (harmless, full file still used): %s' % e)
		try:
			if os.path.exists(_SLIM_FILE + '.tmp'): os.remove(_SLIM_FILE + '.tmp')
		except Exception: pass


# LOCAL PATCH 2026-10-02: the finished indexes, pickled beside the slim file, so every process does not rebuild them
# from JSON (pickle ~2.5x faster). Keyed on the slim file's size and mtime, so a new download (which deletes the slim
# file) invalidates it; any failure falls back to the JSON path.
# Pickle is safe here: the only writer is _write_pickled_index, into DeadLight's own profile folder, and the file is
# never downloaded or shared -- the same trust as the settings and cache databases beside it.
_INDEX_PICKLE = _SLIM_FILE + '.idx.pkl'

def _source_key(path):
	st = os.stat(path)
	return (st.st_size, st.st_mtime_ns)

def _read_pickled_index(key):
	try:
		import pickle
		with open(_INDEX_PICKLE, 'rb') as f:
			stored_key, indexes = pickle.load(f)
		if stored_key == key and len(indexes) == 5: return indexes
	except Exception: pass
	return None

def _write_pickled_index(key, indexes):
	try:
		import pickle
		tmp = _INDEX_PICKLE + '.tmp'
		with open(tmp, 'wb') as f:
			pickle.dump((key, indexes), f, protocol=4)
		os.replace(tmp, _INDEX_PICKLE)   # a concurrent process never reads half a file
	except Exception as e:
		logger('fribb_mappings', 'index pickle write failed (harmless): %s' % e)


# LOCAL PATCH 2026-11-08: the indexes as a small SQLite file beside the pickle, read by key -- unpickling all of them
# cost every anime-touching process tens of ms (more on the box) for a handful of point lookups. 'rows' holds each
# Fribb row once by number; 'ix' maps (kind, key) to row numbers. One decoded object per row number per process
# (_ROW_MEMO), so a row is the SAME object whichever index found it -- the cour code tracks rows by id(). Keyed on the
# slim file like the pickle; missing, stale or failing -> the pickle path, which then writes it.
_DB_FILE = _SLIM_FILE + '.idx.db'
_DB_KEY = None          # None: not checked yet; False: unusable this process; else the slim file's key
_DB_LOCAL = threading.local()
_ROW_MEMO = {}
_KIND_MAL, _KIND_ANI, _KIND_TV, _KIND_MOVIE, _KIND_IMDB = 0, 1, 2, 3, 4

def _db_conn():
	global _DB_KEY
	if _DB_KEY is False: return None
	con = getattr(_DB_LOCAL, 'con', None)
	if con is not None: return con
	try:
		if not (os.path.exists(_SLIM_FILE) and os.path.exists(_DB_FILE)):
			_DB_KEY = False
			return None
		import sqlite3
		con = sqlite3.connect(_DB_FILE, timeout=5)
		if _DB_KEY is None:
			stored = con.execute("SELECT v FROM meta WHERE k = 'key'").fetchone()
			key = list(_source_key(_SLIM_FILE))
			if not stored or json.loads(stored[0]) != key:
				con.close()
				_DB_KEY = False
				return None
			_DB_KEY = key
		_DB_LOCAL.con = con
		return con
	except Exception:
		_DB_KEY = False
		return None

def _db_rows(kind, key):
	"""The rows filed under (kind, key): a list ([] for none), or None when the database cannot answer."""
	con = _db_conn()
	if con is None: return None
	try:
		hit = con.execute('SELECT v FROM ix WHERE kind = ? AND k = ?', (kind, str(key))).fetchone()
		if not hit: return []
		out = []
		for rid in json.loads(hit[0]):
			row = _ROW_MEMO.get(rid)
			if row is None:
				got = con.execute('SELECT v FROM rows WHERE rid = ?', (rid,)).fetchone()
				if not got: continue
				row = _ROW_MEMO.setdefault(rid, json.loads(got[0]))   # setdefault: two threads keep ONE object
			out.append(row)
		return out
	except Exception: return None

def _write_index_db(key, indexes):
	"""Best-effort: write the SQLite index from the five finished dicts (tmp + os.replace)."""
	tmp = '%s.%d.tmp' % (_DB_FILE, os.getpid())
	try:
		import sqlite3
		by_mal, by_ani, by_tmdb, by_movie, by_imdb = indexes
		rid_of, rows, ix = {}, [], []
		def _rid(row):
			i = id(row)
			if i not in rid_of:
				rid_of[i] = len(rows)
				rows.append((len(rows), json.dumps(row, separators=(',', ':'))))
			return rid_of[i]
		for kind, index in ((_KIND_MAL, by_mal), (_KIND_ANI, by_ani), (_KIND_MOVIE, by_movie), (_KIND_IMDB, by_imdb)):
			for k, row in index.items(): ix.append((kind, str(k), '[%d]' % _rid(row)))
		for k, lst in by_tmdb.items(): ix.append((_KIND_TV, str(k), json.dumps([_rid(r) for r in lst])))
		if os.path.exists(tmp): os.remove(tmp)
		con = sqlite3.connect(tmp)
		con.execute('CREATE TABLE rows (rid INTEGER PRIMARY KEY, v TEXT)')
		con.execute('CREATE TABLE ix (kind INTEGER, k TEXT, v TEXT, PRIMARY KEY (kind, k)) WITHOUT ROWID')
		con.execute('CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)')
		con.executemany('INSERT INTO rows VALUES (?, ?)', rows)
		con.executemany('INSERT INTO ix VALUES (?, ?, ?)', ix)
		con.execute("INSERT INTO meta VALUES ('key', ?)", (json.dumps(list(key)),))
		con.commit()
		con.close()
		os.replace(tmp, _DB_FILE)   # a concurrent process never opens half a file
	except Exception as e:
		logger('fribb_mappings', 'index db write failed (harmless): %s' % e)
		try:
			if os.path.exists(tmp): os.remove(tmp)
		except Exception: pass

def _db_is_current(key):
	try:
		import sqlite3
		if not os.path.exists(_DB_FILE): return False
		con = sqlite3.connect(_DB_FILE, timeout=5)
		try: stored = con.execute("SELECT v FROM meta WHERE k = 'key'").fetchone()
		finally: con.close()
		return bool(stored) and json.loads(stored[0]) == list(key)
	except Exception: return False

def _load_index_locked():
	global _INDEX_BY_MAL, _INDEX_BY_ANILIST, _INDEX_BY_TMDB_TV, _INDEX_BY_TMDB_MOVIE, _INDEX_BY_IMDB_MOVIE
	# Prefer the slim projection; fall back to the full file and generate the slim one from it, so only the first process
	# after a download pays the full parse.
	source, make_slim = _SLIM_FILE, False
	if not os.path.exists(_SLIM_FILE):
		source, make_slim = _MAPPINGS_FILE, True
	if not os.path.exists(source):
		_INDEX_BY_MAL = {}
		_INDEX_BY_ANILIST = {}
		_INDEX_BY_TMDB_TV = {}
		_INDEX_BY_TMDB_MOVIE = {}
		_INDEX_BY_IMDB_MOVIE = {}
		return
	key = None
	if not make_slim:
		try:
			key = _source_key(source)
			cached = _read_pickled_index(key)
		except Exception: cached = None
		if cached:
			_INDEX_BY_MAL, _INDEX_BY_ANILIST, _INDEX_BY_TMDB_TV, _INDEX_BY_TMDB_MOVIE, _INDEX_BY_IMDB_MOVIE = cached
			if not _db_is_current(key): _write_index_db(key, cached)   # LOCAL PATCH 2026-11-08
			return
	try:
		with open(source, 'r', encoding='utf-8') as f:
			data = json.load(f)
		if make_slim: _write_slim(data)
		by_mal, by_ani, by_tmdb, by_movie, by_imdb, imdb_seen = {}, {}, {}, {}, {}, {}
		for row in data:
			mal = row.get('mal_id')
			if mal is not None:
				try: by_mal[int(mal)] = row
				except (TypeError, ValueError): pass
			# LOCAL PATCH 2026-08-10: index by anilist_id too. AniList results always carry `id`, but new seasonal shows often
			# have `idMal: null`, so the AniList index resolves far more of them.
			ani = row.get('anilist_id')
			if ani is not None:
				try: by_ani[int(ani)] = row
				except (TypeError, ValueError): pass
			tmdb = row.get('themoviedb_id') or {}
			tv = tmdb.get('tv')
			if tv is not None:
				try: by_tmdb.setdefault(int(tv), []).append(row)
				except (TypeError, ValueError): pass
			for mv in (tmdb.get('movie') or []):
				try: by_movie.setdefault(int(mv), row)
				except (TypeError, ValueError): pass
			if row.get('type') == 'MOVIE':
				imdb = row.get('imdb_id')
				for im in (imdb if isinstance(imdb, list) else [imdb]):
					if isinstance(im, str) and im.startswith('tt'):
						imdb_seen[im] = imdb_seen.get(im, 0) + 1
						by_imdb[im] = row
		_INDEX_BY_MAL = by_mal
		_INDEX_BY_ANILIST = by_ani
		_INDEX_BY_TMDB_TV = by_tmdb
		_INDEX_BY_TMDB_MOVIE = by_movie
		_INDEX_BY_IMDB_MOVIE = by_imdb = {im: row for im, row in by_imdb.items() if imdb_seen[im] == 1}
		# LOCAL PATCH 2026-10-25 (4.0.5): DEBUG level -- every process that builds the index logged it
		logger_debug('fribb_mappings', 'indexed %d MAL / %d AniList rows / %d TMDb TV shows / %d TMDb movies / %d IMDb films'
				% (len(by_mal), len(by_ani), len(by_tmdb), len(by_movie), len(by_imdb)))
		if key is not None:
			_write_pickled_index(key, (by_mal, by_ani, by_tmdb, by_movie, by_imdb))
			_write_index_db(key, (by_mal, by_ani, by_tmdb, by_movie, by_imdb))   # LOCAL PATCH 2026-11-08
	except Exception as e:
		logger('fribb_mappings', 'index load failed: %s' % e)
		_INDEX_BY_MAL = {}
		_INDEX_BY_ANILIST = {}
		_INDEX_BY_TMDB_TV = {}
		_INDEX_BY_TMDB_MOVIE = {}
		_INDEX_BY_IMDB_MOVIE = {}


# ═══════════════════════════════════════════════════════════════════════════
#  Public lookup API
# ═══════════════════════════════════════════════════════════════════════════

def _fribb_row(kind, media_id, index):
	"""The Fribb row for one id of `kind`, or None: from the SQLite index, else the in-memory one -- `index` returns that
	dict AFTER _load_index (which rebinds it)."""
	if media_id is None: return None
	try: media_id = int(media_id)
	except (TypeError, ValueError): return None
	rows = _db_rows(kind, media_id)
	if rows is not None: return rows[0] if rows else None
	_load_index()
	return index().get(media_id)


def mal_to_fribb(mal_id):
	"""MAL ID → full Fribb row dict or None."""
	return _fribb_row(_KIND_MAL, mal_id, lambda: _INDEX_BY_MAL)


def anilist_to_fribb(anilist_id):
	"""AniList ID → full Fribb row dict or None."""
	return _fribb_row(_KIND_ANI, anilist_id, lambda: _INDEX_BY_ANILIST)


# LOCAL PATCH 2026-10-27: the film lookups below by TMDb movie id, then by IMDb id (_INDEX_BY_IMDB_MOVIE).
def _movie_row(tmdb_id, imdb_id=None):
	if _db_conn() is not None:   # LOCAL PATCH 2026-11-08: by key from the SQLite index (same order of lookups)
		try: rows = _db_rows(_KIND_MOVIE, int(tmdb_id)) if tmdb_id is not None else []
		except (TypeError, ValueError): rows = []
		if rows: return rows[0]
		if rows is not None:
			if not imdb_id: imdb_id = _cached_movie_imdb(tmdb_id)
			if isinstance(imdb_id, str) and imdb_id.startswith('tt'):
				rows = _db_rows(_KIND_IMDB, imdb_id)
				if rows is not None: return rows[0] if rows else None
			else: return None
	_load_index()
	try: row = _INDEX_BY_TMDB_MOVIE.get(int(tmdb_id)) if tmdb_id is not None else None
	except (TypeError, ValueError): row = None
	if row is None and _INDEX_BY_IMDB_MOVIE:
		# callers with only the TMDb id (AniList recommendations, Continue Watching's AniList sync, the Anime List Manager):
		# the film's IMDb id from DeadLight's own meta cache -- a local read; a film never built there stays unmatched
		if not imdb_id: imdb_id = _cached_movie_imdb(tmdb_id)
		if isinstance(imdb_id, str) and imdb_id.startswith('tt'): row = _INDEX_BY_IMDB_MOVIE.get(imdb_id)
	return row

def _cached_movie_imdb(tmdb_id):
	try:
		from caches.base_cache import connect_database
		hit = connect_database('metacache_db').execute(
			'SELECT imdb_id FROM metadata WHERE db_type = ? AND tmdb_id = ?', ('movie', str(int(tmdb_id)))).fetchone()
		return hit[0] if hit else None
	except Exception: return None


# LOCAL PATCH 2026-08-29: the reverse of _row_tmdb(want_movie=True), for the AniList backfill. Films have no cours, so
# a watched anime film is simply progress 1.
def anilist_for_tmdb_movie(tmdb_id, imdb_id=None):
	"""TMDb MOVIE id -> AniList id, or None if it is not an anime film."""
	row = _movie_row(tmdb_id, imdb_id)
	if not row: return None
	try: return int(row['anilist_id'])
	except (KeyError, TypeError, ValueError): return None


# LOCAL PATCH 2026-10-02: the same lookup for the Anime List Manager, which writes AniList AND MyAnimeList.
def anime_ids_for_tmdb_movie(tmdb_id, imdb_id=None):
	"""TMDb MOVIE id -> {'anilist': int|None, 'mal': int|None} for an anime film, else {}."""
	row = _movie_row(tmdb_id, imdb_id)
	if not row: return {}
	out = {}
	for key, name in (('anilist_id', 'anilist'), ('mal_id', 'mal')):
		try: out[name] = int(row[key]) if row.get(key) is not None else None
		except (TypeError, ValueError): out[name] = None
	return out


# LOCAL PATCH 2026-09-23: the same reverse movie index, returning BOTH ani.zip lookup keys. The scrape path cannot use
# anilist_for_tmdb_movie: every movie row carries anidb_id but ~6% carry NO anilist_id, and querying ani.zip by anidb_id
# also RECOVERS the AniList id Fribb is missing, which gives seadex a key.
def query_ids_for_tmdb_movie(tmdb_id, imdb_id=None):
	"""TMDb MOVIE id -> {anilist_id, anidb_id} for an anime film, else {}.

	Either value may be absent; anidb_id is the reliable one. Both are LOOKUP KEYS for
	anizip_episode_ids, not scrape data -- a film has no cours, no offsets and no episode
	numbering to resolve beyond the single entry-local episode that IS the film."""
	row = _movie_row(tmdb_id, imdb_id)
	if not row: return {}
	out = {}
	# LOCAL PATCH 2026-10-06: kitsu_id too -- torrentio and comet search a film with no IMDb id by it (scrapers/external.py)
	for _key in ('anilist_id', 'anidb_id', 'kitsu_id'):
		try:
			_v = row.get(_key)
			if _v is not None: out[_key] = int(_v)
		except (TypeError, ValueError): continue
	return out


def _row_tmdb(row, want_movie=False):
	"""Extract a TMDb id (str) from a Fribb row's `themoviedb_id` field.
	Shape is inconsistent upstream by design: `.tv` is a single int, `.movie`
	is a LIST of ints (a single AniDB movie entry can map to several TMDb
	movie ids). For TV we want `.tv`; for movies take the first `.movie`
	entry and fall back to `.tv` (some ONA/OVA rows only carry `.tv`)."""
	if not row: return None
	tv = row.get('themoviedb_id')
	if isinstance(tv, dict):
		if want_movie:
			mv = tv.get('movie')
			if isinstance(mv, list) and mv:
				try: return str(int(mv[0]))
				except (TypeError, ValueError): pass
			elif mv is not None:
				try: return str(int(mv))
				except (TypeError, ValueError): pass
			# LOCAL PATCH 2026-10-27: no `.tv` fallback for a film. The TV id is the parent SERIES, and the caller fetches it as a
			# TMDb MOVIE id -- a different title (the Naruto Shippuden films showed as TMDb movie 31910, 'Chilly Dogs'). Only
			# AniList's MOVIE format asks for a movie (OVA / ONA / SPECIAL go the TV way), so None lets the caller's SIMKL tier
			# and title search find the film.
			return None
		t = tv.get('tv')
		if t is not None:
			try: return str(int(t))
			except (TypeError, ValueError): return None
	elif tv is not None:
		try: return str(int(tv))
		except (TypeError, ValueError): return None
	return None


def fribb_tmdb_for(anilist_id=None, mal_id=None, media_type='tvshow'):
	"""Resolve an AniList/MAL id pair to a TMDb id (str) or None.

	Tries the AniList index first — AniList browse responses always carry `id`
	but brand-new seasonal titles frequently have `idMal: null`, so the AniList
	index hits far more often. Returns the PARENT show's TMDb id for TV (Fribb's
	`themoviedb_id.tv` is the parent, with the cour's season in `season.tmdb`),
	which is exactly what catalog rendering wants."""
	want_movie = (media_type == 'movie')
	row = anilist_to_fribb(anilist_id)
	tmdb = _row_tmdb(row, want_movie)
	if tmdb: return tmdb
	row = mal_to_fribb(mal_id)
	return _row_tmdb(row, want_movie)


def tmdb_tv_to_fribb_rows(tmdb_id):
	"""TMDb TV id → list of all Fribb rows mapped to that TMDb show. Multi-cour
	shows return multiple rows (one per cour). Useful for building a full
	"which cours belong to this TMDb show?" view."""
	if tmdb_id is None: return []
	try: tmdb_id = int(tmdb_id)
	except (TypeError, ValueError): return []
	rows = _db_rows(_KIND_TV, tmdb_id)
	if rows is not None: return rows
	_load_index()
	return list(_INDEX_BY_TMDB_TV.get(tmdb_id, []))

def anilist_ids_for_tmdb_shows(tmdb_ids):
	"""LOCAL PATCH 2026-11-15: every AniList id Fribb maps to these TMDb shows, in their order -- what building their tiles
	reads from anilist_entries (cour counts, start dates), for anilist_api.prime_entries. Shows Fribb does not know (not
	anime) add nothing; local lookups only."""
	out, seen = [], set()
	for tmdb_id in tmdb_ids or []:
		for row in tmdb_tv_to_fribb_rows(tmdb_id) or []:
			a = row.get('anilist_id')
			if a and a not in seen:
				seen.add(a)
				out.append(a)
	return out


# ═══════════════════════════════════════════════════════════════════════════
#  Flat-season repair (LOCAL PATCH 2026-09-01)
#
#  Fribb sometimes copies season.tvdb into season.tmdb. When TMDb has kept the whole show as ONE season that copy is
#  a lie, and it hides the cour split from _season_cour_rows -- the rows for cours 2..n claim TMDb seasons that do
#  not exist and are filtered out, leaving one row and "not split".
#
#  Example: Tokyo Revengers, TMDb 105009, one 50-episode season; Fribb files its three cours as season.tmdb 1, 2, 3
#  with no episode_offset. The truth is season 1 at offsets 0, 24 and 37.
#
#  The tell is structural and free to test: several rows, one per DISTINCT season number, none carrying an offset.
#  Only then are the real boundaries looked for -- first in a TMDb episode group, then in AniList episode counts.
# ═══════════════════════════════════════════════════════════════════════════

def _flat_candidate_rows(tmdb_id):
	"""[(season_number, row), ...] sorted by season for a show of the shape above, else [].

	Index-only, no network -- this is the guard that keeps the repair off the hot path
	for every normally-mapped show."""
	rows = tmdb_tv_to_fribb_rows(tmdb_id)
	if len(rows) < 2: return []
	numbered = []
	for r in rows:
		s = (r.get('season') or {}).get('tmdb')
		if s is None: return []
		try: s = int(s)
		except (TypeError, ValueError): return []
		# Any recorded offset means Fribb already describes the split properly and the
		# normal same-season path is the truth. Never second-guess it.
		if (r.get('episode_offset') or {}).get('tmdb'): return []
		numbered.append((s, r))
	# Exactly one row per season number, and at least one season past the first --
	# the signature of season.tmdb having been copied from season.tvdb.
	if len(set(s for s, _r in numbered)) != len(numbered): return []
	if max(s for s, _r in numbered) < 2: return []
	numbered.sort(key=lambda t: t[0])
	return numbered


def _episode_group_boundaries(tmdb_id, season, expected):
	"""Offsets for `expected` cours read off a TMDb episode group, or [].

	A group is accepted only when its subgroups inside TMDb season `season` number exactly `expected` AND tile that
	season from episode 1 with no gap and no overlap. That tiling test SELECTS the right group, so no group `type` is
	hardcoded (Tokyo Revengers: 'Seasons' passes; 'Story Arcs' has a gap, 'Japanese Blu-ray / DVD' too many subgroups).
	"""
	try:
		from apis.tmdb_api import episode_groups_data, episode_group_details
	except Exception: return []
	try: results = (episode_groups_data(tmdb_id) or {}).get('results') or []
	except Exception: return []
	if not isinstance(results, list): return []
	# Try the closest subgroup counts first -- `expected`, or expected+1 when the group
	# carries a Specials subgroup -- so the usual case costs one details call.
	def _distance(g):
		try: return abs(int(g.get('group_count') or 0) - expected)
		except (TypeError, ValueError): return 9999
	for g in sorted([g for g in results if isinstance(g, dict)], key=_distance):
		if _distance(g) > 4: break
		# LOCAL PATCH 2026-10-05: never a 'Story Arcs' group (TMDb type 5) -- arcs are not cours, yet they tile a season just
		# as well (MASHLE's 3-arc group put E13-E24 in an unaired season, so scrapers found nothing).
		if str(g.get('type')) == '5': continue
		gid = g.get('id')
		if not gid: continue
		try: detail = episode_group_details(gid) or {}
		except Exception: continue
		if not isinstance(detail, dict): continue
		spans = []
		for sub in (detail.get('groups') or []):
			episodes = sub.get('episodes') or []
			nums = []
			for e in episodes:
				try:
					if int(e.get('season_number')) != season: continue
					nums.append(int(e.get('episode_number')))
				except (TypeError, ValueError): continue
			if not nums: continue
			# A subgroup only PARTLY inside this season is not a clean cour boundary;
			# reject the whole group rather than guess at the remainder.
			if len(nums) != len(episodes):
				spans = None
				break
			try: order = int(sub.get('order'))
			except (TypeError, ValueError): order = len(spans)
			spans.append((order, sorted(nums)))
		if not spans or len(spans) != expected: continue
		spans.sort(key=lambda t: t[0])
		flat = [n for _o, nums in spans for n in nums]
		# Contiguous from 1 with no gap and no repeat -- the tiling test.
		if flat != list(range(1, len(flat) + 1)): continue
		offsets, running = [], 0
		for _o, nums in spans:
			offsets.append(running)
			running += len(nums)
		return offsets
	return []


def _anilist_boundaries(numbered):
	"""Offsets derived from each cour's AniList episode count, or [].

	Only the cours BEFORE the last need a count -- the last one simply runs to the end
	of the season -- which matters because a currently-airing cour reports
	`episodes: null` and that is nearly always the last one.
	"""
	try:
		from apis.anilist_api import anilist_episode_counts
	except Exception: return []
	# LOCAL PATCH 2026-10-03 (Batch 4): by AniList id when every cour has one. A MAL id AniList splits in two counted as
	# whichever entry came last, shifting every later cour; anilist_episode_counts now leaves such an id out, which
	# abandons the repair below rather than guess.
	field = 'anilist_id' if all(r.get('anilist_id') for _s, r in numbered) else 'mal_id'
	try: counts = anilist_episode_counts([r.get(field) for _s, r in numbered], by='id' if field == 'anilist_id' else 'mal') or {}
	except Exception: return []
	offsets, running = [0], 0
	for _s, r in numbered[:-1]:
		try: n = int(counts.get(int(r.get(field)), 0))
		except (TypeError, ValueError): return []
		# An unknown or zero-length earlier cour makes every later offset wrong, so
		# abandon the whole repair rather than emit a partly-guessed split.
		if n <= 0: return []
		running += n
		offsets.append(running)
	return offsets


def _tmdb_season_numbers(tmdb_id):
	"""Season numbers TMDb actually has for this show, or None when unknown.

	LOCAL PATCH 2026-09-12. Successes only are memoised: a failed lookup must not be
	cached, or one network blip decides the question for the rest of the session."""
	if tmdb_id in _TMDB_SEASONS_CACHE: return set(_TMDB_SEASONS_CACHE[tmdb_id])
	try:
		from apis.tmdb_api import tvshow_seasons_light
		seasons = (tvshow_seasons_light(tmdb_id) or {}).get('seasons')
		if not seasons: return None
		out = set()
		for s in seasons:
			n = (s or {}).get('season_number')
			if n is None: continue
			try: out.add(int(n))
			except (TypeError, ValueError): continue
		if not out: return None
		_TMDB_SEASONS_CACHE[tmdb_id] = out
		return set(out)
	except Exception: return None


def _repair_is_bogus(tmdb_id, named_seasons):
	"""True when the flat-season repair must NOT run for this show.

	LOCAL PATCH 2026-09-12. _flat_candidate_rows matches the SHAPE of Fribb's rows (one per season number, no offsets),
	but a show that genuinely has those seasons has the same shape. The repair is for shows whose cours Fribb scattered
	across seasons TMDb DOES NOT HAVE (BLUE LOCK: Fribb [1,2], TMDb [1]), so ask TMDb directly instead of inferring.

	Unguarded it does real damage: on a show with two real seasons it gave S1's later episodes Season 2's AniList id,
	poster and title -- and Mark Watched would scrobble an unaired season. Shape matches with real seasons outnumber
	genuine flat shows ~3:1.

	Unknown answer means DO NOT repair: the repair is display/sync only (scrape passes allow_repair=False), so skipping
	costs a plainer label, while running it wrongly pushes bad data to AniList."""
	have = _tmdb_season_numbers(tmdb_id)
	if have is None: return True
	return set(named_seasons) <= have


def _flattened_cour_pairs(tmdb_id, season):
	"""[(offset, row), ...] recovered for a flattened season, or []. Memoised per session."""
	try: tmdb_id, season = int(tmdb_id), int(season)
	except (TypeError, ValueError): return []
	key = (tmdb_id, season)
	if key in _FLAT_PAIRS_CACHE: return list(_FLAT_PAIRS_CACHE[key])
	pairs = []
	numbered = _flat_candidate_rows(tmdb_id)
	# LOCAL PATCH 2026-09-12: the index-only filter above is a cheap PRE-filter; this is the authoritative test. Runs only
	# for shows that matched the shape, cached here and for 168h in tmdb_api.
	if numbered and _repair_is_bogus(tmdb_id, [s for s, _r in numbered]):
		logger('fribb_mappings', 'tmdb %s s%s: not flattened -- TMDb has every season Fribb names; no repair'
				% (tmdb_id, season))
		numbered = []
	# The flattened season is the one TMDb kept, the lowest number Fribb knows. Without this a caller asking for the
	# phantom season 2 would be handed season 1's split.
	if numbered and season == numbered[0][0]:
		source = 'episode group'
		offsets = _episode_group_boundaries(tmdb_id, season, len(numbered))
		if not offsets:
			source = 'anilist'
			offsets = _anilist_boundaries(numbered)
		if len(offsets) == len(numbered) and offsets[0] == 0 and offsets == sorted(set(offsets)):
			pairs = [(off, row) for off, (_s, row) in zip(offsets, numbered)]
			logger('fribb_mappings', 'tmdb %s s%s: flat-season repair via %s, offsets %s'
					% (tmdb_id, season, source, offsets))
		else:
			logger('fribb_mappings', 'tmdb %s s%s: %d mislabelled rows but no usable boundaries'
					% (tmdb_id, season, len(numbered)))
	_FLAT_PAIRS_CACHE[key] = pairs
	return list(pairs)


def _tmdb_episode_count(tmdb_id, season):
	"""Episodes TMDb lists for one season (tvshow_seasons_light, cached 168 h), or None."""
	try:
		from apis.tmdb_api import tvshow_seasons_light
		for s in (tvshow_seasons_light(tmdb_id) or {}).get('seasons') or []:
			if int((s or {}).get('season_number', -1)) == int(season): return int(s.get('episode_count') or 0) or None
	except Exception: pass
	return None


def _mixed_flat_pairs(tmdb_id, season, real):
	"""[(offset, row), ...] for a season TMDb grew by folding other seasons into it, or [].

	LOCAL PATCH 2026-10-16. The mixed case of the repair above: some rows are recorded correctly under TMDb's season,
	others ('strays') under seasons TMDb no longer has -- after the real rows (Bungou Stray Dogs: Seasons 3-5 under TMDb
	S2 / S3) or BETWEEN them (JUJUTSU KAISEN: Season 2 under a TMDb S2, between Season 1 at 0 and the Culling Game at 47).
	Rows are chained in TVDB order (season.tvdb, then its offset); a real row keeps its recorded offset, a stray one starts
	where the row before it ends (AniList episode count). Every guard must hold, else nothing changes:
	  - TMDb's season list known, `season` its last real one, every stray naming a season TMDb lacks and past `season`;
	  - every count a placement needs known (a stray at the very end may be airing: no count);
	  - a stray followed by a real row ends exactly where that row starts (JJK: 24 + 23 = 47, Fribb's own offset);
	  - an offset Fribb did record inside a stray season agrees with the counts;
	  - strays at the end: not past TMDb's episode count, and matching it exactly when the last count is known;
	  - outside widget calls, each stray's episode 1 (ani.zip, UTC) airs within 3 days of the TMDb episode it lands on.
	Only the Fribb index is read for a show with no row past `season` (no request)."""
	key = (tmdb_id, season, 'mixed')
	if key in _FLAT_PAIRS_CACHE: return list(_FLAT_PAIRS_CACHE[key])
	# index-only first: no Fribb row past this season -> nothing to fold in, and no request (this runs for every split
	# anime season a list or widget shows)
	def _later(r):
		try: return int((r.get('season') or {}).get('tmdb')) > season
		except (TypeError, ValueError): return False
	if not any(_later(r) for r in tmdb_tv_to_fribb_rows(tmdb_id)):
		_FLAT_PAIRS_CACHE[key] = []
		return []
	pairs = []
	try:
		# the show's cached meta first (its season_data is TMDb's season list) -- a request only for a show not cached
		cached = {}
		try:
			from caches.meta_cache import meta_cache
			cached = meta_cache.get('tvshow', 'tmdb_id', tmdb_id) or {}
		except Exception: cached = {}
		have = set(int(x['season_number']) for x in (cached.get('season_data') or []) if x.get('season_number') is not None) or None
		if have is None: have = _tmdb_season_numbers(tmdb_id)
		real_seasons = sorted(x for x in (have or ()) if x > 0)
		stray = []
		if real and real_seasons and real_seasons[-1] == season:
			for r in tmdb_tv_to_fribb_rows(tmdb_id):
				try: sn = int((r.get('season') or {}).get('tmdb'))
				except (TypeError, ValueError): continue
				if sn > season and sn not in have: stray.append(r)
		if stray:
			def _tv(r):
				si, oi = r.get('season') or {}, r.get('episode_offset') or {}
				tv_season = si.get('tvdb') if si.get('tvdb') is not None else si.get('tmdb')
				# TVDB's own offset only: a TMDb offset is another numbering (JJK's Culling Game part 1 has TMDb 47, part 2 TVDB 12)
				try: return (int(tv_season), int(oi.get('tvdb') or 0))
				except (TypeError, ValueError): return None
			items = [(_tv(r), off, r, False) for off, r in real] + [(_tv(r), None, r, True) for r in stray]
			if any(t is None for t, _o, _r, _s in items): raise ValueError('a row without a TVDB season')
			items.sort(key=lambda t: (t[0], t[1] if t[1] is not None else -1))
			chain = [r for _t, _o, r, _s in items]
			field = 'anilist_id' if all(r.get('anilist_id') for r in chain) else 'mal_id'
			from apis.anilist_api import anilist_episode_counts
			counts = anilist_episode_counts([r.get(field) for r in chain], by='id' if field == 'anilist_id' else 'mal') or {}
			def _count(r):
				try: return int(counts.get(int(r.get(field)), 0))
				except (TypeError, ValueError): return 0
			total = next((int(x.get('episode_count') or 0) for x in (cached.get('season_data') or []) if x.get('season_number') == season), 0)
			if not total: total = _tmdb_episode_count(tmdb_id, season) or 0
			out, why, prev = [], None, None      # prev: (offset, row) placed last
			season_starts = {}                   # stray TVDB season -> offset of its first row, for Fribb's in-season offsets
			for (tv_season, tv_off), recorded, r, is_stray in items:
				if not is_stray:
					if prev and prev[2] and _count(prev[1]) and prev[0] + _count(prev[1]) != recorded:
						why = 'stray %s ends at %d, the next recorded row starts at %d' % (prev[1].get(field), prev[0] + _count(prev[1]), recorded); break
					if prev and prev[2] and not _count(prev[1]):
						why = 'no count for stray %s before a recorded row' % prev[1].get(field); break
					if prev and recorded < prev[0]:
						why = 'recorded offsets out of TVDB order'; break
					prev = (recorded, r, False)
					out.append((recorded, r))
					continue
				if prev is None: why = 'a stray before every recorded row'; break
				n_prev = _count(prev[1])
				if n_prev <= 0: why = 'no count for %s' % prev[1].get(field); break
				start = prev[0] + n_prev
				season_starts.setdefault(tv_season, start)
				if tv_off and start - season_starts[tv_season] != tv_off:
					why = 'Fribb puts %s at %d inside its season, the counts at %d' % (r.get(field), tv_off, start - season_starts[tv_season]); break
				prev = (start, r, True)
				out.append((start, r))
			from modules.kodi_utils import external
			widget = external()
			stray_ids = set(id(r) for r in stray)
			saved_key = 'fribb_mixed_%s_%s' % (tmdb_id, season)
			dated = False
			if not why and not widget:
				# LOCAL PATCH 2026-10-16: air dates have the last word -- a stray whose episode 1 airs on another TMDb episode than
				# the counts gave moves there (an extra TMDb episode before a season premiere shifts it by one)
				out, date_why, dated = _date_placement(cached, season, out, stray_ids, counts_of=_count)
				if date_why: why = date_why
			elif not why and widget:
				# a widget call fetches no dates: the placement an in-addon call made from them, saved for a day, or the counts
				try:
					from caches.lists_cache import lists_cache
					raw_saved = lists_cache.get(saved_key)
					saved = dict((int(a), int(o)) for a, o in (raw_saved or []))
				except Exception: raw_saved, saved = None, {}
				if raw_saved == []: why = 'an in-addon call found no consistent air dates'
				elif saved and set(saved) == set(int(r.get('anilist_id') or 0) for _o, r in out):
					out, dated = [(saved[int(r['anilist_id'])], r) for _o, r in out], True
			if not why and prev and prev[2]:   # the chain ends on a stray: TMDb's count bounds it
				end_off, last_n = out[-1][0], _count(out[-1][1])
				# an airing last season may run past what TMDb lists so far -- only when air dates placed it
				if not total or end_off >= total or (last_n and end_off + last_n != total and not (dated and end_off + last_n > total)):
					why = 'strays end at %s, TMDb has %s' % (end_off + last_n if last_n else '?', total)
			if why:
				if not widget:
					try:
						from caches.lists_cache import lists_cache
						lists_cache.set(saved_key, [], expiration=24)   # widget calls follow the same verdict
					except Exception: pass
				_log_once(saved_key + '_no', 'tmdb %s s%s: %d rows in seasons TMDb lacks, no repair (%s)' % (tmdb_id, season, len(stray), why))
			else:
				pairs = out
				if not widget:
					try:
						from caches.lists_cache import lists_cache
						lists_cache.set(saved_key, [[int(r['anilist_id']), int(o)] for o, r in pairs if r.get('anilist_id')], expiration=24)
					except Exception: pass
				_log_once(saved_key, 'tmdb %s s%s: mixed flat-season repair via %s, offsets %s (%d rows from seasons TMDb lacks)'
						% (tmdb_id, season, 'air dates' if dated else 'anilist', [o for o, _r in pairs], len(stray)))
	except Exception as e:
		logger('fribb_mappings', 'tmdb %s s%s: mixed repair failed: %s' % (tmdb_id, season, e))
		pairs = []
	_FLAT_PAIRS_CACHE[key] = pairs
	return list(pairs)


def _flat_dated(tmdb_id, season, pairs):
	"""LOCAL PATCH 2026-10-16: the flat repair's cours moved by air date, as _mixed_flat_pairs' strays are -- cours placed
	by counts or an episode group are thrown off by a TMDb extra episode. In-addon calls read the dates and save the
	answer for a day; widget calls use that answer or the counts. A date that settles nothing leaves the repair as it was."""
	key = 'fribb_flat_%s_%s' % (tmdb_id, season)
	try:
		from modules.kodi_utils import external
		from caches.lists_cache import lists_cache
		ids = [int(r.get('anilist_id') or 0) for _o, r in pairs]
		if external():
			saved = dict((int(a), int(o)) for a, o in (lists_cache.get(key) or []))
			if saved and set(saved) == set(ids): return [(saved[int(r['anilist_id'])], r) for _o, r in pairs]
			return pairs
		from caches.meta_cache import meta_cache
		meta = meta_cache.get('tvshow', 'tmdb_id', tmdb_id) or {}
		from apis.anilist_api import anilist_episode_counts
		counts = anilist_episode_counts([i for i in ids if i], by='id') or {}
		moved, why, _d = _date_placement(meta, season, pairs, set(id(r) for _o, r in pairs[1:]),
				counts_of=lambda r: int(counts.get(int(r.get('anilist_id') or 0)) or 0))
		if why or moved == pairs:
			if why: _log_once(key + '_no', 'tmdb %s s%s: flat repair kept, air dates settle nothing (%s)' % (tmdb_id, season, why))
			lists_cache.set(key, [[int(r['anilist_id']), int(o)] for o, r in pairs if r.get('anilist_id')], expiration=24)
			return pairs
		lists_cache.set(key, [[int(r['anilist_id']), int(o)] for o, r in moved if r.get('anilist_id')], expiration=24)
		_log_once(key, 'tmdb %s s%s: flat repair moved by air dates, offsets %s -> %s' % (tmdb_id, season, [o for o, _r in pairs], [o for o, _r in moved]))
		return moved
	except Exception: return pairs


def _e1_date(row, tmdb_day=None, days=3):
	"""LOCAL PATCH 2026-10-25 (4.0.5): a Fribb row's episode-1 date for the cour checks -- AniList's startDate when it
	agrees with tmdb_day within `days` (or there is nothing to compare), else ani.zip's E1, the per-episode source these
	checks were built on (asking ani.zip for every row of every anime season list was slow). The two agree within 3 days
	almost always; ONAs (stream premiere before the broadcast ani.zip dates) disagree with TMDb's date, so they fall
	through to ani.zip and keep the exact answer."""
	from caches.anizip_mappings import anizip_entry_dates, air_dates_agree
	al = None
	if row.get('anilist_id'):
		try:
			from apis.anilist_api import anilist_start_dates
			al = anilist_start_dates([row['anilist_id']]).get(int(row['anilist_id']))
		except Exception: al = None
	if al and (not tmdb_day or air_dates_agree(al, tmdb_day, days)): return al
	return anizip_entry_dates(row.get('anilist_id'), row.get('anidb_id')).get(1) or al

def _date_placement(meta, season, out, stray_ids, counts_of):
	"""LOCAL PATCH 2026-10-16: `out` with each stray row moved to the TMDb episode its episode 1 aired on -> (out, why, moved).

	A stray whose episode 1 (ani.zip, UTC) airs within 3 days of the TMDb episode the counts gave stays. Otherwise it moves
	-- with every stray after it -- to the ONE TMDb episode airing within 3 days of that date, at most 3 episodes away;
	anything else (no such episode, several, too far) is `why` and no repair. A move may not run into the recorded row
	after it. A missing date is no evidence: that stray stays where the counts put it."""
	try:
		from modules.metadata import episodes_meta, tmdb_air_day
		from caches.anizip_mappings import air_dates_agree
		dates = {}
		for e in episodes_meta(season, meta) or []:
			try: dates[int(e.get('episode'))] = tmdb_air_day(e)   # LOCAL PATCH 2026-10-25: TMDb's day, not a dub-shifted one
			except (TypeError, ValueError): continue
		out, shift, moved = list(out), 0, False
		# the anchor first: the season's first row airs with TMDb's E1, or Fribb's rows describe some other season (Monogatari
		# S5 on TMDb is OFF & MONSTER, while Fribb files Owarimonogatari Second Season there)
		anchor = _e1_date(out[0][1], dates.get(out[0][0] + 1)) if out else None   # LOCAL PATCH 2026-10-25 (4.0.5): see _e1_date
		if anchor and dates.get(out[0][0] + 1) and not air_dates_agree(anchor, dates[out[0][0] + 1], 3):
			return out, 'the first row %s aired %s, TMDb E%d %s' % (out[0][1].get('anilist_id'), anchor, out[0][0] + 1, dates[out[0][0] + 1]), moved
		for i, (off, r) in enumerate(out):
			if id(r) not in stray_ids:
				if shift and i and out[i - 1][0] + (counts_of(out[i - 1][1]) or 0) > off:
					return out, 'a moved stray runs into the recorded row at %d' % off, moved
				shift = 0   # a recorded row anchors what follows
				continue
			off += shift
			first = _e1_date(r, dates.get(off + 1))   # LOCAL PATCH 2026-10-25 (4.0.5): see _e1_date
			if first and dates.get(off + 1) and not air_dates_agree(first, dates[off + 1], 3):
				near = [e for e, d in dates.items() if d and air_dates_agree(first, d, 3)]
				if len(near) != 1 or abs(near[0] - 1 - off) > 3:
					return out, '%s ep 1 aired %s, TMDb E%d %s' % (r.get('anilist_id'), first, off + 1, dates.get(off + 1)), moved
				shift += near[0] - 1 - off
				off = near[0] - 1
			if off != out[i][0]: moved = True
			out[i] = (off, r)
		return out, None, moved or any(id(r) in stray_ids for _o, r in out)
	except Exception: return out, None, False


_LOGGED = {}

def _log_once(key, message):
	"""LOCAL PATCH 2026-10-16: a repair's log line once a day per show / season and outcome, not once per Kodi process
	(JJK's logged 11 times in 3 minutes) -- the day is held in a window property, shared by every process."""
	try:
		import datetime
		from modules.kodi_utils import get_property, set_property
		day, prop = datetime.date.today().isoformat(), 'deadlight.fribb_log.%s' % key
		if _LOGGED.get(key) == day or get_property(prop) == day: return
		_LOGGED[key] = day
		set_property(prop, day)
	except Exception: pass
	logger('fribb_mappings', message)


def _season_cour_rows(tmdb_id, season, allow_repair=True):
	"""[(episode_offset, row), ...] for one TMDb season, sorted by offset.

	Shared by find_cour_by_tmdb_coords() and cours_for_tmdb_season(). A row with no episode_offset is the season's first
	cour, i.e. offset 0. allow_repair=False returns Fribb's RAW rows, skipping the flat-season repair (the scrape path --
	see the note on that branch in the uncached body).
	"""
	# LOCAL PATCH 2026-09-04: memoised per (tmdb_id, season): find_cour_by_tmdb_coords calls this once per EPISODE and
	# only `episode` varies. Cleared by clear_cache().
	# LOCAL PATCH 2026-09-05: allow_repair IS PART OF THE KEY. It changes the answer, and modules/sources.py picks files
	# out of a pack (repair off) in the same process that renders results (repair on).
	try: season = int(season)
	except (TypeError, ValueError): return []
	memo_key = (tmdb_id, season, bool(allow_repair))
	if memo_key in _SEASON_ROWS_CACHE: return list(_SEASON_ROWS_CACHE[memo_key])
	# LOCAL PATCH 2026-10-19: a re-entry guard. The flat repair dates its cours (_flat_dated -> _date_placement) through
	# metadata.episodes_meta; on an uncached season that calls _anilist_air_times -> find_cour_by_tmdb_coords -> HERE for
	# the same season, round and round until the C stack runs out (Kodi dies with 0xc0000409, no Python error). A nested ask
	# for the season this thread is computing gets [] (not memoised): _anilist_air_times then leaves the season unstamped,
	# so its next read redoes the air times with the finished rows.
	busy = _ROWS_IN_PROGRESS.__dict__.setdefault('keys', set())
	if memo_key in busy: return []
	busy.add(memo_key)
	try: result = _season_cour_rows_uncached(tmdb_id, season, allow_repair)
	finally: busy.discard(memo_key)
	_SEASON_ROWS_CACHE[memo_key] = result
	return list(result)


def _checked_offsets(tmdb_id, season, out):
	"""LOCAL PATCH 2026-10-16: Fribb's recorded offsets for a split TMDb season, put right by AniList's episode counts when
	they disagree and the counts tile TMDb's season exactly -- else `out` as it was.

	Tokyo Revengers (one TMDb season of 50): Fribb records Season 3 at 36, but Season 2 has 13 episodes, so it starts at 37.
	Rows at or past the season's end (a not-yet-aired season) hold none of its episodes and are left as they are. Guards:
	every count known but the last's, and either the sum equal to TMDb's count or the counts landing on Fribb's own last
	offset. Widget calls read only counts already cached (no request on a widget burst)."""
	try:
		if len(out) < 2: return out
		total = None
		try:
			from caches.meta_cache import meta_cache
			meta = meta_cache.get('tvshow', 'tmdb_id', tmdb_id) or {}
			total = next((int(s.get('episode_count') or 0) for s in (meta.get('season_data') or []) if s.get('season_number') == season), 0) or None
		except Exception: total = None
		if not total: return out
		inside = [(o, r) for o, r in out if o < total]
		beyond = [(o, r) for o, r in out if o >= total]
		if len(inside) < 2 or not all(r.get('anilist_id') for _o, r in inside): return out
		from modules.kodi_utils import external
		from apis.anilist_api import anilist_episode_counts
		counts = anilist_episode_counts([r['anilist_id'] for _o, r in inside], by='id', cached_only=external()) or {}
		offsets, running = [0], 0
		for _o, r in inside[:-1]:
			n = int(counts.get(int(r['anilist_id'])) or 0)
			if n <= 0: return out
			running += n
			offsets.append(running)
		if offsets == [o for o, _r in inside]: return out
		last = int(counts.get(int(inside[-1][1]['anilist_id'])) or 0)
		if running >= total: return out
		# accepted when the counts tile TMDb's season exactly, or -- the last cour still airing, so TMDb lists only part of it
		# -- when they land on Fribb's own LAST offset: both ends agree and only a middle one is wrong
		if not ((last and running + last == total) or running == inside[-1][0]): return out
		logger('fribb_mappings', 'tmdb %s s%s: Fribb offsets %s disagree with AniList counts -> %s'
				% (tmdb_id, season, [o for o, _r in inside], offsets))
		return [(off, r) for off, (_o, r) in zip(offsets, inside)] + beyond
	except Exception: return out


def _season_cour_rows_uncached(tmdb_id, season, allow_repair=True):
	rows = tmdb_tv_to_fribb_rows(tmdb_id)
	if not rows: return []
	# LOCAL PATCH 2026-10-17: TMDb's Specials season is mapped by air date (_season0_rows), in both modes -- Fribb's own
	# season-0 offsets are mostly absent
	if season == 0:
		mapped = _season0_rows(tmdb_id)
		if mapped: return mapped
	out = []
	for r in rows:
		s = (r.get('season') or {}).get('tmdb')
		if s is None: continue
		try:
			if int(s) != season: continue
		except (TypeError, ValueError): continue
		off = (r.get('episode_offset') or {}).get('tmdb') or 0
		try: off = int(off)
		except (TypeError, ValueError): off = 0
		out.append((off, r))
	out.sort(key=lambda t: t[0])
	# LOCAL PATCH 2026-10-17: rows that describe another season are no rows at all (_anchor_ok), in both modes -- unless
	# the entry for THIS season is filed under a season TMDb lacks (_misfiled_swap)
	if out and not _anchor_ok(tmdb_id, season, out[0]):
		out = _misfiled_swap(tmdb_id, season)
		if not out: return []
	out = _checked_offsets(tmdb_id, season, out)   # LOCAL PATCH 2026-10-16
	# LOCAL PATCH 2026-09-01: fewer than two rows can mean the season genuinely is not split, or that Fribb scattered its
	# cours across TMDb seasons that do not exist. _flattened_cour_pairs tells the two apart, free for the former.
	# LOCAL PATCH 2026-09-05: DISPLAY ONLY -- the scrape path passes allow_repair=False. The repair turns a TMDb episode
	# number into a cour-relative one plus a cour_season, right for labelling but not the numbering release groups use for
	# a flat TMDb season (Solo Leveling ep 20 would be asked as S2E8). Scrapers get Fribb's raw coordinates.
	result = out
	if allow_repair and len(out) < 2:
		repaired = _flattened_cour_pairs(tmdb_id, season)
		if len(repaired) > 1: result = _flat_dated(tmdb_id, season, repaired)
	# LOCAL PATCH 2026-10-16: the season is split, but later seasons were folded into it as well (_mixed_flat_pairs)
	if result is out and allow_repair and out:
		mixed = _mixed_flat_pairs(tmdb_id, season, out)
		if mixed: result = mixed
	# LOCAL PATCH 2026-10-16: then the entries Fribb has not added yet, by air date (_tail_entries) -- display / sync only
	if allow_repair and result:
		tail = _tail_entries(tmdb_id, season, result)
		if tail: result = list(result) + tail
	return result


_TAIL_BUSY = threading.local()   # LOCAL PATCH 2026-10-16: _tail_entries' re-entry guard, per thread


_ANCHOR_BUSY = threading.local()


def _anchor_ok(tmdb_id, season, first):
	"""LOCAL PATCH 2026-10-17: False when the first Fribb row of a TMDb season airs more than a year away from that season's
	episode (ani.zip vs TMDb dates) -- Fribb then describes some OTHER season, and none of its rows are used.

	Monogatari S5 is OFF & MONSTER (2024) on TMDb; Fribb files Owarimonogatari Second Season (2017) there, so the raw rows
	sent scrapers searching 2017 episodes. A missing date is no evidence: True. The verdict is kept a week (lists cache);
	widget calls read only that, never a request. Re-entry guard: reading the season's dates can come back here."""
	key = (tmdb_id, season, 'anchor')
	if key in _FLAT_PAIRS_CACHE: return _FLAT_PAIRS_CACHE[key]
	busy = getattr(_ANCHOR_BUSY, 'keys', None)
	if busy is None: busy = _ANCHOR_BUSY.keys = set()
	if key in busy: return True
	busy.add(key)
	ok, saved_key = True, 'fribb_anchor_%s_%s' % (tmdb_id, season)
	try:
		off, row = first
		if not (row.get('anilist_id') or row.get('anidb_id')): return True
		from modules.kodi_utils import external
		from caches.lists_cache import lists_cache
		saved = lists_cache.get(saved_key)
		if saved is not None: ok = bool(saved)
		elif not external():
			# TMDb's SEASON date (the cached show details), not its episode list -- building an uncached anime season is
			# AniList + Trakt + TVmaze work, for every season of a season list. So only a first row that starts the season
			# (offset 0) is judged -- the misfiled case -- one ani.zip date each, cached.
			if off: return True
			from caches.meta_cache import meta_cache
			from caches.anizip_mappings import air_dates_agree
			meta = meta_cache.get('tvshow', 'tmdb_id', tmdb_id) or {}
			tmdb_day = next(((x.get('air_date') or '')[:10] for x in (meta.get('season_data') or []) if x.get('season_number') == season), None)
			first_day = _e1_date(row, tmdb_day, 365) if tmdb_day else None   # LOCAL PATCH 2026-10-25 (4.0.5): AniList first, see _e1_date
			# a year, not days: one release of the SAME season can lead another by weeks to months (a prologue, a streaming
			# premiere, a partial first broadcast). A misfiled season is years away (Monogatari S5: 7).
			ok = not (first_day and tmdb_day and not air_dates_agree(first_day, tmdb_day, 365))
			lists_cache.set(saved_key, ok, expiration=168)
			if not ok:
				_log_once(saved_key, 'tmdb %s s%s: Fribb\'s rows describe another season (AniList %s ep 1 aired %s, TMDb E%d %s) -- not used'
						% (tmdb_id, season, row.get('anilist_id'), first_day, off + 1, tmdb_day))
	except Exception: ok = True
	finally: busy.discard(key)
	_FLAT_PAIRS_CACHE[key] = ok
	return ok


_SWAP_BUSY = threading.local()


def _misfiled_swap(tmdb_id, season):
	"""LOCAL PATCH 2026-10-17: [(0, row)] -- the Fribb entry that IS this TMDb season, filed under a season TMDb lacks -- or
	[]. Asked only when _anchor_ok rejected the season's own rows.

	Monogatari: Fribb files OFF & MONSTER (TMDb S5) under season 6, which TMDb lacks. Its ep 1 date is no help (ani.zip
	gives the TV broadcast, TMDb the streaming premiere), but later episodes match TMDb's dates. So a candidate's episodes
	are compared with TMDb's at the same number (within 2 days), and it is taken when at least 3 and at least half of the
	pairs with both dates agree; one candidate only. In-addon calls read the dates and keep the answer a week; widget calls
	read only that. Re-entry guard: this season's episode list comes back through here."""
	key = (tmdb_id, season, 'swap')
	if key in _FLAT_PAIRS_CACHE: return list(_FLAT_PAIRS_CACHE[key])
	busy = getattr(_SWAP_BUSY, 'keys', None)
	if busy is None: busy = _SWAP_BUSY.keys = set()
	if key in busy: return []
	busy.add(key)
	out, saved_key = [], 'fribb_swap_%s_%s' % (tmdb_id, season)
	try:
		from modules.kodi_utils import external
		from caches.lists_cache import lists_cache
		rows = tmdb_tv_to_fribb_rows(tmdb_id)
		def _ident(r): return [r.get('anilist_id'), r.get('mal_id'), r.get('anidb_id')]
		saved = lists_cache.get(saved_key)
		if saved is not None or external():
			row = next((r for r in rows if saved and _ident(r) == saved), None)
		else:
			from caches.meta_cache import meta_cache
			from modules.metadata import episodes_meta, tmdb_air_day
			from caches.anizip_mappings import anizip_entry_dates, air_dates_agree
			meta = meta_cache.get('tvshow', 'tmdb_id', tmdb_id) or {}
			have = set(x.get('season_number') for x in (meta.get('season_data') or []))
			# LOCAL PATCH 2026-10-25: TMDb's own days (metadata.tmdb_air_day), not dub-shifted ones
			days = dict((int(x['episode']), tmdb_air_day(x)) for x in (episodes_meta(season, meta) or []) if x.get('episode'))
			hits = []
			for r in rows:
				try: sn = int((r.get('season') or {}).get('tmdb'))
				except (TypeError, ValueError): continue
				if sn == 0 or sn in have or not (r.get('anilist_id') or r.get('anidb_id')): continue
				theirs = anizip_entry_dates(r.get('anilist_id'), r.get('anidb_id'))
				pairs = [(d, days[n]) for n, d in theirs.items() if d and days.get(n)]
				agree = sum(1 for a, b in pairs if air_dates_agree(a, b, 2))
				if agree >= 3 and agree * 2 >= len(pairs): hits.append(r)
			row = hits[0] if len(hits) == 1 else None
			lists_cache.set(saved_key, _ident(row) if row else [], expiration=168)
			if row:
				_log_once(saved_key, 'tmdb %s s%s: Fribb files this season under TMDb S%s -- AniList %s used (episode air dates agree)'
						% (tmdb_id, season, (row.get('season') or {}).get('tmdb'), row.get('anilist_id') or row.get('anidb_id')))
		# filed under this TMDb season from here on (its TVDB season, which releases use, stays): left at 6, the mixed-flat
		# repair read it as 'a row in a season TMDb lacks' and logged a no-repair every time
		if row: out = [(0, dict(row, season=dict(row.get('season') or {}, tmdb=season)))]
	except Exception as e:
		logger('fribb_mappings', 'tmdb %s s%s: misfiled-season swap failed: %s' % (tmdb_id, season, e))
		out = []
	finally: busy.discard(key)
	_FLAT_PAIRS_CACHE[key] = out
	return list(out)


def _tail_entries(tmdb_id, season, rows):
	"""LOCAL PATCH 2026-10-16: [(offset, row), ...] for the AniList entries holding the episodes of a TMDb season past
	Fribb's last row, found by air date -- or [].

	Fribb adds a new season days or weeks after it starts; until then everything reads its episodes as 'episode 13+' of
	the entry before. The scrape and the AniList / MAL scrobble already find these per episode
	(apis.anilist_api.anilist_entry_for_tmdb_episode); this gives everything else the same answer.

	From the end of the last row (its AniList episode count): the AniList entry STARTING on the air date of the next TMDb
	episode (anilist_for_tmdb_season: by title, within 10 days, one candidate or the only one within a day), then on from
	its end, at most 3 entries. An entry Fribb already has for the show ends it, as does any miss. The rows are marked
	'_synthetic' and carry no Kitsu / AniDB ids; the scrape's past-the-end retry ignores them (its own lookup adds ani.zip's
	ids). Never on a widget call -- each step is an AniList search on a cold cache."""
	key = (tmdb_id, season, 'tail')
	if key in _FLAT_PAIRS_CACHE: return list(_FLAT_PAIRS_CACHE[key])
	# re-entry guard: the air dates below come from metadata.episodes_meta, which -- building an anime season -- asks the
	# cour mapping, which comes back here; unguarded, an uncached season loops. The inner call answers [] and is not
	# memoised; the outer one finishes with the dates.
	busy = getattr(_TAIL_BUSY, 'keys', None)
	if busy is None: busy = _TAIL_BUSY.keys = set()
	if key in busy: return []
	busy.add(key)
	out = []
	saved_key = 'fribb_tail_%s_%s' % (tmdb_id, season)
	try:
		from modules.kodi_utils import external
		from caches.lists_cache import lists_cache
		if external():
			# a widget call searches nothing: what an in-addon call found for this season, saved for a day
			saved = lists_cache.get(saved_key) or []
			out = [(int(o), {'anilist_id': int(a), 'mal_id': m, 'season': {'tmdb': season}, 'episode_offset': {'tmdb': int(o)},
					'_synthetic': True}) for a, m, o in saved]
			return list(out)
		last_off, last = rows[-1]
		if not last.get('anilist_id'): return []
		from caches.meta_cache import meta_cache
		meta = meta_cache.get('tvshow', 'tmdb_id', tmdb_id) or {}
		total = next((int(x.get('episode_count') or 0) for x in (meta.get('season_data') or []) if x.get('season_number') == season), 0)
		if not total: return []
		from apis.anilist_api import anilist_episode_counts, anilist_for_tmdb_season, _tmdb_episode_air_date
		n = int((anilist_episode_counts([last['anilist_id']], by='id') or {}).get(int(last['anilist_id'])) or 0)
		if not n or last_off + n >= total: return []
		known = set(int(r['anilist_id']) for r in tmdb_tv_to_fribb_rows(tmdb_id) if r.get('anilist_id'))
		titles = [meta.get('tvshowtitle') or meta.get('title'), meta.get('original_title')]
		off = last_off + n
		for _hop in range(3):
			date = _tmdb_episode_air_date(meta, season, off + 1)
			if not date: break
			found = anilist_for_tmdb_season(titles, date) or {}
			if not found.get('anilist') or int(found['anilist']) in known: break
			out.append((off, {'anilist_id': int(found['anilist']), 'mal_id': found.get('mal'), 'season': {'tmdb': season},
							'episode_offset': {'tmdb': off}, '_synthetic': True}))
			known.add(int(found['anilist']))
			if not found.get('episodes'): break   # airing: runs to the season's end
			off += int(found['episodes'])
			if off >= total: break
		lists_cache.set(saved_key, [[r['anilist_id'], r.get('mal_id'), o] for o, r in out], expiration=24)
		if out:
			_log_once(saved_key, 'tmdb %s s%s: past Fribb\'s last entry (E%d of %d) -- by air date %s'
					% (tmdb_id, season, last_off + n, total, ', '.join('AniList %s from E%d' % (r['anilist_id'], o + 1) for o, r in out)))
	except Exception as e:
		logger('fribb_mappings', 'tmdb %s s%s: tail lookup failed: %s' % (tmdb_id, season, e))
		out = []
	finally: busy.discard(key)
	_FLAT_PAIRS_CACHE[key] = out
	return list(out)


_SPECIAL_TAIL_RE = re.compile(r'\s*(?:\(\d+\)|\b[IVX]+\b|\b\d+\b|part\s*\d+)\s*$', re.I)


def special_stem(name):
	"""LOCAL PATCH 2026-10-17: what a run of specials shares in its episode names -- 'Hanamonogatari: Suruga Devil (3)' ->
	'Hanamonogatari', 'Summary II' -> 'Summary', 'Tsubasa Cat (4)' -> 'Tsubasa Cat'. Shared by the season list's specials
	rows (indexers.seasons._special_rows) and _season0_rows, so both draw the same groups."""
	name = (name or '').strip()
	if ':' in name: return name.split(':', 1)[0].strip()
	stem = _SPECIAL_TAIL_RE.sub('', name).strip(' -.')
	return stem or name


def _name_key(name):
	"""LOCAL PATCH 2026-10-17: a name for exact comparison -- lower case, letters and digits only ('Zoku Owarimonogatari'
	== 'zoku owarimonogatari'; 'Complete Movie' -> 'completemovie')."""
	return re.sub(r'[^a-z0-9]', '', (name or '').lower())


def special_groups(episodes):
	"""[{'stem', 'eps': [...], 'last'}] -- runs of consecutive (by number) specials sharing a stem, in episode order."""
	groups = []
	for e in sorted((e for e in (episodes or []) if e.get('episode')), key=lambda e: int(e['episode'])):
		stem = special_stem(e.get('title'))
		if groups and groups[-1]['stem'].lower() == stem.lower() and int(e['episode']) == groups[-1]['last'] + 1:
			groups[-1]['eps'].append(e)
			groups[-1]['last'] = int(e['episode'])
		else: groups.append({'stem': stem, 'eps': [e], 'last': int(e['episode'])})
	return groups


_S0_BUSY = threading.local()


def _season0_rows(tmdb_id):
	"""LOCAL PATCH 2026-10-17: [(offset, row), ...] for TMDb's season 0: each run of specials (special_groups) at its first
	episode, holding the Fribb row -- from ANY season -- whose episode 1 aired within 3 days of the run's (ani.zip dates),
	else the one free entry whose ani.zip title IS the run's name; a run nothing matches holds an empty placeholder row
	(find_cour_by_tmdb_coords answers None there), so a neighbour's ids never reach it. [] when nothing matched -- Fribb's
	raw rows then stand.

	Needed because Fribb's season-0 rows mostly carry no offsets, so every special read as an episode of one entry.
	In-addon calls read the dates and save the map a day; widget calls use the saved map only. A re-entry guard as
	_tail_entries': building season 0's episode list comes back through here."""
	key = (tmdb_id, 0, 's0')
	if key in _FLAT_PAIRS_CACHE: return list(_FLAT_PAIRS_CACHE[key])
	busy = getattr(_S0_BUSY, 'keys', None)
	if busy is None: busy = _S0_BUSY.keys = set()
	if key in busy: return []
	busy.add(key)
	out, saved_key = [], 'fribb_s0_%s' % tmdb_id
	try:
		from modules.kodi_utils import external
		from caches.lists_cache import lists_cache
		fribb = tmdb_tv_to_fribb_rows(tmdb_id)
		def _ident(r): return [r.get('anilist_id'), r.get('mal_id'), r.get('anidb_id')]
		def _placeholder(off): return {'_placeholder': True, 'season': {'tmdb': 0}, 'episode_offset': {'tmdb': off}}
		if external():
			for item in (lists_cache.get(saved_key) or []):
				off, ident, base = (list(item) + [None])[:3]
				row = next((r for r in fribb if ident and _ident(r) == ident), None)
				if row is not None and base is not None: row = dict(row, _ep_base=int(base))
				out.append((int(off), row if row is not None else _placeholder(int(off))))
		else:
			from caches.meta_cache import meta_cache
			meta = meta_cache.get('tvshow', 'tmdb_id', tmdb_id) or {}
			if not any(s.get('season_number') == 0 for s in (meta.get('season_data') or [])): return []   # 0 is falsy: compared directly
			from modules.metadata import episodes_meta, tmdb_air_day
			from caches.anizip_mappings import anizip_entry_dates, anizip_entry_titles, air_dates_agree
			groups = special_groups(episodes_meta(0, meta) or [])
			dated = []
			for r in fribb:
				first = anizip_entry_dates(r.get('anilist_id'), r.get('anidb_id')).get(1) if (r.get('anilist_id') or r.get('anidb_id')) else None
				if first: dated.append((first, r))
			# Fribb's own season-0 rows, as the raw lookup reads them (offset order), for the runs no date matches
			raw = sorted(((int((r.get('episode_offset') or {}).get('tmdb') or 0), r) for r in fribb
						if str((r.get('season') or {}).get('tmdb')) == '0'), key=lambda t: t[0])
			def _raw_row(ep):
				for i, (o, r) in enumerate(raw):
					nxt = raw[i + 1][0] if i + 1 < len(raw) else float('inf')
					if o < ep <= nxt: return o, r
				return None, None
			# a run may only take an entry no regular season holds: Fribb's season 0, a season TMDb lacks, or one where the entry
			# does not air with that season's episode (misfiled). Shorts airing alongside the main run share its dates -- by date
			# alone they took the main Season 1
			have = set(x.get('season_number') for x in (meta.get('season_data') or []))
			season_days = {}
			def _free(r, first):
				try: sn = int((r.get('season') or {}).get('tmdb'))
				except (TypeError, ValueError): return False
				if sn == 0 or sn not in have: return True
				if sn not in season_days:
					season_days[sn] = dict((int(x['episode']), tmdb_air_day(x)) for x in (episodes_meta(sn, meta) or []) if x.get('episode'))   # LOCAL PATCH 2026-10-25
				own = season_days[sn].get(int((r.get('episode_offset') or {}).get('tmdb') or 0) + 1)
				return bool(own) and not air_dates_agree(first, own, 3)
			picks, groups_by_off = [], dict((int(g['eps'][0]['episode']) - 1, g) for g in groups)
			for g in groups:
				off = int(g['eps'][0]['episode']) - 1
				day = (g['eps'][0].get('premiered') or '')[:10]
				hits = [r for d, r in dated if day and air_dates_agree(d, day, 3) and _free(r, d)] if day else []
				picks.append((off, hits[0] if len(hits) == 1 else None))
			# a run no date matched may take an unclaimed free entry by NAME: the run's stem equal to one of the entry's ani.zip
			# titles (English / romaji), one such entry only -- for parts ani.zip dates all with a cinema release (Zoku
			# Owarimonogatari). The entry must have the run's length, or one more when ani.zip's ep 1 is the complete movie.
			# Counted 1:1 either way: releases number the parts 01-06 and AnimeTosho files each under that AniDB episode.
			picked = set(id(r) for _o, r in picks if r is not None)
			for i, (off, r) in enumerate(picks):
				if r is not None: continue
				g = groups_by_off[off]
				stem = _name_key(g['stem'])
				if not stem: continue
				hits = []
				for c in fribb:
					if id(c) in picked or not (c.get('anilist_id') or c.get('anidb_id')): continue
					info = anizip_entry_titles(c.get('anilist_id'), c.get('anidb_id'))
					if not any(_name_key(t) == stem for t in info.get('titles') or []): continue
					first = anizip_entry_dates(c.get('anilist_id'), c.get('anidb_id')).get(1)
					if not _free(c, first): continue
					count, run = int(info.get('count') or 0), len(g['eps'])
					if count == run or (count == run + 1 and _name_key(info.get('ep1_title')) == 'completemovie'): hits.append(c)
				if len(hits) == 1:
					picks[i] = (off, hits[0])
					picked.add(id(hits[0]))
			claimed = picked
			matched = len(claimed)
			for off, r in picks:
				if r is None:
					# no date match: Fribb's raw row still stands unless another run claimed it (that is the leak)
					raw_off, r = _raw_row(off + 1)
					# a claimed entry stays only on its own episode's evidence: that episode (ani.zip) airing with this special (each of
					# One-Punch Man's OVAs keeps its id this way; shorts that do not air with the one season-0 entry go without ids). So
					# does a row Fribb gave no TMDb offset: it was never placed, and the raw lookup would read it as starting at E1.
					if r is not None and (id(r) in claimed or 'tmdb' not in (r.get('episode_offset') or {})):
						day = (groups_by_off[off]['eps'][0].get('premiered') or '')[:10]
						own = anizip_entry_dates(r.get('anilist_id'), r.get('anidb_id')).get(off + 1 - raw_off)
						if not (day and own and air_dates_agree(own, day, 3)): r = None
					# counted from its OWN start, as the raw lookup did (S0E10 is episode 10 of the catch-all, kitsu:14129:10)
					r = _placeholder(off) if r is None else dict(r, _ep_base=raw_off)
				out.append((off, r))
			if not matched: out = []
			lists_cache.set(saved_key, [[o, None if r.get('_placeholder') else _ident(r), r.get('_ep_base')] for o, r in out], expiration=24)
			if out:
				_log_once(saved_key, 'tmdb %s s0: specials mapped by air date -- %s' % (tmdb_id, ', '.join('E%d %s' % (o + 1,
					r.get('anilist_id') or r.get('mal_id') or r.get('anidb_id')) for o, r in out if not r.get('_placeholder'))))
	except Exception as e:
		logger('fribb_mappings', 'tmdb %s s0: specials map failed: %s' % (tmdb_id, e))
		out = []
	finally: busy.discard(key)
	_FLAT_PAIRS_CACHE[key] = out
	return list(out)


def cours_for_tmdb_season(tmdb_id, season, season_episode_count):
	"""Cours making up one TMDb season, or [] when it is not split.

	LOCAL PATCH 2026-08-27. TMDb's season layout is often not how the show aired: Frieren is one TMDb season of 38 but
	two cours of 28 and 10, so TMDb E30 is cour 2 E2. Fribb records the boundaries offline.

	Each entry: {'index', 'offset', 'length', 'mal', 'kitsu', 'anilist'}; the cour covers TMDb episodes
	offset+1 .. offset+length and its own numbering is tmdb_episode - offset.

	Returns [] for a single cour so unsplit seasons keep today's code path.
	"""
	try: season_episode_count = int(season_episode_count)
	except (TypeError, ValueError): return []
	if season_episode_count < 2: return []
	pairs = _season_cour_rows(tmdb_id, season)
	if len(pairs) < 2: return []
	# Drop offsets at or past the end of the season: Fribb lists a cour as soon as it is announced, so an unaired one has
	# an offset equal to the current episode count and would make a zero-length cour.
	pairs = [(off, r) for off, r in pairs if 0 <= off < season_episode_count]
	if len(pairs) < 2: return []
	cours = []
	for i, (off, row) in enumerate(pairs):
		nxt = pairs[i + 1][0] if i + 1 < len(pairs) else season_episode_count
		length = nxt - off
		if length <= 0: continue
		cours.append({
			'index': len(cours) + 1,
			'offset': off,
			'length': length,
			'mal': row.get('mal_id'),
			'kitsu': row.get('kitsu_id'),
			'anilist': row.get('anilist_id'),
		})
	# One usable cour means the season is not actually split.
	return cours if len(cours) > 1 else []


def find_cour_by_tmdb_coords(tmdb_id, season, episode, allow_repair=True):
	"""Given TMDb (show, season, ep) coords, find which anime cour that episode
	belongs to. Returns {mal, kitsu, anilist, cour_ep, mal_title, row} or None.

	allow_repair=False skips the flat-season repair, so the answer comes only from coordinates Fribb records -- the
	SCRAPE path (see the repair branch in _season_cour_rows_uncached). Everything that labels or syncs keeps the default.

	The row at offset O covers (O, next row's offset]; the last row runs to the end. `cour_ep` is the episode RELATIVE
	TO THAT COUR (torrentio's `stream/series/kitsu:<kitsu>:<cour_ep>.json`).
	Example: Slime tmdb=82684 S2 rows at offsets 0 (mal 39551) and 12 (mal 41487) -> E13 is mal 41487, cour_ep 1."""
	if tmdb_id is None or season is None or episode is None: return None
	try:
		tmdb_id, season, episode = int(tmdb_id), int(season), int(episode)
	except (TypeError, ValueError): return None
	same_season = _season_cour_rows(tmdb_id, season, allow_repair)
	if not same_season: return None
	# Find the row whose (offset, next_offset) window contains episode.
	# Episode is 1-indexed. Row at offset O covers eps [O+1, next_O] inclusive.
	# For the last row, upper bound is infinity.
	chosen = None
	chosen_index = 0
	for i, (off, r) in enumerate(same_season):
		next_off = same_season[i + 1][0] if i + 1 < len(same_season) else float('inf')
		if off < episode <= next_off:
			chosen, chosen_index = (off, r), i; break
	if not chosen:
		# Episode below first offset — shouldn't happen for legit inputs; fall back to first row.
		chosen, chosen_index = same_season[0], 0
	off, row = chosen
	if row.get('_placeholder'): return None   # LOCAL PATCH 2026-10-17: a run of specials no entry matched (_season0_rows)
	# LOCAL PATCH 2026-08-27: `cour_season` is the season number RELEASES use: season.tvdb, not season.tmdb. TMDb often
	# files several cours under one season while tvdb numbers them as fansub groups do (Re:ZERO tmdb 1 for every cour, tvdb
	# 1, 2, 2, 3, 4). Scrapers need it to read an "S02"/"2nd Season" marker. Falls back to the tmdb season.
	season_info = row.get('season') or {}
	cour_season = season_info.get('tvdb')
	if cour_season is None: cour_season = season_info.get('tmdb')
	try: cour_season = int(cour_season)
	except (TypeError, ValueError): cour_season = None
	# LOCAL PATCH 2026-08-27: a tvdb season can span SEVERAL Fribb cours, and releases keep counting across them (Re:ZERO
	# TMDb E50 is cour_ep 12 but '2nd Season - 24'). So `season_ep` counts from the FIRST cour of this tvdb season; for a
	# single-cour season they are equal.
	season_ep = None
	if cour_season is not None:
		starts = []
		for _o, _r in same_season:
			_si = _r.get('season') or {}
			_ts = _si.get('tvdb')
			if _ts is None: _ts = _si.get('tmdb')
			try: _ts = int(_ts)
			except (TypeError, ValueError): continue
			if _ts == cour_season: starts.append(_o)
		if starts: season_ep = episode - min(starts)
	# LOCAL PATCH 2026-10-03: how many episodes that release season holds -- its first cour's offset to the next season's.
	# A 'Season 1 (Batch)' carries no range, and TMDb's episode_count is no measure of it when TMDb files several seasons
	# under S1. None for a season with no later cour (the caller can bound it with TMDb).
	season_len = None
	if cour_season is not None and starts:
		later = [_o for _o, _r in same_season if _o > max(starts)]
		if later: season_len = min(later) - min(starts)
	# Which cour of this tvdb season we are in, and how many there are: a batch labelled 'Part 1' cannot hold a Part 2
	# episode, and batches carry no episode numbers. Only meaningful when the season really is split.
	cour_part = cour_part_count = None
	if cour_season is not None and starts:
		ordered = sorted(set(starts))
		cour_part_count = len(ordered)
		if off in ordered: cour_part = ordered.index(off) + 1
	return {
		'mal': row.get('mal_id'),
		'kitsu': row.get('kitsu_id'),
		'anilist': row.get('anilist_id'),
		'anidb': row.get('anidb_id'),
		'cour_ep': episode - row.get('_ep_base', off),   # LOCAL PATCH 2026-10-17: _season0_rows' fallback rows
		'season_ep': season_ep,
		'season_len': season_len,
		'season_start': min(starts) if cour_season is not None and starts else None,
		'cour_part': cour_part,
		'cour_part_count': cour_part_count,
		'cour_season': cour_season,
		'cour_index': chosen_index + 1,
		'row': row,
	}
