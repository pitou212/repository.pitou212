# -*- coding: utf-8 -*-
import re
import json
import base64
import time
from threading import Thread
from functools import lru_cache
from urllib.parse import unquote, unquote_plus
from caches.settings_cache import get_setting
from modules.metadata import episodes_meta, series_absolute_episode, is_anime_check
from modules.settings import date_offset
from modules.kodi_utils import supported_media, get_property, set_property, notification, make_session
from modules.utils import adjust_premiered_date, get_datetime, jsondate_to_datetime, subtract_dates, chunks
# from modules.kodi_utils import logger

# LOCAL PATCH 2026-10-04: the only providers that may run on anime (scrapers/external.py _is_not_for_anime_skipped, and the
# choice offered by indexers/dialogs.anime_providers_choice). The first four exist only for anime; torrentio and comet ask
# by Kitsu id when Fribb gives one (anime numbering), else by IMDb season:episode.
ANIME_ONLY_PROVIDERS = ('animetosho', 'seadex', 'nekobt', 'nyaa')
ANIME_PROVIDERS = ANIME_ONLY_PROVIDERS + ('torrentio', 'comet')
# LOCAL PATCH 2026-10-05: anime and Movies & TV are two separate provider lists. On anime the ticks in scrape.anime_providers
# alone decide (a provider's own switch, magneto.provider.<id>, is the Movies & TV one); off anime the anime-only four never
# run. 'Scrape with ALL' on anime runs every anime provider but these -- Nyaa stays off (its RSS feed caps at 75 rows).
ANIME_ALL_SKIPPED = ('nyaa',)

def is_anime_meta(meta):
	"""TMDb's 'anime' or 'donghua' keyword (metadata.ANIME_KEYWORD_IDS; a movie keeps its keywords under 'keywords', a show
	under 'results'), or anime TMDb has not tagged yet (metadata.untagged_japanese_animation). The one test the scrape and the
	Options menu share."""
	from modules.metadata import ANIME_KEYWORD_IDS, untagged_japanese_animation
	try:
		keywords = (meta or {}).get('keywords') or {}
		if any((k or {}).get('id') in ANIME_KEYWORD_IDS for k in keywords.get('results') or keywords.get('keywords') or []): return True
	except Exception: return False
	return untagged_japanese_animation(meta or {})

def anime_provider_list():
	"""The ticked anime providers, in ANIME_PROVIDERS order; a name outside ANIME_PROVIDERS is ignored."""
	ticked = {i.strip().lower() for i in (get_setting('deadlight.scrape.anime_providers', 'animetosho,seadex,nyaa,nekobt') or '').split(',')}
	return [i for i in ANIME_PROVIDERS if i in ticked]

def anime_providers_to_run(all_scrapers=False):
	if all_scrapers: return [i for i in ANIME_PROVIDERS if i not in ANIME_ALL_SKIPPED]
	return anime_provider_list()

# LOCAL PATCH 2026-07-10 (port of POV debrid session-pooling): module-level
# requests.Session with connection pool + pre-set headers for the debrid cache-check
# hot path. get_external_cache_status previously used bare requests.get/post which
# re-did TCP + TLS handshake per call (~50-200ms each). With RD+TB active and
# mediafusion + torrentio + DMM three-way checks fanning out for every scrape, this
# was adding ~300-800ms per scrape. Session pool amortizes to near-zero for repeat
# hosts (which is exactly what these three services are: same 3 hosts every time).
_debrid_cache_session = make_session('https://', headers={'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json'})

# LOCAL PATCH 2026-10-11: DMM availability token -- (dmmProblemKey, solution) signed by DMM's GET /api/challenge, which is
# what its own web app asks before a sweep. Valid 300 s (problemToken.TOKEN_TTL_SECONDS); kept 240 s, so a scrape costs at
# most one extra request. None when DMM does not answer -- the check is then skipped, never guessed.
_DMM_TOKEN = {'value': None, 'at': 0.0}
_CACHE_PAGE_MEMO = {}   # LOCAL PATCH 2026-10-11: Torrentio / MediaFusion cached-hash pages, {url: (time, hashes)}

def _dmm_token():
	now = time.time()
	if _DMM_TOKEN['value'] and now - _DMM_TOKEN['at'] < 240: return _DMM_TOKEN['value']
	try:
		got = _debrid_cache_session.get('https://debridmediamanager.com/api/challenge', timeout=6).json()
		value = (got['token'], got['hash'])
	except Exception as e:
		try:
			from modules.kodi_utils import logger
			logger('DMM', 'challenge failed: %r' % e)
		except Exception: pass
		return None
	_DMM_TOKEN.update(value=value, at=now)
	return value

# LOCAL PATCH 2026-10-03: what a pack row's size is divided by, in one place (was inline in external.process_sources).
# Providers whose size is already per-episode (torrentio's, and those that divide by their own pack's contents) are
# never divided; nor is a row marked true_size -- meteor, torrentsdb and comet report the size of the EPISODE FILE
# inside a pack (live 2026-10-03: torrentsdb 'Reacher.S02.COMPLETE' 2.93 GB against a 20.85 GB torrent; comet's size
# always equals behaviorHints.videoSize), and dividing that by TMDb's season count showed a tenth of the real size.
PER_EPISODE_PROVIDERS = ('torrentio', 'knightcrawler', 'selfhosted', 'animetosho', 'seadex', 'nekobt')

def pack_size_divider(item, provider, season_divider, show_divider, season_counts=None, season_length=None, total_seasons=None):
	"""Episodes to divide a pack row's size by, or None when its size is already per-episode. In order: the pack's own
	count ('pack_episodes': a name range, a partial pack's episode_start-end, an anime release season's length); for a
	season pack the release season's length (anime, from Fribb) else TMDb's season count; for a show pack the episodes of
	the seasons it holds (first_season..last_season) when that is fewer than the whole show, else every aired episode."""
	if 'package' not in item: return None
	if item.get('true_size') or provider in PER_EPISODE_PROVIDERS: return None
	try:
		n = int(item.get('pack_episodes') or 0)
		if n > 0: return n
	except (TypeError, ValueError): pass
	if item.get('package') == 'season':
		try:
			if season_length and int(season_length) > 0: return int(season_length)
		except (TypeError, ValueError): pass
		return season_divider or 1
	try:
		first, last = int(item.get('first_season') or 1), int(item.get('last_season') or 0)
		if season_counts and last and (not total_seasons or last < int(total_seasons) or first > 1):
			held = sum(c for s, c in season_counts.items() if first <= s <= last)
			if held > 0: return held
	except (TypeError, ValueError): pass
	return show_divider or 1

def extras():
	return ('sample', 'extra', 'extras', 'deleted', 'unused', 'footage', 'inside', 'blooper', 'bloopers',
			'making.of', 'feature', 'featurette', 'behind.the.scenes', 'trailer')

def unwanted_tags():
	return (
'tamilrockers.com', 'www.tamilrockers.com', 'www.tamilrockers.ws', 'www.tamilrockers.pl', 'www-tamilrockers-cl', 'www.tamilrockers.cl', 'www.tamilrockers.li',
'www.tamilrockerrs.pl', 'www.tamilmv.bid', 'www.tamilmv.biz', 'www.1tamilmv.org', 'gktorrent-bz', 'gktorrent-com', 'www.torrenting.com', 'www.torrenting.org',
'www-torrenting-com', 'www-torrenting-org', 'katmoviehd.pw', 'katmoviehd-pw', 'www.torrent9.nz', 'www-torrent9-uno', 'torrent9-cz', 'torrent9.cz',
'agusiq-torrents-pl', 'oxtorrent-bz', 'oxtorrent-com', 'oxtorrent.com', 'oxtorrent-sh', 'oxtorrent-vc', 'www.movcr.tv', 'movcr-com', 'www.movcr.to', '(imax)',
'imax', 'xtorrenty.org', 'nastoletni.wilkoak', 'www.scenetime.com', 'kst-vn', 'www.movierulz.vc', 'www-movierulz-ht', 'www.2movierulz.ac', 'www.2movierulz.ms',
'www.3movierulz.com', 'www.3movierulz.tv', 'www.3movierulz.ws', 'www.3movierulz.ms', 'www.7movierulz.pw', 'www.8movierulz.ws', 'mkvcinemas.live', 'www.bludv.tv',
'ramin.djawadi', 'extramovies.casa', 'extramovies.wiki', '13+', '18+', 'taht.oyunlar', 'crazy4tv.com', 'karibu', '989pa.com', 'best-torrents-net', '1-3-3-8.com',
'ssrmovies.club', 'va:', 'zgxybbs-fdns-uk', 'www.tamilblasters.mx', 'www.1tamilmv.work', 'www.xbay.me', 'crazy4tv-com', '(es)')

def audio_filter_choices():
	return (
('DOLBY DIGITAL', 'DD'), ('DOLBY DIGITAL PLUS', 'DD+'), ('DOLBY DIGITAL EX', 'DD-EX'), ('DOLBY ATMOS', 'ATMOS'), ('DOLBY TRUEHD', 'TRUEHD'),
('DTS', 'DTS'), ('DTS-HD MASTER AUDIO', 'DTS-HD MA'), ('DTS-X', 'DTS-X'), ('DTS-HD', 'DTS-HD'), ('AAC', 'AAC'), ('OPUS', 'OPUS'), ('MP3', 'MP3'),
('8CH AUDIO', '8CH'), ('7CH AUDIO', '7CH'), ('6CH AUDIO', '6CH'), ('2CH AUDIO', '2CH'))

def source_filters():
	return (
('PACK', 'PACK'), ('DOLBY VISION', '[B]D/VISION[/B]'), ('HIGH DYNAMIC RANGE (HDR)', '[B]HDR[/B]'), ('IMAX', 'IMAX'), ('HYBRID', '[B]HYBRID[/B]'), ('AV1', '[B]AV1[/B]'),
('HEVC (X265)', '[B]HEVC[/B]'), ('REMUX', 'REMUX'), ('BLURAY', 'BLURAY'), ('AI ENHANCED/UPSCALED', '[B]AI ENHANCED/UPSCALED[/B]'), ('SDR', 'SDR'), ('3D', '[B]3D[/B]'),
('DOLBY ATMOS', 'ATMOS'), ('DOLBY TRUEHD', 'TRUEHD'), ('DOLBY DIGITAL EX', 'DD-EX'), ('DOLBY DIGITAL PLUS', 'DD+'), ('DOLBY DIGITAL', 'DD'),
('DTS-HD MASTER AUDIO', 'DTS-HD MA'), ('DTS-X', 'DTS-X'), ('DTS-HD', 'DTS-HD'), ('DTS', 'DTS'), ('AAC', 'AAC'), ('OPUS', 'OPUS'), ('MP3', 'MP3'), ('8CH AUDIO', '8CH'),
('7CH AUDIO', '7CH'), ('6CH AUDIO', '6CH'), ('2CH AUDIO', '2CH'), ('DVD SOURCE', 'DVD'), ('WEB SOURCE', 'WEB'), ('MULTIPLE LANGUAGES', 'MULTI-LANG'),
('SUBTITLES', 'SUBS'))

def include_exclude_filters():
	# LOCAL PATCH 2026-06-15: HDR10+ added as separate filter (port-extension of POV per-codec sort).
	return {'hevc': 'HEVC', '3d': '3D', 'hdr': 'HDR', 'hdr10plus': 'HDR10+', 'dv': 'D/VISION', 'av1': 'AV1', 'enhanced_upscaled': 'AI ENHANCED/UPSCALED', 'hybrid': 'HYBRID'}

def get_aliases_titles(aliases):
	try: result = [i['title'] for i in aliases]
	except: result = []
	return result

def make_alias_dict(meta, title):
	aliases = []
	alternative_titles = meta.get('alternative_titles', [])
	original_title = meta['original_title']
	cunt_codes = meta.get('country_codes', [])
	country_codes = set([i.replace('GB', 'UK') for i in cunt_codes])
	if alternative_titles: aliases = [{'title': i, 'country': ''} for i in alternative_titles]
	if original_title not in alternative_titles: aliases.append({'title': original_title, 'country': ''})
	if country_codes: aliases.extend([{'title': '%s %s' % (title, i), 'country': ''} for i in country_codes])
	return aliases

def internal_results(provider, sources):
	set_property('deadlight.internal_results.%s' % provider, json.dumps(sources))

# LOCAL PATCH 2026-09-26: names shown to the user for a scraper whose id reads badly. DISPLAY ONLY -- the
# id itself (http_streams) keys its settings, cache rows, priority/colour and the results filter.
_PROVIDER_DISPLAY = {'HTTP_STREAMS': 'DIRECT STREAMS', 'APIBAY': 'PIRATEBAY', 'TORRENTSCSV': 'TORRENTS-CSV'}   # apibay: 2026-09-29, user's name for it

def provider_display_name(provider):
	provider = (provider or '').upper()
	return _PROVIDER_DISPLAY.get(provider, provider)

# LOCAL PATCH 2026-09-29: the loading window names each provider as it writes itself (the Settings labels), not in
# capitals. DISPLAY ONLY, like _PROVIDER_DISPLAY. Anything unlisted is title-cased.
_PROVIDER_PANEL = {'animetosho': 'AnimeTosho', 'apibay': 'PirateBay', 'bitmagnet': 'Bitmagnet', 'bitsearch': 'BitSearch',
	'mediafusion': 'MediaFusion', 'nekobt': 'nekoBT', 'seadex': 'SeaDex', 'torrentdownload': 'TorrentDownload',
	'torrentsdb': 'TorrentsDB', 'torrentscsv': 'Torrents-CSV', 'torz': 'Torz', 'easynews': 'Easynews', 'http_streams': 'Direct Streams',
	'aiostreams': 'AIOStreams', 'rd_cloud': 'RD Cloud', 'pm_cloud': 'PM Cloud', 'ad_cloud': 'AD Cloud',
	'tb_cloud': 'TorBox Cloud', 'folders': 'Local Folders', 'premiumize.me': 'Premiumize'}

def provider_panel_name(provider):
	provider = provider or ''
	name = _PROVIDER_PANEL.get(provider.lower())
	if name: return name
	return provider if any(c.isupper() for c in provider) else provider.replace('_', ' ').title()

def normalize(title):
	import unicodedata
	try:
		title = ''.join(c for c in unicodedata.normalize('NFKD', title) if unicodedata.category(c) != 'Mn')
		return str(title)
	except: return title

# LOCAL PATCH 2026-09-15: a finished COUR is pack-eligible even while a later one airs.
#
# pack_enable_check asks "does this season contain an unaired episode?" as its proxy for
# "is this season complete?". That holds for a broadcast season and breaks for anime, because
# TMDb files every cour of a show under one season: Re:ZERO is a single TMDb season of 85
# episodes covering four cours and ten years, so the 2016 Blu-ray boxsets were unreachable
# purely because cour 4 was still airing in September 2026 (3 episodes dated 09-16 .. 09-30).
# No pack query was issued to ANY provider, so this was never a scraper problem -- animetosho
# had 35 packs sitting under aid=11370 that nothing asked for.
#
# Anime only, on purpose. The gate is is_anime_check (TMDb keyword 210024), the same test used
# everywhere else, so Western TV keeps byte-identical behaviour. Cour boundaries come from the
# Fribb index already on disk -- no service call, and [] for an unsplit season means this
# returns False and nothing changes.
#
# SHOW packs stay disabled regardless: a whole-show pack necessarily spans the airing cour.
def _cour_complete_for_pack(meta, season, episode, episodes_data, adjust_hours, current_date):
	"""True when every episode of the cour being scraped has aired."""
	try:
		if not is_anime_check(meta): return False
		try: episode = int(episode)
		except (TypeError, ValueError): return False
		from caches.fribb_mappings import cours_for_tmdb_season
		cours = cours_for_tmdb_season(meta.get('tmdb_id'), season, len(episodes_data))
		if not cours: return False
		# A cour covers TMDb episodes offset+1 .. offset+length.
		mine = next((c for c in cours if c['offset'] < episode <= c['offset'] + c['length']), None)
		if not mine: return False
		lo, hi = mine['offset'] + 1, mine['offset'] + mine['length']
		for item in episodes_data:
			try: ep_no = int(item.get('episode'))
			except (TypeError, ValueError): return False
			if not lo <= ep_no <= hi: continue
			aired = adjust_premiered_date(item.get('premiered'), adjust_hours)[0]
			if aired is None or aired > current_date: return False
		return True
	except Exception:
		return False

def pack_enable_check(meta, season, episode):
	try:
		status = meta['extra_info']['status']
		if status in ('Ended', 'Canceled'): return True, True
		adjust_hours, current_date = date_offset(), get_datetime()
		episodes_data = episodes_meta(season, meta)
		unaired_episodes = [adjust_premiered_date(i['premiered'], adjust_hours)[0] for i in episodes_data]
		if None in unaired_episodes or any(i > current_date for i in unaired_episodes):
			return _cour_complete_for_pack(meta, season, episode, episodes_data, adjust_hours, current_date), False
		else: return True, False
	except: pass
	return False, False

def clear_scrapers_cache(silent=False):
	from caches.base_cache import clear_cache
	for item in ('internal_scrapers', 'external_scrapers'): clear_cache(item, silent=True)
	if not silent: notification('Success')

# LOCAL PATCH 2026-09-29: which .m2ts torrents a MOVIE resolve refuses. Upstream refused any torrent holding one .m2ts,
# because a Blu-ray disc folder (BDMV/STREAM/00000.m2ts ...) can split the film over several streams joined by a
# playlist, and a debrid link is one file. Refused now only when the film MAY be split: two or more .m2ts and the
# largest is not clearly the film -- under 4x the next one, or under 75 % of all .m2ts bytes. A single .m2ts plays.
# Backrooms.2026.COMPLETE.UHD.BLURAY-4KDVS: 9 streams, 00002.m2ts 74.4 GiB against 6.7 GiB next (11x, 89 % -- a flat
# 90 % share would have refused it); the resolvers then open the largest file, which is that stream.
# files: [(name, size)]. Unknown sizes (0) refuse. Names repeat in some listings, so each (name, size) counts once.
def split_disc(files):
	m2ts = sorted(set((n, s or 0) for n, s in files if (n or '').lower().endswith('.m2ts')), key=lambda f: f[1], reverse=True)
	if len(m2ts) < 2: return False
	sizes = [s for n, s in m2ts]
	return not (sizes[1] and sizes[0] >= 4 * sizes[1] and sizes[0] >= 0.75 * sum(sizes))

# LOCAL PATCH 2026-09-30: the loading window's quality counts, made to match the list that will open. They counted
# every row every provider sent: The Odyssey's window reached ~170 and the list opened with 19 (repeats, fakes,
# cam rips the pre-release setting hides); Spider-Man: Brand New Day showed 9 '4K', every one a cam or a fake.
class WindowCounter:
	"""Passes each release once (by hash, else url / name) and only when countable(item) returns '' -- the caller's
	own filters. What it leaves out is tallied by reason for the window's 'Hidden' line. Providers answer in
	parallel threads, hence the lock."""
	_LABELS = (('repeat', 'repeat', 'repeats'), ('cam', 'cam rip', 'cam rips'), ('fake', 'fake', 'fakes'),
			   ('other film', 'other film', 'other films'), ('wrong pack', 'pack without the episode', 'packs without the episode'),
			   ('quality', 'outside your quality settings', 'outside your quality settings'))
	def __init__(self, countable=None):
		from collections import Counter
		from threading import Lock
		self.countable, self.seen, self.hidden, self.lock = countable, set(), Counter(), Lock()

	def keep(self, sources):
		out = []
		with self.lock:
			for i in sources or []:
				key = str(i.get('hash') or i.get('url') or i.get('name') or id(i)).lower()
				if key in self.seen:
					self.hidden['repeat'] += 1
					continue
				self.seen.add(key)
				try: reason = self.countable(i) if self.countable else ''
				except Exception: reason = ''
				if reason: self.hidden[reason] += 1
				else: out.append(i)
		return out

	def hide(self, reason, n=1):
		if not n: return
		with self.lock: self.hidden[reason] += n

	def line(self):
		parts = ['%d %s' % (self.hidden[k], one if self.hidden[k] == 1 else many) for k, one, many in self._LABELS if self.hidden.get(k)]
		return 'Hidden  ·  %s' % '  ·  '.join(parts) if parts else ''

def supported_video_extensions():
	supported_video_extensions = supported_media().split('|')
	return [i for i in supported_video_extensions if not i in ('','.zip','.rar','.iso')]

# LOCAL PATCH 2026-08-31: precompiled at import. Both run on every release title the
# debrid-cloud scrapers examine, which is once per file across the whole cloud.
_RE_TITLE_CLEAN = re.compile(r'[^A-Za-z0-9-]+')
_RE_VERSION_SUFFIX = re.compile(r'(?<=\d)v\d+(?=\D|$)')

# LOCAL PATCH 2026-09-24: a candidate SEASON meaning 'whichever season the file names'.
#
# Netflix-sourced One Piece releases write the ABSOLUTE episode under their own season label:
# '[VARYG] ONE.PIECE.S01E1104' is episode 1104, which TMDb asks for as S22E1104. No real pair
# can match it -- (22, 1104) needs s22, and a (1, 1104) pair would be invented numbering.
#
# Safe only for a number no season-RELATIVE count reaches, which is what the threshold is. A
# relative 'S21E150' (Crunchyroll's Wano) is episode ~1041, and a (any, 150) pair would play it
# for episode 150 -- the wrong episode, the one outcome worse than finding nothing. No release
# season in this library runs past 197 episodes (TMDb's own Wano), so an episode number above
# _ANY_SEASON_MIN written after an SxxE can only be the absolute one.
ANY_SEASON = -1
# LOCAL PATCH 2026-09-24: a candidate SEASON meaning 'this is the ABSOLUTE number' -- matched only
# by forms that carry one ('- 24', 'Episode 24', a bare '.24.'), never by an explicit SxxEyy.
#
# The absolute candidate used to be paired with TMDb's season, (2, 24) for Mushoku Tensei S02E01
# (absolute 24, Season 1 being 23 episodes), and candidates are tried highest number first. In a
# pack numbered per season, 'S02E24' is a real file -- the Season 2 FINALE -- so all three S02
# packs tried on 2026-09-24 played 'S02E24 Succession' for S02E01. An absolute number never
# belongs beside a season in an SxxEyy name; beside a dash or on its own it is what absolute-
# numbered packs write, and those still match.
ABSOLUTE_SEASON = -2
_ANY_SEASON_MIN = 200


# LOCAL PATCH 2026-09-24: the episode number a name states after a dash -- '<show> - 681 - <title>'.
# Read on the CLEANED title, where ' - ' has become '.-.'. See seas_ep_filter.
_RE_DASH_NUMBER = re.compile(r'\.-\.0*(\d{1,4})\.')
# LOCAL PATCH 2026-09-24: a bit-depth tag, '10 bit' / '10bit' / '8 bits', on the cleaned title.
# string7 read '[AV1 10 bit]' as '.10.' -- episode 10 -- so Mushoku's 'Special 1 [AV1 10 bit]'
# played for episode 10. Blanked before matching, anime only (strict), like _RE_DASH_NUMBER.
_RE_BIT_DEPTH = re.compile(r'(?<![a-z0-9])(?:8|10|12)\.?bits?(?![a-z0-9])')


@lru_cache(maxsize=512)
def _seas_ep_pattern(season, episode, strict, bare=True):
	"""The compiled season/episode alternation for one (season, episode, strict).

	LOCAL PATCH 2026-08-31: this ~20-branch alternation was rebuilt and re-compiled on EVERY
	seas_ep_filter() call, even though only release_title varies during a scrape -- season,
	episode and strict are fixed for the whole pass. The debrid-cloud scrapers call the filter
	once per file (rd_cloud, ad_cloud, tb_cloud, pm_cloud), so a large cloud recompiled the
	identical pattern once per file while the user waited for playback. Memoised on the only
	three inputs it actually depends on.
	"""
	# LOCAL PATCH 2026-09-24: ANY_SEASON -- the absolute episode under whatever season the
	# release writes. Only the explicit SxxEyy form: an episode-only pattern would add nothing
	# the real pairs do not already try.
	if season == ANY_SEASON:
		return re.compile(r'(s\d{1,3}[.-]?e[p]?[.-]?0*%d[.-])' % int(episode))
	str_season, str_episode = str(season), str(episode)
	season_fill, episode_fill = str_season.zfill(2), str_episode.zfill(2)
	str_ep_plus_1, str_ep_minus_1 = str(episode+1), str(episode-1)
	# LOCAL PATCH 2026-09-24: any number of leading zeros on either side. KQRM's Netflix One
	# Piece packs name every file 'S001E001' / 'S004E093' -- three digits, which neither the
	# plain nor the zfill(2) variant below produces, so a cached S01 pack could not find
	# episode 1 in its own listing and failed on click. Still anchored: the digits must be
	# followed by the next marker, so 's0*1' cannot read 's10e..' nor 'e0*1' read 'e10.'.
	string1 = r'(s0*<<S>>[.-]?e[p]?[.-]?0*<<E>>[.-])'
	string2 = r'(season[.-]?<<S>>[.-]?episode[.-]?<<E>>[.-])'#|([s]?<<S>>[x.]<<E>>[.-])'
	string3 = r'(s<<S>>e<<E1>>[.-]?e?<<E2>>[.-])'
	string4 = r'([.-]<<S>>[.-]<<E>>[.-])' if strict else r'([.-]<<S>>[.-]?<<E>>[.-])'
	# LOCAL PATCH 2026-09-24: leading zeros here too, same reason and same anchoring as
	# string1 -- '[Feibanyama] One Piece EP0001' was unreadable for episode 1.
	string5 = r'(episode[.-]?0*<<E>>[.-])'
	string6 = r'([.-]e[p]?[.-]?0*<<E>>[.-])'
	# LOCAL PATCH 2026-08-27: the NxNN guard was `\d+x\d+`, which is meant to spot an
	# explicit season-x-episode marker ('1x04') and stand down when one is present. It also
	# matched RESOLUTIONS, so any file naming its dimensions -- 'Youjo Senki - 04v3 -
	# Campus Life (BDremux 1920x1080)' -- disabled this pattern and the episode became
	# unmatchable, leaving a 3.8MB preview as the only candidate for episode 4.
	# A season-x-episode marker is at most 2 digits by 3; a resolution is 3-4 by 3-4.
	string7 = r'(^(?=.*\.e?0*<<E>>\.)(?:(?!((?:s|season)[.-]?\d+[.-x]?(?:ep?|episode)[.-]?\d+)|(?<!\d)\d{1,2}x\d{1,3}(?!\d)).)*$)'
	string8 = r'([s]?<<S>>x<<E>>[.-])'
	string_list = []
	string_list_append = string_list.append
	string_list_append(string1.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string1.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string1.replace('<<S>>', season_fill).replace('<<E>>', str_episode))
	string_list_append(string1.replace('<<S>>', str_season).replace('<<E>>', str_episode))
	string_list_append(string2.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string2.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string2.replace('<<S>>', season_fill).replace('<<E>>', str_episode))
	string_list_append(string2.replace('<<S>>', str_season).replace('<<E>>', str_episode))
	string_list_append(string3.replace('<<S>>', season_fill).replace('<<E1>>', str_ep_minus_1.zfill(2)).replace('<<E2>>', episode_fill))
	string_list_append(string3.replace('<<S>>', season_fill).replace('<<E1>>', episode_fill).replace('<<E2>>', str_ep_plus_1.zfill(2)))
	string_list_append(string4.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string4.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string5.replace('<<E>>', episode_fill))
	string_list_append(string5.replace('<<E>>', str_episode))
	string_list_append(string6.replace('<<E>>', episode_fill))
	if bare: string_list_append(string7.replace('<<E>>', episode_fill))
	if season == ABSOLUTE_SEASON:
		# LOCAL PATCH 2026-09-24: season-free forms only -- see ABSOLUTE_SEASON. string6 needs a
		# separator before its 'e', so the 'e24' inside 's02e24' cannot match it either.
		string_list = [string5.replace('<<E>>', episode_fill), string5.replace('<<E>>', str_episode),
			string6.replace('<<E>>', episode_fill)]
		if bare: string_list.append(string7.replace('<<E>>', episode_fill))
	string_list_append(string8.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string8.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string8.replace('<<S>>', season_fill).replace('<<E>>', str_episode))
	string_list_append(string8.replace('<<S>>', str_season).replace('<<E>>', str_episode))
	final_string = '|'.join(string_list)
	return re.compile(final_string)


def _states_dash_number(name):
	"""True when a name states its episode after a dash, read exactly as seas_ep_filter reads it."""
	cleaned = _RE_TITLE_CLEAN.sub('.', unquote(name or '').replace('\'', '')).lower()
	return bool(_RE_DASH_NUMBER.search(_RE_VERSION_SUFFIX.sub('', cleaned)))


def seas_ep_filter(season, episode, release_title, split=False, return_match=False, strict=False, bare=None):
	"""Does `release_title` name this season/episode?

	LOCAL PATCH 2026-08-27 -- `strict` tightens string4 for ANIME ONLY. string4 joins the
	season and episode with an OPTIONAL separator, so '.101.' reads as season 1 episode 01.
	For Western TV that is deliberate and correct: 'Show.101.720p' really does mean S01E01.
	For anime it is a disaster, because 101 there is an absolute episode number --
	'Naruto.101.v4.480p.mkv' was answering requests for episode 1, and 'Naruto.110' was
	answering episode 10. Not a preview but a completely different episode, which is worse
	because it looks plausible on screen.

	The two conventions genuinely conflict, so this cannot be fixed globally. Callers that
	know they are dealing with anime pass strict=True; everyone else keeps today's exact
	behaviour. 'Naruto.001' is unaffected either way -- it matches through string7.
	"""
	release_title = _RE_TITLE_CLEAN.sub('.', unquote(release_title).replace('\'', '')).lower()
	# LOCAL PATCH 2026-08-27: drop the re-release version suffix glued to an episode
	# number -- '04v3' means episode 4, version 3. Anime groups revise releases constantly
	# so v2/v3 are everywhere, and with the suffix attached NOT ONE pattern below matches:
	# '.04v3.' is neither '.04.' nor 'e04'. That is how Saga of Tanya the Evil ended up
	# playing a preview. In the 'Youjo Senki v3 (BDremux)' pack the real 6.60GB
	# 'Youjo Senki - 04v3 - Campus Life' did not match episode 4 at all, while the 3.8MB
	# 'Youjo Senki Episode 04 - ... Preview' matched cleanly -- so the preview was not
	# beating the episode, it was the ONLY candidate.
	# Safe for every other convention: a digit must immediately precede the 'v', so
	# 'AV1', 'x264', 'DivX3' and '1920x1080' are untouched, and Western 'S01E05v2'
	# correctly becomes 'S01E05'.
	release_title = _RE_VERSION_SUFFIX.sub('', release_title)
	# LOCAL PATCH 2026-09-24: once a name states its episode after a dash, a bare number
	# elsewhere in it is part of a TITLE, not the episode. string7 reads any '.500.' in the
	# name, so in a One Piece 1-928 pack 'One Piece - 681 - The 500 Million Berry Man!' answered
	# episode 500 -- and outsized the real file, so 681 PLAYED -- and '... - 060 - The 1000 Year
	# Legend' answered episode 1000. 'Mob Psycho 100 - 05' is the same thing in the show's
	# title. So string7 stands down when the dash number is a different number; every explicit
	# marker (sXXeYY, 'episode', 'e') is unaffected. Anime only, like the rest of strict.
	# `bare=False` from the caller forces the same stand-down: pick_episode_files passes it for a
	# file outside its pack's dash convention (see there). None means decide from this name alone.
	bare = bare is not False
	if strict:
		release_title = _RE_BIT_DEPTH.sub('', release_title)
		# LOCAL PATCH 2026-10-05: a name that STARTS with its episode number ('12. The Woman with the Demon Eyes.mkv', a
		# 66-file Mushoku Tensei Part 2 remux) had no dot before the number for string7 to anchor on, so no file of the
		# pack ever matched: the row kept its 73.5 GB pack size and would have resolved to nothing.
		if release_title[:1].isdigit(): release_title = '.' + release_title
		m = _RE_DASH_NUMBER.search(release_title)
		if m and int(m.group(1)) != int(episode): bare = False
	reg_pattern = _seas_ep_pattern(season, episode, strict, bare)
	if split: return release_title.split(re.search(reg_pattern, release_title).group(), 1)[1]
	if return_match: return re.search(reg_pattern, release_title).group()
	return bool(re.search(reg_pattern, release_title))

# LOCAL PATCH 2026-08-27: anime episode numbering for file selection inside packs.
#
# THE PROBLEM
# seas_ep_filter() above matches a filename against TMDb's season/episode. That is
# right for Western TV and wrong for anime, because anime releases are not numbered
# the way TMDb files them. Three numberings are in active use and all three are
# "correct" -- they just count from different places:
#
#   Re:ZERO, the episode TMDb calls S01E50, appears in packs as
#     "Re Zero ... - 50.mkv"                    series-absolute
#     "Re Zero ... Season 2 - 24.mkv"           release-season-relative
#     "Re Zero ... 2nd Season Part 2 - 12.mkv"  cour-relative
#
# So a season pack that DeadLight happily lists would resolve to nothing on click:
# seas_ep_filter looked for episode 50 in a pack whose files stop at 12, found no
# file, and resolve_magnet returned None. The source appeared broken.
#
# THE APPROACH, AND WHY IT IS ORDERED RATHER THAN OR-ED
# The obvious fix -- match ANY of the three numbers -- is wrong. A complete-series
# pack contains a file "12" as well as the file "50" we actually want, so an OR
# would happily play episode 12 instead. Order fixes this without any knowledge of
# what kind of pack it is: try the HIGHEST episode number first and stop at the
# first one that matches anything.
#
#   complete-series pack -> "50" exists, wins immediately
#   season pack          -> no "50", falls through to "24"
#   cour pack            -> neither, falls through to "12"
#
# Each pack is matched by the numbering it actually uses. The ordering is what makes
# this safe, and it orders by episode number alone -- TMDb's own numbering gets no
# special priority, because for anime it is usually the one a release does NOT use.


def anime_episode_candidates(meta, tmdb_id, season, episode):
	"""Alternate (season, episode) pairs this anime episode may be numbered as.

	Ordered widest-first, see the note above. Empty for non-anime, which leaves
	every existing caller behaving exactly as it did.
	"""
	try:
		from modules.metadata import is_anime_check
		if not is_anime_check(meta, tmdb_id): return []
	except Exception: return []
	try: season, episode = int(season), int(episode)
	except (TypeError, ValueError): return []
	# LOCAL PATCH 2026-08-27: the primary pair is included so that a NON-EMPTY result
	# means 'this is anime' exactly, rather than incidentally. pick_episode_files uses
	# that as its signal to match strictly, and a season-1 anime with no Fribb row and
	# no earlier seasons would otherwise return [] and be treated as Western TV.
	# Harmless downstream: ordered_episode_candidates prepends and de-duplicates it.
	candidates = [(season, episode)]
	# series-absolute: TMDb's own season_data is enough, no mapping needed, so this
	# works even for shows Fribb has no cour row for (Naruto is one such).
	# LOCAL PATCH 2026-09-02: was an inlined `sum(earlier episode_count) + episode` with no
	# already-absolute guard, which is wrong for every show TMDb numbers absolutely. It
	# turned One Piece S02E62 into 123 and Naruto S02E53 into 105 -- both REAL OTHER
	# EPISODES -- and ordered_episode_candidates below sorts DESCENDING, so the bogus number
	# was tried FIRST against a complete-series pack and won. Now shared with
	# scrapers/external.py, which publishes the same number as data['absolute_episode'], so
	# the number the providers get and the number the debrid layer picks a file with cannot
	# drift apart. `!= episode` only suppresses a duplicate of candidates[0].
	absolute = None
	try:
		absolute = series_absolute_episode(meta, season, episode)
		# LOCAL PATCH 2026-09-24: under ABSOLUTE_SEASON, not TMDb's season -- see there.
		if absolute and absolute != episode: candidates.append((ABSOLUTE_SEASON, absolute))
	except Exception: pass
	# LOCAL PATCH 2026-09-24: the absolute number under any season label -- see ANY_SEASON.
	# Appended after the (season, absolute) pair it shares a number with, and the ordering sort
	# is stable, so a file TMDb's own pair can find always wins over this one.
	_abs = absolute or episode
	if _abs > _ANY_SEASON_MIN: candidates.append((ANY_SEASON, _abs))
	try:
		from caches import fribb_mappings
		# LOCAL PATCH 2026-09-05: allow_repair=False -- these candidates are matched against
		# release FILENAMES, both when scraping and when picking a file out of a pack, so
		# they must use numbering releases actually carry. See the same flag at
		# scrapers/external.py and the note on the repair branch in fribb_mappings.
		info = fribb_mappings.find_cour_by_tmdb_coords(tmdb_id, season, episode, allow_repair=False) or {}
		# cour_season is season.tvdb -- the season number RELEASES use. TMDb files
		# every Re:ZERO cour under season 1, so `season` cannot stand in for it.
		cour_season = info.get('cour_season') or season
		for number in (info.get('season_ep'), info.get('cour_ep')):
			# LOCAL PATCH 2026-10-05: not a pair in TMDb's OWN season with another number -- in TMDb numbering that pair is a
			# different episode. Mushoku Tensei S1E12 is Part 2 episode 1 (cour_season 1, cour_ep 1), and (1, 1) found the
			# 'S01E01' of every Part 1 pack (OZR, Lia, the [ΑΩ] Vol 1 remux: S01E01-S01E11) -- kept as holding episode 12,
			# shown at episode 1's size and resolved to episode 1. The same collision cour_match's step 3b refuses (AoT S3
			# part 2 '- 08'). A part-relative pack numbered from 01 is lost with it; playing the wrong episode is worse.
			if number and not (int(cour_season) == season and int(number) != episode):
				candidates.append((int(cour_season), int(number)))
		# LOCAL PATCH 2026-10-05: plus the flat-season repair's pair when it puts the episode in ANOTHER entry. TMDb folded
		# MASHLE's two seasons into one of 24, and its packs are numbered as released: TMDb S1E13 is the 'S02E01' file in
		# Sokudo's and another 24-file pack and in NAN0's Season 2 remux. With TMDb's (1, 13) alone the pack test dropped
		# all three as 'no episode 13' (log 2026-10-05 14:59:31) and the resolver would have found no file in them. Only an
		# extra pair, ordered by number like the rest: a pack numbered by TMDb has no 'S02E01' file to match by accident.
		rep = fribb_mappings.find_cour_by_tmdb_coords(tmdb_id, season, episode, allow_repair=True) or {}
		if rep.get('cour_season') and rep.get('anilist') and rep.get('anilist') != info.get('anilist'):
			for number in (rep.get('season_ep'), rep.get('cour_ep')):
				if number: candidates.append((int(rep['cour_season']), int(number)))
	except Exception: pass
	return candidates


# LOCAL PATCH 2026-08-27: things that sit inside a pack but are not the show -- credit
# sequences, previews, menus, extras. They routinely carry an episode number, so the
# episode test alone cannot tell them from the episode: in SeaDex's Frieren PMR pack
# 'NCOP 01' and 'NCED 01' (0.39GB each) both answer a request for episode 1 alongside the
# real 6.99GB file. Whichever the torrent happens to list first is what played, which is
# why the symptom was intermittent.
#
# extras() does not cover any of this -- it has no ncop/nced/preview/menu -- and it is used
# by the movie path and the cloud scrapers, so it is left alone and this sits beside it.
#
# magneto's providers/torrents/seadex.py has an equivalent `_NOT_AN_EPISODE` for its own
# file picking. The module boundary prevents sharing (magneto cannot import DeadLight), so
# the two are kept in step by hand -- change one, look at the other.
_NON_EPISODE = re.compile(
	r'(?:^|[^a-z0-9])(?:nc)?(?:op|ed)\d*(?:[^a-z0-9]|$)|'
	r'(?:^|[^a-z0-9])(?:preview|pv|menu|creditless|clean|textless|sample|trailer|teaser|'
	r'promo|cm|spot|bonus|interview|omake|recap|digest|prologue|epilogue|'
	r'making\.?of|behind\.?the\.?scenes|featurette|blooper|bloopers|outtake|outtakes|'
	# LOCAL PATCH 2026-08-27 (same day, second pass): the trailing \d* is the whole point.
	# The first version only allowed a number after op/ed, so 'NCOP1' was caught but
	# 'Youjo Senki PV1.mkv' was not -- and promos are numbered as a matter of course
	# (PV1, PV2, PV3), which is exactly how a Saga of Tanya the Evil promo kept playing.
	# Same hole applied to Preview2, CM1, Menu1, Promo1, Spot2 and Teaser1.
	r'commentary|karaoke|logo|scan|scans|booklet)\d*(?:[^a-z0-9]|$)', re.I)


# The credit-sequence half of _NON_EPISODE on its own: prepare_episode_files may give back an episode-sized
# file an extras word flagged, but never one of these.
_CREDIT_SEQUENCE = re.compile(r'(?:^|[^a-z0-9])(?:nc)?(?:op|ed)\d*(?:[^a-z0-9]|$)|creditless|textless', re.I)

def non_episode_file(name, title=None):
	"""True when this file is in the pack but is not an episode of the show.

	`title` is the show/episode title. A word is never used as evidence when it appears in
	the title itself -- the same guard the movie branch already applies via
	`extras_filtering_list` -- so a show actually called "Preview" is not wiped out.
	"""
	name = (name or '').lower()
	if not name: return False
	title = (title or '').lower()
	match = _NON_EPISODE.search(name)
	if match and match.group(0).strip('.-_ ') not in title: return True
	# the long-standing extras vocabulary, same title guard as the movie path
	return any(word in name for word in extras() if word not in title)


def ordered_episode_candidates(season, episode, candidates=None):
	"""Every numbering this episode may be called, highest episode number first.

	LOCAL PATCH 2026-08-27: the single home for this ordering. It was written twice --
	here and again in magneto's seadex provider, whose copy said in its own docstring
	that it "mirrors" this one. Two copies of a rule this subtle will drift, so the
	scrape path now publishes the result of THIS function in data['episode_candidates']
	and the provider reads it instead of recomputing.

	Highest episode number first -- including TMDb's own pair, which for anime is
	usually NOT what a release uses and must not get priority just for being ours.
	Verified the hard way: pinning it first made Naruto S04E01 (absolute 159) match
	'Naruto - 001', and AoT S03E20 (absolute 57) match '- 20' in an absolute-numbered
	pack. Both play the WRONG EPISODE, which is worse than the failure being fixed.
	Descending is safe in the way ascending is not: a low number can turn up by
	coincidence inside a pack numbered a wider way, but a pack numbered a narrow way
	has no file carrying the wider number at all -- so a high candidate never matches
	spuriously, it simply finds nothing and the search falls through.
	"""
	ordered, seen = [], set()
	for pair in [(season, episode)] + list(candidates or []):
		if pair[0] is None or pair[1] is None or pair in seen: continue
		seen.add(pair)
		ordered.append(pair)
	ordered.sort(key=lambda pair: -int(pair[1]))
	return ordered


_SIZE_KEYS = ('size', 'bytes', 's', 'filesize', 'length')


def _file_size(f):
	"""Bytes for a debrid file dict, whatever the provider calls the field.

	TorBox/EasyDebrid/Premiumize use 'size', Real-Debrid 'bytes', AllDebrid 's'.
	Returns 0 when unknown, which leaves such files in their original order.
	"""
	if not isinstance(f, dict): return 0
	for k in _SIZE_KEYS:
		v = f.get(k)
		if v is None: continue
		try: return int(v)
		except (TypeError, ValueError): continue
	return 0


def _key_name(key):
	def _name(f):
		if key is None: return f
		# callable for the callers whose match text is derived, not a plain field
		# (Premiumize matches on the basename of item['path'])
		return key(f) if callable(key) else f[key]
	return _name


def prepare_episode_files(files, key=None, title=None, strict=False):
	"""(usable files, indices outside the pack's naming convention) -- everything
	pick_episode_files works out about a listing BEFORE it looks at an episode number.

	LOCAL PATCH 2026-09-24: split out so a caller asking many episodes of ONE listing pays for it
	once. scrapers/external.py's readability probe asks up to ~85 episodes of the same cached
	pack, and redid the extras filter, the size floor and the convention scan for every one of
	them -- about 30% of the ~27ms a missing pack cost. Must be built with the same `key`,
	`title` and `strict` the picks will use.
	"""
	_name = _key_name(key)
	try:
		flagged = [non_episode_file(_name(f), title) for f in files]
		usable = [f for f, bad in zip(files, flagged) if not bad]
		# LOCAL PATCH 2026-09-27: an extras WORD can be an episode's own title. Saga of Tanya the Evil's
		# 'Youjo Senki - 02v3 - Prologue (BDremux 1920x1080).mkv' (6.7GB) was dropped for 'prologue', which
		# left the pack's chibi short 'Youjo Shenki #02' (12.6MB) as the only file answering episode 2 --
		# it played, and SmartPlay saved it as the pin. The size floor below could not save it: 13 chibi
		# shorts outnumber the 11 surviving episodes, so the "median" was a 12MB short. So a flagged file
		# comes back when it looks like an episode by STRUCTURE, not by name: it states its episode after
		# a dash ('- 02v3 -'), it is episode-sized (half the median of the pack's large files), and the
		# flag was a vocabulary word, never a credit sequence (OP/ED/NCOP/NCED stay out whatever size).
		if usable and any(flagged):
			sizes = sorted(_file_size(f) for f in usable)
			large = [s for s in sizes if s >= sizes[-1] * 0.2]
			reference = large[len(large) // 2] if large else 0
			if reference > 0:
				keep = set(i for i, (f, bad) in enumerate(zip(files, flagged)) if bad
					and _file_size(f) >= reference * 0.5 and _states_dash_number(_name(f))
					and not _CREDIT_SEQUENCE.search((_name(f) or '').lower()))
				if keep: usable = [f for i, f in enumerate(files) if not flagged[i] or i in keep]
	except Exception: usable = list(files)
	# Never let the filter empty the pack -- a release whose every file trips a keyword is
	# better matched loosely than not at all.
	if not usable: usable = list(files)
	# LOCAL PATCH 2026-08-27: and a size floor, which needs no vocabulary at all. Saga of
	# Tanya the Evil packs ship an 'Extra/Preview/' folder holding a 3-5MB promo for EVERY
	# episode, beside 1GB episodes -- 'Youjo Senki 04 Preview.mkv' really is episode 4's
	# preview, so it matches an episode-4 request perfectly. The name test catches these,
	# but only because someone wrote "Preview"; the next pack will use a word nobody
	# listed. A file at 0.4% of the pack's typical size is not an episode whatever it is
	# called, so drop anything under a tenth of the median -- a 25x margin over the real
	# previews, and far below any genuine episode (even a 480p copy in a mixed pack runs
	# ~27% of the median).
	if len(usable) >= 4:
		sizes = sorted(_file_size(f) for f in usable)
		median = sizes[len(sizes) // 2]
		if median > 0:
			floor = median * 0.10
			big_enough = [f for f in usable if _file_size(f) >= floor]
			if big_enough: usable = big_enough
	# LOCAL PATCH 2026-09-24: the pack's own naming convention. When at least two thirds of its
	# files (4 or more) state their episode after a dash, a file that does NOT is outside the run
	# -- a recap, a special -- and may answer only through an explicit marker, never a bare
	# number. '[...] One Piece 783-843' ships 15 'One Piece - The World Navigation 01..15'
	# recaps, and ' 01 ' made the first of them episode 1 (both here and in seadex). Anime only.
	outside = set()
	if strict and len(usable) >= 4:
		try:
			dashed = [_states_dash_number(_name(f)) for f in usable]
			if sum(dashed) * 3 >= len(usable) * 2: outside = set(i for i, d in enumerate(dashed) if not d)
		except Exception: outside = set()
	return usable, outside


_RE_NOT_AN_EPISODE = re.compile(r'(?<![a-z0-9])(?:movies?|gekijou?ban|the[\s._-]?movie|ova|oad|ona|specials?)(?![a-z0-9])', re.I)

def _narrow_anime_hits(hits, name_of, title):
	"""LOCAL PATCH 2026-10-05: several files of one anime pack matching the episode -- keep the episode itself.

	Largest-first then took the wrong one. Bleach S01E01 out of franchise packs (TorBox listings, 2026-10-05):
	'[Judas] Burn the Witch - 01.mkv' (0.26 GB) beat '[Judas] Bleach - 001.mkv' (0.18 GB), and 'Bleach Movie 01.mkv'
	(0.67 GB) beat 'Bleach 01.mkv'. So, each step only when something is left after it: films, OVAs and specials go
	(unless the show's own title says so), then files without the show's name when others carry it. A pack none of whose
	files name the show ('12. The Woman with the Demon Eyes.mkv') is left as it was."""
	title_l = str(title or '').lower()
	def _words(t): return set(w for w in re.findall(r'[a-z0-9]+', str(t).lower()) if len(w) >= 3)
	episodes = [h for h in hits if not any(m.group(0).lower() not in title_l for m in _RE_NOT_AN_EPISODE.finditer(str(name_of(h))))]
	if episodes: hits = episodes
	own = _words(title) - {'the', 'and', 'season', 'part'}
	if own:
		named = [h for h in hits if _words(name_of(h)) & own]
		if named: hits = named
	return hits

def pick_episode_files(files, season, episode, key=None, candidates=None, title=None, prepared=None):
	"""(matching files, the (season, episode) pair that matched them), largest first.

	Returns the pair as well because the debrid modules call seas_ep_filter a second
	time with split=True on a file they have already matched, to inspect what follows
	the episode marker. That second call must use the SAME numbering -- with split=True
	a miss is not False, it is re.search(...) returning None and .group() raising.
	It stays non-strict, which is safe: non-strict matches a superset of strict.

	LOCAL PATCH 2026-08-27 -- two defences against playing the wrong file out of a pack,
	both here because all five debrid modules route through this one function:

	  * credit sequences, previews and extras are dropped before matching. They carry
	    episode numbers, so the episode test cannot tell them apart -- see non_episode_file.
	  * whatever still matches is returned LARGEST FIRST. Every caller takes the first hit,
	    and until now that was simply the torrent's own file order, so a 0.39GB NCOP could
	    beat a 6.99GB episode purely by being listed earlier. Measured over 142 resolutions
	    against real pack listings: 20% matched more than one file, and in 15 of those 28
	    the first was not the largest.

	`strict` episode matching is enabled whenever candidates are supplied, which is exactly
	when the caller has told us this is anime (see anime_episode_candidates).
	"""
	_name = _key_name(key)
	strict = bool(candidates)
	# `prepared`: prepare_episode_files' result for THIS listing with the same key, title and
	# strictness -- lets a caller asking many episodes of one pack prepare it once.
	usable, outside = prepared if prepared is not None else prepare_episode_files(files, key, title, strict)
	for pair in ordered_episode_candidates(season, episode, candidates):
		try: hits = [f for i, f in enumerate(usable) if seas_ep_filter(pair[0], pair[1], _name(f), strict=strict,
			bare=False if i in outside else None)]
		except Exception: continue
		if hits:
			if strict and len(hits) > 1: hits = _narrow_anime_hits(hits, _name, title)
			hits.sort(key=_file_size, reverse=True)
			# LOCAL PATCH 2026-08-31: publish the file we actually chose out of the pack.
			# Every caller takes hits[0] and the debrid modules then return ONLY a url --
			# TorBox's is an opaque uuid with no filename in it -- so nothing downstream
			# could tell which episode was really played. player.playing_filename is the
			# PACK name, which made subtitle release matching blind for pack playback:
			# 'Reply.1988.(2015).Complete.2160p.UHDTV...-HThoreau' scored 5 against
			# per-episode candidates because the packager's name can never match theirs.
			# All five debrid modules route through here, so this is the one honest place
			# to record it. Consumers must re-verify -- see subtitles._played_name().
			try: set_property('deadlight.playing.pack_file', str(_name(hits[0])))
			except Exception: pass
			return hits, pair
	return [], (season, episode)


# LOCAL PATCH 2026-09-24: numbers a pack's own filenames write, for the readability probe in
# scrapers/external.py's _real_pack_sizes. Kept beside the matcher because they answer the
# same question from the other side: which episodes does this listing name?
#
# Episode numbers: that probe tried 1-60 only, so a pack whose files all sit above 60 was
# 'unreadable' and kept whatever it held -- '[Koten_Gars] Naruto Shippuden (Season 08-20)',
# files 154 up, stayed in the S1E1 picker. Resolutions, codecs, years and CRC32 tags are not
# episode numbers and are left out.
_LISTING_NUMBER = re.compile(r'(?<![a-z0-9])0*(\d{1,4})(?![0-9])(?!p\b)(?!bit)', re.I)
_LISTING_CRC = re.compile(r'\[[0-9a-f]{8}\]', re.I)
_LISTING_NOISE = frozenset((480, 576, 720, 1080, 1440, 2160, 264, 265))

def listing_episode_numbers(usable, cap=20):
	"""Distinct plausible episode numbers written in the filenames, lowest first."""
	seen = set()
	for f in usable:
		for m in _LISTING_NUMBER.finditer(_LISTING_CRC.sub(' ', f['filename'])):
			n = int(m.group(1))
			if n and n not in _LISTING_NOISE and not 1900 <= n <= 2099: seen.add(n)
	return sorted(seen)[:cap]

# Season/episode pairs: the probe asks only in the REQUESTED season, so a pack of another season
# could never prove itself readable -- KQRM's 'One Piece S04' (files S004E093-S004E130) stayed
# in the S1E1 picker although the matcher reads every one of its files as season 4. Probing a
# pair a file itself names shows the matcher understands the convention, which is all the drop
# needs.
_LISTING_SXE = re.compile(r'(?<![a-z0-9])s(\d{1,3})[.\-_ ]?e(\d{1,4})(?!\d)', re.I)

def listing_episode_pairs(usable, cap=5):
	"""Distinct (season, episode) pairs written as SxxEyy in the filenames, lowest first."""
	seen = set()
	for f in usable:
		m = _LISTING_SXE.search(f['filename'])
		if m: seen.add((int(m.group(1)), int(m.group(2))))
	return sorted(seen)[:cap]


def find_season_in_release_title(release_title):
	release_title = re.sub(r'[^A-Za-z0-9-]+', '.', unquote(release_title).replace('\'', '')).lower()
	match = None
	regex_list = [r's(\d+)', r's\.(\d+)', r'(\d+)x', r'(\d+)\.x', r'season(\d+)', r'season\.(\d+)']
	for item in regex_list:
		try:
			match = re.search(item, release_title)
			if match:
				match = int(str(match.group(1)).lstrip('0'))
				break
		except: pass
	return match

def check_title(title, release_title, aliases, year, season, episode):
	try:
		all_titles = [title]
		if aliases: all_titles += aliases
		cleaned_titles = []
		cleaned_titles_append = cleaned_titles.append
		year = str(year)
		for i in all_titles:
			cleaned_titles_append(
				i.lower().replace('\'', '').replace(':', '').replace('!', '').replace('(', '').replace(')', '').replace('&', 'and').replace(' ', '.').replace(year, ''))
		release_title = strip_non_ascii_and_unprintable(release_title).lstrip('/ ').replace(' ', '.').replace(':', '.').lower()
		releasetitle_startswith = release_title.startswith
		unwanted = unwanted_tags()
		for i in unwanted:
			if releasetitle_startswith(i):
				i_startswith = i.startswith
				pattern = r'\%s' % i if i_startswith('[') or i_startswith('+') else r'%s' % i
				release_title = re.sub(r'^%s' % pattern, '', release_title, 1, re.I)
		release_title = release_title.lstrip('.-:/')
		release_title = re.sub(r'^\[.*?]', '', release_title, 1, re.I)
		release_title = release_title.lstrip('.-[](){}:/')
		if season:
			if season == 'pack': hdlr = ''
			else:
				try: hdlr = seas_ep_filter(season, episode, release_title, return_match=True)
				except: return False
		else: hdlr = year
		if hdlr:
			release_title = release_title.split(hdlr.lower())[0]
			release_title = release_title.replace(year, '').replace('(', '').replace(')', '').replace('&', 'and').rstrip('.-').rstrip('.').rstrip('-').replace(':', '')
			# LOCAL PATCH 2026-09-22 (Red Light 2.6.4 port): for an EPISODE scrape the show title
			# must match exactly, not merely be contained. release_title has already been cut at
			# the SxxExx token just above, so what is left is precisely the show name the release
			# claims -- which makes an equality test meaningful here and nowhere else.
			#
			# A substring test lets every longer show starting with the same words through:
			# 'Batman: Caped Crusader S01E01' answered a scrape for 'Batman', and 'Behind The
			# Wings' / 'Super Wings' both answered 'Wings'. The equality line was already sitting
			# here commented out, so the intent was known; what it lacked was the guard that keeps
			# it off the paths where the trailing text is NOT just a title.
			#
			# Movies keep the substring test: there hdlr is the year, and the text before it
			# legitimately carries extra tokens. season == 'pack' sets hdlr to '' and so never
			# reaches this branch at all; it is named anyway to keep the condition readable.
			if season and season != 'pack':
				if not any(release_title == i for i in cleaned_titles): return False
			elif not any(item in release_title for item in cleaned_titles): return False
		else:
			release_title = release_title.replace(year, '').replace('(', '').replace(')', '').replace('&', 'and').rstrip('.-').rstrip('.').rstrip('-').replace(':', '')
			if not any(i in release_title for i in cleaned_titles): return False
		return True
	except: return True

def strip_non_ascii_and_unprintable(text):
	try:
		result = ''.join(char for char in text if char in printable)
		return result.encode('ascii', errors='ignore').decode('ascii', errors='ignore')
	except: pass
	return text

# LOCAL PATCH 2026-09-26: every HDR10+ spelling as one token, BEFORE non-alphanumerics become dots --
# after that 'HDR10+' is 'hdr10.' and cannot be told from HDR10. 'HDR10P' (HDHub, 'DV.HDR10P.H.265')
# was never recognised at all. magneto's info_from_name folds the same spellings the same way.
_HDR10_PLUS = re.compile(r'hdr10(?:\+|p(?![a-z0-9]))')
# LOCAL PATCH 2026-10-02: 'DD+' -> 'ddp' for the same reason -- 'DD+7.1' became 'dd.7.1' and get_info tagged it DD.
_DD_PLUS = re.compile(r'(?<![a-z0-9])dd\+')
# LOCAL PATCH 2026-10-02: an 'A' on a Dolby Digital token is Atmos -- 'DDPA.5.1' / 'DDPA5.1' (cTurtle and others; 24 rows
# in one cache) and 'DDP5.1A' / 'DD+5.1A' / 'DD5.1A'. Atmos rides on DD+, so these are DD+ and ATMOS both. Matched on
# get_info's dotted form ('.ddpa.5.1.'); '+' is already 'p' by then.
_DD_ATMOS = re.compile(r'\.ddpa(?=[\d.])|\.ddp?\d(?:\.\d)?a\.')


# LOCAL PATCH 2026-10-02: the results' display names. clean_file_name blanks every '.', so 'DDP5.1' read 'DDP5 1' and
# 'H.265' read 'H 265' (screenshot 115). A channel layout keeps its dot -- a lone digit, dot, lone digit, and the LAST
# such pair, so 'EAC3.5.1' gives 'EAC3 5.1' and 'S04E01.2160p' (digits on both sides) is untouched -- and so does
# H.264 / H.265. clean_file_name itself is left alone: it also names files on disk.
_KEEP_DOT = re.compile(r'(?<!\d)(\d)\.(\d)(?!\d)(?!\.\d)|(?<![A-Za-z0-9])([hH])\.(26[45])(?!\d)')
_SPACES = re.compile(r' {2,}')
_DOT_HOLD = '․'   # ONE DOT LEADER: untouched by clean_file_name's replacements, restored to '.' after

def clean_display_name(name):
	from modules.utils import clean_file_name
	held = _KEEP_DOT.sub(lambda m: _DOT_HOLD.join(g for g in m.groups() if g), name or '')
	# runs of spaces close up: '[Hindi + English]' lost its '+' to a space beside two others and read
	# 'HINDI   ENGLISH' (screenshot 122)
	return _SPACES.sub(' ', clean_file_name(held).replace(_DOT_HOLD, '.'))

def release_info_format(release_title):
	try:
		# folded before url_strip, which already turns '+' into a space
		release_title = url_strip(_DD_PLUS.sub('ddp', _HDR10_PLUS.sub('hdr10plus', (release_title or '').lower())))
		release_title = release_title.lower().replace("'", "").lstrip('.').rstrip('.')
		title = '.%s.' % re.sub(r'[^a-z0-9-~]+', '.', release_title).replace('.-.', '.').replace('-.', '.').replace('.-', '.').replace('--', '.')
		return title
	except:
		return release_title.lower()

def clean_title(title):
	try:
		if not title: return
		title = title.lower()
		title = re.sub(r'&#(\d+);', '', title)
		title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
		title = title.replace('&quot;', '\"').replace('&amp;', '&')
		title = re.sub(r'\n|([\[({].+?[})\]])|([:;–\-"\',!_.?~$@])|\s', '', title)
	except: pass
	return title

def url_strip(url):
	try:
		url = unquote_plus(url)
		if 'magnet:' in url: url = url.split('&dn=')[1]
		url = url.lower().replace("'", "").lstrip('.').rstrip('.')
		title = re.sub(r'[^a-z0-9]+', ' ', url)
		if 'http' in title: return None
		if title == '': return None
		return title
	except: return None

# LOCAL PATCH 2026-08-27: a disc source with no resolution token is not SD.
#
# get_release_quality() only recognises 720p/1080p/4K, so a release whose name says
# what it IS but not what size it is falls through to the 'SD' default. That is very
# wrong for the biggest files in the list: an 84GB "Bleach - Sennen Kessen-hen -
# Season 01 BD Remux [FLAC]" pack was being labelled SD, which sorts it last and hides
# it entirely from anyone with a 1080p minimum. Disc-sourced releases carry the tag but
# often omit the resolution, because for them it is assumed.
#
# 1080p is the floor for a Blu-ray, so it is the safe answer -- a 2160p disc release
# says 2160p and is caught by get_release_quality() before this ever runs.
_DISC_SOURCE = re.compile(r'remux|bluray|blu\.ray|bdrip|bd\.rip|bdmv|blu-ray', re.I)
# Explicit low-resolution and DVD markers must still win: "BDRip 480p" is a Blu-ray
# SOURCE at SD resolution, and assuming 1080p for it would be a straight downgrade in
# accuracy rather than an upgrade.
_LOW_RES = re.compile(r'480p|576p|360p|240p|\bdvd|dvdrip|dvd\.rip|\bvhs', re.I)


def get_file_info(name_info=None, url=None, default_quality='SD'):
	title = None
	if name_info: title = name_info
	elif url: title = url_strip(url)
	if not title: return 'SD', ''
	quality = get_release_quality(title)
	if not quality and _DISC_SOURCE.search(title) and not _LOW_RES.search(title):
		quality = '1080p'
	quality = quality or default_quality
	info = get_info(title)
	return quality, info

def get_release_quality(release_info):
	if any(i in release_info for i in ('.scr.', 'screener', 'dvdscr', 'dvd.scr', '.r5', '.r6')):
		return 'SCR'
	if any(i in release_info for i in ('.cam.', 'camrip', 'hdcam', '.hd.cam', 'hqcam', '.hq.cam', 'cam.rip', 'dvdcam')):
		return 'CAM'
	if any(i in release_info for i in ('.tc.', '.ts.', 'tsrip', 'hdts', 'hdtc', '.hd.tc', 'dvdts', 'telesync', 'tele.sync', 'telecine', 'tele.cine')):
		return 'TELE'
	if any(i in release_info for i in ('720', '720p', '720i', 'hd720', '720hd', 'hd720p', '72o', '72op')):
		return '720p'
	if any(i in release_info for i in ('1080', '1080p', '1080i', 'hd1080', '1080hd', 'hd1080p', 'm1080p', 'fullhd', 'full.hd', '1o8o', '1o8op',
		'108o', '108op', '1o80', '1o80p')): return '1080p'
	if any(i in release_info for i in ('.4k', 'hd4k', '4khd', '.uhd', 'ultrahd', 'ultra.hd', 'hd2160', '2160hd', '2160', '2160p', '216o', '216op')):
		return '4K'
	return None

# LOCAL PATCH 2026-10-05: the Dolby Vision profile a release NAME states, for the results chip (windows/sources.py):
# 'p7fel' / 'p7mel' (FEL / MEL exist only in profile 7) or 'p5' / 'p7' / 'p8' when written out ('DV P7', 'DoVi.P8',
# 'Profile 5'); None when the name does not say. The name must also say DV / DoVi / Dolby Vision.
# 2026-10-06: named only, no guessing (user's call). The 10-05 version also called every DV disc REMUX P7 and every WEB DV
# P8 / P5 from naming habits -- right for most discs, but a remux converted to P8 without saying so was marked P7 too.
_DV_NAMED = re.compile(r'(?<![a-z0-9])(?:dv|dovi|dolby[ ._-]?vision)(?![a-z0-9])', re.I)
_DV_FEL_MEL = re.compile(r'(?<![a-z0-9])(fel|mel)(?![a-z0-9])', re.I)
_DV_PROFILE = re.compile(r'(?<![a-z0-9])(?:dv[ ._-]?)?p(?:rofile)?[ ._-]?([578])(?:\.[0-9])?(?![0-9a-z])', re.I)

def dv_profile_named(name):
	name = str(name or '')
	if not _DV_NAMED.search(name): return None
	m = _DV_FEL_MEL.search(name)
	if m: return 'p7' + m.group(1).lower()
	m = _DV_PROFILE.search(name)
	return 'p' + m.group(1) if m else None

def get_info(title):
	# thanks 123Venom and gaiaaaiaai, whom I knicked most of this code from. :)
	info = []
	info_append = info.append
	if any(i in title for i in ('.3d.', '.sbs.', '.hsbs', 'sidebyside', 'side.by.side', 'stereoscopic', '.tab.', '.htab.', 'topandbottom', 'top.and.bottom')):
		info_append('[B]3D[/B]')
	if '.sdr' in title:
		info_append('SDR')
	elif any(i in title for i in ('dolby.vision', 'dolbyvision', '.dovi.', '.dv.')):
		info_append('[B]D/VISION[/B]')
	elif any(i in title for i in ('2160p.bluray.hevc.truehd', '2160p.bluray.hevc.dts', '2160p.bluray.hevc.lpcm', '2160p.blu.ray.hevc.truehd', '2160p.blu.ray.hevc.dts',
		'2160p.uhd.bluray', '2160p.uhd.blu.ray', '2160p.us.bluray.hevc.truehd', '2160p.us.bluray.hevc.dts', '.hdr.', 'hdr10', 'hdr.10', 'uhd.bluray.2160p',
		'uhd.blu.ray.2160p')):
		info_append('[B]HDR[/B]')
	elif all(i in title for i in ('2160p', 'remux')):
		info_append('[B]HDR[/B]')
	if '[B]D/VISION[/B]' in info:
		# LOCAL PATCH 2026-09-26: + hdr10plus -- 'DV HDR10PLUS' carries an HDR layer too, and without
		# the HDR tag the HDR10+ check below never ran (it got neither tag).
		if any(i in title for i in ('.hdr.', '.hdr10.', 'hdr.10', 'hdr10plus', 'hdr10.plus')) or 'hybrid' in title:
			info_append('[B]HDR[/B]')
		if '[B]HDR[/B]' in info:
			info_append('[B]HYBRID[/B]')
	# LOCAL PATCH 2026-06-15: HDR10+ token (release_info_format normalizes "+" → "."
	# so HDR10+ literal becomes "hdr10." which is ambiguous with HDR10; rely on
	# the explicit "hdr10.plus" / "hdr10plus" tokens release groups actually use.
	# HDR10+ titles also keep the broad [B]HDR[/B] tag (they ARE HDR), so existing
	# HDR=Exclude users still filter HDR10+ out without extra config.
	if '[B]HDR[/B]' in info and any(i in title for i in ('hdr10.plus', 'hdr10plus', '.hdr10p.')):
		info_append('[B]HDR10+[/B]')
	if any(i in title for i in ('avc', 'h264', 'h.264', 'x264', 'x.264')):
		info_append('AVC')
	elif '.av1.' in title:
		info_append('[B]AV1[/B]')
	elif any(i in title for i in ('h265', 'h.265', 'hevc', 'x265', 'x.265')):
		info_append('[B]HEVC[/B]')
	elif any(i in info for i in ('[B]HDR[/B]', '[B]D/VISION[/B]')):
		info_append('[B]HEVC[/B]')
	if any(i in title for i in ('.imax.', '.(imax).', '.(.imax.).')):
		info_append('IMAX')
	elif any(i in title for i in ('.enhanced.', '.upscaled.', '.enhance.', '.upscale.', '.ai.')):
		info_append('[B]AI ENHANCED/UPSCALED[/B]')
	if '.atvp' in title:
		info_append('APPLETV+')
	elif any(i in title for i in ('xvid', '.x.vid')):
		info_append('XVID')
	elif any(i in title for i in ('divx', 'div2', 'div3', 'div4')):
		info_append('DIVX')
	if any(i in title for i in ('remux', 'bdremux')):
		info_append('REMUX')
	if any(i in title for i in ('bluray', 'blu.ray', 'bdrip', 'bd.rip')):
		info_append('BLURAY')
	elif any(i in title for i in ('dvdrip', 'dvd.rip')):
		info_append('DVD')
	elif any(i in title for i in ('.web.', 'webdl', 'web.dl', 'web-dl', 'webrip', 'web.rip')):
		info_append('WEB')
	elif 'hdtv' in title:
		info_append('HDTV')
	elif 'pdtv' in title:
		info_append('PDTV')
	elif any(i in title for i in ('.hdrip', '.hd.rip')):
		info_append('HDRIP')
	_dd_atmos = _DD_ATMOS.search(title) is not None
	if 'atmos' in title or _dd_atmos:
		info_append('ATMOS')
	if any(i in title for i in ('true.hd', 'truehd')):
		info_append('TRUEHD')
	if _dd_atmos or any(i in title for i in ('dolby.digital.plus', 'dolbydigital.plus', 'dolbydigitalplus', 'dd.plus.', 'ddplus', '.ddp.', 'ddp2', 'ddp5', 'ddp7', 'eac3', '.e.ac3')):
		info_append('DD+')
	elif any(i in title for i in ('.dd.ex.', 'ddex', 'dolby.ex.', 'dolby.digital.ex.', 'dolbydigital.ex.')):
		info_append('DD-EX')
	elif any(i in title for i in ('dd2.', 'dd5', 'dd7', 'dolby.digital', 'dolbydigital', '.ac3', '.ac.3.', '.dd.')):
		info_append('DD')
	if 'aac' in title:
		info_append('AAC')
	elif 'mp3' in title:
		info_append('MP3')
	elif '.flac.' in title:
		info_append('FLAC')
	elif 'opus' in title and not title.endswith('opus.'):
		info_append('OPUS')
	if any(i in title for i in ('.dts.x.', 'dtsx')):
		info_append('DTS-X')
	elif any(i in title for i in ('hd.ma', 'hdma')):
		info_append('DTS-HD MA')
	elif any(i in title for i in ('dts.hd.', 'dtshd')):
		info_append('DTS-HD')
	elif '.dts' in title:
		info_append('DTS')
	# 'ddp5.1a.' -- the Atmos 'A' (see _DD_ATMOS) would hide '5.1.' from the channel tests
	ch_title = re.sub(r'(\d\.\d)a\.', r'\1.', title) if _dd_atmos else title
	if any(i in ch_title for i in ('ch8.', '8ch.', '7.1ch', '7.1.')):
		info_append('8CH')
	elif any(i in ch_title for i in ('ch7.', '7ch.', '6.1ch', '6.1.')):
		info_append('7CH')
	elif any(i in ch_title for i in ('ch6.', '6ch.', '5.1ch', '5.1.')):
		info_append('6CH')
	elif any(i in ch_title for i in ('ch2', '2ch', '2.0ch', '2.0.', 'audio.2.0.', 'stereo')):
		info_append('2CH')
	if '.wmv' in title:
		info_append('WMV')
	elif any(i in title for i in ('.mpg', '.mp2', '.mpeg', '.mpe', '.mpv', '.mp4', '.m4p', '.m4v', 'msmpeg', 'mpegurl')):
		info_append('MPEG')
	elif '.avi' in title:
		info_append('AVI')
	elif any(i in title for i in ('.mkv', 'matroska')):
		info_append('MKV')
	if any(i in title for i in ('hindi.eng', 'ara.eng', 'ces.eng', 'chi.eng', 'cze.eng', 'dan.eng', 'dut.eng', 'ell.eng', 'esl.eng', 'esp.eng', 'fin.eng', 'fra.eng',
		'fre.eng', 'frn.eng', 'gai.eng', 'ger.eng', 'gle.eng', 'gre.eng', 'gtm.eng', 'heb.eng', 'hin.eng', 'hun.eng', 'ind.eng', 'iri.eng', 'ita.eng', 'jap.eng',
		'jpn.eng', 'kor.eng', 'lat.eng', 'lebb.eng', 'lit.eng', 'nor.eng', 'pol.eng', 'por.eng', 'rus.eng', 'som.eng', 'spa.eng', 'sve.eng', 'swe.eng', 'tha.eng',
		'tur.eng', 'uae.eng', 'ukr.eng', 'vie.eng', 'zho.eng', 'dual.audio', 'multi')):
		info_append('MULTI-LANG')
	if any(i in title for i in ('1xbet', 'betwin')):
		info_append('ADS')
	if any(i in title for i in ('subita', 'subfrench', 'subspanish', 'subtitula', 'swesub', 'nl.subs', 'subbed')):
		info_append('SUBS')
	return ' | '.join(filter(None, info))

def get_cache_expiry(media_type, meta, season):
	try:
		current_date = get_datetime()
		if media_type == 'movie':
			premiered = jsondate_to_datetime(meta['premiered'], '%Y-%m-%d', remove_time=True)
			difference = subtract_dates(current_date, premiered)
			if difference == 0: single_expiry = 3
			elif difference <= 7: single_expiry = 24
			elif difference <= 14: single_expiry = 48
			elif difference <= 21: single_expiry = 72
			elif difference <= 30: single_expiry = 96
			elif difference <= 60: single_expiry = 168
			else: single_expiry = 336
			season_expiry, show_expiry = 0, 0
		else:
			recently_ended = False
			extra_info = meta['extra_info']
			ended = extra_info['status'] in ('Ended', 'Canceled')
			premiered = adjust_premiered_date(meta['premiered'], date_offset())[0]
			difference = subtract_dates(current_date, premiered)
			last_episode_to_air = jsondate_to_datetime(extra_info['last_episode_to_air']['air_date'], '%Y-%m-%d', remove_time=True)
			last_ep_difference = subtract_dates(current_date, last_episode_to_air)
			if ended and last_ep_difference <= 14: recently_ended = True
			if not ended or recently_ended:
				if difference == 0: single_expiry = 3
				elif difference <= 3: single_expiry = 24
				elif difference <= 7: single_expiry = 72
				else: single_expiry = 168
				if meta['total_seasons'] == season:
					if last_ep_difference <= 7: season_expiry = 72
					else: season_expiry = 240
				else: season_expiry = 720
				show_expiry = 240
			else: single_expiry, season_expiry, show_expiry = 240, 720, 720
	except: single_expiry, season_expiry, show_expiry = 72, 72, 240
	return single_expiry, season_expiry, show_expiry

def warm_rd_cache_check(data):
	"""LOCAL PATCH 2026-10-11: fetch what Real-Debrid's cache check needs that does not depend on any hash -- Torrentio's
	cached page for this title (into _CACHE_PAGE_MEMO) and a DMM token -- while the providers are still searching. Cold,
	the two cost ~1.1 s and ~0.9 s, which landed AFTER the last provider (Project Hail Mary, Clear Scrapers Cache first:
	'prefetch wait 1873ms'). Called on a thread by scrapers/external.get_sources."""
	# with no hashes the call asks Torrentio (memoised) and takes a DMM token (its dmm branch does that first), side by side
	try: get_external_cache_status('Real-Debrid', [], data, ['Real-Debrid'])
	except Exception: pass

def get_external_cache_status(debrid, unchecked_hashes, data, active_debrid):
	def _process(service, hashes):
		result = []
		if service in ('mediafusion', 'torrentio'):
			if service == 'mediafusion':
				base_link, name_test = 'https://mediafusion.elfhosted.com/%s=%s' % (debrid_name, token), '⚡'
				params = json.dumps({'enable_catalogs': False, 'max_streams_per_resolution': 99, 'torrent_sorting_priority':[], 'certification_filter': ['Disable'],
											'nudity_filter': ['Disable'], 'streaming_provider': {'token': token, 'service': debrid_name,
											'only_show_cached_streams': True}}).encode('utf-8')
				headers = {'encoded_user_data': base64.b64encode(params).decode('utf-8')}
			elif service == 'torrentio':
				base_link, name_test = 'https://torrentio.strem.fun/%s=%s' % (debrid_name, token), '[RD+]'
				headers = {'User-Agent': 'Mozilla/5.0'}
			try:
				if 'tvshowtitle' in data: url = '%s%s' % (base_link, '/stream/series/%s:%s:%s.json' % (imdb_id, data['season'], data['episode']))
				else: url = '%s%s' % (base_link, '/stream/movie/%s.json' % imdb_id)
				# LOCAL PATCH 2026-10-11: one answer per episode for 2 minutes -- the page lists every cached hash for the
				# title whatever hashes were asked about, and the scrape now asks once per prefetch batch (scrapers/external.py
				# _prefetch_debrid) plus the final check. Successes only, so a failed request is retried.
				memo = _CACHE_PAGE_MEMO.get(url)
				if memo and time.time() - memo[0] < 120: result = list(memo[1])
				else:
					result = _debrid_cache_session.get(url, headers=headers, timeout=9)
					result = result.json()['streams']
					if result:
						result = [re.search(r'\b\w{40}\b', i.get('url')) for i in result if name_test in i['name']]
						result = [i.group() for i in result if i]
					_CACHE_PAGE_MEMO[url] = (time.time(), list(result or []))
			except: pass
		elif service == 'dmm':
			# LOCAL PATCH 2026-10-11: the token comes from DMM's /api/challenge (see _dmm_token). It used to be computed here
			# from a salt in DMM's browser code; DMM moved signing server-side and stopped accepting those tokens on
			# 2026-08-31, so every check answered 403 'Authentication error' -- swallowed below -- and Real-Debrid's cache
			# status rested on Torrentio's [RD+] list alone. The Alienist S1E4: Torrentio has 1 stream, so all 65 results
			# read uncached; with a signed token DMM confirms 7, two of them whole-season BluRay packs.
			dmm_token = _dmm_token()   # not 'token': that name is the RD token the torrentio branch reads from the outer scope
			if not dmm_token: return
			dmmProblemKey, solution = dmm_token
			def fetch(hash_chunk):
				try:
					json_data = {'dmmProblemKey': dmmProblemKey, 'solution': solution, 'imdbId': imdb_id, 'hashes': hash_chunk}
					resp = _debrid_cache_session.post('https://debridmediamanager.com/api/availability/check', json=json_data, timeout=9)
					if resp.status_code != 200:
						# LOCAL PATCH 2026-10-11: said nothing before -- six weeks of 403s went unseen
						from modules.kodi_utils import logger
						logger('DMM', 'availability check: HTTP %s %s' % (resp.status_code, resp.text[:120]))
						if resp.status_code == 403: _DMM_TOKEN.update(value=None)
						return
					r = [i['hash'] for i in resp.json()['available'] if 'hash' in i]
					result_extend(r)
				except: pass
			result = []
			result_extend = result.extend
			unchecked_hashes_chunks = list(chunks(unchecked_hashes, 100))
			threads = [Thread(target=fetch, args=(item,)) for item in unchecked_hashes_chunks]
			[i.start() for i in threads]
			[i.join() for i in threads]
		results.extend(result)
	try:
		results = []
		imdb_id = data['imdb']
		# LOCAL PATCH 2026-10-11: DMM beside Torrentio rather than after it. It ran once Torrentio had answered, to skip the
		# hashes Torrentio confirmed -- but its branch checks all of unchecked_hashes regardless, so the wait bought nothing:
		# Spider-Man: Brand New Day (337 hashes, cold) took 3.3 s, Torrentio 1.1 s + DMM's token 0.9 s + its checks in a row.
		debrid_name, services, token = {'Real-Debrid': ('realdebrid', ['torrentio', 'dmm'], get_setting('deadlight.rd.token')),
										'AllDebrid': ('alldebrid', ['mediafusion'], get_setting('deadlight.ad.token'))}[debrid]
		threads = [Thread(target=_process, args=(item, unchecked_hashes)) for item in services]
		[i.start() for i in threads]
		[i.join() for i in threads]
		results = list(set(results))
	except: pass
	return results

# LOCAL PATCH 2026-08-29: pre-signed URL expiry, shared by the http_streams and aiostreams
# scrapers.
#
# Pre-signed S3/R2 links carry the moment they die in their own query string -- X-Amz-Date
# plus X-Amz-Expires -- so an expired one can be recognised with NO network call. Measured
# over 427 http_streams sources, each fetched for real and checked for a container magic
# number, evaluated against the time its label was taken:
#
#     150 pre-signed (35%)   36 expired -> all dead    114 fresh -> all alive
#     0 wrongly dropped, 0 wrongly kept
#
# Both scrapers see these URLs: the same FSL / R2 / PixelDrain hosts reach AIOStreams through
# the manifest, where 8 of 9 pre-signs on Dune Part Two and 7 of 7 on LOTR Fellowship were
# already expired.
PRESIGN_GRACE = 300           # 5 min: send a borderline link to a probe rather than dropping


def presign_expiry(url):
	"""Epoch at which a pre-signed URL stops working, or None if it is not pre-signed."""
	try:
		from urllib.parse import urlparse, parse_qs
		import calendar, time as _time
		q = parse_qs(urlparse(url).query)
		signed_at, lifetime = q.get('X-Amz-Date', [None])[0], q.get('X-Amz-Expires', [None])[0]
		if not signed_at or not lifetime: return None
		# calendar.timegm, not mktime: the stamp is UTC.
		return calendar.timegm(_time.strptime(signed_at, '%Y%m%dT%H%M%SZ')) + int(lifetime)
	except Exception:
		return None


def presign_reference(server_date, urls):
	"""Reference clock for the expiry check -> (now_epoch, trustworthy).

	Prefers the provider's own Date header. A CoreELEC box with no RTC can boot with a badly
	wrong clock, and a wrong clock here would silently drop every source. With no server date
	it falls back to the local clock, but reports untrustworthy if anything was signed in the
	future -- which can only mean our clock is behind.
	"""
	import time as _time
	if server_date:
		try:
			import email.utils
			return email.utils.parsedate_to_datetime(server_date).timestamp(), True
		except Exception:
			pass
	now = _time.time()
	for u in urls:
		exp = presign_expiry(u)
		if exp is None: continue
		try:
			from urllib.parse import urlparse, parse_qs
			life = int(parse_qs(urlparse(u).query).get('X-Amz-Expires', ['0'])[0])
		except Exception:
			continue
		if exp - life > now + PRESIGN_GRACE:
			return now, False
	return now, True


def drop_expired_presigns(sources, server_date, url_of=None, mark='_presign_ok'):
	"""Drop pre-signed sources past their expiry; flag the rest as needing no probe."""
	if not sources: return sources
	get = url_of or (lambda s: (s.get('url_dl') or s.get('url') or '').split('|', 1)[0])
	now, ok = presign_reference(server_date, [get(s) for s in sources])
	if not ok:
		from modules.kodi_utils import logger
		logger('presign gate', 'skipped: local clock appears to be behind')
		return sources
	kept, dropped = [], 0
	for s in sources:
		exp = presign_expiry(get(s))
		if exp is None:
			kept.append(s); continue
		if exp < now - PRESIGN_GRACE:
			dropped += 1; continue
		s[mark] = True
		kept.append(s)
	if dropped:
		from modules.kodi_utils import logger
		logger('presign gate', 'dropped %d expired of %d' % (dropped, len(sources)))
	return kept

# LOCAL PATCH 2026-08-29: HDHub's transcoded HLS ladder, shared by both scrapers.
#
# HDHub exposes /resolve/cj/tmdb/<id>/<res>.m3u8 alongside the real files. The rows tag
# themselves by RESOLUTION and carry a bitrate nowhere near it -- read out of the master
# playlists for LOTR The Two Towers:
#
#     4K    3840x2160  BANDWIDTH=8390585  ->  8.4 Mbps
#     1080p 1920x1080  BANDWIDTH=2112780  ->  2.1 Mbps
#     720p  1280x720   BANDWIDTH=1588374  ->  1.6 Mbps
#
# A real 4K remux runs 50-100 Mbps, so a row reading "4K" here is a heavily compressed
# stream sitting next to a 29 GB file claiming the same thing. Nothing else catches them:
# they play, so validation passes them, and quality sorting keys on the resolution token,
# which is honest. They also report 0.00-0.02 GB, so they do not sort down either.
#
# Matched on the endpoint, NOT on '.m3u8' in general -- img1's index_NNN.m3u8 is a
# full-length stream (Fellowship: 4148 segments, 228 min) and must survive.
_TRANSCODE_MARKER = '/resolve/cj/'


def is_transcode_url(url):
	"""True for HDHub's resolution-ladder HLS, which is not the release it claims to be."""
	return _TRANSCODE_MARKER in (url or '').lower()

# LOCAL PATCH 2026-09-01: release-name parsing shared by the subtitle scorer
# (indexers/subtitles.py) and the SmartPlay sticky matcher (modules/sources.py). It lived in
# subtitles.py first and was moved here because modules/ must not import from indexers/.
# Deliberately NOT merged with normalize() above -- that one strips unicode accents, this one
# reduces release separators to single spaces. Different jobs, similar names.

def release_norm(text):
	"""Lowercase, with every release separator reduced to a single space.

	Padded with spaces at both ends so a needle like ' web ' cannot match inside a word.
	"""
	text = (text or '').lower()
	for ch in ('.', '_', '-', '[', ']', '(', ')', '+', "'", ','):
		text = text.replace(ch, ' ')
	return ' %s ' % ' '.join(text.split())


# LOCAL PATCH 2026-09-02: site tags that are legitimate release groups despite the dot.
# Deliberately a closed TLD list rather than r'\.[a-z]{2,4}$' -- the open form would also
# swallow '...-Something.2001' style title hyphens.
_SITE_TAG_RE = re.compile(r'^([a-z0-9]{2,})\.(com|net|org|to|me|cc|tv|io|co|info|xyz|site|link|pw|in|is|se|nu|ws|sx)$')

# LOCAL PATCH 2026-10-02: see _clean_group_token / release_group.
_NOT_GROUPS = frozenset(('dl', 'dv', 'br', 'la', 'lat', 'us', 'uk', 'hd', 'sd', 'hdr', 'sdr', 'rip', 'ma', 'x', 'ray',
	'eng', 'esp', 'spa', 'sub', 'subs', 'subbed', 'audio', 'x264', 'x265', 'h264', 'h265', 'ac3', 'eac3', 'aac',
	'hdma', 'subtitle', 'subtitles'))   # 2026-10-06: 'DTS-HDMA.', '...-english-subtitles.' once trailing dots were read
_TRAILING_LANG = re.compile(r'(?:[.\s_]+(?:multi|dual|[a-z]{2,3}-(?:br|la|lat|mx|us|uk|pt|es)))+$', re.I)

# LOCAL PATCH 2026-09-03: tails that are an episode marker rather than a releaser.
_EPISODE_TOKEN_RE = re.compile(r'^(?:s\d{1,3}e\d{1,4}|e\d{1,4}|ep\d{1,4}|\d{1,4})(?:v\d{1,2})?$')


# LOCAL PATCH 2026-09-03: the group-token rules, shared by the pipe and hyphen paths in
# release_group so the two cannot drift. A site tag may carry ONE dot plus a known TLD
# (stripped); anything else dotted is release metadata, not a group.
def _clean_group_token(raw):
	tok = re.split(r'[\[\](){}]', raw or '')[0].strip().lower()
	if '.' in tok:
		m = _SITE_TAG_RE.match(tok)
		if not m: return ''
		tok = m.group(1)
	if not tok or ' ' in tok or len(tok) > 20: return ''
	if tok.isdigit(): return ''
	# LOCAL PATCH 2026-09-03: an EPISODE MARKER after the final separator is not a group.
	# '[Judas] Re.Zero - S04E01.mkv' was parsing as group 's04e01', and SmartPlay's
	# same-release tier compares release_group(candidate) against the pin's -- 's04e01'
	# against the next episode's 's04e02' can never be equal, so the tier could not chain
	# a Judas-style name at all. Third case of the same family as the '4KHDHub.com' and
	# pipe-tag fixes. The v-suffix is allowed for so 'S04E01v2' is caught too.
	if _EPISODE_TOKEN_RE.match(tok): return ''
	# LOCAL PATCH 2026-10-02: the second half of a hyphenated TAG, never a releaser -- 'WEB-DL', 'HDR-DV', 'PT-BR',
	# 'SPA-LA', 'DTS-HD' (a cached scan of 665 hashes found dl / dv / br / la read as groups)
	if tok in _NOT_GROUPS: return ''
	return tok

def release_group(name):
	"""Release group -- the token after the final '-', where scene and p2p names put it.

	Parsed from the RAW name, before _norm() would eat the hyphen. Returns '' when the name
	does not follow the convention, so a hyphen inside a title cannot masquerade as a group.
	"""
	# LOCAL PATCH 2026-10-06: stray dots after the extension too -- mediafusion lists 'H264-ENIGMA-[DUS-IcTv].mkv.'
	name = re.sub(r'\.(mkv|mp4|avi|m2ts|ts|srt|vtt|ass|ssa|sub)$', '', (name or '').strip().rstrip('.'), flags=re.I)
	# LOCAL PATCH 2026-09-03: some sources put the tag after a PIPE, not a hyphen, and for
	# those the hyphen rule below reads garbage out of the middle of the name. The
	# http_streams/PixelDrain form ends '... | <host> | 4KHDHub', so
	#   '[PixelDrain] The.Rising.of.the.Shield.Hero.S02E02....AAC2.0. pixeldrain | 4KHDHub'
	# split on its final '-' gives 'DL.MULTi.AAC2.0. pixeldrain | 4khdhub' -- dots, spaces
	# and a pipe, so it was rejected and pin_group came back ''. sources.py runs the
	# same-release tier only `if pin_group`, so the tier was skipped outright: observed as
	# 'sticky entry present but unmatched in 29 results' on Shield Hero S02E03 while the pin
	# was a PixelDrain S02E02, and the same for the Frieren pin.
	#
	# Taking the LAST pipe field normalises it to '4khdhub' -- the same token the hyphen
	# form '-4kHdHub.Com' yields -- so a PixelDrain pin now follows onto that site's
	# ordinary releases and back again. Tried before the hyphen rule because when a pipe is
	# present the hyphen tail is meaningless; it falls through if the pipe field is not a
	# clean token, so a name that merely happens to contain a pipe is unaffected.
	if '|' in name:
		_piped = _clean_group_token(name.rsplit('|', 1)[1])
		# LOCAL PATCH 2026-09-27: but the site is only the group when the name inside the decoration has
		# none of its own. http_streams wraps EVERY 4KHDHub-listed file the same way, whoever released it:
		#   '[PixelDrain] Mushoku.Tensei...S02E04...CR.WEB-DL.AAC2.0.H.264-DEV1L. pixeldrain | 4KHDHub'
		# read as '4khdhub', so a pin on the plain 'S02E03...H.264-DEV1L.mkv' (group 'dev1l') rejected
		# both E04 copies on group ('rejected on {group: 12}', 14:59 on 09-27) and SmartPlay fell back to
		# a full scrape. So strip ' <host> | <site>' plus the truncated extension ('.', '.m') 4KHDHub
		# leaves, and read the hyphen group of what remains. The site still wins when that group is empty
		# ('...AAC2.0. pixeldrain | 4KHDHub', the Shield Hero case above) or is the site's own name cut
		# short ('H.264-4k FSL | 4KHDHub', '-4kH', '-4kHd'), so those keep matching '-4kHdHub.Com'.
		_inner = re.sub(r'\s+\S+\s*\|[^|]*$', '', name)
		_inner = re.sub(r'\.(?:m|mk|mkv|mp|mp4)?$', '', _inner, flags=re.I)
		_own = _clean_group_token(_inner.rsplit('-', 1)[1]) if _inner != name and '-' in _inner else ''
		if _own and not (_piped and _piped.startswith(_own)): return _own
		if _piped: return _piped
	# LOCAL PATCH 2026-10-02: trailing language tags go first -- 'REMUX-FraMeSToR.MULTI.PT-BR' read as group 'br'.
	name = _TRAILING_LANG.sub('', name)
	# LOCAL PATCH 2026-10-06: an uploader's bracketed tag AFTER the group -- 'H264-ENIGMA-[DUS-IcTv]' read 'ictv', the hyphen
	# inside the tag being the last one. The group in front of it wins when there is one; when there is none the bracket
	# is read as before, so Polish releasers signing inside it ('DVDRip.[XviD-R22]') keep their group.
	_tagged = re.match(r'^(.*?)[\s._-]*\[[^\[\]]*\]\s*$', name)
	if _tagged and '-' in _tagged.group(1):
		_before = release_group(_tagged.group(1))
		if _before: return _before
	if '-' not in name: return ''
	tail = name.rsplit('-', 1)[1]
	# NOT 'a hyphen inside brackets is never the group': Polish releasers sign that way ('[XviD-R22]', '[x265-AdL]',
	# '[AC3-OzW]'). The bracketed junk ('[WEB-DL]', '[ESP-ENG]', '[Dual-Audio]', '[Multi-Subs]') is all tag words,
	# which _NOT_GROUPS rejects wherever they stand.
	# A real group token is not just digits; a tail with a dot is usually a hyphen from
	# the title itself ('A-Movie-With-Hyphens.2001.1080p'), not a group.
	#
	# LOCAL PATCH 2026-09-02: except when the dot belongs to a SITE TAG, which is a real
	# group name. Rejecting every dotted tail silently disabled SmartPlay's same-release
	# tier for every release from a site-tagged source: the pin
	# 'Lanterns.S01E02.Trust.Fall.2160p.AMZN.WEB-DL...H.265-4KHDHub.com.mkv' parsed to '',
	# and sources.py only runs that tier `if pin_group`, so Lanterns S01E03 fell through to
	# the picker every time -- logged as 'sticky entry present but unmatched in 55 results'
	# with the correct release sitting in those 55. Same for Re:ZERO's '-4kHdHub.Com'.
	#
	# A site tag is domain-shaped: ONE dot and a short alpha TLD. The title-hyphen case it
	# has to stay separated from carries release metadata after the dot ('hyphens.2001.1080p'
	# -- two dots, no TLD), so requiring exactly one dot plus a known TLD keeps them apart.
	# The TLD is then STRIPPED, so '4KHDHub.com', '4kHdHub.Com' and a bare '4KHDHub' all
	# normalise to '4khdhub' and a pin matches its own site's other releases however that
	# site chose to spell itself on the day.
	return _clean_group_token(tail)

def same_group(a, b, min_prefix=3):
	"""release_group() results naming the same releaser. LOCAL PATCH 2026-09-27: 4KHDHub cuts names short, so
	one file lists as '-DEV1' and its twin as '-DEV1L'; a prefix of 3+ characters counts (min_prefix, lowered
	by the caller only for a name name_was_cut() says was truncated). Episode, source, quality and service are
	still checked by the caller -- this only stops the group test rejecting a twin."""
	if not a or not b: return False
	if a == b: return True
	short, long_ = (a, b) if len(a) < len(b) else (b, a)
	return len(short) >= min_prefix and long_.startswith(short)

# LOCAL PATCH 2026-09-27: 4KHDHub cuts the release name at 100 characters before http_streams decorates it, so a
# long episode title eats into the group: Mushoku Tensei S02E05 'Ranoa.University.of.Magic' left '...H.264-D' and
# '-DE' for DEV1L, which the 3-character prefix could not match ('rejected on {group: 12}', 16:21). All 12 cut
# names cached then measured exactly 100; the uncut ones end in '.mkv'.
_DECORATED_RE = re.compile(r'^(?:\[[^\]]+\]\s*)?(.*?)\s+\S+\s*\|[^|]*$')

def name_was_cut(name):
	"""True for an http_streams-decorated name whose release name hit 4KHDHub's 100-character cut."""
	m = _DECORATED_RE.match((name or '').strip())
	return bool(m) and len(m.group(1)) >= 100 and not re.search(r'\.(mkv|mp4|avi|m4v|ts)$', m.group(1), re.I)

def group_lost_to_cut(name):
	"""LOCAL PATCH 2026-09-27: the cut took the whole group, so release_group() fell back to the site after the
	pipe. S02E07 'The.Kidnapping.and.Confinement.of.Beast.Girls' ended at '...1080p.CR.W': group AND source gone,
	and a pin reading group=4khdhub source='' then matched nothing for E08. A name like that says nothing about
	its group -- the group test must be skipped for it, not failed."""
	if not name_was_cut(name): return False
	site = _clean_group_token((name or '').rsplit('|', 1)[-1])
	return bool(site) and release_group(name) == site

# LOCAL PATCH 2026-10-08: HDR10 / HDR10+ / HDR10P / bare HDR; 'HdHub' is not one (no r after the d)
_HDR_NAMED = re.compile(r'(?<![a-z0-9])hdr(?:10(?:\+|p|plus)?)?(?![a-z0-9])', re.I)

def release_dynamic_range(name):
	"""LOCAL PATCH 2026-10-08: 'dv', 'hdr' or 'sdr' as the name states it, '' when it cannot say. A DV release with an
	HDR layer is 'dv'. A name 4KHDHub cut that names neither is '' rather than 'sdr': the cut usually falls right where
	DV.HDR would be. http_streams adds the site's own 'HDR DV' tags after a cut name, so a cut DV row still reads 'dv'."""
	name = str(name or '')
	if _DV_NAMED.search(name): return 'dv'
	if _HDR_NAMED.search(name): return 'hdr'
	return '' if name_was_cut(name) else 'sdr'



def release_source(norm_text):
	"""Source family, '' when the name says nothing about it.

	Order matters: the specific spellings must be tested before the generic ones, or
	'web dl' is caught by the bare 'web' test and a bdremux by 'bluray'.
	"""
	for needle, family in (
		(' bdremux ', 'remux'), (' remux ', 'remux'),
		(' bluray ', 'bluray'), (' blu ray ', 'bluray'), (' bdrip ', 'bluray'), (' brrip ', 'bluray'),
		(' web dl ', 'web'), (' webdl ', 'web'), (' webrip ', 'web'), (' web ', 'web'),
		(' uhdtv ', 'hdtv'), (' hdtv ', 'hdtv'), (' dvdrip ', 'dvd'), (' dvd ', 'dvd'), (' hdrip ', 'hdrip')):
		if needle in norm_text: return family
	return ''

def release_service(norm_text):
	"""Streaming service a WEB release came from, '' when the name does not say.

	LOCAL PATCH 2026-09-01. release_source() answers the FAMILY question -- web vs bluray vs
	hdtv -- and deliberately lumps every WEB platform together, which is right for scoring a
	subtitle but far too loose for following a SmartPlay pin. Observed: a pin on
	'...S01E03.Smoke.3.1080p.NF.WEB-DL...-VARYG' chained onto
	'...S01E04.Learning....1080p.CR.WEB-DL...-VARYG'. Same group, same quality, same audio,
	same codec, same family -- but Netflix and Crunchyroll are different masters, with their
	own encodes and their own intro placement. The naming convention gives it away too: the
	NF line numbers its episodes 'Smoke.3', the CR line uses the real episode title.

	Tags kept deliberately unambiguous once separators become spaces. Notably ABSENT: 'ma',
	which would match the MA in 'DTS-HD.MA', and any other two-letter token that collides
	with an audio or codec field.
	"""
	for tag in (' nf ', ' amzn ', ' dsnp ', ' hmax ', ' atvp ', ' hulu ', ' cr ', ' funi ',
		' hidive ', ' pcok ', ' stan ', ' crav ', ' viu ', ' tving ', ' adn ', ' starz ',
		' mubi ', ' roku ', ' itunes ', ' aniplus ', ' bilibili ', ' b global '):
		if tag in norm_text: return tag.strip()
	return ''
