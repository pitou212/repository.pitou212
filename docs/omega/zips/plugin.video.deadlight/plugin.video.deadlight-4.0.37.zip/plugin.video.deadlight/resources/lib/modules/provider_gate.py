# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-11-23 (user): the anime gate of DeadLight's own scrapers -- the HTTP site scrapers (site_scrapers.SITES),
the Stremio add-on slots, AIOStreams and Easynews. The same model as the torrent providers (source_utils.ANIME_PROVIDERS):
two lists that never touch.

  Movies & TV  each provider's own switch (http_streams.<key>, http_streams.stremio<N>, provider.aiostreams / easynews)
  Anime        the ticks in scrape.anime_direct_providers (Options > Anime Scrapers on an anime item)

ANIME_ONLY never run off anime (AnimeDubHindi: Hindi dubs of anime only). HTTP Scrapers (provider.http_streams) stays the
site scrapers' master switch on both lists, as External is for the torrent sites. The debrid clouds and folders are the
user's own files and are not gated.

'Rescrape With All Scrapers' / Options > 'Scrape with ALL' (all_scrapers=True, the user, 2026-11-23): every provider that
is set up runs, the switches and HTTP Scrapers' master switch ignored -- but the ANIME GATES HOLD: on anime only the anime
list's ticks, off anime never ANIME_ONLY (a site kept for Movies & TV, Cinejoy, stays off anime even then).

The verdict is decided ONCE per scrape (modules/sources: metadata.is_anime_meta on the scrape's meta) and handed to the
scrapers as search_info['is_anime']; info_is_anime() falls back to the cached meta only for a caller that did not set it.
Light on purpose: http_streams, settings and the widgets' prewarm import it."""
from caches.settings_cache import get_setting, set_setting

ANIME_DIRECT_SETTING = 'scrape.anime_direct_providers'
# The setting's row is created by caches/settings_cache.sync_settings from each provider's own switch (what ran on anime
# before the gate existed, minus the HTTP sites kept for Movies & TV); this is only the fallback before that first sync.
ANIME_DIRECT_DEFAULT = 'animedubhindi,stremio1,stremio2,stremio3,aiostreams,easynews'
NOTHING = 'none'   # an empty list as stored: get_setting returns the fallback for an empty value; not a provider key
ANIME_ONLY = ('animedubhindi',)
_OWN_SWITCH = {'aiostreams': 'provider.aiostreams', 'easynews': 'provider.easynews'}   # else http_streams.<key>


def anime_ticks():
	raw = get_setting('deadlight.%s' % ANIME_DIRECT_SETTING, ANIME_DIRECT_DEFAULT)
	return {i.strip().lower() for i in (raw or '').split(',') if i.strip()} - {NOTHING}


def own_scrapers():
	"""[(key, label)] an anime list can tick besides the torrent sites -- the HTTP sites, the Stremio slots with a manifest,
	AIOStreams, Easynews -- for Settings > Anime Providers and Options > Anime Scrapers alike."""
	from scrapers.site_scrapers import SITES
	from scrapers import stremio_addons
	items = [(key, label) for key, label, _module, _picker in SITES]
	items += [('stremio%d' % slot, stremio_addons.addon_name(slot, url)) for slot in stremio_addons.SLOTS if (url := stremio_addons.manifest_url(slot))]
	return items + [('aiostreams', 'AIOStreams'), ('easynews', 'Easynews')]


def save_anime_ticks(shown, chosen):
	"""Write the anime list from a menu: the keys it showed are set from `chosen`, any tick it did not show (a slot whose
	manifest is gone, a site under a switched-off HTTP Scrapers) is kept."""
	ticks = (anime_ticks() - set(shown)) | set(chosen)
	set_setting(ANIME_DIRECT_SETTING, ','.join(sorted(ticks)) or NOTHING)


def switched_on(key):
	"""The provider's own (Movies & TV) switch."""
	return get_setting('deadlight.%s' % _OWN_SWITCH.get(key, 'http_streams.%s' % key), 'false') == 'true'


def set_up(key):
	"""Can the provider run at all: AIOStreams needs its manifest, Easynews its account (a Stremio slot's manifest is
	checked in stremio_slots_to_run; the HTTP sites need nothing)."""
	if key == 'aiostreams': return get_setting('deadlight.aiostreams.manifest_url', '').strip() not in ('', 'empty_setting', 'None')
	if key == 'easynews': return get_setting('deadlight.easynews_user', 'empty_setting') not in ('', 'empty_setting', 'None')
	return True


def runs_all(key, is_anime, ticks=None):
	"""'Scrape with ALL': every set-up provider the anime gate lets through (switches ignored)."""
	if is_anime: allowed = key in (anime_ticks() if ticks is None else ticks)
	else: allowed = key not in ANIME_ONLY
	return allowed and set_up(key)


def provider_runs(key, is_anime, all_scrapers=False, ticks=None):
	"""The one entry point: runs() normally, runs_all() on 'Scrape with ALL'; never a provider that is not set up."""
	return runs_all(key, is_anime, ticks) if all_scrapers else (runs(key, is_anime, ticks) and set_up(key))


def runs(key, is_anime, ticks=None):
	"""Does provider `key` run on this title? `ticks` = anime_ticks(), passed in by callers that ask for many keys."""
	# On anime the tick alone decides, as for the torrent sites (the user, 2026-11-23): a switch that is off for Movies & TV
	# does not stop an anime tick, so the Anime Scrapers menu shows exactly what runs
	if is_anime: return key in (anime_ticks() if ticks is None else ticks)
	return key not in ANIME_ONLY and switched_on(key)


def sites_to_run(is_anime, all_scrapers=False):
	"""site_scrapers.SITES entries to run; none with HTTP Scrapers off (unless 'Scrape with ALL')."""
	if not all_scrapers and get_setting('deadlight.provider.http_streams', 'false') != 'true': return []
	from scrapers.site_scrapers import SITES
	ticks = anime_ticks() if is_anime else None
	return [site for site in SITES if provider_runs(site[0], is_anime, all_scrapers, ticks)]


def stremio_slots_to_run(is_anime, all_scrapers=False):
	"""[(slot, manifest url)] of the Stremio slots to run (a slot without a manifest never runs)."""
	from scrapers.stremio_addons import SLOTS, manifest_url
	ticks = anime_ticks() if is_anime else None
	return [(slot, url) for slot in SLOTS if provider_runs('stremio%d' % slot, is_anime, all_scrapers, ticks) and (url := manifest_url(slot))]


def info_is_anime(info):
	"""The scrape's verdict (search_info['is_anime']); without one, metadata.is_anime_meta on the cached meta (unknown -> False)."""
	if 'is_anime' in info: return bool(info['is_anime'])
	try:
		from caches.meta_cache import meta_cache
		from modules.metadata import is_anime_meta
		meta = meta_cache.get('movie' if info.get('media_type') == 'movie' else 'tvshow', 'tmdb_id', info.get('tmdb_id'))
		return bool(meta) and bool(is_anime_meta(meta))
	except Exception: return False
