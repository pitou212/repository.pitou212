# LOCAL PATCH 2026-11-16 (DeadLight): sukebei.nyaa.si, nyaa's adult site, where hentai releases are posted -- nyaa.py's
# code against its host and Anime category (1_1). Runs on adult anime only (modules/source_utils.ADULT_ANIME_PROVIDERS);
# there is no provider.sukebei switch, so Movies & TV never load it. One host: the translate proxy answers sukebei 400.

from magneto.providers.torrents.nyaa import source as _NyaaSource


class source(_NyaaSource):
	provider = 'sukebei'
	hosts = (('https://sukebei.nyaa.si', ''),)
	host_prop = 'magneto.sukebei_host'
	category = '1_1'
