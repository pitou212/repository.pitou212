# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-11-18: HDHub4u (hdhub4u.*) episodes and films, one of Direct Streams' providers (scrapers/http_streams,
setting http_streams.hdhub4u). The HDHub aggregator lists some of HDHub4u's film files (Animal 2023: 21 rows, PixelDrain /
R2) but not its series episodes (Panchayat S04E01: 2 SD transcodes); films are read here too since 2026-11-18 (_scrape_film).

The site, as read 2026-11-18:
  - try the last working domain or new15.hdhub4u.cl first, then ask the site's lookup endpoints if a request fails.
    Post permalinks keep the old domain: only their path is used.
  - search is a Typesense index (search.pingora.fyi) with an imdb_id field: posts are found by the exact IMDb id.
  - a season post ('Panchayat (Season 4) ... ALL Episodes') lists per episode a 'Drive' link,
      hubcloud.*/drive/search-recover.php?from_ac=<token>&q=<base64 'Panchayat S04 Episode 1'>
    a page that searches HubCloud's file index for that query (JSON: ?api=search&q=..&page=..&from_ac=..). Its hits are
    every upload of that name -- HDHub4u's own episode files among them, each a hubcloud.*/drive/<id> page, resolved at
    play time (scrapers/hubcloud). Only the post's own query is asked: the page marks it locked (the server does not
    enforce that; DeadLight keeps to it).
  - a film post links each quality through the greenmotors.club / gadgetsweb protector (_scrape_film).
  - not used: 'Instant' hubcdn.* links (every one tried: 'File is Deleted or UnAvailable')."""
import base64
import html
import re
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
from modules.kodi_utils import logger
from modules.source_utils import get_aliases_titles
from scrapers._site_common import (get as _get, episode_tag as _episode_tag, with_site_host, norm_title as _norm, title_prefix_ok,
								  hubcloud_recover_links as _recover_links,
								  hubdrive_file as _shared_hubdrive_file, hubdrive_pack_files as _shared_pack_files,
								  protected_page_files as _protected_page_files, film_name_ok, hubcloud_row, recall, keep, forget,
								  protector_url_ok, episode_pairs, site_post_page, site_origin, HIGH_QUALITY as _HIGH_QUALITY,
								  stated_quality_ok, recover_query_ok)
from scrapers.hubcloud import recover_query as _query_text, recover_hits as _recover_hits

LABEL = 'HDHub4u'
_SEARCH = 'https://search.pingora.fyi/collections/post/documents/search'
# the site's own 'where is HDHub4u now' endpoints (its home page tries them in turn); each answers {"c": base64 url}
_HOST_LOOKUPS = ('https://dns.pingora.fyi/v2/host', 'https://h4.suncdn.org/host/', 'https://ml.theapii.org/host/')
_HOST_FALLBACK = 'https://new15.hdhub4u.cl'
_HOST_PROPERTY = 'deadlight.hdhub4u.host'
_SEASONS = re.compile(r'\bSeason\s*(\d{1,2})(?:\s*(?:-|–|&|to)\s*(\d{1,2}))?', re.I)
_QUERY_EPISODE = re.compile(r'\bS(\d{1,2})\s*(?:E|Ep(?:isode)?\.?\s*)(\d{1,3})\b', re.I)
# LOCAL PATCH 2026-11-22: HubDrive links anchored at the host (hubdrive.<tld>/file/<n>), like _site_common's -- '[^"']+' let a
# post send the addon to 'https://hubdrive.x@192.168.1.1/file/1' (see protector_url_ok)
_HUBDRIVE_FILE_ANCHOR = re.compile(r'''<a\b[^>]*href=["'](https?://hubdrive\.[a-z]+/file/\d+/?)["'][^>]*>(.*?)</a>''', re.I | re.S)

_PROTECTOR_EPISODE = re.compile(r'''<a\b[^>]*href=["'](https?://[^"']+)["'][^>]*>\s*(?:EPiSODE|EP|E)\s*0*(\d{1,3})\s*</a>''', re.I)
# a film post's quality links: '<a href="https://greenmotors.club/...">1080p HEVC [2.3GB]</a>' (one per quality; 'WATCH ONLiNE'
# and the 480p hubcdn 'Instant' link carry no resolution / another host)
_FILM_LINK = re.compile(r'''(?is)<a\b[^>]*href=["'](https?://[^"']*(?:greenmotors|gadgetsweb)\.[^"']+)["'][^>]*>((?:(?!</a>).)*?\b(?:\d{3,4}p|4K)\b(?:(?!</a>).)*)</a>''')
# LOCAL PATCH 2026-11-21: some quality links point straight to HubDrive file pages instead of through the protector. Keep the
# quality label check so unrelated HubDrive controls on the page don't become film results. Host-anchored (see above).
_FILM_HUBDRIVE_LINK = re.compile(r'''(?is)<a\b[^>]*href=["'](https?://hubdrive\.[a-z]+/file/\d+/?)["'][^>]*>((?:(?!</a>).)*?\b(?:\d{3,4}p|4K)\b(?:(?!</a>).)*)</a>''')


_POSTS_TTL = 12 * 3600


class _Stale(Exception):
	"""A kept post list led nowhere (a post moved, or a new season's post is not in it): search again, once."""


def _search_posts(imdb, host, fresh=False):
	"""(hit count, the posts filed under exactly `imdb`, from_cache) from the site's Typesense index. The index answers 403
	without the site as Referer + Origin. num_typos 0: with typo
	tolerance the id of a show it lacks matched a near one (Marriage Toxin tt39122769 -> Happy Raj tt39122419).
	LOCAL PATCH 2026-11-18: a found list is kept 12 h in a Home property every DeadLight process sees -- the search took
	1.0-1.4 s of an episode's ~4 s (Dupahiya, 2026-11-18). Only a found list is kept; a failed search still raises."""
	prop = 'deadlight.hdhub4u.posts.%s' % imdb
	kept = None if fresh else recall(prop, _POSTS_TTL)
	if kept and kept.get('docs'): return kept.get('n', 0), kept['docs'], True
	hits = _get(_SEARCH, referer=host + '/', origin=host,
				params={'q': imdb, 'query_by': 'imdb_id', 'limit': 50, 'highlight_fields': 'none', 'num_typos': 0}).json().get('hits') or []
	docs = [h['document'] for h in hits if (h.get('document') or {}).get('imdb_id') == imdb]
	if docs: keep(prop, {'n': len(hits), 'docs': [dict((k, d.get(k)) for k in ('imdb_id', 'permalink', 'post_title')) for d in docs]})
	else: forget(prop)
	return len(hits), docs, False


def _scrape_film(info, imdb, fresh=False):
	"""LOCAL PATCH 2026-11-18: a film post's files. Each quality ('720p HEVC [1GB]', '1080p Links [4.1GB]', '4K [2160p ...]')
	is one protector link (greenmotors / gadgetsweb) -> its HBLINKS archive -> HubDrive / HubCloud pages
	(_site_common.protected_page_files), resolved at play time like the episodes' rows."""
	title = info.get('title') or ''
	try: year = int(info.get('year') or 0)
	except (TypeError, ValueError): year = 0
	host, (count, docs, cached) = _search_on_site(imdb, fresh)
	if not docs:
		logger('HDHub4u', '%s (%s): no post (%d hit(s) for %s)' % (title, year or '', count, imdb))
		return []
	try: host, page = _post_page(urlparse(docs[0].get('permalink') or '').path, host)
	except Exception:
		if cached: raise _Stale()
		raise
	protectors = list(dict.fromkeys(html.unescape(u) for u, label in _FILM_LINK.findall(page)
									 if _HIGH_QUALITY.search(html.unescape(label)) and protector_url_ok(u)))
	drive_pages = list(dict.fromkeys(html.unescape(u) for u, label in _FILM_HUBDRIVE_LINK.findall(page)
									 if _HIGH_QUALITY.search(html.unescape(label))))
	if not protectors and not drive_pages:
		logger('HDHub4u', '%s (%s): no quality link on %r' % (title, year or '', (docs[0].get('post_title') or '')[:70]))
		return []
	def follow(protector):
		try: landing = _get(protector, referer=host + '/').text
		except Exception as e: return [], e
		return _protected_page_files(landing, protector, (), quality_pattern=_HIGH_QUALITY)[0], None
	def follow_drive(url):
		hit = _shared_hubdrive_file(url)
		return ([hit] if hit else []), None
	tasks = [(follow, url) for url in protectors] + [(follow_drive, url) for url in drive_pages]
	with ThreadPoolExecutor(max_workers=min(8, len(tasks))) as ex:
		results = list(ex.map(lambda task: task[0](task[1]), tasks))
	files = {}
	for found, _error in results:
		for hit in found:
			if hit.get('url'): files.setdefault(hit['url'], hit)
	errors = [e for _found, e in results if e]
	if not files and errors:
		# every quality link failed to load: a failure, not an empty answer (http_streams then caches nothing)
		logger('HDHub4u', '%s (%s): %d of %d quality link(s) unreachable: %r' % (title, year or '', len(errors), len(tasks), errors[0]))
		raise errors[0]
	names = set(n for n in (_norm(t) for t in [title] + get_aliases_titles(info.get('aliases', []))) if n)
	rows = _film_rows(files.values(), year, names)
	logger('HDHub4u', '%s (%s): %d file(s) of %d from %d protector + %d direct HubDrive quality link(s), post %r' %
		(title, year or '', len(rows), len(files), len(protectors), len(drive_pages), (docs[0].get('post_title') or '')[:70]))
	return rows


def _film_rows(hits, year, names):
	"""The hits naming this film (_site_common.film_name_ok: its title before its year, never a longer title)."""
	rows = []
	for hit in hits:
		name, url = (hit.get('file_name') or '').strip(), hit.get('url') or ''
		if 'video' not in (hit.get('mimeType') or '') or '/drive/' not in url: continue
		if _HIGH_QUALITY.search(name) and film_name_ok(name, year, names): rows.append(hubcloud_row(LABEL, name, url, hit.get('size')))
	return rows


def scrape(info):
	"""Stremio-shaped rows (http_streams._make_item reads them) for info's episode or film. Raises on a failed request, so
	http_streams counts the provider as failed and does not cache the empty answer."""
	media_type = info.get('media_type')
	if media_type not in ('episode', 'movie'): return []
	imdb = str(info.get('imdb_id') or '')
	if not imdb.startswith('tt'): return []
	work = _scrape_film if media_type == 'movie' else _scrape_episode
	started = time.monotonic()
	try:
		try: return work(info, imdb)
		except _Stale: return work(info, imdb, fresh=True)   # the kept post list led nowhere: search again, once
	finally:
		# LOCAL PATCH 2026-11-22: a timing line, so only with the timing diagnostics on (modules/settings.DIAG_TIMING)
		from modules.settings import diag_timing
		if diag_timing(): logger('HDHub4u timing', '%s: %d ms' % (info.get('title') or imdb, int((time.monotonic() - started) * 1000)))


def _scrape_episode(info, imdb, fresh=False):
	try: season, episode = int(info.get('season')), int(info.get('episode'))
	except (TypeError, ValueError): return []
	if season < 1: return []
	title = info.get('title') or ''
	wanted = episode_pairs(info, season, episode)   # incl. the absolute number under a season label (_site_common)
	host, (count, docs, cached) = _search_on_site(imdb, fresh)
	posts = []
	for doc in docs:
		seasons = set()
		for m in _SEASONS.finditer(doc.get('post_title') or ''):
			seasons.update(range(int(m.group(1)), int(m.group(2) or m.group(1)) + 1))
		if any(s in seasons for s, _e in wanted): posts.append((doc, seasons))
	if not posts:
		if cached: raise _Stale()   # a season posted since the list was kept
		logger('HDHub4u', '%s S%02dE%02d: no season post (%d post(s) for %s)' % (title, season, episode, count, imdb))
		return []
	names = set(n for n in (_norm(t) for t in [title] + get_aliases_titles(info.get('aliases', []))) if n)
	for doc, seasons in posts:
		path = urlparse(doc.get('permalink') or '').path
		try: host, page = _post_page(path, host)
		except Exception:
			if cached: raise _Stale()
			raise
		files, how = {}, ''
		# A pack can contain 4K while the episode section contains 1080p. Start fetching
		# section files while reading packs, and fetch each HubDrive URL only once.
		sections = _hubdrive_links(page, [e for s, e in wanted if s in seasons])
		with ThreadPoolExecutor(max_workers=8) as ex:
			pending = {url: ex.submit(_hubdrive_file, url) for url in sections}
			packed = _pack_files(page, wanted, '%s S%02dE%02d' % (title, season, episode))
			for url in packed:
				if url not in pending:
					pending[url] = ex.submit(_hubdrive_file, url)
			for url, future in pending.items():
				hit = future.result()
				if hit:
					hit['pack_priority'] = 0 if url in packed else 1
					kept = files.setdefault(hit['url'], hit)
					kept['pack_priority'] = min(kept.get('pack_priority', 1), hit['pack_priority'])
		if sections or packed:
			how = '%d HubDrive page(s) (%d section links, %d pack links)' % (len(pending), len(sections), len(packed))
		else:
			queries = {}
			for url in _recover_links(page):
				q = _query_text(url)
				n = _QUERY_EPISODE.search(q or '')
				# LOCAL PATCH 2026-11-22: the link's OWN query only (module docstring); _rows keeps the 4K / 1080p names
				if n and (int(n.group(1)), int(n.group(2))) in wanted and recover_query_ok(q, _HIGH_QUALITY): queries.setdefault(q, url)
			# the queries are independent: asked together, so the slowest sets the wait
			if queries:
				with ThreadPoolExecutor(max_workers=min(8, len(queries))) as ex:
					for found in ex.map(_recover_hits, list(queries.values())):
						for hit in found: files.setdefault(hit.get('url'), hit)
			how = 'the search %s' % ', '.join(repr(q) for q in queries) if queries else ''
		# Newer episode posts put a Greenmotors/Gadgetsweb protector URL on the episode heading.
		# Decode its payload and follow the archive's HubDrive/HubCloud links without running page JavaScript.
		protected, protected_how = _protected_files(page, [(s, e) for s, e in wanted if s in seasons], host)
		for hit in protected: files.setdefault(hit['url'], hit)
		if protected_how: how = (how + '; ' if how else '') + protected_how
		if not how: continue
		rows = _rows(files.values(), wanted, names)
		# Dedupe later keeps the first equivalent release, so place pack entries first here as well as
		# carrying the preference through to the final results sorter.
		rows.sort(key=lambda row: row.get('pack_priority', 1))
		logger('HDHub4u', '%s S%02dE%02d: %d file(s) of %d from %s, post %r' % (title, season, episode, len(rows), len(files), how, (doc.get('post_title') or '')[:70]))
		return rows
	logger('HDHub4u', '%s S%02dE%02d: no link for it on %d season post(s)' % (title, season, episode, len(posts)))
	return []


# an episode's section in an older post: '<strong>EPiSODE 1</strong>' (2024) or 'E01 &#8211; <a ...>Drive</a>' (2020)
_EPISODE_HEAD = re.compile(r'>\s*(?:EPiSODE|EP|E)\s*0*(\d{1,3})\s*(?:<|&#8211;|–|-|:)', re.I)
def _hubdrive_links(page, episodes):
	"""The HubDrive links in the wanted episodes' sections (an older post's layout), each section running to the next episode
	marker; the season-pack links above the first episode are left out. _rows checks every file's own SxxEyy after."""
	heads = list(_EPISODE_HEAD.finditer(page or ''))
	links = []
	for i, h in enumerate(heads):
		if int(h.group(1)) not in episodes: continue
		chunk = page[h.end():heads[i + 1].start() if i + 1 < len(heads) else len(page)]
		previous_end = 0
		for match in _HUBDRIVE_FILE_ANCHOR.finditer(chunk):
			url, label = html.unescape(match.group(1)), html.unescape(re.sub(r'<[^>]+>', ' ', match.group(2)))
			# LOCAL PATCH 2026-11-21: on HDHub4u's episode rows the resolution sits immediately before the Drive anchor. If the
			# nearby context names a resolution, skip it unless it is 4K/2160p or 1080p. Unknown labels remain eligible.
			context = html.unescape(re.sub(r'<[^>]+>', ' ', chunk[previous_end:match.start()]))
			previous_end = match.end()
			if stated_quality_ok(context + ' ' + label) is False: continue
			if url not in links: links.append(url)
	return links


def _pack_files(page, wanted, diagnostics=''):
	"""HubDrive file pages for the wanted episodes, out of the post's per-quality packs ('720p EP - PACK' -> hubdrive.*/packs/<id>,
	a page listing each episode's file). [] when the post has no packs or none lists the episode."""
	return _shared_pack_files(page, wanted, _HIGH_QUALITY, diagnostics=diagnostics)


def _hubdrive_file(url):
	return _shared_hubdrive_file(url)


def _protected_files(page, wanted, referer):
	"""Decode episode-specific Greenmotors/Gadgetsweb protectors and read their HBLINKS archive links."""
	episodes = {e for _s, e in wanted}
	links = []
	for match in _PROTECTOR_EPISODE.finditer(page or ''):
		if int(match.group(2)) not in episodes: continue
		url = html.unescape(match.group(1))
		if protector_url_ok(url) and url not in links: links.append(url)
	files, archives = {}, 0
	def follow(protector):
		try: landing = _get(protector, referer=referer + '/').text
		except Exception: return [], 0
		return _protected_page_files(landing, protector, wanted, quality_pattern=_HIGH_QUALITY)
	results = []
	if links:
		with ThreadPoolExecutor(max_workers=min(8, len(links))) as pool:
			results = list(pool.map(follow, links))
	for found, target_count in results:
		archives += target_count
		for hit in found: files.setdefault(hit['url'], hit)
	return list(files.values()), ('%d decoded protector target(s)' % (archives or len(links)) if files else '')


def _site_origin(url):
	return site_origin(url, 'hdhub4u')


def _find_host():
	"""Ask the site's domain lookup endpoints after a search or post request fails."""
	for lookup in _HOST_LOOKUPS:
		try:
			encoded = _get(lookup, params={'v': '1a' + time.strftime('%Y%m%d%H')}).json().get('c')
			host = _site_origin(base64.b64decode(encoded).decode('utf-8'))
			if host: return host
		except Exception: continue
	return None


def _search_on_site(imdb, fresh):
	return with_site_host(_HOST_PROPERTY, _find_host, _HOST_FALLBACK, lambda host: _search_posts(imdb, host, fresh))


def _post_page(path, host):
	return site_post_page(_HOST_PROPERTY, _find_host, host, path, _site_origin)


def _rows(hits, wanted, names):
	tags = [_episode_tag(s, e) for s, e in wanted]
	rows = []
	for hit in hits:
		name, url = (hit.get('file_name') or '').strip(), hit.get('url') or ''
		if 'video' not in (hit.get('mimeType') or '') or '/drive/' not in url or not _HIGH_QUALITY.search(name): continue
		tag = next((m for m in (t.search(name) for t in tags) if m), None)
		if not tag: continue
		if not title_prefix_ok(name, tag.start(), names): continue   # the query's other shows
		rows.append(hubcloud_row(LABEL, name, url, hit.get('size'), pack_priority=hit.get('pack_priority', 1)))
	return rows
