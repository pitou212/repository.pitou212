# -*- coding: utf-8 -*-
import json
import re
import time
from threading import Thread
from windows.base_window import open_window, create_window
from caches.episode_groups_cache import episode_groups_cache
from caches.settings_cache import get_setting
from scrapers import external
from modules import debrid, kodi_utils, settings, metadata, watched_status, smartplay_utils
from modules.kodi_utils import logger

_DEBRID_CACHE_PROVIDERS = ('Real-Debrid', 'Premiumize.me', 'AllDebrid', 'TorBox')
_CAM_QUALITIES = ('CAM', 'SCR', 'TELE')
_CUSTOM_GROUP_LABEL = '[B]CUSTOM GROUP: S%02dE%02d[/B]'
_PIN_HASH_TAG = re.compile(r'\[[0-9A-Fa-f]{8,}\]')

def _counts_to_end(ns):
	"""LOCAL PATCH 2026-10-15: the next-episode card counts to the REAL end, not a fixed countdown -- a guessed point
	(low confidence), or content after the outro."""
	return ns.get('timing_confidence') == 'low' or bool(ns.get('content_after'))
from modules.player import DeadLightPlayer, PLAYBACK_STOPPED_PROP, PLAYBACK_LAST_REMAINING_PROP, mark_internal_stop
# LOCAL PATCH 2026-09-24: how close to the end the player's last sample must be for a playback
# that was already over to count as having reached its end. See autoplay_nextep_handler.
NEXTEP_END_TOLERANCE = 15
# LOCAL PATCH 2026-10-15: the debrid resolvers' last failure reason ('TorBox: no file for this episode'), shown by play_file
RESOLVE_REASON_PROP = 'deadlight.resolve_reason'
from modules.source_utils import get_cache_expiry, make_alias_dict, include_exclude_filters, anime_episode_candidates, episode_number_keys, seas_ep_filter, release_group, get_release_quality, provider_panel_name, WindowCounter, rank_provider, internal_row_keys, internal_counts, namesake_clash, episode_title_mismatch, publish_pack_file,\
	quality_count, quality_count_sd, quality_count_total
from modules.utils import clean_file_name, string_to_float, safe_string, remove_accents, get_datetime, manual_function_import

# LOCAL PATCH 2026-09-06: a torrent whose name ends in a video extension is a SINGLE FILE (multi-file torrents
# are directories, no extension), so pack-play must not look for another episode inside it. A pack whose name
# happens to look like a file merely degrades to the scrape path.
_SINGLE_FILE_NAME = re.compile(r'\.(?:mkv|mp4|avi|ts|m2ts|mov|wmv|flv|m4v|mpg|mpeg|webm)$', re.I)
# LOCAL PATCH 2026-09-29: releases that are not the film asked for (sources.filter_not_the_film), e.g.
# 'The.Odyssey.2026.(NOT.The.Chris.Nolan.FILM).1080p...' -- another film of the same name.
_NOT_THE_FILM = re.compile(r'(?:^|[^a-z])not[ ._-]+the[ ._-]+(?:[a-z0-9]+[ ._-]+){0,4}(?:film|movie)(?:[^a-z]|$)', re.I)
_PROLOGUE = re.compile(r'(?:^|[^a-z])prologue(?:[^a-z]|$)', re.I)
# LOCAL PATCH 2026-09-06: an explicit SxxExx token names exactly ONE episode. Providers often report a pin name
# with no file extension ('...S01E22.1080p.CR.WEB-DL.AAC.2'), so the extension test cannot stand alone.
# A real season pack ('...S01.1080p...') carries no Exx.
_EPISODE_MARKER = re.compile(r'[sS]\d{1,3}[ ._-]?[eE]\d{1,4}')
# LOCAL PATCH 2026-09-07: a season token with NO episode after it ('S01' in 'Lion.S01.2160p...') names one whole
# season. The lookbehind keeps 'DTS5.1' / 'x265' out; the lookahead is exactly the shape _EPISODE_MARKER accepts,
# so the two never both match the same token.
# LOCAL PATCH 2026-09-22: read the SPELLED-OUT season too ('...(Season.1).[BD.Remux...]' has no S01 token) --
# without it the season-pack guard never ran and an S01 pack was resolved for S02 episodes.
# A spelled-out RANGE ('Season 1-2') is deliberately not matched, so a multi-season pack falls through untouched.
_SEASON_MARKER = re.compile(r'(?<![A-Za-z0-9])[sS](\d{1,3})(?![ ._-]?[eE]\d)(?![0-9])'
	r'|(?<![a-z])season[ ._-]?(\d{1,3})(?![ ._-]*[-~][ ._-]*\d)(?![0-9])', re.I)


# LOCAL PATCH 2026-09-27: pins without a pack whose provider is one of these get a
# scrape of that provider alone before the full scrape (see _sticky_provider_play).
_SINGLE_PROVIDER_PINS = ('http_streams', 'easynews')

def _cinema_exempt(item):
	"""LOCAL PATCH 2026-11-06: rows the in-cinemas relabel leaves alone -- everything that is not a torrent: Direct
	Streams, Easynews, the debrid clouds, folders, and AIOStreams' usenet / http rows. A torrent (an external provider's
	row, or an AIOStreams row carrying an infoHash) is where the fakes come from, so those are still relabelled."""
	if item.get('external'): return False
	if item.get('scrape_provider') == 'aiostreams' and item.get('hash'): return False
	return True

# LOCAL PATCH 2026-11-08: TMDb's digital date can be wrong (The Odyssey's was weeks after retail remuxes and
# WEB-DLs from dozens of groups were out, all relabelled CAM). Pre-release fakes come from a few odd uploaders;
# many groups posting retail copies means the film is out.
_RETAIL_TAG = re.compile(r'(?i)(?:^|[^a-z])(?:web-?dl|webrip|web|blu-?ray|remux|bdrip|brrip|bdremux|uhd)(?:[^a-z]|$)')
_PRE_TAG = re.compile(r'(?i)(?:^|[^a-z])(?:cam|hdcam|ts|hdts|telesync|tc|hdtc|telecine|scr|screener|webscr|hdrip|trial)(?:[^a-z]|$)')
_RELEASE_GROUP = re.compile(r'-([A-Za-z0-9]{2,12})(?:\.(?:mkv|mp4|avi))?[.\s\]\)]*$')
_NOT_A_GROUP = re.compile(r'(?i)^(?:\d+p|\d+|x26[45]|h26[45]|hevc|avc|10bit|8bit|hdr|dv|sdr)$')
_RELEASED_GROUPS = 10

def retail_release_groups(results):
	"""The distinct release groups posting retail-tagged copies (WEB-DL / WEBRip / Blu-ray / remux) whose names carry no
	cam / TS / screener word."""
	groups = set()
	for i in results:
		name = str(i.get('name') or '').replace(' ', '.')
		if not _RETAIL_TAG.search(name) or _PRE_TAG.search(name): continue
		m = _RELEASE_GROUP.search(name.rstrip('.'))
		if m and not _NOT_A_GROUP.match(m.group(1)): groups.add(m.group(1).lower())
	return groups
# LOCAL PATCH 2026-10-24: longest wait for the one-provider pin scrape before the full scrape takes over (a down
# Direct host otherwise held SmartPlay ~13 s).
# LOCAL PATCH 2026-10-25 (4.0.5): 10, not 5 -- HDHub answering in just over 5 s missed the pin.
_PIN_SCRAPE_CAP = 10

def _probe_stream(url):
	"""LOCAL PATCH 2026-10-08: True when a link serves its first byte, False when the server refuses it outright
	(403 / 404 / 410 / 5xx), None when it cannot tell (not http, timeout, any other error). Only False counts against
	a source, so a slow or odd server never blocks playback. Kodi's 'url|Header=v' form carries the player's headers."""
	try:
		if not str(url or '').lower().startswith(('http://', 'https://')): return None
		import requests
		link, headers = kodi_utils.stream_request_parts(url)
		headers['Range'] = 'bytes=0-0'
		with requests.get(link, headers=headers, stream=True, timeout=8, allow_redirects=True) as r:
			if r.status_code in (200, 206): return True
			if r.status_code in (401, 403, 404, 410, 451) or r.status_code >= 500: return False
			return None
	except Exception:
		return None

def _season_tokens(name):
	"""Distinct season numbers a pin name claims. Deduped BY VALUE, because the two
	forms often both appear for the SAME season -- '[sam] ... Season 1 (S01)' would
	otherwise look like a two-season pack and skip the guard."""
	out = []
	for m in _SEASON_MARKER.finditer(name or ''):
		v = m.group(1) or m.group(2)
		if v is None: continue
		try: out.append(int(v))
		except ValueError: pass
	return sorted(set(out))

class Sources():
	def __init__(self):
		self.params = {}
		self.prescrape_scrapers, self.prescrape_threads, self.prescrape_sources, self.uncached_results = [], [], [], []
		self.filtered_results = []
		self.threads, self.providers, self.sources, self.internal_scraper_names, self.remove_scrapers = [], [], [], [], ['external']
		self.clear_properties, self.filters_ignored, self.active_folders, self.resolve_dialog_made, self.episode_group_used = True, False, False, False, False
		self.sources_total = self.sources_4k = self.sources_1080p = self.sources_720p = self.sources_sd = 0
		self.prescrape, self.disabled_ext_ignored = 'true', 'false'
		# LOCAL PATCH 2026-10-04: set by 'Rescrape With All Scrapers' alone. disabled_ext_ignored is also set by the episode
		# group and filters-ignored retries, so it cannot tell external.py that the user asked for every anime provider.
		self.all_scrapers_retry = False
		self.progress_dialog, self.progress_thread = None, None
		self._cinema_lookup = None
		self.playing_filename = ''
		self.scrape_count = 0
		self.count_tuple = (('sources_4k', '4K', quality_count), ('sources_1080p', '1080p', quality_count), ('sources_720p', '720p', quality_count),
							('sources_sd', '', quality_count_sd), ('sources_total', '', quality_count_total))
		self.filter_keys = include_exclude_filters()
		self.filter_keys.pop('hybrid')
		self.default_internal_scrapers = ('easynews', 'rd_cloud', 'pm_cloud', 'ad_cloud', 'tb_cloud', 'aiostreams', 'http_streams', 'folders')
		self.debrids = {'Real-Debrid': ('apis.real_debrid_api', 'RealDebridAPI'), 'rd_cloud': ('apis.real_debrid_api', 'RealDebridAPI'),
		'rd_browse': ('apis.real_debrid_api', 'RealDebridAPI'), 'Premiumize.me': ('apis.premiumize_api', 'PremiumizeAPI'), 'pm_cloud': ('apis.premiumize_api', 'PremiumizeAPI'),
		'pm_browse': ('apis.premiumize_api', 'PremiumizeAPI'), 'AllDebrid': ('apis.alldebrid_api', 'AllDebridAPI'), 'ad_cloud': ('apis.alldebrid_api', 'AllDebridAPI'),
		'ad_browse': ('apis.alldebrid_api', 'AllDebridAPI'), 'TorBox': ('apis.torbox_api', 'TorBoxAPI'), 'tb_cloud': ('apis.torbox_api', 'TorBoxAPI'),
		'tb_browse': ('apis.torbox_api', 'TorBoxAPI')}
		self.retry_actions = settings.rescrape_settings()

	def playback_prep(self, params=None):
		kodi_utils.hide_busy_dialog()
		if params: self.params = params
		params_get = self.params.get
		if not kodi_utils.external_playback_check(self.params): return
		# LOCAL PATCH 2026-11-14: TorBox connections opened while the metadata loads and the progress window builds
		# (modules/scrape_warm). Once per process; the retries call playback_prep again.
		if not getattr(Sources, '_warm_started', False):
			Sources._warm_started = True
			try:
				from modules import scrape_warm
				scrape_warm.start()
			except Exception: pass
		self.play_type = params_get('play_type', '')
		# LOCAL PATCH 2026-08-31 (doc only): `background` carries THREE unrelated meanings no caller can separate (set
		# only by episode_tools' next-episode and random-continual paths):
		#   1. show no UI -- no progress window, synchronous scraper joins, dialogs become toasts
		#   2. chain to another episode -- continue_resolve_check relies on it. LOAD-BEARING: without it nothing chains
		#   3. play, do not ask -- the tail of play_source
		# So "silent play but do not chain" and "chain but do ask" are inexpressible; meaning 3 has silently played a
		# wrong source when code wanted meaning 2.
		self.background = params_get('background', 'false') == 'true'
		self.prescrape = params_get('prescrape', self.prescrape) == 'true'
		self.random, self.random_continual = params_get('random', 'false') == 'true', params_get('random_continual', 'false') == 'true'
		if 'external_cache_check' in self.params: self.external_cache_check = params_get('external_cache_check') == 'true'
		else: self.external_cache_check = settings.external_cache_check()
		if self.play_type:
			if self.play_type == 'autoplay_nextep': self.autoplay_nextep, self.autoscrape_nextep = True, False
			elif self.play_type == 'random_continual': self.autoplay_nextep, self.autoscrape_nextep = False, False
			else: self.autoplay_nextep, self.autoscrape_nextep = False, True
		else: self.autoplay_nextep, self.autoscrape_nextep = settings.autoplay_next_episode(), settings.autoscrape_next_episode()
		self.autoscrape = self.autoscrape_nextep and self.background		
		self.ignore_scrape_filters = params_get('ignore_scrape_filters', 'false') == 'true'
		self.nextep_settings, self.disable_autoplay_next_episode = params_get('nextep_settings', {}), params_get('disable_autoplay_next_episode', 'false') == 'true'
		# LOCAL PATCH 2026-09-04: hashes whose cached resolve failed during THIS attempt.
		self._sticky_dead_hashes = set()
		# the episode-group retry sets True (a bool) before calling playback_prep again
		self.disabled_ext_ignored = params_get('disabled_ext_ignored', self.disabled_ext_ignored) in (True, 'true')
		# LOCAL PATCH 2026-10-05: Options > 'Scrape with ALL External Scrapers' asks for every anime provider too, like the retry
		if params_get('all_scrapers', 'false') == 'true': self.all_scrapers_retry = True
		self.folders_ignore_filters = get_setting('deadlight.results.folders_ignore_filters', 'false') == 'true'
		self.filter_size_method = int(get_setting('deadlight.results.filter_size_method', '0'))
		self.media_type, self.tmdb_id = params_get('media_type'), params_get('tmdb_id')		
		self.custom_title, self.custom_year = params_get('custom_title', None), params_get('custom_year', None)
		self.episode_group_label, self.episode_id = params_get('episode_group_label', ''), params_get('episode_id', None)
		self.playcount, self.watch_count = params_get('playcount', None), params_get('watch_count', 1)
		if self.media_type == 'episode':
			self.season, self.episode = int(params_get('season')), int(params_get('episode'))
			self.custom_season, self.custom_episode = params_get('custom_season', None), params_get('custom_episode', None)
			self.check_episode_group()
		else: self.season, self.episode, self.custom_season, self.custom_episode = '', '', '', ''
		if 'autoplay' in self.params: self.autoplay = params_get('autoplay', 'false') == 'true'
		else: self.autoplay = settings.auto_play(self.media_type)
		self.get_meta()
		# LOCAL PATCH 2026-09-26: IntroDB lookup starts here, alongside the scrape, instead of
		# blocking play() at the end -- see apis/introdb_api.prefetch_segments.
		try:
			from apis.introdb_api import prefetch_segments
			prefetch_segments(self.meta)
		except Exception: pass
		self.determine_scrapers_status()
		# sleep_time: poll interval of the internal-scrapers dialog (scrapers_dialog).
		self.sleep_time, self.provider_sort_ranks, self.scraper_settings = 50, settings.provider_sort_ranks(), settings.scraping_settings()
		self.include_prerelease_results = settings.include_prerelease_results()
		self.limit_resolve = settings.limit_resolve()
		self.weight_size = settings.size_sort_weighted()
		self.sort_function, self.quality_filter = settings.results_sort_order(), self._quality_filter()
		self.include_unknown_size = get_setting('deadlight.results.size_unknown', 'false') == 'true'
		self.make_search_info()
		if self.autoscrape: self.autoscrape_nextep_handler()
		else:
			# LOCAL PATCH 2026-08-31 (doc only): with a pack pinned this returns and SKIPS THE SCRAPE, so _sticky_match only
			# ever sees non-pack pins -- a pack play logs "pack-play[debrid]" and no match line at all.
			if self._sticky_pack_play(): return
			return self.get_sources()

	def check_episode_group(self):
		try:
			if any([self.custom_season, self.custom_episode]) or 'skip_episode_group_check' in self.params: return
			group_info = episode_groups_cache.get(self.tmdb_id)
			if not group_info: return
			group_details = metadata.group_episode_data(metadata.group_details(group_info['id']), self.episode_id, self.season, self.episode)
			if group_details:
				self.custom_season, self.custom_episode, self.episode_group_used = group_details['season'], group_details['episode'], True
				self.episode_group_label = _CUSTOM_GROUP_LABEL % (self.custom_season, self.custom_episode)
		except: self.custom_season, self.custom_episode = None, None

	def determine_scrapers_status(self):
		# LOCAL PATCH 2026-11-23 (user): the anime verdict, ONCE per scrape: modules/provider_gate gates DeadLight's own
		# scrapers on it (search_info['is_anime'] hands it to http_streams), as external_sources gates the torrent sites
		self.is_anime = bool(metadata.is_anime_meta(self.meta))
		self.active_internal_scrapers = settings.active_internal_scrapers(self.is_anime, self.all_scrapers_retry)
		if not 'external' in self.active_internal_scrapers and self.disabled_ext_ignored: self.active_internal_scrapers.append('external')
		self.active_external = 'external' in self.active_internal_scrapers
		if self.active_external:
			self.debrid_enabled = debrid.debrid_enabled()
			if not self.debrid_enabled:
				return self.disable_external('No Debrid Services Enabled' if all(scraper == 'external' for scraper in self.active_internal_scrapers) else 'EN used only')

	def get_sources(self):
		self.scrape_count += 1
		# LOCAL PATCH 2026-10-02: scrape.diag_timing also times the internal scrapers and the whole scrape (scrapers/external.py
		# times each external provider). Off by default; a hidden setting.
		self._diag_timing = settings.diag_timing()
		self._scrape_t0 = time.perf_counter()
		# LOCAL PATCH 2026-11-25: no chips prewarm here any more (2026-11-01 loaded Pillow, the fonts and the character widths on a
		# thread at scrape start). The providers are CPU-bound on the box, not waiting on the network: without it they finished
		# ~0.45 s sooner and the results opened ~0.35 s sooner (session 72; the window build pays ~0.1 s for the fonts instead).
		if not self.progress_dialog and not self.background: self._make_progress_dialog()
		self._mark('progress window')
		self._start_cinema_notice()
		self._mark('cinema notice scheduled')
		results = []
		if self.prescrape and any(x in self.active_internal_scrapers for x in self.default_internal_scrapers):
			if self.prepare_internal_scrapers():
				results = self.collect_prescrape_results()
				if results: results = self.process_results(results)
		if not results:
			self._mark('prescrape')
			self.prescrape = False
			self.prepare_internal_scrapers()
			self._mark('internal scrapers prepared')
			if self.active_external: self.activate_external_providers()
			elif not self.active_internal_scrapers: self._kill_progress_dialog()
			self._mark('external providers loaded')
			self.orig_results = self.collect_results()
			self._mark('all scrapers returned (%d sources)' % len(self.orig_results or []))
			if not self.orig_results and not self.active_external: self._kill_progress_dialog()
			results = self.process_results(self.orig_results)
		# LOCAL PATCH 2026-11-25 (user): the scrape's own time, shown in the results header as POV does ('4.62 SECONDS')
		self.meta['scrape_time'] = time.perf_counter() - self._scrape_t0
		if self._diag_timing:
			kodi_utils.logger('scrape.timing', 'TOTAL: %dms to %d results (%d before filters)%s' % (int((time.perf_counter() - self._scrape_t0) * 1000),
				len(results) if isinstance(results, list) else 0, len(getattr(self, 'orig_results', None) or []), ' prescrape' if self.prescrape else ''))
		if not results: return self._process_post_results()
		if self.autoscrape: return results
		else: return self.play_source(results)

	def collect_results(self):
		# Fresh per run too: the retries reset self.threads but not this, so the last run's rows (AIOStreams', which dedup
		# lets through) came back doubled in 'Access Filtered Results' / the cache-check and IMDb-year retries.
		self.sources = list(self.prescrape_sources)
		# LOCAL PATCH 2026-10-15: built fresh per run. The retry paths reset self.threads, and an only-extended list ran
		# every internal scraper again per retry (doubled / tripled AIOStreams rows).
		self.providers = []
		threads_append = self.threads.append
		if self.active_folders: self.append_folder_scrapers(self.providers)
		self.providers.extend(self.internal_sources())
		self._mark('internal scrapers imported')
		if self.providers:
			for i in self.providers: threads_append(Thread(target=self.activate_providers, args=(i[0], i[1], False), name=i[2]))
			[i.start() for i in self.threads]
		join_deadline = self._scrape_deadline()
		self._mark('internal scrapers started')
		if self.active_external or self.background:
			if self.active_external:
				self.external_args = (self.meta, self.external_providers, self.debrid_enabled, self.external_cache_check, self.internal_scraper_names,
										self.prescrape_sources, self.progress_dialog, self.disabled_ext_ignored, self._window_countable, self.all_scrapers_retry)
				self.activate_providers('external', external, False)
			if self.background: self._join_by(self.threads, join_deadline)
		elif self.active_internal_scrapers: self.scrapers_dialog()
		return self.sources

	# LOCAL PATCH 2026-10-15: a background (next-episode) scrape waits for the internal scrapers only as long as the
	# foreground would -- results.timeout from their start, plus the 1.5 s external._background allows. Their requests
	# run 10-12 s, which made the handoff late. A late thread still finishes, its rows unused.
	def _scrape_deadline(self):
		try: return time.time() + int(get_setting('deadlight.results.timeout', '20')) + 1.5
		except (TypeError, ValueError): return time.time() + 21.5

	@staticmethod
	def _join_by(threads, deadline):
		for t in threads: t.join(max(0.0, deadline - time.time()))
		late = [t.name for t in threads if t.is_alive()]
		if late: kodi_utils.logger('scrape.background', 'not waiting for %s (past results.timeout)' % ', '.join(late))

	def collect_prescrape_results(self):
		threads_append = self.prescrape_threads.append
		if self.active_folders:
			if settings.check_prescrape_sources('folders', self.media_type):
				self.append_folder_scrapers(self.prescrape_scrapers)
				self.remove_scrapers.append('folders')
		self.prescrape_scrapers.extend(self.internal_sources(True))
		if not self.prescrape_scrapers: return []
		for i in self.prescrape_scrapers: threads_append(Thread(target=self.activate_providers, args=(i[0], i[1], True), name=i[2]))
		[i.start() for i in self.prescrape_threads]
		join_deadline = self._scrape_deadline()
		self.remove_scrapers.extend(i[2] for i in self.prescrape_scrapers)
		if self.background: self._join_by(self.prescrape_threads, join_deadline)
		else: self.scrapers_dialog()
		return self.prescrape_sources

	def process_results(self, results):
		# LOCAL PATCH 2026-11-08: one line per scrape saying what each stage removed ('scrape filters'). The filters below dropped
		# rows without a word, so 'where did the sources go?' had no answer in the log.
		found, drops = len(results or []), []
		# LOCAL PATCH 2026-11-22: the rows the scrape filters and quality limits removed, kept for 'Show Filtered Sources' in the
		# results window (by id(): every filter on this path keeps the row dicts)
		self.filtered_results = []
		def _counted(label, before, after):
			gone = len(before or []) - len(after or [])
			if gone > 0: drops.append('%s -%d' % (label, gone))
			return after
		results = self.relabel_in_cinemas(results)
		self._mark('post: relabel')
		results = _counted('duplicates', results, self.deduplicate_results(results))
		self._mark('post: dedupe (%d left)' % len(results or []))
		results = self.sort_results(results)
		self._mark('post: sort')
		min_seeders = settings.uncached_min_seeders()
		all_uncached_results = [i for i in results if 'Uncached' in i.get('cache_provider', '')]
		# LOCAL PATCH 2026-08-10 (Red Light 2.2.0 port): missing/None/non-numeric seeders count as 0. Providers return an
		# explicit `seeders: None`, and int(None) killed the whole scrape.
		def _seeders(item):
			try: return int(item.get('seeders') or 0)
			except (TypeError, ValueError): return 0
		self.uncached_results = [i for i in all_uncached_results if _seeders(i) >= min_seeders]
		# LOCAL PATCH 2026-10-25 (4.0.5): was `not i in all_uncached_results` -- a dict-equality scan of that list per row
		# (quadratic). all_uncached_results is the same predicate over the same rows, so the complement is the predicate's.
		results = _counted('uncached (own list)', results, [i for i in results if not 'Uncached' in i.get('cache_provider', '')])
		if self.ignore_scrape_filters: self.filters_ignored = True
		else:
			before_filters = results
			self._size_dropped = 0
			results = _counted('quality', results, self.filter_results(results))
			if self._size_dropped and drops and drops[-1].startswith('quality '):   # filter_results also applies the size limits
				q = int(drops[-1].split('-')[-1]) - self._size_dropped
				drops[-1:] = (['quality -%d' % q] if q > 0 else []) + ['size -%d' % self._size_dropped]
			self._mark('post: filters (%d left)' % len(results or []))
			results = _counted('audio', results, self.filter_audio(results))
			results = _counted('banned words', results, self.filter_banned_keywords(results))
			self._mark('post: audio + banned keywords')
			results = _counted('not the film', results, self.filter_not_the_film(results))
			for file_type in self.filter_keys: results = _counted(self.filter_keys[file_type], results, self.special_filter(results, file_type))
			if len(results) < len(before_filters):
				visible_ids = {id(item) for item in results}
				self.filtered_results = [item for item in before_filters if id(item) not in visible_ids]
			self._mark('post: not-the-film + special filters')
		results = _counted('debrid twins', results, self.collapse_debrid_twins(results))
		self._mark('post: debrid twins (%d left)' % len(results or []))
		results = self.sort_preferred_filters(results)
		self._mark('post: preferred sort')
		results = self.demote_namesake(results)
		if self.prescrape:
			self.all_scrapers = self.active_internal_scrapers
			autoplay_results = [i for i in results if i['scrape_provider'] in self.active_internal_scrapers and settings.autoplay_prescrape(i['scrape_provider'])]
			if autoplay_results:
				self.autoplay = True
				results = _counted('not a prescrape provider', results, autoplay_results)
		else:
			self.all_scrapers = list(set(self.active_internal_scrapers + self.remove_scrapers))
			kodi_utils.clear_property('fs_filterless_search')
		results = self.sort_first(results)
		self._mark('post: sort first')
		if not self.ignore_scrape_filters:
			before_limits = results
			results = _counted('quality limits', results, self.limit_quality_total(self.limit_quality_numbers(results)))
			if len(results) < len(before_limits):
				visible_ids = {id(item) for item in results}
				self.filtered_results.extend(item for item in before_limits if id(item) not in visible_ids)
			# LOCAL PATCH 2026-11-23: the filtered rows read like the results -- one row per torrent (debrid twins, as the results;
			# not collapse_debrid_twins, which also trims the uncached list) in the Results Sorting order, so the filters' and the
			# limits' rows of one quality are one block
			if self.filtered_results:
				try:
					self.filtered_results = self._merge_debrid_twins(self.filtered_results)[0]
					self.filtered_results.sort(key=self._result_sort_key(settings.prefer_release_groups(self.autoplay)))
				except Exception as e: kodi_utils.logger('filtered sources', 'left unsorted: %r' % e)
			self._mark('post: quality limits')
		kodi_utils.logger('scrape filters', '%d found -> %d shown%s%s' % (found, len(results or []),
			' (%s)' % ', '.join(drops) if drops else '', ' -- filters ignored' if self.ignore_scrape_filters else ''))
		return results

	def deduplicate_results(self, results):
		# LOCAL PATCH 2026-06-20: dedup keys include cache_provider so the SAME hash cached on several debrids
		# (scrapers/external.py emits one entry per (hash, debrid)) yields one row per debrid, not just the first.
		seen_urls = set()
		seen_hashes = set()
		seen_size_quality = set()
		deduplicated = []
		for item in results:
			if item.get('scrape_provider') == 'aiostreams':
				deduplicated.append(item)
				continue
			url = (item.get('url_dl', '') or item.get('url', '') or '').strip()
			info_hash = (item.get('infoHash', '') or item.get('hash', '') or '').strip().lower()
			cache_provider = item.get('cache_provider', '')
			if url and (url, cache_provider) in seen_urls: continue
			if info_hash and (info_hash, cache_provider) in seen_hashes: continue
			# LOCAL PATCH 2026-10-15: the size twin must also be the same RELEASE (its name), and a row with no size is never
			# one. Sizes are rounded (0.01-0.1 GB), so different releases collapsed -- and this runs BEFORE the filters, so a
			# filtered survivor took its twin with it.
			quality = item.get('quality', 'SD')
			size = item.get('size', 0)
			size_quality_key = (quality, size, cache_provider, re.sub(r'[^a-z0-9]', '', str(item.get('name') or '').lower())) if size else None
			if size_quality_key and size_quality_key in seen_size_quality: continue
			if url: seen_urls.add((url, cache_provider))
			if info_hash: seen_hashes.add((info_hash, cache_provider))
			if size_quality_key: seen_size_quality.add(size_quality_key)
			deduplicated.append(item)
		return deduplicated

	@staticmethod
	def _twin_hash(item):
		return (item.get('hash') or '').lower() if item.get('scrape_provider') == 'external' else ''

	def _merge_debrid_twins(self, results):
		"""LOCAL PATCH 2026-11-23: collapse_debrid_twins' cached half on its own -> (rows, {hash: kept row}): one row per torrent,
		the others' debrids on it as 'debrid_fallbacks'. Also used for Show Filtered Sources, which must not touch the uncached list."""
		_hash, best = self._twin_hash, {}
		for i in results:
			h = _hash(i)
			if not h: continue
			if h not in best or i.get('provider_rank', 99) < best[h].get('provider_rank', 99): best[h] = i
		out = []
		for i in results:
			h = _hash(i)
			if not h: out.append(i); continue
			keep = best[h]
			if i is keep: out.append(i); continue
			if i.get('cache_provider') and i['cache_provider'] != keep.get('cache_provider'):
				fallbacks = keep.setdefault('debrid_fallbacks', [])
				if i['cache_provider'] not in fallbacks: fallbacks.append(i['cache_provider'])
		for keep in best.values():
			if keep.get('debrid_fallbacks'):
				keep['debrid_fallbacks'].sort(key=lambda c: self._get_provider_rank(c.lower()))
		return out, best

	def collapse_debrid_twins(self, results):
		"""LOCAL PATCH 2026-10-11: one row per torrent when several debrids carry it. deduplicate_results keeps a row per
		(hash, debrid) on purpose -- the RD keyword ban must not take the TorBox copy with it. Runs after the filters, so a
		twin a filter removed is never the one kept.
		Cached: the twin on the debrid highest in Provider Priority stays; the others go on it as 'debrid_fallbacks', tried
		in order by resolve_sources when it fails (RD's 'infringing_file' block, a dead cache entry). Uncached: dropped for
		a torrent that is cached anywhere, otherwise one row per torrent (the priority debrid's)."""
		try:
			out, best = self._merge_debrid_twins(results)
			_hash = self._twin_hash
			uncached, seen = [], set(best)
			for u in sorted(self.uncached_results or [], key=lambda u: self._get_provider_rank((u.get('debrid') or '').lower())):
				h = _hash(u)
				if h and h in seen: continue
				if h: seen.add(h)
				uncached.append(u)
			kodi_utils.logger_debug('debrid twins', '%d rows -> %d (%d with a fallback debrid); uncached %d -> %d' % (len(results), len(out),
				sum(1 for k in best.values() if k.get('debrid_fallbacks')), len(self.uncached_results or []), len(uncached)))
			if len(uncached) != len(self.uncached_results or []):
				# keep the uncached list's own order (seeders etc.), minus the twins
				kept_ids = set(id(u) for u in uncached)
				self.uncached_results = [u for u in self.uncached_results if id(u) in kept_ids]
			return out
		except Exception as e:
			kodi_utils.logger('debrid twins', 'collapse failed, rows left as they were: %r' % e)
			return results

	def sort_results(self, results):
		# LOCAL PATCH 2026-11-23 (user): a Stremio slot row ranks by Stremio Add-ons' Provider Priority (source_utils.rank_provider)
		results = [dict(i, **{
			'provider_rank': self._get_provider_rank(rank_provider(i)), 'quality_rank': self._get_quality_rank(i.get('quality', 'SD')),
			'size_rank': self._get_size_rank(i)}) for i in results]
		# LOCAL PATCH 2026-10-25: Prefer Known Release Groups (modules/release_groups.py) -- the group weight goes in right
		# after the quality key, wherever the chosen Results Sorting puts quality, so a known group never jumps quality
		boost = settings.prefer_release_groups(self.autoplay)
		if boost:
			from modules.release_groups import release_group_boost
			# LOCAL PATCH 2026-10-25 (4.0.5): source_utils.release_group is lru_cached, so the repeat parses are free here and
			# in the picker -- one lookup order, kept in release_groups.release_group_boost.
			for i in results: i['group_boost'] = release_group_boost(i)
		results.sort(key=self._result_sort_key(boost))
		if boost:
			_known = [k for k in results if k['group_boost']]
			kodi_utils.logger_debug('release groups', '%d of %d result(s) from a known group lead their quality: %s' % (len(_known), len(results),
				', '.join(sorted(set('%s %s' % (k.get('quality'), k.get('release_group') or release_group(k.get('name') or '')) for k in _known[:40])))[:300]))
		results = self._sort_uncached_results(results)
		return results

	def _result_sort_key(self, boost):
		"""sort_results' key, for rows it has ranked (provider_rank / quality_rank / size_rank, and group_boost when boost).
		LOCAL PATCH 2026-11-23: on its own so Show Filtered Sources orders its rows the same way."""
		# LOCAL PATCH 2026-11-22: HDHub4u's pack_priority (a season-pack copy 0, an episode-section copy 1) breaks only a tie of
		# every Results Sorting key, size included, as its scraper intends; also in the group-boost key
		_base = lambda k: self.sort_function(k) + (k.get('pack_priority', 1),)
		if not boost: return _base
		# where quality sits in each Results Sorting (settings.results_sort_order): Q-P-S, Q-S-P, P-Q-S, P-S-Q, S-Q-P, S-P-Q
		try: _at = (1, 1, 2, 3, 2, 3)[int(get_setting('deadlight.results.sort_order', '1'))]
		except (TypeError, ValueError, IndexError): _at = 1
		return lambda k: (lambda t: t[:_at] + (-k.get('group_boost', 0),) + t[_at:])(_base(k))

	def filter_results(self, results):
		if self.folders_ignore_filters:
			# LOCAL PATCH 2026-10-25 (4.0.5): one-pass split (was `not i in folder_results`, quadratic)
			folder_results, _rest = [], []
			for i in results: (folder_results if i['scrape_provider'] == 'folders' else _rest).append(i)
			results = _rest
		else: folder_results = []
		_all = results
		results = [i for i in results if i['quality'] in self.quality_filter]
		if not results and 'SD' not in self.quality_filter: results = self._unknown_resolution_fallback(_all)   # LOCAL PATCH 2026-10-19
		if self.filter_size_method:
			min_size = string_to_float(get_setting('deadlight.results.%s_size_min' % self.media_type, '0'), '0') / 1000
			if min_size == 0.0 and not self.include_unknown_size: min_size = 0.02
			if self.filter_size_method == 1:
				duration = self.meta['duration'] or (5400 if self.media_type == 'movie' else 2400)
				max_size = ((0.125 * (0.90 * string_to_float(get_setting('results.line_speed', '25'), '25'))) * duration)/1000
			elif self.filter_size_method == 2:
				max_size = string_to_float(get_setting('deadlight.results.%s_size_max' % self.media_type, '10000'), '10000') / 1000
			_before = len(results)
			results = [i for i in results if i['scrape_provider'] == 'folders' or min_size <= i['size'] <= max_size]
			self._size_dropped = _before - len(results)   # LOCAL PATCH 2026-11-08: for process_results' 'scrape filters' line
		results += folder_results
		return results

	def filter_audio(self, results):
		a_filters = settings.audio_filters()
		return [i for i in results if not any(x in i['extraInfo'] for x in a_filters)]

	# LOCAL PATCH 2026-06-20: Real-Debrid filename-keyword filter. Drops a row only when ALL hold:
	#   1) scrape_provider == 'external' (the magnet path; aiostreams/easynews/Stremio add-ons/http_streams/cloud/folders
	#      never go through addMagnet)
	#   2) cache_provider contains 'Real-Debrid' (cached and 'Uncached Real-Debrid' rows; only RD runs the ban)
	#   3) the raw 'name' (not display_name / extraInfo) contains a banned token (case-insensitive substring)
	# The setting ships with RD's known blocked tokens (WEB-DL, AMZN, RARBG...); empty = disabled. Other debrids have
	# no filename ban, so the same hash's TorBox row stays when its RD row drops.
	def filter_banned_keywords(self, results):
		raw = settings.banned_keywords_filter()
		if not raw: return results
		tokens = [t.strip().lower() for t in raw.split(',') if t.strip()]
		if not tokens: return results
		return [r for r in results
				if r.get('scrape_provider') != 'external'
				or 'Real-Debrid' not in (r.get('cache_provider') or '')
				or not any(tok in (r.get('name') or '').lower() for tok in tokens)]

	def _digital_release(self, allow_remote=True):
		"""LOCAL PATCH 2026-09-29: this movie's first digital / disc release date ('YYYY-MM-DD'), or ''. A meta cached
		before the field existed asks TMDb once per session -- only for a film out in the last 180 days (or not yet out).
		A failed ask counts as 'no date' for the session too, so a TMDb outage costs one 3 s wait, not one per scrape."""
		if 'digital_release' in self.meta: return self.meta['digital_release'] or ''
		try:
			import datetime
			premiered = datetime.date(*[int(x) for x in self.meta['premiered'][:10].split('-')])
			if (datetime.date.today() - premiered).days > 180: return ''
		except Exception: return ''
		prop = 'deadlight.digital_release.%s' % self.meta.get('tmdb_id')
		cached = kodi_utils.get_property(prop)
		# LOCAL PATCH 2026-10-03 (Batch 3): a failed ask is 'fail:<epoch>' and is retried after an hour; 'none' (TMDb
		# answered, no date) stays for the session. Not 'none' for a timeout: that stuck until Kodi restarted.
		if cached.startswith('fail:'):
			try:
				if time.time() - int(cached[5:]) < 3600: return ''
			except ValueError: pass
		elif cached: return '' if cached == 'none' else cached
		if not allow_remote: return None
		from apis.tmdb_api import movie_release_dates
		results = movie_release_dates(self.meta.get('tmdb_id'), settings.tmdb_api_key())
		if results is None:
			kodi_utils.set_property(prop, 'fail:%d' % int(time.time()))
			return ''
		date = metadata.digital_release_date(results) if results else ''
		kodi_utils.set_property(prop, date or 'none')
		return date

	def _cinema_date(self):
		"""LOCAL PATCH 2026-09-30: the movie's first digital / disc release date while it is still in the future, else ''.
		Worked out once per scrape: the loading window's notice, its counts and relabel_in_cinemas all read it."""
		value = getattr(self, '_cinema_date_value', None)
		if value is not None: return value
		if self._cinema_lookup:
			self._cinema_lookup.join()
			return self._cinema_date_value
		self._cinema_date_value = self._read_cinema_date()
		return self._cinema_date_value

	def _read_cinema_date(self, allow_remote=True):
		if self.media_type != 'movie': return ''
		try:
			import datetime
			date = self._digital_release(allow_remote)
			if date is None: return None
			return date if date > datetime.date.today().isoformat() else ''
		except Exception as e:
			kodi_utils.logger('in cinemas', 'skipped: %s' % e)
			return ''

	def _start_cinema_notice(self):
		dialog = self.progress_dialog
		if not dialog or self.media_type != 'movie': return
		date = getattr(self, '_cinema_date_value', None)
		if date is None and self._cinema_lookup: return
		if date is None: date = self._read_cinema_date(allow_remote=False)
		if date is not None:
			self._cinema_date_value = date
			self._show_cinema_notice(dialog, date)
			return

		# Older movie metadata needs a TMDb request. Let the providers run while it is in flight.
		def lookup():
			self._cinema_date_value = self._read_cinema_date()
			self._show_cinema_notice(dialog, self._cinema_date_value)

		worker = Thread(target=lookup, name='cinema_release_date')
		try:
			worker.start()
			self._cinema_lookup = worker
		except RuntimeError:
			lookup()

	def _show_cinema_notice(self, dialog, date):
		if not date or self.progress_dialog is not dialog: return
		try:
			import datetime
			day = datetime.date(*[int(x) for x in date.split('-')])
			when = '%d %s' % (day.day, day.strftime('%b'))
			if day.year != datetime.date.today().year: when = '%s %d' % (when, day.year)
			what = 'shown as cam rips' if 'CAM' in self.quality_filter else 'cam rips hidden'
			dialog.set_notice('In cinemas  ·  digital release %s  ·  %s' % (when, what))
		except Exception: pass

	def relabel_in_cinemas(self, results):
		"""LOCAL PATCH 2026-09-29: before a movie's first digital / disc release no web or disc copy of it can exist, so
		every result is a cam, a fake or another film (e.g. 'D.WEBRip.1O8Op' listed as 1080p). Each one becomes CAM, so the
		pre-release setting decides: Exclude hides them, Include lists them honestly marked.
		LOCAL PATCH 2026-11-06: only torrents are relabelled -- direct, usenet, cloud and folder rows are files already up,
		not names (_cinema_exempt)."""
		if self.media_type != 'movie' or not results: return results
		date = self._cinema_date()
		if not date: return results
		# LOCAL PATCH 2026-11-08: out already, whatever TMDb's date says (see retail_release_groups); nothing is relabelled and
		# the rest of this scrape (counts, filters) treats the film as released
		groups = retail_release_groups(results)
		if len(groups) >= _RELEASED_GROUPS:
			kodi_utils.logger('in cinemas', 'TMDb digital release %s, but %d release groups have retail copies (%s) -- treated as out'
				% (date, len(groups), ', '.join(sorted(groups)[:6])))
			self._cinema_date_value = ''
			return results
		n = 0
		for i in results:
			if _cinema_exempt(i): continue
			if i.get('quality') not in _CAM_QUALITIES: i['quality'] = 'CAM'; n += 1
		if n: kodi_utils.logger('in cinemas', 'digital release %s: %d result(s) relabelled CAM' % (date, n))
		return results

	def _other_film(self, name):
		"""LOCAL PATCH 2026-09-29: True for a release that says it is another film ('NOT.The.Chris.Nolan.FILM'), or on a
		MOVIE one named as a prologue -- episodes are left alone, where 'Prologue' is a common episode title. A title
		that itself holds the word keeps its matches."""
		flags = getattr(self, '_other_film_flags', None)
		if flags is None:
			title = self.get_search_title() or ''
			flags = self._other_film_flags = (not _NOT_THE_FILM.search(title), self.media_type == 'movie' and not _PROLOGUE.search(title))
		name = name or ''
		return bool((flags[0] and _NOT_THE_FILM.search(name)) or (flags[1] and _PROLOGUE.search(name)))

	def demote_namesake(self, results):
		"""LOCAL PATCH 2026-10-25: a show whose title another show shares (source_utils.namesake_clash, read from the results:
		no request) -- a release carrying an episode title that is not ours goes to the end of the list, marked 'other
		show?' (its name is left as it is: SmartPlay and the filters read that). E.g. Avatar: The Last Airbender 2024 / 2005."""
		try:
			if self.media_type != 'episode' or not results: return results
			meta = self.meta if isinstance(getattr(self, 'meta', None), dict) else {}
			ep_title = meta.get('ep_name') or ''
			if not ep_title or not namesake_clash([r.get('name') for r in results], meta.get('title') or ''): return results
			kept, suspects = [], []
			for r in results:
				if episode_title_mismatch(r.get('name'), self.season, self.episode, ep_title, meta.get('year')): suspects.append(r)
				else: kept.append(r)
			if not suspects: return results
			for r in suspects:
				r['namesake_suspect'] = True
				r['display_name'] = '[COLOR FFE0AA46]other show?[/COLOR]  %s' % (r.get('display_name') or r.get('name') or '')
			kodi_utils.logger('namesake', '%s S%sE%s: %d release(s) carry another episode title, moved to the end' % (meta.get('title'), self.season, self.episode, len(suspects)))
			return kept + suspects
		except Exception: return results

	def filter_not_the_film(self, results):
		"""LOCAL PATCH 2026-09-29: drop what _other_film names. Every provider passes here, internal ones included."""
		kept = [r for r in results if not self._other_film(r.get('name'))]
		if len(kept) != len(results): kodi_utils.logger('not the film', 'dropped %d release(s)' % (len(results) - len(kept)))
		return kept

	def _window_countable(self, item):
		"""LOCAL PATCH 2026-09-30: why the results list will hide this release, or '' when it will show it -- the loading
		window counts only the ''s (source_utils.WindowCounter). The same tests the list applies: the quality filter,
		which holds CAM / SCR / TELE only when pre-releases are included, after the in-cinemas relabel; and _other_film.
		Size, audio and codec filters are not repeated here, so the count can still run a little high."""
		if self.ignore_scrape_filters: return ''
		quality = item.get('quality') or 'SD'
		if self._cinema_date() and quality not in _CAM_QUALITIES and not _cinema_exempt(item): quality = 'CAM'
		if quality not in self.quality_filter: return 'cam' if quality in _CAM_QUALITIES else 'quality'
		if self._other_film(item.get('name')): return 'other film'
		return ''

	def special_filter(self, results, file_type):
		enable_setting, key = settings.filter_status(file_type), self.filter_keys[file_type]
		if key == 'HEVC' and enable_setting == 0:
			hevc_max_quality = self._get_quality_rank(get_setting('deadlight.filter.hevc.%s' % ('max_autoplay_quality' if self.autoplay else 'max_quality'), '4K'))
			results = [i for i in results if not key in i['extraInfo'] or i['quality_rank'] >= hevc_max_quality]
		if enable_setting == 1:
			if key in ('D/VISION', 'HDR'):
				# A HYBRID (DV + HDR) release goes only when its other format is excluded too; Sort to Top on it wants it kept.
				if settings.filter_status({'D/VISION': 'hdr', 'HDR': 'dv'}[key]) == 1: results = [i for i in results if not key in i['extraInfo']]
				else: results = [i for i in results if not (key in i['extraInfo'] and not 'HYBRID' in i['extraInfo'])]
			else: results = [i for i in results if not key in i['extraInfo']]
		# LOCAL PATCH 2026-06-15: per-codec Sort to Top (port from POV 5.12). Setting 2 moves items whose extraInfo has
		# this codec/HDR key to the top, stable within groups. Codec settings stack: the LAST processed ends up on top.
		elif enable_setting == 2:
			priority = [i for i in results if key in i['extraInfo']]
			if priority and len(priority) != len(results):
				priority_ids = {id(i) for i in priority}
				remainder = [i for i in results if id(i) not in priority_ids]
				results = priority + remainder
		return results

	def sort_preferred_filters(self, results):
		if settings.sort_to_top_filter(self.autoplay):
			try:
				preferences = settings.preferred_filters()
				if not preferences: return results
				preferences = [self.filter_keys.get(i.lower(), i) for i in preferences]
				# LOCAL PATCH 2026-10-25 (4.0.5): one-pass split (was `not i in preference_results`, quadratic)
				preference_results, _rest = [], []
				for i in results: (preference_results if any(x in i['extraInfo'] for x in preferences) else _rest).append(i)
				if not preference_results: return results
				results = _rest
				preference_results = sorted([dict(item, **{'pref_includes': sum([{0:100, 1:50, 2:20, 3:10, 4:5, 5:2}[preferences.index(x)] \
					for x in [i for i in preferences if i in item['extraInfo']]])}) for item in preference_results], key=lambda k: k['pref_includes'], reverse=True)
				return preference_results + results
			except: pass
		return results

	def sort_first(self, results):
		try:
			sort_first_scrapers = []
			if 'folders' in self.all_scrapers and settings.sort_to_top('folders'): sort_first_scrapers.append('folders')
			sort_first_scrapers.extend([i for i in self.all_scrapers if i in ('rd_cloud', 'pm_cloud', 'ad_cloud', 'tb_cloud') and settings.sort_to_top(i)])
			if not sort_first_scrapers: return results
			sort_first = [i for i in results if i['scrape_provider'] in sort_first_scrapers]
			sort_first.sort(key=lambda k: (self._sort_folder_to_top(k['scrape_provider']), k['quality_rank']))
			sort_last = [i for i in results if not i['scrape_provider'] in sort_first_scrapers]   # LOCAL PATCH 2026-10-25 (4.0.5): was `not i in sort_first` (quadratic)
			results = sort_first + sort_last
		except: pass
		return results

	def limit_quality_numbers(self, results):
		if self.autoplay: return results
		quality_limit = settings.limit_number_quality()
		if not quality_limit: return results
		quality_counter_dict, limit_list = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0, 'SCR': 0, 'CAM': 0, 'TELE': 0}, []
		for i in results:
			if quality_counter_dict[i['quality']] < quality_limit:
				quality_counter_dict[i['quality']] += 1
				limit_list.append(i)
		return limit_list

	def limit_quality_total(self, results):
		if self.autoplay: return results
		total_limit = settings.limit_number_total()
		if not total_limit: return results
		return results[:total_limit]

	def prepare_internal_scrapers(self):
		if self.active_external and len(self.active_internal_scrapers) == 1: return
		active_internal_scrapers = [i for i in self.active_internal_scrapers if not i in self.remove_scrapers]
		if self.prescrape and not self.active_external and all([settings.check_prescrape_sources(i, self.media_type) for i in active_internal_scrapers]): return False
		if 'folders' in active_internal_scrapers:
			folder_info = self.get_folderscraper_info()
			self.folder_info = [i for i in folder_info if settings.source_folders_directory(self.media_type, i[1])]
			if self.folder_info:
				self.active_folders = True
				self.internal_scraper_names = [i for i in active_internal_scrapers if not i == 'folders'] + [i[0] for i in self.folder_info]
			else: self.internal_scraper_names = [i for i in active_internal_scrapers if not i == 'folders']
		else:
			self.folder_info = []
			self.internal_scraper_names = active_internal_scrapers[:]
		self.active_internal_scrapers = active_internal_scrapers
		if self.clear_properties: self._clear_properties()
		return True

	def _mark(self, label):
		"""LOCAL PATCH 2026-10-02: scrape.diag_timing checkpoint -- ms since get_sources began."""
		if getattr(self, '_diag_timing', False):
			kodi_utils.logger('scrape.timing', 'setup %s: +%dms' % (label, int((time.perf_counter() - self._scrape_t0) * 1000)))

	def activate_providers(self, module_type, function, prescrape):
		_t0 = time.perf_counter()
		_module = self._get_module(module_type, function)
		if module_type == 'external': self._mark('external scraper built')
		sources = _module.results(self.search_info)
		if getattr(self, '_diag_timing', False):
			_name = 'external (all)' if module_type == 'external' else getattr(function, '__module__', str(function)).rsplit('.', 1)[-1]
			kodi_utils.logger('scrape.timing', '%s: %dms (%d sources)%s' % (_name, int((time.perf_counter() - _t0) * 1000), len(sources or []),
				' prescrape' if prescrape else ''))
		if not sources: return
		if prescrape: self.prescrape_sources.extend(sources)
		else: self.sources.extend(sources)

	def activate_external_providers(self):
		self.external_providers = self.external_sources()
		if not self.external_providers: self.disable_external('No External Providers Enabled')

	def disable_external(self, line1=''):
		if line1: kodi_utils.notification(line1, 2000)
		try: self.active_internal_scrapers.remove('external')
		except: pass
		self.active_external, self.external_providers = False, []

	def internal_sources(self, prescrape=False):
		active_sources = [i for i in self.active_internal_scrapers if i in ['easynews', 'rd_cloud', 'pm_cloud', 'ad_cloud', 'tb_cloud', 'aiostreams', 'http_streams']]
		try: sourceDict = [('internal', manual_function_import('scrapers.%s' % i, 'source'), i) for i in active_sources \
												if not (prescrape and not settings.check_prescrape_sources(i, self.media_type))]
		except: sourceDict = []
		return sourceDict

	def external_sources(self):
		# LOCAL PATCH 2026-09-26: the torrent providers are bundled in resources/lib/magneto (POV-style)
		# instead of loaded from a chosen script.module.* addon; scrapers/external.py runs them as before.
		try:
			from magneto import sources as magneto_sources
			from modules.source_utils import anime_providers_to_run, adult_anime_scrape, ADULT_ANIME_PROVIDERS
			# LOCAL PATCH 2026-10-05: on anime the anime list alone decides, the providers' own switches do not count
			# (source_utils.ANIME_ALL_SKIPPED); scrapers/external.py applies the same list again per provider.
			# LOCAL PATCH 2026-11-16: + sukebei on adult anime (source_utils.adult_anime_scrape)
			if self.is_anime:   # LOCAL PATCH 2026-11-23: determine_scrapers_status's verdict
				sourceDict = magneto_sources(specified_folders=['torrents'],
						only=anime_providers_to_run(self.all_scrapers_retry, adult_anime_scrape(self.meta)))
			# LOCAL PATCH 2026-11-18: never the adult-anime providers off anime. 'All scrapers' (ret_all) loads every module,
			# switch or not, and sukebei has no switch to be off -- it ran on Neagley S01E01 (5.7 s, 0 sources) and a film.
			else: sourceDict = [i for i in magneto_sources(specified_folders=['torrents'], ret_all=self.disabled_ext_ignored)
								if i[0] not in ADULT_ANIME_PROVIDERS]
		except: sourceDict = []
		return sourceDict

	def folder_sources(self):
		def import_info():
			for item in self.folder_info:
				scraper_name = item[0]
				module = manual_function_import('scrapers.folders', 'source')
				yield ('folders', (module, (item[1], scraper_name, item[2])), scraper_name)
		# LOCAL PATCH 2026-08-31: no unguarded import_info() call above this try -- it would raise past this except.
		try: sourceDict = list(import_info())
		except: sourceDict = []
		return sourceDict

	def play_source(self, results):
		matched = self._sticky_match(results)
		# LOCAL PATCH 2026-10-08: on the next-episode handoff a pinned source is checked while the episode still plays. A dead
		# one is dropped and the match asked again, so another copy of the same release gets its turn; when none is left the
		# picker follows the end of the episode.
		_dead_checked = 0
		while matched is not None and not self._precheck_pinned(matched):
			self._mark_dead(matched)
			_dead_checked += 1
			_prev, matched = matched, (self._sticky_match(results) if _dead_checked < 3 else None)
			if matched is _prev: matched = None   # no hash to rule it out with
		if matched is None and _dead_checked:
			logger('SmartPlay', 'pinned source is down; picker after this episode')
			self.picker_notice = 'SmartPlay: saved source is down - pick another'
			return self.display_results(results)
		if matched is not None:
			# LOCAL PATCH 2026-09-27: the pin follows the episode, also when SmartPlay keeps matching it.
			# player.playback_close_dialogs saves playing_item once Kodi is really playing, so a failed play leaves the old
			# pin as it was (_sticky_reset_play_state).
			self.sticky_pending = True
			self.play_file([matched], matched)
			if self.playback_successful: return
			# LOCAL PATCH 2026-07-02: read self.user_cancelled (genuine user Back / cancel),
			# not self.cancel_all_playback (which also fires on playback failure).
			user_cancelled = self.user_cancelled
			self._sticky_reset_play_state()
			if user_cancelled:
				logger('SmartPlay', 'user cancelled sticky resolve; aborting (sticky preserved)')
				return
			# LOCAL PATCH 2026-09-16: the picker opens on EVERY path, background and autoplay included, although
			# autoplay_nextep_handler has already stopped the previous episode: pinning says WHICH release to play, so quietly
			# playing another when the pin will not resolve is the outcome pinning exists to prevent.
			# No re-pin here: display_results arms sticky_pending when the user picks; backing out keeps the old pin.
			logger('SmartPlay', 'sticky-matched source failed; showing picker')
			self.picker_notice = 'SmartPlay: saved source failed - showing picker'
			return self.display_results(results)
		# LOCAL PATCH 2026-08-31: a sticky MISS opens the picker even when background/autoplay would play results[0]
		# silently (the next-episode handler passes background='true'). Narrow: needs SmartPlay on, a saved pin for this
		# show and a failed match; prescrape and in-dialog rescrape keep plain upstream behaviour.
		if getattr(self, 'sticky_miss', False):
			# LOCAL PATCH 2026-09-20: on every path, as for a pin that fails to resolve. Cost accepted: on the autoplay path
			# the previous episode is already stopped, and a miss is often transient -- but substituting a release unannounced
			# is what pinning exists to prevent.
			# LOCAL PATCH 2026-09-20: run the next-episode handoff check BEFORE opening the picker -- the countdown lives in
			# play_file, which a miss no longer reaches. Not added to the failure branch above: play_file already ran it there
			# and a second call would prompt twice.
			# LOCAL PATCH 2026-10-08: not on the next-episode handoff: display_results holds the picker until the episode ends
			# (or cuts the credits), and the picker is itself the question the countdown asked.
			if not self._nextep_autoplay():
				if not self.continue_resolve_check(): return self._kill_progress_dialog()
			self.picker_notice = 'SmartPlay: saved source not found - showing picker'
			return self.display_results(results)
		# LOCAL PATCH 2026-10-08: SmartPlay on, but this show has no pin yet: rather than play the top result unasked, the
		# user picks once, after this episode, and that pick becomes the pin every later episode follows.
		if getattr(self, 'sticky_no_pin', False) and self._nextep_autoplay():
			logger('SmartPlay', 'no saved source for this show; picker after this episode')
			self.picker_notice = 'SmartPlay: no saved source yet - pick one, next episodes will follow it'
			return self.display_results(results)
		if self.background or self.autoplay: return self.play_file(results)
		return self.display_results(results)

	def _smartplay_enabled(self):
		return get_setting('deadlight.smartplay.enabled', 'false') == 'true'

	def _smartplay_active(self):
		"""SmartPlay on, and not a prescrape call. LOCAL PATCH 2026-08-31 (doc only): tested by KEY PRESENCE, not value --
		prescrape:'false' still disables SmartPlay. Every current caller (rescrape menu, autoscrape chain) wants that; a new
		caller setting the key for another reason would turn SmartPlay off unaware."""
		return self._smartplay_enabled() and 'prescrape' not in self.params

	def _nextep_autoplay(self):
		"""LOCAL PATCH 2026-10-08: the automatic next-episode handoff (episode_tools sets play_type), not a play the user started."""
		return bool(self.background) and getattr(self, 'play_type', '') == 'autoplay_nextep'

	def _precheck_pinned(self, item):
		"""LOCAL PATCH 2026-10-08: resolve a pinned source and ask the link for one byte BEFORE the countdown stops the
		playing episode, so a dead link does not leave a picker over a stopped show. Only on the next-episode handoff;
		False only when the link is known dead. The resolved URL rides on the item as '_preresolved' so play_file does not
		resolve it a second time."""
		if not self._nextep_autoplay(): return True
		url = item.get('_preresolved') or self.resolve_sources(item)
		if not url:
			logger('SmartPlay precheck', 'did not resolve: %s' % (item.get('name') or '')[:80])
			return False
		# LOCAL PATCH 2026-11-04: a multi-host release was just checked by _resolve_direct_fallbacks (direct_url_alive: same
		# 1-byte request, stricter -- it also refuses HTML); asking again cost ~1.7 s per handoff.
		verdict = True if url == item.get('_alive_checked') else _probe_stream(url)
		logger('SmartPlay precheck', '%s: %s' % ({True: 'ok', False: 'dead link', None: 'could not tell; playing'}[verdict], (item.get('name') or '')[:80]))
		if verdict is False: return False
		item['_preresolved'] = url
		return True

	def _mark_dead(self, item):
		try:
			if item.get('hash'): self._sticky_dead_hashes.add(str(item['hash']).lower())
		except Exception: pass

	# LOCAL PATCH 2026-11-01 (cleanup): the pin store is read / written through modules/smartplay_utils (load_all / save_all).

	def _sticky_after_play(self, tag, dead_item=None):
		"""After a sticky play_file: True on success (LOCAL PATCH 2026-09-07: touched, so a working pin does not age out of
		the LRU) or on the user's cancel; False -> the fallback scrape.
		LOCAL PATCH 2026-07-02: user_cancelled (set only on a genuine Back-press / next-ep cancel), NOT cancel_all_playback,
		which also fires on playback failure. User-cancel -> True (keep pin, no retry); failure -> False (picker opens).
		LOCAL PATCH 2026-09-27: dead_item (the provider path) is marked dead, or the fallback scrape's hash tier matched the
		stream that had just failed and played it into the same failure. The debrid path marks its hash before playing."""
		if self.playback_successful:
			self._sticky_touch()
			return True
		if self.user_cancelled:
			logger(tag, 'user cancelled; aborting (no fallback scrape)')
			self._sticky_reset_play_state()
			return True
		if dead_item is not None: self._mark_dead(dead_item)
		logger(tag, 'play_file failed; falling back to scrape')
		self._sticky_reset_play_state()
		return False

	def _sticky_reset_play_state(self):
		self.sticky_pending = False   # LOCAL PATCH 2026-09-27: a follow armed for a play that failed must not save
		self.resolve_dialog_made = False
		self.progress_dialog, self.progress_thread = None, None
		self.playback_successful, self.cancel_all_playback, self.user_cancelled = None, False, False

	def _sticky_match(self, results):
		# LOCAL PATCH 2026-08-31: this returns None for six different reasons and only ONE of
		# them -- a sticky entry exists for this show but nothing in the results matches it --
		# should change what play_source does. Flag that case specifically; every early
		# return below leaves it False so unrelated paths keep plain upstream behaviour.
		self.sticky_miss = False
		self.sticky_no_pin = False   # LOCAL PATCH 2026-10-08: SmartPlay asked, nothing pinned for this show (see play_source)
		if not self._smartplay_active(): return None
		if self.scrape_count > 1:
			logger('SmartPlay', 'in-dialog rescrape detected; bypassing sticky match to let user pick')
			return None
		if not results: return None
		# LOCAL PATCH 2026-09-04: drop anything this attempt has already proved dead before
		# any tier looks at it, so the name tiers cannot re-offer it either.
		_dead = getattr(self, '_sticky_dead_hashes', None)
		if _dead:
			_before = len(results)
			results = [i for i in results if (i.get('hash') or '').lower() not in _dead]
			if len(results) != _before:
				logger('SmartPlay', 'skipping %d result(s) whose resolve already failed this attempt'
					% (_before - len(results),))
			if not results: return None
		state = smartplay_utils.load_all().get(str(self.tmdb_id))
		if not state:
			self.sticky_no_pin = True
			return None
		saved_hash = (state.get('hash') or '').lower()
		saved_name = state.get('last_name') or ''
		# LOCAL PATCH 2026-09-27: the same torrent as a SEASON pack recorded for another season cannot be the pick -- its file
		# for this episode number is the other season's (see _sticky_pack_play). Same hash, or the same exact name, is that
		# torrent, so both tiers stand down; the same-release tiers below still follow the pin to this season's release.
		_other_season_pack = False
		try:
			_pk = state.get('pack') or {}
			_other_season_pack = (self.media_type == 'episode' and _pk.get('package') == 'season'
				and _pk.get('season') is not None and int(_pk['season']) != int(self.season))
		except Exception: pass
		if _other_season_pack: logger('SmartPlay', 'pin is a season pack for another season; skipping its hash / exact-name match')
		if saved_hash and not _other_season_pack:
			for item in results:
				if (item.get('hash') or '').lower() == saved_hash:
					logger('SmartPlay hash match', '%s' % saved_hash[:12])
					return item
		if saved_name:
			# LOCAL PATCH 2026-11-09: names compared without the host decorations older Direct Streams rows and pins carry
			# ('[PixelDrain] ...', '... FSL-V2 | 4KHDHub'), so a pin saved before 4.0.25 still meets today's rows
			from modules import smartplay_match
			_clean = smartplay_match.clean_name
			def _pin_name(name): return _PIN_HASH_TAG.sub('', _clean(name or '')).strip()
			lp, names = _pin_name(saved_name), [_pin_name(item.get('name', '')) for item in results]
			if not _other_season_pack:
				for item, rel in zip(results, names):
					if rel == lp:
						logger('SmartPlay name exact match', rel[:80])
						return item
			if self.media_type == 'episode':
				# LOCAL PATCH 2026-08-31: this fallback follows a pin to the NEXT episode -- same group, same quality, one number
				# changed. "Differs only at some digit position" alone matched S01E01, S02E05, S01E0999 or a 2080p encode for
				# episode 6, so three guards: equal lengths (a substitution, not a prefix), the substituted digits ARE the wanted
				# episode, and seas_ep_filter confirms no other digit in the name stands in for it.
				ep_forms = []
				for _form in (str(self.episode or 0), str(self.episode or 0).zfill(2)):
					if _form not in ep_forms: ep_forms.append(_form)
				for ep in ep_forms:
					L = len(ep)
					digit_positions = [i for i in range(len(lp) - L + 1) if lp[i:i + L].isdigit()]
					if not digit_positions: continue
					for item, rel in zip(results, names):
						if len(rel) != len(lp): continue
						for pos in digit_positions:
							if rel[pos:pos + L] != ep: continue
							if not (rel.startswith(lp[:pos]) and rel.endswith(lp[pos + L:])): continue
							try:
								if not seas_ep_filter(int(self.season), int(self.episode), rel): continue
							except Exception: continue
							logger('SmartPlay name position match', rel[:80])
							return item
				# Same-release tier (LOCAL PATCH 2026-09-01; reworked 2026-11-09, modules/smartplay_match). The position match above
				# fails whenever names embed the episode TITLE (lengths differ). So follow the release's identity, and let
				# seas_ep_filter alone decide WHICH episode -- that gate is not optional (a loose matcher once replayed the wrong
				# episode). The identity was read once when the pick was saved; a field a name does not state (a group 4KHDHub's
				# cut took, a fansub name with none) is UNKNOWN, not a mismatch -- the old tier skipped every pin without a group,
				# and read a cut tail ('-4kH', '-D') as one. What still refuses a candidate: smartplay_match.refusal.
				pin_id = smartplay_match.of_pin(state)
				_t4, same_release = {}, []
				for item in results:
					rel = _clean(item.get('name', '') or '')
					if not rel:
						_t4['no_name'] = _t4.get('no_name', 0) + 1
						continue
					try:
						if not seas_ep_filter(int(self.season), int(self.episode), rel):
							_t4['episode'] = _t4.get('episode', 0) + 1
							continue
					except Exception:
						_t4['episode_error'] = _t4.get('episode_error', 0) + 1
						continue
					cand_id = smartplay_match.of_item(item)
					why = smartplay_match.refusal(pin_id, cand_id)
					if why:
						_t4[why] = _t4.get(why, 0) + 1
						continue
					same_release.append((item, cand_id))
				if not same_release:
					# LOCAL PATCH 2026-09-03: WHY nothing matched -- the axis each candidate failed
					logger('sticky.tier4', 'no candidate matched pin %s -- rejected on %s' % (smartplay_match.describe(pin_id), _t4 or '{}'))
				else:
					# Best first: the pin's provider, host, HDR format, codec, service, then the largest file (smartplay_match.rank;
					# the provider-first order is the 4.0.5 rule, the codec key the 2026-11-09 one)
					same_release.sort(key=lambda p: smartplay_match.rank(pin_id, p[1], p[0].get('size')), reverse=True)
					best = same_release[0][0]
					logger('SmartPlay same-release match', '%s (pin %s)' % ((best.get('name', '') or '')[:80], smartplay_match.describe(pin_id)))
					return best
		# Reached only when a sticky entry EXISTS and no tier matched it -- not hash, not exact
		# name, not position, not same-release. The saved source is genuinely absent here.
		self.sticky_miss = True
		logger('SmartPlay', 'sticky entry present but unmatched in %s results' % len(results))
		return None

	def _sticky_save(self, source):
		if not self._smartplay_enabled(): return
		if not source or not self.tmdb_id: return
		try:
			entry = {
				'last_name': source.get('name', '') or '',
				'hash': (source.get('hash') or '').lower(),
				'scrape_provider': source.get('scrape_provider', ''),
				'hoster': source.get('hoster', ''),   # LOCAL PATCH 2026-10-25 (4.0.5): FSL-V2 / PixelDrain (Direct Streams), see _sticky_match
				'ts': int(time.time()),
			}
			pkg_raw = source.get('package', '')
			cache_provider = source.get('cache_provider', '')
			magnet_url = source.get('url') or source.get('url_dl') or ''
			scrape_provider = source.get('scrape_provider', '')
			if cache_provider in _DEBRID_CACHE_PROVIDERS and magnet_url and entry['hash']:
				if pkg_raw in ('show', 'season'): pack_default = pkg_raw
				elif self.media_type != 'episode': pack_default = ''
				# LOCAL PATCH 2026-09-06: was unconditionally 'season' for every episode pin, which is
				# what made pack-play fail on every transition. See _SINGLE_FILE_NAME.
				elif _SINGLE_FILE_NAME.search(entry['last_name'] or ''): pack_default = 'episode'
				else: pack_default = 'season'
				entry['pack'] = {
					'type': 'debrid',
					'cache_provider': cache_provider,
					'url': magnet_url,
					'hash': entry['hash'],
					'name': entry['last_name'],
					'package': pack_default,
					# LOCAL PATCH 2026-09-06: which episode this pin actually holds, so a single-file
					# pin can still pack-play an instant REPLAY of the same episode while being
					# skipped for every other one.
					'season': getattr(self, 'season', None),
					'episode': getattr(self, 'episode', None),
					'quality': source.get('quality', 'SD'),
					'size': source.get('size', 0),
					'size_label': source.get('size_label', ''),
					'extraInfo': source.get('extraInfo', ''),
					'debrid': source.get('debrid', cache_provider),
					'scrape_provider': scrape_provider or 'external',
					'media_type': self.media_type,
				}
			elif scrape_provider == 'aiostreams':
				entry['pack'] = {
					'type': 'aiostreams',
					'name': entry['last_name'],
					'hash': entry['hash'],
					'media_type': self.media_type,
				}
			data = smartplay_utils.load_all()
			# LOCAL PATCH 2026-11-09: the release's identity (modules/smartplay_match), read once here from the best name there
			# is -- the row's own, which for Direct Streams is now the file's full name when its link states it, and the file
			# picked inside a debrid pack. Fields this name cannot state are taken from the previous pin when it is the same
			# kind of release (the pin follows each episode; a cut name must not erase what earlier ones stated). This replaces
			# the 2026-09-27 rule that kept the previous NAME after a cut one: the identity carries that knowledge now.
			try:
				from modules import smartplay_match
				prev = data.get(str(self.tmdb_id)) or {}
				new_id = smartplay_match.identity(entry['last_name'], entry['scrape_provider'], entry['hoster'], source.get('file_name') or '')
				entry['identity'] = smartplay_match.fill_from(new_id, smartplay_match.of_pin(prev) if prev else None)
			except Exception as e: logger('SmartPlay save', 'identity not saved: %s' % type(e).__name__)
			data[str(self.tmdb_id)] = entry
			if len(data) > 10:
				data = dict(sorted(data.items(), key=lambda kv: kv[1].get('ts', 0), reverse=True)[:10])
			smartplay_utils.save_all(data)
			logger('SmartPlay save', 'tmdb=%s pack=%s host=%s name=%s%s' % (self.tmdb_id, 'pack' in entry, entry['hoster'] or '-', entry['last_name'][:100],
				(' -- %s' % smartplay_match.describe(entry['identity'])) if entry.get('identity') else ''))
			# LOCAL PATCH 2026-11-01: keep the link this pick played, so the first pinned replay reuses it like a pinned play's
			# own (saves a ~2 s TorBox round). Only for a debrid pack: the pinned path reads the link for that, and only the
			# link play_file just played.
			if entry.get('pack', {}).get('type') == 'debrid' and getattr(self, 'playing_url', None):
				self._keep_pin_link(entry['hash'], self.playing_url)
		except Exception as e: logger('SmartPlay save exception', str(e))

	def _pin_link_key(self, info_hash):
		return 'smartplay_link_%s_%s_%s' % (str(info_hash).lower(), self.season or '', self.episode or '')

	def _keep_pin_link(self, info_hash, url):
		"""LOCAL PATCH 2026-10-31 / 11-01: a resolved debrid link kept 3 hours for the next pinned play of this hash and
		episode (_sticky_debrid_play probes it with one byte before using it). The pack file rides along for subtitles."""
		try:
			from caches.main_cache import main_cache
			main_cache.set(self._pin_link_key(info_hash), {'url': url, 'pack_file': kodi_utils.get_property('deadlight.playing.pack_file') or ''}, expiration=3)
		except Exception: pass

	def _sticky_touch(self):
		"""LOCAL PATCH 2026-09-07: refresh the pin timestamp after a successful pack-play. The pin store is a 10-entry LRU
		on ts and _sticky_save runs only on a pick in the results window, so a pin used daily via pack-play would otherwise
		be evicted by picks on other shows. Touch only; nothing else about the pin changes."""
		try:
			data = smartplay_utils.load_all()
			entry = data.get(str(self.tmdb_id))
			if not entry: return
			entry['ts'] = int(time.time())
			smartplay_utils.save_all(data)
		except Exception: pass


	def _sticky_pack_play(self):
		if not self._smartplay_active(): return False
		state = smartplay_utils.load_all().get(str(self.tmdb_id)) or {}
		pack = state.get('pack')
		# LOCAL PATCH 2026-09-27: a pin with no pack but a single DeadLight provider behind it asks that provider alone
		# first instead of waiting out the full scrape (every torrent provider plus the debrid cache check); on no match
		# (or a failed play) the full scrape and its sticky-miss picker follow.
		if not pack:
			provider = state.get('scrape_provider') or ''
			if provider in _SINGLE_PROVIDER_PINS: return self._sticky_provider_play(provider)
			return False
		ptype = pack.get('type') or ('debrid' if pack.get('cache_provider') else '')
		# LOCAL PATCH 2026-09-27: aiostreams before the name tests below. Those ask whether a pinned TORRENT can hold the
		# wanted episode; an aiostreams pin has no torrent (its path scrapes the wanted episode fresh), so they would skip
		# the very case the same-release tier in _sticky_match exists for.
		if ptype == 'aiostreams': return self._sticky_provider_play('aiostreams')
		# LOCAL PATCH 2026-09-06 (revised): keyed on the pin's own NAME, not the stored package label, which older pins lack
		# and which mislabels extensionless single-episode names as 'season'. A name saying SxxExx names ONE episode; if it
		# is not the one asked for, skip to the scrape and let _sticky_match's same-release tiers follow the pin. A genuine
		# pack ('...S01.1080p', no Exx) is untouched. seas_ep_filter stays non-strict on purpose: a false positive only
		# means we do NOT skip.
		_pin_name = pack.get('name') or ''
		if self.media_type == 'episode' and _EPISODE_MARKER.search(_pin_name):
			try: _wanted = seas_ep_filter(int(self.season), int(self.episode), _pin_name)
			except Exception: _wanted = True
			if not _wanted:
				logger('SmartPlay pack-play', 'pin names one episode (%s); skipping pack resolve for S%sE%s'
					% (_pin_name[:60], self.season, self.episode))
				return False
		# LOCAL PATCH 2026-09-07: the season-pack counterpart. A pin named '...S01.2160p...' IS a pack, but asked for
		# S02E01 pack-play would search the S01 torrent. One Sxx token and no Exx names one season; if that is not the
		# season requested, skip. Multi-season packs ('S01-S05', 'S01.S02') carry several tokens and are left alone. The
		# recorded pack.season is preferred; the name is the fallback for pins saved without it.
		if self.media_type == 'episode' and not _EPISODE_MARKER.search(_pin_name):
			_seasons = _season_tokens(_pin_name)
			if len(_seasons) == 1:
				try:
					_pin_season = pack.get('season')
					_pin_season = int(_pin_season) if _pin_season is not None else int(_seasons[0])
					if _pin_season != int(self.season):
						logger('SmartPlay pack-play', 'pin is a season pack for S%02d (%s); skipping pack resolve for S%sE%s'
							% (_pin_season, _pin_name[:50], self.season, self.episode))
						return False
				except Exception: pass
			# LOCAL PATCH 2026-09-13: the anime absolute-numbering gap -- a name with NO Exx and NO Sxx (the fansub shape,
			# 'Okusama.ga.Seitokaichou!.-.03.[...].mkv'), which the name tests cannot read. Fall back to the pin's recorded
			# package / season / episode: written by our own code, not parsed from a provider string, so they are the only
			# trustworthy thing left. elif, so a pin with one or more Sxx tokens keeps the season-pack behaviour above.
			elif not _seasons:
				try:
					_pin_pkg = pack.get('package') or ''
					_pin_s, _pin_e = pack.get('season'), pack.get('episode')
					# Both halves must be certain before skipping: package=='episode' (the pin is ONE file) and both ints recorded
					# (older pins have neither and must fall through). Not skipping costs one futile ~1.5 s resolve_cached; skipping
					# wrongly loses a pack-play that would have worked.
					# LOCAL PATCH 2026-09-27: a SEASON pack whose name states no season ('The.Saga.of.Tanya.the.Evil.(BD.RMX...'),
					# pinned on S1E2: asked for S2E2 it played the pack's episode-2 file, i.e. S1E2 again. When the pack holds a
					# DIFFERENT season, not skipping plays the wrong episode. The recorded season is our own TMDb-space int, so a
					# filename's absolute number cannot mislead it. A 'show' pack spans seasons and is left alone.
					if _pin_pkg == 'season' and _pin_s is not None and int(_pin_s) != int(self.season):
						logger('SmartPlay pack-play', 'pin is a season pack recorded for S%02d (%s); skipping pack resolve for S%sE%s'
							% (int(_pin_s), _pin_name[:50], self.season, self.episode))
						return False
					if _pin_pkg == 'episode' and _pin_s is not None and _pin_e is not None:
						# Compare the PAIR in TMDb space: both sides come from self.season/self.episode (the pin's at save time), so the
						# filename's absolute number never enters it. != keeps the instant REPLAY of the same episode pack-playing.
						# int() both sides -- self.season/self.episode are strings on this path.
						if (int(_pin_s), int(_pin_e)) != (int(self.season), int(self.episode)):
							logger('SmartPlay pack-play', 'pin is a single file holding S%02dE%02d (%s); skipping pack resolve for S%sE%s'
								% (int(_pin_s), int(_pin_e), _pin_name[:50], self.season, self.episode))
							return False
				# Nothing here may raise into pack-play, but the except must log: int() on an old pin's '' / non-numeric value
				# would otherwise silently stop the skip, and the wrong episode would play with nothing in the log. Falling
				# through is still the right behaviour.
				except Exception as e:
					try:
						logger('SmartPlay pack-play', 'single-file pin test failed (%s: %s); pin s=%r e=%r asked s=%r e=%r -- proceeding with pack resolve'
							% (type(e).__name__, e, pack.get('season'), pack.get('episode'), self.season, self.episode))
					except Exception: pass
		if ptype == 'debrid': return self._sticky_debrid_play(pack)
		return False

	def _pack_holds_episode(self, info_hash):
		"""Check a saved pack using any file listing still cached by an older build."""
		try:
			from modules.debrid import query_local_cache_files
			from modules.source_utils import listing_holds_episode, supported_video_extensions
			listings = query_local_cache_files([info_hash, str(info_hash).lower()], 'tb')
			blob = listings.get(info_hash) or listings.get(str(info_hash).lower())
			if not blob: return None
			extensions = tuple(supported_video_extensions())
			usable = [{'filename': f['name'], 'size': f['size']} for f in json.loads(blob)
					  if f.get('name') and f.get('size') and str(f['name']).lower().endswith(extensions)]
			if not usable: return None
			meta = self.meta if isinstance(getattr(self, 'meta', None), dict) else {}
			cands = anime_episode_candidates(meta, meta.get('tmdb_id'), int(self.season), int(self.episode))
			return listing_holds_episode(usable, self.season, self.episode, cands or None, meta.get('title') or None)
		except Exception: return None

	def _sticky_debrid_play(self, pack):
		cache_provider = pack.get('cache_provider', '')
		info_hash = pack.get('hash', '')
		magnet_url = pack.get('url', '')
		pack_type = pack.get('package', 'season')
		if not (cache_provider and info_hash and magnet_url): return False
		is_episode = self.media_type == 'episode'
		# LOCAL PATCH 2026-11-09: a pinned pack whose stored TorBox file list shows it without this episode is not resolved --
		# that cost ~3 s and a second scrape window for nothing (Mushoku, 2026-11-08). The scrape follows at once. No stored
		# list, or one the episode matcher cannot read: pack-play goes ahead as before.
		if is_episode and cache_provider == 'TorBox' and self._pack_holds_episode(info_hash) is False:
			logger('SmartPlay pack-play[debrid]', 'pinned pack %s has no S%sE%s in its stored file list; skipping to the scrape'
				% (info_hash[:12], self.season, self.episode))
			self._mark_dead({'hash': info_hash})
			return False
		logger('SmartPlay pack-play[debrid]', 'cache=%s hash=%s media=%s s=%s e=%s' % (cache_provider, info_hash[:12], self.media_type, self.season, self.episode))
		try: title = self.meta.get('title', '') if isinstance(getattr(self, 'meta', None), dict) else ''
		except: title = ''
		# LOCAL PATCH 2026-10-31: the Resolving window from the start, not Kodi's spinner over Home for the debrid round.
		# play_file finds it made (resolve_dialog_made) and carries on in it. Not for a background handoff, which keeps its
		# own window rules.
		early_window = not self.background
		if early_window:
			try:
				from windows.sources import shown_size as _shown_size
				self._make_resolve_dialog()
				self.progress_dialog.update_resolver(text='[B]%s  ·  %s  ·  %s[/B][CR][COLOR FF85828A]%s[/COLOR]' % (cache_provider,
					pack.get('quality', ''), _shown_size(pack.get('size_label', '')), pack.get('name', '')), percent=0, detail='Source 1 of 1')
				self.progress_dialog.busy_spinner()
			except Exception as e:
				logger('SmartPlay pack-play[debrid] early window', str(e))
				early_window = False
		# LOCAL PATCH 2026-10-31: a pin's link is reused for 3 hours when it still serves a byte (_probe_stream, ~0.5 s)
		# instead of TorBox's three calls (add, file list, link: ~2.4 s). A TorBox link outlives the torrent's removal from
		# the list. The pack file it played rides along for subtitles.
		from caches.main_cache import main_cache
		link_key = self._pin_link_key(info_hash)
		url = None
		try:
			kept = main_cache.get(link_key)
			if isinstance(kept, dict) and kept.get('url') and _probe_stream(kept['url']) is True:
				url = kept['url']
				kodi_utils.set_property('deadlight.playing.pack_file', kept.get('pack_file') or '')
				logger('SmartPlay pack-play[debrid]', 'reusing the pinned link (still serving)')
		except Exception: url = None
		try:
			if not early_window: kodi_utils.show_busy_dialog()
			if url: pass
			elif is_episode:
				# LOCAL PATCH 2026-08-27: this path is a pack by definition, so the anime
				# numbering alternatives matter here even more than on the normal resolve path.
				_cands = anime_episode_candidates(self.meta, (self.meta or {}).get('tmdb_id'), int(self.season), int(self.episode))
				url = self.resolve_cached(cache_provider, magnet_url, info_hash, title, int(self.season), int(self.episode), pack_type in ('show', 'season'), _cands)
			else:
				url = self.resolve_cached(cache_provider, magnet_url, info_hash, title, None, None, False)
			if url: self._keep_pin_link(info_hash, url)
		except Exception as e:
			logger('SmartPlay pack-play[debrid] resolve error', str(e))
			url = None
		finally:
			if not early_window: kodi_utils.hide_busy_dialog()
		if not url and early_window:
			# the scrape that follows makes its own window, in its scraping mode
			self._kill_progress_dialog()
			self.resolve_dialog_made = False
		if not url:
			# LOCAL PATCH 2026-09-04: remember that this hash did not resolve, so the fallback scrape's hash tier does not hand
			# the same torrent straight back into the same failure. Instance-scoped on purpose: one playback attempt's verdict,
			# not a lasting judgement (playback_prep runs pack-play and the scrape on the same Sources object). The pin itself
			# is deliberately left alone.
			self._mark_dead({'hash': info_hash})
			logger('SmartPlay pack-play[debrid]', 'resolve_cached returned None; falling back to scrape')
			return False
		source = {
			'name': pack.get('name', ''),
			'display_name': pack.get('name', ''),
			'quality': pack.get('quality', 'SD'),
			'size': pack.get('size', 0),
			'size_label': pack.get('size_label', '0.00 GB'),
			'extraInfo': pack.get('extraInfo', ''),
			'url': magnet_url,
			'url_dl': magnet_url,
			'id': info_hash,
			'hash': info_hash,
			'cache_provider': cache_provider,
			'debrid': pack.get('debrid', cache_provider),
			'scrape_provider': pack.get('scrape_provider', 'external'),
			'package': pack_type,
			'local': False,
			'direct': False,
		}
		# LOCAL PATCH 2026-10-08: resolve_cached above already gave the link -- check it before the countdown stops the
		# episode, and hand it to play_file so it is not resolved a second time.
		# LOCAL PATCH 2026-10-25: on every pack-play, not only the autoplay handoff (saves a second TorBox round, 2-3 s).
		source['_preresolved'] = url
		if not self._precheck_pinned(source):
			self._mark_dead(source)
			try: main_cache.delete(link_key)
			except Exception: pass
			if early_window:
				self._kill_progress_dialog()
				self.resolve_dialog_made = False
			logger('SmartPlay pack-play[debrid]', 'pinned link is down; falling back to scrape')
			return False
		try: self.play_file([source], source)
		except Exception as e: logger('SmartPlay pack-play[debrid] play_file error', str(e))
		return self._sticky_after_play('SmartPlay pack-play[debrid]')

	def _sticky_provider_play(self, provider):
		# LOCAL PATCH 2026-09-27: any one internal provider (_SINGLE_PROVIDER_PINS, plus aiostreams via its pack). Raw
		# provider results: the pin was chosen from filtered results, and every tier past the hash is gated on seas_ep_filter.
		tag = 'SmartPlay pack-play[%s]' % provider
		if provider not in (self.active_internal_scrapers or []):
			logger(tag, 'provider not enabled; falling back to scrape')
			return False
		logger(tag, 'media=%s s=%s e=%s' % (self.media_type, self.season, self.episode))
		try:
			provider_source = manual_function_import('scrapers.%s' % provider, 'source')
			info = self.search_info   # set by make_search_info() in playback_prep, before any sticky play
			# LOCAL PATCH 2026-09-27: say what SmartPlay is doing in the loading window instead of a bare busy spinner
			# (the next-episode handoff runs in the background and has no window, so it keeps the spinner)
			name = provider_panel_name(provider)
			self._smartplay_status('SmartPlay: looking for your pinned release on %s' % name)
			if not self.background:
				if not self.progress_dialog: self._make_progress_dialog()
				try: self.progress_dialog.update_scraper(0, 0, 0, 0, 0, '', 0, providers=[(provider, provider_panel_name(provider), 'running', 0)],
														phase='Checking Pinned Provider', detail=name)
				except Exception: pass
			else: kodi_utils.show_busy_dialog()
			# LOCAL PATCH 2026-10-24: capped at _PIN_SCRAPE_CAP; a late scrape is left to finish on its own thread
			box = []
			def _scrape():
				try: box.append(provider_source().results(info) or [])
				except Exception as e: logger(tag + ' scrape error', str(e))
			worker = Thread(target=_scrape, daemon=True)
			worker.start()
			worker.join(_PIN_SCRAPE_CAP)
			if worker.is_alive(): logger(tag, 'no answer in %d s' % _PIN_SCRAPE_CAP)
			results = box[0] if box else []
		except Exception as e:
			logger(tag + ' scrape error', str(e))
			results = []
		finally:
			kodi_utils.hide_busy_dialog()
		matched = self._sticky_match(results) if results else None
		if matched is None:
			logger(tag, ('no match in %d results; falling back to scrape' % len(results)) if results else 'no results; falling back to scrape')
			self._smartplay_status('SmartPlay: pinned release not found - searching all providers')
			return False
		# LOCAL PATCH 2026-10-08: a dead link is found out while the episode still plays; the full scrape then offers
		# the release's other copies (play_source checks those the same way)
		if not self._precheck_pinned(matched):
			self._mark_dead(matched)
			logger(tag, 'pinned link is down; falling back to scrape')
			return False
		self._smartplay_status('SmartPlay: playing your pinned release')
		self.sticky_pending = True   # LOCAL PATCH 2026-09-27: the pin follows the episode (see play_source)
		try: self.play_file([matched], matched)
		except Exception as e: logger(tag + ' play_file error', str(e))
		return self._sticky_after_play(tag, dead_item=matched)

	def append_folder_scrapers(self, current_list):
		current_list.extend(self.folder_sources())

	def get_folderscraper_info(self):
		folder_info = [(get_setting('deadlight.%s.display_name' % i), i, settings.source_folders_directory(self.media_type, i))
						for i in ('folder1', 'folder2', 'folder3', 'folder4', 'folder5')]
		return [i for i in folder_info if not i[0] in (None, 'None', '') and i[2]]

	def scrapers_dialog(self):
		def _scraperDialog():
			monitor = kodi_utils.kodi_monitor()
			start_time = time.time()
			while not self.progress_dialog.iscanceled() and not monitor.abortRequested():
				try:
					remaining_providers = [x.getName() for x in _threads if x.is_alive() is True]
					self._process_internal_results()
					current_progress = max((time.time() - start_time), 0)
					percent = int((current_progress/float(25))*100)
					# LOCAL PATCH 2026-09-27: one row per provider; the bar shows providers done, the timer still ends it
					counts = getattr(self, 'provider_counts', {})
					# LOCAL PATCH 2026-11-23 (user): http_streams' thread is two rows, HTTP Scrapers and Stremio Add-ons (internal_row_keys)
					rows = [(k, provider_panel_name(k), 'running' if x.is_alive() else ('done' if counts.get(k) else 'none'), counts.get(k, 0))
							for x in _threads for k in row_keys[x.getName()]]
					done = len([r for r in rows if r[2] != 'running'])
					left = max(0, int(round(25 - current_progress)))
					shown = percent if len(rows) <= 1 else 100.0 * done / len(rows)
					self.progress_dialog.update_scraper(self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total, '', shown,
						providers=rows, phase='Searching Providers', detail='%d of %d done  ·  %ds left' % (done, len(rows), left),
						time_pct=None if len(rows) <= 1 else percent, late=left <= 3,
						hidden=self.window_counter.line() if hasattr(self, 'window_counter') else '')
					kodi_utils.sleep(self.sleep_time)
					if len(remaining_providers) == 0: break
					if percent >= 100: break
				except:	return self._kill_progress_dialog()
		if self.prescrape: scraper_list, _threads = self.prescrape_scrapers, self.prescrape_threads
		else: scraper_list, _threads = self.providers, self.threads
		self.internal_scrapers = self._get_active_scraper_names(scraper_list)
		if not self.internal_scrapers: return
		row_keys = {x.getName(): internal_row_keys(x.getName(), self.is_anime, self.all_scrapers_retry) for x in _threads}
		_scraperDialog()

	# LOCAL PATCH 2026-09-02: never draw the picker over a still-playing episode when the scrape was the AUTOMATIC
	# next-episode handoff (the alert fires at outro_start, so the scrape runs during the credits). Waiting in
	# display_results covers every route into the picker, including a rescrape from _process_post_results, and is
	# idempotent where the caller already waited.
	# Gated on play_type, NOT autoplay_nextep: that flag is just the autoplay_next_episode SETTING on an ordinary manual
	# play, and would delay a picker opened mid-episode to replace a stalling stream. play_type is set only by
	# episode_tools' next-episode handoff ('' for anything the user started).
	_NEXTEP_PLAY_TYPES = ('autoplay_nextep', 'autoscrape_nextep')

	# LOCAL PATCH 2026-10-15: SmartPlay missed, so the next episode needs a source picked. At the credits (window_time
	# before the end, as autoplay_nextep_handler) the Up Next card opens as a Choose Source card --
	#   Choose Source / no answer -> the episode is stopped, then True: the list opens (2026-11-08; a card counting to the
	#                                real end -- content after the outro -- lets it play out first)
	#   Watch Credits             -> the episode plays to its real end, then True
	#   Stop After This / Back    -> False: no list
	# Also False when the episode was CUT SHORT while we waited (the user's Stop, a dead stream) -- _finished_naturally.
	def _wait_out_playback(self):
		if getattr(self, 'play_type', '') not in self._NEXTEP_PLAY_TYPES: return True
		last = [None]
		def _remaining(player):
			try: last[0] = player.getTotalTime() - player.getTime()
			except Exception: pass
			return last[0]
		try:
			player = kodi_utils.kodi_player()
			if not player.isPlayingVideo(): return True
			_ns = getattr(self, 'nextep_settings', None) or {}
			_window = _ns.get('window_time') or 0
			while player.isPlayingVideo():
				_left = _remaining(player)
				if _left is None or round(_left) <= _window: break
				kodi_utils.sleep(500)
			if not player.isPlayingVideo(): return self._finished_naturally(last[0])
			# LOCAL PATCH 2026-10-15 (later): the card counts the ALERT time (autoplay_alert_countdown_sec), as the Up Next card
			# does, and no answer is 'stop' -- the episode is stopped and the list opens. Only where what is left is credits:
			# with content after the outro, or a percentage-guessed point, it counts to the real end ('to_end',
			# _make_nextep_dialog), and 'stop' then lands at the end itself.
			_to_end = _counts_to_end(_ns)
			# LOCAL PATCH 2026-11-16: always the card (the Notification alert is gone). No answer is 'list' (stop, open the list);
			# the card's Stop is 'stop' -- the player stops and nothing follows, as on the Up Next card.
			# LOCAL PATCH 2026-11-16: Play Next Immediately shows no card here either -- a choice is needed anyway, so the list
			# opens at the credits (credits_skip), or when the episode ends if they are not known (the % point may be story).
			if _ns.get('credits_mode') == 'play':
				action = 'list' if _ns.get('credits_skip') else 'close'
				kodi_utils.logger_debug('DialogFlash display_results', 'no auto-play, Play Next Immediately: source list %s' % ('now' if action == 'list' else 'at the end'))
			else:
				kodi_utils.logger_debug('DialogFlash display_results', 'no auto-play; Choose Source card (source=%s)' % _ns.get('transition_source'))
				action = self._make_nextep_dialog(default_action='list', choose=True)
			kodi_utils.logger_debug('DialogFlash display_results', 'Choose Source card answered %r' % action)
			if action == 'cancel': return False
			if action == 'stop':
				try:
					mark_internal_stop()
					if player.isPlayingVideo(): player.stop()
				except Exception: pass
				return False
			# LOCAL PATCH 2026-11-08: 'Choose source' stops the episode before the list opens, as Up Next's 'Next episode' does
			# (it opened the list over the still-playing episode, which played on under the picker -- user, 2026-11-08)
			if action in ('play', 'list'):
				if player.isPlayingVideo():
					kodi_utils.logger_debug('DialogFlash display_results', 'Choose Source card: %s -- stopping the episode, opening the list'
						% ('choose source' if action == 'play' else 'no answer'))
					try:
						mark_internal_stop()   # ours, not the user's -- see onPlayBackStopped
						player.stop()
					except Exception: pass
					while player.isPlayingVideo(): kodi_utils.sleep(100)
					return True
				if action == 'play': return True
				# over before the countdown ran out: the real end on a card counting to it, else cut short (a dead stream)
				return True if _to_end else self._finished_naturally(last[0])
			# The card answers 'cancel' itself on the user's Stop, so a card still open at a natural end comes back 'close'
			# with the episode over -- 'last' is then from when it opened, not the end; no position test for that.
			if not player.isPlayingVideo(): return True
			_remaining(player)
			while player.isPlayingVideo():
				_remaining(player)
				kodi_utils.sleep(250)
			return self._finished_naturally(last[0])
		except Exception: return True

	def _finished_naturally(self, last_remaining):
		if last_remaining is not None and last_remaining > NEXTEP_END_TOLERANCE:
			stopped = True
			# LOCAL PATCH 2026-10-15: a STREAM that died is not the user's Stop -- say so, or the chain just seems to hang.
			# onPlayBackStopped lands ~2.5 s after the player flips, so give it 3 s before deciding it was not the user.
			for _i in range(12):
				if kodi_utils.get_property(PLAYBACK_STOPPED_PROP) == 'true': break
				kodi_utils.sleep(250)
			else: kodi_utils.notification('Playback ended early - next episode not started', 6000)
		else:
			kodi_utils.sleep(600)   # onPlayBackStopped lands ~2.5 s after the player flips; the position test usually decides first
			stopped = kodi_utils.get_property(PLAYBACK_STOPPED_PROP) == 'true'
		if stopped: kodi_utils.logger_debug('DialogFlash display_results', 'episode cut short (last %s s from the end) -- no picker' % (None if last_remaining is None else int(last_remaining)))
		return not stopped

	def display_results(self, results):
		if not self._wait_out_playback(): return self._kill_progress_dialog()
		# LOCAL PATCH 2026-09-20: fire the SmartPlay notice HERE, not where the miss / failure was detected: on the autoplay
		# path _wait_out_playback blocks until the episode ends, long after a 3 s toast would have gone. Foreground is
		# unaffected (no wait). Set by play_source only, so other callers of display_results are untouched.
		_notice = getattr(self, 'picker_notice', None)
		if _notice:
			self.picker_notice = None
			kodi_utils.notification(_notice, 3000)
		window_format, window_number = settings.results_format()
		action, chosen_item = open_window(('windows.sources', 'SourcesResults'), 'sources_results.xml',
				window_format=window_format, window_id=window_number, results=results, meta=self.meta, episode_group_label=self.episode_group_label,
				scraper_settings=self.scraper_settings, prescrape=self.prescrape, filters_ignored=self.filters_ignored,
				uncached_results=self.uncached_results, filtered_results=self.filtered_results, external_cache_check=self.external_cache_check)
		if not action: self._kill_progress_dialog()
		# LOCAL PATCH 2026-11-22: 'play_filtered' -- a row picked under Show Filtered Sources plays alone (the next / previous rows
		# play_file falls back to are the shown list's, which that row is not in)
		elif action in ('play', 'play_filtered'):
			# LOCAL PATCH 2026-09-15: ARM the pin here, do not write it. play_file tries [source] + items_next + items_prev, so
			# the pick may fail and a later source play; player.playback_close_dialogs writes the pin once playback is
			# confirmed, from self.playing_item -- whatever is really on screen. A source that never played is never pinned.
			self.sticky_pending = True
			# LOCAL PATCH 2026-09-03: the user has just chosen this source by hand, so the
			# next-episode countdown must not then ask whether to play it. See
			# continue_resolve_check.
			self.chosen_by_user = True
			return self.play_file([chosen_item] if action == 'play_filtered' else results, chosen_item)
		elif self.prescrape and action == 'perform_full_search':
			self.prescrape, self.clear_properties = False, False
			return self.get_sources()
		elif action == 'cache_change_rescrape':
			self.external_cache_check = chosen_item == 'true'
			self.sources, self.orig_results, self.threads = [], [], []
			self.prescrape, self.clear_properties = False, False
			return self.get_sources()

	def _get_active_scraper_names(self, scraper_list):
		return [i[2] for i in scraper_list]

	def _tb_down_only(self):
		"""LOCAL PATCH 2026-10-25 (4.0.6): TorBox is the only debrid and is stalling (torbox_api.not_answering)."""
		try:
			if list(self.debrid_enabled or []) != ['TorBox']: return False
			from apis.torbox_api import not_answering
			return bool(not_answering())
		except Exception: return False

	def _process_post_results(self):
		# LOCAL PATCH 2026-10-25 (4.0.6): while TorBox is the reason, no retry that scrapes torrents again against the same dead
		# service -- only 'Access Filtered Results', whose rows can be Direct Streams -- and the no-results dialog says why
		if self._tb_down_only():
			self.retry_actions = [a for a in self.retry_actions if a[0] == 'ignore_filters']
			self._no_results_reason = 'TorBox is not answering, so no torrent can play. Try again in a minute.'
		if not self.retry_actions: return self._no_results(getattr(self, '_no_results_reason', None))
		next_action, next_setting, order = self.retry_actions.pop(0)
		if next_action == 'cache_ignored':
			if next_setting in (1, 2) and self.active_external and self.orig_results and self.external_cache_check \
																				and debrid.debrid_for_ext_cache_check(self.debrid_enabled):
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With Cache Check Disabled?'):
					self.threads, self.prescrape, self.external_cache_check = [], False, False
					return self.get_sources()
			return self._process_post_results()
		if next_action == 'imdb_year':
			if next_setting in (1, 2) and self.active_external and not self.orig_results and not self.meta.get('custom_year'):
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With IMDb Year Data?'):
					from apis.imdb_api import imdb_year_check
					imdb_year = str(imdb_year_check(self.meta.get('imdb_id')))
					if imdb_year != self.get_search_year():
						self.meta['custom_year'] = imdb_year
						self.make_search_info()
						self.threads, self.prescrape = [], False
						return self.get_sources()
			return self._process_post_results()
		if next_action == 'with_all':
			if next_setting in (1, 2) and self.active_external:
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With All Scrapers?'):
					self.threads, self.disabled_ext_ignored, self.prescrape, self.all_scrapers_retry = [], True, False, True
					# LOCAL PATCH 2026-11-23 (user): ALL is every scraper, DeadLight's own too (modules/provider_gate.runs_all)
					self.determine_scrapers_status()
					self.search_info['all_scrapers'] = True
					return self.get_sources()
			return self._process_post_results()
		if next_action == 'episode_group':
			if next_setting in (1, 2) and self.media_type == 'episode':
				if next_setting == 1 \
											or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With Custom Episode Group if Possible?'):
					if self.episode_group_used:
						self.params.update({'custom_season': None, 'custom_episode': None, 'episode_group_label': _CUSTOM_GROUP_LABEL % (self.season, self.episode),
											'skip_episode_group_check': True})
						self.threads, self.disabled_ext_ignored, self.prescrape = [], True, False
						return self.playback_prep()
					if next_setting == 2:
						from indexers.dialogs import episode_groups_choice
						try: group_id = episode_groups_choice({'meta': self.meta, 'poster': self.meta['poster']})
						except: group_id = None
					else:
						try: group_id = metadata.episode_groups(self.tmdb_id)[0]['id']
						except: group_id = None
					if group_id:
						try: group_details = metadata.group_episode_data(metadata.group_details(group_id), None, self.season, self.episode)
						except: group_details = None
						if group_details:
							season, episode = group_details['season'], group_details['episode']
							self.params.update({'custom_season': season, 'custom_episode': episode, 'episode_group_label': _CUSTOM_GROUP_LABEL % (season, episode)})
							self.threads, self.disabled_ext_ignored, self.prescrape = [], True, False
							return self.playback_prep()
			return self._process_post_results()
		if next_action == 'ignore_filters':
			if next_setting in (1, 2) and self.orig_results and not self.background:
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results. Access Filtered Results?'):
					if self.autoplay: kodi_utils.notification('Filters Ignored & Autoplay Disabled')
					self.threads, self.ignore_scrape_filters, self.disabled_ext_ignored, self.autoplay = [], True, True, False
					return self.get_sources()
			return self._process_post_results()

	def _no_results(self, reason=None):
		self._kill_progress_dialog()
		try: kodi_utils.hide_busy_dialog()
		except: pass
		if self.background: return kodi_utils.notification('[B]Next Up:[/B] %s' % ('TorBox is not answering' if reason else 'No Results'), 5000)
		title = self.meta.get('title') or self.meta.get('rootname') or ''
		text = 'No sources found' + ((' for [B]%s[/B]' % title) if title else '')
		if reason: text = '%s[CR]%s' % (text, reason)   # LOCAL PATCH 2026-10-25 (4.0.6)
		try: kodi_utils.ok_dialog(heading='No Results', text=text)
		except: kodi_utils.notification('No Results', 3000)

	def get_search_title(self):
		search_title = self.meta.get('custom_title', None) or self.meta.get('english_title') or self.meta.get('title')
		return search_title

	def get_search_year(self):
		year = self.meta.get('custom_year', None) or self.meta.get('year')
		return year

	def get_season(self):
		season = self.meta.get('custom_season', None) or self.meta.get('season')
		try: season = int(season)
		except: season = None
		return season

	def get_episode(self):
		episode = self.meta.get('custom_episode', None) or self.meta.get('episode')
		try: episode = int(episode)
		except: episode = None
		return episode

	def get_ep_name(self):
		ep_name = None
		if self.meta['media_type'] == 'episode':
			ep_name = self.meta.get('ep_name')
			try: ep_name = safe_string(remove_accents(ep_name))
			except: ep_name = safe_string(ep_name)
		return ep_name

	def _process_internal_results(self):
		for i in self.internal_scrapers:
			win_property = kodi_utils.get_property('deadlight.internal_results.%s' % i)
			if win_property in ('checked', '', None): continue
			try: sources = json.loads(win_property)
			except: continue
			kodi_utils.set_property('deadlight.internal_results.%s' % i, 'checked')
			self._sources_quality_count(sources)
			if not hasattr(self, 'provider_counts'): self.provider_counts = {}
			self.provider_counts.update(internal_counts(i, sources))   # LOCAL PATCH 2026-09-27: per-provider rows (2026-11-23: Stremio split)
	
	def _sources_quality_count(self, sources):
		# LOCAL PATCH 2026-09-30: each release once, and only what the list will show (source_utils.WindowCounter)
		if not hasattr(self, 'window_counter'): self.window_counter = WindowCounter(self._window_countable)
		sources = self.window_counter.keep(sources)
		for item in self.count_tuple: setattr(self, item[0], getattr(self, item[0]) + item[2](sources, item[1]))

	# LOCAL PATCH 2026-10-19 (SD-tag option B, user's call): a file whose resolution NOTHING states (no name token, the
	# scraper's 'unknown') is labelled SD and so dropped by a 4K / 1080p quality filter, even when it is the only copy.
	# Only when the quality filter would leave NOTHING are such rows kept, shown as UNKNOWN ('quality_unknown'; still
	# 'SD' for sorting). For an episode the file name must also carry the show's name or the episode's title (a
	# relabelled 'S00E07.mkv' of an unrelated OVA names neither).
	_STATED_LOW = re.compile(r'(?<![0-9])(?:480|576|360|240)[pi]?(?![0-9])|\bsd\b|dvd|vhs', re.I)

	def _unknown_resolution_fallback(self, results):
		def _norm(text): return re.sub(r'[^a-z0-9]', '', str(text or '').lower())
		names = []
		if self.media_type == 'episode':
			meta = getattr(self, 'meta', None) or {}
			for key in ('title', 'original_title', 'english_title', 'ep_name'):
				if _norm(meta.get(key)): names.append(_norm(meta.get(key)))
			for alias in (meta.get('alternative_titles') or [])[:20]:
				if len(_norm(alias)) >= 4: names.append(_norm(alias))
		kept = []
		for item in results:
			if item.get('quality', 'SD') != 'SD': continue
			text = ' '.join(str(item.get(k) or '') for k in ('name', 'display_name'))
			if get_release_quality(text.lower()) or self._STATED_LOW.search(text): continue   # a resolution IS stated
			if names and not any(n in _norm(text) for n in names): continue
			item['quality_unknown'] = True
			kept.append(item)
		if kept: kodi_utils.logger('###quality.unknown###', '%d row(s) kept with no stated resolution (the quality filter left none)' % len(kept))
		return kept

	def _quality_filter(self):
		setting = 'results_quality_%s' % self.media_type if not self.autoplay else 'autoplay_quality_%s' % self.media_type
		filter_list = settings.quality_filter(setting)
		# LOCAL PATCH 2026-09-30: Include means include. Upstream added CAM / SCR / TELE only when SD was allowed too, so
		# with '4K, 1080p' the switch did nothing -- and relabel_in_cinemas turns every result of a film in cinemas into CAM.
		if self.include_prerelease_results: filter_list = list(filter_list) + ['SCR', 'CAM', 'TELE']
		return filter_list

	def _get_size_rank(self, item):
		return item['size'] * 2 if self.weight_size and 'HEVC' in item['extraInfo'] else item['size']

	def _get_quality_rank(self, quality):
		return {'4K': 1, '1080p': 2, '720p': 3, 'SD': 4, 'SCR': 5, 'CAM': 5, 'TELE': 5}[quality]

	def _get_provider_rank(self, account_type):
		return self.provider_sort_ranks.get(account_type) or 11   # LOCAL PATCH 2026-10-03: .get -- one unknown debrid broke sorting for the whole scrape

	def _sort_folder_to_top(self, provider):
		if provider == 'folders': return 0
		else: return 1

	def _sort_uncached_results(self, results):
		# LOCAL PATCH 2026-10-25 (4.0.5): one-pass split (not `not i in uncached`, which is quadratic)
		cached, uncached = [], []
		for i in results: (uncached if 'Uncached' in i.get('cache_provider', '') else cached).append(i)
		return cached + uncached

	def get_meta(self):
		prefetched = self.params.get('_prefetched_meta') if isinstance(self.params, dict) else None
		if (self.media_type == 'episode' and isinstance(prefetched, dict)
				and 'tvshow_plot' in prefetched and 'season_data' in prefetched):
			self.meta = prefetched
			self.meta.update({'playcount': self.playcount, 'watch_count': self.watch_count,
							'custom_season': self.custom_season, 'custom_episode': self.custom_episode})
		elif self.media_type == 'movie':
			self.meta = metadata.movie_meta('tmdb_id', self.tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
		else:
			try:
				self.meta = metadata.tvshow_meta('tmdb_id', self.tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
				episodes_data = metadata.episodes_meta(self.season, self.meta)
				episode_data = [i for i in episodes_data if i['episode'] == self.episode][0]
				ep_thumb = episode_data.get('thumb', None) or self.meta.get('fanart') or ''
				episode_type = episode_data.get('episode_type', '')
				self.meta.update({'season': episode_data['season'], 'episode': episode_data['episode'], 'premiered': episode_data['premiered'], 'episode_type': episode_type,
								'ep_name': episode_data['title'], 'ep_thumb': ep_thumb, 'plot': episode_data['plot'], 'tvshow_plot': self.meta['plot'],
								'ep_duration': episode_data.get('duration', 0),   # LOCAL PATCH 2026-10-01: the results panel's bitrate
								'playcount': self.playcount, 'watch_count': self.watch_count, 'custom_season': self.custom_season, 'custom_episode': self.custom_episode})
				self.meta.update(metadata.episode_rating_fields(episode_data))   # LOCAL PATCH 2026-10-19: the OSD's episode rating
			except: pass
		self.meta.update({'media_type': self.media_type, 'background': self.background, 'custom_title': self.custom_title, 'custom_year': self.custom_year})

	def make_search_info(self):
		title, year, ep_name = self.get_search_title(), self.get_search_year(), self.get_ep_name()
		aliases = make_alias_dict(self.meta, title)
		expiry_times = get_cache_expiry(self.media_type, self.meta, self.season)
		self.search_info = {'media_type': self.media_type, 'title': title, 'year': year, 'tmdb_id': self.tmdb_id, 'imdb_id': self.meta.get('imdb_id'), 'aliases': aliases,
							'season': self.get_season(), 'episode': self.get_episode(), 'tvdb_id': self.meta.get('tvdb_id'), 'ep_name': ep_name, 'expiry_times': expiry_times,
							'total_seasons': self.meta.get('total_seasons', 1),
							'premiered': str(self.meta.get('premiered') or '')[:10] if self.media_type == 'episode' else '',   # LOCAL PATCH 2026-10-24: check_title(air_date=)
							'is_anime': self.is_anime, 'all_scrapers': self.all_scrapers_retry}   # LOCAL PATCH 2026-11-23: modules/provider_gate
		# LOCAL PATCH 2026-11-18: the absolute number and season counts, from TMDb's own pair (meta) even when an episode group's
		# number is searched -- the site scrapers' absolute-number rules (scrapers/_site_common.episode_pairs)
		if self.media_type == 'episode': self.search_info.update(episode_number_keys(self.meta, self.meta.get('season'), self.meta.get('episode')))
		# LOCAL PATCH 2026-11-03: a special is searched AND resolved under TVDB's / Stremio's number when TMDb's differs
		# (modules/cinemeta.special_episode): Steins;Gate 0's Valentine OVA is TMDb S0E1, every release names it S00E02.
		# One home: search_info feeds every scraper and the pack file pick in resolve_sources. meta['episode'] stays TMDb's
		# (Fribb / ani.zip lookups, watched status, progress). Not for a special Fribb's season-0 map places
		# (fribb_mappings._season0_rows): those are scraped as their own AniList / AniDB entries, and a bare S00Exx would
		# replace those candidates.
		# LOCAL PATCH 2026-11-04: TMDb's OWN pair (meta), never get_season()/get_episode(), which return a custom or
		# episode-group number (the 'Retry With Custom Episode Group' pass re-runs this). A custom / group number in effect
		# is an explicit choice: searched as given, not remapped; the ani.zip eid still applies (it names the episode).
		_fribb_special = False
		try: _tmdb_s, _tmdb_e = int(self.meta.get('season')), int(self.meta.get('episode'))
		except (TypeError, ValueError): _tmdb_s, _tmdb_e = None, None
		_custom = (self.search_info.get('season'), self.search_info.get('episode')) != (_tmdb_s, _tmdb_e)
		if self.media_type == 'episode' and _tmdb_s == 0 and _tmdb_e:
			try:
				from caches.fribb_mappings import find_cour_by_tmdb_coords
				_fribb_special = bool(find_cour_by_tmdb_coords(self.tmdb_id, 0, _tmdb_e, allow_repair=False))
			except Exception: pass
		# LOCAL PATCH 2026-11-06: a special Fribb's season-0 map places is still scraped as TMDb numbers it, but its TVDB /
		# Stremio pair joins the episode candidates (episode_card._candidates) so releases named by it are not dropped
		# (Dr. STONE 'RYUSUI' is TMDb S0E3, everyone else's S00E02). The searched number does not change.
		if self.media_type == 'episode' and _tmdb_s == 0 and _tmdb_e and _fribb_special and not _custom:
			try:
				from modules.episode_card import special_pair, special_tvdb_id   # 2026-11-07 (phase 1a): the pair lookups live there
				_alt = special_pair(self.meta.get('imdb_id'), self.search_info['premiered'], ep_name, special_tvdb_id(self.tmdb_id, _tmdb_e))
				if _alt and (int(_alt[0]), int(_alt[1])) != (0, _tmdb_e):
					self.search_info['special_alt_pair'] = (int(_alt[0]), int(_alt[1]))
					kodi_utils.logger('scrape.special', 'tmdb %s S0E%s %r: Fribb-mapped, scraped as TMDb numbers it; TVDB / Stremio S%sE%s '
						'joins the episode candidates' % (self.tmdb_id, _tmdb_e, ep_name, _alt[0], _alt[1]))
			except Exception as e: kodi_utils.logger('scrape.special', 'alt pair lookup failed: %s' % type(e).__name__)
		if self.media_type == 'episode' and _tmdb_s == 0 and _tmdb_e and not _fribb_special:
			try:
				from modules.episode_card import special_pair, special_tvdb_id   # 2026-11-07 (phase 1a): the pair lookups live there
				_tvdb_ep = special_tvdb_id(self.tmdb_id, _tmdb_e)
				# LOCAL PATCH 2026-11-04: an anime special's AniDB ids by the same TVDB id (caches.anizip_mappings.anizip_special_ids),
				# for animetosho's exact ?eid= query -- set even when the number needs no change. Its TVDB pair stands in when
				# Cinemeta has none; when both answer and differ, Cinemeta's (searched today, the providers' own numbering) is kept.
				_az = {}
				if _tvdb_ep:
					try:
						from modules.metadata import is_anime_check
						if is_anime_check(self.meta, self.tmdb_id):
							from caches.anizip_mappings import anizip_special_ids
							_az = anizip_special_ids(self.tmdb_id, _tvdb_ep) or {}
					except Exception as e: kodi_utils.logger('scrape.special', 'ani.zip lookup failed: %s' % type(e).__name__)
				_sp = special_pair(self.meta.get('imdb_id'), self.search_info['premiered'], ep_name, _tvdb_ep)
				_az_pair = (str(_az['season']), str(_az['episode'])) if _az.get('season') is not None and _az.get('episode') is not None else None
				if _az:
					# the pack query (anidb_aid) only for a special TVDB files as a REGULAR episode: those ship inside the season's
					# packs under that number (Tsubasa Cat (3) is 'Bakemonogatari - 13'). A season-0 OVA inside a pack is named by
					# no number the file pick can match ('Steins;Gate 0 - 24 (OVA)' for S00E02), so it gets the eid query only.
					_packs = bool(_az_pair) and _az_pair[0] != '0'
					self.search_info['special_anidb'] = (_az['aid'], _az['eid'], _packs)
					kodi_utils.logger('scrape.special', 'tmdb %s S0E%s %r: ani.zip AniDB %s eid %s (TVDB S%sE%s)%s' % (self.tmdb_id,
						_tmdb_e, ep_name, _az['aid'], _az['eid'], _az.get('season'), _az.get('episode'),
						'' if _packs else ', no pack query'))
				if not _sp and _az_pair: _sp = _az_pair
				elif _sp and _az_pair and _sp != _az_pair:
					kodi_utils.logger('scrape.special', 'tmdb %s S0E%s: Cinemeta says S%sE%s, ani.zip S%sE%s -- Cinemeta kept'
						% (self.tmdb_id, _tmdb_e, _sp[0], _sp[1], _az_pair[0], _az_pair[1]))
				if _sp and _custom:
					kodi_utils.logger('scrape.special', 'tmdb %s S0E%s: TVDB / Stremio S%sE%s not applied -- a custom / episode group number '
						'(S%sE%s) is in effect' % (self.tmdb_id, _tmdb_e, _sp[0], _sp[1], self.search_info.get('season'), self.search_info.get('episode')))
				elif _sp and _sp != ('0', str(_tmdb_e)):
					kodi_utils.logger('scrape.special', 'tmdb %s S0E%s %r is S%sE%s in TVDB / Stremio numbering -- searched as S%02dE%02d'
						% (self.tmdb_id, _tmdb_e, ep_name, _sp[0], _sp[1], int(_sp[0]), int(_sp[1])))
					# the TMDb pair rides along for the results cache key (scrapers/external.py), so a special searched as
					# S01E13 never shares a cache row with a TMDb S01E13
					self.search_info['special_tmdb'] = (0, _tmdb_e)
					self.search_info['season'], self.search_info['episode'] = int(_sp[0]), int(_sp[1])
					self.search_info['special_episode'] = (int(_sp[0]), int(_sp[1]))
			except Exception as e: kodi_utils.logger('scrape.special', 'lookup failed: %s' % type(e).__name__)
		# http_streams' _drop_other_episodes keeps a row named by any of these; only external.py's own data had them, so
		# an anime release named by cour / season numbering (Re:ZERO S01E27 as S02E02) lost its Direct Streams rows.
		if self.media_type == 'episode':
			try: self.search_info['episode_candidates'] = anime_episode_candidates(self.meta, self.tmdb_id, int(self.search_info['season']), int(self.search_info['episode']))
			except Exception: pass

	def _get_module(self, module_type, function):
		if module_type == 'external': module = function.source(*self.external_args)
		elif module_type == 'folders': module = function[0](*function[1])
		else: module = function()
		return module

	def _clear_properties(self):
		def_internal = self.default_internal_scrapers
		for item in def_internal: kodi_utils.clear_property('deadlight.internal_results.%s' % item)
		if self.active_folders:
			for item in self.folder_info: kodi_utils.clear_property('deadlight.internal_results.%s' % item[0])

	def _make_progress_dialog(self):
		from modules.kodi_utils import logger_debug as logger
		logger('DialogFlash _make_progress_dialog', 'creating new SourcesPlayback (background=%s, autoplay_nextep=%s)' % (self.background, getattr(self, 'autoplay_nextep', 'n/a')))
		try:
			self.progress_dialog = create_window(('windows.sources', 'SourcesPlayback'), 'sources_playback.xml', meta=self.meta)
			self.progress_thread = Thread(target=self.progress_dialog.run)
			self.progress_thread.start()
			# LOCAL PATCH 2026-09-27: a SmartPlay status set before this window existed (a background handoff)
			if getattr(self, 'smartplay_note', ''): self.progress_dialog.set_smartplay(self.smartplay_note)
		except Exception as e:
			kodi_utils.logger('SourcesPlayback init failed', str(e))
			self.progress_dialog, self.progress_thread = None, None
			try: kodi_utils.close_all_dialog()
			except: pass

	def _smartplay_status(self, text):
		"""LOCAL PATCH 2026-09-27: the SmartPlay line in the loading window. Kept on self so a window made later shows it."""
		self.smartplay_note = text
		try:
			if self.progress_dialog: self.progress_dialog.set_smartplay(text)
		except Exception: pass

	def _make_resolve_dialog(self):
		from modules.kodi_utils import logger_debug as logger
		logger('DialogFlash _make_resolve_dialog', 'resolve_dialog_made=%s progress_dialog=%s' % (self.resolve_dialog_made, self.progress_dialog is not None))
		self.resolve_dialog_made = True
		if not self.progress_dialog: self._make_progress_dialog()
		self.progress_dialog.enable_resolver()

	def _make_resume_dialog(self, percent):
		if not self.progress_dialog: self._make_progress_dialog()
		self.progress_dialog.enable_resume(percent)
		return self.progress_dialog.resume_choice

	def _make_nextep_dialog(self, default_action='cancel', choose=False):
		# LOCAL PATCH 2026-08-25: countdown_mode drives how NextEpisode counts down:
		#   'fixed'  -> HIGH confidence (IntroDB outro / chapter): count N seconds into the credits, then autoplay.
		#   'to_end' -> LOW confidence (percentage fallback): the alert point is arbitrary, so count the real remaining
		#               time and autoplay only at the true end (otherwise ~2 min of episode is cut at defaults).
		ns = getattr(self, 'nextep_settings', None)
		if not isinstance(ns, dict): ns = {}
		# LOCAL PATCH 2026-10-15: also to the real end when there is content after the outro (player.info_next_ep
		# 'content_after': a preview / post-credits scene is not credits).
		countdown_mode = 'to_end' if _counts_to_end(ns) else 'fixed'
		try:
			action = open_window(('windows.playback_notifications', 'NextEpisode'), 'playback_notifications.xml',
								meta=self.meta, default_action=default_action,
								countdown_mode=countdown_mode, total_time=ns.get('total_time'), choose=choose)
		except: action = 'cancel'
		return action

	def _make_still_watching_dialog(self, check_text):
		try: action = open_window(('windows.playback_notifications', 'StillWatching'), 'playback_notifications.xml', meta=self.meta, check_text=check_text)
		except: action = False   # LOCAL PATCH 2026-10-15: was 'no', which callers read as yes (StillWatching.onAction)
		return action

	def _kill_progress_dialog(self):
		from modules.kodi_utils import logger_debug as logger
		import traceback
		caller = traceback.extract_stack(limit=2)[-2]   # LOCAL PATCH 2026-10-25 (4.0.5): the caller only, not the whole stack
		logger('DialogFlash _kill_progress_dialog', 'called from %s:%d in %s' % (caller.filename.rsplit('\\', 1)[-1], caller.lineno, caller.name))
		success = 0
		try:
			self.progress_dialog.close()
			success += 1
		except: pass
		try:
			self.progress_thread.join()
			success += 1
		except: pass
		if success != 2:
			try: kodi_utils.close_all_dialog()
			except: pass
		self.progress_dialog, self.progress_thread = None, None

	def debridPacks(self, debrid_provider, name, magnet_url, info_hash, download=False):
		# LOCAL PATCH 2026-10-03: an uncached pack has no file list to browse yet. Its provider arrives as 'Uncached TorBox',
		# which the table below does not name (KeyError in Browse Pack).
		if str(debrid_provider or '').startswith('Uncached'):
			kodi_utils.notification('Pack not cached on %s yet' % str(debrid_provider).replace('Uncached', '', 1).strip())
			return None
		# LOCAL PATCH 2026-10-03: looked up before the busy dialog, so a name the table lacks cannot leave the spinner up
		debrid_info = {'Real-Debrid': 'rd_browse', 'Premiumize.me': 'pm_browse', 'AllDebrid': 'ad_browse', 'TorBox': 'tb_browse'}.get(debrid_provider)
		if not debrid_info: return kodi_utils.notification('No debrid service for this source')
		kodi_utils.show_busy_dialog()
		debrid_function = self.debrid_importer(debrid_info)
		try: debrid_files = debrid_function().display_magnet_pack(magnet_url, info_hash)
		except: debrid_files = None
		kodi_utils.hide_busy_dialog()
		if not debrid_files: return kodi_utils.notification('Error')
		debrid_files.sort(key=lambda k: k['filename'].lower())
		if download: return debrid_files, debrid_function
		list_items = [{'line1': '%.2f GB | %s' % (float(item['size'])/1073741824, clean_file_name(item['filename']).upper())} for item in debrid_files]
		kwargs = {'items': json.dumps(list_items), 'heading': name, 'enumerate': 'true', 'narrow_window': 'true'}
		chosen_result = kodi_utils.select_dialog(debrid_files, **kwargs)
		link = self.resolve_internal(debrid_info, chosen_result['link'], '') if chosen_result is not None else None
		# LOCAL PATCH 2026-11-18: TorBox's file link ('torrent_id,file_id') needs the torrent until requestdl has answered,
		# so display_magnet_pack keeps it; once the link is in hand (or the list was cancelled) it goes, as resolve_magnet
		# does, unless 'Store resolved to cloud' keeps it (a list of 2+ files counts as a pack for 'Show Packs Only')
		if debrid_info == 'tb_browse' and not (link and settings.store_resolved_to_cloud('TorBox', len(debrid_files) > 1)):
			Thread(target=debrid_function().delete_torrent, args=(debrid_files[0]['link'].split(',')[0],)).start()
		if chosen_result is None: return None
		self._kill_progress_dialog()
		return DeadLightPlayer().run(link, 'video', title=chosen_result['filename'].rsplit('.', 1)[0])

	def play_file(self, results, source={}):
		self.last_resolve_reason = None   # LOCAL PATCH 2026-10-15: per call (a sticky-pack fallback runs this twice)
		# LOCAL PATCH 2026-07-02: user_cancelled is set only on an active Back / cancel; cancel_all_playback also fires on
		# playback failure. The sticky fallback keeps the pin on the former and rescrapes (picker opens) on the latter.
		self.playback_successful, self.cancel_all_playback, self.user_cancelled = None, False, False
		retry_easynews = settings.easynews_playback_method('retry')
		retry_easynews_limit = settings.easynews_playback_method_retries()
		try:
			kodi_utils.hide_busy_dialog()
			url = None
			results = [i for i in results if not 'Uncached' in i.get('cache_provider', '')]
			if not source: source = results[0]
			items = [source]
			if not self.limit_resolve: 
				source_index = results.index(source)
				results.remove(source)
				items_prev = results[:source_index]
				items_prev.reverse()
				items_next = results[source_index:]
				items = items + items_next + items_prev
			processed_items = []
			processed_items_append = processed_items.append
			from windows.sources import resolve_tags_line, shown_size
			# LOCAL PATCH 2026-11-22: a Stremio slot's row is headed by that add-on's name, looked up once per slot
			from scrapers.stremio_addons import addon_name
			stremio_names = {slot: addon_name(slot) for slot in {item.get('stremio_slot') for item in items} if slot}
			for item in items:
				resolve_item = dict(item)
				provider = item['scrape_provider']
				if provider == 'external': provider = item['debrid'].replace('.me', '')
				elif provider == 'folders': provider = item['source']
				# LOCAL PATCH 2026-09-27: laid out like the episode block (SourcesPlayback.set_resolver_properties): one bold heading
				# with number, provider, quality and size; codec details and the release name (in its own case) in plain text.
				# LOCAL PATCH 2026-09-29: no '01 -' counter (the phase line says 'source n of N'). Tags in kind order
				# (windows.sources.resolve_tags_line); the release name darker than the box's FFB7B4BB text so it steps back.
				# LOCAL PATCH 2026-09-29: the service as it writes itself ('TorBox', 'Easynews', not 'TORBOX')
				heading_name = provider if item['scrape_provider'] in ('external', 'folders') else provider_panel_name(provider)
				heading_name = stremio_names.get(item.get('stremio_slot'), heading_name)
				heading = '%s  ·  %s  ·  %s' % (heading_name, item['quality'], shown_size(item['size_label']))
				display_name = item['display_name']
				extra_info = resolve_tags_line(item['extraInfo'], display_name)
				body = '%s[CR][COLOR FF85828A]%s[/COLOR]' % (extra_info, display_name) if extra_info else '[COLOR FF85828A]%s[/COLOR]' % display_name
				resolve_item['resolve_display'] = '[B]%s[/B][CR]%s' % (heading, body)
				resolve_item['resolve_parts'] = (heading, extra_info)
				processed_items_append(resolve_item)
				if provider == 'easynews' and retry_easynews:
					for retry in range(1, retry_easynews_limit):
						resolve_item = dict(item)
						resolve_item['resolve_display'] = '[B]%s  ·  Retry %s[/B][CR]%s' % (heading, retry, body)
						processed_items_append(resolve_item)
			items = list(processed_items)
			if not self.continue_resolve_check(): return self._kill_progress_dialog()
			self._handoff_mark('handler returned')
			kodi_utils.hide_busy_dialog()
			self.playback_percent = self.get_playback_percent()
			self._handoff_mark('resume point read')
			if self.playback_percent == None: return self._kill_progress_dialog()
			if not self.resolve_dialog_made: self._make_resolve_dialog()
			# LOCAL PATCH 2026-09-26: no fixed sleep for background plays (the hand-off replaces the playing file since
			# 2026-11-14 instead of stopping it).
			monitor = kodi_utils.kodi_monitor()
			from modules.kodi_utils import logger_debug as _dflogger   # LOCAL PATCH 2026-10-25 (4.0.5): DialogFlash traces at DEBUG
			_dflogger('DialogFlash play_file loop', 'items=%d background=%s autoplay=%s autoplay_nextep=%s' % (len(items), self.background, self.autoplay, getattr(self, 'autoplay_nextep', 'n/a')))
			for count, item in enumerate(items, 1):
				try:
					_dflogger('DialogFlash play_file iter %d' % count, 'name=%s' % (item.get('name', '')[:60]))
					kodi_utils.hide_busy_dialog()
					if not self.progress_dialog: break
					self.progress_dialog.reset_is_cancelled()
					# LOCAL PATCH 2026-09-27: ONE bar for the whole resolve: the debrid resolve fills its first half, Kodi opening the
					# stream its second (player.py maps its start-wait counter onto _bar_span); the heading says which source.
					# LOCAL PATCH 2026-10-25: each source gets the WHOLE bar (a fallback starts it over, amber, 'Source 2 of N'). Not
					# sliced by len(items): a pick from the results makes every result a fallback, the slice fell under the 1 % below
					# which the fill stays hidden, and the bar never moved.
					self._bar_span = (50.0, 100.0)
					# LOCAL PATCH 2026-09-29: amber (the bar's late colour) from the second source on -- a fallback is running
					_source_n = 'Source %d of %d' % (count, len(items))
					if count > 1: _source_n = '[COLOR FFE0AA46]%s[/COLOR]' % _source_n
					self.progress_dialog.update_resolver(text=item['resolve_display'], percent=0.0, detail=_source_n)
					self.progress_dialog.busy_spinner()
					if count > 1:
						kodi_utils.sleep(200)
						try: del player
						except: pass
					url, self.playback_successful, self.cancel_all_playback, self.user_cancelled = None, None, False, False
					self.playing_filename = item['name']
					self.playing_item = item
					player = DeadLightPlayer()
					try:
						if self.progress_dialog.iscanceled() or monitor.abortRequested(): break
						# LOCAL PATCH 2026-10-08: a pinned source checked before the handoff (_precheck_pinned) is already resolved
						kodi_utils.clear_property(RESOLVE_REASON_PROP)
						_pre = bool(item.get('_preresolved'))
						url = item.get('_preresolved') or self.resolve_sources(item)
						self._handoff_mark('url ready (%s)' % ('pre-checked' if _pre else 'resolved now'))
						self.playing_url = url   # LOCAL PATCH 2026-11-01: _sticky_save keeps it for the next pinned play
						if url:
							self.last_resolve_reason = None   # a reason belongs to the source that failed, not a later one
							resolve_percent = self._bar_span[0]   # LOCAL PATCH 2026-09-27: the link is resolved -- half this slice
							self.progress_dialog.busy_spinner('false')
							self.progress_dialog.update_resolver(text=self._pack_file_display(item), percent=resolve_percent,
								detail='%s  ·  Starting playback' % _source_n)
							kodi_utils.sleep(50)   # one GUI tick for the update above
							# LOCAL PATCH 2026-11-17: a link that needs no resolving (Direct Streams: one alive check) reached play while
							# the results window was still fading out (its 220 ms WindowClose), and that half-faded window stayed over
							# the Resolving window -- a dark tint -- until the video opened (screenshot 502, PixelDrain, log 17:52:32
							# 'topmost modal dialog closing animation is running'). Window.IsVisible counts a closing dialog; capped.
							for _wait in range(10):
								if not kodi_utils.get_visibility('Window.IsVisible(sources_results.xml)'): break
								kodi_utils.sleep(50)
							player.run(url, self)
						else:
							# LOCAL PATCH 2026-10-15: say why this source failed, on the window, before trying the next. The debrid
							# resolvers' reasons ('no file for this episode', 'not cached on RD') reached only the log.
							self.last_resolve_reason = kodi_utils.get_property(RESOLVE_REASON_PROP) or None
							if self.last_resolve_reason:
								try:
									self.progress_dialog.update_resolver(percent=self._bar_span[0], detail='%s%s' % (self.last_resolve_reason,
										'  ·  trying the next source' if count < len(items) else ''))
									kodi_utils.sleep(900)   # long enough to read
								except Exception: pass
							continue
						if self.cancel_all_playback: break
						if self.playback_successful: break
						if count == len(items):
							self.cancel_all_playback = True
							mark_internal_stop()   # LOCAL PATCH 2026-08-26: our stop, not the user's
							player.stop()
							break
					except: pass
				except: pass
		except: self._kill_progress_dialog()
		if self.cancel_all_playback: return self._kill_progress_dialog()
		if not self.playback_successful or not url: self.playback_failed_action()
		try: del monitor
		except: pass

	def get_playback_percent(self):
		if self.media_type == 'movie': percent = watched_status.get_progress_status_movie(watched_status.get_bookmarks_movie(), str(self.tmdb_id))
		elif any((self.random, self.random_continual)): return 0.0
		else: percent = watched_status.get_progress_status_episode(watched_status.get_bookmarks_episode(self.tmdb_id, self.season), self.episode)
		if not percent: return 0.0
		action = self.get_resume_status(percent)
		if action == 'cancel': return None
		if action == 'start_over':
			watched_status.erase_bookmark(self.media_type, self.tmdb_id, self.season, self.episode)
			return 0.0
		return float(percent)

	def get_resume_status(self, percent):
		if settings.auto_resume(self.media_type, self.autoplay): return float(percent)
		return self._make_resume_dialog(percent)

	def playback_failed_action(self):
		self._kill_progress_dialog()
		# LOCAL PATCH 2026-10-15: a failed play said nothing when no source resolved -- the window just closed. Not when a
		# full search follows (below), which keeps going.
		# Only with a resolver's reason: a play error already has the player's own 'Playback Failed' (player.run_error).
		_why = getattr(self, 'last_resolve_reason', None)
		if _why and not (self.prescrape and self.autoplay): kodi_utils.notification('Playback failed - %s' % _why, 6000)
		if self.prescrape and self.autoplay:
			self.resolve_dialog_made, self.prescrape, self.prescrape_sources = False, False, []
			self.get_sources()

	def still_watching_check(self):
		watching_check = self.nextep_settings['watching_check']
		if watching_check == 0: return True
		player = kodi_utils.kodi_player()
		# LOCAL PATCH 2026-10-15: nothing playing is not a 'no' -- the episode may have ended before the scrape came back
		# (outro auto-skip, a slow scrape), the case autoplay_nextep_handler, this function's only caller, keeps the alert
		# for; that handler tells a Stop from a natural end itself. StillWatching cannot be shown without playback (its
		# countdown runs while the player plays), so the count waits for the next handoff.
		if not player.isPlayingVideo(): return True
		watch_count = self.meta.get('watch_count')
		if watch_count == watching_check: still_watching, watch_count = self._make_still_watching_dialog('Are you still watching [B]%s[/B]?'), 0
		else: still_watching = True
		watch_count += 1
		self.meta['watch_count'] = watch_count
		return still_watching

	def continue_resolve_check(self):
		try:
			if not self.background or self.autoscrape_nextep: return True
			# LOCAL PATCH 2026-09-03: a source picked out of the picker is already the user's answer to 'play the next
			# episode?', so no countdown afterwards. The alert is for the AUTOMATIC handoff, where nothing has been chosen.
			if getattr(self, 'chosen_by_user', False):
				kodi_utils.logger('autoplay_nextep_handler', 'skipped: source was chosen from the picker')
				return True
			# LOCAL PATCH 2026-10-08: asked once per handoff. A failed sticky pack-play falls back to a scrape on this same
			# object; asked again, the handler read the dead stream's stop as the user's and refused the fallback.
			if getattr(self, 'nextep_answered', False):
				kodi_utils.logger('autoplay_nextep_handler', 'skipped: next episode already confirmed this handoff')
				return True
			if self.autoplay_nextep: return self.autoplay_nextep_handler()
			return self.random_continual_handler()
		except: return False

	def _notify_next_up(self):
		kodi_utils.notification('[B]Next Up:[/B] %s S%02dE%02d' % (self.meta.get('title'), self.meta.get('season'), self.meta.get('episode')),
								6500, self.meta.get('poster'))

	def random_continual_handler(self):
		self._notify_next_up()
		player = kodi_utils.kodi_player()
		while player.isPlayingVideo(): kodi_utils.sleep(100)
		self._make_resolve_dialog()
		return True

	def _handoff_mark(self, label):
		"""DIAG 2026-11-14: where the next-episode switch spends its time -- ms since the handler stopped the episode, and whether
		Kodi still reports the old file playing. Only with DIAG_TIMING (settings.diag_timing) and only after a hand-off."""
		t0 = getattr(self, '_handoff_t0', None)
		if t0 is None or not settings.diag_timing(): return
		try: playing = kodi_utils.kodi_player().isPlaying()
		except Exception: playing = '?'
		kodi_utils.logger('handoff.timing', '%s: +%dms (kodi playing=%s)' % (label, int((time.perf_counter() - t0) * 1000), playing))

	def autoplay_nextep_handler(self):
		from modules.kodi_utils import logger as _dflogger
		if not self.nextep_settings:
			_dflogger('autoplay_nextep_handler', 'no nextep_settings — aborting')
			return False
		if not self.still_watching_check():
			kodi_utils.notification('Cancel Autoplay', icon=self.meta.get('poster'))
			return False
		player = kodi_utils.kodi_player()
		window_time, default_action = self.nextep_settings['window_time'], self.nextep_settings['default_action']
		# LOCAL PATCH 2026-11-16: the card only for Next Episode > At the Credits = Show Countdown. Play Next Immediately: at
		# credits that run to the end of the file (player.info_next_ep credits_skip) the next episode plays now; anywhere else
		# (credits unknown, a preview after them) it plays when this one ends ('close'), with no card.
		use_window = self.nextep_settings.get('credits_mode') == 'countdown'
		credits_skip = bool(self.nextep_settings.get('credits_skip'))
		playing_at_entry = player.isPlayingVideo()
		_dflogger('autoplay_nextep_handler', 'entry playing=%s use_window=%s window_time=%s default_action=%s' % (playing_at_entry, use_window, window_time, default_action))
		# LOCAL PATCH 2026-07-22: open the dialog even when the previous episode already ended (outro auto-skip + slow
		# scrape race); only wait for the timing window if the video IS still playing.
		action = None if use_window else ('play' if credits_skip else 'close')
		continue_nextep = False
		last_remaining = None   # DIAG/fallback 2026-08-25: position at last sample
		if playing_at_entry:
			try: total_time = player.getTotalTime()
			except: total_time = 0
			while player.isPlayingVideo():
				try:
					remaining_time = round(total_time - player.getTime())
					last_remaining = remaining_time
					if remaining_time <= window_time:
						continue_nextep = True
						break
					kodi_utils.sleep(1000)
				except: pass
		# If the wait loop exits because playback ended (or never ran), still show the dialog -- the intent was
		# autoplay-with-alert. Only suppress on explicit cancel.
		# LOCAL PATCH 2026-08-21: a plain Stop is ALSO an explicit cancel, though it sets neither cancel_all_playback nor
		# user_cancelled. DeadLightPlayer's onPlayBackStopped/onPlayBackEnded record the verdict in a window property (not
		# an instance flag: this runs on a fresh Sources() from episode_tools.auto_nextep).
		if not continue_nextep:
			# Exiting the wait loop WITHOUT reaching the alert window means playback was cut short (the user's Stop): a natural
			# end drops remaining_time below window_time and breaks with continue_nextep=True first. This position test is
			# primary because onPlayBackStopped arrives ~2.5 s after isPlayingVideo() flips, after this gate has decided.
			ended_before_window = last_remaining is not None and last_remaining > window_time
			# LOCAL PATCH 2026-09-24: playback already over when we got here, so ask the player where it last saw it. Kodi
			# reports a stream that DIES as a natural end (onPlayBackEnded), so the stop verdict never fires for it; an episode
			# that really reached its end (including the outro-skip / slow-scrape race) was last seen within seconds of it.
			if last_remaining is None:
				try: _player_last = float(kodi_utils.get_property(PLAYBACK_LAST_REMAINING_PROP) or '')
				except (TypeError, ValueError): _player_last = None
				if _player_last is not None and _player_last > NEXTEP_END_TOLERANCE:
					ended_before_window = True
					last_remaining = _player_last
			user_stopped = kodi_utils.get_property(PLAYBACK_STOPPED_PROP) == 'true'
			if not user_stopped and not ended_before_window:
				# Inconclusive — give the late callback a brief chance before allowing.
				kodi_utils.sleep(600)
				user_stopped = kodi_utils.get_property(PLAYBACK_STOPPED_PROP) == 'true'
			if user_stopped or ended_before_window or getattr(self, 'cancel_all_playback', False) or getattr(self, 'user_cancelled', False):
				_dflogger('autoplay_nextep_handler', 'suppressing dialog — user_stopped=%s ended_before_window=%s (last_remaining=%s window_time=%s)'
					% (user_stopped, ended_before_window, last_remaining, window_time))
				# LOCAL PATCH 2026-11-16: as the dialog's cancel below -- without user_cancelled, SmartPlay's sticky path read the
				# 'not played' as a failed play_file and fell back to a full scrape, opening the next episode's source list after
				# the user's Stop (Dead-End Job S01E03, 2026-11-16 14:00)
				self.cancel_all_playback, self.user_cancelled = True, True
			else:
				# last_remaining is None => playback was already over when we got here
				# (outro auto-skip + slow scrape race, the 2026-07-22 case). Alert is wanted.
				continue_nextep = True
		# LOCAL PATCH 2026-11-14: Play Next Now + chapter timing: Kodi names only the chapter that is PLAYING, so a credits
		# chapter is recognised only now, at the alert point (the hand-off started scraper_time earlier, before it played).
		# Named like credits ('Credits', 'Ending', 'ED' -- player._CHAPTER_SEGMENT_RES) -> the next episode, no countdown.
		# An unnamed last chapter waits for the end: it may be story. (2026-11-16: Next Episode > At the Credits, as credits_skip.)
		if continue_nextep and not credits_skip and self.nextep_settings.get('credits_mode') == 'play' and player.isPlayingVideo() \
				and (self.nextep_settings.get('transition_source') or '') in ('chapter', 'chapter_credits') \
				and not self.nextep_settings.get('content_after'):
			try:
				from modules.player import _CHAPTER_SEGMENT_RES
				_ch = (kodi_utils.get_infolabel('Player.ChapterName') or '').strip()
				if _ch and any(t == 'outro' and rx.match(_ch) for t, rx in _CHAPTER_SEGMENT_RES):
					credits_skip, action = True, 'play'
					_dflogger('autoplay_nextep_handler', 'credits chapter %r playing, outro skip auto -> next episode, no countdown' % _ch)
			except Exception: pass
		# LOCAL PATCH 2026-11-26 (user): Play Next Immediately with NO credits data -- the percentage point, or a last chapter not
		# named like credits ('Szene 29': Dupahiya S02E06, 2026-11-26) -- shows the card counting the time left to the real end
		# (low confidence -> _counts_to_end), instead of waiting silently for the end. Ignored, it plays the next episode at the
		# end, as before. Known credits (credits_skip) and a preview after the outro (content_after) keep their paths.
		if continue_nextep and not use_window and not credits_skip and not self.nextep_settings.get('content_after') \
				and self.nextep_settings.get('credits_mode') == 'play' and player.isPlayingVideo():
			use_window = True
			self.nextep_settings['timing_confidence'] = 'low'
			_dflogger('autoplay_nextep_handler', 'no credits data (source=%s): card counting to the end' % self.nextep_settings.get('transition_source'))
		_dflogger('autoplay_nextep_handler', 'pre-dialog continue_nextep=%s cancel_all=%s user_cancelled=%s' % (continue_nextep, getattr(self, 'cancel_all_playback', False), getattr(self, 'user_cancelled', False)))
		if continue_nextep:
			if use_window:
				_dflogger('autoplay_nextep_handler', 'opening NextEpisode dialog default_action=%s' % default_action)
				action = self._make_nextep_dialog(default_action=default_action)
				_dflogger('autoplay_nextep_handler', 'dialog returned action=%r' % action)
			if not action: action = default_action
			_dflogger('autoplay_nextep_handler', 'final action=%r' % action)
			if action == 'cancel':
				# The card dismissed (Back): keep watching, nothing after this episode.
				# user_cancelled tells the sticky paths this was the user (without it a sticky play reads play_file's
				# failure and falls back to a full scrape -- re-firing the popup at episode end).
				self.cancel_all_playback, self.user_cancelled = True, True
				return False
			elif action == 'stop':
				# LOCAL PATCH 2026-11-16: Stop (the card's button, or If No Answer = Stop) stops the player now, nothing after
				self.cancel_all_playback, self.user_cancelled = True, True
				mark_internal_stop()   # LOCAL PATCH 2026-08-26: our stop, not the user's
				try: player.stop()
				except: pass
				return False
			elif action == 'play':
				self._make_resolve_dialog()
				# LOCAL PATCH 2026-08-26: this stop is OURS (handing off to the next episode). Unmarked, onPlayBackStopped records a
				# user stop, and the next episode's handler reads that stale verdict and suppresses itself -- also blocking
				# SmartPlay's fallback scrape.
				mark_internal_stop()
				self._handoff_t0 = time.perf_counter()   # DIAG 2026-11-14: handoff.timing (_handoff_mark)
				# LOCAL PATCH 2026-11-14: while the episode still plays, do NOT stop it -- the next episode's play() replaces the
				# file, so Kodi stays in the video window instead of closing to Home first (a stop -> Home -> widgets rebuilt ->
				# open cost ~1.8 s before the next file opened, 2026-11-14 18:47). DeadLightPlayer._playback_confirmed does not
				# take the old file, still playing meanwhile, for the new one (replaced_file). Nothing playing: stop as before.
				self.replaced_file = None
				try:
					if player.isPlayingVideo(): self.replaced_file = player.getPlayingFile() or None
				except Exception: self.replaced_file = None
				if not self.replaced_file:
					try: player.stop()
					except: pass
				self._handoff_mark('stop sent' if not self.replaced_file else 'no stop: the next file will replace the playing one')
				self.nextep_answered = True   # LOCAL PATCH 2026-10-08: see continue_resolve_check
				return True
			else:
				while player.isPlayingVideo(): kodi_utils.sleep(100)
				self._make_resolve_dialog()
				self.nextep_answered = True
				return True
		else: return False

	def autoscrape_nextep_handler(self):
		if settings.autoscrape_confirm():
			if not self._make_still_watching_dialog('Autoscrape Next Episode of [B]%s[/B]?'): return kodi_utils.notification('Cancel Autoscrape', icon=self.meta.get('poster'))
		player = kodi_utils.kodi_player()
		if player.isPlayingVideo():
			results = self.get_sources()
			if not results: return kodi_utils.notification(33092, 3000)
			else:
				kodi_utils.notification('[B]Next Episode Ready:[/B] %s S%02dE%02d' \
						% (self.meta.get('title'), self.meta.get('season'), self.meta.get('episode')), 6500, self.meta.get('poster'))
				# LOCAL PATCH 2026-11-14: outro skip on Auto with credits to the end (player.info_next_ep credits_skip): stop at the
				# credits and open the list -- the skipper does not run while this waits, so the credits used to play out
				_ns = self.nextep_settings if isinstance(getattr(self, 'nextep_settings', None), dict) else {}
				_skip_at = _ns.get('window_time') if _ns.get('credits_skip') else None
				while player.isPlayingVideo():
					if _skip_at is not None:
						try:
							if player.getTotalTime() - player.getTime() <= _skip_at:
								mark_internal_stop()
								player.stop()
								break
						except Exception: pass
					kodi_utils.sleep(100)
			self.display_results(results)
		else: return

	def debrid_importer(self, debrid_provider):
		return manual_function_import(*self.debrids[debrid_provider])

	def _pack_file_display(self, item):
		"""LOCAL PATCH 2026-09-29: a pack's release name says nothing about which episode plays. Once resolve_cached has
		picked the file (source_utils.pick_episode_files publishes it as deadlight.playing.pack_file, cleared at every
		resolve), the block shows that file in the release name's place -- same line count, so the 145 px box still
		fits. '' (text unchanged) for a non-pack, or when the file is only the release name again."""
		try:
			if 'package' not in item: return ''
			picked = (kodi_utils.get_property('deadlight.playing.pack_file') or '').strip()
			picked = picked.replace(chr(92), '/').rsplit('/', 1)[-1]
			if not picked or picked.rsplit('.', 1)[0].lower() == (item.get('name') or '').lower(): return ''
			heading, extra_info = item['resolve_parts']
			file_line = '[COLOR FF6E6E6E]File[/COLOR]  [COLOR FF85828A]%s[/COLOR]' % picked
			return '[B]%s[/B][CR]%s' % (heading, '%s[CR]%s' % (extra_info, file_line) if extra_info else file_line)
		except Exception: return ''

	def resolve_sources(self, item, meta=None):
		if meta: self.meta = meta
		url = None
		try:
			if 'cache_provider' in item:
				cache_provider = item['cache_provider']
				if self.meta['media_type'] == 'episode':
					if hasattr(self, 'search_info'):
						title, season, episode, pack = self.search_info['title'], self.search_info['season'], self.search_info['episode'], 'package' in item
					else: title, season, episode, pack = self.get_ep_name(), self.get_season(), self.get_episode(), 'package' in item
				else: title, season, episode, pack = self.get_search_title(), None, None, False
				# LOCAL PATCH 2026-08-27: anime files inside a pack are not numbered as TMDb numbers them, so the debrid layer needs
				# the alternatives to find the right file. Empty for everything that is not anime.
				# LOCAL PATCH 2026-09-22: the RAW TMDb pair, matching scrapers/external.py. season/episode above come from
				# get_season()/get_episode() (an episode group's rewrite), but anime_episode_candidates reads TMDb numbering, and a
				# group pair yields numbers no file carries. season/episode themselves pass on unchanged -- only the candidates move.
				_raw_s = self.meta.get('season', season)
				_raw_e = self.meta.get('episode', episode)
				ep_candidates = anime_episode_candidates(self.meta, self.meta.get('tmdb_id'), _raw_s, _raw_e) if season is not None else []
				# LOCAL PATCH 2026-11-03: a special searched under TVDB's number is picked out of a pack by that number only
				# (make_search_info) -- TMDb's raw (0, 1) is Steins;Gate 0's prologue file, not the OVA the row was found for
				_special = getattr(self, 'search_info', {}).get('special_episode')
				if _special and season is not None: ep_candidates = [tuple(int(x) for x in _special)]
				if cache_provider in _DEBRID_CACHE_PROVIDERS:
					url = self.resolve_cached(cache_provider, item['url'], item['hash'], title, season, episode, pack, ep_candidates)
				# LOCAL PATCH 2026-10-11: the same torrent on the other debrid(s) it is cached on (collapse_debrid_twins), before
				# the play loop moves on to another release. The row then names the debrid that played it.
				for fallback in ([] if url else item.get('debrid_fallbacks') or []):
					if fallback not in _DEBRID_CACHE_PROVIDERS: continue
					kodi_utils.logger('debrid twins', '%s failed on %s -- trying %s' % (item.get('hash'), cache_provider, fallback))
					url = self.resolve_cached(fallback, item['url'], item['hash'], title, season, episode, pack, ep_candidates)
					if url:
						item['cache_provider'], item['debrid'] = fallback, fallback
						break
			# LOCAL PATCH 2026-11-18: a Direct Streams row whose link is a HubCloud page (AnimeDubHindi): its file link is signed
			# and expires, so it is fetched now (scrapers/hubcloud)
			elif item.get('resolver') == 'hubcloud':
				publish_pack_file('')
				from scrapers.hubcloud import resolve as resolve_hubcloud
				url = resolve_hubcloud(item['url_dl'])
			elif item.get('url_fallbacks') and item.get('scrape_provider') == 'http_streams':
				url = self._resolve_direct_fallbacks(item)
			elif item.get('scrape_provider', None) in self.default_internal_scrapers:
				url = self.resolve_internal(item['scrape_provider'], item['id'], item['url_dl'], item.get('direct_debrid_link', False))
			else: url = item['url']
		except: pass
		return url

	def _resolve_direct_fallbacks(self, item):
		"""LOCAL PATCH 2026-10-24: a Direct Streams release on several hosts (scrapers/http_streams._merge_host_copies): the
		first that answers, in the merged row's order (FSL, FSLv2, PixelDrain, then other hosts). None answering, the row's own link as before -- so
		a check that cannot reach the host never makes a playable link worse than it was."""
		publish_pack_file('')
		from scrapers.http_streams import source as http_streams
		links = [item['url_dl']] + [u for u in item.get('url_fallbacks') or [] if u]
		for n, link in enumerate(links):
			if http_streams.direct_url_alive(link):
				item['_alive_checked'] = link   # LOCAL PATCH 2026-11-04: _precheck_pinned does not ask this link a second time
				if n:
					kodi_utils.logger('direct hosts', '%s: %d of %d hosts did not answer -- playing host %d' % (item.get('name'), n, len(links), n + 1))
					item['url_dl'] = link
				return link
		kodi_utils.logger('direct hosts', '%s: none of %d hosts answered the check -- trying the first anyway' % (item.get('name'), len(links)))
		return item['url_dl']

	def resolve_cached(self, debrid_provider, item_url, _hash, title, season, episode, pack, ep_candidates=None):
		# LOCAL PATCH 2026-08-31: cleared at both resolution entry points so a pack file
		# recorded by a previous playback cannot leak into this one.
		publish_pack_file('')
		debrid_function = self.debrid_importer(debrid_provider)
		store_to_cloud = settings.store_resolved_to_cloud(debrid_provider, pack)
		# LOCAL PATCH 2026-11-07 (Red Light 3.0.1 port): the episode's title, so its words are not read as a bonus file's
		# (source_utils.extras / pick_episode_file: 'Show.S02E05.Inside.Job.mkv' resolved to no file)
		ep_name = None
		if season:
			try: ep_name = self.get_ep_name()
			except Exception: ep_name = None
		try: url = debrid_function().resolve_magnet(item_url, _hash, store_to_cloud, title, season, episode, ep_candidates, ep_name=ep_name)
		except: url = None
		return url

	def resolve_internal(self, scrape_provider, item_id, url_dl, direct_debrid_link=False):
		publish_pack_file('')
		url = None
		try:
			if direct_debrid_link or scrape_provider == 'folders': url = url_dl
			elif scrape_provider == 'easynews':
				from indexers.easynews import resolve_easynews
				url = resolve_easynews({'url_dl': url_dl, 'play': 'false'})
			else:
				debrid_function = self.debrid_importer(scrape_provider)
				if any(i in scrape_provider for i in ('rd_', 'ad_', 'tb_')):
					debrid = debrid_function()
					url = debrid.unrestrict_link(item_id)
					# 2026-11-18: the service's refusal was kept (TorBox's last_dl_error) but never shown; player.run's
					# 'Playback failed' then had no reason in the log
					if not url: kodi_utils.logger('resolve_internal', '%s gave no link: %s' % (scrape_provider, getattr(debrid, 'last_dl_error', None) or 'empty answer'))
				else:
					if '_cloud' in scrape_provider: item_id = debrid_function().get_item_details(item_id)['link']
					url = debrid_function().add_headers_to_url(item_id)
		except: pass
		return url

