# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-11-14: open 4 connections to api.torbox.app at the top of Sources.playback_prep, one per TorBox check
request debrid.TB_check sends side by side. Each scrape is a fresh interpreter, so the check's requests otherwise each paid
DNS + TCP + TLS (~175 ms, measured 2026-11-14) -- and the last batch (the slowest provider's hashes) is the tail the
results window waits for.

Measured in Kodi on 2026-11-14 (60 scrapes, 5 titles, variants alternated): this alone gave the best medians -- TOTAL
3125 -> 2787 ms, TorBox tail 705 -> 498 ms. Also tried and NOT kept: importing the providers in the background and
pre-connecting to the providers' hosts. In Kodi both compete with the main thread for the GIL (the progress window opened up
to 400 ms later) and the providers had opened their own connections before the warm ones were ready.
Nothing here changes what is checked: a connection that is not ready just means the request opens its own. Never raises."""
import threading

_TB_CONNECTIONS = 4   # debrid.TB_check: up to 4 requests side by side

def start():
	t = threading.Thread(target=_run, name='scrape_warm', daemon=True)
	t.start()
	return t

def _run():
	try:
		from caches.settings_cache import get_setting
		if get_setting('deadlight.provider.external', 'false') != 'true': return
		from modules.debrid import debrid_enabled
		if 'TorBox' not in debrid_enabled(): return
		threads = [threading.Thread(target=_torbox, daemon=True) for _ in range(_TB_CONNECTIONS)]
		[t.start() for t in threads]
	except Exception: pass

def _torbox():
	try:
		from apis.torbox_api import session
		# LOCAL PATCH 2026-11-25: a URL INSIDE the session's mounted prefix (torbox_api: 'https://api.torbox.app/v1/api/'). The
		# site root fell through to requests' default adapter: each of the 4 connections built its own SSL context and loaded the
		# whole CA bundle (~0.6 s CPU each on the PC, during the providers' parsing), into a pool the TorBox check never uses.
		session.head('https://api.torbox.app/v1/api/', timeout=4, allow_redirects=False).close()
	except Exception: pass
