"""
	Fenomscrapers Module
"""

import functools
import html
import re
import unicodedata


def _fold(text):
	"""LOCAL PATCH 2026-10-21 (with POV 6.10.17's NFKD release names, source_utils.strip_non_ascii_and_unprintable): letters
	reduced to their base form -- 'Amélie' -> 'Amelie', fullwidth 'ＳＰＹ' -> 'SPY' -- so a searched title matches release
	names, which are folded the same way. Other scripts are kept as they were (only combining marks go)."""
	return ''.join(c for c in unicodedata.normalize('NFKD', text) if not unicodedata.combining(c))

def get(title):
	"""LOCAL PATCH 2026-11-22: cached per title (_get_cached) -- a scrape asks for the same names over and over: 126,473 calls for
	~13,500 comet rows (about 9 per row, each folding accents character by character), 7.5 s of a profiled anime run. Pure:
	a string in, a new string out. An unhashable argument still goes through _get uncached."""
	try: return _get_cached(title)
	except TypeError: return _get(title)


@functools.lru_cache(maxsize=8192)
def _get_cached(title):
	return _get(title)


def _get(title):
	try:
		if not title: return
		title = _fold(html.unescape(title))   # LOCAL PATCH 2026-10-21: named entities too ('&eacute;', '&#39;'), then folded
		title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title) # fix html codes with missing semicolon between groups
		title = re.sub(r'&#(\d+);', '', title).lower()
		title = title.replace('&quot;', '\"').replace('&amp;', '&').replace('&nbsp;', '')
		title = re.sub(r'\([^\d]*(\d+)[^\d]*\)', '', title) #eliminate all numbers between ()
		title = re.sub(r'[<\[{].*?[}\]>]|[^\w0-9]|[_]', '', title)
		return title
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return title

# LOCAL PATCH 2026-11-01 (cleanup): get_simple removed (no callers).


def normalize(title):
	try:
		import unicodedata
		title = ''.join(c for c in unicodedata.normalize('NFKD', title) if unicodedata.category(c) != 'Mn')
		return str(title)
	except:
		from magneto.modules import log_utils
		log_utils.error()
		return title
