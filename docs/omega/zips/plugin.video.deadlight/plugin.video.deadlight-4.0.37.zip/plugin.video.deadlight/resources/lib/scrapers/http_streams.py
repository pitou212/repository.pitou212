# -*- coding: utf-8 -*-
# LOCAL PATCH (2026-06-12, providers reworked 2026-11-22): the runner behind 'HTTP Scrapers' and the 'Stremio Add-ons' slots.
#   - site scrapers  scrapers/site_scrapers.SITES (HDHub4u, 4KHDHub, MoviesDrive, AnimeDubHindi, Cinejoy), each a setting under
#                    the provider.http_streams master switch
#   - Stremio slots  up to three Stremio stream add-on manifests (scrapers/stremio_addons), each switched on by itself -- they
#                    run even with HTTP Scrapers off (settings.active_internal_scrapers)
# The site scrapers hand back rows in the Stremio shape; HubCloud pages are resolved at play time (scrapers/hubcloud).
# This wrapper does the DeadLight glue:
#   - reads info dict, applies per-provider settings gates
#   - calls into core functions in parallel
#   - converts core's stream dicts to DeadLight's source dict format
#   - external_cache (SQLite) for repeat scrapes
#   - URL hash dedup
import hashlib
import re
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
from caches.settings_cache import get_setting
from modules import source_utils
from modules.settings import filter_by_name
from modules.kodi_utils import make_session
from scrapers import stremio_addons
from scrapers.site_scrapers import SITES

# LOCAL PATCH 2026-08-29: pooled session for the validation probes, as in aiostreams.py -- ~25 probes over a handful
# of hosts; a bare requests.head pays a TCP+TLS handshake each (~25 s vs ~11 s pooled).
_session = make_session('https://')


def _results_cache_key(sites, addons):
	"""Separate cached results when enabled sources or Stremio manifests change."""
	values = '\0'.join(['http_and_stremio_v1', get_setting('deadlight.http_streams.title_filter', 'false')]
					  + [key for key, _label, _module, _picker in sites]
					  + ['stremio%d=%s' % (slot, url) for slot, url in addons])
	return 'http_streams_%s' % hashlib.sha1(values.encode('utf-8')).hexdigest()[:12]


class _ProviderCache:
	"""LOCAL PATCH 2026-11-22: one provider's raw rows for one title / episode, in external_cache's results table (so 'Rescrape'
	and Clean Databases clear them with the rest). Keyed by what the provider asks -- a site scraper's module + IMDb id, a
	Stremio slot's manifest URL + id + episode pair -- so switching one provider on or off keeps the others' answers. Raw rows,
	before _make_item: the display and filter code runs on every read, as on a fresh scrape. Lifetimes as the combined cache:
	30 min with rows (HDHub-style ?token= links last ~1 h), 1 h for an empty answer; a failed provider is never kept."""
	_VERSION = 'v1'

	def __init__(self, media_type, tmdb_id, title, year, season, episode):
		from caches.external_cache import external_cache
		from os import urandom
		self._cache, self._where = external_cache, (media_type, tmdb_id, title, year, season, episode)
		self._token = urandom(6).hex()   # this run's mark (shared); not id(self): every add-on interpreter lives in Kodi's one process

	def _name(self, identity):
		return 'http_provider_%s' % hashlib.sha1(('%s\0%s' % (self._VERSION, identity)).encode('utf-8')).hexdigest()[:16]

	def get(self, identity):
		rows = self._cache.get(self._name(identity), *self._where)
		return rows if isinstance(rows, list) else None

	def set(self, identity, rows):
		self._cache.set(self._name(identity), *self._where, rows, 0.5 if rows else 1)

	# LOCAL PATCH 2026-11-22: a provider asked by one DeadLight process is not asked again by another for the same episode while
	# that answer is on its way. The asker marks it in a Home property ('<start time>|<run token>'; every process sees them)
	# and keeps the answer the moment it arrives, BEFORE clearing the mark, so a waiter finds it. No atomic lock exists across
	# processes: two that check at the same instant both ask, as before this. A mark older than _RUNNING_MAX is a run that
	# died. A failed answer is not kept: the waiter then asks itself.
	_RUNNING_MAX = 30   # seconds; a provider's own timeouts are 10-12 s
	# LOCAL PATCH 2026-11-22: and a waiter waits at most _WAIT_MAX, then asks itself -- waiting must never cost more than asking.
	# Log 22:18 (DNS failing for every host right after a Kodi restart): runs stuck on their requests kept their marks fresh,
	# and later scrapes of the same episode waited 21-46 s behind them (one second pass took 27.8 s to its results).
	_WAIT_MAX = 8       # seconds; HDHub4u, the slowest site, answers in 3-6 s
	_POLL = 0.2

	def _mark(self, identity):
		where = '\0'.join(str(x) for x in self._where)
		return 'deadlight.http_running.%s' % hashlib.sha1(('%s\0%s' % (self._name(identity), where)).encode('utf-8')).hexdigest()[:20]

	def _running_elsewhere(self, identity):
		from modules.kodi_utils import get_property
		try: started, token = (get_property(self._mark(identity)) or '').split('|', 1)
		except ValueError: return False
		try: age = time.time() - float(started)
		except ValueError: return False
		return token != self._token and 0 <= age < self._RUNNING_MAX

	def shared(self, identity, label, ask):
		"""ask()'s rows for `identity` -- or, when another process is asking it right now, that process's answer once it is kept."""
		from modules.kodi_utils import get_property, set_property, clear_property, logger
		if self._running_elsewhere(identity):
			start = time.time()
			while self._running_elsewhere(identity) and time.time() - start < self._WAIT_MAX:
				time.sleep(self._POLL)
				rows = self.get(identity)
				if rows is not None:
					logger('http_streams cache', '%s: took the answer of a run already going (waited %.1f s)' % (label, time.time() - start))
					return rows
			rows = self.get(identity)   # kept just before the mark went
			if rows is not None: return rows
		mark = self._mark(identity)
		set_property(mark, '%f|%s' % (time.time(), self._token))
		try:
			rows = ask()
			if rows is not None: self.set(identity, rows)
			return rows
		finally:
			if get_property(mark).endswith('|' + self._token): clear_property(mark)


# LOCAL PATCH 2026-09-26: the display name, without the upstream formatter's debris. HDHub rows glue three layers:
#   '<filename>|^|<squashed tag block>.pad-<source> 📡 <title> • S02E05 🎞️ 4K • MKV ... 🛰️ Source: ... 🎧 Audio: ...'
# Rows with no filename start at the tag block. Kept: the filename, else the description's title, episode and tags.
# Dropped: tag block, bitrate, Source/Audio tail (own columns / extraInfo). Display only -- quality and extraInfo are
# parsed from the full text. Films open the description with 🍿 instead of 📡.
_DESC_START = re.compile('\U0001f4e1|\U0001f37f')  # 📡 episodes / 🍿 films
_DESC_STOP = re.compile(r'(?:\U0001f6f0️?|\U0001f3a7)')  # 🛰️ source / 🎧 audio
_DESC_SPLIT = re.compile(r'\s*(?:•|\U0001f39e️?)\s*')  # • and 🎞️
_BITRATE = re.compile(r'^~?\s*[\d.,]+\s*[kmg]bps$', re.I)
_TAG_BLOCK = re.compile(r'^\S*\.pad-\S+\s*')
# An archive EXTENSION: '.zip' not followed by a word char, dot or dash. Not \b: that hits a title
# word ('The.Zip.Code.S01E01.mkv').
_ZIP = re.compile(r'\.zip(?![\w.-])', re.I)
# a HubCloud link page (hubcloud.ist / .cx / ... /drive/<id>): HTML, not media -- see the 10gbps check
_HUBCLOUD_PAGE = re.compile(r'^https?://(?:[\w-]+\.)*hubcloud\.[a-z]{2,}/drive/', re.I)
# LOCAL PATCH 2026-11-22: HubCloud's direct links as the HDHub aggregator lists them ('gpdl.' / 'pixel.hubcloud.mov/?id=...') never
# serve the file: 0 of 77 (2026-11-22, player-style check) -- 39 redirect to the cryptonewz.online ad page, 38 end on a
# *.workers.dev that answers 400. Every such file had R2 / PixelDrain copies (11 of 12 alive each). A HubCloud /drive/ page
# resolved at play time (resolver 'hubcloud', the site scrapers) is not this.
_HUBCLOUD_DIRECT = re.compile(r'^https?://(?:[\w-]+\.)*hubcloud\.[a-z]{2,}/?\?id=', re.I)
# LOCAL PATCH 2026-11-22: a Stremio add-on that plays through its OWN server (Meteor: '<host>/<config>/play/<hash>/...') names
# the debrid it resolves with at the start of its stream name ('TB 1080p WEBRip', '[RD+] ...'); without it the Hoster column
# showed the add-on's address ('METEORFORTHE...').
_ADDON_DEBRID = re.compile(r'^\s*\[?(TB|RD|AD|PM|DL|ED|OC|PKP)\b', re.I)
_DEBRID_NAMES = {'TB': 'TorBox', 'RD': 'Real-Debrid', 'AD': 'AllDebrid', 'PM': 'Premiumize', 'DL': 'Debrid-Link', 'ED': 'EasyDebrid',
				 'OC': 'Offcloud', 'PKP': 'PikPak'}
_MIRROR = re.compile(r'Source:\s*[^·|\n]*·\s*([A-Za-z0-9][\w.-]*)')  # 'Source: MoviesDrives · FSL' -> FSL
_LEAD_HOST_TAG = re.compile(r'^\s*\[(FSL(?:[ -]?V2)?|PixelDrain)\]', re.IGNORECASE)   # HDHub: '[FSLv2] HdHub 1080p ...' -> FSLv2


# LOCAL PATCH 2026-11-08: 4KHDHub's own name in a row ('4KHDHub', '4kHdHub.Com'), cut out before the quality parse (_make_item)
_SITE_4K = re.compile(r'4k[\s._-]?hd[\s._-]?hub(?:[\s._-]?(?:com|ms|ist))?', re.I)

# LOCAL PATCH 2026-11-22: what may stand in front of a release name and is not part of it -- symbols a Stremio add-on puts
# before the file name ('📄 '), one of our own sites' names as a tag ('[AnimeDubHindi] Naruto S02E53 ...'), a mirror tag
# ('[FSL] ...'). Taken off the release name (_normalize): the name filter (check_title) failed '📄 [ToonsHub] MASHLE ...'
# (MASHLE S01E01, 2026-11-22), and the user wants titles to start with the release. A release group tag ('[ToonsHub]',
# '[SubsPlease]') stays.
_LEAD_SYMBOLS = re.compile(r'^[^\w\[(]+')
_LEAD_SITE_TAG = re.compile(r'^\[\s*(?:%s)\s*\]\s*' % '|'.join(re.escape(label) for _key, label, _module, _picker in SITES), re.I)


def _trim_lead(text):
	"""(the name without its leading clutter, the site tag taken off or ''). The site tag is the release group of a name
	with no '-GROUP' of its own ('[AnimeDubHindi] Naruto S02E53 ...'): _make_item keeps it for the Group column (user)."""
	trimmed, site = text or '', ''
	while True:
		before = trimmed
		trimmed = _LEAD_SYMBOLS.sub('', trimmed)
		m = _LEAD_SITE_TAG.match(trimmed)
		if m:
			site = site or m.group(0).strip(' []')
			trimmed = trimmed[m.end():]
		trimmed = _LEAD_HOST_TAG.sub('', trimmed).lstrip()
		if trimmed == before: break
	return (trimmed or text), site


def _clean_display(raw):
	raw = (raw or '').strip()
	head, sep, tail = raw.partition('|^|')
	if sep and head.strip(): return head.strip()
	text = tail if sep else raw
	start = _DESC_START.search(text)
	if start:
		desc = _DESC_STOP.split(text[start.end():], 1)[0]
		parts = [p.strip() for p in _DESC_SPLIT.split(desc)]
		parts = [p for p in parts if p and not _BITRATE.match(p)]
		if parts: return ' '.join(parts)
	return _TAG_BLOCK.sub('', text).strip() or raw


# LOCAL PATCH 2026-08-29: the pre-signed expiry helpers live in source_utils (shared with aiostreams).


class source:
	def __init__(self, publish=True):
		self.scrape_provider = 'http_streams'
		self.sources = []
		self.timeout = 25
		# LOCAL PATCH 2026-11-22: publish=False for a run that is not part of a live scrape (scrape_prewarm): it fills the
		# caches but does not write Window(Home) 'deadlight.internal_results.http_streams', which EVERY process reads. Dexter:
		# Resurrection, 21:56:21: the prewarm of S2E4 wrote its 8 rows there 0.1 s before the user's S2E1 scrape checked it;
		# external.py took them as S2E1's HTTP answer and opened the results without them; the real rows came 3.7 s later.
		self.publish = publish

	def results(self, info):
		# LOCAL PATCH 2026-11-23 (user): which sites and slots run on this title is modules/provider_gate's (anime list on
		# anime, own switches off it); the verdict is the scrape's own (search_info['is_anime'])
		from modules.provider_gate import info_is_anime, sites_to_run, stremio_slots_to_run
		is_anime = info_is_anime(info)
		all_scrapers = bool(info.get('all_scrapers'))   # 'Rescrape With All Scrapers': every set-up site and slot
		sites, addons = sites_to_run(is_anime, all_scrapers), stremio_slots_to_run(is_anime, all_scrapers)
		if not (sites or addons): return self._return()
		media_type = info.get('media_type')
		tmdb_id = info.get('tmdb_id')
		title = info.get('title') or ''
		year = info.get('year', '')
		season_key = info.get('season') if media_type == 'episode' else ''
		episode_key = info.get('episode') if media_type == 'episode' else ''
		imdb = info.get('imdb_id') or ''
		cache_provider = _results_cache_key(sites, addons)

		# Cache lookup (skip if no tmdb_id since cache is keyed by it)
		if tmdb_id:
			try:
				from caches.external_cache import external_cache
				cached = external_cache.get(cache_provider, media_type, tmdb_id, title, year, season_key, episode_key)
				if cached is not None:
					self.sources = self._drop_other_titles(cached, info)
					return self._return()
			except Exception: pass

		# Stremio add-ons can also be queried with a TMDb ID when IMDb is missing.
		imdb = self._valid_imdb(imdb)
		tmdb_stream_id = 'tmdb:%s' % tmdb_id if tmdb_id else ''
		if not imdb and not tmdb_stream_id:
			return self._return()

		# Translate media_type to upstream content_type ('movie' or 'tv')
		content_type = 'movie' if media_type == 'movie' else 'tv'
		season = info.get('season') if media_type == 'episode' else None
		episode = info.get('episode') if media_type == 'episode' else None

		stremio_stream_id = imdb or tmdb_stream_id
		# LOCAL PATCH 2026-11-05: the Stremio addons are asked in Cinemeta's numbering (IMDb id : season : episode), not TMDb's
		# -- for anime TMDb often files several cours as one season (MASHLE TMDb S1E13 = Cinemeta 2:1). Anime only (a Fribb
		# row), one query per provider; the pair also joins episode_candidates so the episode and name filters keep its rows.
		pairs = [(season, episode)]
		if season is not None and tmdb_id and imdb:
			# the lookup lives in modules/episode_card.stremio_pair, shared with scrapers/external.py
			try:
				from modules.episode_card import stremio_pair
				mapped, how = stremio_pair(tmdb_id, season, episode, imdb)
				if mapped and mapped != (int(season), int(episode)):
					pairs = [mapped]
					info = dict(info, episode_candidates=list(info.get('episode_candidates') or []) + [mapped])
					from modules.kodi_utils import logger
					logger('http_streams numbering', 'TMDb S%sE%s -> %s:%d:%d (%s)' % (season, episode, imdb, mapped[0], mapped[1], how))
			except Exception: pass

		scrape_ran = False
		failed = False   # LOCAL PATCH 2026-10-15: any provider failed -> results are shown but not cached
		reused = False   # LOCAL PATCH 2026-11-22: some rows came from _ProviderCache (see the combined write below)
		try:
			from scrapers import _http_providers_core as core
			collected = []

			tasks = []
			def scrape_addon(slot, manifest, season, episode):
				parts = urlparse(manifest)
				base = parts._replace(path=parts.path[:-len('/manifest.json')]).geturl()
				rows = core._scrape_json_provider(base, 'stream', 'Stremio%d' % slot,
					stremio_stream_id, content_type, season, episode, title_query=title, year_query=year)
				return [dict(row, stremio_slot=slot) for row in rows] if rows is not None else None

			# each task: (label, identity -- what it asks, for its own cache entry -- , fn)
			for slot, manifest in addons:
				provider_key = 'Stremio%d' % slot
				for i, (s, e) in enumerate(pairs):
					task_label = provider_key if not i else '%s S%sE%s' % (provider_key, s, e)
					identity = 'stremio\0%s\0%s\0%s:%s:%s' % (manifest, content_type, stremio_stream_id, s, e)
					tasks.append((task_label, identity, lambda slot=slot, manifest=manifest, s=s, e=e: scrape_addon(slot, manifest, s, e)))

			# Site scrapers in scrapers/site_scrapers.SITES are not Stremio endpoints: each reads its site and returns rows in
			# the same shape. HubCloud links resolve at play time. Handed the checked IMDb id; title searches ignore it.
			from importlib import import_module
			# LOCAL PATCH 2026-11-23 (user): each site under the providers' timeout memory (_http_providers_core.run_guarded): skipped
			# for 10 min after 3 timeouts in a row, then probed once
			from scrapers._http_providers_core import run_guarded
			for _key, label, module, _picker in sites:
				site = import_module('scrapers.%s' % module)
				tasks.append((label, 'site\0%s\0%s' % (module, imdb),
							  lambda site=site, label=label: run_guarded(label, lambda: site.scrape(dict(info, imdb_id=imdb)))))

			if not tasks:
				return self._return()

			# LOCAL PATCH 2026-11-22: each provider's answer is also kept on its own (_ProviderCache), so a provider that answered
			# lately is not asked again when another one failed -- the combined cache above is written only when NONE failed, and
			# one Stremio add-on timing out made every click re-run every site (12.5 s, 2026-11-22 18:33). Same lifetimes.
			provider_cache = _ProviderCache(media_type, tmdb_id, title, year, season_key, episode_key) if tmdb_id else None
			from_cache = []
			if provider_cache:
				pending = []
				for task in tasks:
					rows = provider_cache.get(task[1])
					if rows is None: pending.append(task)
					else: from_cache.append((task[0], rows))
				tasks = pending
			reused = bool(from_cache)

			# One worker per provider (up to 8); fall back to sequential on RuntimeError
			# for embedded-box thread limits.
			# LOCAL PATCH 2026-11-05: a provider has failed only when none of its queries answered with rows (a timeout on
			# the pair it does not index must not keep the other pair's rows out of the cache)
			answered, errored = set(), set()
			def _take(label, res):
				provider = label.split()[0]
				if res is None: errored.add(provider)
				elif res:
					answered.add(provider)
					# LOCAL PATCH 2026-11-26 (user): a site scraper's rows remember the site ('4KHDHub'), shown as the row's site
					# instead of 'HTTP' (windows/sources.py); a Stremio slot row is named by its slot already
					for i in res:
						if not i.get('stremio_slot'): i.setdefault('site', provider)
					collected.extend(res)
			for label, rows in from_cache: _take(label, rows)
			# LOCAL PATCH 2026-11-22: each provider runs through _ProviderCache.shared (with a cache): its answer is kept the moment
			# it arrives, and a provider another DeadLight process is already asking for this episode (the prewarm) is waited for
			# instead of asked twice (Dexter: Resurrection S2E1, 21:56: HDHub4u ran for the prewarm and the scrape at once,
			# 3.98 s + 5.70 s)
			run = (lambda label, identity, fn: provider_cache.shared(identity, label, lambda: self._run_task(label, fn))) if provider_cache \
				else (lambda label, identity, fn: self._run_task(label, fn))
			if tasks:
				try:
					# LOCAL PATCH 2026-11-18: every provider at once (3 dated from HDHub + one Stremio add-on alone; with the site scrapers on, the
					# 4th..6th task waited for a free thread and the scrape took two rounds)
					with ThreadPoolExecutor(max_workers=min(8, len(tasks))) as ex:
						futures = [(label, ex.submit(run, label, identity, fn)) for label, identity, fn in tasks]
						for label, fut in futures:
							try: _take(label, fut.result(timeout=self.timeout))
							except Exception: _take(label, None)
				except RuntimeError:
					for label, identity, fn in tasks:
						try: _take(label, run(label, identity, fn))
						except Exception: _take(label, None)
			if provider_cache:
				if from_cache:
					from modules.kodi_utils import logger
					logger('http_streams cache', '%s: kept answers of %s; asked %s' % (title, ', '.join(l for l, _r in from_cache),
						', '.join(l for l, _i, _f in tasks) or 'none'))
			failed = bool(errored - answered)

			# Convert upstream stream dicts → DeadLight source dicts
			# LOCAL PATCH 2026-11-08: with the episode title, as aiostreams / easynews do (Red Light 3.0.1). For an episode,
			# not the four list words that are ordinary title words -- release names may carry an episode title TMDb lacks
			# ('INSIDE THE GARBAGE BAG'). These upstreams are asked for one exact episode (_drop_other_episodes); the
			# unmistakable markers (sample, featurette, trailer, ...) still apply.
			extras = source_utils.extras(title, info.get('ep_name') if media_type == 'episode' else None)
			if media_type == 'episode': extras = tuple(w for w in extras if w not in ('inside', 'extra', 'extras', 'feature'))
			self._unplayable = {}
			self.sources = [s for s in (self._make_item(item, extras) for item in collected) if s]
			# LOCAL PATCH 2026-11-08: the rows _make_item drops as unplayable, logged like every other filter here.
			if self._unplayable:
				from modules.kodi_utils import logger
				logger('http_streams unplayable', '%s: dropped %d of %d (%s)' % (title, sum(len(v) for v in self._unplayable.values()), len(collected),
					'; '.join('%d %s: %s' % (len(v), why, ' | '.join(sorted(set(v))[:2])) for why, v in self._unplayable.items())))
			self.sources = self._drop_expired_presigns(self.sources, collected)
			# Dedup by URL hash
			seen = set()
			deduped = []
			for s in self.sources:
				h = s.get('hash') or ''
				if h and h in seen: continue
				if h: seen.add(h)
				deduped.append(s)
			deduped = self._inherit_prerelease(deduped)
			deduped = self._drop_other_episodes(deduped, info)
			self.sources = self._filter_dead_urls(self._filter_pixeldrain_blocked(deduped))
			scrape_ran = True
		except Exception as e:
			from modules.kodi_utils import logger
			logger('http_streams scraper Exception', str(e))

		# Cache result. HDHub's CDN URLs carry ~1-hour ?token= params (404 once expired), so 30 min on
		# success, 1 hour on empty. Not info['expiry_times']: its 24h default outlasts the tokens.
		# LOCAL PATCH 2026-11-22: not when some rows were kept answers -- a fresh 30 min on rows already up to 30 min old would
		# outlast those tokens; the per-provider entries serve the next click anyway.
		if scrape_ran and tmdb_id and not failed and not reused:
			try:
				from caches.external_cache import external_cache
				expiry_hours = 0.5 if self.sources else 1
				external_cache.set(cache_provider, media_type, tmdb_id, title, year, season_key, episode_key, self.sources, expiry_hours)
			except Exception: pass

		self.sources = self._drop_other_titles(self.sources, info)
		return self._return()

	# LOCAL PATCH 2026-09-22: the flavours of 'no imdb' a truthiness check misses ('tt0000000', 'empty_setting', ...).
	# Same set as Red Light's _INVALID_IMDB.
	_INVALID_IMDB = ('', 'none', 'null', '0', 'tt0000000', 'tt0', 'empty_setting')

	@classmethod
	def _valid_imdb(cls, imdb):
		"""The id in tt-form, or '' when TMDb gave us nothing usable."""
		imdb = str(imdb or '').strip()
		if not imdb or imdb.lower() in cls._INVALID_IMDB: return ''
		if not imdb.startswith('tt'): imdb = 'tt' + imdb
		return '' if imdb.lower() in cls._INVALID_IMDB else imdb

	@staticmethod
	def _drop_expired_presigns(sources, raw_items):
		"""Drop pre-signed URLs past their expiry; mark the rest as needing no probe.

		Reference clock is the aggregator's Date header, carried on the raw items by
		_scrape_json_provider, not the local one -- see source_utils.presign_reference.
		"""
		server_date = next((i.get('server_date') for i in (raw_items or []) if i.get('server_date')), None)
		return source_utils.drop_expired_presigns(sources, server_date)

	# LOCAL PATCH 2026-09-28: drop rows that NAME ANOTHER EPISODE -- HDHub's aggregator matches the episode as a text
	# PREFIX (S20E01 also returns E10-E19). Conservative: a row goes only when its name carries an explicit SxxEyy / NxNN
	# that is neither this episode nor an anime numbering candidate. A name stating no episode contradicts nothing.
	_EPISODE_TAG = re.compile(r'(?i)(?<![a-z0-9])(?:s(\d{1,2})[ ._-]?e(\d{1,4})|(\d{1,2})x(\d{2,4}))(?![0-9])')
	_SEASON_WORD = re.compile(r'(?i)(?<![a-z0-9])season[ ._-]?(\d{1,2})(?![0-9])')

	@classmethod
	def _season_word_names(cls, name):
		"""LOCAL PATCH 2026-11-10: [name] plus, when the name spells out a season its SxxEyy tag disagrees with, the name with
		that tag rewritten to the stated season and the season word taken out ('Dorohedoro.Season2.S01E01' -> also
		'Dorohedoro.S02E01'): check_title reads everything before the episode tag as the title.
		LOCAL PATCH 2026-11-22: and the name with a bracketed episode tag unbracketed ('Mashle: Magic and Muscles [S01E01] ...' ->
		'... S01E01 ...'): check_title does not read an SxxEyy inside brackets (MoviesDrive's MASHLE S01E01 row was dropped)."""
		names = [name]
		plain = cls._BRACKETED_EPISODE.sub(r' \1 ', name)
		if plain != name: names.append(re.sub(r'\s{2,}', ' ', plain).strip())
		for base in list(names):
			for n in set(int(m.group(1)) for m in cls._SEASON_WORD.finditer(base)):
				alt = re.sub(r'(?i)(?<![a-z0-9])s(\d{1,2})([ ._-]?e\d{1,4})(?![0-9])',
					lambda m: m.group(0) if int(m.group(1)) == n else 'S%02d%s' % (n, m.group(2)), base)
				if alt != base: names.append(re.sub(r'\s{2,}|\.{2,}', lambda m: m.group(0)[0], cls._SEASON_WORD.sub('', alt)).strip(' ._-'))
		return names

	_BRACKETED_EPISODE = re.compile(r'(?i)[\[(]\s*(s\d{1,2}[ ._-]?e\d{1,4})\s*[\])]')

	# LOCAL PATCH 2026-11-04 (release judge, phase 4b): stays here, not in modules/release_judge -- it runs on EVERY show, and
	# the card and cour data the judge needs are built in the external scrape only. For anime it reads the card's numbers via
	# info['episode_candidates'].
	@classmethod
	def _drop_other_episodes(cls, sources, info):
		if info.get('media_type') != 'episode': return sources
		try: season, episode = int(info.get('season')), int(info.get('episode'))
		except (TypeError, ValueError): return sources
		# LOCAL PATCH 2026-11-18: the same pairs the site scrapers match by (_site_common.episode_pairs) -- with the absolute
		# number under a season label, which the card's candidates carry only as ABSOLUTE_SEASON (never a real 'S02'): this
		# filter dropped the 'S02E26' / 'S01E53' rows the scrapers had found for them
		from scrapers._site_common import episode_pairs
		wanted = episode_pairs(info, season, episode)
		kept, dropped = [], []
		for s in sources:
			name = s.get('name') or ''
			# LOCAL PATCH 2026-11-10: a name that also spells out the season ('Dorohedoro.Season2.S01E01...', HDHub) numbers
			# the episode within that season; its tag is read both ways (_season_word_names). Log 2026-11-09: S02E01 dropped 8 of 8.
			tags = [(int(m.group(1) or m.group(3)), int(m.group(2) or m.group(4)))
				for n in cls._season_word_names(name) for m in cls._EPISODE_TAG.finditer(n)]
			if not tags or any(t in wanted for t in tags): kept.append(s)
			else: dropped.append(name)
		if dropped:
			from modules.kodi_utils import logger
			logger('http_streams episode', 'S%02dE%02d: dropped %d of %d naming another episode (%s)'
				% (season, episode, len(dropped), len(sources), ', '.join(sorted(set(n[:40] for n in dropped))[:4])))
		return kept

	# LOCAL PATCH 2026-10-15: 'Filter Results by Name' (check_title) -- the aggregators answer by id but not always with
	# that title. Off by default: a regional release named differently from TMDb's would go too. Applied when results are
	# RETURNED, not before the cache write, so the cache keeps the full set and the setting takes effect at once.
	# LOCAL PATCH 2026-10-16: with the name filter OFF a film still loses rows stating another year
	# (source_utils.year_mismatch) -- a regional name cannot trip it, a different film can. Episodes keep only the episode check.
	@staticmethod
	def _drop_other_titles(sources, info):
		if not sources: return sources
		if not filter_by_name('http_streams'):
			if info.get('media_type') == 'episode': return sources
			year = info.get('year', '')
			kept = [s for s in sources if not source_utils.year_mismatch(s.get('name') or '', year)]
			if len(kept) < len(sources):
				from modules.kodi_utils import logger
				logger('http_streams year', '%s (%s): dropped %d of %d stating another year (%s)' % (info.get('title') or '', year,
					len(sources) - len(kept), len(sources), ', '.join(sorted(set((s.get('name') or '')[:40] for s in sources if s not in kept))[:4])))
			return kept
		title, year = info.get('title') or '', info.get('year', '')
		season = episode = None
		if info.get('media_type') == 'episode':
			try: season, episode = int(info.get('season')), int(info.get('episode'))
			except (TypeError, ValueError): season, episode = info.get('season'), info.get('episode')
		aliases = source_utils.get_aliases_titles(info.get('aliases', []))
		# LOCAL PATCH 2026-11-05: an anime row named by another numbering of this episode passes, as in _drop_other_episodes
		# LOCAL PATCH 2026-11-19: the same pairs (_site_common.episode_pairs), with the absolute number under a season label --
		# this filter's own copy lacked it and dropped the 1080p 'NARUTO.S01E53' rows 4KHDHub had found for TMDb S2E53
		pairs = [(season, episode)]
		if isinstance(season, int) and isinstance(episode, int):
			from scrapers._site_common import episode_pairs
			pairs = episode_pairs(info, season, episode)
		def _ok(name):
			# LOCAL PATCH 2026-11-10: and the name read with its spelled-out season ('Season2.S01E01' as S02E01), see _drop_other_episodes
			return any(source_utils.check_title(title, n, aliases, year, s, e, air_date=info.get('premiered'), ep_title=info.get('ep_name'))
				for n in source._season_word_names(name) for s, e in pairs)
		kept = [s for s in sources if _ok(s.get('name') or '')]
		if len(kept) < len(sources):
			from modules.kodi_utils import logger
			logger('http_streams title', '%s: dropped %d of %d naming another title (%s)' % (title, len(sources) - len(kept),
				len(sources), ', '.join(sorted(set((s.get('name') or '')[:40] for s in sources if s not in kept))[:4])))
		return kept

	# LOCAL PATCH 2026-11-02: a cam rip re-listed WITHOUT its tag takes the tag of its tagged copy -- PenguPlay lists one
	# upload once per indexer, and MoviesDrives rebuilds the name from tags and loses the source. Same file = same
	# behaviorHints.videoSize to the byte. Without bytes on both sides the 2-decimal GB size is used, and then only for a
	# row whose name states no source: equal GB alone is too weak.
	_PRERELEASE = ('CAM', 'SCR', 'TELE')
	_SOURCE_TAG = re.compile(r'(?i)(?<![a-z0-9])(?:web[ ._-]?(?:dl|rip)?|blu[ ._-]?ray|bdrip|brrip|remux|hdrip|dvdrip|hdtv|amzn|nf|dsnp|hmax|atvp)(?![a-z0-9])')

	@staticmethod
	def _byte_size(value):
		try: return int(value or 0)
		except (TypeError, ValueError): return 0

	@classmethod
	def _inherit_prerelease(cls, sources):
		if not sources: return sources
		by_bytes, by_gb = {}, {}
		for s in sources:
			if s.get('quality') not in cls._PRERELEASE: continue
			if s.get('video_size'): by_bytes.setdefault(s['video_size'], s['quality'])
			if s.get('size'): by_gb.setdefault(s['size'], s['quality'])
		if not by_bytes and not by_gb: return sources
		changed = []
		for s in sources:
			if s.get('quality') in cls._PRERELEASE: continue
			quality = by_bytes.get(s.get('video_size')) if s.get('video_size') else None
			if not quality and s.get('size') and not cls._SOURCE_TAG.search(s.get('name') or ''):
				quality = by_gb.get(s['size']) if not (s.get('video_size') and by_bytes) else None
			if quality:
				changed.append('%s (%s)' % ((s.get('name') or '')[:40], s.get('size_label') or ''))
				s['quality'] = quality
		if changed:
			from modules.kodi_utils import logger
			logger('http_streams prerelease', '%d untagged copy/copies of a cam / TS release relabelled: %s' % (len(changed), ', '.join(changed[:4])))
		return sources

	_PIXELDRAIN_ID = re.compile(r'pixeldrain\.(?:dev|com)/(?:api/file|u)/([A-Za-z0-9]+)', re.I)

	@staticmethod
	def _filter_pixeldrain_blocked(sources):
		"""LOCAL PATCH 2026-10-11: drop PixelDrain links PixelDrain itself says will not download. Its /api/file/<id>/info
		reports 'availability' (e.g. 'file_rate_limited_captcha_required': too much hotlink bandwidth, a browser captcha
		is wanted) and 'can_download'; such a link answers the player 403 every time. Not the HEAD probe, whose 403s
		PixelDrain also sends under mere concurrency: this is the file's own state, one small request per link, in parallel,
		4 s at most. Unreadable info keeps the link. Only with `http_streams.validate_urls` on (no extra requests otherwise)."""
		if get_setting('deadlight.http_streams.validate_urls', 'false') != 'true': return sources
		ids = {}
		for src in sources or []:
			m = source._PIXELDRAIN_ID.search(src.get('url_dl') or src.get('url') or '')
			if m: ids.setdefault(m.group(1), []).append(src)
		if not ids: return sources
		def _blocked(pd_id):
			try:
				info = _session.get('https://pixeldrain.dev/api/file/%s/info' % pd_id, timeout=4).json()
				if not isinstance(info, dict) or not info.get('success'): return None
				if info.get('availability') or info.get('can_download') is False: return info.get('availability') or 'can_download false'
			except Exception: return None
			return None
		with ThreadPoolExecutor(max_workers=min(4, len(ids))) as pool:
			verdicts = dict(zip(ids, pool.map(_blocked, list(ids))))
		blocked = dict((k, v) for k, v in verdicts.items() if v)
		if not blocked: return sources
		drop = set(id(src) for k in blocked for src in ids[k])
		try:
			from modules.kodi_utils import logger
			logger('http_streams pixeldrain', 'dropped %d link(s) PixelDrain will not serve: %s' % (len(drop),
				', '.join('%s (%s)' % (k, v) for k, v in blocked.items())))
		except Exception: pass
		return [src for src in sources if id(src) not in drop]

	@staticmethod
	def _filter_dead_urls(sources):
		# HEAD-check each URL in parallel; drop ones that 4xx/5xx/timeout/refuse
		# or return a non-video Content-Type (catches expired/CDN-error pages).
		# Gated on `http_streams.validate_urls` (default off) because validation
		# adds up to `validate_timeout` seconds of latency per scrape.
		if get_setting('deadlight.http_streams.validate_urls', 'false') != 'true':
			return sources
		if not sources:
			return sources
		try:
			timeout = max(2, int(get_setting('deadlight.http_streams.validate_timeout', '5') or '5'))
		except Exception:
			timeout = 5

		ok_status = (200, 206)
		ok_ctype_prefixes = (
			'video/',
			'application/octet-stream',
			'application/vnd.apple.mpegurl',
			'application/x-mpegurl',
			'application/dash+xml',
		)

		def _response_ok(r):
			if r is None:
				return False
			if getattr(r, 'status_code', 999) not in ok_status:
				return False
			try:
				ctype = (r.headers.get('Content-Type') or '').lower().split(';', 1)[0].strip()
			except Exception:
				return False
			if not ctype:
				return False
			return any(ctype.startswith(p) for p in ok_ctype_prefixes)

		def is_alive(source):
			# LOCAL PATCH 2026-08-29: already settled by the pre-signed expiry gate (inside
			# its signed window = alive), so a probe can only cost time or invent a failure.
			# LOCAL PATCH 2026-11-18: nor a row resolved at play time -- its link is an HTML page the probe would call dead
			if source.get('_presign_ok') or source.get('resolver'):
				return source
			# http_streams URLs may have |Header=... suffix appended for Kodi's
			# player; strip it before the HEAD probe so requests doesn't choke.
			url = (source.get('url_dl') or source.get('url') or '').split('|', 1)[0]
			if not url:
				return None
			# LOCAL PATCH 2026-08-29: send NO explicit User-Agent -- not an omission. Some hosts
			# (hcdn.hakunaymatata.com) serve requests' default UA and answer 428 to a browser UA.
			try:
				r = _session.head(url, timeout=timeout, allow_redirects=True)
				if _response_ok(r):
					return source
				# LOCAL PATCH 2026-08-29: retry once on 403 -- PixelDrain rate-limits under concurrency
				# with 403s for links that serve fine a moment later.
				if getattr(r, 'status_code', 0) == 403:
					time.sleep(1.0)
					r = _session.head(url, timeout=timeout, allow_redirects=True)
					if _response_ok(r):
						return source
				# Rate-limited on the HEAD: keep it, and do not spend a GET making it worse.
				if getattr(r, 'status_code', 0) == 429:
					return source
				r = _session.get(url, timeout=timeout, headers={'Range': 'bytes=0-0'}, stream=True)
				if _response_ok(r):
					return source
				if getattr(r, 'status_code', 0) == 403:
					time.sleep(1.0)
					r = _session.get(url, timeout=timeout, headers={'Range': 'bytes=0-0'}, stream=True)
					if _response_ok(r):
						return source
				# LOCAL PATCH 2026-08-29: 429 means the host is rate-limiting checks, not that the link is dead;
				# keep the source, since dropping on 429 would lose more good sources as the scrape gets busier.
				if getattr(r, 'status_code', 0) == 429:
					return source
			except Exception:
				return None
			return None

		# Cap at 6. DO NOT RAISE: past ~10 workers the load causes timeouts that silently discard
		# WORKING sources (16 workers dropped 2 of 16 good rows), and 6 stays modest for CoreELEC's
		# pid limit. The RuntimeError fallback below degrades to sequential.
		max_workers = max(1, min(len(sources), 6))
		try:
			with ThreadPoolExecutor(max_workers=max_workers) as ex:
				checked = list(ex.map(is_alive, sources))
		except RuntimeError as e:
			from modules.kodi_utils import logger
			logger('http_streams thread pool failed', str(e))
			checked = [is_alive(s) for s in sources]
		return [s for s in checked if s is not None]

	@staticmethod
	def _run_task(label, fn):
		from modules.kodi_utils import logger
		try:
			out = fn() or []
			logger('http_streams %s' % label, 'returned %d streams' % len(out))
			return out
		except Exception as e:
			logger('http_streams %s error' % label, str(e))
			return None   # LOCAL PATCH 2026-10-15: a failure, told apart from an empty answer (see results)

	# LOCAL PATCH 2026-11-08: a row dropped as unplayable, kept by reason for results()' log line
	def _unplayable_row(self, why, item):
		try: self._unplayable.setdefault(why, []).append(' '.join(str(item.get('title') or item.get('name') or '?').split())[:60])   # one log line
		except AttributeError: pass   # _make_item called outside results()
		return None

	# LOCAL PATCH 2026-11-08: one reading of an upstream (Stremio-shaped) row, so its quirks are handled in one place. HDHub's
	# label 'HDHub | 4K 1080p' and info line 'pixeldrain | 4KHDHub' name the SITE, not the file ('4K' there is not the
	# resolution). Returns None for a row with no usable link; 'unplayable' names what kind of non-video row it is.
	_RELEASE_HINT = re.compile(r'\b(19|20)\d{2}\b|\b(?:2160|1080|720|480)p\b|\bS\d{1,3}[.\s-]?E\d{1,4}\b', re.IGNORECASE)
	_RESOLUTION = {'4k': '4K', '2160p': '4K', '1080p': '1080p', '720p': '720p', '480p': 'SD', 'sd': 'SD'}

	@classmethod
	def _normalize(cls, item):
		url = (item.get('url') or '').strip()
		if not url: return None
		url_part = url.split('|', 1)[0]
		if not cls._is_valid_http_url(url_part): return None
		title, name, info = (item.get('title') or '').strip(), (item.get('name') or '').strip(), (item.get('info') or '').strip()
		texts = info + ' ' + name + ' ' + title
		unplayable = None
		# HDHub's '[10Gbps Download Only]' HubCloud rows and a hubcloud /drive/ page are link generators (HTML), not media; its HLS
		# ladder is a transcode (4K-labelled at 8 Mbps); a .zip is a season archive Kodi cannot play.
		if '10gbps' in texts.lower(): unplayable = '10Gbps download page'
		# LOCAL PATCH 2026-11-18: unless the row says it is resolved at play time (resolver='hubcloud', AnimeDubHindi)
		elif _HUBCLOUD_PAGE.search(url_part) and item.get('resolver') != 'hubcloud': unplayable = 'HubCloud drive page'
		elif _HUBCLOUD_DIRECT.search(url_part): unplayable = 'HubCloud direct link'
		elif source_utils.is_transcode_url(url_part): unplayable = 'HLS transcode'
		elif _ZIP.search(texts + ' ' + url_part): unplayable = 'zip archive'
		# The release name: a real filename first; else the info line when it reads as a release (a year, a resolution or an
		# SxxEyy -- 4KHDHub cuts long names before their resolution) and is longer; else the longer of title / name.
		if any(title.lower().endswith(ext) for ext in ('.mkv', '.mp4', '.avi', '.mov', '.ts', '.webm')):
			parse_source = title
		elif cls._RELEASE_HINT.search(info) and len(info) > len(title):
			cleaned = info
			# info is '[host] [size] NAME' then a second line 'host | site': the first line alone when it is the release
			first = info.split('\n', 1)[0]
			if first != info and cls._RELEASE_HINT.search(first): cleaned = first
			while True:   # leading [FSL] / [FSLV2] / [PIXELDRAIN] / [PixelDrain] host tags (a group tag like [SubsPlease] stays)
				# LOCAL PATCH 2026-11-17: also HDHub's '[FSLv2]' (lower-case v): left in the name, it kept the FSLv2 copy out of its
				# release's merge (a second row of the same file)
				m = re.match(r'\s*\[([A-Z][A-Z0-9_-]+)\]\s*', cleaned) or re.match(r'\s*\[(?:pixeldrain|fsl[ -]?v?2?)\]\s*', cleaned, re.IGNORECASE)
				if not m: break
				cleaned = cleaned[m.end():]
			cleaned = re.sub(r'\[?\s*\U0001f4be\s*[\d.,]+\s*(?:GB|GiB|MB|MiB|TB|TiB)\s*\]?', '', cleaned, flags=re.IGNORECASE)
			cleaned = re.sub(r'\[\s*[\d.,]+\s*(?:GB|GiB|MB|MiB|TB|TiB)\s*\]', '', cleaned, flags=re.IGNORECASE)
			parse_source = re.sub(r'\s+', ' ', cleaned).strip(' |\t\n')
		elif len(title) >= len(name): parse_source = title or name
		else: parse_source = name
		parse_source, site_tag = _trim_lead(parse_source)
		# LOCAL PATCH 2026-11-09: the file's FULL name when its link states it. 4KHDHub cuts the name it lists at 100
		# characters (the tail with codec, audio and group is lost on a long episode title), but an FSL link names the whole
		# file (response-content-disposition). Taken only when it extends the listed name. The merge key stays the LISTED
		# name, the same on every host, so an FSL copy (full name) and its PixelDrain twin (cut, no name in the link) merge.
		release_key = re.sub(r'[^a-z0-9]', '', parse_source.lower())
		full = cls._link_filename(url_part)
		if full and len(full) > len(parse_source) and release_key and re.sub(r'[^a-z0-9]', '', full.lower()).startswith(release_key):
			parse_source = full
		upstream_q = (item.get('quality') or '').strip()
		# LOCAL PATCH 2026-11-17: HDHub states the host as a LEADING tag ('[FSL] ...', '[FSLv2] ...'), not 'Source: x · FSL'.
		# Without it both R2 copies were named by their URL guess (FSL-V2) and FSL could not be ranked before FSLv2.
		mirror = _MIRROR.search(texts) or _LEAD_HOST_TAG.search(info) or _LEAD_HOST_TAG.search(title) or _LEAD_HOST_TAG.search(name)
		return {'url': url, 'url_part': url_part, 'unplayable': unplayable, 'title': title, 'name': name, 'info': info,
				'parse_source': parse_source, 'release': _clean_display(parse_source),
				# the site's name ('4KHDHub', '-4kHdHub.Com') is not a resolution
				'parse_text': _SITE_4K.sub(' ', ((parse_source + ' ' + info).strip() if info else parse_source)),
				'resolution': cls._RESOLUTION.get(upstream_q.lower(), upstream_q if upstream_q in ('4K', '1080p', '720p', 'SD') else ''),
				'mirror': mirror.group(1) if mirror else '', 'release_key': release_key, 'site_tag': site_tag}

	@staticmethod
	def _addon_debrid(item):
		"""LOCAL PATCH 2026-11-23: 'TorBox' for a Stremio row named 'Stremio1 | TB 1080p WEBRip' (the add-on's own name follows the
		slot label), else ''."""
		m = _ADDON_DEBRID.match((item.get('name') or '').split(' | ', 1)[-1])
		return _DEBRID_NAMES[m.group(1).upper()] if m else ''

	def _addon_hoster(self, item):
		"""LOCAL PATCH 2026-11-22: the debrid a Stremio row plays through (_addon_debrid), else the add-on's display name
		(stremio_addons.addon_name, looked up once per slot)."""
		debrid = self._addon_debrid(item)
		if debrid: return debrid
		names = self.__dict__.setdefault('_addon_names', {})
		slot = item['stremio_slot']
		if slot not in names: names[slot] = stremio_addons.addon_name(slot)
		return names[slot]

	_CD_FILENAME = re.compile(r'filename\*?=(?:UTF-8\'\')?"?([^";&]+)', re.I)
	_LINK_VIDEO = re.compile(r'\.(?:mkv|mp4|avi|m4v|ts|webm|mov)$', re.I)

	@classmethod
	def _link_filename(cls, url_part):
		"""LOCAL PATCH 2026-11-09: the file name a direct link states -- its content-disposition query (FSL's signed R2
		links) or a path ending in a video file. '' when it names none (PixelDrain's /api/file/<id>)."""
		try:
			from urllib.parse import parse_qs, unquote
			p = urlparse(url_part)
			cd = (parse_qs(p.query).get('response-content-disposition') or [''])[0]
			m = cls._CD_FILENAME.search(unquote(cd)) if cd else None
			if m and cls._LINK_VIDEO.search(m.group(1).strip()): return m.group(1).strip()
			last = unquote(p.path.rsplit('/', 1)[-1])
			if cls._LINK_VIDEO.search(last): return last
		except Exception: pass
		return ''

	def _make_item(self, item, extras):
		"""Convert upstream stream dict to DeadLight source dict.
		Upstream shape (from _process_resolved_results / _scrape_json_provider):
		    {'name': str (host | size, e.g. "HubCloud | 2.1 GB"),
		     'url': str (with optional |Header=... suffix),
		     'quality': str ('4K'/'1080p'/'720p'/'SD'),
		     'title': str (full filename, e.g. "Movie.2024.1080p.BluRay.x265.HEVC.mkv"),
		     'size': str ('2.1 GB'),
		     'info': str (provider | branch info)}
		"""
		# LOCAL PATCH 2026-11-08: the upstream row is read once, by _normalize (what the row IS: its link, whether it can play,
		# its real release name, the resolution and host it states); what follows is DeadLight's own reading of that.
		try:
			row = self._normalize(item)
			if row is None: return None
			if row['unplayable']: return self._unplayable_row(row['unplayable'], item)
			url, url_part, display_source, parse_source = row['url'], row['url_part'], row['release'], row['parse_source']
			if not display_source: return None
			if any(x in display_source.lower() for x in extras): return None
			# De-dup "HDHub | HDHub ..." in the display when upstream attached the label twice.
			display_name = source_utils.clean_display_name(re.sub(r'\bHDHub\s*\|?\s*HDHub\b', 'HDHub', display_source, flags=re.IGNORECASE))
			size_gb, size_str = self._extract_size(item.get('size'), item.get('info'), row['title'], row['name'])
			# Quality + extraInfo from as much text as there is (the info often carries the codec / HDR / audio tags). An upstream
			# resolution only stands in when the parser finds none (SD).
			fl_quality, details = source_utils.get_file_info(name_info=source_utils.release_info_format(row['parse_text']))
			quality = row['resolution'] if fl_quality == 'SD' and row['resolution'] and row['resolution'] != 'SD' else (fl_quality or row['resolution'] or 'SD')
			langs = self._extract_languages(parse_source, row['info'], row['title'], row['name'])
			extra_info = ' | '.join(x for x in (details, ' | '.join(langs) if langs else '') if x)
			try:
				from scrapers import _http_providers_core as core
				hoster = core._identify_host_from_url(url_part) or ''
			except Exception:
				hoster = ''
			# LOCAL PATCH 2026-10-24: a mirror the URL does not name (an opaque /direct/<token> address) is named by the row's own tag
			# LOCAL PATCH 2026-11-17: so is a Cloudflare R2 link -- 'FSL-V2' is only the URL guess, and HDHub's FSL copies sit on R2
			# too (Rings of Power S03E01: all 10 [FSL] rows were labelled FSL-V2)
			netloc = urlparse(url_part).netloc.lower().replace('www.', '')
			if hoster in ('', 'Direct', 'FSL-V2', netloc.split('.')[0].title()) and row['mirror']: hoster = row['mirror']
			# LOCAL PATCH 2026-11-22: a Stremio slot's own playback link is named by the debrid it plays through ('TB' -> TorBox), else
			# by the add-on's name -- not by its address (_ADDON_DEBRID)
			via_debrid = ''
			if item.get('stremio_slot') and hoster in ('', 'Direct', netloc.split('.')[0].title()):
				hoster = self._addon_hoster(item) or hoster
				via_debrid = self._addon_debrid(item)
			# LOCAL PATCH 2026-11-22 (user): no '[FSL]' / '[FSL-V2]' / '[PIXELDRAIN]' in front of the name any more -- the mirror
			# shows in the Hoster column only
			url_hash = hashlib.sha1(url_part.encode('utf-8')).hexdigest()[:24]
			out = {
				'name': display_source,                 # full filename when available
				'display_name': display_name,
				'quality': quality,
				'size': size_gb,
				'size_label': size_str if size_str else ('%.2f GB' % size_gb if size_gb > 0 else '0.00 GB'),
				'extraInfo': extra_info,
				'url_dl': url,
				'id': url_hash,
				'debrid': self.scrape_provider,
				'scrape_provider': self.scrape_provider,
				'direct': True,
				'direct_debrid_link': True,
				'local': False,
				'source': self.scrape_provider,
				'hash': url_hash,
				'hoster': hoster,                       # PixelDrain / FSL-V2 / etc.; consumed by windows/sources.py
				'release_key': row['release_key'],      # LOCAL PATCH 2026-11-09: the listed name, for _merge_host_copies
				'video_size': self._byte_size(item.get('video_size')),   # LOCAL PATCH 2026-11-02: see _inherit_prerelease
			}
			# Preserve HDHub4u's source-layout hint so the results sorter can prefer an episode file from a season pack
			# when the normal quality/provider/size sort keys are otherwise equal.
			if item.get('pack_priority') is not None: out['pack_priority'] = item['pack_priority']
			if item.get('stremio_slot'): out['stremio_slot'] = item['stremio_slot']
			elif item.get('site'): out['site'] = item['site']   # LOCAL PATCH 2026-11-26: see results()._take
			# LOCAL PATCH 2026-11-23 (user): the debrid a slot's own link plays through -- the results window shows it under the
			# quality with CACHED as the Hoster, like a torrent row. 'hoster' keeps 'TorBox' (SmartPlay pins match on it).
			if via_debrid: out['via_debrid'] = via_debrid
			# LOCAL PATCH 2026-11-18: a link page resolved at play time (sources.resolve_sources), not the file itself
			if item.get('resolver'): out['resolver'] = item['resolver']
			# LOCAL PATCH 2026-11-22 (user): the site tag trimmed off the name stays the Group ('[AnimeDubHindi] Naruto ...' showed
			# ANIMEDUBHINDI there) -- only when the name names no group of its own, as release_group read it before the trim.
			# The results window and the release-group sort read 'release_group' before parsing the name.
			if row['site_tag'] and not source_utils.release_group(parse_source): out['release_group'] = row['site_tag']
			return out
		except Exception:
			from modules.kodi_utils import log_row_error
			return log_row_error('http_streams._make_item')   # LOCAL PATCH 2026-11-08: logged once, the row skipped

	# Common audio-language tokens worth detecting. Order matters — first match
	# wins per language to avoid double-counting. Each entry: (display_label,
	# list-of-lowercase-patterns-to-match-as-whole-words-or-bracketed).
	_LANG_PATTERNS = (
		('HINDI',     ('hindi', 'hin')),
		('ENGLISH',   ('english', 'eng')),
		('TAMIL',     ('tamil', 'tam')),
		('TELUGU',    ('telugu', 'tel')),
		('MALAYALAM', ('malayalam', 'mal')),
		('KANNADA',   ('kannada', 'kan')),
		('BENGALI',   ('bengali', 'ben')),
		('PUNJABI',   ('punjabi', 'pun')),
		('MARATHI',   ('marathi', 'mar')),
		('GUJARATI',  ('gujarati', 'guj')),
		('URDU',      ('urdu', 'urd')),
		('SPANISH',   ('spanish', 'spa', 'esp')),
		('FRENCH',    ('french', 'fre', 'fra')),
		('GERMAN',    ('german', 'ger', 'deu')),
		('ITALIAN',   ('italian', 'ita')),
		('RUSSIAN',   ('russian', 'rus')),
		('JAPANESE',  ('japanese', 'jap', 'jpn')),
		('KOREAN',    ('korean', 'kor')),
		('CHINESE',   ('chinese', 'chi', 'zho')),
		('ARABIC',    ('arabic', 'ara')),
		('TURKISH',   ('turkish', 'tur')),
		('DUTCH',     ('dutch', 'dut', 'nld')),
		('POLISH',    ('polish', 'pol')),
		('PORTUGUESE',('portuguese', 'por')),
	)

	@classmethod
	def _extract_languages(cls, *candidates):
		"""Scan candidate strings for audio-language tokens. Returns a
		deduplicated ordered list of UPPERCASE language labels found.
		Detection uses word-boundary regex against the lowercased input so
		that random substrings (e.g. 'china' inside 'machinaut') don't false-match."""
		import re as _re
		hits = []
		seen = set()
		joined = ' '.join((c or '') for c in candidates if c).lower()
		if not joined: return hits
		for label, pats in cls._LANG_PATTERNS:
			for pat in pats:
				# \b doesn't work next to brackets/punctuation in some cases; use a
				# permissive boundary that accepts start/end/non-letter on each side.
				if _re.search(r'(?<![a-z])' + _re.escape(pat) + r'(?![a-z])', joined):
					if label not in seen:
						hits.append(label)
						seen.add(label)
					break
		return hits

	@staticmethod
	def _extract_size(*candidates):
		"""Best-effort size extractor — try each candidate string for a size pattern
		and return (size_gb_float, size_label_str). Returns (0.0, '') if nothing parses.
		Patterns recognized (case-insensitive):
		    "[2.1 GB]"             — HDHub4u branch format with brackets
		    "💾 9.58 GB"           — Stremio behaviorHints (emoji + size)
		    "Size: 2.1 GB"         — generic label
		    "2.1 GB" / "2.1GB"     — bare format
		    "2100 MB" / "1.2 TB"   — unit variants
		"""
		import re as _re
		# Order patterns by specificity (most specific first to avoid false positives).
		patterns = (
			_re.compile(r'\[([\d.,]+)\s*(GB|GiB|MB|MiB|TB|TiB)\]', _re.IGNORECASE),
			_re.compile(r'💾\s*([\d.,]+)\s*(GB|GiB|MB|MiB|TB|TiB)', _re.IGNORECASE),
			_re.compile(r'(?:size|file\s*size)\s*[:\-]\s*([\d.,]+)\s*(GB|GiB|MB|MiB|TB|TiB)', _re.IGNORECASE),
			_re.compile(r'(?<![A-Za-z0-9])([\d.,]+)\s*(GB|GiB|MB|MiB|TB|TiB)(?![A-Za-z0-9])', _re.IGNORECASE),
		)
		for candidate in candidates:
			if not candidate or not isinstance(candidate, str): continue
			text = candidate.strip()
			if not text: continue
			for pat in patterns:
				m = pat.search(text)
				if not m: continue
				try:
					num = source_utils.size_number(m.group(1))   # LOCAL PATCH 2026-10-19: '2,750 MB' is thousands, '2,75 GB' decimal
					unit = m.group(2).upper().rstrip('B').rstrip('I')  # GB/GIB → G, MB/MIB → M
					if unit == 'G': size_gb = num
					elif unit == 'M': size_gb = num / 1024.0
					elif unit == 'T': size_gb = num * 1024.0
					else: continue
					if size_gb <= 0 or size_gb > 500: continue  # sanity: >500GB is bogus (4K remux ceiling)
					return round(size_gb, 2), '%.2f GB' % size_gb
				except Exception: continue
		return 0.0, ''

	_is_valid_http_url = staticmethod(source_utils.is_valid_http_url)   # LOCAL PATCH 2026-10-19: shared copy

	def _return(self):
		self.sources = self._merge_host_copies(self.sources)
		if self.publish: source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources

	# LOCAL PATCH 2026-10-24: one row per release, the other hosts kept as fallbacks. The same file is listed on up to three
	# hosts (same name, size and quality); dedup alone would let a dead or capped host fail the release. Copies ride on the
	# kept row as 'url_fallbacks', which sources.resolve_sources tries in order (direct_url_alive).
	# LOCAL PATCH 2026-11-19: user preference: FSL first, FSLv2 second, PixelDrain third. Earlier measurements on Rings of
	# Power S03E01 found FSL slower (0.4-8 MB/s) and FSLv2 dead in 5 of 7 links (R2 403); the user's preferred order still
	# keeps the other hosts as automatic fallbacks if the selected mirror does not answer.
	@staticmethod
	def _host_rank(src):
		host = re.sub(r'[^a-z0-9]', '', str(src.get('hoster') or '').lower())
		if host.startswith('fslv2'): return 1
		if host.startswith('fsl'): return 0
		if 'pixeldrain' in host or 'pixeldrain' in str(src.get('url_dl') or src.get('url') or '').lower(): return 2
		return 3

	@classmethod
	def _merge_host_copies(cls, sources):
		if not sources: return sources
		groups, order = {}, []
		for s in sources:
			# LOCAL PATCH 2026-11-09: keyed on the LISTED name (release_key) -- an FSL copy may carry the file's full name and its
			# PixelDrain twin the cut one; rows cached before it existed have only 'name'
			k = (s.get('quality'), s.get('size'), s.get('release_key') or re.sub(r'[^a-z0-9]', '', str(s.get('name') or '').lower())) if s.get('size') else id(s)
			if k not in groups:
				groups[k] = []
				order.append(k)
			groups[k].append(s)
		out = []
		for k in order:
			group = sorted(groups[k], key=cls._host_rank)   # stable: the providers' own order within a rank
			keep = group[0]
			fallbacks = [u for u in ((g.get('url_dl') or g.get('url')) for g in group[1:]) if u and u != keep.get('url_dl')]
			if fallbacks: keep['url_fallbacks'] = fallbacks
			out.append(keep)
		return out

	@staticmethod
	def direct_url_alive(url, timeout=4):
		"""LOCAL PATCH 2026-10-24: does a direct link answer with the file? True for 200 / 206 that is not an HTML page
		(PixelDrain's cap and the hosts' error pages are HTML), else False. A 'url|Header=value' link sends its Kodi headers.
		LOCAL PATCH 2026-11-18: asked the way the PLAYER asks -- an open-ended 'bytes=0-' read (headers only: stream=True and
		closed unread), not a 1-byte range. HubCloud's 'File' links (Cloudflare Workers) answer 206 to 'bytes=0-0' but 403 to
		'bytes=0-' / no Range / HEAD: the 1-byte check passed them and Kodi then failed on every one (Harry Potter and the
		Goblet of Fire, 6 of 6 rows, 53 s, 2026-11-18 21:03)."""
		from urllib.parse import parse_qsl
		base, _, extra = (url or '').partition('|')
		headers = dict(parse_qsl(extra)) if extra else {}
		headers.setdefault('User-Agent', 'Mozilla/5.0')
		headers['Range'] = 'bytes=0-'
		try:
			r = make_session().get(base, headers=headers, timeout=timeout, stream=True, allow_redirects=True)
			ok = r.status_code in (200, 206) and 'text/html' not in (r.headers.get('Content-Type') or '').lower()
			r.close()
			return ok
		except Exception: return False
