# -*- coding: utf-8 -*-
# TRUMP WON
import xbmc, xbmcgui, xbmcplugin, xbmcvfs, xbmcaddon
import os
import threading
from urllib.parse import urlencode, unquote, quote_plus

# LOCAL PATCH 2026-10-10: each theme has its own 'icon' -- a swatch in resources/media/themes/<icon>.png, drawn from these
# colours by addon_patches/harness/theme_swatches.py (re-run it after adding or changing a theme). Not the media repo:
# it has no themes folder.
def addon_themes():
	# LOCAL PATCH 2026-11-12: each theme also sets DeadLight's accent (rings, bars, chips) and focus plate (dark text on it),
	# read by base_window.set_theme via theme_colours(). The neutral greys share crimson on a light grey plate; the tinted
	# themes take an accent and a plate tint from their own hue.
	return [{'name': 'Light', 'value': ('FF434343', 'FF2E2E2E'), 'icon': 'light', 'accent': 'E5484D', 'focus': 'E8E8EA'},
			{'name': 'Medium', 'value': ('FF373737', 'FF4a4347'), 'icon': 'medium', 'accent': 'E5484D', 'focus': 'E8E8EA'},
			{'name': 'Dark', 'value': ('FF1F2020', 'FF4F4F4F'), 'icon': 'dark', 'accent': 'E5484D', 'focus': 'E8E8EA'},
			# LOCAL PATCH 2026-09-27: near-black, for the white source-info logos
			{'name': 'Black', 'value': ('FF141517', 'FF3A3D44'), 'icon': 'black', 'accent': 'E5484D', 'focus': 'E8E8EA'},
			# LOCAL PATCH 2026-10-09: tinted darks, for LCD / QLED panels. Not pure black: local dimming blooms a halo round
			# white text on it; a slight tint hides the backlight glow. Each second value is the unfocused-button shade, kept
			# dark enough for the E8E8EA labels.
			{'name': 'Midnight', 'value': ('FF101826', 'FF2D3B55'), 'icon': 'midnight', 'accent': '4C9AFF', 'focus': 'D6E4FF'},
			{'name': 'Slate', 'value': ('FF1C222D', 'FF3A4456'), 'icon': 'slate', 'accent': '5EB1EF', 'focus': 'DCE6F2'},
			{'name': 'Plum', 'value': ('FF1C1522', 'FF42344F'), 'icon': 'plum', 'accent': 'B57EDC', 'focus': 'E9DDF5'},
			{'name': 'Forest', 'value': ('FF122019', 'FF2E4A3C'), 'icon': 'forest', 'accent': '3DBE8B', 'focus': 'D9F0E4'},
			{'name': 'Mocha', 'value': ('FF201B18', 'FF4A3F38'), 'icon': 'mocha', 'accent': 'D9734E', 'focus': 'F0E3D6'}]

def theme_colours(theme):
	"""(accent, focus plate) as RRGGBB for a window_theme value (AARRGGBB, opacity first): matched on the RGB so the opacity
	setting does not matter. A theme not in the list gets the neutral pair."""
	rgb = (theme or '')[-6:].upper()
	match = next((i for i in addon_themes() if i['value'][0][-6:].upper() == rgb), None)
	return (match['accent'], match['focus']) if match else ('E5484D', 'E8E8EA')

def theme_icon(icon):
	return os.path.join(addon_info('path'), 'resources', 'media', 'themes', icon + '.png')

def addon_themes_opacity():
	return [{'name': '100%', 'value': 'FF'}, {'name': '95%', 'value': 'F2'}, {'name': '90%', 'value': 'E6'}, {'name': '85%', 'value': 'D9'}, {'name': '80%', 'value': 'CC'},
			{'name': '75%', 'value': 'BF'}, {'name': '70%', 'value': 'B3'}, {'name': '65%', 'value': 'A6'}, {'name': '60%', 'value': '99'}, {'name': '55%', 'value': '8C'},
			{'name': '50%', 'value': '80'},
			# LOCAL PATCH 2026-10-23: lower levels (more of what is behind shows through the panels)
			{'name': '45%', 'value': '73'}, {'name': '40%', 'value': '66'}, {'name': '35%', 'value': '59'}, {'name': '30%', 'value': '4D'},
			{'name': '25%', 'value': '40'}, {'name': '20%', 'value': '33'}]

def random_valid_type_check():
	return {'build_movie_list': 'movie', 'build_tvshow_list': 'tvshow', 'build_season_list': 'season', 'build_episode_list': 'episode',
	'build_in_progress_episode': 'single_episode', 'build_recently_watched_episode': 'single_episode', 'build_next_episode': 'single_episode',
	'build_my_calendar': 'single_episode', 'build_trakt_lists': 'trakt_list',
	'trakt.list.build_trakt_list': 'trakt_list', 'build_trakt_lists_contents': 'trakt_list', 'personal_lists.build_personal_list': 'personal_list',
	'build_personal_lists_contents': 'personal_list', 'tmdblist.build_tmdb_list': 'tmdb_list', 'build_tmdb_lists_contents': 'tmdb_list'}

def random_episodes_check():
	return {'build_in_progress_episode': 'episode.progress', 'build_recently_watched_episode': 'episode.recently_watched',
	'build_next_episode': 'episode.next', 'build_my_calendar': 'episode.trakt'}

def extras_button_label_values():
	return {'movie':
				{'movies_play': 'Play', 'show_trailers': 'Trailer', 'show_images': 'Images',  'show_extrainfo': 'Extra Info', 'show_genres': 'Genres',
				'show_director': 'Director', 'show_options': 'Options', 'show_recommended': 'Recommended', 'show_related': 'Related', 'show_more_like_this': 'More Like This',
				'show_similar': 'Similar', 'show_reviews': 'Reviews', 'show_comments': 'Comments', 'show_trivia': 'Trivia', 'show_blunders': 'Blunders',
				'show_year': 'More Year', 'show_genre': 'More Genres', 'show_network': 'More Network',
				'show_trakt_manager': 'Trakt Lists', 'show_personallists_manager': 'Personal Lists', 'show_tmdb_manager': 'TMDb Lists',
				'show_favorites_manager': 'Favorites Lists', 'playback_choice': 'Play Options', 'show_plot': 'Plot', 'show_keywords': 'Keywords',
				'show_in_trakt_lists': 'In Trakt Lists', 'close_all': 'Close', 'none': 'None (hidden)'},
			'tvshow':
				{'tvshow_browse': 'Browse', 'show_trailers': 'Trailer', 'show_images': 'Images', 'show_extrainfo': 'Extra Info', 'show_genres': 'Genres',
				'play_nextep': 'Play Next', 'show_options': 'Options', 'show_recommended': 'Recommended', 'show_related': 'Related', 'show_more_like_this': 'More Like This',
				'show_similar': 'Similar', 'show_reviews': 'Reviews', 'show_comments': 'Comments', 'show_trivia': 'Trivia', 'show_blunders': 'Blunders',
				'show_year': 'More Year', 'show_genre': 'More Genres', 'show_network': 'More Network',
				'show_trakt_manager': 'Trakt Lists', 'show_personallists_manager': 'Personal Lists', 'show_tmdb_manager': 'TMDb Lists',
				'show_favorites_manager': 'Favorites Lists', 'play_random_episode': 'Play Random', 'show_plot': 'Plot', 'show_keywords': 'Keywords',
				'show_in_trakt_lists': 'In Trakt Lists', 'close_all': 'Close', 'none': 'None (hidden)'}}

def extras_items():
	# LOCAL PATCH 2026-11-07: no 'Plot' -- the Extras header shows tagline + plot; row 2050 stays hidden (windows/extras)
	return [{'name': 'Cast', 'value': 2051}, {'name': 'Recommended', 'value': 2052}, {'name': 'Related', 'value': 2053},
	{'name': 'More Like This', 'value': 2054}, {'name': 'Similar', 'value': 2055}, {'name': 'Reviews', 'value': 2056}, {'name': 'Comments', 'value': 2057},
	{'name': 'Trivia', 'value': 2058}, {'name': 'Blunders', 'value': 2059}, {'name': 'Parental Guide', 'value': 2060}, {'name': 'In Trakt Lists', 'value': 2061},
	{'name': 'Videos', 'value': 2062}, {'name': 'More from Year', 'value': 2063}, {'name': 'More from Genres', 'value': 2064}, {'name': 'More from Networks', 'value': 2065},
	{'name': 'More from Collection', 'value': 2066}, {'name': 'AniList Recommended', 'value': 2067}]

def context_menu_items():
	return [
	{'name': 'Extras', 'value': 'extras'}, {'name': 'Options', 'value': 'options'}, {'name': 'Play Options', 'value': 'playback_options'},
	{'name': 'Browse Movie Set', 'value': 'browse_movie_set'}, {'name': 'Browse TV Seasons', 'value': 'browse_seasons'},
	{'name': 'Browse Season Episodes', 'value': 'browse_episodes'}, {'name': 'Browse Recommended', 'value': 'recommended'}, {'name': 'Browse Related', 'value': 'related'},
	{'name': 'Browse More Like This', 'value': 'more_like_this'}, {'name': 'Browse Similar', 'value': 'similar'}, {'name': 'Browse AniList Recommended', 'value': 'anilist_recommended'}, {'name': 'Watch Order', 'value': 'watch_order'}, {'name': 'In Trakt Lists', 'value': 'in_trakt_list'},
	{'name': 'Trakt Lists Manager', 'value': 'trakt_manager'}, {'name': 'Anime List Manager', 'value': 'anilist_manager'}, {'name': 'MDBList Manager', 'value': 'mdblist_manager'}, {'name': 'SIMKL Manager', 'value': 'simkl_manager'}, {'name': 'Drop Show', 'value': 'drop_show'}, {'name': 'Personal Lists Manager', 'value': 'personal_manager'},
	{'name': 'TMDb Lists Manager', 'value': 'tmdb_manager'}, {'name': 'Favorites Manager', 'value': 'favorites_manager'}, {'name': 'Mark Watched/Unwatched', 'value': 'mark_watched'},
	{'name': 'Unmark Previous Watched Episode', 'value': 'unmark_previous_episode'}, {'name': 'Exit List', 'value': 'exit'}, {'name': 'Refresh Widgets', 'value': 'refresh'},
	{'name': 'Reload Widgets', 'value': 'reload'}]

def rescrape_items():
	return [
	{'name': 'Rescrape With No Cache Check', 'value': 'cache_ignored'},
	{'name': 'Rescrape With IMDb Year Data', 'value': 'imdb_year'},
	{'name': 'Rescrape With All Scrapers', 'value': 'with_all'},
	{'name': 'Rescrape With Episode Group', 'value': 'episode_group'},
	{'name': 'Rescrape with Filters Ignored', 'value': 'ignore_filters'}]

def video_extensions():
	return ('m4v', '3g2', '3gp', 'nsv', 'tp', 'ts', 'ty', 'pls', 'rm', 'rmvb', 'mpd', 'ifo', 'mov', 'qt', 'divx', 'xvid', 'bivx', 'vob', 'nrg', 'img', 'iso', 'udf', 'pva',
			'wmv', 'asf', 'asx', 'ogm', 'm2v', 'avi', 'bin', 'dat', 'mpg', 'mpeg', 'mp4', 'mkv', 'mk3d', 'avc', 'vp3', 'svq3', 'nuv', 'viv', 'dv', 'fli', 'flv', 'wpl',
			'xspf', 'vdr', 'dvr-ms', 'xsp', 'mts', 'm2t', 'm2ts', 'evo', 'ogv', 'sdp', 'avs', 'rec', 'url', 'pxml', 'vc1', 'h264', 'rcv', 'rss', 'mpls', 'mpl', 'webm',
			'bdmv', 'bdm', 'wtv', 'trp', 'f4v', 'pvr', 'disc')

def image_extensions():
	return ('jpg', 'jpeg', 'jpe', 'jif', 'jfif', 'jfi', 'bmp', 'dib', 'png', 'gif', 'webp', 'tiff', 'tif',
			'psd', 'raw', 'arw', 'cr2', 'nrw', 'k25', 'jp2', 'j2k', 'jpf', 'jpx', 'jpm', 'mj2')

def kodi_progress_background():
	return xbmcgui.DialogProgressBG()

def get_visibility(obj):
	return xbmc.getCondVisibility(obj)

def get_infolabel(label):
	return xbmc.getInfoLabel(label)

def kodi_actor():
	return xbmc.Actor

def translate_path(_path):
	return xbmcvfs.translatePath(_path)

# LOCAL PATCH 2026-05-26: xbmc.Monitor and xbmc.Player as module-level singletons; one shared instance per process is
# fine for these abort/wait/playback-state checks.
_kodi_monitor_instance = None
def kodi_monitor():
	global _kodi_monitor_instance
	if _kodi_monitor_instance is None:
		_kodi_monitor_instance = xbmc.Monitor()
	return _kodi_monitor_instance

_kodi_player_instance = None
def kodi_player():
	global _kodi_player_instance
	if _kodi_player_instance is None:
		_kodi_player_instance = xbmc.Player()
	return _kodi_player_instance

def kodi_dialog():
	return _GuardedDialog(xbmcgui.Dialog())

class _GuardedDialog(object):
	"""LOCAL PATCH 2026-11-01: xbmcgui.Dialog whose prompts (keyboard input, browse, select, yes/no) run inside
	busy_guard.paused(), so a context action's spinner is not drawn over them. A notification does not take input and
	is passed straight through."""
	_PASS = ('notification',)
	def __init__(self, dialog): self._dialog = dialog
	def __getattr__(self, name):
		attr = getattr(self._dialog, name)
		if name in self._PASS or not callable(attr): return attr
		def call(*args, **kwargs):
			from modules.busy_guard import paused
			with paused(): return attr(*args, **kwargs)
		return call

def addon_info(info):
	return xbmcaddon.Addon('plugin.video.deadlight').getAddonInfo(info)

# LOCAL PATCH 2026-09-06: the display name from addon.xml, not hardcoded, so a rename needs no code change. Cached in a
# window property by SetAddonConstants like the siblings below.
def addon_name():
	return get_property('deadlight.addon_name') or addon_info('name')

def addon_version():
	return get_property('deadlight.addon_version') or addon_info('version')

def addon_path():
	return get_property('deadlight.addon_path') or addon_info('path')

def addon_profile():
	return get_property('deadlight.addon_profile') or translate_path(addon_info('profile'))

def addon_icon():
	return get_property('deadlight.addon_icon') or translate_path(addon_info('icon'))

def addon_icon_mini():
	return get_property('deadlight.addon_icon_mini') or os.path.join(addon_info('path'), 'resources', 'media', 'addon_icons', 'minis',
														os.path.basename(translate_path(addon_info('icon'))))

def addon_fanart():
	return get_property('deadlight.addon_fanart') or translate_path(addon_info('fanart'))

# LOCAL PATCH 2026-09-14: artwork keys on media.username/media.location, not on the updater's coordinates (see the
# settings_cache note). The literals are a real fallback, not a duplicate of the settings defaults: the properties are
# seeded by the service's settings sync, so on a first run (or a plugin call racing it) they are empty.
def media_base():
	return 'https://raw.githubusercontent.com/%s/%s/main/packages/media' \
			% (get_property('deadlight.media.username') or 'pitou212',
			   get_property('deadlight.media.location') or 'deadlight-media')

# LOCAL PATCH 2026-10-23: menu icons in white (packages/media/icons_white). A new folder, not recoloured files: Kodi
# caches remote images by URL, so recoloured files at the old URLs would stay teal on every device.
def get_icon(image_name, image_folder='icons_white', image_type='png'):
	return '%s/%s/%s.%s' % (media_base(), image_folder, image_name, image_type)

def get_addon_fanart():
	return get_property('deadlight.default_addon_fanart') or addon_fanart()

# LOCAL PATCH 2026-09-26: fast path for build_url (a TV tile builds ~18 URLs). _URL_SAFE is exactly quote_plus's
# always-safe set (safe=''), so skipping the call for such a value yields the same bytes. The output MUST stay
# byte-identical to urlencode(): these URLs are also favourites, widget paths and Kodi's directory cache keys.
# Anything not a plain dict of str/int values goes to urlencode itself.
_URL_SAFE = frozenset('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.-~')

def _url_quote(value):
	return _url_quote_str(str(value))

# LOCAL PATCH 2026-11-08: memoised -- a tile's ~18 URLs repeat its title, art and ids, so most quotes are repeats.
from functools import lru_cache as _lru_cache
@_lru_cache(maxsize=4096)
def _url_quote_str(value):
	return value if _URL_SAFE.issuperset(value) else quote_plus(value)

def build_url(url_params):
	if isinstance(url_params, dict):
		parts = []
		for k, v in url_params.items():
			if isinstance(k, bytes) or isinstance(v, bytes): break
			parts.append(_url_quote(k) + '=' + _url_quote(v))
		else: return 'plugin://plugin.video.deadlight/?' + '&'.join(parts)
	return 'plugin://plugin.video.deadlight/?%s' % urlencode(url_params)

# LOCAL PATCH 2026-11-16: Kodi 21 takes an `offscreen` flag here (Fen Light passed True everywhere); Kodi 22 (Piers)
# takes none and raised "ListItem_getVideoInfoTag expected 0 arguments, got 1" -- every list with a Next Page entry
# failed. The flag is passed while Kodi accepts it and dropped for good (this process) from the first refusal.
_VIDEO_TAG_FLAG = True

def video_info_tag(listitem):
	global _VIDEO_TAG_FLAG
	if _VIDEO_TAG_FLAG:
		try: return listitem.getVideoInfoTag(True)
		except TypeError: _VIDEO_TAG_FLAG = False
	return listitem.getVideoInfoTag()

def add_dir(handle, url_params, list_name, icon_image='folder', fanart_image=None, isFolder=True):
	# LOCAL PATCH 2026-11-01: a WIDGET's Next Page item records its URL for the service to warm later (page_prefetch) -- every
	# paged list makes that item here, so one hook covers them all
	if icon_image == 'nextpage':
		try:
			from modules.page_prefetch import note_widget_url
			note_widget_url(url_params)
		except Exception: pass
	fanart = fanart_image or get_addon_fanart()
	icon = get_icon(icon_image)
	url = build_url(url_params)
	listitem = make_listitem()
	listitem.setLabel(list_name)
	listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': fanart})
	info_tag = video_info_tag(listitem)
	info_tag.setPlot(' ')
	add_item(handle, url, listitem, isFolder)

def make_listitem():
	return xbmcgui.ListItem(offscreen=True)

def add_item(handle, url, listitem, isFolder):
	from modules import widget_reload
	widget_reload.note_rows((url,))
	xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder)

def add_items(handle, item_list):
	from modules import widget_reload
	widget_reload.note_rows(i[0] for i in item_list)
	xbmcplugin.addDirectoryItems(handle, item_list)

def set_content(handle, content):
	xbmcplugin.setContent(handle, content)

def set_category(handle, label):
	xbmcplugin.setPluginCategory(handle, label)

def end_directory(handle, cacheToDisc=True):
	xbmcplugin.endOfDirectory(handle, cacheToDisc=cacheToDisc)
	from modules import widget_reload   # LOCAL PATCH 2026-11-01: what a widget listed
	widget_reload.record_widget()

def set_view_mode(view_type, content='files', is_external=None, refreshed=False):
	if not get_property('deadlight.use_viewtypes') == 'true': return
	if is_external == None: is_external = external()
	if is_external: return
	view_id = get_property('deadlight.%s' % view_type) or None
	if not view_id: return
	# LOCAL PATCH 2026-10-19: Jump To's 1 s settle wait (refreshed) lives here, after the checks above, so with view types
	# off it does not delay routing() and the page prefetch.
	if refreshed: sleep(1000)
	try:
		hold = 0
		sleep(100)
		while not container_content() == content:
			hold += 1
			if hold < 3000: sleep(1)
			else: return
		execute_builtin('Container.SetViewMode(%s)' % view_id)
	except: return


def remove_keys(dict_item, dict_removals):
	for k in dict_removals: dict_item.pop(k, None)
	return dict_item


def _scrub(text):
	"""LOCAL PATCH 2026-11-18: every DeadLight log line goes through utils.redact_url -- a URL password or a secret query value
	(api keys, tokens, an AIOStreams manifest's config) never reaches kodi.log, also where a line formats an exception's text
	itself (player._read_file_chapters). Only a line that could hold one ('@' or '=') is looked at."""
	text = str(text)
	if '@' not in text and '=' not in text: return text
	try:
		from modules.utils import redact_url
		return redact_url(text)
	except Exception: return text

def logger(heading, function):
	xbmc.log('###%s###: %s' % (heading, _scrub(function)), 1)

# LOCAL PATCH 2026-10-25 (4.0.5): diagnostics that run on hot paths log at Kodi's DEBUG level -- hidden unless Kodi's
# own debug logging is on (Settings > System > Logging), so a normal kodi.log is not flooded.
def logger_debug(heading, function):
	xbmc.log('###%s###: %s' % (heading, _scrub(function)), 0)

# LOCAL PATCH 2026-10-09: the row builders drop a row on ANY exception (a bare except per row), right for one bad title
# but it hides a whole-list failure. Called from inside those excepts: logs the FIRST error each builder swallows in
# this plugin run, with where it was raised; the row is still skipped.
_ROW_ERRORS_SEEN = set()

def _log_first(where, heading, outcome):
	if (heading, where) in _ROW_ERRORS_SEEN: return
	_ROW_ERRORS_SEEN.add((heading, where))
	try:
		import sys, traceback
		etype, err, tb = sys.exc_info()
		frames = traceback.extract_tb(tb) if tb else []
		at = '%s:%d' % (frames[-1].filename.replace('\\', '/').rsplit('/lib/', 1)[-1], frames[-1].lineno) if frames else '?'
		# LOCAL PATCH 2026-11-08: utils.safe_err, never str(err) -- a request error's text carries its URL, and a Real-Debrid
		# URL carries the account token (auth_token=)
		from modules.utils import safe_err
		logger(heading, '%s: %s at %s (first of this run; %s)' % (where, safe_err(err) if err is not None else etype, at, outcome))
	except Exception: pass

def log_row_error(builder):
	_log_first(builder, 'row error', 'the row was skipped')

# LOCAL PATCH 2026-11-08: the same for a feature that catches an exception and carries on with nothing (a debrid cloud
# listing, a Direct Streams row, a provider), so a source family cannot vanish silently. Once per place per plugin run.
def log_swallowed(where, outcome='carried on without it'):
	_log_first(where, 'caught', outcome)

# REVERTED 2026-09-04: NOT a module-level singleton like kodi_monitor/kodi_player above. xbmcgui.Window(10000) is a
# HANDLE ON A LIVE GUI WINDOW whose validity is not ours to assume, and service.py / the player live far longer than
# one call. A held handle would save under 1 ms per plugin call -- not worth any lifetime risk. Constructing one per
# access (as upstream) is always valid.
def kodi_window():
	return xbmcgui.Window(10000)

def get_property(prop):
	return kodi_window().getProperty(prop)

# LOCAL PATCH 2026-10-19: shared by the rate-limit breakers of OMDb, MDBList, AniList, TVmaze and AnimeSchedule (a
# Home-window property holding the time the cooldown ends, so every plugin process and the service share it).
def cooldown_active(prop):
	"""True while the cooldown stored in window property `prop` has not run out."""
	try:
		import time
		until = get_property(prop)
		return bool(until) and time.time() < float(until)
	except Exception: return False

def start_cooldown(prop, secs):
	import time
	set_property(prop, str(time.time() + secs))

def set_property(prop, value):
	return kodi_window().setProperty(prop, value)

def clear_property(prop):
	return kodi_window().clearProperty(prop)


def addon(addon_id='plugin.video.deadlight'):
	return xbmcaddon.Addon(id=addon_id)

def addon_installed(addon_id):
	return get_visibility('System.HasAddon(%s)' % addon_id)

def addon_enabled(addon_id):
	return get_visibility('System.AddonIsEnabled(%s)' % addon_id)

def container_content():
	return get_infolabel('Container.Content')

def set_sort_method(handle, method):
	xbmcplugin.addSortMethod(handle, {'episodes': 24, 'files': 5, 'label': 2, 'none': 0}[method])

# LOCAL PATCH 2026-09-04: make_session returns a LAZY session. Every plugin call is a fresh process, and `import
# requests` costs ~0.4 s; API modules call this at import, so a cache-warm list that makes no http call would still pay
# it. requests enters the add-on ONLY through this function; the proxy forwards attribute access, which is all any
# caller does. extra_mounts: tmdb_api/tmdblist_api need a second pooled prefix for their failover host (without a
# module-level `import requests`).
# LOCKED, and it must stay locked: an unlocked check-then-build lets parallel threads on a cold session each import
# requests and build their OWN Session (separate connection pools).
class _LazySession:
	__slots__ = ('_url', '_extra_mounts', '_headers', '_session', '_lock')

	def __init__(self, url, extra_mounts, headers=None):
		self._url, self._extra_mounts, self._headers, self._session = url, extra_mounts, headers, None
		self._lock = threading.Lock()

	def _build(self):
		with self._lock:
			if self._session is not None: return self._session
			import requests
			session = requests.Session()
			adapter, retry = _shared_ssl_adapter(), _dropped_connection_retry()
			session.mount(self._url, adapter(pool_maxsize=100, max_retries=retry))
			for prefix in self._extra_mounts:
				session.mount(prefix, adapter(pool_maxsize=100, max_retries=retry))
			if self._headers: session.headers.update(self._headers)
			self._session = session
			return session

	def __getattr__(self, name):
		# _session/_lock are slots, so they resolve normally and never re-enter __getattr__.
		session = self._session
		if session is None: session = self._build()
		return getattr(session, name)

# LOCAL PATCH 2026-10-19: one SSL context per process, its CA bundle loaded ONCE. Kodi's requests 2.31 / urllib3 2.2.3
# build a fresh context per HTTPS connection and load certifi's whole bundle into it (~0.9 s CPU each), and a page
# opens ~20 connections. Verification is unchanged: urllib3's own default context (CERT_REQUIRED, hostname checked),
# same certifi bundle; ca_certs is cleared so urllib3 does not load it again.
_SSL_ADAPTER, _SSL_LOCK = None, threading.Lock()

# LOCAL PATCH 2026-11-26: ONE retry, on a fresh connection, when a POOLED connection turns out dead -- urllib3's
# ProtocolError ('Connection aborted.', RemoteDisconnected / ConnectionReset). With the language invoker reused (the box)
# these sessions live across plugin calls, so after a 20-30 min episode the first request of the next-episode hand-off
# went out on a socket the server had already closed: TorBox's pack resolve AND its cache check failed ('TorBox not
# answering', SmartPlay fell back to the picker), and Torrentio / Meteor / MediaFusion / theintrodb all failed in the same
# 30 ms (box log 2026-11-26 07:15 and 07:54). requests' default is no retry at all. Everything else keeps that default
# exactly: read timeouts and other read errors re-raise at once (read=False, same exception types, provider timeouts
# unchanged), connect errors count against connect=0 as before. Any method may retry: the request never got an answer,
# and the calls that POST (TorBox add, Trakt / MDBList sync) are safe to repeat.
_RETRY_CLASS = None

def _dropped_connection_retry():
	global _RETRY_CLASS
	if _RETRY_CLASS is None:
		from urllib3.util.retry import Retry
		from urllib3.exceptions import ProtocolError
		class DroppedConnectionRetry(Retry):
			def increment(self, method=None, url=None, response=None, error=None, _pool=None, _stacktrace=None):
				if isinstance(error, ProtocolError) and self.total:
					return self.new(total=self.total - 1)   # urllib3 discards the dead connection and opens a new one
				return super().increment(method, url, response, error, _pool, _stacktrace)
		_RETRY_CLASS = DroppedConnectionRetry
	return _RETRY_CLASS(total=1, connect=0, read=False, redirect=False, status=0, other=0, raise_on_status=False)
# LOCAL PATCH 2026-10-19: the 0xc0000409 crashes once blamed on the shared context were the fribb_mappings re-entry
# loop (see _season_cour_rows). The sealing below stays: urllib3 does write into the context per connection.
# LOCAL PATCH 2026-11-01 (cleanup): a failure below falls back to requests' own per-connection contexts.

def _shared_ssl_adapter():
	global _SSL_ADAPTER
	if _SSL_ADAPTER is not None: return _SSL_ADAPTER
	with _SSL_LOCK:
		if _SSL_ADAPTER is not None: return _SSL_ADAPTER
		import requests
		try:
			import ssl, certifi
			from urllib3.util.ssl_ import create_urllib3_context, ALPN_PROTOCOLS
			# LOCAL PATCH 2026-10-19 (crash fix): the shared context must be READ-ONLY once built. urllib3 writes to it on
			# EVERY connection -- set_alpn_protocols (frees and reallocates OpenSSL's ALPN buffer) and verify_mode -- and
			# one thread rewriting the buffer while another's handshake copies it is heap corruption (0xc0000409). Set once
			# here; the per-connection writes become no-ops. verify=False never reaches this context (see send()).
			def _base(name):   # a Python property (verify_mode) or a C getset descriptor (check_hostname), by version
				return next(vars(k)[name] for k in ssl.SSLContext.__mro__ if name in vars(k))
			_vm, _ch = _base('verify_mode'), _base('check_hostname')
			class _ReadOnlyContext(ssl.SSLContext):
				_sealed = False
				def set_alpn_protocols(self, protocols):
					if not self._sealed: super().set_alpn_protocols(protocols)
				@property
				def verify_mode(self): return _vm.__get__(self, type(self))
				@verify_mode.setter
				def verify_mode(self, value):
					if not self._sealed: _vm.__set__(self, value)
				@property
				def check_hostname(self): return _ch.__get__(self, type(self))
				@check_hostname.setter
				def check_hostname(self, value):
					if not self._sealed: _ch.__set__(self, value)
			context = create_urllib3_context()
			context.__class__ = _ReadOnlyContext
			context.load_verify_locations(certifi.where())
			context.set_alpn_protocols(ALPN_PROTOCOLS)
			context.verify_mode, context.check_hostname = ssl.CERT_REQUIRED, True
			context._sealed = True
		except Exception as e:
			logger('shared SSL context', 'not used (%s: %s) -- requests per-connection contexts instead' % (type(e).__name__, e))
			_SSL_ADAPTER = requests.adapters.HTTPAdapter   # anything unexpected: requests' own behaviour
			return _SSL_ADAPTER
		class SharedSSLAdapter(requests.adapters.HTTPAdapter):
			# urllib3 writes each request's verify setting INTO the context, so only default-verified requests use the
			# shared one; verify=False / a CA path goes through a plain adapter of its own.
			def send(self, request, **kwargs):
				if kwargs.get('verify', True) is not True:
					plain = self.__dict__.get('_plain')
					if plain is None: plain = self.__dict__['_plain'] = requests.adapters.HTTPAdapter(
						pool_connections=self._pool_connections, pool_maxsize=self._pool_maxsize, max_retries=self.max_retries)
					return plain.send(request, **kwargs)
				return super().send(request, **kwargs)
			def init_poolmanager(self, *args, **kwargs):
				kwargs['ssl_context'] = context
				return super().init_poolmanager(*args, **kwargs)
			def proxy_manager_for(self, *args, **kwargs):
				kwargs['ssl_context'] = context
				return super().proxy_manager_for(*args, **kwargs)
			def cert_verify(self, conn, url, verify, cert):
				super().cert_verify(conn, url, verify, cert)
				# verify=True means 'the default bundle' -- already in the context; a path or False keeps requests' handling
				if verify is True and url.lower().startswith('https'): conn.ca_certs, conn.ca_cert_dir = None, None
		_SSL_ADAPTER = SharedSSLAdapter
		return _SSL_ADAPTER

# headers: session-wide defaults, applied when the session is built. Do NOT use a module-level
# `session.headers.update(...)`: any attribute access builds the session (imports requests, ~0.4 s).
def make_session(url='https://', extra_mounts=(), headers=None):
	return _LazySession(url, extra_mounts, headers)

# LOCAL PATCH 2026-11-18: one reading of Kodi's 'link|Header=value&...' play URL for code that fetches the stream itself
# (sources._probe_stream, mkv_chapters), with a browser User-Agent unless the link names its own.
_STREAM_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'

def stream_request_parts(url):
	from urllib.parse import parse_qsl
	link, _, extra = (url or '').partition('|')
	headers = dict(parse_qsl(extra)) if extra else {}
	headers.setdefault('User-Agent', _STREAM_UA)
	return link, headers


def supported_media():
	return xbmc.getSupportedMedia('video')

def path_exists(path):
	return xbmcvfs.exists(path)

def open_file(_file, mode='r'):
	return xbmcvfs.File(_file, mode)


def delete_file(_file):
	xbmcvfs.delete(_file)


def list_dirs(location):
	return xbmcvfs.listdir(location)

def make_directory(path):
	xbmcvfs.mkdir(path)

def make_directories(path):
	xbmcvfs.mkdirs(path)

def sleep(time):
	return xbmc.sleep(time)

def execute_builtin(command, block=False):
	return xbmc.executebuiltin(command, block)

def current_skin():
	return xbmc.getSkinDir()

def get_window_id():
	return xbmcgui.getCurrentWindowId()

def current_window_object():
	return xbmcgui.Window(get_window_id())


def show_busy_dialog():
	return execute_builtin('ActivateWindow(busydialognocancel)')

def hide_busy_dialog(kodi_too=True):
	"""LOCAL PATCH 2026-11-22: kodi_too=False closes only DeadLight's own spinner (show_busy_dialog: busydialognocancel).
	'busydialog' is KODI's, shown while a plugin folder loads, and Kodi does not reopen it during that load -- a context
	action (busy_guard) or a window closing (base_window) that hid it while the next list loaded left that list with no
	loading card. Playback / resolve paths keep closing both."""
	execute_builtin('Dialog.Close(busydialognocancel)')
	if kodi_too: execute_builtin('Dialog.Close(busydialog)')


def close_all_dialog():
	execute_builtin('Dialog.Close(all,true)')

def run_addon(addon='plugin.video.deadlight', block=False):
	return execute_builtin('RunAddon(%s)' % addon, block)

# LOCAL PATCH 2026-11-15: a directory call is a widget or not by where it was CALLED from, decided once at its start
# (deadlight.py sets _EXTERNAL_CALL; invocation.begin resets it per call). The after-list steps (deadlight.py's exit
# check, rating backfills, stale refreshes, next-page warm, filler flags, scrape prewarm) asked the live window 2-4 s
# later -- after Back to Home they took an in-addon list for a widget, skipped their work and ended the reused
# interpreter (sys_exit_check), so the next click started a fresh one. Actions (handle -1) and the service keep the live
# answer. _external_live() is the window as it is now, for questions about what is on screen.
_EXTERNAL_CALL = None

# LOCAL PATCH 2026-11-17: with Reuse Language Invoker on, Kodi crashes (python3.8.dll, a STARTING interpreter) when it shuts
# down the idle reusable interpreter from another thread while widget interpreters start. A playback (any add-on's) makes
# Kodi invalidate every AF3 widget on OnPlay / OnResume / OnStop, so the first Home / Hub visit after it reloads them all at
# once -- and the show page's post-stop reload had left exactly that idle interpreter. The service sets this property on
# those announcements; while it is set, in-addon calls end their interpreter too (router.sys_exit_check); the first
# DeadLight widget call clears it (deadlight.py), as the reload burst has then begun.
WIDGETS_STALE_PROP = 'deadlight.widgets_stale'

def _external_live():
	return 'deadlight' not in get_infolabel('Container.PluginName')

def external():
	if _EXTERNAL_CALL is not None: return _EXTERNAL_CALL
	return _external_live()

# LOCAL PATCH 2026-08-09: shared synchronous auto-focus for browse lists (seasons: the one mid-way through; episodes:
# the first unwatched). Runs after end_directory: Kodi keeps the GUI live for the rest of the invocation, so we poll for
# the NEW container and issue SetFocus. Callers only invoke it when DeadLight owns the container, so the current
# window IS the list; gated on Container.NumItems == expected (the new list, not the stale previous one).
def autoscroll_focus(target_index, expected_count):
	# Focus item `target_index` (0-based) in flat list / wall views: match the focused container's NumItems (or
	# NumItems-1 for a skin ".." parent) and SetFocus into it.
	# AF3 "Combined" views are NOT supported: the episodes are in no addressable container, so SetFocus cannot reach them.
	# LOCAL PATCH 2026-11-08: a Combined view returns at once (the loop could never match and held every episode list
	# ~4 s); the skin enters the episodes from the first_unwatched hint (episodes._publish_first_unwatched).
	# Elsewhere ~1.2 s is plenty: a flat list is live well within that once endOfDirectory is sent.
	try:
		if not target_index or expected_count <= 1: return
		if 'Combined' in (get_infolabel('Container.Viewmode') or ''): return
		for _ in range(15):   # ~1.2 s max; exits early once the list is live + matched
			xbmc.sleep(80)
			try:
				win_id = xbmcgui.getCurrentWindowId()
				if win_id in (10000, 12005, 12006): continue  # home / fullscreen video / vis
				active_id = xbmcgui.Window(win_id).getFocusId()
				if not active_id: continue
				n = int(get_infolabel('Container(%d).NumItems' % active_id) or '0')
				if n == expected_count: offset = 0
				elif n == expected_count + 1: offset = 1   # skin prepends a parent ".." item
				else: continue   # focused control isn't our freshly-built list yet
			except Exception:
				continue
			xbmc.executebuiltin('SetFocus(%d,%d,absolute)' % (active_id, target_index + offset))
			return
	except: pass

def home():
	return xbmcgui.getCurrentWindowId() == 10000

def folder_path():
	return get_infolabel('Container.FolderPath')

def path_check(string):
	return string in unquote(folder_path())


def kodi_full_refresh():
	"""Every widget of every add-on, and the list on screen: Kodi's 'library updated' broadcast."""
	execute_builtin('UpdateLibrary(video,special://skin/foo)')

# The lists a watched change adds a title to or drops it from, reloaded with that title's widgets (refresh(titles=...)).
PROGRESS_LISTS = ('build_continue_watching', 'in_progress', 'next_episode', 'recently_watched')

def _deadlight_list_on_screen():
	return not home() and not _external_live()   # LOCAL PATCH 2026-11-15: what is on screen now, not the call's origin

# LOCAL PATCH 2026-11-05: Arctic Fuse 3's Combined / Combined Wall views show a second panel beside the main list, loaded
# from the focused row's folder (View_530-538_Content / View_560-566_Content), e.g. seasons in 527, the focused season's
# episodes in 537. Container.Refresh reloads the main list only, so with such a panel on screen the panel is reloaded
# beside it (_reload_side_panel), not every list (UpdateLibrary).
_SIDE_PANEL_SLOTS = (0, 1, 2, 3, 4, 6, 7, 8)   # N of main list 52N; its side panel is 53N (Combined) or 56N (Combined Wall)

def _side_panel_visible(window, slot):
	"""LOCAL PATCH 2026-11-06: asked of the window itself. Not Control.IsVisible(): it is read against the topmost MODAL
	dialog, and a plugin call runs under Kodi's busy dialog 10160, so it is always False there. Only the slot's two ids
	are asked: each missing control costs Kodi an 'EXCEPTION: Non-Existent Control' log line and ~20 ms."""
	for control_id in (530 + slot, 560 + slot):
		try:
			if window.getControl(control_id).isVisible(): return True
		except Exception: continue   # not in this view
	return False

def _reload_side_panel(window):
	"""LOCAL PATCH 2026-11-06: reload just the side panel. Its content is AF3's View_53N_Content: the window property
	ViewCombined.52N.Path while ViewCombined.52N.Directory is the folder on screen (both cleared when the window unloads).
	Kodi reloads a container when its path text changes, so the path gets a fresh &reload= token -- the widgets' trick
	(router pops it). True when reloaded; False in a Combined view whose panel AF3 still fills straight from the focused row
	(no property yet: nothing moved since the view opened) -- the caller then reloads everything; None otherwise."""
	import re, time
	folder = get_infolabel('Container.FolderPath')
	for slot in _SIDE_PANEL_SLOTS:
		key = 'ViewCombined.52%d.' % slot
		path = window.getProperty(key + 'Path')
		if not path or window.getProperty(key + 'Directory') != folder or not _side_panel_visible(window, slot): continue
		window.setProperty(key + 'Path', '%s&reload=%d' % (re.sub(r'&reload=[^&]*', '', path), int(time.time() * 1000)))
		return True
	return False if 'Combined' in get_infolabel('Container.Viewmode') else None

def _refresh_list_on_screen():
	container_refresh()
	try:
		if _reload_side_panel(xbmcgui.Window(xbmcgui.getCurrentWindowId())) is False: kodi_full_refresh()
	except Exception: pass

# LOCAL PATCH 2026-11-08: THE refresh after a change (check_refresh in the regression suite pins its behaviour).
#   lists:  path fragments of the lists / widgets that changed ('trakt_watchlist', 'anilist.list.'); none: all of them.
#   titles: tmdb id(s) whose watched / progress state changed -- adds the progress lists and every widget listing one of them.
#   screen: 'always' -- the DeadLight list on screen is refreshed too (Mark Watched, a cache rebuild); 'if_listed' -- only when
#           it is one of `lists` (a list manager's add / remove: the list being edited, not whatever else is on screen).
# Widgets reload one by one through AF3's tokens (modules/widget_reload); without them, everything is reloaded instead --
# for 'if_listed' only when the change touches the list on screen or the call came from outside DeadLight.
def refresh(*lists, titles=None, screen='always'):
	from modules.widget_reload import reload_widgets, id_list
	ids = id_list(titles) if titles is not None else []
	if ids: lists = tuple(lists) + PROGRESS_LISTS
	listed = screen == 'always' or not lists or any(path_check(p) for p in lists)
	if reload_widgets(*lists, tmdb_id=ids or None):
		if listed and _deadlight_list_on_screen(): _refresh_list_on_screen()
	elif listed or external(): kodi_full_refresh()

# LOCAL PATCH 2026-09-28: automatic widget reloads, coalesced. After playback several arrive at once (the player's,
# then each sync service that waited on is_playing()), and overlapping interpreter bursts deadlock Kodi 21's Python.
# The first reload goes through at once; any within `window` seconds collapse into ONE trailing reload at its end.
# 15 s because the syncs spread over ~11 s after a long playback. Not simply dropped: a sync asks AFTER rewriting its
# lists. State lives in Home window properties (shared by the player's plugin call and the service's threads). Only for
# automatic callers -- a reload the user asked for goes out at once.
# LOCAL PATCH 2026-11-01: `tmdb_id` (the title a caller changed) narrows the reload to the progress lists and widgets
# listing it. The trailing reload covers every folded request: titles kept in a Home property as 'all' or 'id,id' (a
# sync names no title, so it makes it 'all').
_SCOPE_PROP = 'deadlight.auto_refresh.scope'

def _fold_scope(tmdb_id, fresh=False):
	current = '' if fresh else get_property(_SCOPE_PROP)
	if current == 'all' or not tmdb_id: return set_property(_SCOPE_PROP, 'all')
	set_property(_SCOPE_PROP, ','.join(sorted(set(filter(None, current.split(','))) | {str(tmdb_id)})))

def auto_kodi_refresh(caller, window=15, tmdb_id=None):
	import time
	now = time.time()
	try: last = float(get_property('deadlight.auto_refresh.last') or 0)
	except ValueError: last = 0.0
	if not 0 <= now - last < window:
		set_property('deadlight.auto_refresh.last', str(now))
		logger('widget.refresh', '%s: reloading widgets%s' % (caller, (' (tmdb %s)' % tmdb_id) if tmdb_id else ''))
		return refresh(titles=tmdb_id)
	due = last + window
	try: pending = float(get_property('deadlight.auto_refresh.due') or 0)
	except ValueError: pending = 0.0
	if pending >= now:
		_fold_scope(tmdb_id)
		return logger('widget.refresh', '%s: folded into the reload due in %.1fs' % (caller, pending - now))
	set_property('deadlight.auto_refresh.due', str(due))
	_fold_scope(tmdb_id, fresh=True)
	logger('widget.refresh', '%s: reload %.1fs ago, one more in %.1fs' % (caller, now - last, due - now))
	if xbmc.Monitor().waitForAbort(max(due - time.time(), 0)): return
	set_property('deadlight.auto_refresh.last', str(time.time()))
	clear_property('deadlight.auto_refresh.due')
	scope = get_property(_SCOPE_PROP)
	clear_property(_SCOPE_PROP)
	everything = scope in ('', 'all')
	logger('widget.refresh', '%s: trailing reload (%s)' % (caller, 'all' if everything else 'tmdb ' + scope))
	refresh(titles=None if everything else scope.split(','))

def refresh_widgets():
	from caches.settings_cache import get_setting
	from caches.random_widgets_cache import RandomWidgets
	RandomWidgets().delete_like('random_list.%')
	kodi_full_refresh()   # the user asked: every widget
	if get_setting('deadlight.widget_refresh_notification', 'true') == 'true': notification('Widgets Refreshed', 2500)

def run_plugin(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin('RunPlugin(%s)' % params, block)

def container_update(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin('Container.Update(%s)' % params, block)

def activate_window(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin('ActivateWindow(Videos,%s,return)' % params, block)

def container_refresh():
	return execute_builtin('Container.Refresh')

def container_refresh_input(params, block=False):
	if isinstance(params, dict): params = build_url(params)
	return execute_builtin('Container.Refresh(%s)' % params, block)


def disable_enable_addon(addon_name='plugin.video.deadlight'):
	import json
	try:
		xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': False}}))
		xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': True}}))
	except: pass

def update_local_addons():
	execute_builtin('UpdateLocalAddons', True)
	sleep(2500)
 
def update_kodi_addons_db(addon_name='plugin.video.deadlight'):
	import time
	import sqlite3 as database
	try:
		date = time.strftime('%Y-%m-%d %H:%M:%S')
		dbcon = database.connect(translate_path('special://database/Addons33.db'), timeout=40.0)
		dbcon.execute("INSERT OR REPLACE INTO installed (addonID, enabled, lastUpdated) VALUES (?, ?, ?)", (addon_name, 1, date))
		dbcon.close()
	except: pass

def get_jsonrpc(request):
	import json
	response = xbmc.executeJSONRPC(json.dumps(request))
	result = json.loads(response)
	return result.get('result', None)

def jsonrpc_get_directory(directory, properties=['title', 'file', 'thumbnail']):
	command = {'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory', 'params': {'directory': directory, 'media': 'files', 'properties': properties}}
	try:
		files = get_jsonrpc(command).get('files')
		results = [i for i in files if i['file'].startswith('plugin://') and i['filetype'] == 'directory']
	except: results = None
	return results


def jsonrpc_get_system_setting(setting_id, setting_value=''):
	command = {'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue', 'params': {'setting': setting_id}}
	try: result = get_jsonrpc(command)['value']
	except: result = setting_value
	return result

def open_settings(category=None):
	# LOCAL PATCH 2026-10-01: DeadLight's own settings window again (settings_manager.xml), as before 2026-09-26.
	# LOCAL PATCH 2026-10-09: the only settings screen -- Kodi's Add-ons > Configure (resources/settings.xml) is a button to it.
	from windows.base_window import open_window
	open_window(('windows.settings_manager', 'SettingsManager'), 'settings_manager.xml', category=category)

def external_scraper_settings():
	# The torrent providers are bundled; their settings are the Scrapers category of DeadLight's settings.
	open_settings('external_scrapers')

def progress_dialog(heading='', icon=None):
	from threading import Thread
	from windows.base_window import create_window
	from modules.busy_guard import paused
	progress_dialog = create_window(('windows.progress', 'Progress'), 'progress.xml', heading=heading, icon=icon or addon_icon())
	# LOCAL PATCH 2026-11-01: the progress window is the indicator while it is up -- a context action's spinner (busy_guard)
	# steps aside from now until the window closes
	guard = paused()
	guard.__enter__()
	def _run():
		try: progress_dialog.run()
		finally: guard.__exit__(None, None, None)
	Thread(target=_run).start()
	return progress_dialog

def qr_dialog(heading, url, text, wait=600, poll=None, interval=5):
	"""LOCAL PATCH 2026-09-30: a login step with a QR code of `url` beside `text`, so the page opens on a phone
	instead of being typed on a TV remote. The bar shows the time left.
	with poll: poll() runs every `interval` s; its first truthy return is returned. BACK or `wait` s -> None.
	without: the step waits for the user -- BACK means 'done, carry on' and returns True; `wait` s -> False."""
	import time
	from modules.utils import make_qrcode
	dialog = progress_dialog(heading, make_qrcode(url) or '')
	start, result, next_poll = time.time(), None, time.time() + interval
	try:
		while not dialog.iscanceled():
			elapsed = time.time() - start
			if elapsed >= wait: break
			dialog.update(text, int(100 * elapsed / wait))
			if poll and time.time() >= next_poll:
				try: result = poll()
				except Exception: result = None
				if result: break
				next_poll = time.time() + interval
			sleep(500)
		canceled = dialog.iscanceled()
	finally:
		try: dialog.close()
		except Exception: pass
	return result if poll else canceled

def select_dialog(function_list, **kwargs):
	from windows.base_window import open_window
	selection = open_window(('windows.default_dialogs', 'Select'), 'select.xml', **kwargs)
	if selection in (None, []): return selection
	if kwargs.get('multi_choice', 'false') == 'true': return [function_list[i] for i in selection]
	return function_list[selection]

def confirm_dialog(heading='', text='Are you sure?', ok_label='OK', cancel_label='Cancel', default_control=11):
	from windows.base_window import open_window
	kwargs = {'heading': heading, 'text': text, 'ok_label': ok_label, 'cancel_label': cancel_label, 'default_control': default_control}
	return open_window(('windows.default_dialogs', 'Confirm'), 'confirm.xml', **kwargs)

def ok_dialog(heading='', text='No Results', ok_label='OK'):
	from windows.base_window import open_window
	kwargs = {'heading': heading, 'text': text, 'ok_label': ok_label}
	return open_window(('windows.default_dialogs', 'OK'), 'ok.xml', **kwargs)

def show_text(heading, text=None, file=None, font_size='small', kodi_log=False):
	from windows.base_window import open_window
	heading = heading.replace('[B]', '').replace('[/B]', '')
	if file:
		with open(file, encoding='utf-8') as r: text = r.readlines()
	if kodi_log:
		confirm = confirm_dialog(text='Show Log Errors Only?', ok_label='Yes', cancel_label='No')
		if confirm == None: return
		if confirm: text = [i for i in text if any(x in i.lower() for x in ('exception', 'error', '[test]'))]
	text = ''.join(text)
	return open_window(('windows.textviewer', 'TextViewer'), 'textviewer.xml', heading=heading, text=text, font_size=font_size)

def notification(line1, time=5000, icon=None):
	kodi_dialog().notification(addon_name(), line1, icon or addon_icon(), time)

# LOCAL PATCH 2026-11-16 (after Red Light's Kodi 22 port): Kodi 22 (Piers) plays a widget's plugin:// item by RESOLVING it --
# it waits for setResolvedUrl on the call's handle, and when the call ends without one it marks the item unplayable
# ("Playback failed" after the user stopped the episode DeadLight's own player had started). Kodi 21 does not wait, and an
# answer there would show that very dialog, so below 22 nothing changes. A handle is answered once: the first source plays
# through it; a later source of the same scrape and the next-episode hand-off use Player.play() as before.
_ANSWERED_HANDLES = set()

def kodi_version():
	try: return int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
	except (ValueError, IndexError): return 21

def answer_resolve(listitem=None):
	"""Answer this call's resolve handle -- with the item to play, or (listitem None) as not played: a cancelled or
	failed play, whose OK dialog is then closed. True when an answer was sent."""
	if kodi_version() < 22: return False
	import sys
	try: handle = int(sys.argv[1])
	except Exception: return False
	if handle < 0 or handle in _ANSWERED_HANDLES: return False
	_ANSWERED_HANDLES.add(handle)
	if listitem is None:
		# LOCAL PATCH 2026-11-16 (Red Light's _abort_plugin_resolve): Kodi 22 plays a list / widget click through the video
		# PLAYLIST, which holds the rest of that list too -- answered "not played", Kodi moved on to the next item, and the
		# next (4 episodes of 3 shows in 5 s, 01:03:24), each "not playable", then "Playback failed". Nothing to move to now.
		# Not while something plays (a hand-off's playlist is the player's own).
		try:
			if not xbmc.Player().isPlaying(): xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
		except Exception: pass
	try: xbmcplugin.setResolvedUrl(handle, listitem is not None, listitem if listitem is not None else xbmcgui.ListItem())
	except Exception: return False
	if listitem is None: threading.Thread(target=_close_failed_dialog, name='close_failed_dialog').start()
	return True

def _close_failed_dialog():
	# Kodi posts the OK dialog just after setResolvedUrl(False) returns; a second at most
	for _ in range(25):
		if get_visibility('Window.IsVisible(okdialog)'): return execute_builtin('Dialog.Close(okdialog,true)')
		sleep(40)

def player_check(mode, params):
	# LOCAL PATCH: external-addon playback block removed. Unknown playback.* modes
	# fall through to Sources().playback_prep instead of the "not supported" dialog.
	from modules.sources import Sources
	if mode == 'playback.video':
		from modules.player import DeadLightPlayer
		DeadLightPlayer().run(params.get('url', None), params.get('obj', None))
	else:
		Sources().playback_prep(params)

def external_playback_check(params):
	# LOCAL PATCH: external-addon playback block removed. Always allow.
	return True


def volume_checker():
	# 0% == -60db, 100% == 0db
	try:
		if get_property('deadlight.playback.volumecheck_enabled') == 'false' or get_visibility('Player.Muted'): return
		from modules.utils import string_alphanum_to_num
		max_volume = min(int(get_property('deadlight.playback.volumecheck_percent') or '50'), 100)
		if int(100 - (float(string_alphanum_to_num(get_infolabel('Player.Volume').split('.')[0]))/60)*100) > max_volume: execute_builtin('SetVolume(%d)' % max_volume)
	except: pass

def focus_index(index):
	current_window = current_window_object()
	focus_id = current_window.getFocusId()
	try: current_window.getControl(focus_id).selectItem(index)
	except: pass

def get_all_icons():
	import requests
	from caches.main_cache import cache_object
	def _process(dummy):
		try:
			# LOCAL PATCH 2026-11-17: icons_white, the folder get_icon loads (deadlight-media drops its teal 'icons' copies)
			results = requests.get('https://api.github.com/repos/%s/%s/contents/packages/media/icons_white' % (username, location), timeout=10)   # LOCAL PATCH 2026-10-25 (4.0.5): no timeout hung the caller
			results = [i['name'].replace('.png', '') for i in results.json()]
			return results
		except: return None
	username, location = get_property('deadlight.media.username'), get_property('deadlight.media.location')
	# LOCAL PATCH 2026-11-08: a failed GitHub listing is not cached (the fallback would be the answer for 168 h); listed
	# names have their '.png' cut off, so the fallback is 'folder'
	return cache_object(_process, 'all_icons', 'foo', False, 168) or ['folder']


def upload_logfile(params):
	import json
	import requests
	from modules.utils import copy2clip, make_qrcode
	log_files = [('Current Kodi Log', 'kodi.log'), ('Previous Kodi Log', 'kodi.old.log')]
	list_items = [{'line1': i[0]} for i in log_files]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Choose Which Log File to Upload', 'narrow_window': 'true'}
	log_file = select_dialog(log_files, **kwargs)
	if log_file == None: return
	log_name, log_file = log_file
	if not confirm_dialog(heading=log_name): return
	show_busy_dialog()
	url = 'https://paste.kodi.tv/'
	log_file = translate_path('special://logpath/%s' % log_file)
	if not path_exists(log_file): return hide_busy_dialog(), ok_dialog(text='Error. Log Upload Failed[CR]Log file was not found.')
	# LOCAL PATCH 2026-11-14 (Red Light 3.1.1): paste.kodi.tv's nginx takes 1 MB and answers 413 HTML above that, which
	# .json() turned into a bare 'Log Upload Failed'. Send the newest part (from a line start, marked) and show the reason.
	reason = ''
	try:
		with open(log_file, 'rb') as f:
			f.seek(0, 2)
			start = max(0, f.tell() - _PASTE_MAX_BYTES)
			f.seek(start)
			data = f.read()
		if start:
			cut = data.find(b'\n')
			if 0 <= cut < 500: data = data[cut + 1:]
			data = b'[DeadLight uploaded the newest part of this log.]\n' + data
		resp = requests.post('%s%s' % (url, 'documents'), data=data, headers={'User-Agent': 'script.kodi.loguploader: 1.0'}, timeout=60)
		try: response = resp.json() or {}
		except Exception: response = {}
		if not isinstance(response, dict): response = {}
		if resp.status_code != 200 or 'key' not in response: reason = str(response.get('message') or 'HTTP %s' % resp.status_code)
	except Exception as e: reason, response = str(e) or type(e).__name__, {}
	try:
		if not reason:
			user_code = response['key']
			url = '%s%s' % (url, user_code)
			copy2clip(url)
			qr_code = make_qrcode(url) or ''
			progressDialog = progress_dialog(heading='Kodi Log Uploader', icon=qr_code)
			count, success = 20, None
			while not progressDialog.iscanceled() and count >= 0 and success == None:
				try:
					count -= 1
					progressDialog.update('Share or Access with this url: [B]%s[/B][CR]Or Access using this QR Code' % url, count)
					sleep(2500)
				except: success = False
			# its run() thread is not a daemon: left open, deadlight.py's exit wait blocked and skipped closing the databases
			try: progressDialog.close()
			except: pass
		else:
			if len(reason) > 180: reason = reason[:177] + '...'
			logger('DeadLight', 'Log upload failed: %s' % reason)
			hide_busy_dialog()
			ok_dialog(text='Error. Log Upload Failed[CR]%s' % reason)
	except: ok_dialog(text='Error. Log Upload Failed')
	hide_busy_dialog()

_PASTE_MAX_BYTES = 1000000   # paste.kodi.tv accepts 1 MiB; a little under leaves room for the header line

