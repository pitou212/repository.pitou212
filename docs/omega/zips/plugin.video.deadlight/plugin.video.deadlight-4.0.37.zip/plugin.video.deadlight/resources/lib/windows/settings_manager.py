# -*- coding: utf-8 -*-
from time import time
from urllib.parse import parse_qsl
from windows.base_window import BaseDialog

# LOCAL PATCH 2026-09-26: open straight on a category. Positions in the category list (control 2000) of
# settings_manager.xml (no visibility conditions, so positions never shift); keep in step with that list's order.
# LOCAL PATCH 2026-10-01: keyed by the category ids of resources/settings.xml, as callers named them for Kodi's dialog.
# LOCAL PATCH 2026-11-22: HTTP Scrapers (7) and Stremio Add-ons (8, AIOStreams + the custom slots) replaced Direct Providers;
# 'aiostreams' still names its category for older callers
CATEGORY_POSITIONS = {'general': 0, 'features': 1, 'content': 2, 'interface': 3, 'accounts': 4, 'debrid': 5,
					  'external_scrapers': 6, 'http_scrapers': 7, 'aiostreams': 8,
					  'stremio_addons': 8, 'other_providers': 9, 'results': 10, 'playback': 11}
# LOCAL PATCH 2026-10-01: dividers are headings, not settings -- a Kodi list cannot make one item unfocusable, so the
# highlight is stepped past them in the direction it was going (up / down, page up / down, mouse wheel).
SETTINGS_LIST = 2100
MOVE_UP, MOVE_DOWN = (3, 5, 104), (4, 6, 105)

class InWindowSettings:
	"""LOCAL PATCH 2026-10-09: rows change their setting inside the window (Red Light 2.8.2's settings engine): a row carries
	setting_mode (+ setting_id / setting_query) and onClick runs that handler here. Not RunPlugin(): that starts a plugin
	process per toggle and the value flickers. Rows that still have a RunPlugin onclick (sign-in flows, icon change) still work.
	  setting_mode 'settings_manager.<name>' -> caches.settings_cache.<name>(params)   (as router.py)
	               '<name>_choice'             -> indexers.dialogs.<name>(params)         (as router.py)"""
	settings_list_id = SETTINGS_LIST

	def onClick(self, controlID):
		if controlID == self.settings_list_id: self.apply_focused_setting()

	def settings_action(self, action):
		# Kodi does not always pass a static list item's click to onClick when the item has its own <onclick>; Red Light
		# answers Select here too, and the debounce in apply_focused_setting keeps it to one change
		if action in self.closing_actions:
			self.close()
			return True
		if action in self.selection_actions and self.getFocusId() == self.settings_list_id:
			self.apply_focused_setting()
			return True
		return False

	def onAction(self, action):
		self.settings_action(action)

	def _row_property(self, key):
		return self.get_infolabel('Container(%d).ListItem.Property(%s)' % (self.settings_list_id, key)) or ''

	def apply_focused_setting(self):
		# Enter fires onClick and, on some remotes, a select action as well: one press, one change
		now = time()
		if now - getattr(self, '_last_apply', 0) < 0.35: return
		mode = self._row_property('setting_mode')
		if not mode: return
		self._last_apply = now
		params = dict(parse_qsl(self._row_property('setting_query'), keep_blank_values=True))
		setting_id = self._row_property('setting_id')
		if setting_id: params['setting_id'] = setting_id
		params.setdefault('setting_label', self._row_property('setting_label'))   # LOCAL PATCH 2026-11-08: the picker's heading
		try: self._dispatch(mode, params)
		except Exception as e:
			from modules.kodi_utils import logger
			logger('DeadLight settings', '%s(%s) failed: %s' % (mode, params, e))
		self._refresh_row()

	def _dispatch(self, mode, params):
		if mode.startswith('settings_manager.'):
			from caches import settings_cache
			func = getattr(settings_cache, mode.split('.', 1)[1], None)
		elif 'choice' in mode:
			from indexers import dialogs
			func = getattr(dialogs, mode, None)
		else: func = None
		if func: return func(params)

	def _refresh_row(self):
		# A static list redraws a row's $INFO values when it is laid out again: step off the row and back
		try:
			position = self.get_position(self.settings_list_id)
			if position < 0: return
			self.select_item(self.settings_list_id, position - 1 if position > 0 else position + 1)
			self.select_item(self.settings_list_id, position)
		except Exception: pass

class SettingsManager(InWindowSettings, BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.control_id = None
		self.start_position = CATEGORY_POSITIONS.get(kwargs.get('category'))

	def onInit(self):
		# Runs after the XML's <onload>SetFocus(2000,0,absolute)</onload>, so this wins.
		if self.start_position is not None: self.execute_code('SetFocus(2000,%d,absolute)' % self.start_position)
		# LOCAL PATCH 2026-11-22: the Stremio slots' add-on names, refreshed off the UI thread (cached 12 h in main_cache)
		from threading import Thread
		from scrapers.stremio_addons import SLOTS, refresh_name
		for slot in SLOTS:
			Thread(target=refresh_name, args=(slot,), daemon=True).start()

	def run(self):
		self.doModal()
		self.clearProperties()

	def onAction(self, action):
		if self.settings_action(action): return
		if self.getFocusId() != SETTINGS_LIST: return
		if action in MOVE_UP: self.skip_separator(-1)
		elif action in MOVE_DOWN: self.skip_separator(1)

	def skip_separator(self, step):
		# Kodi has already moved the list when this runs. A few tries in case rows hidden by their own conditions leave two
		# dividers touching.
		# LOCAL PATCH 2026-10-05: wrap at either end instead of turning back: every category opens on a divider, so turning
		# back would bounce Up off it forever (onup/ondown 2100 in settings_manager.xml wrap past the real ends).
		for _ in range(3):
			if self.get_infolabel('Container(%d).ListItem.Property(setting_type)' % SETTINGS_LIST) != 'separator': return
			try: position, total = int(self.get_infolabel('Container(%d).CurrentItem' % SETTINGS_LIST)), int(self.get_infolabel('Container(%d).NumItems' % SETTINGS_LIST))
			except ValueError: return
			if 1 <= position + step <= total: self.execute_code('Control.Move(%d,%d)' % (SETTINGS_LIST, step), True)
			else: self.execute_code('SetFocus(%d,%d,absolute)' % (SETTINGS_LIST, total - 1 if step < 0 else 0), True)

class SettingsManagerFolders(InWindowSettings, BaseDialog):
	settings_list_id = 2101   # LOCAL PATCH 2026-10-09: the folders window's settings list

	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)

	def run(self):
		self.doModal()
		self.clearProperties()
