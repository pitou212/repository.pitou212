# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-11-18: AnimeDubHindi (www.animedubhindi.link) -- Hindi / multi-audio dubs of anime and other animation,
one of Direct Streams' providers (scrapers/http_streams, setting http_streams.animedubhindi).

The site, as read 2026-11-18:
  - WordPress: /wp-json/wp/v2/search finds posts by title; a post's body holds ONE link to its gate page on
    new.adhlinks.com (/episode/<slug>/ or /movie/<slug>/).
  - post titles: '<Series> Season 18 Hindi, Tamil, ... (Multi Audio) BluRay Episodes Download',
    '<Series> Season 01-05 ...', '<Title> (2004) BluRay Hindi, ... Movie Download', 'One Piece (2023) Season 1 Live-Action ...'.
  - gate page: an h2 'Episode: 01' (seasonal shows) or 'Episode: 373' (long runners number absolutely) per episode, under
    it one line per quality -- '720P x264 [Size: 197mb]' -- then that file on Hcloud | GDF | MEGA | Multi | Fprs. A film's
    page is one such block. 'Episode 01-12 Zip Pack' blocks are archives: skipped.
  - only the HubCloud links are used: resolved at play time (scrapers/hubcloud). GDFlix's 'Instant DL' answered 500,
    FilePress sits behind a Cloudflare check, MEGA does not stream. Posts from before ~2026 link every host through ad
    shorteners (exe.io, shrinkme, cuty.io): those give no rows.
Anime only (2026-11-18, the user's call): since 2026-11-23 modules/provider_gate decides (ANIME_ONLY: never off anime; on
anime its tick in Options > Anime Scrapers), on the scrape's own verdict -- this module no longer tests.
The site also carries western animation (Invincible, Vox Machina); those are no longer asked."""
import html
import re
import unicodedata
from concurrent.futures import ThreadPoolExecutor
from modules.kodi_utils import logger
from modules.source_utils import get_aliases_titles, ABSOLUTE_SEASON, ANY_SEASON
from scrapers._site_common import get as _get, hubcloud_row, recall, keep, forget

BASE = 'https://www.animedubhindi.link'
LABEL = 'AnimeDubHindi'
_MAX_FALLBACK_POSTS = 4   # other posts of the show read for an absolute episode number when its own season's has none

# a post title, read into its parts (_post_parts)
_TITLE_CUT = re.compile(r'\s+Season\s*\d|\s*\((?:19|20)\d{2}\)|\s+(?:in\s+)?(?:Hindi|Tamil|Telugu|English|Eng|Japanese|Jap)\b|'
						r'\s*\((?:Multi|Dual)\b|\s+(?:BluRay|WEB-?DL|AMZN|HDTV|Official)\b|\s+Movie\s+Download', re.I)
_SEASONS = re.compile(r'\bSeason\s*(\d{1,2})(?:\s*[-–]\s*(\d{1,2}))?', re.I)
_YEAR = re.compile(r'\(((?:19|20)\d{2})\)')
_SOURCE = re.compile(r'\b(AMZN\s+WEB-?DL|WEB-?DL|BluRay|HDTV|WEBRip)\b', re.I)
_AUDIO = re.compile(r'\((Multi|Dual)\s+Audio\)', re.I)
_LANGS = re.compile(r'\b(Hindi|Tamil|Telugu|Malayalam|Kannada|Bangla|Bengali|English|Eng|Japanese|Jap|Korean|Chinese)\b', re.I)
_LANG_NAMES = {'eng': 'English', 'jap': 'Japanese', 'bangla': 'Bengali'}
# a gate page, read into blocks (_gate_blocks)
_EPISODE_HEAD = re.compile(r'<h[1-6][^>]*>\s*(?:<[^>]+>\s*)*Episode\s*:?\s*(\d{1,4})(\s*[-–]\s*\d+)?[^<]*', re.I)
# A HubCloud link's quality and size: the LAST resolution and the last size in the text between the previous HubCloud link
# and it. One rule for the four templates seen (2026-11-18): '720P x264 [Size: 197mb]' (Naruto), '[480P x264]' + '💾 925.9 MB'
# (Infinity Castle), a bare '[480P x264]' (ReLIFE), '480p:- <links>' (Re:Zero S1). A size the page omits is read from the
# HubCloud page (_fill_sizes).
_RESOLUTION = re.compile(r'(?<![\w.])((?:2160|1440|1080|720|576|480|360)p|4K)\b((?:[\s,]*(?:x26[45]|HEVC|AVC|10[\s-]?bit|8[\s-]?bit|HQ|HDR|SDR))*)', re.I)
_SIZE = re.compile(r'(?<![\w.])([\d.,]+)\s*([KMGT]i?B)\b', re.I)
_HUBCLOUD = re.compile(r'''href=["'](https?://(?:[\w-]+\.)*hubcloud\.[a-z]{2,}/drive/[\w-]+)["']''', re.I)


class _Stale(Exception):
	"""A kept search answer or gate list led nowhere (a post moved, or a new season's post is not in it): read it again, once."""


_KEEP_TTL = 12 * 3600


def scrape(info):
	"""Stremio-shaped rows (http_streams._make_item reads them) for info's film or episode. Raises on a failed request, so
	http_streams counts the provider as failed and does not cache the empty answer."""
	if info.get('media_type') not in ('movie', 'episode'): return []
	try: return _scrape(info)
	except _Stale: return _scrape(info, fresh=True)


def _search(query, fresh):
	"""(search hits, from_memory). LOCAL PATCH 2026-11-18: a found answer is kept 12 h (_site_common.recall) -- one search
	serves every episode of a show (0.7 s of a 2.6 s Bleach scrape)."""
	prop = 'deadlight.animedubhindi.search.%s' % _norm(query)
	kept = None if fresh else recall(prop, _KEEP_TTL)
	if kept: return kept, True
	hits = _get(BASE + '/wp-json/wp/v2/search', params={'search': query, 'per_page': 20, 'type': 'post'}).json() or []
	slim = [dict((k, h.get(k)) for k in ('id', 'title', 'url')) for h in hits if isinstance(h, dict)]
	if slim: keep(prop, slim)
	else: forget(prop)
	return slim, False


def _scrape(info, fresh=False):
	media_type = info.get('media_type')
	title = info.get('title') or ''
	names = set(n for n in (_norm(t) for t in [title] + get_aliases_titles(info.get('aliases', []))) if n)
	try: year = int(info.get('year') or 0)
	except (TypeError, ValueError): year = 0
	# WordPress matches each word as typed: 'Shippūden' / 'Journey’s' would miss the site's 'Shippuden' / 'Journey's'
	query = ' '.join(re.sub(r'[^A-Za-z0-9]+', ' ', unicodedata.normalize('NFKD', title).encode('ascii', 'ignore').decode('ascii')).split())
	hits, remembered = _search(query, fresh)
	posts = [p for p in (_post_parts(h) for h in hits or []) if p['name'] in names and (not p['year'] or not year or abs(p['year'] - year) <= 1)]
	posts = [p for p in posts if p['movie'] == (media_type == 'movie')]
	if not posts:
		if remembered: raise _Stale()
		logger('AnimeDubHindi', '%s: no post (%d search hits)' % (title, len(hits or [])))
		return []
	if media_type == 'movie':
		page = _gate_page(posts[0], fresh)
		rows = _rows(_gate_blocks(page).get(None) or [], posts[0], info, None)
		logger('AnimeDubHindi', '%s (%s): %d file(s) from %r%s' % (title, year, len(rows), posts[0]['title'][:80], _shortener_only(page)))
		return rows
	try: season, episode = int(info.get('season')), int(info.get('episode'))
	except (TypeError, ValueError): return []
	if season < 1: return []
	pairs, absolutes = [(season, episode)], []
	for pair in info.get('episode_candidates') or []:
		try: s, e = int(pair[0]), int(pair[1])
		except (TypeError, ValueError, IndexError): continue
		if s in (ABSOLUTE_SEASON, ANY_SEASON): absolutes.append(e)
		elif 0 < s < 100 and (s, e) not in pairs: pairs.append((s, e))
	# the posts of a season TMDb (or the cour numbering) gives, then the show's other posts, nearest season first -- nearest
	# to the TMDb season that holds the absolute number when there is one. A show TMDb numbers straight through is scraped
	# as S1E<absolute> (Naruto Shippuden S18E373 arrives as S1E373, 2026-11-18): season 1 alone would read Seasons 1-5.
	home = next((s for s in (_season_of_absolute(info, n) for n in absolutes) if s), season)
	own = [p for p in posts if any(s in p['seasons'] for s, _e in pairs)]
	if not own and remembered and not absolutes: raise _Stale()   # a season posted since the search answer was kept
	others = sorted((p for p in posts if p not in own), key=lambda p: min([abs(s - home) for s in p['seasons']] or [99]))
	why = ''
	for tier, group in (('season', own), ('absolute', others[:_MAX_FALLBACK_POSTS] if absolutes else [])):
		if not group: continue
		with ThreadPoolExecutor(max_workers=min(3, len(group))) as ex:
			pages = list(ex.map(lambda post: _gate_page(post, fresh), group))
		for post, page in zip(group, pages):
			if tier == 'season' and not why: why = _shortener_only(page)
			blocks = _gate_blocks(page)
			if len(post['seasons']) > 1:
				# a range post ('Bleach Season 01-05', 'Naruto Season 01-09') numbers the whole run from 1: matched by the
				# absolute number only (TMDb's own number when it is absolute already). Read as 'Season 2 is in 01-05' it gave
				# TMDb Bleach S02E01 (Thousand-Year Blood War, absolute 367) the files of episode 1 (2026-11-18).
				numbers = absolutes or [episode]
			else:
				numbers = ([e for s, e in pairs if s in post['seasons']] if tier == 'season' else []) + absolutes
			number = next((n for n in numbers if n in blocks), None)
			if number is None: continue
			rows = _rows(blocks[number], post, info, (season, episode))
			logger('AnimeDubHindi', '%s S%02dE%02d: %d file(s) from episode %d of %r (%s)' % (title, season, episode, len(rows), number, post['title'][:70], tier))
			if rows: return rows
	logger('AnimeDubHindi', '%s S%02dE%02d: not in %d post(s) (%s)%s' % (title, season, episode, len(posts), ', '.join(p['title'][:40] for p in posts[:4]), why))
	return []


def _shortener_only(page):
	"""A log note for a gate page with no HubCloud link: every host behind the ad-link redirect (posts from before ~2026), or
	only hosts that cannot be played (Re:Zero S2 / S3: MEGA, GDTot, TeraBox, FilePress)."""
	return ' -- no HubCloud link on its page (ad-shortener or unplayable hosts only)' if page and not _HUBCLOUD.search(page) else ''



def _meta(info):
	try:
		from caches.meta_cache import meta_cache
		return meta_cache.get('movie' if info.get('media_type') == 'movie' else 'tvshow', 'tmdb_id', info.get('tmdb_id')) or {}
	except Exception: return {}


def _season_of_absolute(info, number):
	"""The TMDb season whose episodes, counted from the first season on, include absolute episode `number` (Shippuden:
	373 -> 18). None without the show's season list."""
	try:
		total = 0
		for row in sorted((r for r in _meta(info).get('season_data') or [] if int(r.get('season_number') or 0) > 0), key=lambda r: int(r['season_number'])):
			total += int(row.get('episode_count') or 0)
			if number <= total: return int(row['season_number'])
	except (TypeError, ValueError, KeyError): pass
	return None


def _norm(text):
	"""'Frieren: Beyond Journey’s End' and 'Naruto Shippūden' as the site and TMDb both spell them: ascii letters and digits."""
	text = unicodedata.normalize('NFKD', html.unescape(text or '')).encode('ascii', 'ignore').decode('ascii').lower()
	text = re.sub(r'[^a-z0-9]+', '', text)
	return text[3:] if text.startswith('the') and len(text) > 6 else text


def _post_parts(hit):
	raw = html.unescape((hit or {}).get('title') or '').strip()
	cut = _TITLE_CUT.search(raw)
	seasons = set()
	for m in _SEASONS.finditer(raw):
		first = int(m.group(1))
		seasons.update(range(first, int(m.group(2) or first) + 1))
	year = _YEAR.search(raw)
	langs = []
	for m in _LANGS.finditer(raw[cut.start():] if cut else ''):
		lang = _LANG_NAMES.get(m.group(1).lower(), m.group(1).title())
		if lang not in langs: langs.append(lang)
	source = _SOURCE.search(raw)
	audio = _AUDIO.search(raw)
	return {'id': hit.get('id'), 'url': hit.get('url'), 'title': raw, 'name': _norm(raw[:cut.start()] if cut else raw),
			'series': (raw[:cut.start()] if cut else raw).strip(' :-'), 'seasons': seasons, 'year': int(year.group(1)) if year else 0,
			'movie': bool(re.search(r'\bMovie\s+Download\b', raw, re.I)) and not seasons,
			'langs': langs, 'source': re.sub(r'\s+', ' ', source.group(1)) if source else '',
			'audio': '%s Audio' % audio.group(1).title() if audio else ''}


def _gate_page(post, fresh=False):
	"""The post's gate page(s) (new.adhlinks.com) as one text, '' when the post links none. A range post links one per site
	season -- 'Naruto Season 01-09': naruto-season-01 (episodes 1-26) ... naruto-season-08-09 (187-220), numbered straight
	through -- and every one is read (4 at once): only the first was, and Naruto stopped at episode 26 (2026-11-18). Joined,
	they read as one list (_gate_blocks: each page's episodes follow the last one's)."""
	# LOCAL PATCH 2026-11-18: the post's gate links are kept 12 h (_site_common.recall; 0.3 s per post), with whether their
	# pages held a HubCloud link. A kept list that no longer answers -- or whose pages HAD HubCloud links and now have none --
	# re-reads the post, once (_Stale). `fresh` (that retry) never uses a kept list, so it cannot be stale again.
	prop = 'deadlight.animedubhindi.gates.%s' % post['id']
	kept = None if fresh else recall(prop, _KEEP_TTL)
	remembered = isinstance(kept, dict)
	if remembered: gates, had_hubcloud = kept.get('gates') or [], kept.get('hubcloud')
	else:
		body = _get(BASE + '/wp-json/wp/v2/posts/%s' % post['id'], params={'_fields': 'content'}).json()
		gates = list(dict.fromkeys(html.unescape(u) for u in
			re.findall(r'''href=["'](https?://[^"']*adhlinks\.[a-z]+/[^"']+)["']''', ((body or {}).get('content') or {}).get('rendered') or '')))
	if not gates:
		if not remembered: keep(prop, {'gates': [], 'hubcloud': False})
		return ''
	def read(gate):
		try: return _get(gate, referer=BASE + '/').text
		except Exception:
			if remembered:
				forget(prop)
				raise _Stale()
			raise
	if len(gates) == 1: text = read(gates[0])
	else:
		with ThreadPoolExecutor(max_workers=min(4, len(gates))) as ex:
			text = '\n'.join(ex.map(read, gates))
	# the gate site answers 200 for a page it no longer has, so a kept list whose pages HAD HubCloud links and now have none
	# is re-read once. A post that never had any (ad-shortener hosts only: Shippuden's older seasons) is kept as it is -- before
	# that distinction every scrape of such a show re-read it twice and then failed (2026-11-18).
	has_hubcloud = bool(_HUBCLOUD.search(text))
	if remembered and had_hubcloud and not has_hubcloud:
		forget(prop)
		raise _Stale()
	if not remembered: keep(prop, {'gates': gates, 'hubcloud': has_hubcloud})
	return text


def _gate_blocks(page):
	"""{episode number: [(quality label, size, hubcloud url)]}, or {None: [...]} for a page without episode headings (a film).
	Zip-pack headings ('Episode 01-12') end the block before them and start none."""
	heads = list(_EPISODE_HEAD.finditer(page or ''))
	spans = [(None, 0, len(page or ''))] if not heads else \
		[(None if h.group(2) else int(h.group(1)), h.end(), heads[i + 1].start() if i + 1 < len(heads) else len(page)) for i, h in enumerate(heads)]
	blocks = {}
	for number, start, end in spans:
		if number is None and heads: continue
		chunk, files, since = page[start:end], [], 0
		for link in _HUBCLOUD.finditer(chunk):
			text = html.unescape(re.sub(r'<[^>]+>', ' ', chunk[since:link.start()]))
			since = link.end()
			res, size = list(_RESOLUTION.finditer(text)), list(_SIZE.finditer(text))
			if not res: continue   # a second HubCloud link for the same quality line
			label = ' '.join((res[-1].group(1).upper() + ' ' + res[-1].group(2).replace(',', ' ')).split())
			files.append((label, '%s %s' % (size[-1].group(1), size[-1].group(2).upper()) if size else '', link.group(1)))
		if files: blocks.setdefault(number, files)
	return blocks


def _fill_sizes(files):
	"""Sizes for the quality lines that state none, from each file's HubCloud page (in parallel, ~0.4 s)."""
	missing = [i for i, f in enumerate(files) if not f[1]]
	if not missing: return files
	from scrapers.hubcloud import drive_size
	with ThreadPoolExecutor(max_workers=min(4, len(missing))) as ex:
		sizes = dict(zip(missing, ex.map(lambda i: drive_size(files[i][2]), missing)))
	return [(f[0], sizes.get(i, f[1]), f[2]) for i, f in enumerate(files)]


def _rows(files, post, info, pair):
	"""Stremio-shaped rows. The name is built as a release name: http_streams' episode, title and quality filters read it."""
	files = _fill_sizes(files)
	what =('%s S%02dE%02d' % (post['series'], pair[0], pair[1])) if pair else ('%s (%s)' % (post['series'], post['year'] or info.get('year') or ''))
	langs = ', '.join(post['langs'])
	rows = []
	for label, size, url in files:
		q = label.lower()
		quality = '4K' if ('2160' in q or '4k' in q) else '1080p' if '1080' in q else '720p' if '720' in q else 'SD'
		name = ' '.join(x for x in ('[%s]' % LABEL, what, label, post['source'], post['audio'], langs.replace(', ', ' ')) if x)
		rows.append(hubcloud_row(LABEL, '%s.mkv' % name, url, size, info='%s | %s' % (LABEL, langs) if langs else LABEL, quality=quality))
	return rows
