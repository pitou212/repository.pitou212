# -*- coding: utf-8 -*-
from caches.base_cache import BaseCache, cache_ttl, single_flight

class MainCache(BaseCache):
	def __init__(self):
		BaseCache.__init__(self, 'maincache_db', 'maincache')

	def delete_all(self):
		try:
			dbcon = self.manual_connect('maincache_db')
			dbcon.execute('DELETE FROM maincache')
			dbcon.execute('VACUUM')
			return True
		except: return False

	def delete_all_folderscrapers(self):
		dbcon = self.manual_connect('maincache_db')
		try:
			dbcon.execute('DELETE FROM maincache WHERE id LIKE %s' % "'FOLDERSCRAPER_%'")
			dbcon.execute('VACUUM')
			return True
		except: return False

main_cache = MainCache()

def cache_object(function, string, args, json=True, expiration=24):
	cache = main_cache.get(string)
	if cache is not None: return cache
	with single_flight('main:' + string):   # LOCAL PATCH 2026-11-08: one fetch per key (base_cache.single_flight)
		cache = main_cache.get(string)
		if cache is not None: return cache
		if isinstance(args, list): args = tuple(args)
		else: args = (args,)
		if json: result = function(*args).json()
		else: result = function(*args)
		# LOCAL PATCH 2026-10-03 (Batch 3): base_cache.cache_ttl -- refusals are not stored, empties at most 0.3 h
		expiration = cache_ttl(result, expiration)
		if expiration: main_cache.set(string, result, expiration=expiration)
		return result
