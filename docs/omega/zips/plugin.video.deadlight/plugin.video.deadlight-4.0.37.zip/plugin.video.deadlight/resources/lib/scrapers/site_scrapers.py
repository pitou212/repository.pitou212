# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-11-18: Direct Streams' site scrapers, listed once. http_streams runs the switched-on ones (each as one
task, all at once) and the source picker (indexers/dialogs.scraper_choice) lists them under Direct Streams, in this order.

Each module has scrape(info) -> Stremio-shaped rows. Most return links resolved at play time. Failed requests are raised so http_streams
counts the provider as failed and caches nothing. Shared pieces live in scrapers/_site_common (requests, title and film rules,
rows, values kept in Home properties).

A new site: its module here, plus its setting in caches/settings_cache.py, modules/kodi_settings_spec.py and a row in
skins/Default/1080i/settings_manager_rows.jsonl (then `python tools/build_settings_manager.py`; the XML is generated)."""

# (setting key under http_streams., label in rows and logs, module under scrapers/, label in the source picker)
SITES = (
	('hdhub4u', 'HDHub4u', 'hdhub4u', 'HDHUB4U'),
	('4khdhub', '4KHDHub', 'k4hdhub', '4KHDHUB'),
	('moviesdrive', 'MoviesDrive', 'moviesdrive', 'MOVIESDRIVE'),
	('animedubhindi', 'AnimeDubHindi', 'animedubhindi', 'ANIMEDUBHINDI'),
	('cinejoy', 'Cinejoy', 'cinejoy', 'CINEJOY'),
)
