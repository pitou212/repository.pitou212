# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-11-21: Cinejoy (cinejoy.pk), one of Direct Streams' site scrapers (scrapers/site_scrapers, setting
http_streams.cinejoy). Reads the download list the site's own page asks for (downloads2.wing.st, by TMDb id); its links are
signed Cloudflare R2 URLs, played directly (no resolver). Only R2 hosts are kept (_is_r2_storage_url: exact host)."""
import re
from urllib.parse import parse_qs, urlparse

from modules.kodi_utils import logger
from scrapers._site_common import get as _get

LABEL = 'Cinejoy'
_SITE = 'https://cinejoy.pk/'
_DOWNLOADS = 'https://downloads2.wing.st'


def _is_r2_storage_url(url):
	try:
		host = (urlparse(url).hostname or '').lower().rstrip('.')
	except (TypeError, ValueError):
		return False
	return any(host == domain or host.endswith('.' + domain)
			for domain in ('r2.dev', 'r2.cloudflarestorage.com'))


def scrape(info):
	"""Return all matching page download options for one movie or one TV episode.

	Cinejoy's UI calls /movie/{tmdb_id} or /tv/{tmdb_id}/{season}/{episode}; the
	response contains the complete, already-signed download list. Signed URLs
	are intentionally fetched fresh on each scrape.
	"""
	media_type = info.get('media_type')
	try:
		tmdb = int(info.get('tmdb_id') or 0)
	except (TypeError, ValueError):
		return []
	if tmdb <= 0 or media_type not in ('movie', 'episode'):
		return []

	title = (info.get('title') or '').strip()
	if not title:
		return []
	if media_type == 'movie':
		path = '/movie/%d' % tmdb
		season = episode = None
	else:
		try:
			season, episode = int(info.get('season')), int(info.get('episode'))
		except (TypeError, ValueError):
			return []
		if season < 1 or episode < 1:
			return []
		path = '/tv/%d/%d/%d' % (tmdb, season, episode)

	# LOCAL PATCH 2026-11-22: the Stremio add-ons' recent-timeout memory (_http_providers_core.provider_timeout): a healthy
	# answer takes 0.2-1.2 s, a stall the full 5 s read timeout (8 of 25 requests on 2026-11-22) -- within 5 minutes of a
	# timeout it is asked with 2 s, and its first answer restores 5 s.
	# LOCAL PATCH 2026-11-23: the outcome is recorded once per scrape by http_streams' run_guarded (every site); here only the wait
	from scrapers._http_providers_core import provider_timeout
	read_timeout, _fails = provider_timeout(LABEL, 5, 2)
	try:
		# This endpoint is already scoped by TMDb ID and, for TV, season/episode.
		# Use a short connect/read timeout so a stalled API doesn't hold up playback.
		payload = _get(_DOWNLOADS + path, referer=_SITE, timeout=(3, read_timeout)).json()
	except Exception as exc:
		# LOCAL PATCH 2026-11-22: raised, not [] -- an empty answer is cached an hour by http_streams; a failure is not (site_scrapers).
		# Log 2026-11-22 19:11: a 5 s read timeout here returned [] and the next scrape showed the cached 0 rows.
		logger(LABEL, 'Download-list request failed: %s' % exc)
		raise
	links = payload.get('links') if isinstance(payload, dict) else None
	if not isinstance(links, list):
		logger(LABEL, 'Download-list response had no links array')
		return []

	rows, seen = [], set()
	for item in links:
		if not isinstance(item, dict):
			continue
		url = item.get('url')
		name = str(item.get('name') or '').strip()
		if not isinstance(url, str) or not url.startswith(('https://', 'http://')) or not name or not _is_r2_storage_url(url):
			continue
		# Cinejoy's display name is a provider/quality label; the release filename
		# is in the signed URL's Content-Disposition query parameter.
		query = parse_qs(urlparse(url).query)
		file_name = str(item.get('file_name') or item.get('filename') or
					(query.get('response-content-disposition') or [''])[0])
		match = re.search(r"(?i)filename\*?=(?:UTF-8''|\")?([^\";]+)", file_name)
		if match:
			file_name = match.group(1)
		file_name = file_name.strip().strip('"')
		if not file_name:
			file_name = name
		key = url
		if key in seen:
			continue
		seen.add(key)
		try:
			quality_value = int(item.get('quality') or 0)
		except (TypeError, ValueError):
			quality_value = 0
		quality = '4K' if quality_value >= 2160 else ('%dp' % quality_value if quality_value else '')
		label = str(item.get('source') or LABEL).strip()
		size = str(item.get('size') or '').strip()
		rows.append({
			'name': '%s | %s' % (LABEL, label),
			'title': file_name,
			'url': url,
			'info': '%s%s' % (label, (' | ' + size) if size else ''),
			'quality': quality,
			'mimeType': 'video',
		})
	logger(LABEL, '%s: %d source(s)' % (title, len(rows)))
	return rows
