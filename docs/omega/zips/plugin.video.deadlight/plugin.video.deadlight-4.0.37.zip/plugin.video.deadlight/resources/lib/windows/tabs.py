# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-11-13: the tab behaviour Extras and People share (windows/extras_layout.py writes their XML).
# A window shows one section at a time: the section whose list id is in the window property 'tab'. Each tab is a
# togglebutton with id = list id + TAB_OFFSET; the skin sets 'tab' / 'tab_button' as a tab gets focus. Here: the tab a
# window opens on (the first with something in it, in tab_ids() order), the focus on open, and the tab it comes back to.
# The lists fill in parallel threads (BaseDialog.start_with_tasks), so pick_tab runs after each fill.
from threading import Lock
from modules.kodi_utils import get_visibility

TAB_OFFSET = 1000


class TabsMixin:
	"""Mixed in before BaseDialog: class Extras(TabsMixin, BaseDialog). The window defines tab_ids()."""
	tab_takes_focus = True   # False: the window opens on its first button and the picked tab only shows its content (Extras)

	def tab_ids(self):
		"""The list ids that have a tab, in tab-bar order."""
		return []

	def tab_filled(self, list_id):
		try: return self.get_control(list_id).size() > 0
		except Exception: return False

	def add_items(self, _control, _items):
		super().add_items(_control, _items)
		self.pick_tab()

	def is_tab(self, control_id):
		return TAB_OFFSET + 2000 <= control_id < TAB_OFFSET + 3000

	def set_tab(self, list_id):
		self.setProperty('tab', str(list_id))
		self.setProperty('tab_button', str(list_id + TAB_OFFSET))

	def current_focus(self):
		"""getFocusId raises while nothing has the focus (a window opening, a control that could not take it): 0 then."""
		try: return self.getFocusId()
		except Exception: return 0

	def focus_control(self, control_id, tries=15):
		"""Focus a control once Kodi shows it: its visibility (a label set just before the window opened, a list that has
		items) is evaluated on the next frame, and each earlier ask logged "has been asked to focus, but it can't"."""
		for _ in range(tries):
			if self.current_focus() == control_id: return True
			if get_visibility('Control.IsVisible(%d)' % control_id):
				try: self.setFocusId(control_id)
				except Exception: pass
				if self.current_focus() == control_id: return True
			self.sleep(100)
		return False

	def focus_tab(self, tab):
		"""Focus a tab's button. Its visibility (the list has items / Details is set) is evaluated by Kodi on the next frame,
		so a focus asked in the same instant fails ('has been asked to focus, but it can't', 2026-11-13): retry for up to
		1.5 s. Stops as soon as the focus is somewhere the user moved it (not a default button, not this tab)."""
		target, allowed = tab + TAB_OFFSET, (0,) + tuple(getattr(self, 'tab_default_buttons', (10,)))
		for _ in range(15):
			focus = self.current_focus()
			if focus == target: return True
			if focus not in allowed and focus != getattr(self, '_auto_focus_from', None): return False
			if get_visibility('Control.IsVisible(%d)' % target):   # not before: every early ask logs an error
				try: self.setFocusId(target)
				except Exception: pass
			self.sleep(100)
		return False

	def pick_tab(self):
		"""Until the user picks a tab (or set_returning_focus does), show the first tab with something in it and give it the
		focus. A tab's own onfocus sets 'tab' too, so the user's choice is a 'tab' that differs from the one picked here."""
		lock = self.__dict__.setdefault('_tab_lock', Lock())
		with lock:
			if self.getProperty('tab_chosen') == 'true': return
			auto = getattr(self, '_auto_tab', None)
			if auto is not None and self.getProperty('tab') not in ('', str(auto)):
				return self.setProperty('tab_chosen', 'true')
			tab = next((i for i in self.tab_ids() if self.tab_filled(i)), None)
			if tab is None or tab == auto: return
			self._auto_tab = tab
			self._auto_focus_from = auto + TAB_OFFSET if auto is not None else None   # the previous pick's tab may hold the focus
			self.set_tab(tab)
		if self.tab_takes_focus: self.focus_tab(tab)

	def tab_default_focus(self, fallback=10):
		"""onInit: the button first (always focusable), then the picked tab once Kodi shows it (pick_tab may have run first)."""
		self.focus_control(fallback)
		tab = self.getProperty('tab')
		if tab.isdigit() and self.tab_takes_focus: self.focus_tab(int(tab))
		return True

	def set_returning_focus(self, list_id, focus, sleep_time=700):
		# back from a title or person opened here: its tab, then the same item once its list has been filled again
		try:
			self.setProperty('tab_chosen', 'true')
			self.set_tab(list_id)
			self.sleep(sleep_time)
			for _ in range(25):
				if self.get_control(list_id).size() > focus: break
				self.sleep(200)
			self.setFocusId(list_id)
			self.select_item(list_id, focus)
		except: self.set_default_focus()
