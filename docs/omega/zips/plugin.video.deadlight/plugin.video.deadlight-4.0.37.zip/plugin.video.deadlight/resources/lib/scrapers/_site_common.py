# -*- coding: utf-8 -*-
"""Shared HTTP, title, host-cache, and protector/archive helpers for Direct Streams' site scrapers."""
from concurrent.futures import ThreadPoolExecutor
import html
import re
import time
from urllib.parse import urlparse

from modules.kodi_utils import make_session, stream_request_parts, get_property, set_property, clear_property, logger

TIMEOUT = 10
_session = make_session('https://')
_HUBDRIVE_FILE = re.compile(r'''href=["'](https?://hubdrive\.[a-z]+/file/\d+)["']''', re.I)
_HUBDRIVE_PACK = re.compile(r'''href=["'](https?://hubdrive\.[a-z]+/packs/[\w-]+)["']''', re.I)
_HUBDRIVE_PACK_ANCHOR = re.compile(r'''<a\b[^>]*href=["'](https?://hubdrive\.[a-z]+/packs/[\w-]+)["'][^>]*>(.*?)</a>''', re.I | re.S)
_HUBDRIVE_NAME = re.compile(r'<h6[^>]*>\s*([^<]+\.(?:mkv|mp4|avi|ts|webm))\s*</h6>', re.I)
_HUBDRIVE_SIZE = re.compile(r'File\s*Size\s*</td>\s*<td[^>]*>\s*([\d.,]+\s*[KMGT]i?B)', re.I)
_HUBCLOUD_DRIVE = re.compile(r'''href=["'](https?://hubcloud\.[a-z]+/drive/(?!search-recover)[\w-]+)["']''', re.I)
_HUBCLOUD_RECOVER = re.compile(r'''href=["'](https?://hubcloud\.[a-z]+/drive/search-recover\.php\?[^"']+)["']''', re.I)
_PACK_ENTRY = re.compile(r'''window\.open\(\s*['"](/file/\d+)['"].{0,600}?pack-clean-title[^>]*>\s*([^<]+?)\s*<''', re.I | re.S)
# LOCAL PATCH 2026-11-22: the 4K / 1080p-only rule (HDHub4u, MoviesDrive), one copy for every site scraper. KNOWN_QUALITY:
# any resolution a label may state; HIGH_QUALITY: the ones kept.
KNOWN_QUALITY = re.compile(r'\b(?:4K|2160p|1080p|720p|480p|360p)\b', re.I)
HIGH_QUALITY = re.compile(r'\b(?:4K|2160p|1080p)\b', re.I)


def stated_quality_ok(text):
	"""None when `text` states no resolution, else whether the LAST one it states is kept (4K / 2160p / 1080p) -- a link's
	own label sits right before it ('720p ... 1080p [Drive]' is the 1080p link)."""
	stated = list(KNOWN_QUALITY.finditer(text or ''))
	return bool(HIGH_QUALITY.search(stated[-1].group(0))) if stated else None


def site_origin(url, site):
	"""LOCAL PATCH 2026-11-22: 'https://<host>' when `url` is https on `site`.<tld> or a subdomain of it (new15.hdhub4u.cl),
	else None -- the exact-host rule (protector_url_ok) for a site's moving domain."""
	try: parsed = urlparse(url or '')
	except ValueError: return None
	host = (parsed.hostname or '').lower()
	if parsed.scheme == 'https' and re.fullmatch(r'(?:[a-z0-9-]+\.)*%s\.[a-z]+' % re.escape(site), host): return 'https://' + host
	return None
_PROTECTOR_S = re.compile(r'''s\s*\(\s*(['"])o\1\s*,\s*(['"])([A-Za-z0-9_+/=-]+)\2''', re.I)
_PROTECTOR_CK = re.compile(r'''ck\s*\(\s*(['"])_wp_http_N\1\s*,\s*(['"])([A-Za-z0-9_+/=-]+)\2''', re.I)
_ROT13 = str.maketrans('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz',
					   'NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm')
_PROTECTED_ARCHIVE = re.compile(r'^https?://hblinks\.[a-z]+/archives/\d+/?$', re.I)


def get(url, referer=None, accept=None, origin=None, timeout=TIMEOUT, **kwargs):
	_link, headers = stream_request_parts(url)
	if referer: headers['Referer'] = referer
	if accept: headers['Accept'] = accept
	if origin: headers['Origin'] = origin
	r = _session.get(url, headers=headers, timeout=timeout, **kwargs)
	r.raise_for_status()
	return r


def episode_tag(season, episode):
	"""S04E01 / S04.E01 / S4 E1 in a file name -- one episode, not a range ('Ep.01-08', 'E01-E08')."""
	return re.compile(r'(?i)(?<![a-z0-9])S0*%d[ ._-]?E0*%d(?![0-9])(?!\s*[-–~]\s*E?\d)' % (season, episode))


def norm_title(text):
	"""A title as clean_title reads it: lower case, no punctuation, bracketed tags ('(Movies4u.Foo)') and accents dropped.
	LOCAL PATCH 2026-11-18: and no apostrophe of any kind -- clean_title kept the curly one ('The Handmaid’s Tale' ->
	'thehandmaid’stale'), which no file name carries."""
	from modules.source_utils import clean_title, normalize
	return clean_title(normalize(re.sub(r"['’‘`]", '', html.unescape(text or '')))) or ''


def title_prefix_ok(name, end, titles):
	"""Does the release name before position `end` (where its episode tag or year starts) name one of `titles` (norm_title'd)?
	Either may start the other: files shorten long titles ('Scam.1992.S01.E02' for 'Scam 1992: The Harshad Mehta Story').
	A search over a file index also returns other shows and films; this keeps them out. True when there are no titles.
	For an EPISODE: a film is matched by film_name_ok (a longer name there is another film)."""
	prefix = norm_title(name[:end])
	return not titles or (len(prefix) >= 3 and any(t.startswith(prefix) or prefix.startswith(t) for t in titles))


def episode_pairs(info, season, episode):
	"""LOCAL PATCH 2026-11-18: the (season, episode) pairs a site's file names may use for this episode -- the searched pair,
	the episode card's candidates with a real season, and the ABSOLUTE number filed under a season label where it cannot be
	that label's own episode:
	  - under TMDb's season, above that season's episode count (Blue Box TMDb S2E1 = 'S02E26' on 4KHDHub);
	  - under season 1, above season 1's episode count (Naruto TMDb S2E53 = 'NARUTO.S01E53' on 4KHDHub's 1080p copies; its
	    480p copies say 'S02E53').
	The absolute number and the counts are TMDb's own (search_info keys from source_utils.episode_number_keys), never worked
	out from an episode group's pair: the group's Naruto S2E18 would give 70, another episode."""
	pairs = [(season, episode)]
	for pair in info.get('episode_candidates') or []:
		try: s, e = int(pair[0]), int(pair[1])
		except (TypeError, ValueError, IndexError): continue
		if 0 < s < 100 and (s, e) not in pairs: pairs.append((s, e))
	try:
		absolute, tmdb_season = int(info.get('absolute_episode') or 0), int(info.get('tmdb_season') or 0)
		own_count, first_count = int(info.get('tmdb_season_count') or 0), int(info.get('first_season_count') or 0)
	except (TypeError, ValueError): return pairs
	if absolute and tmdb_season > 0 and own_count and absolute > own_count and (tmdb_season, absolute) not in pairs:
		pairs.append((tmdb_season, absolute))
	if absolute and tmdb_season > 1 and first_count and absolute > first_count and (1, absolute) not in pairs:
		pairs.append((1, absolute))
	return pairs


_YEAR = re.compile(r'(?<!\d)(19\d{2}|20\d{2})(?!\d)')


def film_name_ok(name, year, titles):
	"""LOCAL PATCH 2026-11-18: does a file name name this film -- its title (exactly, or shortened) before a year within one
	of TMDb's? NEVER a longer title: 'Animal.Park.2023' is another film than Animal (2023), which title_prefix_ok's either-way
	rule let through. Every year in the name is tried: one may belong to the title ('Scam.1992.2020'); one at position 0 IS
	the title ('1917.2019'). The cut is stripped of separators and an opening bracket ('Dune Part Two (2024)'). `titles`:
	norm_title'd; none -> any title. One rule for every site scraper (HDHub4u, 4KHDHub, MoviesDrive)."""
	for m in _YEAR.finditer(name or ''):
		if m.start() == 0 or (year and abs(int(m.group(1)) - int(year)) > 1): continue
		if not titles: return True
		prefix = norm_title(name[:m.start()].rstrip(' ._-([{'))
		if prefix and (prefix in titles or (len(prefix) >= 3 and any(t.startswith(prefix) for t in titles))): return True
	return False


_PROTECTOR_HOST = re.compile(r'(?:www\.)?(?:greenmotors|gadgetsweb)\.[a-z]{2,}')


def protector_url_ok(url):
	"""LOCAL PATCH 2026-11-18: is `url` a link-protector page this addon may fetch -- https, and a hostname that IS
	greenmotors.<tld> / gadgetsweb.<tld>? The sites' HTML decides which URLs get fetched; a substring test ('greenmotors' in
	the URL or host) let a page point the addon at any address, LAN devices included (http://192.168.1.1/greenmotors.x,
	greenmotors.evil.example). Every real link seen is https://greenmotors.club (897 on HDHub4u + 4KHDHub, 2026-11-18)."""
	try: p = urlparse(html.unescape(url or ''))
	except ValueError: return False
	return p.scheme == 'https' and bool(_PROTECTOR_HOST.fullmatch((p.hostname or '').lower()))


def hubcloud_row(label, name, url, size='', info=None, **extra):
	"""LOCAL PATCH 2026-11-18: one site scraper row (Stremio-shaped; http_streams._make_item reads it): a HubCloud page,
	resolved at play time (sources.resolve_sources -> hubcloud.resolve)."""
	row = {'name': '%s | HubCloud' % label, 'title': name, 'url': url, 'size': size or '', 'info': info or label, 'resolver': 'hubcloud'}
	row.update(extra)
	return row


# LOCAL PATCH 2026-11-18: a value kept in a Home window property -- every DeadLight process (plugin calls, the service's
# prewarm) sees it, and it is gone at Kodi's restart. JSON with its time; the site scrapers keep their search answers here
# (one search serves every episode of a show), the sites' addresses too (site_host / with_site_host).
def recall(prop, ttl):
	"""The value kept under `prop` while younger than `ttl` seconds (any age when `ttl` is None), else None."""
	import json
	try:
		kept = json.loads(get_property(prop) or 'null')
		if isinstance(kept, dict) and 't' in kept and (ttl is None or time.time() - kept['t'] < ttl): return kept.get('v')
	except (ValueError, TypeError): pass
	return None


def keep(prop, value):
	import json
	set_property(prop, json.dumps({'t': int(time.time()), 'v': value}))


def forget(prop):
	clear_property(prop)


def hubdrive_links(page):
	return list(dict.fromkeys(_HUBDRIVE_FILE.findall(page or '')))


def hubcloud_recover_links(page):
	return list(dict.fromkeys(html.unescape(u) for u in _HUBCLOUD_RECOVER.findall(page or '')))


def hubdrive_file(url):
	try: page = get(url).text
	except Exception: return None
	name, size, cloud = _HUBDRIVE_NAME.search(page), _HUBDRIVE_SIZE.search(page), _HUBCLOUD_DRIVE.search(page)
	if not (name and cloud): return None
	return {'file_name': html.unescape(name.group(1)).strip(), 'size': size.group(1) if size else '',
			'url': cloud.group(1), 'mimeType': 'video'}


def hubcloud_file(url):
	try:
		from scrapers.hubcloud import drive_info
		name, size = drive_info(url)
	except Exception: return None
	if not name: return None
	return {'file_name': name, 'size': size, 'url': url, 'mimeType': 'video'}


def hubdrive_pack_files(page, wanted, quality_pattern=None, diagnostics=''):
	"""HubDrive file URLs for wanted episode names in the pack pages linked from a post/archive."""
	packs = list(dict.fromkeys(_HUBDRIVE_PACK.findall(page or '')))
	discovered = len(packs)
	if quality_pattern:
		# Site posts often put the pack's resolution in its anchor label ('1080p WEB-DL PACK',
		# '4K/2160p SDR WEB-DL PACK'). Skip an explicitly lower-resolution pack before fetching it.
		labels = {}
		for url, label in _HUBDRIVE_PACK_ANCHOR.findall(page or ''):
			label = html.unescape(re.sub(r'<[^>]+>', ' ', label))
			labels[url] = label
		packs = [url for url in packs if url not in labels or not KNOWN_QUALITY.search(labels[url])
				 or quality_pattern.search(labels[url])]
	if not packs or not wanted:
		if diagnostics:
			logger('HDHub4u packs', '%s: %d recognized pack URL(s), %d eligible after quality filter' %
				   (diagnostics, discovered, len(packs)))
		return []
	tags = [episode_tag(s, e) for s, e in wanted]
	def pack_files(pack):
		try: text = get(pack).text
		except Exception as error:
			return [], 0, type(error).__name__
		base = '%s://%s' % (urlparse(pack).scheme, urlparse(pack).netloc)
		entries = _PACK_ENTRY.findall(text)
		matches = []
		for path, name in entries:
			name = html.unescape(name)
			if not any(tag.search(name) for tag in tags): continue
			if quality_pattern and KNOWN_QUALITY.search(name) and not quality_pattern.search(name): continue
			matches.append(base + path)
		return matches, len(entries), ''
	with ThreadPoolExecutor(max_workers=min(3, len(packs))) as pool:
		results = list(pool.map(pack_files, packs))
	files = list(dict.fromkeys(url for found, _, _ in results for url in found))
	if diagnostics:
		errors = [error for _, _, error in results if error]
		logger('HDHub4u packs', '%s: %d recognized pack URL(s), %d eligible, %d fetch failed%s, '
			   '%d parsed entries, %d matching episode file(s)' %
			   (diagnostics, discovered, len(packs), len(errors), ' (%s)' % ', '.join(sorted(set(errors))) if errors else '',
				sum(count for _, count, _ in results), len(files)))
	return files


def protector_targets(page):
	"""Decode Greenmotors/Gadgetsweb's base64 -> base64 -> ROT13 -> base64 payload URL."""
	import base64
	import json
	values = []
	for pattern in (_PROTECTOR_S, _PROTECTOR_CK): values.extend(m.group(3) for m in pattern.finditer(page or ''))
	def decode(value):
		def b64(text):
			text = re.sub(r'\s+', '', text or '').replace('-', '+').replace('_', '/')
			text += '=' * (-len(text) % 4)
			return base64.b64decode(text).decode('utf-8')
		try:
			stage = b64(value)
			stage = b64(stage)
			payload = json.loads(b64(stage.translate(_ROT13)))
			target = b64(payload.get('o') or '')
			p = urlparse(target)
			host = (p.hostname or '').lower()
			if p.scheme == 'https' and p.netloc and (_PROTECTED_ARCHIVE.match(target) or re.fullmatch(r'(?:www\.)?hub(?:cloud|drive)\.[a-z]+', host)):
				return target
		except Exception: pass
		return ''
	targets = []
	for value in values:
		target = decode(html.unescape(value))
		if target and target not in targets: targets.append(target)
	return targets


def recover_query_ok(query, quality_pattern=None):
	"""LOCAL PATCH 2026-11-22: is a search-recover link worth asking, given the quality rule? A query that states a dropped
	resolution ('Animal 2023 720p') is skipped; a generic one is asked AS IS -- only a link's own query is sent (hubcloud.py),
	and its hits are filtered by name instead."""
	return not quality_pattern or stated_quality_ok(query) is not False


def _protected_recover_hits(url, quality_pattern):
	from scrapers.hubcloud import recover_query, recover_hits
	if not recover_query_ok(recover_query(url), quality_pattern): return []
	hits = recover_hits(url)
	return [hit for hit in hits if quality_pattern.search(hit.get('file_name') or '')] if quality_pattern else hits


def protected_target_files(target, referer, wanted=(), fast=False, quality_pattern=None):
	"""Read one decoded HBLINKS/HubDrive/HubCloud target into HubCloud file-page hits."""
	files = {}
	def cloud_hit(url):
		if fast: return {'file_name': '', 'size': '', 'url': url, 'mimeType': 'video'}
		return hubcloud_file(url)
	try:
		if _PROTECTED_ARCHIVE.match(target):
			archive = get(target, referer=referer).text
			drive_pages = hubdrive_links(archive)
			drive_pages.extend(url for url in hubdrive_pack_files(archive, wanted, quality_pattern) if url not in drive_pages)
			with ThreadPoolExecutor(max_workers=min(4, len(drive_pages) or 1)) as pool:
				for hit in pool.map(hubdrive_file, drive_pages):
					if hit and (not quality_pattern or quality_pattern.search(hit.get('file_name') or '')):
						files.setdefault(hit['url'], hit)
			recover_urls = hubcloud_recover_links(archive)
			if recover_urls:
				def recover(url):
					try: return _protected_recover_hits(url, quality_pattern)
					except Exception: return []
				with ThreadPoolExecutor(max_workers=min(3, len(recover_urls))) as pool:
					for found in pool.map(recover, recover_urls):
						for hit in found:
							if hit.get('url'): files.setdefault(hit['url'], hit)
			cloud_urls = list(dict.fromkeys(_HUBCLOUD_DRIVE.findall(archive)))
			with ThreadPoolExecutor(max_workers=min(4, len(cloud_urls) or 1)) as pool:
				for hit in pool.map(cloud_hit, cloud_urls):
					if hit and (not quality_pattern or quality_pattern.search(hit.get('file_name') or '')):
						files.setdefault(hit['url'], hit)
		elif '/file/' in target and 'hubdrive.' in target:
			hit = hubdrive_file(target)
			if hit and (not quality_pattern or quality_pattern.search(hit.get('file_name') or '')):
				files.setdefault(hit['url'], hit)
		elif '/drive/search-recover.php' in target and 'hubcloud.' in target:
			for hit in _protected_recover_hits(target, quality_pattern):
				if hit.get('url'): files.setdefault(hit['url'], hit)
		elif '/drive/' in target and 'hubcloud.' in target:
			hit = cloud_hit(target)
			if hit and (not quality_pattern or quality_pattern.search(hit.get('file_name') or '')):
				files.setdefault(hit['url'], hit)
	except Exception: pass
	return list(files.values())


def protected_page_files(page, referer, wanted=(), fast=False, quality_pattern=None):
	targets = protector_targets(page)
	files = {}
	if targets:
		with ThreadPoolExecutor(max_workers=min(4, len(targets))) as pool:
			groups = pool.map(lambda target: protected_target_files(target, referer, wanted, fast=fast,
														 quality_pattern=quality_pattern), targets)
			for found in groups:
				for hit in found:
					if hit.get('url'): files.setdefault(hit['url'], hit)
	return list(files.values()), len(targets)


def with_site_host(prop, find, fallback, call):
	"""call(host) on the site's last known address (window property `prop`, else `fallback`) at once; only when that fails is
	the address looked up again (find(): 'https://host' or None) and call() retried there. For a site whose lookup is slow
	(MoviesDrive's: its landing page, then the homepage it points to, ~2-5 s) and whose old address keeps working a while."""
	known = recall(prop, None) or ''
	host = known if known.startswith('http') else fallback
	try: result = call(host)
	except Exception:
		fresh = None
		try: fresh = find()
		except Exception: pass
		if not fresh or fresh == host: raise
		host = fresh
		result = call(host)
	if host != known: keep(prop, host)
	return host, result


def site_post_page(prop, find, host, path, site_origin):
	"""Fetch a post and remember its final site origin after a domain move."""
	def fetch(origin):
		response = get(origin + path, referer=origin + '/')
		final = site_origin(response.url)
		if final and final != origin and urlparse(response.url).path in ('', '/'):
			response = get(final + path, referer=final + '/')
			final = site_origin(response.url)
		if not final or urlparse(response.url).path in ('', '/'):
			raise ValueError('Site post redirected away from the post')
		return final, response.text

	request_host, (final, page) = with_site_host(prop, find, host, fetch)
	if final != request_host:
		keep(prop, final)
	return final, page


def site_host(prop, find, fallback, ttl=12 * 3600):
	"""A site's current 'https://host', kept `ttl` in window property `prop`. find() works it out (None on failure); the last
	known one, else `fallback`, when it cannot."""
	current = recall(prop, ttl)
	if current: return current
	try: host = find()
	except Exception: host = None
	if host:
		keep(prop, host)
		return host
	last = recall(prop, None) or ''
	return last if last.startswith('http') else fallback
