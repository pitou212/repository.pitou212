# -*- coding: utf-8 -*-
"""4KHDHub.one movies and series scraper; resolves only matching release blocks via the site's protector."""
import html
import re
import time
from copy import deepcopy
from concurrent.futures import ThreadPoolExecutor
from threading import Event, Lock
from urllib.parse import quote_plus, urljoin, urlparse

from modules.kodi_utils import logger
from modules.source_utils import get_aliases_titles
from scrapers._site_common import (get as _get, episode_tag as _episode_tag, norm_title as _norm, title_prefix_ok,
							  protected_page_files as _protected_page_files, hubcloud_file as _hubcloud_file,
							  film_name_ok, hubcloud_row, recall, keep, forget, protector_url_ok, episode_pairs)

LABEL = '4KHDHub'
_BASE = 'https://4khdhub.one'
_ANCHOR = re.compile(r'''(?is)<a\b[^>]*href=["']([^"']+)["'][^>]*>(.*?)</a>''')
_BLOCK = re.compile(r'''(?is)<div\b(?=[^>]*\bclass=["'][^"']*(?:episode-download-item|download-item)[^"']*["'])[^>]*>''')
_FILENAME = re.compile(r'''(?i)([^<>\r\n]+?\.(?:mkv|mp4|avi|ts|webm))\b''')
_SIZE = re.compile(r'''(?i)(?<![\w.])([\d.,]+\s*(?:TiB|GiB|MiB|KiB|TB|GB|MB|KB))\b''')
_PROTECTOR_LINK = re.compile(r'''(?is)<a\b[^>]*href=["'](https?://[^"']*(?:greenmotors|gadgetsweb)\.[^"']+)["'][^>]*>(?:(?!</a>).)*?Download\s*(HubCloud|HubDrive)''')
_CACHE_TTL = 10 * 60
_EMPTY_CACHE_TTL = 60
_CACHE_LOCK = Lock()
_CACHE = {}
_INFLIGHT = {}
_FAILED = {}          # key -> (expiry, exception): an owner's failure, re-raised to the callers that waited on it
_FAILED_TTL = 5


def scrape(info):
	"""Coalesce repeated prewarm/foreground requests and reuse stable HubCloud page links briefly."""
	key = _cache_key(info)
	now = time.time()
	with _CACHE_LOCK:
		cached = _CACHE.get(key)
		if cached and cached[0] > now: return deepcopy(cached[1])
		if cached: _CACHE.pop(key, None)
		event = _INFLIGHT.get(key)
		owner = event is None
		if owner:
			event = Event()
			_INFLIGHT[key] = event
	if not owner:
		event.wait(25)
		with _CACHE_LOCK:
			cached = _CACHE.get(key)
			if cached and cached[0] > time.time(): return deepcopy(cached[1])
			failed = _FAILED.get(key)
		if failed and failed[0] > time.time(): raise failed[1]   # the owner's request just failed: don't repeat it
		return _scrape(info)
	try:
		try: rows = _scrape(info)
		except Exception as e:
			with _CACHE_LOCK: _FAILED[key] = (time.time() + _FAILED_TTL, e)
			raise
		with _CACHE_LOCK:
			for old_key, value in list(_CACHE.items()):
				if value[0] <= time.time(): _CACHE.pop(old_key, None)
			while len(_CACHE) >= 256: _CACHE.pop(next(iter(_CACHE)))
			_CACHE[key] = (time.time() + (_CACHE_TTL if rows else _EMPTY_CACHE_TTL), deepcopy(rows))
			_FAILED.pop(key, None)
		return rows
	finally:
		with _CACHE_LOCK:
			_INFLIGHT.pop(key, None)
			event.set()


def _cache_key(info):
	return (info.get('media_type'), str(info.get('tmdb_id') or info.get('imdb_id') or ''), info.get('title'),
			str(info.get('year') or ''), str(info.get('season') or ''),
			str(info.get('episode') or ''), repr(info.get('episode_candidates') or []), repr(info.get('aliases') or []))


def _scrape(info):
	"""Stremio-shaped results for one movie or one episode."""
	media_type = info.get('media_type')
	if media_type not in ('movie', 'episode'): return []
	title = info.get('title') or ''
	aliases = get_aliases_titles(info.get('aliases', []))
	titles = set(n for n in (_norm(t) for t in [title] + aliases) if n)
	title_phrases = set(n for n in (_word_norm(t) for t in [title] + aliases) if n)
	if not titles: return []
	season = episode = None
	wanted = []
	if media_type == 'episode':
		try: season, episode = int(info.get('season')), int(info.get('episode'))
		except (TypeError, ValueError): return []
		if season < 1: return []
		# the searched pair, the card's candidates and the absolute number under a season label where it cannot be that
		# season's own episode (Blue Box 'S02E26', Naruto 1080p 'S01E53'): _site_common.episode_pairs
		wanted = episode_pairs(info, season, episode)
	# Series cards often omit the show's premiere year (or use a slug containing another year).
	# Keep year matching for films, but don't reject a title-matched TV post on that basis.
	find = lambda: _find_post(title, info.get('year') if media_type == 'movie' else None, media_type, title_phrases)
	# The post is one page per show (every season, every episode), so its address is kept 12 h in a Home property that
	# every DeadLight process sees: the next episode skips the 0.4-1 s search. Only a found post is kept; a search error
	# still raises (http_streams must count the provider as failed, not cache an empty answer).
	prop = _post_prop(info, media_type, title)
	post = recall(prop, _POST_TTL)
	from_cache = bool(post)
	if not post:
		post = find()
		if post: keep(prop, post)
	if not post:
		logger(LABEL, '%s: no matching post' % title)
		return []
	try: page = _get(post, referer=_BASE + '/').text
	except Exception:
		if not from_cache: raise
		forget(prop)   # the kept address stopped answering (post moved or removed): search again, once
		post = find()
		if not post:
			logger(LABEL, '%s: no matching post' % title)
			return []
		keep(prop, post)
		page = _get(post, referer=_BASE + '/').text
	blocks = _file_blocks(page)
	selected = []
	for filename, size, block in blocks:
		if not _matches_file(filename, media_type, wanted, titles, info.get('year'), title_phrases): continue
		links = [(html.unescape(url), kind) for url, kind in _PROTECTOR_LINK.findall(block) if protector_url_ok(url)]
		# Prefer HubCloud, then fall back to HubDrive when its protector or archive is broken.
		urls = [url for url, kind in links if kind.lower() == 'hubcloud']
		urls += [url for url, kind in links if kind.lower() == 'hubdrive']
		urls = list(dict.fromkeys(urls))
		if urls: selected.append((filename.strip(), size, urls))
	if not selected:
		logger(LABEL, '%s%s: no matching release blocks (%s)' % (title, ' S%02dE%02d' % (season, episode) if season else '',
			', '.join('S%02dE%02d' % p for p in wanted) or 'film'))
		return []
	# Every matching block at once (up to eight concurrent protector chains).
	with ThreadPoolExecutor(max_workers=min(8, len(selected))) as pool:
		groups = list(pool.map(lambda item: _resolve_block(item, media_type, wanted, titles, title_phrases, info.get('year')),
							  selected))
	hits, errors = {}, [error for _found, error in groups if error]
	for (filename, size, _urls), (found, _error) in zip(selected, groups):
		for hit in found:
			if not hit.get('file_name'): hit['file_name'] = filename
			if not hit.get('size'): hit['size'] = size
			# Prefer the block's exact filename if a protector archive lists more than one file.
			if _matches_file(hit.get('file_name') or '', media_type, wanted, titles, info.get('year'), title_phrases):
				hits.setdefault(hit.get('url'), hit)
	if not hits:
		# a block whose links all failed to load: raise, so http_streams counts the provider as failed and does not cache
		# this empty answer for an hour (an outage would otherwise hide the episode's 4KHDHub files until it expired)
		if errors:
			logger(LABEL, '%s: %d matching file block(s), %d unreachable: %r' % (title, len(selected), len(errors), errors[0]))
			raise errors[0]
		logger(LABEL, '%s: %d matching file block(s), no playable HubCloud link' % (title, len(selected)))
		return []
	rows = [hubcloud_row(LABEL, hit.get('file_name') or '', hit['url'], hit.get('size')) for hit in hits.values()]
	logger(LABEL, '%s%s: %d file(s) from %d matching release block(s)' %
		   (title, ' S%02dE%02d' % (season, episode) if season else '', len(rows), len(selected)))
	return rows


_POST_TTL = 12 * 3600


def _post_prop(info, media_type, title):
	"""The Home property keeping a show's / film's post address: by TMDb id, else by title (+ year for a film)."""
	ident = info.get('tmdb_id') or ('%s_%s' % (_word_norm(title).replace(' ', '_'), info.get('year') if media_type == 'movie' else ''))
	return 'deadlight.4khdhub.post.%s.%s' % (media_type, ident)


def _find_post(title, year, media_type, title_phrases):
	"""One fast title search; prefer a URL slug for the requested media type, allowing unmarked slugs as fallback."""
	queries = [title]
	if year: queries.append('%s %s' % (title, year))
	all_candidates = []
	for query in dict.fromkeys(queries):
		result = _get(_BASE + '/?s=' + quote_plus(query), referer=_BASE + '/').text
		candidates = []
		for match in _ANCHOR.finditer(result):
			url = urljoin(_BASE, html.unescape(match.group(1)))
			parsed = urlparse(url)
			if parsed.netloc.lower() != '4khdhub.one' or parsed.path in ('/', '') or parsed.path.startswith('/category/'): continue
			path = parsed.path.lower()
			type_marker = '-series-' if media_type == 'episode' else '-movie-'
			other_marker = '-movie-' if media_type == 'episode' else '-series-'
			if other_marker in path: continue
			path_rank = 2 if type_marker in path else 1
			text = _word_norm(re.sub(r'<[^>]+>', ' ', html.unescape(match.group(2))))
			if type_marker in path:
				slug_title = _word_norm(path.split(type_marker, 1)[0].rsplit('/', 1)[-1])
				if not _slug_title_matches(slug_title, title_phrases, year): continue
			elif not any(_title_in_text(t, text) for t in title_phrases):
				continue
			year_match = bool(year and re.search(r'(?<!\d)%s(?!\d)' % re.escape(str(year)), text + ' ' + parsed.path))
			if year and not year_match: continue
			candidates.append((path_rank, int(year_match), url))
		if candidates:
			all_candidates.extend(candidates)
			if any(rank == 2 for rank, _year_match, _url in candidates): break
	if all_candidates:
		all_candidates.sort(key=lambda c: (c[0], c[1]), reverse=True)
		return all_candidates[0][2]
	return ''


def _file_blocks(page):
	starts = list(_BLOCK.finditer(page or ''))
	result = []
	for i, match in enumerate(starts):
		block = page[match.start():starts[i + 1].start() if i + 1 < len(starts) else len(page)]
		plain = html.unescape(re.sub(r'<[^>]+>', ' ', block))
		name = _FILENAME.search(plain)
		if name:
			size = _SIZE.search(plain)
			result.append((re.sub(r'\s+', ' ', name.group(1)).strip(), size.group(1) if size else '', block))
	return result


def _matches_file(name, media_type, wanted, titles, year, title_phrases):
	name = html.unescape(name or '').strip()
	if media_type == 'episode':
		return any(_episode_tag(s, e).search(name) for s, e in wanted) and title_prefix_ok(name, _episode_start(name), titles)
	return film_name_ok(name, year, titles)   # the one film rule all site scrapers share


def _title_in_text(title, text):
	return bool(title and re.search(r'(?<!\w)%s(?!\w)' % re.escape(title), text or ''))


def _word_norm(text):
	from modules.source_utils import normalize
	text = normalize(html.unescape(text or '')).lower()
	text = re.sub(r"['’`]", '', text)   # Handmaid's -> handmaids, as the site's slugs and file names write it
	return re.sub(r'[^\w]+', ' ', text, flags=re.UNICODE).strip()


def _slug_title_matches(slug_title, titles, year):
	if year:
		slug_title = re.sub(r'\s+%s$' % re.escape(str(year)), '', slug_title).strip()
	return slug_title in titles


def _episode_start(name):
	for s, e in [(int(m.group(1)), int(m.group(2))) for m in re.finditer(r'(?i)(?<![a-z0-9])S(\d{1,2})[ ._-]?E(\d{1,3})(?!\d)', name)]:
		m = _episode_tag(s, e).search(name)
		if m: return m.start()
	return 0


def _resolve_block(item, media_type, wanted, titles, title_phrases, year):
	"""(hits, error): error is the last request failure when EVERY link of the block failed to load, else None -- an
	answer the site gave (no matching file) is not an error."""
	filename, _size, urls = item
	error, answered = None, False
	for url in urls:
		try: page = _get(url, referer=_BASE + '/').text
		except Exception as e:
			error = e
			continue
		answered = True
		found, _count = _protected_page_files(page, url, wanted, fast=True)
		# The block name identifies a fast-path HubCloud URL only when the protector returned one file.
		single_unnamed = len(found) == 1 and not found[0].get('file_name')
		if len(found) > 1:
			unnamed = [hit for hit in found if not hit.get('file_name')]
			if unnamed:
				with ThreadPoolExecutor(max_workers=min(4, len(unnamed))) as pool:
					metadata = pool.map(_hubcloud_file, (hit['url'] for hit in unnamed))
					resolved = {hit['url']: hit for hit in metadata if hit}
				found = [hit if hit.get('file_name') else resolved[hit['url']] for hit in found
						 if hit.get('file_name') or hit['url'] in resolved]
		matching = []
		for hit in found:
			name = hit.get('file_name') or (filename if single_unnamed else '')
			if not name: continue
			if _matches_file(name, media_type, wanted, titles, year, title_phrases):
				if not hit.get('file_name'): hit['file_name'] = filename
				if not hit.get('size'): hit['size'] = _size
				matching.append(hit)
		if matching:
			block_name = _word_norm(filename)
			exact = [hit for hit in matching if _word_norm(hit.get('file_name') or '') == block_name]
			return exact or matching, None
	return [], (None if answered else error)
