# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-11-18: a HubCloud /drive/<id> page -> a link Kodi can play. Called at PLAY time (sources.resolve_sources,
rows carrying resolver='hubcloud'): the file link it ends in is a signed Cloudflare R2 URL that expires.

The chain, as measured 2026-11-18 (hubcloud.mov, ~1.5 s in all, no browser check on any step):
  drive page                  -> 'Generate Direct Download Link' (var url = 'https://gamerxyt.com/hubcloud.php?...')
  that page                   -> 'Download [PixelServer : 2]' PixelDrain page (/u/<id>; the file is /api/file/<id>). The
                                                               button's href is a DECOY ('negn6f' on every file): a script
                                                               after it sets the real one (var pxl = "...")
                                 'Download [FSL Server]'     signed R2 link (not offered for every file)
                                 'Download [Server : 10Gbps]' redirects to an ad page (cryptonewz.online) -- never used
                                 'Download File [341.71 MB]'  on some files: a Workers link serving the file itself
FSL first, then FSLv2, PixelDrain, and the 'File' link (not measured yet), following the user's requested mirror order. The
first that serves the file (http_streams.direct_url_alive: a range request, HTML refused -- PixelDrain can return an HTML
limit page) is played."""
import html
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from modules.kodi_utils import make_session, logger, stream_request_parts

_session = make_session('https://')
_GENERATE = (re.compile(r'''var\s+url\s*=\s*['"](https?://[^'"]+)['"]'''),
			 re.compile(r'''href=["'](https?://[^"']+/hubcloud\.php\?[^"']+)["']'''))
# 'Download [FSL Server]' and, on some files instead, 'Download File [341.71 MB]' (a Cloudflare Workers link that serves the
# file itself: 206, ranges, Matroska -- 2026-11-18, Panchayat S04E01 720p); the label keeps 'File' so _rank tells it apart
_DOWNLOAD = re.compile(r'''<a[^>]+href=["']([^"']+)["'][^>]*>(?:(?!</a>).)*?Download\s*((?:File\s*)?\[[^\]]+)\]''', re.S | re.I)
_PIXELDRAIN_PAGE = re.compile(r'^(https?://pixeldrain\.[a-z]+)/u/([A-Za-z0-9]+)', re.I)
_PIXEL_SCRIPT = re.compile(r'''var\s+pxl\s*=\s*["'](https?://[^"']+)["']''')


def _rank(label):
	label = label.lower()
	if 'fsl' in label and re.search(r'fsl[\s_-]*v[\s_-]*2|version\s*2', label): return 1
	if 'fsl' in label: return 0
	if 'pixel' in label: return 2
	return 3


_SIZE = re.compile(r'''id=["']size["'][^>]*>\s*([\d.,]+\s*[KMGT]i?B)''', re.I)


def _drive_page(drive_url, timeout):
	_link, headers = stream_request_parts(drive_url)
	return _session.get(drive_url, headers=headers, timeout=timeout).text, headers


_TITLE = re.compile(r'<title>\s*([^<]+?)\s*</title>', re.I)


def drive_info(drive_url, timeout=8):
	"""(file name, size) as the drive page states them -- its <title> is the file name ('[AnimeDubHindi] ReLIFE S01E01 ...mkv'),
	'File Size' the size ('109.42 MB'); ('', '') when the page cannot be read."""
	try: page = _drive_page(drive_url, timeout)[0]
	except Exception: return '', ''
	name, size = _TITLE.search(page), _SIZE.search(page)
	return (html.unescape(name.group(1)) if name else ''), (size.group(1) if size else '')


def drive_size(drive_url, timeout=8):
	"""The size alone, for a listing that gives none (AnimeDubHindi's '[480P x264]' lines): a sizeless row falls to the
	results' size filter."""
	return drive_info(drive_url, timeout)[1]


def download_links(drive_url, timeout=10):
	"""[(label, url)] the drive page's generator offers, best first; the 10Gbps page left out. [] when the chain breaks."""
	page, headers = _drive_page(drive_url, timeout)
	gen = next((m.group(1) for m in (rx.search(page) for rx in _GENERATE) if m), None)
	if not gen:
		logger('hubcloud', 'no generate link on %s' % drive_url)
		return []
	page = _session.get(html.unescape(gen), headers=dict(headers, Referer=drive_url), timeout=timeout).text
	links, pixel = [], _PIXEL_SCRIPT.search(page)
	for url, label in _DOWNLOAD.findall(page):
		url, label = html.unescape(url).strip(), ' '.join(label.replace('[', ' ').split())
		if 'pixel' in label.lower() and pixel: url = pixel.group(1)   # the script's link, not the decoy href
		if '10gbps' in label.lower() or not url.startswith('http'): continue
		m = _PIXELDRAIN_PAGE.match(url)
		if m: url = '%s/api/file/%s' % (m.group(1), m.group(2))
		links.append((label, url))
	return sorted(links, key=lambda lu: _rank(lu[0]))


# LOCAL PATCH 2026-11-18: HubCloud's 'search-recover' links (hubcloud.*/drive/search-recover.php?from_ac=<token>&q=<base64>), what
# HDHub4u's newer season posts and MoviesDrive's older posts link instead of a file: a page that searches HubCloud's file
# index for its query ('Panchayat S04 Episode 1', 'Animal 2023 1080p'). Only a link's own query is asked: the page marks it
# locked (the server does not enforce that; DeadLight keeps to it). The 4K / 1080p rule filters the hits by name instead
# (_site_common.recover_query_ok, 2026-11-22).
_RECOVER_PAGES = 8   # 20 hits a page; Panchayat S04 Episode 1 had 139 (7 pages)
_HUBCLOUD_CURRENT = 'hubcloud.mov'   # where the posts' older HubCloud domains redirect to (2026-11-18)


def recover_query(drive_url):
	"""A search-recover link's locked query: q is base64 without padding ('UGFuY2hheWF0IFMwNCBFcGlzb2RlIDE' -> 'Panchayat S04 Episode 1')."""
	try:
		import base64
		from urllib.parse import parse_qs, urlparse
		q = (parse_qs(urlparse(drive_url).query).get('q') or [''])[0]
		return base64.urlsafe_b64decode(q + '=' * (-len(q) % 4)).decode('utf-8', 'replace')
	except Exception: return ''


def recover_hits(drive_url):
	"""Every hit of a search-recover link's own search ({'file_name', 'size', 'mimeType', 'url': hubcloud.*/drive/<id>}):
	page 1, then the rest 3 at once (7 pages in 1.2 s). Raises when HubCloud cannot be reached."""
	from concurrent.futures import ThreadPoolExecutor
	from urllib.parse import parse_qs, urlparse
	from scrapers._site_common import get
	p = urlparse(drive_url)
	params = parse_qs(p.query)
	# HubCloud's current domain first: a post's older one (hubcloud.ist) answered 302 -> hubcloud.mov one minute and reset
	# the connection the next (2026-11-18); then the post's own, in case HubCloud has moved on again
	bases = ['https://%s%s' % (_HUBCLOUD_CURRENT, p.path)] + (['%s://%s%s' % (p.scheme, p.netloc, p.path)] if p.netloc != _HUBCLOUD_CURRENT else [])
	ask = lambda page: get(base, params={'api': 'search', 'q': recover_query(drive_url), 'page': str(page), 'from_ac': params.get('from_ac', [''])[0]},
						   referer=drive_url, accept='application/json').json()
	for n, base in enumerate(bases):
		try:
			first = ask(1)
			break
		except Exception:
			if n == len(bases) - 1: raise
	hits = list(first.get('hits') or [])
	pages = min(_RECOVER_PAGES, -(-int(first.get('found') or 0) // int(first.get('per_page') or 20)))
	if pages > 1:
		with ThreadPoolExecutor(max_workers=min(3, pages - 1)) as ex:
			for d in ex.map(ask, range(2, pages + 1)): hits += d.get('hits') or []
	return hits


def resolve(drive_url):
	from scrapers.http_streams import source as http_streams
	try: links = download_links(drive_url)
	except Exception as e:
		logger('hubcloud', '%s: %s: %s' % (drive_url, type(e).__name__, e))
		return None
	if links:
		# LOCAL PATCH 2026-11-19: check mirrors together, but keep the site's preference order: don't return a lower-ranked success until every
		# higher-ranked candidate has failed its probe. This avoids serial timeout delays without changing mirror choice.
		pool = ThreadPoolExecutor(max_workers=min(4, len(links)))
		futures = {}
		for index, (label, url) in enumerate(links):
			futures[pool.submit(http_streams.direct_url_alive, url)] = (index, label, url)
		checked, next_index = {}, 0
		try:
			for future in as_completed(futures):
				index, label, url = futures[future]
				try: alive = future.result()
				except Exception: alive = False
				checked[index] = (label, url, alive)
				while next_index in checked and not checked[next_index][2]: next_index += 1
				if next_index in checked:
					label, url, _alive = checked[next_index]
					logger('hubcloud', '%s -> %s' % (drive_url, label))
					return url
		finally:
			# Other probes may still be waiting on a host's timeout. They are tiny range checks and finish under their own
			# timeout; don't make the selected mirror wait for them. Kodi 21 ships Python 3.8, whose shutdown() has no
			# cancel_futures argument, so cancel queued work explicitly before shutting down.
			for future in futures:
				if not future.done(): future.cancel()
			pool.shutdown(wait=False)
	# LOCAL PATCH 2026-11-22 (user's call): no unverified fallback. A page none of whose links passes the player-style check
	# (http_streams.direct_url_alive) is dead: resolve_sources moves on to the next source instead of handing Kodi a link
	# that 403s (HubCloud's Workers 'File' links, session 67). The 2026-11-19 fallback (Two Towers' 108.94 GB File link
	# failed the probe, then downloaded in a browser) let every dead page reach Kodi.
	logger('hubcloud', '%s: none of %d link(s) served the file (%s)' % (drive_url, len(links), ', '.join(l for l, _u in links) or 'none offered'))
	return None
