# -*- coding: utf-8 -*-
import sys
from datetime import datetime
from modules.utils import datetime_workaround
from apis.real_debrid_api import RealDebrid
from modules import kodi_utils
from indexers.cloud_listing import cloud_listitem, end_cloud_directory
from modules.source_utils import supported_video_extensions
from modules.utils import clean_file_name, normalize, jsondate_to_datetime
logger = kodi_utils.logger

def rd_cloud():
	def _builder():
		for count, item in enumerate(cloud_files, 1):
			try:
				cm = []
				cm_append = cm.append
				folder_name, folder_id = item['filename'], item['id']
				clean_folder_name = clean_file_name(normalize(folder_name)).upper()
				display = '%02d | [B]FOLDER[/B] | [I]%s [/I]' % (count, clean_folder_name)
				url_params = {'mode': 'real_debrid.browse_rd_cloud', 'id': folder_id}
				delete_params = {'mode': 'real_debrid.delete', 'id': folder_id, 'cache_type': 'torrent'}
				cm_append(('[B]Delete Folder[/B]','RunPlugin(%s)' % kodi_utils.build_url(delete_params)))
				cm_append(('[B]Delete All From Cloud[/B]','RunPlugin(%s)' % kodi_utils.build_url({'mode': 'real_debrid.delete_all', 'cache_type': 'torrent'})))
				url = kodi_utils.build_url(url_params)
				listitem = cloud_listitem(display, cm, icon, fanart)
				yield (url, listitem, True)
			except: pass
	try:
		cloud_files = RealDebrid.user_cloud()
		cloud_files = [i for i in cloud_files if i['progress'] == 100 and i['status'] == 'downloaded']
		logger('cloud_files', cloud_files)
	except: cloud_files = []
	icon, fanart = kodi_utils.get_icon('realdebrid'), kodi_utils.get_addon_fanart()
	handle = int(sys.argv[1])
	end_cloud_directory(handle, _builder())

def rd_downloads():
	def _builder():
		for count, item in enumerate(downloads, 1):
			try:
				cm = []
				cm_append = cm.append
				datetime_object = jsondate_to_datetime(item['generated'], '%Y-%m-%dT%H:%M:%S.%fZ', remove_time=True)
				filename, size = item['filename'], float(int(item['filesize']))/1073741824
				name = clean_file_name(filename).upper()
				display = '%02d | %.2f GB | %s  | [I]%s [/I]' % (count, size, datetime_object, name)
				url_link = item['download']
				url_params = {'mode': 'playback.video', 'url': url_link, 'obj': 'video'}
				down_file_params = {'mode': 'downloader.runner', 'name': name, 'url': url_link, 'action': 'cloud.realdebrid_direct', 'image': icon}
				delete_params = {'mode': 'real_debrid.delete', 'id': item['id'], 'cache_type': 'download'}
				cm_append(('[B]Download File[/B]','RunPlugin(%s)' % kodi_utils.build_url(down_file_params)))
				cm_append(('[B]Delete File[/B]','RunPlugin(%s)' % kodi_utils.build_url(delete_params)))
				cm_append(('[B]Delete All Downloads[/B]','RunPlugin(%s)' % kodi_utils.build_url({'mode': 'real_debrid.delete_all', 'cache_type': 'download'})))
				url = kodi_utils.build_url(url_params)
				listitem = cloud_listitem(display, cm, icon, fanart)
				yield (url, listitem, True)
			except: pass
	try:
		downloads = RealDebrid.downloads()
		downloads = [i for i in downloads if i['download'].lower().endswith(tuple(supported_video_extensions()))]
	except: downloads = []
	icon, fanart = kodi_utils.get_icon('realdebrid'), kodi_utils.get_addon_fanart()
	handle = int(sys.argv[1])
	end_cloud_directory(handle, _builder())

def browse_rd_cloud(folder_id):
	def _builder():
		for count, item in enumerate(pack_info, 1):
			try:
				cm = []
				name, url_link, size = item['path'], item['url_link'], float(int(item['bytes']))/1073741824
				if name.startswith('/'): name = name.split('/')[-1]
				name = clean_file_name(name).upper()
				if url_link.startswith('/'): url_link = 'http' + url_link
				display = '%02d | [B]FILE[/B] | %.2f GB | [I]%s [/I]' % (count, size, name)
				url_params = {'mode': 'real_debrid.resolve_rd', 'url': url_link, 'play': 'true'}
				url = kodi_utils.build_url(url_params)
				down_file_params = {'mode': 'downloader.runner', 'name': name, 'url': url_link, 'action': 'cloud.realdebrid', 'image': icon}
				cm.append(('[B]Download File[/B]','RunPlugin(%s)' % kodi_utils.build_url(down_file_params)))
				listitem = cloud_listitem(display, cm, icon, fanart)
				yield (url, listitem, False)
			except: pass
	icon, fanart = kodi_utils.get_icon('realdebrid'), kodi_utils.get_addon_fanart()
	handle = int(sys.argv[1])
	cloud_files = RealDebrid.user_cloud_info(folder_id)
	c_files = cloud_files['files']
	files = [i for i in c_files if i['selected'] == 1 and i['path'].lower().endswith(tuple(supported_video_extensions()))]
	file_info = [dict(i, **{'url_link': cloud_files['links'][idx]}) for idx, i in enumerate(files)]
	pack_info = sorted(file_info, key=lambda k: k['path'])
	end_cloud_directory(handle, _builder())

def _rd_ok(result):
	"""Mirrors rd_delete's own test, plus the None the api returns when there is no token
	(reading .status_code off that would raise)."""
	try: return result.status_code not in (401, 403, 404)
	except Exception: return False

def rd_delete_all(cache_type):
	"""Scoped to the list being viewed. Real Debrid keeps torrents and downloads as two
	separate collections shown in two separate places, so a single 'delete everything'
	spanning both would delete things the user cannot even see from here."""
	from modules.debrid_cleanup import delete_all
	if cache_type == 'torrent':
		label, source, deleter = 'Real Debrid torrents', RealDebrid.user_cloud, RealDebrid.delete_torrent
	else:
		label, source, deleter = 'Real Debrid downloads', RealDebrid.downloads, RealDebrid.delete_download
	try: items = [i['id'] for i in (source() or [])]
	except Exception: items = []
	delete_all(label, items, lambda i: _rd_ok(deleter(i)), RealDebrid.clear_cache, kodi_utils.get_icon('realdebrid'))

def rd_delete(file_id, cache_type):
	if not kodi_utils.confirm_dialog(): return
	if cache_type == 'torrent': result = RealDebrid.delete_torrent(file_id)
	else: result = RealDebrid.delete_download(file_id) # cache_type: 'download'
	if result.status_code in (401, 403, 404): return kodi_utils.notification('Error')
	RealDebrid.clear_cache()
	kodi_utils.execute_builtin('Container.Refresh')

def resolve_rd(params):
	url = params['url']
	resolved_link = RealDebrid.unrestrict_link(url)
	if params.get('play', 'false') != 'true' : return resolved_link
	from modules.player import DeadLightPlayer
	DeadLightPlayer().run(resolved_link, 'video')

def rd_account_info():
	try:
		kodi_utils.show_busy_dialog()
		account_info = RealDebrid.account_info()
		expires = datetime_workaround(account_info['expiration'], '%Y-%m-%dT%H:%M:%S.%fZ')
		days_remaining = (expires - datetime.today()).days
		body = []
		append = body.append
		append('[B]Account:[/B] %s' % account_info['email'])
		append('[B]Username:[/B] %s' % account_info['username'])
		append('[B]Status:[/B] %s' % account_info['type'].capitalize())
		append('[B]Expires:[/B] %s' % expires)
		append('[B]Days Remaining:[/B] %s' % days_remaining)
		append('[B]Fidelity Points:[/B] %s' % account_info['points'])
		kodi_utils.hide_busy_dialog()
		return kodi_utils.show_text('REAL DEBRID', '\n\n'.join(body), font_size='large')
	except: kodi_utils.hide_busy_dialog()
