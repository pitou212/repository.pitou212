# -*- coding: utf-8 -*-
# LOCAL PATCH (2026-06-12): Port of HDHub + HDHub4u scrapers from plugin.video.tmdbmovies (Angelitto),
# resources/lib/scraper.py. Near-verbatim; only the top (imports + log shim) is adapted, so re-pulls stay easy.
# Entry points used by the http_streams.py wrapper:
#   - _scrape_json_provider(base_url, pattern, label, imdb_id, content_type, season, episode, ...)
#   - _identify_host_from_url(url)
#
# LOCAL PATCH 2026-11-01 (cleanup): TRIMMED to those two entry points and what they call (_extract_quality_from_string,
# get_headers, get_random_ua, log). Re-extract a function from upstream scraper.py when it is needed again; do not
# hand-edit the upstream code.

import requests
import xbmc
import re
from urllib.parse import urlparse
# LOCAL PATCH 2026-11-22: no urllib3.disable_warnings -- the Stremio requests are verified now (_stremio_session)

# ----- Adaptation shims (DeadLight side) -----

def log(msg, level=None):
    try: xbmc.log('DeadLight [http_streams]: %s' % str(msg), xbmc.LOGINFO)
    except: pass

# ----- End shims -----

def get_random_ua():
    return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0'

def get_headers():
    """Shim for tmdbmovies/config.get_headers — default JSON request headers."""
    return {
        'User-Agent': get_random_ua(),
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Connection': 'keep-alive',
    }

# =============================================================================
# _extract_quality_from_string  (from scraper.py:1917-2010)
# =============================================================================

def _extract_quality_from_string(text):
    """
    Extrage calitatea video dintr-un string.
    """
    if not text:
        return None
    
    t = text.lower()

    
    # === ADAUGARE NOUĂ: Detectare Multi-Rezoluție (pentru link-uri generice) ===
    clean_t = t.replace('ds4k', '').replace('hdr4k', '').replace('sdr4k', '').replace('4khdhub', '')
    res_count = sum(1 for r in ['2160p', '1080p', '720p', '480p', '360p'] if r in t)
    if re.search(r'(?:^|[\.\-\s_])4k(?:$|[\.\-\s_])', clean_t) and '2160p' not in t: 
        res_count += 1
    
    if res_count >= 2:
        return 'SD'
    # =======================================================================
    
    # =================================================================
    # METODA 1 (PRIORITARĂ): Caută AN.CALITATE sau AN-CALITATE
    # Exemplu: "2025.720p" sau "2025-1080p" sau "2025.4K"
    # =================================================================
    
    # Captează ce vine IMEDIAT după an (primul segment)
    after_year_match = re.search(r'(?:19|20)\d{2}[\.\-\s_]+([^\.\-\s_]+)', t)
    if after_year_match:
        first_segment = after_year_match.group(1).lower()
        
        # Verifică calități standard
        if first_segment.startswith('2160p'):
            return '4K'
        if first_segment.startswith('1080p'):
            return '1080p'
        if first_segment.startswith('720p'):
            return '720p'
        if first_segment.startswith('480p'):
            return '480p'
        if first_segment.startswith('360p'):
            return '360p'
        # 4K trebuie să fie EXACT "4k" la început, nu parte din alt cuvânt
        if first_segment == '4k' or first_segment.startswith('4k-') or first_segment.startswith('4k.'):
            return '4K'
    
    # =================================================================
    # METODA 2 (FALLBACK): Caută oriunde în text
    # IMPORTANT: 720p și 1080p au PRIORITATE față de 4K!
    # =================================================================
    
    # Verifică calitățile numerice ÎN ORDINE DE PRIORITATE
    # (evităm să găsim 4K din DS4K înainte de 720p real)
    if '720p' in t:
        return '720p'
    
    if '1080p' in t:
        return '1080p'
    
    if '2160p' in t:
        return '4K'
    
    if '480p' in t:
        return '480p'
    
    if '360p' in t:
        return '360p'
    
    # 4K DOAR dacă nu e precedat de literă (evită DS4K, HDR4K, SDR4K)
    # Pattern: spațiu/punct/început + 4k + non-literă
    if re.search(r'(?:^|[\.\-\s_])4k(?:$|[\.\-\s_])', t):
        return '4K'
    
    # UHD = 4K
    if 'uhd' in t or 'ultrahd' in t:
        # log(f"[QUALITY] Fallback: found UHD -> 4K")r
        return '4K'
    
    return None




# =============================================================================
# _identify_host_from_url  (from scraper.py:2035-2124)
# =============================================================================

def _identify_host_from_url(url):
    """Identifică numele host-ului din URL - VERSIUNE V3 cu TrashBytes și altele."""
    if not url:
        return 'Direct'
    
    url_lower = url.lower()
    
    # Ordinea contează - cele mai specifice primele!
    if 'pixeldrain.dev/api/file' in url_lower or 'pixeldrain.com/api/file' in url_lower:
        return 'PixelDrain'
    elif 'pixel.hubcdn' in url_lower:
        return 'HubPixel (10Gbps)'
    elif 'yummy.monster' in url_lower:
        return 'FSL Server'
    elif 'trashbytes.net' in url_lower:
        return 'TrashBytes'
    elif 'awsdllaaa' in url_lower or 'aws-storage' in url_lower:
        return 'FastCloud'
    elif 'bbdownload.filesdl' in url_lower:
        if 'adl.php' in url_lower:
            return 'FastCloud-02'
        elif 'fdownload.php' in url_lower:
            return 'DirectDL'
        else:
            return 'FilesDL'
    elif 'busycdn' in url_lower or 'instant.busycdn' in url_lower:
        return 'InstantDL'
    elif 'r2.cloudflarestorage.com' in url_lower:
        return 'FSL-V2'
    elif 'r2.dev' in url_lower or 'pub-' in url_lower:
        return 'CloudR2'
    elif 'gpdl' in url_lower and 'hubcdn' in url_lower:
        return 'HubCDN'
    elif 'fsl-lover' in url_lower:
        return 'FSL-Lover'
    elif 'fsl-buckets' in url_lower or 'fsl.gdboka' in url_lower:
        return 'CDN'
    elif 'gdboka' in url_lower:
        return 'FastServer'
    elif 'polgen.buzz' in url_lower:
        return 'Flash'
    elif 'workers.dev' in url_lower:
        return 'CFWorker'
    elif 'hubcdn' in url_lower:
        return 'HubCDN'
    elif 'hubcloud' in url_lower:
        return 'HubCloud'
    elif 'gdflix' in url_lower:
        return 'GDFlix'
    elif 'filesdl' in url_lower:
        return 'FilesDL'
    elif 'gofile' in url_lower:
        return 'GoFile'
    elif 'mediafire' in url_lower:
        return 'MediaFire'
    elif 'mega.nz' in url_lower or 'mega.co' in url_lower:
        return 'MEGA'
    elif 'streamtape' in url_lower:
        return 'StreamTape'
    elif 'doodstream' in url_lower or 'dood.' in url_lower:
        return 'DoodStream'
    elif 'mixdrop' in url_lower:
        return 'MixDrop'
    elif 'upstream' in url_lower:
        return 'UpStream'
    elif 'buzzheavie' in url_lower:
        return 'BuzzHeavie'
    elif 'bzzhr' in url_lower:
        return 'BuzzShort'
    elif 'buzzserver' in url_lower:
        return 'BuzzServer'
    else:
        # Încearcă să extragă din domeniu
        try:
            parsed = urlparse(url)
            domain = parsed.netloc.lower().replace('www.', '')
            parts = domain.split('.')
            if parts and len(parts[0]) >= 2:
                # Capitalizează prima literă
                return parts[0].title()
        except:
            pass
        
        return 'Direct'



# =============================================================================
# _scrape_json_provider  (from scraper.py:4344-4464)
# =============================================================================

_AUTO_QUALITY = re.compile(r'(?<![A-Za-z])Auto(?![A-Za-z])')

# LOCAL PATCH 2026-11-05: one request per URL, and a provider that just timed out is not waited on in full again (a
# stalled HDHub cost every click its full cap, while the full scrape sent duplicate requests alongside).
#  - _fetch_shared: a repeat ask for the same URL in this process waits on the request already running (and takes a
#    finished answer for a while after), instead of sending another.
#  - the provider's consecutive timeouts live in a Home-window property, so every plugin process sees them;
#    _timeout_after_failures turns them into the next request's timeout. Any answer clears them.
import threading, time
_BASE_TIMEOUT = 12        # seconds; what every request waited before
_SHORT_TIMEOUT = 4        # seconds, while a timeout is recent
_RECENT_SECS = 300        # how long a timeout counts as recent
_SKIP_AFTER = 3           # LOCAL PATCH 2026-11-23: this many timeouts in a row -> the provider is skipped ...
_SKIP_SECS = 600          # ... for this long after the last one, then probed once with the short wait
_SHARE_OK_SECS = 60      # a finished answer is handed to a repeat ask this long
_SHARE_FAIL_SECS = 20     # a failure only this long: pinned check -> full scrape is immediate, a new click is not
_inflight = {}            # api_url -> [Event, (data, date) or Exception or None, finished-at or None]
_inflight_lock = threading.Lock()

def _down_prop(label): return 'deadlight.http_prov.down.%s' % label

def _read_failures(label):
    """(consecutive timeouts, seconds since the last one), or (0, None) when none is recorded."""
    try:
        from modules.kodi_utils import get_property
        raw = get_property(_down_prop(label))
        if not raw: return 0, None
        n, ts = raw.split(',')
        return int(n), max(0.0, time.time() - float(ts))
    except Exception: return 0, None

def _record(label, timed_out):
    try:
        from modules.kodi_utils import set_property, clear_property
        if not timed_out: return clear_property(_down_prop(label))
        n, _age = _read_failures(label)
        set_property(_down_prop(label), '%d,%f' % (n + 1, time.time()))
    except Exception: pass

def _timeout_after_failures(fails, age, base=_BASE_TIMEOUT, short=_SHORT_TIMEOUT):
    """Seconds the next request to a provider may take, given its recent timeouts.
    LOCAL PATCH 2026-11-22: base / short per provider (provider_timeout) -- the site scrapers wait less than a Stremio add-on.

    fails: consecutive timeouts recorded (0 = none, or it answered since).
    age:   seconds since the last of them (None when fails == 0).
    Return _BASE_TIMEOUT for normal behaviour, a smaller number to wait less, or 0 to skip the request (it counts as
    failed: shown, not cached).

    Healthy HDHub answers a warm episode in under 1 s and a cold one in ~3 s; stalls have lasted minutes.
    Stremio usually answers in 1-4 s.
    """
    # A short ask still reaches the provider, so the first answer after an outage clears the memory.
    # 4 s still catches a healthy cold HDHub; a stall costs 4 s per click instead of 12. After 5 minutes without a new
    # timeout the full wait comes back, so a cold episode gets its time.
    # LOCAL PATCH 2026-11-23 (user): _SKIP_AFTER timeouts in a row -> skipped (0) for _SKIP_SECS after the last one, then ONE
    # short probe: an answer clears the record, another timeout skips it again. A down provider then costs nothing per scrape
    # instead of its short wait every time.
    if not fails or age is None: return base
    if fails >= _SKIP_AFTER: return 0 if age < _SKIP_SECS else short
    if age > _RECENT_SECS: return base
    return short

# LOCAL PATCH 2026-11-22: the same recent-timeout memory for any provider, not only the Stremio requests below -- a site
# scraper (Cinejoy: 8 of 25 requests timed out on 2026-11-22, 5 s each) asks provider_timeout before its request and reports
# the outcome with provider_answered; every DeadLight process sees the record (Home property).
def provider_check(label):
    """LOCAL PATCH 2026-11-23: (recent timeouts, seconds since the last) for `label`, or RAISES requests' Timeout('skipped: ...')
    while it is skipped (_SKIP_AFTER timeouts in a row, for _SKIP_SECS after the last). Every caller treats a raise as a failed
    provider (shown, not cached), and provider_answered ignores 'skipped:' errors, so a skip never counts as another timeout."""
    fails, age = _read_failures(label)
    if fails and age is not None and not _timeout_after_failures(fails, age, 1, 1):
        log(f"[JSON-PROV] {label}: skipped -- {fails} timeouts in a row, last {int(age)} s ago (probed again after {_SKIP_SECS} s)")
        raise requests.exceptions.Timeout('skipped: %s timed out %d times in a row' % (label, fails))
    return fails, age

def provider_timeout(label, base, short):
    """(seconds the next request may take, recent timeouts) for `label`: `base` normally, `short` within _RECENT_SECS of a
    timeout; raises while the provider is skipped (provider_check)."""
    fails, age = provider_check(label)
    return _timeout_after_failures(fails, age, base, short), fails

def run_guarded(label, fn):
    """LOCAL PATCH 2026-11-23: fn() for a provider that makes several requests of its own (a site scraper), under the same
    memory: skipped while benched (provider_check), its outcome recorded once -- rows or an empty answer clear the record, a
    raised timeout / connection error counts one (provider_answered)."""
    provider_check(label)
    try: out = fn()
    except Exception as e:
        provider_answered(label, e)
        raise
    provider_answered(label)
    return out

def provider_answered(label, error=None):
    """Record a request's outcome: an answer (error None) clears the record; a timeout -- requests' Timeout, or the
    ConnectionError ('Connection aborted.') that wraps a read timeout -- adds one. Other errors leave it as it is."""
    if error is None: return _record(label, False)
    if isinstance(error, (requests.exceptions.Timeout, requests.exceptions.ConnectionError)) and not str(error).startswith('skipped:'):
        _record(label, True)

# LOCAL PATCH 2026-11-22: the Stremio add-ons are asked through DeadLight's pooled session (kodi_utils.make_session): one
# SSL context per process, certificates VERIFIED, connections kept between requests (an episode's two numbering pairs, and
# later scrapes with the reuse invoker). Before, a bare requests.get(verify=False): a new TCP + TLS handshake per request and
# no certificate check. Verifying through a bare requests.get would also reload the whole CA bundle per connection (~0.9 s
# CPU, kodi_utils._shared_ssl_adapter), hence the session. The add-ons' hosts all verify (aiostreams / meteor / hdhub, 2026-11-22).
_SESSION = None

# LOCAL PATCH 2026-11-22 (user): a shorter wait for one add-on host, whatever slot it sits in -- the HDHub aggregator answers most
# requests in 0.7-2.3 s but hangs often (2026-11-22: 7 failures at 2-12.6 s; 15 of 70 answers came after 3 s and are given up).
# (normal, after a recent timeout) seconds, as provider_timeout takes them.
_HOST_TIMEOUTS = {'hdhub.thevolecitor.qzz.io': (3, 3)}

def _stremio_session():
    global _SESSION
    if _SESSION is None:
        from modules.kodi_utils import make_session
        _SESSION = make_session('https://')
    return _SESSION

def _fetch_shared(api_url, label):
    """(json, Date header) for api_url; raises like requests does."""
    now = time.time()
    with _inflight_lock:
        slot = _inflight.get(api_url)
        if slot and slot[2] is not None:
            keep = _SHARE_FAIL_SECS if isinstance(slot[1], Exception) else _SHARE_OK_SECS
            if now - slot[2] > keep: slot = None
        owner = slot is None
        if owner:
            slot = [threading.Event(), None, None]
            _inflight[api_url] = slot
    if not owner:
        slot[0].wait(_BASE_TIMEOUT + 5)
        if slot[1] is None: raise requests.exceptions.Timeout('the shared request is still running')
        log(f"[JSON-PROV] {label}: took the answer of the request already made")
        if isinstance(slot[1], Exception): raise slot[1]
        return slot[1]
    try:
        base, short = _HOST_TIMEOUTS.get((urlparse(api_url).hostname or '').lower(), (_BASE_TIMEOUT, _SHORT_TIMEOUT))
        timeout, fails = provider_timeout(label, base, short)
        if fails: log(f"[JSON-PROV] {label}: {fails} recent timeout(s), waiting {timeout} s")
        r = _stremio_session().get(api_url, headers=get_headers(), timeout=timeout)
        r.raise_for_status()
        slot[1] = (r.json(), r.headers.get('Date'))
        provider_answered(label)
        return slot[1]
    except Exception as e:
        slot[1] = e
        provider_answered(label, e)   # 'Connection aborted.' wrapping a read timeout is a ConnectionError, not a Timeout
        raise
    finally:
        slot[2] = time.time()
        slot[0].set()

def _scrape_json_provider(base_url, pattern, label, imdb_id, content_type, season, episode, title_query=None, year_query=None):
    """
    Helper pentru providerii JSON (StreamVix, Vidzee, Webstreamr, MeowTV).
    FIX: Extrage calitatea din name/title/description și folosește titlul fallback.
    """
    local_streams = []

    try:
        base = urlparse(base_url)
        resource = 'movie/' + imdb_id if content_type == 'movie' else f'series/{imdb_id}:{season}:{episode}'
        prefix = '/stream/' if pattern == 'stream' else '/'
        api_url = base._replace(path=base.path + prefix + resource + '.json').geturl()

        # LOCAL PATCH 2026-11-05: the request is shared and its timeout follows the provider's recent timeouts (_fetch_shared)
        data, server_date = _fetch_shared(api_url, label)

        if data is not None:
            if 'streams' in data:
                # LOCAL PATCH 2026-06-15: no Referer/Origin pointing at the aggregator: its stream URLs are pre-signed CDN URLs
                # (?token=...), and an aggregator-domain Referer makes the CDN 404. Kodi makes a plain GET, as for AIOStreams.

                for s in data['streams']:
                    url = s.get('url', '')
                    if not url: continue

                    # =====================================================
                    # FIX 1: OCOLIM CLOUDFLARE EXTRĂGÂND URL-UL DIRECT (M3U8)
                    # =====================================================
                    import urllib.parse
                    if 'meowserver' in url and 'url=' in url:
                        try:
                            parsed_qs = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
                            if 'url' in parsed_qs:
                                url = parsed_qs['url'][0]
                        except:
                            pass
                    
                    raw_name = s.get('name', '')
                    raw_title = s.get('title', '')
                    description = s.get('description', '')

                    # =====================================================
                    # FIX 2: IGNORĂM CALITATEA "AUTO" PENTRU A EVITA DEDUPLICAREA GRESITĂ A 1080P
                    # =====================================================
                    # LOCAL PATCH 2026-10-15: the WORD 'Auto' (the HLS quality), not the substring -- the description
                    # carries the release filename, so 'The Autopsy of Jane Doe' / 'Automata' / 'Autograph' lost every row.
                    if _AUTO_QUALITY.search(raw_name) or _AUTO_QUALITY.search(description):
                        continue

                    # =====================================================
                    # EXTRAGERE FILENAME ORIGINAL (Din description pt Volecitor/etc)
                    # =====================================================
                    if description:
                        first_line = description.split('\n')[0].strip()
                        # Verificăm strict dacă pe prima linie există o extensie video
                        if re.search(r'(\.mkv|\.mp4|\.avi|\.ts|\.webm)', first_line, re.IGNORECASE):
                            # Eliminăm doar parantezele pătrate de la început (ex: [10Gbps] [💾 9.58 GB])
                            clean_filename = re.sub(r'^(\[[^\]]+\]\s*)+', '', first_line).strip()
                            if clean_filename:
                                raw_title = clean_filename
                    
                    # APLICARE TITLU FALLBACK (Dacă nu s-a extras niciun fișier video și raw_title e gol)
                    if not raw_title and title_query:
                        if label == 'MeowTV':
                            base_name = f"{title_query} ({year_query})" if year_query else title_query
                            if content_type == 'tv' and season and episode:
                                raw_title = f"{base_name} S{int(season):02d}E{int(episode):02d}"
                            else:
                                raw_title = f"{base_name}"
                        else:
                            if content_type == 'tv' and season and episode:
                                raw_title = f"{title_query} S{int(season):02d}E{int(episode):02d}"
                            else:
                                raw_title = title_query

                    try: clean_name = raw_name.encode('ascii', 'ignore').decode('ascii')
                    except: clean_name = raw_name

                    # Eliminare nume provider din afișare
                    banned_names = ['WebStreamr', 'StreamVix', 'Vidzee', 'Sooti', 'Sootio', 'MeowTV', 'HDHub']
                    for bn in banned_names:
                        clean_name = clean_name.replace(bn, '').strip()
                    
                    clean_name = clean_name.replace('|', '').replace('[', '').replace(']', '').strip()
                    clean_name = clean_name.replace('\n', ' ').strip()
                    while '  ' in clean_name: clean_name = clean_name.replace('  ', ' ')

                    final_name = f"{label} | {clean_name}" if clean_name else label
                    
                    # Extragere Calitate
                    quality = None
                    if s.get('quality'): quality = s.get('quality')
                    if not quality and description: quality = _extract_quality_from_string(description)
                    if not quality or quality.upper() == 'SD': quality = _extract_quality_from_string(raw_name)
                    if not quality: quality = _extract_quality_from_string(raw_title)
                    if not quality: quality = _extract_quality_from_string(s.get('behaviorHints', {}).get('filename', ''))
                    if not quality: quality = 'SD'
                    
                    # Înglobăm description în info pentru ca regex-urile din player.py să extragă corect mărimea (ex: 💾 9.58 GB)
                    info_text = str(s.get('behaviorHints', {}).get('filename', '')) + " " + description
                    
                    # LOCAL PATCH 2026-06-15: bare URL (no |Header= suffix) -- any pipe-headers make the pre-signed CDN link 404.
                    stream_obj = {
                        'name': final_name,
                        'url': url,
                        'quality': quality,
                        'title': raw_title,
                        'info': info_text.strip(),
                        'provider_id': label.lower(),
                        # LOCAL PATCH 2026-08-29: the aggregator's Date header, so http_streams' pre-signed expiry gate judges
                        # X-Amz-Expires against SERVER time (a CoreELEC box with no RTC can boot with a badly wrong clock).
                        'server_date': server_date,
                        # LOCAL PATCH 2026-11-02: the exact byte size, for http_streams._inherit_prerelease
                        'video_size': s.get('behaviorHints', {}).get('videoSize') or 0,
                    }
                    local_streams.append(stream_obj)
                
                log(f"[SCRAPER] ✓ {label}: {len(local_streams)} surse")
                
    except Exception as e:
        log(f"[JSON-PROV] Error {label}: {e}")
        # LOCAL PATCH 2026-10-15: a request that failed with nothing collected is a FAILURE, not an empty answer.
        # Returning [] let http_streams cache "no streams" for an hour after one 502 / 429 / timeout.
        if not local_streams: raise

    return local_streams
