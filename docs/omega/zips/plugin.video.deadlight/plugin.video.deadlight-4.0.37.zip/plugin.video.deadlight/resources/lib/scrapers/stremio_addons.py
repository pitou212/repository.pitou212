"""Configured Stremio stream add-ons and their display names."""
from hashlib import sha256
from urllib.parse import urlsplit

from caches.main_cache import main_cache
from caches.settings_cache import get_setting

SLOTS = (1, 2, 3)


def manifest_url(slot):
	url = get_setting('deadlight.http_streams.stremio%d_url' % slot, '').strip()
	if url.startswith('stremio://'): url = 'https://' + url[len('stremio://'):]
	try: parsed = urlsplit(url)
	except ValueError: return ''
	if parsed.scheme not in ('http', 'https') or not parsed.hostname: return ''
	path = parsed.path.rstrip('/')
	if not path.endswith('/manifest.json'): path += '/manifest.json'
	return parsed._replace(path=path, fragment='').geturl()


def enabled_slots():
	return [(slot, url) for slot in SLOTS if get_setting('deadlight.http_streams.stremio%d' % slot) == 'true'
			and (url := manifest_url(slot))]


def _key(url):
	return 'stremio_manifest_' + sha256(url.encode('utf-8')).hexdigest()


def addon_name(slot, url=None):
	url = manifest_url(slot) if url is None else url
	return (main_cache.get(_key(url)) if url else '') or 'Stremio Add-on %d' % slot


def refresh_name(slot, force=False):
	from modules.kodi_utils import set_property
	url = manifest_url(slot)
	property_name = 'deadlight.stremio_addon_%d_name' % slot
	set_property(property_name, addon_name(slot, url))
	if not url: return
	key = _key(url)
	if not force and main_cache.get(key) is not None: return
	from requests import get
	try:
		with get(url, timeout=(2, 3)) as response:
			response.raise_for_status()
			name = response.json().get('name')
			name = ' '.join(name.split()).replace('[', '(').replace(']', ')')[:100] if isinstance(name, str) else ''
	except (ValueError, AttributeError, OSError):
		name = ''
	if name or main_cache.get(key) is None:
		main_cache.set(key, name, expiration=720 if name else 0.1)
	if manifest_url(slot) == url: set_property(property_name, addon_name(slot, url))
