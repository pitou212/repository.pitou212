# -*- coding: utf-8 -*-
import sys
from datetime import datetime
from apis.alldebrid_api import AllDebrid
from modules import kodi_utils
from indexers.cloud_listing import cloud_listitem, end_cloud_directory
from modules.utils import clean_file_name, normalize

def ad_cloud(folder_id=None):
	def _builder():
		for count, item in enumerate(cloud_dict, 1):
			try:
				cm = []
				folder_name, folder_id = item['filename'], item['id']
				clean_folder_name = clean_file_name(normalize(folder_name)).upper()
				display = '%02d | [B]FOLDER[/B] | [I]%s [/I]' % (count, clean_folder_name)
				url_params = {'mode': 'alldebrid.browse_ad_cloud', 'id': folder_id}
				delete_params = {'mode': 'alldebrid.delete', 'id': folder_id}
				cm.append(('[B]Delete Folder[/B]','RunPlugin(%s)' % kodi_utils.build_url(delete_params)))
				url = kodi_utils.build_url(url_params)
				listitem = cloud_listitem(display, cm, icon, fanart)
				yield (url, listitem, True)
			except: pass
	try:
		cloud = AllDebrid.user_cloud()['magnets']
		cloud_dict = [i for i in cloud if i['statusCode'] == 4]
	except: cloud_dict = []
	icon, fanart = kodi_utils.get_icon('alldebrid'), kodi_utils.get_addon_fanart()
	handle = int(sys.argv[1])
	end_cloud_directory(handle, _builder(), cache_to_disc=True)

def _file_directory(files, keys, play_params, dl_action, label=''):
	"""LOCAL PATCH 2026-11-17: the file rows of Downloads, Saved Links and a cloud folder (one builder, was three).
	keys = the item's (name, size, link) keys; play_params(link) = the row's play url params."""
	name_key, size_key, link_key = keys
	icon, fanart = kodi_utils.get_icon('alldebrid'), kodi_utils.get_addon_fanart()
	def _builder():
		for count, item in enumerate(files, 1):
			try:
				url_link = item[link_key]
				name = clean_file_name(item[name_key]).upper()
				display = '%02d | %s%.2f GB | [I]%s [/I]' % (count, label, float(int(item[size_key]))/1073741824, name)
				down_file_params = {'mode': 'downloader.runner', 'name': name, 'url': url_link, 'action': dl_action, 'image': icon}
				cm = [('[B]Download File[/B]','RunPlugin(%s)' % kodi_utils.build_url(down_file_params))]
				yield (kodi_utils.build_url(play_params(url_link)), cloud_listitem(display, cm, icon, fanart), False)
			except: pass
	end_cloud_directory(int(sys.argv[1]), _builder())

def _resolve_params(url_link):
	return {'mode': 'alldebrid.resolve_ad', 'url': url_link, 'play': 'true'}

def ad_downloads():
	try:
		downloads = AllDebrid.history()
		downloads = downloads.get('links', []) or []
		downloads = [i for i in downloads if not i.get('error')]
	except: downloads = []
	_file_directory(downloads, ('filename', 'size', 'link_dl'), lambda url_link: {'mode': 'playback.video', 'url': url_link, 'obj': 'video'},
					'cloud.alldebrid_direct')

def ad_saved_links():
	try:
		saved_links = AllDebrid.user_links()
		saved_links = saved_links.get('links', []) or []
	except: saved_links = []
	_file_directory(saved_links, ('filename', 'size', 'link'), _resolve_params, 'cloud.alldebrid')

def browse_ad_cloud(folder_id):
	try: links = AllDebrid.parse_magnet(transfer_id=folder_id)[1]
	except: links = []
	_file_directory(links, ('n', 's', 'l'), _resolve_params, 'cloud.alldebrid', label='[B]FILE[/B] | ')

def resolve_ad(params):
	url = params['url']
	resolved_link = AllDebrid.unrestrict_link(url)
	if params.get('play', 'false') != 'true' : return resolved_link
	from modules.player import DeadLightPlayer
	DeadLightPlayer().run(resolved_link, 'video')

def ad_delete(file_id):
	if not kodi_utils.confirm_dialog(): return
	result = AllDebrid.delete_transfer(file_id)
	if not result: return kodi_utils.notification('Error')
	AllDebrid.clear_cache()
	kodi_utils.execute_builtin('Container.Refresh')

def ad_account_info():
	try:
		kodi_utils.show_busy_dialog()
		account_info = AllDebrid.account_info()['user']
		username = account_info['username']
		email = account_info['email']
		status = 'Premium' if account_info['isPremium'] else 'Not Active'
		expires = datetime.fromtimestamp(account_info['premiumUntil'])
		days_remaining = (expires - datetime.today()).days
		body = []
		append = body.append
		append('[B]Username:[/B] %s' % username)
		append('[B]Email:[/B] %s' % email)
		append('[B]Status:[/B] %s' % status)
		append('[B]Expires:[/B] %s' % expires)
		append('[B]Days Remaining:[/B] %s' % days_remaining)
		kodi_utils.hide_busy_dialog()
		return kodi_utils.show_text('ALL DEBRID', '\n\n'.join(body), font_size='large')
	except: kodi_utils.hide_busy_dialog()
