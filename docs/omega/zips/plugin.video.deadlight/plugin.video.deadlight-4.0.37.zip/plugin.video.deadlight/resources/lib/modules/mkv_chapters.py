# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-11-18: the chapters of a Matroska file, read from the stream itself.

Kodi names only the chapter that is PLAYING (Player.ChapterName), so player._chapter_segments could not tell a cold
open called 'Intro' from the opening when an 'OP' chapter follows it: tmdb 118821 S1E12 (Intro 0 s / OP 38 s /
Part A / Part B / ED / Extra) had its 38 s cold open auto-skipped and the 90 s OP played. Reading the whole chapter
table up front answers that.

MKV (and WebM) only: one ranged read of the file's start, plus one more when the chapters sit past it (the SeekHead
says where -- mkvmerge can put megabytes of fonts first). Anything else, or any failure, returns None and the player
keeps its per-chapter reading."""
import os
from modules import kodi_utils as ku

_HEAD_BYTES = 256 * 1024
_CHAPTERS_MAX = 1024 * 1024   # a chapter table is a few KB; anything this big is not one
_NOT_MATROSKA = ('.mp4', '.m4v', '.mov', '.avi', '.ts', '.m2ts', '.mts', '.wmv', '.mpg', '.mpeg', '.iso', '.flv', '.m3u8')

_ID_SEGMENT, _ID_SEEKHEAD, _ID_SEEK, _ID_SEEKID, _ID_SEEKPOS = 0x18538067, 0x114D9B74, 0x4DBB, 0x53AB, 0x53AC
_ID_CHAPTERS, _ID_CLUSTER, _ID_EDITION, _ID_ATOM = 0x1043A770, 0x1F43B675, 0x45B9, 0xB6
_ID_TIMESTART, _ID_DISPLAY, _ID_STRING = 0x91, 0x80, 0x85
_EBML_MAGIC, _CHAPTERS_ID_BYTES = b'\x1a\x45\xdf\xa3', b'\x10\x43\xa7\x70'


def chapter_names(url, filename=None, timeout=8):
	"""[(start seconds, name)] in time order, [] for a Matroska file without chapters, None when not known."""
	link = (url or '').partition('|')[0]
	if not link or link.startswith('plugin://'): return None
	for name in (filename, link.split('?')[0]):
		if name and os.path.splitext(name)[1].lower() in _NOT_MATROSKA: return None
	if link.lower().startswith(('http://', 'https://')):
		session = ku.make_session()
		try: return _read_chapters(_http_reader(session, url, timeout))
		finally:
			try: session.close()
			except Exception: pass
	return _read_chapters(_file_reader(link))


def _http_reader(session, url, timeout):
	link, headers = ku.stream_request_parts(url)
	def read(offset, length):
		h = dict(headers, Range='bytes=%d-%d' % (offset, offset + length - 1))
		with session.get(link, headers=h, stream=True, timeout=timeout) as r:
			# a server that ignores Range answers 200 with the whole file: fine for the start, never for a later offset
			if r.status_code != 206 and not (r.status_code == 200 and offset == 0): return b''
			data = bytearray()
			for chunk in r.iter_content(65536):
				data += chunk
				if len(data) >= length: break
			return bytes(data[:length])
	return read


def _file_reader(path):
	import xbmcvfs
	def read(offset, length):
		f = xbmcvfs.File(path)
		try:
			if offset: f.seek(offset, 0)
			return bytes(f.readBytes(length))
		finally: f.close()
	return read


def _read_chapters(read):
	head = read(0, _HEAD_BYTES)
	if head[:4] != _EBML_MAGIC: return None
	segment = next(((s, e) for eid, s, e in _elements(head, 0, len(head)) if eid == _ID_SEGMENT), None)
	if not segment: return None
	seg_start, where = segment[0], None
	for eid, s, e in _elements(head, seg_start, min(segment[1], len(head))):
		if eid == _ID_CHAPTERS:
			if e <= len(head): return _parse_chapters(head, s, e)
			if e - s > _CHAPTERS_MAX: return None
			return _parse_chapters(read(s, e - s), 0, e - s)
		if eid == _ID_SEEKHEAD and e <= len(head):
			for sid, ss, se in _elements(head, s, e):
				if sid != _ID_SEEK: continue
				fields = dict((fid, head[fs:fe]) for fid, fs, fe in _elements(head, ss, se))
				if fields.get(_ID_SEEKID) == _CHAPTERS_ID_BYTES and _ID_SEEKPOS in fields:
					where = seg_start + int.from_bytes(fields[_ID_SEEKPOS], 'big')
		if eid == _ID_CLUSTER: break   # the video itself: no chapters before it, only the SeekHead's pointer can help
	if where is None: return []
	buf = read(where, 64 * 1024)
	try:
		eid, j, _ = _vint(buf, 0, True)
		size, k, unknown = _vint(buf, j, False)
	except (IndexError, ValueError): return None
	if eid != _ID_CHAPTERS or unknown or size > _CHAPTERS_MAX: return None
	if k + size > len(buf): buf = read(where, k + size)
	return _parse_chapters(buf, k, min(k + size, len(buf)))


def _parse_chapters(b, start, end):
	"""The first edition that has chapters (the default one in practice); a chapter's first display string is its name."""
	for eid, s, e in _elements(b, start, end):
		if eid != _ID_EDITION: continue
		out = []
		for aid, a_s, a_e in _elements(b, s, e):
			if aid != _ID_ATOM: continue
			ts, name = None, ''
			for cid, cs, ce in _elements(b, a_s, a_e):
				if cid == _ID_TIMESTART: ts = int.from_bytes(b[cs:ce], 'big') / 1e9
				elif cid == _ID_DISPLAY and not name:
					name = next((b[ds:de].decode('utf-8', 'replace').strip() for did, ds, de in _elements(b, cs, ce) if did == _ID_STRING), '')
			if ts is not None: out.append((ts, name))
		if out: return sorted(out)
	return []


def _elements(b, start, end):
	"""(id, data start, data end) of each element in b[start:end]. The first one running past the buffer is still
	yielded (its end lies beyond len(b)) and ends the walk -- as does an element of unknown size, which runs to `end`."""
	i = start
	while i < end:
		try:
			eid, j, _ = _vint(b, i, True)
			size, k, unknown = _vint(b, j, False)
		except (IndexError, ValueError): return
		stop = end if unknown else k + size
		yield eid, k, stop
		if unknown or stop > len(b): return
		i = stop


def _vint(b, i, marker):
	"""An EBML variable-length number at b[i] -> (value, next index, unknown). Element IDs keep their length marker
	(marker=True); sizes drop it, and an all-ones size means 'unknown' (a stream still being written)."""
	first, n = b[i], 1
	while n <= 8 and not first & (0x80 >> (n - 1)): n += 1
	if n > 8: raise ValueError('bad EBML number')
	v = first if marker else first & (0xFF >> n)
	for k in range(1, n): v = (v << 8) | b[i + k]
	return v, i + n, (not marker and v == (1 << (7 * n)) - 1)
