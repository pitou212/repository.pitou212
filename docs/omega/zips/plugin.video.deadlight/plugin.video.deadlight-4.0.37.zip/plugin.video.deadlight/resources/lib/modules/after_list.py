# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-11-15: a list's after-list work, done by the SERVICE instead of the plugin call.

After a list is on screen, deadlight.py used to run the scrape prewarm, stale refreshes, rating / art backfills, filler
flags and the next-page warm itself -- 1.6-3.2 s with the interpreter still busy. A click in that window (Back, the next
page, the skin's season preview) found the reused interpreter busy, so Kodi started another one and shut the old one down
when it finished; fast browsing made 5 interpreters in 40 s, and those shutdowns crashed Kodi 21's Python 3.8
(python3.8.dll+0xdfec1, three times on 2026-11-15; seven more with reuse off since October). The service's interpreter
lives as long as Kodi, so work done there starts and ends nothing.

Plugin side: deadlight.py calls hand_off() once the list is delivered. It takes this call's queues as JSON data (_TAKERS:
one small function per queue), writes them as ONE job file and wakes the service (NotifyAll). Which queues a call hands over
depends on the call (_PROFILES):
  in-addon -- everything: prewarm, stale refreshes, backfills, filler flags, the next page;
  widget   -- only the backfill chains of titles shown with art pending (AniList rows and search rows always start with TMDb
              art, and a cached title still missing art queues its fill on every read). Widgets used to drop all
              backfills: doing them in the widget call meant bursts of work in many interpreters at once. In the service
              that reason is gone. Everything else a widget call queues keeps its old path (the stale ids are recorded for
              WidgetPageWarmer, the rest is skipped).
Anything that cannot be written as data stays in the plugin call and runs there as before (in-addon only).

Service side (service.py AfterListWorker -> Worker): one job at a time, oldest first, each after invocation.begin() and with
the call's widget-or-not answer (kodi_utils._EXTERNAL_CALL) for the job's length, so module state never mixes between
jobs. _STEPS runs the job's parts in order. A job older than _MAX_AGE is dropped; its next-page warm and its scrape prewarm are
skipped when a newer job is waiting (the user moved on), the page warm also when older than _PAGE_MAX_AGE or while a video plays."""
import os, json, time

NOTIFY = 'after_list'                 # NotifyAll(plugin.video.deadlight, after_list) -> service onNotification 'Other.after_list'
_MAX_AGE, _PAGE_MAX_AGE = 3600, 600
_DIR = []

def job_dir():
	if not _DIR:
		import xbmcvfs
		_DIR.append(xbmcvfs.translatePath('special://profile/addon_data/plugin.video.deadlight/after_list'))
	return _DIR[0]

# ---------------------------------------------------------------- plugin side
# Each taker empties one module's queue into the job and returns what could not be written as data (to run here).
def _take_prewarm(modules, job, argv, widget):
	sp = modules.get('modules.scrape_prewarm')
	pending = sp.take() if sp is not None else None
	if not pending: return []
	meta, episodes, anime, tvdb_pairs = pending
	data = {'meta': meta, 'episodes': [list(e) for e in episodes or []], 'anime': bool(anime), 'tvdb_pairs': [list(p) for p in tvdb_pairs or []]}
	try:
		json.dumps(data)
		job['prewarm'] = data
	except Exception: sp._PENDING = pending   # cannot travel: deadlight.py runs it here, as before
	return []

def _take_stale(modules, job, argv, widget):
	md = modules.get('modules.metadata')
	stale = md.take_stale() if md is not None else None
	if stale: job['stale'] = stale
	return []

def _take_backfills(modules, job, argv, widget):
	md = modules.get('modules.metadata')
	if md is None: return []
	pending = md.take_deferred()
	if widget: pending = [p for p in pending if isinstance(p[0], dict) and p[0].get('art_pending')]   # see _PROFILES
	try: data, leftovers = md.backfills_to_data(pending)
	except Exception: data, leftovers = None, pending   # never lose the queue: the caller runs it here
	if data: job['backfills'] = data
	return leftovers

def _take_filler(modules, job, argv, widget):
	af = modules.get('modules.anime_filler')
	ids = af.take() if af is not None else None
	if ids: job['filler'] = ids
	return []

def _take_page(modules, job, argv, widget):
	pp = modules.get('modules.page_prefetch')
	if pp is None or not pp.take(): return []
	from urllib.parse import parse_qsl
	params = dict(parse_qsl(argv[2].lstrip('?'))) if len(argv) > 2 else {}
	try: page = int(params.get('new_page') or params.get('page') or 1)
	except ValueError: return []
	params['new_page'] = str(page + 1)
	job['page'] = params
	return []

_PROFILES = {False: (_take_prewarm, _take_stale, _take_backfills, _take_filler, _take_page),   # in-addon
			 True: (_take_backfills,)}                                                         # widget
_PARTS = ('prewarm', 'stale', 'backfills', 'filler', 'page')

def collect(argv, call_name='', widget=False):
	"""(job or None, leftovers): this call's after-list queues for its profile, taken (each queue is emptied). leftovers are
	the backfill chains that cannot be written as data."""
	import sys
	job, leftovers = {'v': 1, 'created': time.time(), 'call': call_name, 'widget': bool(widget)}, []
	for take in _PROFILES[bool(widget)]: leftovers += take(sys.modules, job, argv, widget)
	return (job if any(k in job for k in _PARTS) else None), leftovers

def submit(job):
	"""Write the job (temp file, then rename: the service never reads half a job) and wake the service."""
	import uuid, xbmc
	folder = job_dir()
	os.makedirs(folder, exist_ok=True)
	path = os.path.join(folder, '%.6f_%s.json' % (job['created'], uuid.uuid4().hex[:6]))
	with open(path + '.tmp', 'w', encoding='utf-8') as f: json.dump(job, f, separators=(',', ':'))
	os.replace(path + '.tmp', path)
	xbmc.executebuiltin('NotifyAll(plugin.video.deadlight,%s)' % NOTIFY)

def hand_off(argv, call_name='', widget=False):
	"""deadlight.py, once the list is delivered: give this call's after-list work to the service. In-addon, leftovers go
	back to metadata's queue (flush_rating_backfills then runs them here) and a job that cannot be written runs here.
	A widget call drops both, as it always dropped its backfills. Never raises."""
	try:
		job, leftovers = collect(argv, call_name, widget)
		if leftovers and not widget:
			import sys
			md = sys.modules.get('modules.metadata')
			if md is not None: md._DEFERRED = leftovers
		if job is None: return
		try: submit(job)
		except Exception:
			if not widget: run_job(job, in_service=False)
	except Exception: pass

# ---------------------------------------------------------------- service side
# Each step runs one part of a job and returns its log words (or None when the job has no such part).
def _run_stale(job, skip_page, kodi_utils):
	from modules import metadata
	metadata.refresh_stale_metas(job['stale'])
	return 'stale %d' % len(job['stale'])

def _run_backfills(job, skip_page, kodi_utils):
	from modules import metadata
	pending = metadata.backfills_from_data(job['backfills'])
	metadata.run_backfills(pending)
	return 'backfills %d' % len(pending)

def _run_filler(job, skip_page, kodi_utils):
	from modules import anime_filler
	anime_filler.fetch_flags(job['filler'])
	return 'filler %d' % len(job['filler'])

def _run_page(job, skip_page, kodi_utils):
	page = job['page']
	why = 'newer list' if skip_page else 'old' if time.time() - job.get('created', 0) > _PAGE_MAX_AGE else \
		'playing' if _playing(kodi_utils) else ''
	if why: return 'page %s skipped (%s)' % (page.get('new_page'), why)
	from modules import page_prefetch
	page_prefetch.warm_next_page(page)
	return 'page %s' % page.get('new_page')

_STEPS = (('stale', _run_stale), ('backfills', _run_backfills), ('filler', _run_filler), ('page', _run_page))

def _start_prewarm(job):
	"""First, on its own thread beside the rest: a play clicked 2 s after the list must not wait behind the backfills.
	LOCAL PATCH 2026-11-15: and not joined -- a provider timing out (AnimeTosho's feed, 22.6 s on 2026-11-15) held the worker,
	so the next list's page-2 warm waited behind it. The prewarm finishes on its own; the worker goes on."""
	import threading
	from modules import scrape_prewarm
	p = job['prewarm']
	pending = (p['meta'], [tuple(e) for e in p['episodes']], p['anime'], [tuple(t) for t in p['tvdb_pairs']])
	thread = threading.Thread(target=scrape_prewarm.run_pending, args=(pending,), name='after_list_prewarm')
	thread.start()
	return thread, 'prewarm %d ep' % len(pending[1])

def run_job(job, skip_page=False, in_service=True):
	"""Run one job. in_service=False: the plugin call's own fallback when the job could not be written."""
	from modules import kodi_utils
	if in_service:
		from modules import invocation
		invocation.begin()
		kodi_utils._EXTERNAL_CALL = bool(job.get('widget'))   # the calling list's answer, for the code below
	start, done = time.time(), []
	try:
		if job.get('prewarm'):
			# LOCAL PATCH 2026-11-15: not for a list a newer one has replaced (skip_page: the user moved on) -- scrolling One Piece's
			# seasons queued 8 episode-list jobs in 15 s, and each prewarmed its episodes at the stream providers for nothing
			if skip_page: done.append('prewarm skipped (newer list)')
			else:
				_thread, words = _start_prewarm(job)
				done.append(words + ' (started)')
		for part, step in _STEPS:
			if job.get(part): done.append(step(job, skip_page, kodi_utils))
	finally:
		if in_service: kodi_utils._EXTERNAL_CALL = None
	kodi_utils.logger('after list', '%s%s: %s in %.2f s (queued %.1f s before)' % (job.get('call') or '?', ' (widget)' if job.get('widget') else '',
		', '.join(done) or 'nothing', time.time() - start, start - job.get('created', start)))

def _pending_files():
	try: return sorted(f for f in os.listdir(job_dir()) if f.endswith('.json'))
	except OSError: return []

def _playing(kodi_utils):
	try: return bool(kodi_utils.kodi_player().isPlayingVideo())
	except Exception: return False

class Worker:
	"""service.py: one thread. Woken by the plugin's NotifyAll (and every 5 s, in case one was missed)."""
	def __init__(self):
		import threading
		self._wake = threading.Event()

	def wake(self):
		self._wake.set()

	def run(self):
		from modules import kodi_utils
		monitor = kodi_utils.kodi_monitor()
		while not monitor.abortRequested():
			self._wake.wait(5)
			self._wake.clear()
			while not monitor.abortRequested():
				files = _pending_files()
				if not files: break
				path = os.path.join(job_dir(), files[0])
				try:
					with open(path, encoding='utf-8') as f: job = json.load(f)
				except Exception: job = None
				try: os.remove(path)   # before running: a job that kills the run is not run again at the next start
				except OSError: pass
				if not isinstance(job, dict) or time.time() - job.get('created', 0) > _MAX_AGE: continue
				try: run_job(job, skip_page=len(files) > 1)
				except Exception as e: kodi_utils.logger('after list', 'job failed: %r' % e)
