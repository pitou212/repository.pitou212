# -*- coding: utf-8 -*-
import re
from json import loads as jsloads
from caches.settings_cache import get_setting
from modules import source_utils
from modules.utils import normalize, safe_err, url_host
from modules.settings import filter_by_name
from modules.kodi_utils import make_session

# LOCAL PATCH 2026-06-23 (perf): pooled HTTP session for the manifest fetch, mounted to 'https://' for any manifest host.
# 2026-08-29: no URL validation here. The manifest serves cached debrid links minted on demand, so a probe finds nothing,
# and source_utils.drop_expired_presigns catches expired pre-signed CDN URLs without a request.
_session = make_session('https://')

# LOCAL PATCH 2026-10-01: the description's tag words (_description_tags). Bounded so HDR10 is not HDR10+, DD not
# DD+, DTS not DTS-HD / DTS:X; small caps, emoji and the formatter's symbols are blanked first (_NON_ASCII).
_NON_ASCII = re.compile(r'[^\x20-\x7e\n]+')
def _word(pattern): return re.compile(r'(?i)(?<![a-z0-9])(?:%s)(?![a-z0-9+:\-])' % pattern)
_DESC_TAG = {'dv': _word(r'dv|dovi|dolby[ .]?vision'), 'hdr10plus': _word(r'hdr10\+|hdr10plus|hdr10p'), 'hdr': _word(r'hdr|hdr10'),
			 'hevc': _word(r'hevc|h\.?265|x265'), 'av1': _word(r'av1'), 'avc': _word(r'avc|h\.?264|x264'),
			 'atmos': _word(r'atmos'), 'truehd': _word(r'truehd|true[ .]hd'), 'dtsx': _word(r'dts[:\-]?x'),
			 'dtshdma': _word(r'dts[\- ]?hd[ \-]?ma'), 'dtshd': _word(r'dts[\- ]?hd'), 'dts': _word(r'dts'),
			 'ddp': _word(r'dd\+|ddp|e-?ac-?3'), 'dd': _word(r'dd|ac-?3'), 'aac': _word(r'aac'), 'flac': _word(r'flac'), 'opus': _word(r'opus')}
# description key -> get_info's tag, in get_info's audio order
_DESC_AUDIO = {'atmos': 'ATMOS', 'truehd': 'TRUEHD', 'ddp': 'DD+', 'dd': 'DD', 'aac': 'AAC', 'flac': 'FLAC', 'opus': 'OPUS',
			   'dtsx': 'DTS-X', 'dtshdma': 'DTS-HD MA', 'dtshd': 'DTS-HD', 'dts': 'DTS'}
_DESC_CHANNELS = tuple((re.compile(r'(?<![0-9.])%s(?![0-9])' % re.escape(layout)), tag)
					   for layout, tag in (('7.1', '8CH'), ('6.1', '7CH'), ('5.1', '6CH'), ('2.0', '2CH')))


class source:
	def __init__(self):
		self.scrape_provider = 'aiostreams'
		self.sources = []
		self.timeout = 10

	def results(self, info):
		# LOCAL PATCH: reuse DeadLight's ExternalCache (the store the other scrapers use) so repeat scrapes skip the manifest
		# fetch. TTL from source_utils.get_cache_expiry via info['expiry_times'].
		media_type = info.get('media_type')
		tmdb_id = info.get('tmdb_id')
		title = info.get('title') or ''
		year = info.get('year', '')
		season_key = info.get('season') if media_type == 'episode' else ''
		episode_key = info.get('episode') if media_type == 'episode' else ''
		# Cache lookup
		if tmdb_id:
			try:
				from caches.external_cache import external_cache
				cached = external_cache.get('aiostreams', media_type, tmdb_id, title, year, season_key, episode_key)
				if cached is not None:
					self.sources = cached
					return self._return()
			except Exception:
				pass
		scrape_ran = False
		try:
			base_link = self._base_link()
			if not base_link:
				return self._return()
			# LOCAL PATCH 2026-08-26 (Red Light 2.3.3 port): fall back to a tmdb: id when the title has no IMDb id (Stremio-protocol
			# addons accept `tmdb:12345[:S:E]`) -- many anime entries have no IMDb id. IMDb stays preferred when present.
			imdb = info.get('imdb_id') or ''
			stream_id = imdb if imdb else ('tmdb:%s' % tmdb_id if tmdb_id else '')
			if not stream_id:
				return self._return()
			self.media_type = media_type
			self.title = title
			self.year = year
			# LOCAL PATCH 2026-08-29: coerce to int. check_title -> seas_ep_filter does arithmetic on them, and check_title swallows
			# the TypeError as False, so with strings every episode source was silently rejected.
			try: self.season, self.episode = int(info.get('season')), int(info.get('episode'))
			except (TypeError, ValueError): self.season, self.episode = info.get('season'), info.get('episode')
			self.aliases = source_utils.get_aliases_titles(info.get('aliases', []))
			self.air_date = info.get('premiered')   # LOCAL PATCH 2026-10-24: date-named talk-show releases (check_title)
			self.filter_title = filter_by_name('aiostreams')
			self.pairs = [(self.season, self.episode)]
			if self.media_type == 'episode':
				season, episode = int(self.season), int(self.episode)
				# LOCAL PATCH 2026-11-14 (Red Light 3.0.6 #295, DeadLight's way): an anime cour TMDb files in one long season is
				# asked in Cinemeta's numbering, as Direct Streams and the external Stremio providers do (Tokyo Revengers TMDb
				# S1E25 = tt13196080:2:1; 1:25 finds nothing). IMDb ids only -- a tmdb: id is TMDb's numbering. The name
				# filter below accepts either pair.
				if imdb and tmdb_id:
					try:
						from modules.episode_card import stremio_pair
						mapped, how = stremio_pair(tmdb_id, season, episode, imdb)
						if mapped and tuple(int(x) for x in mapped) != (season, episode):
							season, episode = int(mapped[0]), int(mapped[1])
							self.pairs.append((season, episode))
							from modules.kodi_utils import logger
							logger('aiostreams numbering', 'TMDb S%sE%s -> %s:%d:%d (%s)' % (self.season, self.episode, imdb, season, episode, how))
					except Exception: pass
				url = '%s/stream/series/%s:%s:%s.json' % (base_link, stream_id, season, episode)
			else:
				url = '%s/stream/movie/%s.json' % (base_link, stream_id)
			# LOCAL PATCH 2026-11-23 (user): the HTTP providers' timeout memory (_http_providers_core): the short wait after a recent
			# timeout, skipped for 10 min after 3 in a row (then probed once); any answer from the server clears it
			from scrapers._http_providers_core import provider_timeout, provider_answered
			try:
				timeout, _fails = provider_timeout('AIOStreams', self.timeout, 4)
				response = _session.get(url, timeout=timeout)
				provider_answered('AIOStreams')
			except Exception as e:
				provider_answered('AIOStreams', e)
				if str(e).startswith('skipped:'): return self._return()   # logged by provider_check; nothing is unreachable
				# LOCAL PATCH 2026-10-25 (4.0.5): host + error type only -- the manifest url embeds the user's config / credentials
				self._warn_once('AIOStreams: Manifest Unreachable', 'connect failed: %s' % safe_err(e, url, host_only=True))
				return self._return()
			if not response.ok:
				self._warn_once('AIOStreams: HTTP %s from manifest' % response.status_code, 'HTTP %s for %s' % (response.status_code, url_host(url)))
				return self._return()
			files = self._parse_streams(response.text)
			# LOCAL PATCH 2026-11-07 (Red Light 3.0.1 port): the episode's title too -- 'S02E05.Inside.Job' was dropped as an extra
			extras = source_utils.extras(self.title, info.get('ep_name') if media_type == 'episode' else None)
			self.sources = [r for r in (self._make_item(item, extras) for item in files) if r]
			# LOCAL PATCH 2026-08-29: free pre-signed expiry gate, same one http_streams uses -- an expired X-Amz signature is read
			# straight off the URL. The only dead-link check here; most FSL / R2 / PixelDrain pre-signs come back already expired.
			self.sources = source_utils.drop_expired_presigns(self.sources, response.headers.get('Date'))
			scrape_ran = True
		except Exception as e:
			from modules.kodi_utils import logger
			logger('aiostreams scraper Exception', safe_err(e, host_only=True))
		# Cache write — only after a real scrape attempt (skip on config-fail early returns)
		if scrape_ran and tmdb_id:
			try:
				from caches.external_cache import external_cache
				# LOCAL PATCH 2026-08-29: cap the TTL at 1 hour. get_cache_expiry is tuned for torrent hashes (up to 336 h), but these are
				# short-lived pre-signed / debrid-signed URLs; http_streams caps itself at 0.5 h for the same reason. A re-scrape is cheap.
				expiry_times = info.get('expiry_times') or (24, 0, 0)
				expiry_hours = min(1, expiry_times[0]) if self.sources else 1
				external_cache.set('aiostreams', media_type, tmdb_id, title, year, season_key, episode_key, self.sources, expiry_hours)
			except Exception:
				pass
		return self._return()

	@staticmethod
	def _warn_once(user_msg, log_msg):
		from modules.kodi_utils import logger, notification, get_property, set_property
		logger('aiostreams', log_msg)
		if get_property('deadlight.aiostreams.warned') == 'true':
			return
		set_property('deadlight.aiostreams.warned', 'true')
		notification(user_msg, 3500)

	def _return(self):
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources

	def _base_link(self):
		url = get_setting('deadlight.aiostreams.manifest_url', '').strip()
		if url in ('', 'empty_setting'): return ''
		url = url.rstrip('/')
		if url.endswith('/manifest.json'): url = url[:-len('/manifest.json')]
		if not url.startswith(('http://', 'https://')): url = 'https://%s' % url.lstrip('/')
		# LOCAL PATCH 2026-10-25 (4.0.5): plain http still works (a self-hosted LAN instance is legit) but the manifest
		# url carries the config in the clear, so say so once per Kodi session -- without the url
		if url.startswith('http://'):
			from modules.kodi_utils import logger, get_property, set_property
			if get_property('deadlight.aiostreams.http_warned') != 'true':
				set_property('deadlight.aiostreams.http_warned', 'true')
				logger('aiostreams', 'AIOStreams manifest is plain http')
		return url

	def _parse_streams(self, payload):
		try:
			data = jsloads(payload)
			return data.get('streams', []) if isinstance(data, dict) else []
		except:
			return []

	def _stream_url(self, item):
		url = item.get('url') or item.get('externalUrl') or ''
		if not url:
			stream = item.get('stream', {})
			if isinstance(stream, dict): url = stream.get('url') or ''
		return url

	def _stream_name(self, item):
		name = ''
		try: name = item.get('behaviorHints', {}).get('filename', '')
		except: name = ''
		if not name: name = item.get('name', '')
		if not name:
			title = item.get('title', '')
			name = title.split('\n')[0] if title else ''
		return normalize(name or '')

	def _stream_size_gb(self, item, file_info=''):
		try:
			size_bytes = float(item.get('behaviorHints', {}).get('videoSize'))
			return round(size_bytes / 1073741824.0, 2)
		except: pass
		try:
			# LOCAL PATCH 2026-10-19: source_utils.size_number reads the comma ('2,75 GB' was 275 GB); TB added.
			match = re.search(r'((?:\d+,\d+\.\d+|\d+\.\d+|\d+,\d+|\d+))\s*(GB|GiB|Gb|MB|MiB|Mb|TB|TiB|Tb)', file_info)
			if not match: return 0.0
			num = source_utils.size_number(match.group(1))
			unit = match.group(2).lower()
			if unit.startswith('m'): num /= 1024.0
			elif unit.startswith('t'): num *= 1024.0
			return round(num, 2)
		except: return 0.0

	def _file_info_line(self, item):
		file_title = item.get('title', '')
		if not file_title: return ''
		for line in file_title.replace('┈➤', '\n').split('\n'):
			if '💾' in line or '👤' in line: return line
		return ''

	def _description_tags(self, item, details):
		"""details (get_info's tags off the file name) plus the ones AIOStreams' description adds -- added, never removed."""
		# LOCAL PATCH 2026-10-01: AIOStreams parses more than the file name (the torrent / folder name too), and its formatter
		# writes the result into the description ('DV · HDR10'). Matched by the tags' own words, not the formatter's symbols, so a
		# different formatter still works; the title is cut first so it cannot supply tags. No languages (written in small caps).
		text = item.get('description') or item.get('title') or ''
		if not text: return details
		text = _NON_ASCII.sub(' ', text)
		if self.title: text = re.sub(re.escape(self.title), ' ', text, flags=re.I)
		have = [t.strip() for t in details.split('|') if t.strip()]
		def add(tag):
			if tag not in have: have.append(tag)
		def found(key, where=text): return _DESC_TAG[key].search(where) is not None
		if 'SDR' not in have:
			if found('dv'): add('[B]D/VISION[/B]')
			if found('hdr10plus'): add('[B]HDR[/B]'); add('[B]HDR10+[/B]')
			if found('hdr'): add('[B]HDR[/B]')
			if '[B]D/VISION[/B]' in have and '[B]HDR[/B]' in have: add('[B]HYBRID[/B]')
		if not any(t in have for t in ('AVC', '[B]AV1[/B]', '[B]HEVC[/B]')):
			if found('hevc'): add('[B]HEVC[/B]')
			elif found('av1'): add('[B]AV1[/B]')
			elif found('avc'): add('AVC')
		audio_lines = [line for line in text.split('\n') if any(found(k, line) for k in _DESC_AUDIO)]
		for key, tag in _DESC_AUDIO.items():
			if any(found(key, line) for line in audio_lines): add(tag)
		if 'DD+' in have and 'DD' in have: have.remove('DD')          # get_info's own rule: one Dolby Digital tag
		for drop, keep in (('DTS', ('DTS-X', 'DTS-HD MA', 'DTS-HD')), ('DTS-HD', ('DTS-HD MA',))):
			if drop in have and any(k in have for k in keep): have.remove(drop)
		# channels: only off a line that names an audio codec ('7.1 GB' / '7.1 Mbps' elsewhere are not a layout),
		# the largest layout listed, and only when the name gave none
		if not any(t in have for t in ('8CH', '7CH', '6CH', '2CH')):
			joined = ' '.join(audio_lines)
			for pattern, tag in _DESC_CHANNELS:
				if pattern.search(joined): add(tag); break
		return ' | '.join(have)

	_is_valid_http_url = staticmethod(source_utils.is_valid_http_url)   # LOCAL PATCH 2026-10-19: shared copy

	def _make_item(self, item, extras):
		try:
			url = self._stream_url(item)
			if not url: return None
			# Split off Kodi's pipe-headers convention (https://...|User-Agent=...) before validating
			url_part = url.split('|', 1)[0]
			if not self._is_valid_http_url(url_part):
				from modules.kodi_utils import logger
				logger('aiostreams reject url', url_host(url_part))   # LOCAL PATCH 2026-10-25 (4.0.5): playback urls carry the config
				return None
			name = self._stream_name(item)
			if not name: return None
			name_lower = name.lower()
			# LOCAL PATCH 2026-06-23: drop rows whose name contains 'download': download-page links from aggregator providers that
			# never play.
			if 'download' in name_lower: return None
			# LOCAL PATCH 2026-08-29: same transcode filter http_streams uses: the manifest can surface HDHub's /resolve/cj/ ladder,
			# an honest resolution tag over a bitrate a tenth of what it implies.
			if source_utils.is_transcode_url(url_part): return None
			if any(x in name_lower for x in extras): return None
			# LOCAL PATCH 2026-11-14: either numbering of the episode (self.pairs: TMDb's, plus Cinemeta's for a cour)
			if self.filter_title and not any(source_utils.check_title(self.title, name, self.aliases, self.year, s, e, air_date=getattr(self, 'air_date', None))
												for s, e in (getattr(self, 'pairs', None) or [(self.season, self.episode)])):
				return None
			size_gb = self._stream_size_gb(item, self._file_info_line(item))
			display_name = source_utils.clean_display_name(name)
			video_quality, details = source_utils.get_file_info(name_info=source_utils.release_info_format(name))
			details = self._description_tags(item, details)
			return {
				'name': name,
				'display_name': display_name,
				'quality': video_quality,
				'size': size_gb,
				'size_label': '%.2f GB' % size_gb if size_gb > 0 else '0.00 GB',
				'extraInfo': details,
				'url_dl': url,
				'id': url,
				'debrid': self.scrape_provider,
				'scrape_provider': self.scrape_provider,
				'direct': True,
				'direct_debrid_link': True,
				'local': False,
				'source': self.scrape_provider,
				'hash': item.get('infoHash', '') or item.get('hash', ''),
			}
		except:
			return None
