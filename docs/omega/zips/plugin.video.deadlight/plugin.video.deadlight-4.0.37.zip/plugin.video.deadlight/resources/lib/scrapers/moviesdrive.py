# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-11-18: MoviesDrive (moviesdrive.*), films and episodes, one of Direct Streams' providers
(scrapers/http_streams, setting http_streams.moviesdrive).

The site, as read 2026-11-18:
  - Try the last working domain or new4.moviesdrive.cyou first. If a request fails, the landing pages can supply
    the current domain.
  - search.php?q=<IMDb id> answers Typesense JSON with an imdb_id per post: posts are taken by the exact id.
  - a post lists its files as mdrive.lol/archive/<id> pages, one per quality: '2160p [19GB]' for a film, '720p Single
    Episode' / '4K 2160p Single Episode' for a season (a post may hold two seasons: the page title says which), 'Zip' packs.
  - an archive page names the release in its <title> and lists the files with plain hubcloud.*/drive/ links -- one for a
    film, 'EP01 - 2160p [7.36 GB] HubCloud | GDFliX' per episode. No link protector. HubCloud is resolved at play time
    (scrapers/hubcloud), which also gives each row its real file name and size. GDFlix is not used (its 'Instant DL'
    answered 500, 2026-11-18)."""
import base64
import html
import re
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
from modules.kodi_utils import logger
from modules.source_utils import get_aliases_titles
from scrapers._site_common import (get, with_site_host, site_post_page, episode_tag, norm_title, title_prefix_ok, film_name_ok, hubcloud_row,
								  recall, keep, forget, site_origin, HIGH_QUALITY as _HIGH_QUALITY, stated_quality_ok, recover_query_ok)
from scrapers.hubcloud import recover_query, recover_hits

LABEL = 'MoviesDrive'
_LANDINGS = ('https://moviesdrives.bid/', 'https://moviesdrives.mov/')
_HOST_FALLBACK = 'https://new4.moviesdrive.cyou'
_HOST_PROPERTY = 'deadlight.moviesdrive.host'
# The public landing can move ahead of older post mirrors. Last-chance WordPress index hosts for posts omitted by Typesense.
_WORDPRESS_FALLBACK_HOSTS = (_HOST_FALLBACK, 'https://new3.moviesdrive.cyou')
_SEASONS = re.compile(r'\bSeason\s*(\d{1,2})(?:\s*(?:-|–|&|to)\s*(\d{1,2}))?|\bS(\d{2})\b', re.I)
_ARCHIVE = re.compile(r'''<a[^>]+href=["'](https?://mdrive\.[a-z]+/archive/\d+/?)["'][^>]*>(.*?)</a>''', re.I | re.S)
_HUBCLOUD = re.compile(r'''href=["'](https?://hubcloud\.[a-z]+/drive/[\w-]+)["']''', re.I)
_RECOVER = re.compile(r'''href=["'](https?://hubcloud\.[a-z]+/drive/search-recover\.php\?[^"']+)["']''', re.I)
_EPISODE = re.compile(r'\b(?:EP|Episode|E)\s*0*(\d{1,3})\b', re.I)
_SIZE = re.compile(r'\[\s*([\d.,]+\s*[KMGT]i?B)\s*\]', re.I)
_TITLE = re.compile(r'<title>\s*([^<]+?)\s*</title>', re.I)
_MAX_ARCHIVES = 8


def _high_quality_link(label, heading):
	"""LOCAL PATCH 2026-11-21: an archive link is fetched only for 4K / 1080p -- the resolution its label states, else the
	last one in the heading just above it; neither stating one -> not fetched."""
	ok = stated_quality_ok(label)
	return bool(stated_quality_ok((heading or '')[-400:]) if ok is None else ok)


class _Stale(Exception):
	"""A kept search answer led nowhere (a post moved, or a new season's post is not in it): search again, once."""


def scrape(info):
	"""Stremio-shaped rows (http_streams._make_item reads them). Raises on a failed request, so http_streams counts the
	provider as failed and does not cache the empty answer."""
	media_type = info.get('media_type')
	imdb = str(info.get('imdb_id') or '')
	if media_type not in ('movie', 'episode') or not imdb.startswith('tt'): return []
	started = time.monotonic()
	try:
		try: return _scrape(info, imdb)
		except _Stale: return _scrape(info, imdb, fresh=True)
	finally:
		# LOCAL PATCH 2026-11-22: a timing line, so only with the timing diagnostics on (modules/settings.DIAG_TIMING)
		from modules.settings import diag_timing
		if diag_timing(): logger('MoviesDrive timing', '%s: %d ms' % (info.get('title') or imdb, int((time.monotonic() - started) * 1000)))


_SEARCH_TTL = 12 * 3600


def _search(imdb, fresh):
	"""(host, hit count, the posts filed under exactly `imdb`, from_memory). LOCAL PATCH 2026-11-18: a found answer is kept
	12 h (_site_common.recall): the search took 0.4-1.8 s of a 3-6 s scrape, and one answer serves every episode of a show."""
	prop = 'deadlight.moviesdrive.search.%s' % imdb
	kept = None if fresh else recall(prop, _SEARCH_TTL)
	if kept and kept.get('docs'):
		return recall(_HOST_PROPERTY, None) or _HOST_FALLBACK, kept.get('n', 0), kept['docs'], True
	# the last known address at once; the slow lookup (_find_host) only when it stops answering
	host, hits = with_site_host(_HOST_PROPERTY, _find_host, _HOST_FALLBACK,
		lambda h: get(h + '/search.php', params={'q': imdb, 'page': '1'}, referer=h + '/', accept='application/json').json().get('hits') or [])
	docs = [h['document'] for h in hits if (h.get('document') or {}).get('imdb_id') == imdb]
	# LOCAL PATCH 2026-11-21: Typesense can return hits without a post (Avaraachan & Sons, tt34792531).
	# Check WordPress search on the resolved host, then known post mirrors; accept only a body linking this exact IMDb id.
	if not docs:
		wp_hosts = list(dict.fromkeys([host] + list(_WORDPRESS_FALLBACK_HOSTS)))
		with ThreadPoolExecutor(max_workers=min(4, len(wp_hosts))) as ex:
			wp_requests = {wp_host: ex.submit(get, wp_host + '/wp-json/wp/v2/posts',
				params={'search': imdb, 'per_page': '10', '_fields': 'link,title,content'}, referer=wp_host + '/', accept='application/json')
				for wp_host in wp_hosts}
		for wp_host in wp_hosts:
			try:
				posts = wp_requests[wp_host].result().json()
				if not isinstance(posts, list): posts = []
				for post in posts:
					body = ((post.get('content') or {}).get('rendered') or '')
					if not re.search(r'(?i)https?://(?:www\.)?imdb\.com/title/%s(?:/|[\"\'?#])' % re.escape(imdb), body): continue
					title = ((post.get('title') or {}).get('rendered') or '').strip()
					if title and post.get('link'):
						docs.append({'imdb_id': imdb, 'permalink': post['link'], 'post_title': html.unescape(title)})
				if docs:
					host = wp_host
					keep(_HOST_PROPERTY, host)
					logger('MoviesDrive', '%s: IMDb-index fallback found %d exact post(s) on %s' % (imdb, len(docs), urlparse(host).netloc))
					break
			except Exception as e:
				logger('MoviesDrive', 'WordPress fallback failed on %s (%s)' % (urlparse(wp_host).netloc, type(e).__name__))
	if docs: keep(prop, {'n': len(hits), 'docs': [dict((k, d.get(k)) for k in ('imdb_id', 'permalink', 'post_title')) for d in docs]})
	else: forget(prop)
	return host, len(hits), docs, False


def _scrape(info, imdb, fresh=False):
	media_type = info.get('media_type')
	season = episode = None
	if media_type == 'episode':
		try: season, episode = int(info.get('season')), int(info.get('episode'))
		except (TypeError, ValueError): return []
		if season < 1: return []
	title = info.get('title') or ''
	host, count, posts, remembered = _search(imdb, fresh)
	what = '%s (%s)' % (title, info.get('year', '')) if season is None else '%s S%02dE%02d' % (title, season, episode)
	if season is not None:
		posts = [p for p in posts if not _seasons(p.get('post_title')) or season in _seasons(p.get('post_title'))]
	if not posts:
		if remembered: raise _Stale()   # a season posted since the answer was kept
		logger('MoviesDrive', '%s: no post (%d hit(s) for %s)' % (what, count, imdb))
		return []
	# LOCAL PATCH 2026-11-18: a show split over two posts has both pages read at once (MobLand: 2.78 s + 0.97 s, one after
	# the other, before)
	def post_page(post):
		path = urlparse(post.get('permalink') or '').path
		try:
			_, page = site_post_page(_HOST_PROPERTY, _find_host, host, path, _site_origin)
			return page
		except Exception:
			if remembered: raise _Stale()
			raise
	with ThreadPoolExecutor(max_workers=2) as ex:
		pages = list(ex.map(post_page, posts[:2]))
	links, queries = {}, {}
	for post, page in zip(posts[:2], pages):
		since = 0
		for m in _ARCHIVE.finditer(page):
			url, label = m.group(1), ' '.join(html.unescape(re.sub(r'<[^>]+>', ' ', m.group(2))).split())
			# the release heading above the link names its season ('MobLand (Season 2) [Hindi - English] 4K 2160p ... [7GB/E]'):
			# another season's archives are not fetched (a two-season post: 4 pages instead of 8)
			heading = ' '.join(html.unescape(re.sub(r'<[^>]+>', ' ', page[since:m.start()])).split())
			since = m.end()
			if not _high_quality_link(label, heading): continue
			if re.search(r'(?i)\bzip\b|\bpack\b', label): continue
			if season is not None:
				if not re.search(r'(?i)episode', label): continue   # season pages: 'Single Episode' archives
				if _seasons(heading[-200:]) and season not in _seasons(heading[-200:]): continue
			links.setdefault(url, (label, _seasons(post.get('post_title'))))
		# older posts (Animal, 2023) link each quality to HubCloud's search instead: one query per quality ('Animal 2023 1080p')
		for url in _RECOVER.findall(page):
			url = html.unescape(url)
			q = recover_query(url)
			if season is not None and not _query_is_episode(q, season, episode): continue
			# LOCAL PATCH 2026-11-22: the link's OWN query only (hubcloud.py); _searched_files keeps the 4K / 1080p names
			if recover_query_ok(q, _HIGH_QUALITY): queries.setdefault(q, url)
	archives = list(links.items())[:_MAX_ARCHIVES]
	if not archives and not queries:
		logger('MoviesDrive', '%s: no file page on %d post(s)' % (what, len(posts)))
		return []
	found = []
	if archives:
		# every archive page in one round (up to _MAX_ARCHIVES = 8; at 4, Dune Part Two's 5th and 6th waited for a free thread)
		with ThreadPoolExecutor(max_workers=len(archives)) as ex:
			found = [f for files in ex.map(lambda a: _archive_files(a[0], a[1][1], season, episode), archives) for f in files]
	searched = _searched_files(list(queries.values()), info, season, episode) if queries else []
	rows = _rows(found, season, episode, title if season is not None else '%s (%s)' % (title, info.get('year', ''))) + searched
	logger('MoviesDrive', '%s: %d file(s) from %d archive page(s) and %d HubCloud search(es), post %r' % (what, len(rows), len(archives), len(queries),
		(posts[0].get('post_title') or '')[:70]))
	return rows


def _query_is_episode(query, season, episode):
	"""A season post's search query for this episode ('MobLand S01E05 720p', 'Panchayat S04 Episode 1')."""
	m = re.search(r'\bS0*(\d{1,2})\s*(?:E|Ep(?:isode)?\.?\s*)0*(\d{1,3})\b', query or '', re.I)
	return bool(m) and (int(m.group(1)), int(m.group(2))) == (season, episode)


def _searched_files(urls, info, season, episode):
	"""Rows from HubCloud search-recover queries: video files of this film (its year, ±1, after its title) or this episode
	(its SxxEyy after the show's title). The search also returns other films and shows; those are left out."""
	titles = set(t for t in (norm_title(x) for x in [info.get('title') or ''] + get_aliases_titles(info.get('aliases', []))) if t)
	tag = episode_tag(season, episode) if season is not None else None
	try: year = int(info.get('year') or 0)
	except (TypeError, ValueError): year = 0
	with ThreadPoolExecutor(max_workers=min(8, len(urls))) as ex:
		hits = dict((h.get('url'), h) for found in ex.map(recover_hits, urls) for h in found if h.get('url'))
	rows = []
	for hit in hits.values():
		name = (hit.get('file_name') or '').strip()
		if 'video' not in (hit.get('mimeType') or '') or '/drive/' not in hit['url'] or not _HIGH_QUALITY.search(name): continue
		if tag:
			m = tag.search(name)
			if not m or not title_prefix_ok(name, m.start(), titles): continue
		elif not film_name_ok(name, year, titles): continue   # the shared film rule: never a longer title ('Animal.Park.2023')
		rows.append(hubcloud_row(LABEL, name, hit['url'], hit.get('size')))
	return rows


def _site_origin(url):
	return site_origin(url, 'moviesdrive')


def _find_host():
	"""The site's current 'https://host': the first base64 address on the landing page that answers as MoviesDrive (the
	redirect it may lead to followed). None when none does."""
	for landing in _LANDINGS:
		try: text = get(landing).text
		except Exception: continue
		for b in re.findall(r'''atob\(\s*['"]([A-Za-z0-9+/=]{16,})['"]\s*\)''', text):
			try: url = base64.b64decode(b).decode('utf-8', 'ignore').strip()
			except Exception: continue
			if not _site_origin(url): continue
			try:
				r = get(url)
				origin = _site_origin(r.url)
				if origin and 'moviesdrive' in r.text[:3000].lower(): return origin
			except Exception: continue
	return None


def _seasons(text):
	found = set()
	for m in _SEASONS.finditer(text or ''):
		if m.group(3): found.add(int(m.group(3)))
		else: found.update(range(int(m.group(1)), int(m.group(2) or m.group(1)) + 1))
	return found


def _archive_files(url, post_seasons, season, episode):
	"""[(HubCloud link, size stated, release title)] on one archive page: its one link for a film; for an episode, the link
	whose 'EP<n>' line is the episode, on a page of that season (its title names the season, or the post holds only it)."""
	try: page = get(url).text
	except Exception: return []
	title = html.unescape((_TITLE.search(page) or [None, ''])[1] or '')
	if season is None:
		m = _HUBCLOUD.search(page)
		size = _SIZE.search(title)
		return [(m.group(1), size.group(1) if size else '', title)] if m else []
	page_seasons = _seasons(title) or post_seasons
	if page_seasons and season not in page_seasons: return []
	files, since = [], 0
	for link in _HUBCLOUD.finditer(page):
		text = html.unescape(re.sub(r'<[^>]+>', ' ', page[since:link.start()]))
		since = link.end()
		eps, size = _EPISODE.findall(text), _SIZE.findall(text)
		if eps and int(eps[-1]) == episode: files.append((link.group(1), size[-1] if size else '', title))
	return files


def _rows(found, season, episode, show):
	"""One row per HubCloud file, named after its archive page's title -- the release as the site describes it, quality,
	source, SDR/HDR and codec included ('Dune: Part Two (2024) [Hindi.DDP5.1 + English.DDPA5.1] 2160p AMZN WEB-DL SDR H.265'),
	with 'S02E01' in place of '(Season 2)' for an episode, and the title in front when the archive leaves it out
	('Season 4 [Hindi (DD5.1)] 480p x264' -> 'Panchayat S04E01 ...': the name filter reads it). Not each HubCloud page's file
	name: that was one more request per row (2026-11-18); the page is opened at play time anyway."""
	rows = []
	for url, size, title in dict((f[0], f) for f in found).values():
		name = re.sub(r'\s*\[[^\]]*\d\s*[KMGT]i?B[^\]]*\]\s*$', '', title).strip()   # its trailing size ('[19GB]', '[7GB/E]')
		if not _HIGH_QUALITY.search(name): continue
		# and a leading 'Download ' ('Download Dupahiya (Season 1) WEB-DL ...'): the name filter refused all 4 Dupahiya S01E06
		# rows over it (Kodi log 2026-11-18 15:55)
		name = re.sub(r'(?i)^\s*download\s+', '', name)
		if season is not None:
			tag = 'S%02dE%02d' % (season, episode)
			name, n = re.subn(r'\(\s*Season\s*\d{1,2}\s*\)|\bSeason\s*\d{1,2}\b', tag, name, count=1, flags=re.I)
			if not n: name = re.sub(r'^(.*?)(\s*[\[(]|\s+\d{3,4}p\b|$)', lambda m: '%s %s%s' % (m.group(1), tag, m.group(2)), name, count=1)
		if show and norm_title(show) not in norm_title(name): name = '%s %s' % (show, name)
		rows.append(hubcloud_row(LABEL, name + '.mkv', url, size))
	return rows
