# -*- coding: utf-8 -*-
import json
import time
from caches.debrid_cache import debrid_cache
from caches.settings_cache import get_setting
from apis.real_debrid_api import RealDebridAPI
from apis.premiumize_api import PremiumizeAPI
from apis.alldebrid_api import AllDebridAPI
from apis.torbox_api import TorBoxAPI
from modules.source_utils import get_external_cache_status
from modules.kodi_utils import show_busy_dialog, hide_busy_dialog, notification
from modules.settings import enabled_debrids_check
# from modules.kodi_utils import logger

def debrid_enabled():
	return [
	i[0] for i in [('Real-Debrid', 'rd'), ('Premiumize.me', 'pm'), ('AllDebrid', 'ad'), ('TorBox', 'tb')] if enabled_debrids_check(i[1])]

def debrid_for_ext_cache_check(enabled_debrid=None):
	if not enabled_debrid: enabled_debrid = debrid_enabled()
	return any(i in ['Real-Debrid', 'AllDebrid'] for i in enabled_debrid)

def manual_add_magnet_to_cloud(params):
	# LOCAL PATCH 2026-10-03: look the service up BEFORE the busy dialog, and close the dialog whatever happens. An unknown
	# name ('Uncached TorBox' from an older context menu) raised IndexError here with the spinner left on screen.
	provider = str(params.get('provider') or '').replace('Uncached ', '', 1)
	function = dict([('Real-Debrid', RealDebridAPI), ('Premiumize.me', PremiumizeAPI), ('AllDebrid', AllDebridAPI), ('TorBox', TorBoxAPI)]).get(provider)
	if not function: return notification('No debrid service for this source')
	show_busy_dialog()
	try:
		result = function().create_transfer(params['magnet_url'])
		function().clear_cache()
	except Exception: result = 'failed'
	finally: hide_busy_dialog()
	if result == 'failed': notification('Failed')
	else: notification('Success')

def query_local_cache(hash_list):
	return debrid_cache.get_many(hash_list) or []

# LOCAL PATCH 2026-09-22: the per-file listing recorded alongside a cached verdict.
# Read from the database rather than returned by the check on purpose. Only UNCHECKED
# hashes are ever sent to the service (see cached_check), so on a re-scrape within the
# 24h window most hashes never reach TorBox at all -- and a listing that came back only
# from a live call would make a pack's size change between two scrapes of the same
# episode. Going through the table makes both paths answer identically.
def query_local_cache_files(hash_list, debrid='tb'):
	return debrid_cache.get_files_many(hash_list, debrid) or {}

def add_to_local_cache(hash_list, debrid, expires=24):
	debrid_cache.set_many(hash_list, debrid, expires)

def cached_check(hash_list, cached_hashes, debrid):
	cached_list = [i[0] for i in cached_hashes if i[1] == debrid and i[2] == 'True']
	# LOCAL PATCH 2026-10-02: a set, not a scan of every cached row per hash -- 1457 hashes x 1457 rows was ~2.1M
	# comparisons (70 ms off Kodi, more on the box). Same result.
	known = set(i[0] for i in cached_hashes if i[1] == debrid)
	unchecked_list = [i for i in hash_list if i not in known]
	return cached_list, unchecked_list

# LOCAL PATCH 2026-10-11: torrents Real-Debrid refuses to add (addMagnet error 35, 'infringing_file': blocked on RD's side)
# while DMM's shared index still lists them as cached -- The Alienist's S01-02 BluRay pack showed CACHED and failed to play
# every time. Kept a week in the MAIN cache, as one {hash: expiry} entry, because 'Clear Scrapers Cache' wipes the debrid
# cache and the block would be forgotten at once; RD_check reports them uncached whatever DMM or Torrentio say.
RD_BLOCKED_KEY, RD_BLOCKED_HOURS = 'rd_blocked_hashes', 168

# LOCAL PATCH 2026-10-11: Real-Debrid premium gone. A free account is refused every addMagnet ('permission_denied', code 9):
# 2026-10-11 from 16:45 every RD play failed that way -- the rows still showed CACHED (Torrentio / DMM say what is cached
# on RD, not what this account may use), RD-only releases (The Alienist, a Mushoku Tensei pack) could not play at all and
# every other pick spent its first try on RD. Marked for 6 h (re-checked on the next refusal after that); while it
# stands RD_check reports nothing cached, so the list and SmartPlay use the other debrids. Re-authorising clears it.
RD_NO_PREMIUM_KEY, RD_NO_PREMIUM_HOURS = 'rd_no_premium', 6

def rd_premium_lost():
	try:
		from caches.main_cache import main_cache
		return bool(main_cache.get(RD_NO_PREMIUM_KEY))
	except Exception: return False

def rd_mark_premium(lost):
	try:
		from caches.main_cache import main_cache
		if lost: main_cache.set(RD_NO_PREMIUM_KEY, 'true', expiration=RD_NO_PREMIUM_HOURS)
		else: main_cache.delete(RD_NO_PREMIUM_KEY)
	except Exception: pass

def rd_blocked():
	try:
		from caches.main_cache import main_cache
		now = time.time()
		return set(h for h, until in (main_cache.get(RD_BLOCKED_KEY) or {}).items() if until > now)
	except Exception: return set()

def rd_block(info_hash, hours=RD_BLOCKED_HOURS):
	# LOCAL PATCH 2026-10-25 (4.0.5): `hours` -- also used for a day when RD answers 'not cached' at play time
	# (real_debrid_api.resolve_magnet): Torrentio's [RD+] can be stale, and a verdict kept in the debrid cache alone was
	# lost to the next 'Clear Scrapers Cache' (Spider-Man 59a4d2ad: refused 13:41:41, wiped, read CACHED again at 13:43:36).
	try:
		from caches.main_cache import main_cache
		now = time.time()
		current = dict((h, u) for h, u in (main_cache.get(RD_BLOCKED_KEY) or {}).items() if u > now)
		current[str(info_hash).lower()] = max(current.get(str(info_hash).lower(), 0), now + hours * 3600)   # a week's block stays a week
		main_cache.set(RD_BLOCKED_KEY, current, expiration=RD_BLOCKED_HOURS)
		debrid_cache.set_many([(str(info_hash).lower(), 'False')], 'rd', hours)
	except Exception: pass

def RD_check(hash_list, cached_hashes, data, active_debrid):
	expires = 24
	if rd_premium_lost(): return []   # LOCAL PATCH 2026-10-11: see RD_NO_PREMIUM_KEY
	cached_hashes, unchecked_hashes = cached_check(hash_list, cached_hashes, 'rd')
	if unchecked_hashes:
		status = {}
		results = get_external_cache_status('Real-Debrid', unchecked_hashes, data, active_debrid, status)
		if results:
			cached_append = cached_hashes.append
			process_list = []
			process_append = process_list.append
			# LOCAL PATCH 2026-10-15: a hash is written uncached only when every service answered (status['complete']). With one
			# down, the 'True' rows are still evidence and are kept; the rest stay unknown and are asked again next time.
			complete = status.get('complete', False)
			for h in unchecked_hashes:
				if h in results:
					cached_append(h)
					process_append((h, 'True'))
				elif complete: process_append((h, 'False'))
		# LOCAL PATCH 2026-08-26 (Red Light 2.3.2/2.3.5 port): a failed check is NOT
		# evidence that the hashes are uncached. This branch used to record every
		# unchecked hash as 'False' and persist that verdict for 2h, so one debrid
		# timeout or empty reply made every source look uncached and kept it that way
		# across later scrapes. Write nothing instead -- the hashes stay unknown and
		# get re-checked next time. (Red Light additionally surfaces the provider as
		# UNCHECKED in the results list; that is a UI change and not ported here.)
		else: process_list, expires = [], 2
		add_to_local_cache(process_list, 'rd', expires)
	blocked = rd_blocked()
	return [h for h in cached_hashes if h not in blocked] if blocked else cached_hashes

def AD_check(hash_list, cached_hashes, data, active_debrid):
	# LOCAL PATCH 2026-07-10 (port of Red Light 1.7.3): AllDebrid retired the
	# magnet/instant API in 2025. Mediafusion cache-probes for AD (via
	# get_external_cache_status) are slow, unreliable behind VPN, and often
	# return NO_SERVER or hang for the full timeout. Skip the external check
	# entirely and return every hash as "unchecked" — AD sources still play
	# (they'll be resolved on-demand at play time), they just don't get a
	# pre-play cache badge. Behaves the same as external_cache_check=False.
	# Saves 2-5s per scrape when AllDebrid is an active debrid.
	return cached_hashes

def _check_failed(service, error, reply):
	from modules.kodi_utils import logger
	logger('debrid check', '%s: unreadable reply, nothing cached (%r): %s' % (service, error, str(reply)[:200]))

def PM_check(hash_list, cached_hashes):
	expires = 24
	cached_hashes, unchecked_hashes = cached_check(hash_list, cached_hashes, 'pm')
	if unchecked_hashes:
		results = PremiumizeAPI().check_cache(unchecked_hashes)
		if results:
			cached_append = cached_hashes.append
			process_list = []
			process_append = process_list.append
			try:
				results = results['response']
				for c, h in enumerate(unchecked_hashes):
					cached = 'False'
					try:
						if results[c] is True:
							cached_append(h)
							cached = 'True'
					except: pass
					process_append((h, cached))
			# LOCAL PATCH 2026-10-15: an unreadable reply (an error body, or raw text -- PremiumizeAPI._post returns
			# the text when it is not JSON) is a failed check too: write nothing, as the else-branch below. It used to
			# mark every hash 'False' for 24 h, the exact verdict the 2026-08-26 note forbids.
			except Exception as e:
				_check_failed('Premiumize', e, results)
				process_list, expires = [], 2
		# LOCAL PATCH 2026-08-26 (Red Light 2.3.2/2.3.5 port): a failed check is NOT
		# evidence that the hashes are uncached. This branch used to record every
		# unchecked hash as 'False' and persist that verdict for 2h, so one debrid
		# timeout or empty reply made every source look uncached and kept it that way
		# across later scrapes. Write nothing instead -- the hashes stay unknown and
		# get re-checked next time. (Red Light additionally surfaces the provider as
		# UNCHECKED in the results list; that is a UI change and not ported here.)
		else: process_list, expires = [], 2
		add_to_local_cache(process_list, 'pm', expires)
	return cached_hashes

# LOCAL PATCH 2026-10-25 (4.0.5): a TorBox outage said nothing. Every batch failing (2026-10-25 13:13 on: each call 307 ->
# status.torbox.app) wrote nothing, as it should -- no answer is not 'uncached' -- but the list just showed no TorBox rows.
# Now one log line per check and a notification at most every 30 minutes.
_TB_DOWN_PROP = 'deadlight.tb_down_notified'

def _tb_not_answering(reason):
	try:
		from modules.kodi_utils import logger, get_property, set_property
		logger('TorBox check', 'no answer from any batch (%s) -- TorBox down? Its rows stay unchecked' % reason)
		try: last = float(get_property(_TB_DOWN_PROP) or 0)
		except ValueError: last = 0
		if time.time() - last > 1800:
			set_property(_TB_DOWN_PROP, str(time.time()))
			notification('TorBox is not answering (%s)' % reason[:60], 6000)
	except Exception: pass

def TB_check(hash_list, cached_hashes):
	expires = 24
	cached_hashes, unchecked_hashes = cached_check(hash_list, cached_hashes, 'tb')
	if unchecked_hashes:
		from apis.torbox_api import LAST_ERROR as _tb_last_error, not_answering as _tb_stalled
		# LOCAL PATCH 2026-10-25 (4.0.6): not while TorBox is stalling (torbox_api._STALL_PROP) -- every further batch of the
		# early check, and the final check, waited out its own 20 s for nothing. Nothing is written: the hashes stay unknown.
		_stalled = _tb_stalled()
		if _stalled:
			_tb_not_answering('%d requests in a row timed out' % _stalled[0])
			return cached_hashes
		_tb_last_error['reason'] = ''
		_tb_errors = {}
		_t0 = time.perf_counter()
		# LOCAL PATCH 2026-10-11: up to 4 requests of at most 200 hashes, side by side, instead of one. Project Hail Mary's
		# 662 hashes, cold: one request 2.23 s, four of 200 0.94 s (warm 0.79 / 0.66). Four, not more: a burst of 9 TorBox
		# calls once left one hanging for its full 10 s (_prefetch_debrid's note). Each chunk is judged on ITS answer -- a
		# chunk whose request failed writes nothing, as a failed single request did (the 2026-08-26 rule below).
		size = max(200, -(-len(unchecked_hashes) // 4))
		chunks = [unchecked_hashes[i:i + size] for i in range(0, len(unchecked_hashes), size)]
		answers = [None] * len(chunks)
		def _ask(n):
			try: answers[n] = TorBoxAPI().check_cache(chunks[n])
			except Exception as e:
				answers[n] = None
				_tb_errors['reason'] = type(e).__name__
		if len(chunks) == 1: _ask(0)
		else:
			from threading import Thread
			threads = [Thread(target=_ask, args=(n,)) for n in range(len(chunks))]
			[t.start() for t in threads]
			[t.join() for t in threads]
		# LOCAL PATCH 2026-10-02: scrape.diag_timing -- how many hashes really went to TorBox, and how long that took
		if get_setting('deadlight.scrape.diag_timing', 'false') == 'true':
			from modules.kodi_utils import logger
			logger('scrape.timing', 'TorBox check: %d of %d hashes sent in %d request(s), %dms' % (len(unchecked_hashes), len(hash_list), len(chunks),
				int((time.perf_counter() - _t0) * 1000)))
		if not any(answers): _tb_not_answering(_tb_errors.get('reason') or _tb_last_error.get('reason') or 'no answer')
		process_list = []
		process_append = process_list.append
		cached_append = cached_hashes.append
		for chunk, results in zip(chunks, answers):
			# LOCAL PATCH 2026-08-26 (Red Light 2.3.2/2.3.5 port): a failed check is NOT evidence that the hashes are
			# uncached -- one debrid timeout or empty reply used to make every source look uncached for 2h. Write nothing
			# for such a chunk; its hashes stay unknown and are re-checked next time.
			if not results: continue
			try:
				data = results['data']
				# LOCAL PATCH 2026-09-22: keep the per-file listing, trimmed to the two fields anything
				# downstream uses -- short_name (what TorBox's own resolver matches on) and size. The
				# raw entry also carries id and opensubtitles_hash, which would roughly double the blob
				# for no consumer. Absent for an uncached hash, since it is not in the response at all.
				file_map = {}
				for i in data:
					try:
						_files = [{'name': f.get('short_name') or f.get('name'), 'size': f.get('size')}
							for f in (i.get('files') or []) if f.get('size')]
						if _files: file_map[str(i['hash']).lower()] = json.dumps(_files, separators=(',', ':'))
					except Exception: pass
				found = set(str(i['hash']).lower() for i in data)
				for h in chunk:
					cached = 'False'
					if str(h).lower() in found:
						cached_append(h)
						cached = 'True'
					process_append((h, cached, file_map.get(str(h).lower())))
			# LOCAL PATCH 2026-10-15: an error-shaped reply ({"success": false, "data": null} on a 429 or a dead key) is
			# truthy, passed `if not results`, and raised on `for i in data` -- which then wrote the whole chunk 'False'
			# for 24 h, against the rule just above. Now the chunk writes nothing and the reason is logged.
			except Exception as e: _check_failed('TorBox', e, results)
		if process_list: add_to_local_cache(process_list, 'tb', expires)
	return cached_hashes
