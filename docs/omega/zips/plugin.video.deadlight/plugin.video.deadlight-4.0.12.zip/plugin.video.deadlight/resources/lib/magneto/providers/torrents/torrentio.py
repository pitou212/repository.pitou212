# created by Venom for Fenomscrapers
"""
	Fenomscrapers Project
"""

from json import loads as jsloads
import re
from threading import Lock
from magneto.modules import client
from magneto.modules import source_utils
from magneto.modules import anime_utils


def _one_row_per_hash(rows):
	"""LOCAL PATCH 2026-10-21: torrentio can answer one episode with SEVERAL files of the same torrent -- The Last of Us
	S01E03 gave the episode (fileIdx 0, 17.56 GB) and 'Extras/Inside.the.Episode.S01E03.mkv' (fileIdx 17, 171 MB). Both
	carry the pack's name, so no name filter can tell them apart, and sources.deduplicate_results keeps whichever came
	first. Keeps each hash's LARGEST file (an extra is always smaller than its episode), at the first row's place."""
	best = {}
	for i, row in enumerate(rows):
		key = (row.get('hash') or '').lower()
		if key not in best: best[key] = (i, row)
		elif (row.get('size') or 0) > (best[key][1].get('size') or 0): best[key] = (best[key][0], row)
	return [row for i, row in sorted(best.values(), key=lambda x: x[0])]


class source(source_utils.SourceRegistry):
	timeout = 10
	priority = 1
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	# LOCAL PATCH 2026-10-06: one future per search (source_utils.SourceRegistry), not the class-wide queue
	_lock = Lock()
	_cache = {}
	def __init__(self):
		self.language = ['en']
		self.base_link = "https://torrentio.strem.fun"
		self.movieSearch_link = '/stream/movie/%s.json'
		self.tvSearch_link = '/stream/series/%s:%s:%s.json'
		# LOCAL PATCH 2026-08-09: kitsu path for anime — cour-scoped at the source,
		# no cross-cour contamination possible. Otaku uses this pattern.
		self.tvSearch_link_kitsu = '/stream/series/kitsu:%s:%s.json'
		self.min_seeders = 0
# Currently supports YTS(+), EZTV(+), RARBG(+), 1337x(+), ThePirateBay(+), KickassTorrents(+), TorrentGalaxy(+), HorribleSubs(+), NyaaSi(+), NyaaPantsu(+), Rutor(+), Comando(+), ComoEuBaixo(+), Lapumia(+), OndeBaixa(+), Torrent9(+).

	def sources(self, data, hostDict):
		sources = []
		if not data: return sources
		future = self.start_future(data)
		sources_append = sources.append
		try:
			aliases = data['aliases']
			year = data['year']
			imdb = data['imdb']
			kitsu_mode = kitsu_film = False
			if 'tvshowtitle' in data:
				title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
				episode_title = data['title']
				season = data['season']
				episode = data['episode']
				hdlr = 'S%02dE%02d' % (int(season), int(episode))
				air_date = data.get('premiered')   # LOCAL PATCH 2026-10-24: date-named releases (source_utils.air_date_pattern)
				years = None
				# LOCAL PATCH 2026-08-09: prefer kitsu path for anime when DeadLight
				# passed kitsu_id + cour_episode. Cour-scoped query eliminates
				# cross-cour leakage that the imdb path suffers from.
				kitsu_id = data.get('kitsu_id')
				cour_ep = data.get('cour_episode')
				kitsu_mode = bool(kitsu_id) and cour_ep is not None
				if kitsu_mode:
					url = '%s%s' % (self.base_link, self.tvSearch_link_kitsu % (kitsu_id, cour_ep))
				else:
					url = '%s%s' % (self.base_link, self.tvSearch_link % ((imdb,) + source_utils.stremio_se(data, season, episode)))   # LOCAL PATCH 2026-10-25 (4.0.5)
			else:
				title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
				episode_title = None
				hdlr = year
				air_date = None
				years = [str(int(year)-1), str(year), str(int(year)+1)]
				# LOCAL PATCH 2026-10-06: an anime film with no IMDb id is asked for by its Kitsu id (kitsu:2280 Detective Conan:
				# Conan and Kid and Crystal Mother -- 3 rows, none before). With an IMDb id the query is unchanged.
				kitsu_film = bool(data.get('kitsu_id')) and not anime_utils.real_imdb(imdb)
				url = '%s%s' % (self.base_link, self.movieSearch_link % ('kitsu:%s' % data['kitsu_id'] if kitsu_film else imdb))
			try:
				results = client.request(url, timeout=self.timeout)
				files = jsloads(results)['streams']
			except:
				files = []
				raise
			finally:
				source_utils.set_future(future, files)
			_INFO = re.compile(r'👤.*')
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.set_future(future, [])
			source_utils.scraper_error('TORRENTIO')
			return sources

		for file in files:
			try:
				hash = file['infoHash']
				file_title = file['title'].split('\n')
				file_info = [x for x in file_title if _INFO.match(x)][0]

				name = source_utils.clean_name(file_title[0])

				# LOCAL PATCH 2026-08-09: skip the SxxEyy name check in kitsu mode.
				# Torrentio's kitsu:<id>:<ep> endpoint is cour-scoped — it already did
				# the episode matching at the source (each stream carries a fileIdx
				# pointing at the right file inside batches). Anime batch names
				# ('[DB] Diamond no Ace [BD1080p]', '[Erai-raws] ... 01 ~ 75') carry
				# no S01E43 token, so check_title rejected EVERY kitsu result and the
				# provider silently contributed nothing for anime.
				# LOCAL PATCH 2026-10-06: a film asked for by Kitsu id is judged like the kitsu episode path (the title only):
				# older film releases often carry no year, which check_title demands of a film
				if not (kitsu_mode or kitsu_film):
					if not source_utils.check_title(title, aliases, name.replace('.(Archie.Bunker', ''), hdlr, year, years, air_date=air_date, id_matched=True): continue
				# LOCAL PATCH 2026-08-27: kitsu mode still skips the SxxExx check above (anime
				# releases carry no such token) but no longer skips checking the SHOW. Querying
				# by ID was assumed to scope results to one anime; it does not always -- a bad
				# id returns the right episode number of an entirely different series, which no
				# episode-level test can catch. See anime_utils.title_guard.
				elif not anime_utils.title_guard(name, title, anime_utils.alias_titles(data)): continue
				# LOCAL PATCH 2026-10-05: on anime, judge the FILE torrentio picked (behaviorHints.filename, also line 2 of the
				# title) -- archives, art, music, scans (anime_utils.stremio_junk). Nothing stricter: its Kitsu answers are
				# scoped to the entry, and reading the file's numbers there only lost right rows (measured 2026-10-05: all 11
				# of Black Clover's 2nd Season, and SubsPlease's 'Solo Leveling - 13', which is S2E1 in its numbering).
				if data.get('is_anime'):
					_file = (file.get('behaviorHints') or {}).get('filename') or (file_title[1] if len(file_title) > 1 and not _INFO.match(file_title[1]) else '')
					if anime_utils.stremio_junk(_file or file_title[0], [title] + anime_utils.alias_titles(data)): continue
					# LOCAL PATCH 2026-10-05: ...but a file claiming a LATER season is a mis-file even here: kitsu:43907:12
					# (Mushoku Tensei S1E23) answered 'Mushoku Tensei II - Episode 23' (anime_utils.later_season_reject)
					if anime_utils.later_season_reject([_file, file_title[0]], data): continue
					if anime_utils.foreign_cour_marked(_file, data) or anime_utils.foreign_cour_marked(file_title[0], data): continue   # 'act II' under Ace S2
					if anime_utils.other_show_year(file_title[0], data) or anime_utils.other_show_year(_file, data): continue   # a remake / live-action series
				name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)

				try:
					seeders = int(re.search(r'(\d+)', file_info).group(1))
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				try:
					size = re.search(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', file_info).group(0)
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)

				item = {
					'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True,
					'provider': 'torrentio', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
					'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders
				}
				# LOCAL PATCH 2026-10-03: a kitsu batch ('[DB] Diamond no Ace [BD1080p]') said nothing about being one, so
				# playback took the single-file path. Tagged like nyaa's (anime_utils.batch_fields); the size is already
				# the episode file's and torrentio is on DeadLight's no-divide list, so the size is unchanged.
				if kitsu_mode:
					_m = anime_utils._extract_meta(anime_utils._clean_for_extract(name))
					item.update(anime_utils.batch_fields(name, _m[1], _m[3], data.get('season_length')))
				sources_append(item)
			except:
				source_utils.scraper_error('TORRENTIO')
		return _one_row_per_hash(sources)

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		sources = []
		if not data: return sources
		sources_append = sources.append
		try:
			title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			aliases = data['aliases']
			imdb = data['imdb']
			year = data['year']
			season = data['season']
			url = '%s%s' % (self.base_link, self.tvSearch_link % (imdb, season, data['episode']))
			files = self.wait_future(data, self.timeout + 1)
			_INFO = re.compile(r'👤.*')
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('TORRENTIO')
			return sources

		for file in files:
			try:
				hash = file['infoHash']
				file_title = file['title'].split('\n')
				file_info = [x for x in file_title if _INFO.match(x)][0]

				name = source_utils.clean_name(file_title[0])

				episode_start, episode_end = 0, 0
				if not search_series:
					if not bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, season, name.replace('.(Archie.Bunker', ''))
						if not valid: continue
					package = 'season'

				elif search_series:
					if not bypass_filter:
						valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season, name.replace('.(Archie.Bunker', ''), total_seasons)
						if not valid: continue
					else: last_season = total_seasons
					package = 'show'

				# LOCAL PATCH 2026-10-05: on anime, a pack named for a LATER season is not this one ('[JP-EN] Mushoku Tensei II
				# ... COMPLETE' for Season 1 -- anime_utils.later_season_reject); filter_season_pack reads 'II' as nothing
				if data.get('is_anime') and package == 'season':
					_file = (file.get('behaviorHints') or {}).get('filename') or (file_title[1] if len(file_title) > 1 and not _INFO.match(file_title[1]) else '')
					if anime_utils.later_season_reject([file_title[0], _file], data): continue
				if data.get('is_anime') and anime_utils.other_show_year(file_title[0], data): continue   # a remake / live-action series
				if data.get('is_anime') and anime_utils.foreign_cour_marked(file_title[0], data): continue   # 'act II' packs under Ace S2
				name_info = source_utils.info_from_name(name, title, year, season=season, pack=package)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
				try:
					seeders = int(re.search(r'(\d+)', file_info).group(1))
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				try:
					size = re.search(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', file_info).group(0)
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)

				item = {
					'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True, 'true_size': True,
					'provider': 'torrentio', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
					'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders, 'package': package
				}
				if search_series: item.update({'last_season': last_season})
				elif episode_start: item.update(source_utils.pack_range_fields(episode_start, episode_end))   # LOCAL PATCH 2026-10-03: + pack_episodes for the size; # for partial season packs
				sources_append(item)
			except:
				source_utils.scraper_error('TORRENTIO')
		return _one_row_per_hash(sources)
