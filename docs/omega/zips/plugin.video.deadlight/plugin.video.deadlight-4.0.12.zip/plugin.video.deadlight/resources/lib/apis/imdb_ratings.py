# LOCAL PATCH 2026-10-22: IMDb's episode ratings, live, from IMDb's own GraphQL API -- the one source for the episode
# IMDb chip (metadata._backfill_season_imdb).
#
# OMDb rated ~13% of this library's episodes and lagged IMDb by weeks (Mirzapur S3: 3 of 10; VisionQuest: none, a week
# after the premiere). IMDb's own API answers a whole season -- every episode's tt id and rating -- in one request
# (0.5-0.9 s), the same day an episode airs (VisionQuest S1E3 the day after airing: 8.2 from 2,552 votes).
#
# This is the API imdb.com's own pages call. It is not a public, documented API: it answers only requests that carry the
# web client's headers (a plain request gets 403), and IMDb may change the schema or refuse them at any time. So every
# failure is quiet -- the chip stays empty -- and a refusal (403 / 429) starts a 6 h cooldown instead of being retried on
# every list.
from modules.kodi_utils import make_session, logger, cooldown_active, start_cooldown
from modules.utils import safe_err   # LOCAL PATCH 2026-10-25 (4.0.5): request errors logged without their url / query keys

_URL = 'https://api.graphql.imdb.com/'
_HEADERS = {'Content-Type': 'application/json', 'Origin': 'https://www.imdb.com', 'Referer': 'https://www.imdb.com/',
			'x-imdb-client-name': 'imdb-web-next-localized',
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36'}
_COOLDOWN_PROP = 'deadlight.imdb_api_cooldown_until'
_COOLDOWN_SECONDS = 6 * 3600
_PAGE = 250   # long anime seasons page past this
session = make_session(_URL, headers=_HEADERS)

_SEASON_QUERY = '''query DeadLightSeason($id: ID!, $season: String!, $first: Int!, $after: ID) {
  title(id: $id) {
    episodes {
      episodes(first: $first, after: $after, filter: { includeSeasons: [$season] }) {
        edges { node { id series { episodeNumber { seasonNumber episodeNumber } } ratingsSummary { aggregateRating voteCount } } }
        pageInfo { hasNextPage endCursor }
      }
    }
  }
}'''


def on_cooldown():
	return cooldown_active(_COOLDOWN_PROP)


def season_ratings(series_imdb_id, season):
	"""{episode_number:int -> (rating:str like '8.2' or '', episode tt id:str, votes:int)} for one season, every episode IMDb lists.
	{} when IMDb has no such season; None when the request failed (not cached by the caller, so it is asked again)."""
	if not series_imdb_id or not str(series_imdb_id).startswith('tt') or on_cooldown(): return None
	out, after = {}, None
	try:
		for _page in range(8):
			variables = {'id': series_imdb_id, 'season': str(season), 'first': _PAGE, 'after': after}
			r = session.post(_URL, json={'query': _SEASON_QUERY, 'variables': variables}, timeout=10)
			if r.status_code in (403, 429):
				start_cooldown(_COOLDOWN_PROP, _COOLDOWN_SECONDS)
				logger('IMDb API', 'refused (HTTP %s) -- paused for %d h' % (r.status_code, _COOLDOWN_SECONDS // 3600))
				return None
			if r.status_code != 200:
				logger('IMDb API', 'HTTP %s for %s S%s' % (r.status_code, series_imdb_id, season))
				return None
			data = r.json()
			if data.get('errors') and not data.get('data'):
				logger('IMDb API', 'error for %s S%s: %s' % (series_imdb_id, season, str(data['errors'])[:160]))
				return None
			conn = ((((data.get('data') or {}).get('title') or {}).get('episodes') or {}).get('episodes')) or {}
			for edge in conn.get('edges') or []:
				node = (edge or {}).get('node') or {}
				num = ((node.get('series') or {}).get('episodeNumber') or {})
				try: ep = int(num.get('episodeNumber'))
				except (TypeError, ValueError): continue
				summary = node.get('ratingsSummary') or {}
				value = summary.get('aggregateRating')
				try: votes = int(summary.get('voteCount') or 0)
				except (TypeError, ValueError): votes = 0
				# LOCAL PATCH 2026-10-27: + the vote count, for the season's own rating (metadata.imdb_season_rating)
				out[ep] = ('%.1f' % float(value) if value else '', node.get('id') or '', votes)
			info = conn.get('pageInfo') or {}
			if not info.get('hasNextPage'): break
			after = info.get('endCursor')
		return out
	except Exception as e:
		logger('IMDb API', 'failed for %s S%s: %s' % (series_imdb_id, season, safe_err(e)))
		return None


# LOCAL PATCH 2026-10-27: every regular episode of a series in IMDb's order, for an anime TMDb keeps as ONE season where IMDb
# splits it (Re:Zero: TMDb S1 of 85 episodes, IMDb S1-S4 of 25 / 25 / 16 / 19). Asking IMDb for TMDb's season number got
# IMDb's first 25 only, so episodes 26-85 had no IMDb rating and the later cour rows no season rating. The caller
# (metadata._backfill_season_imdb) matches by position in the whole run instead: TMDb S1E26 is the 26th episode, IMDb S2E1.
_ALL_QUERY = '''query DeadLightAll($id: ID!, $first: Int!, $after: ID) {
  title(id: $id) {
    episodes {
      episodes(first: $first, after: $after) {
        edges { node { id series { episodeNumber { seasonNumber episodeNumber } } ratingsSummary { aggregateRating voteCount } } }
        pageInfo { hasNextPage endCursor }
      }
    }
  }
}'''


def all_episode_ratings(series_imdb_id):
	"""[(season, episode, rating:str or '', tt id, votes:int)] for every episode in seasons 1+, ordered by season and
	episode. None when the request failed (the caller then keeps the season-number answer)."""
	if not series_imdb_id or not str(series_imdb_id).startswith('tt') or on_cooldown(): return None
	rows, after = [], None
	try:
		for _page in range(8):
			r = session.post(_URL, json={'query': _ALL_QUERY, 'variables': {'id': series_imdb_id, 'first': _PAGE, 'after': after}}, timeout=10)
			if r.status_code in (403, 429):
				start_cooldown(_COOLDOWN_PROP, _COOLDOWN_SECONDS)
				logger('IMDb API', 'refused (HTTP %s) -- paused for %d h' % (r.status_code, _COOLDOWN_SECONDS // 3600))
				return None
			if r.status_code != 200: return None
			data = r.json()
			conn = ((((data.get('data') or {}).get('title') or {}).get('episodes') or {}).get('episodes')) or {}
			for edge in conn.get('edges') or []:
				node = (edge or {}).get('node') or {}
				num = ((node.get('series') or {}).get('episodeNumber') or {})
				try: s, e = int(num.get('seasonNumber')), int(num.get('episodeNumber'))
				except (TypeError, ValueError): continue
				if s < 1: continue
				summary = node.get('ratingsSummary') or {}
				value = summary.get('aggregateRating')
				try: votes = int(summary.get('voteCount') or 0)
				except (TypeError, ValueError): votes = 0
				rows.append((s, e, '%.1f' % float(value) if value else '', node.get('id') or '', votes))
			info = conn.get('pageInfo') or {}
			if not info.get('hasNextPage'): break
			after = info.get('endCursor')
		return sorted(rows, key=lambda x: (x[0], x[1]))
	except Exception as e:
		logger('IMDb API', 'all episodes failed for %s: %s' % (series_imdb_id, safe_err(e)))
		return None
