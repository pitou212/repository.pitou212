# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-10-25 (4.0.5): the Stremio episode number of a date-released show, by air date.

	TMDb and Stremio number a daily show differently: Jeopardy! 2026-10-23 is TMDb S43E30 but Cinemeta (and so torrentio,
	comet, mediafusion and the other id-searched providers) S2026E177, so asking them for tt0159881:43:30 found nothing
	while tt0159881:2026:177 held the release. Both sides agree on the air date, so the date is the key.

	Cinemeta's 'released' is the US air time written at a fixed UTC-8 (no daylight saving): Jeopardy! 03:00Z (7 pm),
	The Daily Show 07:00Z (11 pm), Fallon 07:30Z (11:30 pm), every episode -- so released - 8 h is the US air date.
	The meta is large (Jeopardy!: 7.5 MB, 9646 episodes), so only a date -> [season, episode] map of the last ~400 days is
	kept, in main_cache for a day, and fetched again at most hourly when asked for a date it does not hold yet.
	Season 0 is skipped (a special can share a day with an episode: 0:71 and 2026:176 on 10-22).

	Red Light's native_torrents._cinemeta_map_episode solves a different case (no IMDb id: maps the season only).
"""
import time
from datetime import datetime, timedelta
from caches.main_cache import main_cache
from modules.kodi_utils import logger, make_session

_META_URL = 'https://v3-cinemeta.strem.io/meta/series/%s.json'
_KEEP_DAYS = 400
_REFETCH_SECONDS = 3600
_session = make_session('https://v3-cinemeta.strem.io')

def _us_air_date(released):
	"""'2026-10-24T03:00:00.000Z' -> '2026-10-23'. Hand-parsed: datetime.strptime fails in Kodi after its first call."""
	try:
		r = str(released)
		stamp = datetime(int(r[0:4]), int(r[5:7]), int(r[8:10]), int(r[11:13] or 0), int(r[14:16] or 0))
		return (stamp - timedelta(hours=8)).strftime('%Y-%m-%d')
	except (TypeError, ValueError, IndexError): return ''

def _fetch(imdb_id):
	"""{air date: [[season, episode], ...]} for the last _KEEP_DAYS days and ahead, or None on any failure."""
	try:
		response = _session.get(_META_URL % imdb_id, timeout=8)
		if not response.ok: return None
		videos = (response.json().get('meta') or {}).get('videos') or []
	except Exception as e:
		logger('cinemeta', '%s: fetch failed: %s' % (imdb_id, type(e).__name__))
		return None
	cutoff = (datetime.utcnow() - timedelta(days=_KEEP_DAYS)).strftime('%Y-%m-%d')
	dates = {}
	for v in videos:
		try: season, episode = int(v.get('season')), int(v.get('episode'))
		except (TypeError, ValueError): continue
		if season <= 0: continue
		day = _us_air_date(v.get('released') or v.get('firstAired') or '')
		if day and day >= cutoff: dates.setdefault(day, []).append([season, episode])
	for pairs in dates.values(): pairs.sort()
	return dates

def daily_episode(imdb_id, air_date):
	"""(season, episode) as strings in Stremio's numbering for the episode that aired on air_date ('YYYY-MM-DD'), or None.
	Two episodes on one day: the first (lower) one, logged."""
	if not imdb_id or not str(imdb_id).startswith('tt') or len(str(air_date or '')) < 10: return None
	air_date = str(air_date)[:10]
	key = 'cinemeta_dates_%s' % imdb_id
	cached = main_cache.get(key)
	if not isinstance(cached, dict) or (air_date not in (cached.get('dates') or {}) and time.time() - cached.get('ts', 0) > _REFETCH_SECONDS):
		dates = _fetch(imdb_id)
		# a failed fetch is stamped too (the older map kept), so a down Cinemeta is asked again in an hour, not every scrape
		cached = {'ts': int(time.time()), 'dates': dates if dates is not None else ((cached or {}).get('dates') or {})}
		main_cache.set(key, cached, expiration=24)
	pairs = ((cached or {}).get('dates') or {}).get(air_date)
	if not pairs: return None
	if len(pairs) > 1: logger('cinemeta', '%s %s: %d episodes that day, using S%sE%s' % (imdb_id, air_date, len(pairs), pairs[0][0], pairs[0][1]))
	return str(pairs[0][0]), str(pairs[0][1])
