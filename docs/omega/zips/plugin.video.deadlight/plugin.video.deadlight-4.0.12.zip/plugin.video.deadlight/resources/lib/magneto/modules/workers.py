"""
	Fenomscrapers Module
"""

from threading import Thread as thread

class Thread(thread):
	def __init__(self, target, *args):
		# LOCAL PATCH 2026-10-18: counted -- this thread's requests land in the creating thread's tally (client.status)
		from magneto.modules.client import counted
		self._target = counted(target)
		self._args = args
		thread.__init__(self, target=self._target, args=self._args)
