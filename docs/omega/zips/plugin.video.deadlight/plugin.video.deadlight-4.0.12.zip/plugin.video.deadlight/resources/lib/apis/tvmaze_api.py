# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-10-16: TVmaze (api.tvmaze.com) -- TV episode air times and a show's renewal state.

Public API, no key, no account. Data by TVmaze, licensed CC BY-SA 4.0 -- credited in the 'TV Air Times' setting.
Limit: 20 requests per 10 seconds per IP (429 beyond it): at most _IN_FLIGHT at once here, one retry after a 429.

  show_id(meta)                 TVmaze id via /lookup/shows?imdb=, else ?thetvdb=; 0 when TVmaze has no such show
  season_air_times(meta, n)     {episode: 'YYYY-MM-DDTHH:MM:SS.000Z'} for season n, from ONE /shows/{id}/episodes
                                request that covers every season (the same shape trakt_air.get_season_air_times returns)
  show_info(meta, cached_only)  {'status', 'next', 'prev'} -- status is TVmaze's 'Running' / 'To Be Determined' /
                                'In Development' / 'Ended'; TMDb only says 'Returning Series' for the first three

Lists cache: the id 30 days (a miss too, as {'id': 0} -- an empty result would be kept only 0.3 h), the show 12 h, the
episodes 24 h, or 30 days once the show has ended. A request that failed is not stored (base_cache.cache_ttl)."""
import time, threading, datetime
from caches.lists_cache import lists_cache_object, lists_cache
from modules.kodi_utils import get_property, set_property, logger, make_session, cooldown_active, start_cooldown
# LOCAL PATCH 2026-10-19: DeadLight's lazy session -- its shared SSL context loads the CA bundle once per process,
# where a bare requests.get reloaded it for every connection (~0.9 s CPU each with Kodi's requests 2.31 / urllib3 2.2)
_session = make_session()

_BASE = 'https://api.tvmaze.com'
_HEADERS = {'User-Agent': 'DeadLight-Kodi'}
_COOLDOWN_PROP = 'deadlight.tvmaze_cooldown_until'
_IN_FLIGHT = threading.Semaphore(4)


def on_cooldown():
	return cooldown_active(_COOLDOWN_PROP)


def _start_cooldown(secs, reason):
	try:
		start_cooldown(_COOLDOWN_PROP, secs)
		logger('TVmaze', '%s - no requests for %d s' % (reason, secs))
	except Exception: pass


def _get(path, params=None):
	"""Parsed JSON; {} for a 404 (TVmaze has no such thing); None when it did not answer."""
	if on_cooldown(): return None
	with _IN_FLIGHT:
		for attempt in (1, 2):
			try: r = _session.get(_BASE + path, params=params, headers=_HEADERS, timeout=10)
			except Exception as e:
				_start_cooldown(120, 'unreachable (%s)' % e.__class__.__name__); return None
			if r.status_code == 429 and attempt == 1:
				time.sleep(2); continue
			if r.status_code == 429: _start_cooldown(10, 'rate limited'); return None
			if r.status_code == 404: return {}
			if r.status_code >= 500: _start_cooldown(300, 'HTTP %s' % r.status_code); return None
			if not r.ok:
				logger('TVmaze', 'HTTP %s for %s' % (r.status_code, path)); return None
			try: return r.json()
			except ValueError: return None
	return None


def show_id(meta):
	"""TVmaze's id for a TMDb show, 0 when TVmaze has none, None when it could not be asked."""
	tmdb_id = meta.get('tmdb_id')
	if not tmdb_id: return None
	imdb_id, tvdb_id = meta.get('imdb_id'), meta.get('tvdb_id')
	def _fetch(_dummy):
		for key, value in (('imdb', imdb_id), ('thetvdb', tvdb_id)):
			if not value or str(value) in ('None', '0'): continue
			res = _get('/lookup/shows', {key: value})
			if res is None: return None   # no answer: nothing stored, asked again next time
			if res.get('id'): return {'id': int(res['id'])}
		return {'id': 0}
	try: res = lists_cache_object(_fetch, 'tvmaze_id_%s' % tmdb_id, 1, expiration=24 * 30)
	except Exception: return None
	return None if res is None else int(res.get('id') or 0)


def _stamp_iso(airstamp):
	"""TVmaze's '2026-10-21T12:00:00+00:00' -> trakt_air's '2026-10-21T12:00:00.000Z' (UTC). Not strptime (Kodi 3.8)."""
	try:
		s = str(airstamp)
		when = datetime.datetime(int(s[0:4]), int(s[5:7]), int(s[8:10]), int(s[11:13]), int(s[14:16]), int(s[17:19]))
		offset = s[19:]
		if offset and offset not in ('Z', '+00:00'):
			sign = -1 if offset[0] == '-' else 1
			when -= sign * datetime.timedelta(hours=int(offset[1:3]), minutes=int(offset[4:6]))
		return when.strftime('%Y-%m-%dT%H:%M:%S.000Z')
	except Exception: return None


def _all_episodes(meta, tvmaze_id):
	"""{'season': {'episode': iso}} for every numbered episode of the show (keys as str: the cache stores JSON)."""
	ended = meta.get('status') in ('Ended', 'Canceled')
	def _fetch(_dummy):
		# LOCAL PATCH 2026-10-20: the show with its episodes embedded, not /episodes alone -- the status chip's next / previous
		# episode and seasons ride along (~8 KB) and are stored for show_info, which then needs no request of its own. Not
		# the other way round: embedding the episodes in show_info's request would cost a talk show 1.7 MB (Tonight Show:
		# 2361 episodes, 6.3 s) for a chip that needs 10 KB.
		res = _get('/shows/%d' % tvmaze_id, _CHIP_EMBEDS + [('embed[]', 'episodes')])
		if not isinstance(res, dict): return None   # no answer: not stored
		eps = (res.get('_embedded') or {}).get('episodes') or []   # a 404 ({}) is an answer: nothing, stored as before
		if res.get('id'):
			try: _store_chip(tvmaze_id, _chip_info(res))
			except Exception: pass
		out = {}
		for ep in eps if isinstance(eps, list) else []:
			try:
				# a streaming release (webChannel: Apple TV, Netflix ...) usually has no 'airtime', and its 'airstamp' is then
				# a 12:00 UTC placeholder on the date (Slow Horses S6E6 2026-10-21T12:00:00+00:00) -- not a time; left out
				if not ep.get('airtime'): continue
				season, number, iso = ep.get('season'), ep.get('number'), _stamp_iso(ep.get('airstamp'))
				if season and number and iso: out.setdefault(str(int(season)), {})[str(int(number))] = iso
			except Exception: continue
		return out or {'_none': {}}
	try: return lists_cache_object(_fetch, 'tvmaze_eps_%s' % tvmaze_id, 1, expiration=24 * (30 if ended else 1)) or {}
	except Exception: return {}


def season_air_times(meta, season):
	"""{episode number: iso UTC} for one season; {} when TVmaze has nothing (or did not answer)."""
	try: season = int(season)
	except (TypeError, ValueError): return {}
	if season < 1: return {}
	tvmaze_id = show_id(meta)
	if not tvmaze_id: return {}
	season_map = _all_episodes(meta, tvmaze_id).get(str(season)) or {}
	out = {}
	for k, v in season_map.items():
		try: out[int(k)] = v
		except (TypeError, ValueError): continue
	return out


def show_info_known(meta):
	"""LOCAL PATCH 2026-10-16: True when show_info(cached_only=True) already has its answer -- TVmaze's show cached, or the
	show known to be missing there. False: only a request would tell (metadata queues one after the list is shown)."""
	try:
		cached = lists_cache.get('tvmaze_id_%s' % meta.get('tmdb_id'))
		if cached is None: return False
		tvmaze_id = int(cached.get('id') or 0)
		return not tvmaze_id or lists_cache.get('tvmaze_show2_%s' % tvmaze_id) is not None
	except Exception: return True

def show_info(meta, cached_only=False):
	"""{'status': ..., 'next': {...} or None, 'prev': {...} or None}, or None. cached_only: never a request."""
	# 'tvmaze_show2_': the row gained 'next_season' 2026-10-16; rows cached without it are not read
	if cached_only:
		try:
			cached = lists_cache.get('tvmaze_id_%s' % meta.get('tmdb_id'))
			tvmaze_id = int((cached or {}).get('id') or 0)
			return lists_cache.get('tvmaze_show2_%s' % tvmaze_id) if tvmaze_id else None
		except Exception: return None
	tvmaze_id = show_id(meta)
	if not tvmaze_id: return None
	string = 'tvmaze_show2_%s' % tvmaze_id
	try:
		cached = lists_cache.get(string)
		if cached is not None: return cached
		res = _get('/shows/%d' % tvmaze_id, _CHIP_EMBEDS)
		if not res: return None   # failed: not stored, asked again next time (as cache_ttl did)
		info = _chip_info(res)
		_store_chip(tvmaze_id, info)
		return info
	except Exception: return None


_CHIP_EMBEDS = [('embed[]', 'nextepisode'), ('embed[]', 'previousepisode'), ('embed[]', 'seasons')]

def _chip_info(res):
	"""show_info's record from a /shows/{id} answer carrying _CHIP_EMBEDS."""
	embedded = res.get('_embedded') or {}
	def _ep(e):
		if not e: return None
		return {'season': e.get('season'), 'number': e.get('number'), 'airstamp': _stamp_iso(e.get('airstamp')), 'type': e.get('type')}
	prev = _ep(embedded.get('previousepisode'))
	# a season listed after the last aired one -- what TVmaze adds when a renewal is real (Reacher lists S5 and S6
	# undated). 'Running' alone is not: it stays on a show nobody updated (Dupahiya, Chamak: no third season anywhere)
	last = int((prev or {}).get('season') or 0)
	later = sorted(int(s['number']) for s in (embedded.get('seasons') or []) if s.get('number') and int(s['number']) > last)
	return {'status': res.get('status') or '', 'next': _ep(embedded.get('nextepisode')), 'prev': prev,
			'next_season': later[0] if later else None}

def _store_chip(tvmaze_id, info):
	# LOCAL PATCH 2026-10-19: 12 h only while an episode is announced (its date can move); between seasons a renewal changes
	# over weeks, and 12 h meant 1-2 TVmaze requests per unwatched returning show on most browses.
	lists_cache.set('tvmaze_show2_%s' % tvmaze_id, info, expiration=12 if info.get('next') else 72)
