# -*- coding: utf-8 -*-
import json
import re
import time
from threading import Thread
from windows.base_window import open_window, create_window
from caches.episode_groups_cache import episode_groups_cache
from caches.settings_cache import get_setting
from scrapers import external, folders
from modules import debrid, kodi_utils, settings, metadata, watched_status
from modules.player import DeadLightPlayer, PLAYBACK_STOPPED_PROP, PLAYBACK_LAST_REMAINING_PROP, mark_internal_stop
# LOCAL PATCH 2026-09-24: how close to the end the player's last sample must be for a playback
# that was already over to count as having reached its end. See autoplay_nextep_handler.
NEXTEP_END_TOLERANCE = 15
# LOCAL PATCH 2026-10-15: the debrid resolvers' last failure reason ('TorBox: no file for this episode'), shown by play_file
RESOLVE_REASON_PROP = 'deadlight.resolve_reason'
from modules.source_utils import get_cache_expiry, make_alias_dict, include_exclude_filters, anime_episode_candidates, seas_ep_filter, release_group, same_group, name_was_cut, group_lost_to_cut, release_source, release_norm, get_release_quality, release_service, release_dynamic_range, provider_display_name, provider_panel_name, WindowCounter, namesake_clash, episode_title_mismatch
from modules.utils import clean_file_name, string_to_float, safe_string, remove_accents, get_datetime, manual_function_import
# logger = kodi_utils.logger

# LOCAL PATCH 2026-09-06: a torrent whose name ends in a video extension is a SINGLE FILE --
# multi-file torrents are directories and carry no extension on the name. _sticky_save used
# to label EVERY episode pin 'season', so pack-play then asked the debrid service to find
# episode N+1 inside a torrent holding only episode N. That can never succeed: BLACK TORCH
# e4-e8 each logged 'resolve_cached returned None' after ~1.5s before falling back to the
# scrape it should have gone straight to. Providers report this name themselves, so a pack
# whose name happens to look like a file merely degrades to the scrape path -- which is
# exactly today's behaviour -- rather than breaking anything.
_SINGLE_FILE_NAME = re.compile(r'\.(?:mkv|mp4|avi|ts|m2ts|mov|wmv|flv|m4v|mpg|mpeg|webm)$', re.I)
# LOCAL PATCH 2026-09-29: releases that are not the film asked for (sources.filter_not_the_film). The Odyssey (2026):
# 'The.Odyssey.2026.(NOT.The.Chris.Nolan.FILM).1080p...' (a Tubi film of the same name, BONE / NOtLAN) and
# 'the-odyssey-2026-official-imaxr-prologue-1.90-4-k-ultra-hd' (the IMAX prologue, listed as a 4K result).
_NOT_THE_FILM = re.compile(r'(?:^|[^a-z])not[ ._-]+the[ ._-]+(?:[a-z0-9]+[ ._-]+){0,4}(?:film|movie)(?:[^a-z]|$)', re.I)
_PROLOGUE = re.compile(r'(?:^|[^a-z])prologue(?:[^a-z]|$)', re.I)
# LOCAL PATCH 2026-09-06: an explicit SxxExx token names exactly ONE episode. Providers
# routinely report a pin name with no file extension at all -- kodi.log 12:33 shows
# 'Daemons.of.the.Shadow.Realm.S01E22.1080p.CR.WEB-DL.AAC.2' -- so the extension test
# above cannot stand alone. A real season pack ('...S01.1080p...') carries no Exx.
_EPISODE_MARKER = re.compile(r'[sS]\d{1,3}[ ._-]?[eE]\d{1,4}')
# LOCAL PATCH 2026-09-07: a season token with NO episode after it -- 'S01' in
# 'Lion.S01.2160p...' -- names one whole season. The lookbehind keeps 'DTS5.1' / 'x265'
# out; the lookahead is exactly the shape _EPISODE_MARKER accepts, so the two never both
# match the same token.
# LOCAL PATCH 2026-09-22: read the SPELLED-OUT season too. The pin for Mushoku Tensei
# (tmdb 94664) is named '...Jobless.Reincarnation.(Season.1).[BD.Remux...]' and carries
# no 'S01' token at all, so this pattern found nothing, the season-pack guard below never
# ran, and the recorded pack.season=1 -- sitting right there -- was never consulted. The
# S01 BD remux was then resolved for S02E01 and S02E13: kodi.log 2026-09-22 11:48 shows
# hash 9097dc596948 replayed for both.
#
# A spelled-out RANGE is deliberately not matched ('Season 1-2' yields nothing rather
# than a misleading single token), so a multi-season pack keeps falling through untouched.
_SEASON_MARKER = re.compile(r'(?<![A-Za-z0-9])[sS](\d{1,3})(?![ ._-]?[eE]\d)(?![0-9])'
	r'|(?<![a-z])season[ ._-]?(\d{1,3})(?![ ._-]*[-~][ ._-]*\d)(?![0-9])', re.I)


# LOCAL PATCH 2026-09-27: pins without a pack whose provider is one of these get a
# scrape of that provider alone before the full scrape (see _sticky_provider_play).
_SINGLE_PROVIDER_PINS = ('http_streams', 'easynews')
# LOCAL PATCH 2026-10-24: longest wait for that one-provider scrape. A down Direct host held SmartPlay ~13 s (Sootio's
# requests run 12 s) before the full scrape even started; past this the full scrape takes over.
# LOCAL PATCH 2026-10-25 (4.0.5): 5 -> 10 -- HDHub answered in 5.07 s (Avatar S2E4, 12:16) and the pin was missed.
_PIN_SCRAPE_CAP = 10

def _probe_stream(url):
	"""LOCAL PATCH 2026-10-08: True when a link serves its first byte, False when the server refuses it outright (403 / 404 /
	410 / 5xx -- a 4KHDHub mirror answered 403 'NotEntitled' to Kodi), None when it cannot tell (not http, timeout, any
	other error). Only False counts against a source, so a slow or odd server never blocks playback. Kodi's 'url|Header=v'
	form carries the headers the player would send."""
	try:
		if not str(url or '').lower().startswith(('http://', 'https://')): return None
		from urllib.parse import parse_qsl
		import requests
		link, _, extra = url.partition('|')
		headers = dict(parse_qsl(extra)) if extra else {}
		headers.setdefault('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36')
		headers['Range'] = 'bytes=0-0'
		with requests.get(link, headers=headers, stream=True, timeout=8, allow_redirects=True) as r:
			if r.status_code in (200, 206): return True
			if r.status_code in (401, 403, 404, 410, 451) or r.status_code >= 500: return False
			return None
	except Exception:
		return None

def _season_tokens(name):
	"""Distinct season numbers a pin name claims. Deduped BY VALUE, because the two
	forms often both appear for the SAME season -- '[sam] ... Season 1 (S01)' would
	otherwise look like a two-season pack and skip the guard."""
	out = []
	for m in _SEASON_MARKER.finditer(name or ''):
		v = m.group(1) or m.group(2)
		if v is None: continue
		try: out.append(int(v))
		except ValueError: pass
	return sorted(set(out))

class Sources():
	def __init__(self):
		self.params = {}
		self.prescrape_scrapers, self.prescrape_threads, self.prescrape_sources, self.uncached_results = [], [], [], []
		self.threads, self.providers, self.sources, self.internal_scraper_names, self.remove_scrapers = [], [], [], [], ['external']
		self.clear_properties, self.filters_ignored, self.active_folders, self.resolve_dialog_made, self.episode_group_used = True, False, False, False, False
		self.sources_total = self.sources_4k = self.sources_1080p = self.sources_720p = self.sources_sd = 0
		self.prescrape, self.disabled_ext_ignored = 'true', 'false'
		# LOCAL PATCH 2026-10-04: set by 'Rescrape With All Scrapers' alone. disabled_ext_ignored is also set by the episode
		# group and filters-ignored retries, so it cannot tell external.py that the user asked for every anime provider.
		self.all_scrapers_retry = False
		self.progress_dialog, self.progress_thread = None, None
		self.playing_filename = ''
		self.scrape_count = 0
		self.count_tuple = (('sources_4k', '4K', self._quality_length), ('sources_1080p', '1080p', self._quality_length), ('sources_720p', '720p', self._quality_length),
							('sources_sd', '', self._quality_length_sd), ('sources_total', '', self._quality_length_final))
		self.filter_keys = include_exclude_filters()
		self.filter_keys.pop('hybrid')
		self.default_internal_scrapers = ('easynews', 'rd_cloud', 'pm_cloud', 'ad_cloud', 'tb_cloud', 'aiostreams', 'http_streams', 'folders')
		self.debrids = {'Real-Debrid': ('apis.real_debrid_api', 'RealDebridAPI'), 'rd_cloud': ('apis.real_debrid_api', 'RealDebridAPI'),
		'rd_browse': ('apis.real_debrid_api', 'RealDebridAPI'), 'Premiumize.me': ('apis.premiumize_api', 'PremiumizeAPI'), 'pm_cloud': ('apis.premiumize_api', 'PremiumizeAPI'),
		'pm_browse': ('apis.premiumize_api', 'PremiumizeAPI'), 'AllDebrid': ('apis.alldebrid_api', 'AllDebridAPI'), 'ad_cloud': ('apis.alldebrid_api', 'AllDebridAPI'),
		'ad_browse': ('apis.alldebrid_api', 'AllDebridAPI'), 'TorBox': ('apis.torbox_api', 'TorBoxAPI'), 'tb_cloud': ('apis.torbox_api', 'TorBoxAPI'),
		'tb_browse': ('apis.torbox_api', 'TorBoxAPI')}
		self.retry_actions = settings.rescrape_settings()

	def playback_prep(self, params=None):
		kodi_utils.hide_busy_dialog()
		if params: self.params = params
		params_get = self.params.get
		if not kodi_utils.external_playback_check(self.params): return
		self.play_type = params_get('play_type', '')
		# LOCAL PATCH 2026-08-31 (doc only): `background` carries THREE unrelated meanings and
		# no caller can separate them. Produced only by episode_tools.py:94 (next episode) and
		# episode_tools.py:141 (random-continual, links 2+):
		#   1. show no UI    -- suppresses the progress window, joins scraper threads
		#                       synchronously, downgrades dialogs to toasts (lines 110, 136,
		#                       141, 156, 810, 821, 1066, and via meta['background'] into
		#                       scrapers/external.py)
		#   2. chain to another episode -- continue_resolve_check (line ~1147) uses it to
		#                       decide whether play_file is the tail end of an episode. THIS
		#                       IS LOAD-BEARING: without background, nothing chains at all
		#   3. play, do not ask -- the tail of play_source
		# So "silent play but do not chain", and "chain but do ask", are both inexpressible.
		# Meaning 3 is what silently played a wrong source when code wanted meaning 2.
		self.background = params_get('background', 'false') == 'true'
		self.prescrape = params_get('prescrape', self.prescrape) == 'true'
		self.random, self.random_continual = params_get('random', 'false') == 'true', params_get('random_continual', 'false') == 'true'
		if 'external_cache_check' in self.params: self.external_cache_check = params_get('external_cache_check') == 'true'
		else: self.external_cache_check = settings.external_cache_check()
		if self.play_type:
			if self.play_type == 'autoplay_nextep': self.autoplay_nextep, self.autoscrape_nextep = True, False
			elif self.play_type == 'random_continual': self.autoplay_nextep, self.autoscrape_nextep = False, False
			else: self.autoplay_nextep, self.autoscrape_nextep = False, True
		else: self.autoplay_nextep, self.autoscrape_nextep = settings.autoplay_next_episode(), settings.autoscrape_next_episode()
		self.autoscrape = self.autoscrape_nextep and self.background		
		self.ignore_scrape_filters = params_get('ignore_scrape_filters', 'false') == 'true'
		self.nextep_settings, self.disable_autoplay_next_episode = params_get('nextep_settings', {}), params_get('disable_autoplay_next_episode', 'false') == 'true'
		# LOCAL PATCH 2026-09-04: hashes whose cached resolve failed during THIS attempt.
		self._sticky_dead_hashes = set()
		# the episode-group retry sets True (a bool) before calling playback_prep again
		self.disabled_ext_ignored = params_get('disabled_ext_ignored', self.disabled_ext_ignored) in (True, 'true')
		# LOCAL PATCH 2026-10-05: Options > 'Scrape with ALL External Scrapers' asks for every anime provider too, like the retry
		if params_get('all_scrapers', 'false') == 'true': self.all_scrapers_retry = True
		self.folders_ignore_filters = get_setting('deadlight.results.folders_ignore_filters', 'false') == 'true'
		self.filter_size_method = int(get_setting('deadlight.results.filter_size_method', '0'))
		self.media_type, self.tmdb_id = params_get('media_type'), params_get('tmdb_id')		
		self.custom_title, self.custom_year = params_get('custom_title', None), params_get('custom_year', None)
		self.episode_group_label, self.episode_id = params_get('episode_group_label', ''), params_get('episode_id', None)
		self.playcount, self.watch_count = params_get('playcount', None), params_get('watch_count', 1)
		if self.media_type == 'episode':
			self.season, self.episode = int(params_get('season')), int(params_get('episode'))
			self.custom_season, self.custom_episode = params_get('custom_season', None), params_get('custom_episode', None)
			self.check_episode_group()
		else: self.season, self.episode, self.custom_season, self.custom_episode = '', '', '', ''
		if 'autoplay' in self.params: self.autoplay = params_get('autoplay', 'false') == 'true'
		else: self.autoplay = settings.auto_play(self.media_type)
		self.get_meta()
		# LOCAL PATCH 2026-09-26: IntroDB lookup starts here, alongside the scrape, instead of
		# blocking play() at the end -- see apis/introdb_api.prefetch_segments.
		try:
			from apis.introdb_api import prefetch_segments
			prefetch_segments(self.meta)
		except Exception: pass
		self.determine_scrapers_status()
		# sleep_time: poll interval of the internal-scrapers dialog (scrapers_dialog), 100 -> 50 ms 2026-09-26.
		self.sleep_time, self.provider_sort_ranks, self.scraper_settings = 50, settings.provider_sort_ranks(), settings.scraping_settings()
		self.include_prerelease_results = settings.include_prerelease_results()
		self.limit_resolve = settings.limit_resolve()
		self.weight_size = settings.size_sort_weighted()
		self.sort_function, self.quality_filter = settings.results_sort_order(), self._quality_filter()
		self.include_unknown_size = get_setting('deadlight.results.size_unknown', 'false') == 'true'
		self.make_search_info()
		if self.autoscrape: self.autoscrape_nextep_handler()
		else:
			# LOCAL PATCH 2026-08-31 (doc only): this returns and SKIPS THE SCRAPE ENTIRELY when
			# the pin has a pack, so _sticky_match never runs for pack pins. The matcher only
			# sees NON-pack pins (http_streams, direct links). Worth knowing before trying to
			# observe match/miss behaviour: with a pack pinned you will see only
			# "pack-play[debrid]" in the log and no match line at all, which looks like the
			# matcher is broken when it simply was not consulted.
			if self._sticky_pack_play(): return
			return self.get_sources()

	def check_episode_group(self):
		try:
			if any([self.custom_season, self.custom_episode]) or 'skip_episode_group_check' in self.params: return
			group_info = episode_groups_cache.get(self.tmdb_id)
			if not group_info: return
			group_details = metadata.group_episode_data(metadata.group_details(group_info['id']), self.episode_id, self.season, self.episode)
			if group_details:
				self.custom_season, self.custom_episode, self.episode_group_used = group_details['season'], group_details['episode'], True
				self.episode_group_label = '[B]CUSTOM GROUP: S%02dE%02d[/B]' % (self.custom_season, self.custom_episode)
		except: self.custom_season, self.custom_episode = None, None

	def determine_scrapers_status(self):
		self.active_internal_scrapers = settings.active_internal_scrapers()
		if not 'external' in self.active_internal_scrapers and self.disabled_ext_ignored: self.active_internal_scrapers.append('external')
		self.active_external = 'external' in self.active_internal_scrapers
		if self.active_external:
			self.debrid_enabled = debrid.debrid_enabled()
			if not self.debrid_enabled:
				return self.disable_external('No Debrid Services Enabled' if all(scraper == 'external' for scraper in self.active_internal_scrapers) else 'EN used only')

	def get_sources(self):
		self.scrape_count += 1
		# LOCAL PATCH 2026-10-02: scrape.diag_timing also times the internal scrapers and the whole scrape (scrapers/external.py
		# times each external provider). Off by default; a hidden setting.
		self._diag_timing = get_setting('deadlight.scrape.diag_timing', 'false') == 'true'
		self._scrape_t0 = time.perf_counter()
		if not self.progress_dialog and not self.background: self._make_progress_dialog()
		self._mark('progress window')
		if self.progress_dialog: self._show_cinema_notice()   # LOCAL PATCH 2026-09-30
		self._mark('cinema notice')
		results = []
		if self.prescrape and any(x in self.active_internal_scrapers for x in self.default_internal_scrapers):
			if self.prepare_internal_scrapers():
				results = self.collect_prescrape_results()
				if results: results = self.process_results(results)
		if not results:
			self._mark('prescrape')
			self.prescrape = False
			self.prepare_internal_scrapers()
			self._mark('internal scrapers prepared')
			if self.active_external: self.activate_external_providers()
			elif not self.active_internal_scrapers: self._kill_progress_dialog()
			self._mark('external providers loaded')
			self.orig_results = self.collect_results()
			self._mark('all scrapers returned (%d sources)' % len(self.orig_results or []))
			if not self.orig_results and not self.active_external: self._kill_progress_dialog()
			results = self.process_results(self.orig_results)
		if self._diag_timing:
			kodi_utils.logger('scrape.timing', 'TOTAL: %dms to %d results (%d before filters)%s' % (int((time.perf_counter() - self._scrape_t0) * 1000),
				len(results) if isinstance(results, list) else 0, len(getattr(self, 'orig_results', None) or []), ' prescrape' if self.prescrape else ''))
		if not results: return self._process_post_results()
		if self.autoscrape: return results
		else: return self.play_source(results)

	def collect_results(self):
		# Fresh per run too: the retries reset self.threads but not this, so the last run's rows (AIOStreams', which dedup
		# lets through) came back doubled in 'Access Filtered Results' / the cache-check and IMDb-year retries.
		self.sources = list(self.prescrape_sources)
		# LOCAL PATCH 2026-10-15: built fresh per run. It was only ever extended, and the retry paths (cache-check
		# rescrape, 'Access Filtered Results') reset self.threads but not this -- so every internal scraper ran once
		# more per retry, and AIOStreams rows, which dedup lets through, came back doubled or tripled.
		self.providers = []
		threads_append = self.threads.append
		if self.active_folders: self.append_folder_scrapers(self.providers)
		self.providers.extend(self.internal_sources())
		self._mark('internal scrapers imported')
		if self.providers:
			for i in self.providers: threads_append(Thread(target=self.activate_providers, args=(i[0], i[1], False), name=i[2]))
			[i.start() for i in self.threads]
		join_deadline = self._scrape_deadline()
		self._mark('internal scrapers started')
		if self.active_external or self.background:
			if self.active_external:
				self.external_args = (self.meta, self.external_providers, self.debrid_enabled, self.external_cache_check, self.internal_scraper_names,
										self.prescrape_sources, self.progress_dialog, self.disabled_ext_ignored, self._window_countable, self.all_scrapers_retry)
				self.activate_providers('external', external, False)
			if self.background: self._join_by(self.threads, join_deadline)
		elif self.active_internal_scrapers: self.scrapers_dialog()
		return self.sources

	# LOCAL PATCH 2026-10-15: a background (next-episode) scrape waits for the internal scrapers only as long as the
	# foreground would -- results.timeout from their start, plus the 1.5 s external._background allows. The joins had no
	# timeout: http_streams' requests run 12 s and aiostreams' 10 s against this install's 4 s, so a slow HDHub made the
	# handoff (fired scraper_time + window_time before the end) late. A late thread still finishes, its rows unused.
	def _scrape_deadline(self):
		try: return time.time() + int(get_setting('deadlight.results.timeout', '20')) + 1.5
		except (TypeError, ValueError): return time.time() + 21.5

	@staticmethod
	def _join_by(threads, deadline):
		for t in threads: t.join(max(0.0, deadline - time.time()))
		late = [t.name for t in threads if t.is_alive()]
		if late: kodi_utils.logger('scrape.background', 'not waiting for %s (past results.timeout)' % ', '.join(late))

	def collect_prescrape_results(self):
		threads_append = self.prescrape_threads.append
		if self.active_folders:
			if settings.check_prescrape_sources('folders', self.media_type):
				self.append_folder_scrapers(self.prescrape_scrapers)
				self.remove_scrapers.append('folders')
		self.prescrape_scrapers.extend(self.internal_sources(True))
		if not self.prescrape_scrapers: return []
		for i in self.prescrape_scrapers: threads_append(Thread(target=self.activate_providers, args=(i[0], i[1], True), name=i[2]))
		[i.start() for i in self.prescrape_threads]
		join_deadline = self._scrape_deadline()
		self.remove_scrapers.extend(i[2] for i in self.prescrape_scrapers)
		if self.background: self._join_by(self.prescrape_threads, join_deadline)
		else: self.scrapers_dialog()
		return self.prescrape_sources

	def process_results(self, results):
		results = self.relabel_in_cinemas(results)
		self._mark('post: relabel')
		results = self.deduplicate_results(results)
		self._mark('post: dedupe (%d left)' % len(results or []))
		results = self.sort_results(results)
		self._mark('post: sort')
		min_seeders = settings.uncached_min_seeders()
		all_uncached_results = [i for i in results if 'Uncached' in i.get('cache_provider', '')]
		# LOCAL PATCH 2026-08-10 (Red Light 2.2.0 port): treat missing/None/non-numeric
		# seeders as 0. `i.get('seeders', '0')` only defaults when the KEY is absent —
		# providers that return an explicit `seeders: None` made int(None) raise
		# TypeError here, which killed the whole scrape and left the results window
		# stuck open with no sources.
		def _seeders(item):
			try: return int(item.get('seeders') or 0)
			except (TypeError, ValueError): return 0
		self.uncached_results = [i for i in all_uncached_results if _seeders(i) >= min_seeders]
		# LOCAL PATCH 2026-10-25 (4.0.5): was `not i in all_uncached_results` -- a dict-equality scan of that list per row
		# (quadratic). all_uncached_results is the same predicate over the same rows, so the complement is the predicate's.
		results = [i for i in results if not 'Uncached' in i.get('cache_provider', '')]
		if self.ignore_scrape_filters: self.filters_ignored = True
		else:
			results = self.filter_results(results)
			self._mark('post: filters (%d left)' % len(results or []))
			results = self.filter_audio(results)
			results = self.filter_banned_keywords(results)
			self._mark('post: audio + banned keywords')
			results = self.filter_not_the_film(results)
			for file_type in self.filter_keys: results = self.special_filter(results, file_type)
			self._mark('post: not-the-film + special filters')
		results = self.collapse_debrid_twins(results)
		self._mark('post: debrid twins (%d left)' % len(results or []))
		results = self.sort_preferred_filters(results)
		self._mark('post: preferred sort')
		results = self.demote_namesake(results)
		if self.prescrape:
			self.all_scrapers = self.active_internal_scrapers
			autoplay_results = [i for i in results if i['scrape_provider'] in self.active_internal_scrapers and settings.autoplay_prescrape(i['scrape_provider'])]
			if autoplay_results:
				self.autoplay = True
				results = autoplay_results
		else:
			self.all_scrapers = list(set(self.active_internal_scrapers + self.remove_scrapers))
			kodi_utils.clear_property('fs_filterless_search')
		results = self.sort_first(results)
		self._mark('post: sort first')
		if self.ignore_scrape_filters: return results
		results = self.limit_quality_numbers(results)
		results = self.limit_quality_total(results)
		self._mark('post: quality limits')
		return results

	def deduplicate_results(self, results):
		# LOCAL PATCH 2026-06-20: dedup keys include cache_provider so the SAME hash cached
		# on multiple debrids (e.g. Real-Debrid AND TorBox) yields one row per debrid in the
		# picker instead of only the first-arriving thread's entry winning. scrapers/external.py
		# emits one entry per (hash, debrid) — without this, the second debrid's rows were
		# silently swallowed by hash/url/size-quality dedup.
		seen_urls = set()
		seen_hashes = set()
		seen_size_quality = set()
		deduplicated = []
		for item in results:
			if item.get('scrape_provider') == 'aiostreams':
				deduplicated.append(item)
				continue
			url = (item.get('url_dl', '') or item.get('url', '') or '').strip()
			info_hash = (item.get('infoHash', '') or item.get('hash', '') or '').strip().lower()
			cache_provider = item.get('cache_provider', '')
			if url and (url, cache_provider) in seen_urls: continue
			if info_hash and (info_hash, cache_provider) in seen_hashes: continue
			# LOCAL PATCH 2026-10-15: the size twin must also be the same RELEASE (its name), and a row with no size is never
			# one. Sizes are 0.01 GB-rounded (torrentdownloads gives 0.1 GB), so 'X.WEB-DL.1080p' and 'X.BluRay.1080p' at
			# 4.50 GB collapsed into whichever thread answered first -- and this runs BEFORE the filters, so when the
			# survivor was then filtered out (RD's WEB-DL ban) both were gone. Every size-0 direct row collapsed into one.
			quality = item.get('quality', 'SD')
			size = item.get('size', 0)
			size_quality_key = (quality, size, cache_provider, re.sub(r'[^a-z0-9]', '', str(item.get('name') or '').lower())) if size else None
			if size_quality_key and size_quality_key in seen_size_quality: continue
			if url: seen_urls.add((url, cache_provider))
			if info_hash: seen_hashes.add((info_hash, cache_provider))
			if size_quality_key: seen_size_quality.add(size_quality_key)
			deduplicated.append(item)
		return deduplicated

	def collapse_debrid_twins(self, results):
		"""LOCAL PATCH 2026-10-11: one row per torrent when several debrids carry it. deduplicate_results keeps a row per
		(hash, debrid) on purpose -- the RD keyword ban must not take the TorBox copy with it -- so with TorBox and
		Real-Debrid both on, every torrent came twice (Project Hail Mary: 662 hashes -> 1315 rows), and every uncached one
		twice as well. Runs after the filters, so a twin a filter removed is never the one kept.
		Cached: the twin on the debrid highest in Provider Priority stays; the others go on it as 'debrid_fallbacks', tried
		in order by resolve_sources when it fails (RD's 'infringing_file' block, a dead cache entry). Uncached: dropped for
		a torrent that is cached anywhere, otherwise one row per torrent (the priority debrid's)."""
		try:
			def _hash(i): return (i.get('hash') or '').lower() if i.get('scrape_provider') == 'external' else ''
			best = {}
			for i in results:
				h = _hash(i)
				if not h: continue
				if h not in best or i.get('provider_rank', 99) < best[h].get('provider_rank', 99): best[h] = i
			out = []
			for i in results:
				h = _hash(i)
				if not h: out.append(i); continue
				keep = best[h]
				if i is keep: out.append(i); continue
				if i.get('cache_provider') and i['cache_provider'] != keep.get('cache_provider'):
					fallbacks = keep.setdefault('debrid_fallbacks', [])
					if i['cache_provider'] not in fallbacks: fallbacks.append(i['cache_provider'])
			for keep in best.values():
				if keep.get('debrid_fallbacks'):
					keep['debrid_fallbacks'].sort(key=lambda c: self._get_provider_rank(c.lower()))
			uncached, seen = [], set(best)
			for u in sorted(self.uncached_results or [], key=lambda u: self._get_provider_rank((u.get('debrid') or '').lower())):
				h = _hash(u)
				if h and h in seen: continue
				if h: seen.add(h)
				uncached.append(u)
			kodi_utils.logger_debug('debrid twins', '%d rows -> %d (%d with a fallback debrid); uncached %d -> %d' % (len(results), len(out),
				sum(1 for k in best.values() if k.get('debrid_fallbacks')), len(self.uncached_results or []), len(uncached)))
			if len(uncached) != len(self.uncached_results or []):
				# keep the uncached list's own order (seeders etc.), minus the twins
				kept_ids = set(id(u) for u in uncached)
				self.uncached_results = [u for u in self.uncached_results if id(u) in kept_ids]
			return out
		except Exception as e:
			kodi_utils.logger('debrid twins', 'collapse failed, rows left as they were: %r' % e)
			return results

	def sort_results(self, results):
		results = [dict(i, **{
			'provider_rank': self._get_provider_rank(i['debrid'].lower()), 'quality_rank': self._get_quality_rank(i.get('quality', 'SD')),
			'size_rank': self._get_size_rank(i)}) for i in results]
		# LOCAL PATCH 2026-10-25: Prefer Known Release Groups (modules/release_groups.py) -- the group weight goes in right
		# after the quality key, wherever the chosen Results Sorting puts quality, so a known group never jumps quality
		if settings.prefer_release_groups(self.autoplay):
			from modules.release_groups import release_group_boost
			# LOCAL PATCH 2026-10-25 (4.0.5): source_utils.release_group is lru_cached, so the repeat parses are free here and
			# in the picker -- one lookup order, kept in release_groups.release_group_boost.
			for i in results: i['group_boost'] = release_group_boost(i)
			# where quality sits in each Results Sorting (settings.results_sort_order): Q-P-S, Q-S-P, P-Q-S, P-S-Q, S-Q-P, S-P-Q
			try: _at = (1, 1, 2, 3, 2, 3)[int(get_setting('deadlight.results.sort_order', '1'))]
			except (TypeError, ValueError, IndexError): _at = 1
			_base = self.sort_function
			results.sort(key=lambda k: (lambda t: t[:_at] + (-k['group_boost'],) + t[_at:])(_base(k)))
			_known = [k for k in results if k['group_boost']]
			kodi_utils.logger_debug('release groups', '%d of %d result(s) from a known group lead their quality: %s' % (len(_known), len(results),
				', '.join(sorted(set('%s %s' % (k.get('quality'), k.get('release_group') or release_group(k.get('name') or '')) for k in _known[:40])))[:300]))
		else: results.sort(key=self.sort_function)
		results = self._sort_uncached_results(results)
		return results

	def filter_results(self, results):
		if self.folders_ignore_filters:
			# LOCAL PATCH 2026-10-25 (4.0.5): one-pass split (was `not i in folder_results`, quadratic)
			folder_results, _rest = [], []
			for i in results: (folder_results if i['scrape_provider'] == 'folders' else _rest).append(i)
			results = _rest
		else: folder_results = []
		_all = results
		results = [i for i in results if i['quality'] in self.quality_filter]
		if not results and 'SD' not in self.quality_filter: results = self._unknown_resolution_fallback(_all)   # LOCAL PATCH 2026-10-19
		if self.filter_size_method:
			min_size = string_to_float(get_setting('deadlight.results.%s_size_min' % self.media_type, '0'), '0') / 1000
			if min_size == 0.0 and not self.include_unknown_size: min_size = 0.02
			if self.filter_size_method == 1:
				duration = self.meta['duration'] or (5400 if self.media_type == 'movie' else 2400)
				max_size = ((0.125 * (0.90 * string_to_float(get_setting('results.line_speed', '25'), '25'))) * duration)/1000
			elif self.filter_size_method == 2:
				max_size = string_to_float(get_setting('deadlight.results.%s_size_max' % self.media_type, '10000'), '10000') / 1000
			results = [i for i in results if i['scrape_provider'] == 'folders' or min_size <= i['size'] <= max_size]
		results += folder_results
		return results

	def filter_audio(self, results):
		a_filters = settings.audio_filters()
		return [i for i in results if not any(x in i['extraInfo'] for x in a_filters)]

	# LOCAL PATCH 2026-06-20: Real Debrid filename-keyword filter. Drops sources whose raw
	# filename contains any of the comma-separated banned tokens (case-insensitive substring).
	# Matches on the 'name' field (raw scraper output), NOT display_name (cleaned for UI) or
	# extraInfo (BBCODE tags only). Setting ships pre-populated with RD's confirmed blocked
	# tokens (WEB-DL, AMZN, RARBG, [rarbg], etc. from the May 2026 FNEF/DSA filter rollout);
	# user can edit/clear the setting. Empty setting = filter disabled (no-op pass-through).
	#
	# Scope (refined 2026-06-23): only drops a row when ALL of the following hold —
	#   1) scrape_provider == 'external'  (i.e. magnet torrent path, not aiostreams/easynews/
	#      sootio/http_streams/cloud/folders — those bypass addMagnet entirely)
	#   2) cache_provider contains 'Real-Debrid'  (covers both 'Real-Debrid' cached entries
	#      AND 'Uncached Real-Debrid' rows — the only debrid running the FNEF filename ban)
	#   3) name contains one of the banned tokens
	# TorBox / Premiumize / AllDebrid have no filename ban — their cache_provider-tagged rows
	# pass through even when the filename has WEB-DL/AMZN/RARBG, so the user keeps full access
	# to those same magnets via the non-RD debrids (handy when the multi-debrid dedup fix has
	# placed twin rows for the same hash). Same hash, two cache_provider rows: RD row drops,
	# TB row stays.
	def filter_banned_keywords(self, results):
		raw = settings.banned_keywords_filter()
		if not raw: return results
		tokens = [t.strip().lower() for t in raw.split(',') if t.strip()]
		if not tokens: return results
		return [r for r in results
				if r.get('scrape_provider') != 'external'
				or 'Real-Debrid' not in (r.get('cache_provider') or '')
				or not any(tok in (r.get('name') or '').lower() for tok in tokens)]

	def _digital_release(self):
		"""LOCAL PATCH 2026-09-29: this movie's first digital / disc release date ('YYYY-MM-DD'), or ''. A meta cached
		before the field existed asks TMDb once per session -- only for a film out in the last 180 days (or not yet out),
		since an older one's refreshed meta carries it and its date has passed anyway. A failed ask counts as 'no date'
		for the session too (2026-09-30), so a TMDb outage costs one 3 s wait, not one per scrape."""
		if 'digital_release' in self.meta: return self.meta['digital_release'] or ''
		try:
			import datetime
			premiered = datetime.date(*[int(x) for x in self.meta['premiered'][:10].split('-')])
			if (datetime.date.today() - premiered).days > 180: return ''
		except Exception: return ''
		prop = 'deadlight.digital_release.%s' % self.meta.get('tmdb_id')
		cached = kodi_utils.get_property(prop)
		# LOCAL PATCH 2026-10-03 (Batch 3): a failed ask is 'fail:<epoch>' and is retried after an hour; 'none' (TMDb
		# answered, no date) stays for the session. A timeout used to be recorded as 'none' until Kodi restarted.
		if cached.startswith('fail:'):
			try:
				if time.time() - int(cached[5:]) < 3600: return ''
			except ValueError: pass
		elif cached: return '' if cached == 'none' else cached
		from apis.tmdb_api import movie_release_dates
		results = movie_release_dates(self.meta.get('tmdb_id'), settings.tmdb_api_key())
		if results is None:
			kodi_utils.set_property(prop, 'fail:%d' % int(time.time()))
			return ''
		date = metadata.digital_release_date(results) if results else ''
		kodi_utils.set_property(prop, date or 'none')
		return date

	def _cinema_date(self):
		"""LOCAL PATCH 2026-09-30: the movie's first digital / disc release date while it is still in the future, else ''.
		Worked out once per scrape: the loading window's notice, its counts and relabel_in_cinemas all read it."""
		value = getattr(self, '_cinema_date_value', None)
		if value is not None: return value
		value = ''
		if self.media_type == 'movie':
			try:
				import datetime
				date = self._digital_release()
				if date and date > datetime.date.today().isoformat(): value = date
			except Exception as e: kodi_utils.logger('in cinemas', 'skipped: %s' % e)
		self._cinema_date_value = value
		return value

	def _show_cinema_notice(self):
		"""LOCAL PATCH 2026-09-30: say so in the loading window, before the scrape, when a movie is still in cinemas --
		otherwise a list emptied by relabel_in_cinemas looks like the providers failing."""
		try:
			import datetime
			date = self._cinema_date()
			if not date or not self.progress_dialog: return
			day = datetime.date(*[int(x) for x in date.split('-')])
			when = '%d %s' % (day.day, day.strftime('%b'))
			if day.year != datetime.date.today().year: when = '%s %d' % (when, day.year)
			what = 'shown as cam rips' if 'CAM' in self.quality_filter else 'cam rips hidden'
			self.progress_dialog.set_notice('In cinemas  ·  digital release %s  ·  %s' % (when, what))
		except Exception: pass

	def relabel_in_cinemas(self, results):
		"""LOCAL PATCH 2026-09-29: before a movie's first digital / disc release no web or disc copy of it can exist, so
		every result is a cam, a fake or another film -- Spider-Man: Brand New Day (digital 2026-10-06) listed
		'D.WEBRip.1O8Op', 'WEBSCR.TRIAL' and bare '...2026.1080p.mkv' as 1080p / 4K. Each one becomes CAM, so the
		pre-release setting decides: Exclude hides them, Include lists them honestly marked."""
		if self.media_type != 'movie' or not results: return results
		date = self._cinema_date()
		if not date: return results
		n = 0
		for i in results:
			if i.get('quality') not in ('CAM', 'SCR', 'TELE'): i['quality'] = 'CAM'; n += 1
		if n: kodi_utils.logger('in cinemas', 'digital release %s: %d result(s) relabelled CAM' % (date, n))
		return results

	def _other_film(self, name):
		"""LOCAL PATCH 2026-09-29: True for a release that says it is another film ('NOT.The.Chris.Nolan.FILM'), or on a
		MOVIE one named as a prologue -- episodes are left alone, where 'Prologue' is a common episode title. A title
		that itself holds the word keeps its matches."""
		flags = getattr(self, '_other_film_flags', None)
		if flags is None:
			title = self.get_search_title() or ''
			flags = self._other_film_flags = (not _NOT_THE_FILM.search(title), self.media_type == 'movie' and not _PROLOGUE.search(title))
		name = name or ''
		return bool((flags[0] and _NOT_THE_FILM.search(name)) or (flags[1] and _PROLOGUE.search(name)))

	def demote_namesake(self, results):
		"""LOCAL PATCH 2026-10-25: a show whose title another show shares (source_utils.namesake_clash, read from the results:
		no request) -- a release carrying an episode title that is not ours goes to the end of the list, marked 'other
		show?' (its name is left as it is: SmartPlay and the filters read that). Avatar: The Last Airbender (2024) S02E03
		listed 23 copies of the 2005 show's 'Return to Omashu' among its 'City of Walls and Secrets'."""
		try:
			if self.media_type != 'episode' or not results: return results
			meta = self.meta if isinstance(getattr(self, 'meta', None), dict) else {}
			ep_title = meta.get('ep_name') or ''
			if not ep_title or not namesake_clash([r.get('name') for r in results], meta.get('title') or ''): return results
			kept, suspects = [], []
			for r in results:
				if episode_title_mismatch(r.get('name'), self.season, self.episode, ep_title, meta.get('year')): suspects.append(r)
				else: kept.append(r)
			if not suspects: return results
			for r in suspects:
				r['namesake_suspect'] = True
				r['display_name'] = '[COLOR FFE0AA46]other show?[/COLOR]  %s' % (r.get('display_name') or r.get('name') or '')
			kodi_utils.logger('namesake', '%s S%sE%s: %d release(s) carry another episode title, moved to the end' % (meta.get('title'), self.season, self.episode, len(suspects)))
			return kept + suspects
		except Exception: return results

	def filter_not_the_film(self, results):
		"""LOCAL PATCH 2026-09-29: drop what _other_film names. Every provider passes here, internal ones included."""
		kept = [r for r in results if not self._other_film(r.get('name'))]
		if len(kept) != len(results): kodi_utils.logger('not the film', 'dropped %d release(s)' % (len(results) - len(kept)))
		return kept

	def _window_countable(self, item):
		"""LOCAL PATCH 2026-09-30: why the results list will hide this release, or '' when it will show it -- the loading
		window counts only the ''s (source_utils.WindowCounter). The same tests the list applies: the quality filter,
		which holds CAM / SCR / TELE only when pre-releases are included, after the in-cinemas relabel; and _other_film.
		Size, audio and codec filters are not repeated here, so the count can still run a little high."""
		if self.ignore_scrape_filters: return ''
		quality = item.get('quality') or 'SD'
		if self._cinema_date() and quality not in ('CAM', 'SCR', 'TELE'): quality = 'CAM'
		if quality not in self.quality_filter: return 'cam' if quality in ('CAM', 'SCR', 'TELE') else 'quality'
		if self._other_film(item.get('name')): return 'other film'
		return ''

	def special_filter(self, results, file_type):
		enable_setting, key = settings.filter_status(file_type), self.filter_keys[file_type]
		if key == 'HEVC' and enable_setting == 0:
			hevc_max_quality = self._get_quality_rank(get_setting('deadlight.filter.hevc.%s' % ('max_autoplay_quality' if self.autoplay else 'max_quality'), '4K'))
			results = [i for i in results if not key in i['extraInfo'] or i['quality_rank'] >= hevc_max_quality]
		if enable_setting == 1:
			if key in ('D/VISION', 'HDR'):
				if not settings.filter_status({'D/VISION': 'hdr', 'HDR': 'dv'}[key]) == 0: results = [i for i in results if not key in i['extraInfo']]
				else: results = [i for i in results if not (key in i['extraInfo'] and not 'HYBRID' in i['extraInfo'])]
			else: results = [i for i in results if not key in i['extraInfo']]
		# LOCAL PATCH 2026-06-15: per-codec Sort to Top (port from POV 5.12). When the
		# filter setting is 2, bubble items whose extraInfo contains this codec/HDR
		# key to the top while preserving relative order within each group (stable).
		# Applies to HEVC/HDR/DV/AV1 — each codec's setting acts independently and
		# they stack: later filters in the special_filter loop will sort on top of
		# earlier ones, so the LAST processed codec ends up most-on-top.
		elif enable_setting == 2:
			priority = [i for i in results if key in i['extraInfo']]
			if priority and len(priority) != len(results):
				priority_ids = {id(i) for i in priority}
				remainder = [i for i in results if id(i) not in priority_ids]
				results = priority + remainder
		return results

	def sort_preferred_filters(self, results):
		if settings.sort_to_top_filter(self.autoplay):
			try:
				preferences = settings.preferred_filters()
				if not preferences: return results
				preferences = [self.filter_keys.get(i.lower(), i) for i in preferences]
				# LOCAL PATCH 2026-10-25 (4.0.5): one-pass split (was `not i in preference_results`, quadratic)
				preference_results, _rest = [], []
				for i in results: (preference_results if any(x in i['extraInfo'] for x in preferences) else _rest).append(i)
				if not preference_results: return results
				results = _rest
				preference_results = sorted([dict(item, **{'pref_includes': sum([{0:100, 1:50, 2:20, 3:10, 4:5, 5:2}[preferences.index(x)] \
					for x in [i for i in preferences if i in item['extraInfo']]])}) for item in preference_results], key=lambda k: k['pref_includes'], reverse=True)
				return preference_results + results
			except: pass
		return results

	def sort_first(self, results):
		try:
			sort_first_scrapers = []
			if 'folders' in self.all_scrapers and settings.sort_to_top('folders'): sort_first_scrapers.append('folders')
			sort_first_scrapers.extend([i for i in self.all_scrapers if i in ('rd_cloud', 'pm_cloud', 'ad_cloud', 'tb_cloud') and settings.sort_to_top(i)])
			if not sort_first_scrapers: return results
			sort_first = [i for i in results if i['scrape_provider'] in sort_first_scrapers]
			sort_first.sort(key=lambda k: (self._sort_folder_to_top(k['scrape_provider']), k['quality_rank']))
			sort_last = [i for i in results if not i['scrape_provider'] in sort_first_scrapers]   # LOCAL PATCH 2026-10-25 (4.0.5): was `not i in sort_first` (quadratic)
			results = sort_first + sort_last
		except: pass
		return results

	def limit_quality_numbers(self, results):
		if self.autoplay or self.ignore_scrape_filters: return results
		quality_limit = settings.limit_number_quality()
		if not quality_limit: return results
		quality_counter_dict, limit_list = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0, 'SCR': 0, 'CAM': 0, 'TELE': 0}, []
		for i in results:
			if quality_counter_dict[i['quality']] < quality_limit:
				quality_counter_dict[i['quality']] += 1
				limit_list.append(i)
		return limit_list

	def limit_quality_total(self, results):
		if self.autoplay or self.ignore_scrape_filters: return results
		total_limit = settings.limit_number_total()
		if not total_limit: return results
		return results[:total_limit]

	def prepare_internal_scrapers(self):
		if self.active_external and len(self.active_internal_scrapers) == 1: return
		active_internal_scrapers = [i for i in self.active_internal_scrapers if not i in self.remove_scrapers]
		if self.prescrape and not self.active_external and all([settings.check_prescrape_sources(i, self.media_type) for i in active_internal_scrapers]): return False
		if 'folders' in active_internal_scrapers:
			folder_info = self.get_folderscraper_info()
			self.folder_info = [i for i in folder_info if settings.source_folders_directory(self.media_type, i[1])]
			if self.folder_info:
				self.active_folders = True
				self.internal_scraper_names = [i for i in active_internal_scrapers if not i == 'folders'] + [i[0] for i in self.folder_info]
			else: self.internal_scraper_names = [i for i in active_internal_scrapers if not i == 'folders']
		else:
			self.folder_info = []
			self.internal_scraper_names = active_internal_scrapers[:]
		self.active_internal_scrapers = active_internal_scrapers
		if self.clear_properties: self._clear_properties()
		return True

	def _mark(self, label):
		"""LOCAL PATCH 2026-10-02: scrape.diag_timing checkpoint -- ms since get_sources began."""
		if getattr(self, '_diag_timing', False):
			kodi_utils.logger('scrape.timing', 'setup %s: +%dms' % (label, int((time.perf_counter() - self._scrape_t0) * 1000)))

	def activate_providers(self, module_type, function, prescrape):
		_t0 = time.perf_counter()
		_module = self._get_module(module_type, function)
		if module_type == 'external': self._mark('external scraper built')
		sources = _module.results(self.search_info)
		if getattr(self, '_diag_timing', False):
			_name = 'external (all)' if module_type == 'external' else getattr(function, '__module__', str(function)).rsplit('.', 1)[-1]
			kodi_utils.logger('scrape.timing', '%s: %dms (%d sources)%s' % (_name, int((time.perf_counter() - _t0) * 1000), len(sources or []),
				' prescrape' if prescrape else ''))
		if not sources: return
		if prescrape: self.prescrape_sources.extend(sources)
		else: self.sources.extend(sources)

	def activate_external_providers(self):
		self.external_providers = self.external_sources()
		if not self.external_providers: self.disable_external('No External Providers Enabled')

	def disable_external(self, line1=''):
		if line1: kodi_utils.notification(line1, 2000)
		try: self.active_internal_scrapers.remove('external')
		except: pass
		self.active_external, self.external_providers = False, []

	def internal_sources(self, prescrape=False):
		active_sources = [i for i in self.active_internal_scrapers if i in ['easynews', 'rd_cloud', 'pm_cloud', 'ad_cloud', 'tb_cloud', 'aiostreams', 'http_streams']]
		try: sourceDict = [('internal', manual_function_import('scrapers.%s' % i, 'source'), i) for i in active_sources \
												if not (prescrape and not settings.check_prescrape_sources(i, self.media_type))]
		except: sourceDict = []
		return sourceDict

	def external_sources(self):
		# LOCAL PATCH 2026-09-26: the torrent providers are bundled in resources/lib/magneto (POV-style)
		# instead of loaded from a chosen script.module.* addon; scrapers/external.py runs them as before.
		try:
			from magneto import sources as magneto_sources
			from modules.source_utils import is_anime_meta, anime_providers_to_run
			# LOCAL PATCH 2026-10-05: on anime the anime list alone decides, the providers' own switches do not count
			# (source_utils.ANIME_ALL_SKIPPED); scrapers/external.py applies the same list again per provider.
			if is_anime_meta(self.meta):
				sourceDict = magneto_sources(specified_folders=['torrents'], only=anime_providers_to_run(self.all_scrapers_retry))
			else: sourceDict = magneto_sources(specified_folders=['torrents'], ret_all=self.disabled_ext_ignored)
		except: sourceDict = []
		return sourceDict

	def folder_sources(self):
		def import_info():
			for item in self.folder_info:
				scraper_name = item[0]
				module = manual_function_import('scrapers.folders', 'source')
				yield ('folders', (module, (item[1], scraper_name, item[2])), scraper_name)
		# LOCAL PATCH 2026-08-31: an identical unguarded call sat above this try. It did the
		# full import work, threw the result away, and -- being outside the try -- raised
		# past the except that exists to catch exactly that failure.
		try: sourceDict = list(import_info())
		except: sourceDict = []
		return sourceDict

	def play_source(self, results):
		matched = self._sticky_match(results)
		# LOCAL PATCH 2026-10-08: on the next-episode handoff a pinned source is checked while the episode still plays. A dead
		# one is dropped and the match asked again, so another copy of the same release (Reacher S04E06: the RGzsRutracker
		# DV.HDR file after the 4KHDHub one) gets its turn; when none is left the picker follows the end of the episode.
		_dead_checked = 0
		while matched is not None and not self._precheck_pinned(matched):
			self._mark_dead(matched)
			_dead_checked += 1
			_prev, matched = matched, (self._sticky_match(results) if _dead_checked < 3 else None)
			if matched is _prev: matched = None   # no hash to rule it out with
		if matched is None and _dead_checked:
			from modules.kodi_utils import logger
			logger('SmartPlay', 'pinned source is down; picker after this episode')
			self.picker_notice = 'SmartPlay: saved source is down - pick another'
			return self.display_results(results)
		if matched is not None:
			# LOCAL PATCH 2026-09-27: the pin follows the episode. Only a user's pick in the results window
			# armed sticky_pending, so a pin SmartPlay kept matching never moved on -- Mushoku Tensei's stayed on
			# the S02E03 file through E04 and E05. player.playback_close_dialogs saves playing_item once Kodi
			# is really playing, so a failed play leaves the old pin as it was (_sticky_reset_play_state).
			self.sticky_pending = True
			self.play_file([matched], matched)
			if self.playback_successful: return
			# LOCAL PATCH 2026-07-02: read self.user_cancelled (genuine user Back / cancel),
			# not self.cancel_all_playback (which also fires on playback failure).
			user_cancelled = self.user_cancelled
			self._sticky_reset_play_state()
			if user_cancelled:
				from modules.kodi_utils import logger
				logger('SmartPlay', 'user cancelled sticky resolve; aborting (sticky preserved)')
				return
			from modules.kodi_utils import logger
			# LOCAL PATCH 2026-09-16: the picker now opens on EVERY path, background and autoplay
			# included. This reverses the 2026-09-07 narrowing, which dropped the failed source and
			# played the best of the rest so the show would not stop.
			#
			# The reasoning then was that autoplay_nextep_handler has already stopped the previous
			# episode, so a picker strands the user on a dialog. That cost is real and is accepted
			# deliberately: pinning a source is a statement about WHICH release to play, so when the
			# pinned one will not resolve, quietly playing a different one is the outcome pinning
			# exists to prevent. Being asked is better than being surprised.
			#
			# A MISS still plays on (the branch below). The two are not the same evidence: a miss
			# means the release was absent from THIS scrape, which is often transient -- BLACK TORCH
			# S01E08 missed against 10 results at 10:14:21 and matched at 10:16:31 -- whereas a
			# resolve failure means the release WAS here and would not play.
			#
			# No re-pin here any more. display_results arms sticky_pending when the user picks, so
			# whatever they choose becomes the new pin through the normal path, and the old pin
			# survives untouched if they back out.
			logger('SmartPlay', 'sticky-matched source failed; showing picker')
			self.picker_notice = 'SmartPlay: saved source failed - showing picker'
			return self.display_results(results)
		# LOCAL PATCH 2026-08-31: a sticky MISS opens the picker even when background/autoplay
		# would otherwise play results[0] silently. The next-episode handler passes
		# background='true' (episode_tools.next_episode_info), so without this the pinned
		# source merely being absent meant some other source played unannounced -- the
		# opposite of what pinning one is for. Deliberately narrow: needs SmartPlay on AND a
		# saved entry for this show AND a failed match. No sticky saved, SmartPlay off,
		# prescrape and in-dialog rescrape all keep plain upstream behaviour.
		if getattr(self, 'sticky_miss', False):
			# LOCAL PATCH 2026-09-20: a sticky MISS now opens the picker on every path, the same
			# way a sticky source that FAILS to resolve already does in the branch above. This
			# reverses the 2026-09-06 narrowing.
			# 
			# The 09-06 reasoning is recorded here because its cost is real and still applies: on
			# the background / autoplay path autoplay_nextep_handler has ALREADY stopped the
			# previous episode for the handoff, so a picker nobody is sitting in front of stops
			# the show instead of continuing it. It also argued a miss is weaker evidence than a
			# resolve failure -- the pinned release is often merely absent from one scrape and
			# present in the next, BLACK TORCH S01E08 missing against 10 results at 10:14:21 and
			# the same release matching at 10:16:31.
			# 
			# Both points stand; they are overridden deliberately. Pinning a source is a statement
			# about WHICH release to play, so substituting a different one unannounced is the
			# outcome pinning exists to prevent -- and that holds whether the pin was absent from
			# the scrape or present but unplayable. Being asked beats being surprised.
			# 
			# This leaves _prefer_pinned_group (added 09-07) with no callers. It is kept rather
			# than deleted: it encodes how to rank a pinned release group and is the thing to
			# reach for if this ever needs a non-interactive fallback (e.g. a picker that times
			# out on the unattended next-episode path).
			# LOCAL PATCH 2026-09-20: run the next-episode handoff BEFORE opening the picker.
			# The countdown alert lives inside play_file, reached via continue_resolve_check ->
			# autoplay_nextep_handler. Routing a miss to display_results instead of play_file
			# therefore skipped it, and the 'Next Up' prompt disappeared on exactly the episodes
			# SmartPlay could not pin — a regression introduced earlier today when the miss
			# stopped falling through to play_file.
			#
			# Same call and same abort play_file makes. continue_resolve_check returns True
			# immediately when not self.background, so the foreground picker is unaffected; on
			# 'play' it stops the current episode, which leaves _wait_out_playback below with
			# nothing to wait for. Deliberately NOT added to the failure branch above: play_file
			# has already run this check there, and a second call would prompt twice.
			# LOCAL PATCH 2026-10-08: not on the next-episode handoff any more. The countdown stopped the episode playing and
			# left a picker over a stopped show; display_results now holds the picker until the episode ends (or cuts the
			# credits) instead, and the picker is itself the question the countdown asked.
			if not self._nextep_autoplay():
				if not self.continue_resolve_check(): return self._kill_progress_dialog()
			self.picker_notice = 'SmartPlay: saved source not found - showing picker'
			return self.display_results(results)
		# LOCAL PATCH 2026-10-08: SmartPlay on, but this show has no pin yet. The handoff used to play the top result unasked;
		# now the user picks once, after this episode, and that pick becomes the pin every later episode follows.
		if getattr(self, 'sticky_no_pin', False) and self._nextep_autoplay():
			from modules.kodi_utils import logger
			logger('SmartPlay', 'no saved source for this show; picker after this episode')
			self.picker_notice = 'SmartPlay: no saved source yet - pick one, next episodes will follow it'
			return self.display_results(results)
		if self.background or self.autoplay: return self.play_file(results)
		return self.display_results(results)

	def _smartplay_enabled(self):
		return get_setting('deadlight.smartplay.enabled', 'false') == 'true'

	def _nextep_autoplay(self):
		"""LOCAL PATCH 2026-10-08: the automatic next-episode handoff (episode_tools sets play_type), not a play the user started."""
		return bool(self.background) and getattr(self, 'play_type', '') == 'autoplay_nextep'

	def _precheck_pinned(self, item):
		"""LOCAL PATCH 2026-10-08: resolve a pinned source and ask the link for one byte BEFORE the countdown stops the
		episode that is playing. Reacher S04E06 (17:02): the countdown stopped E05, then the 4KHDHub link answered 403 and the
		picker came up over a stopped show. Only on the next-episode handoff; False only when the link is known dead. The
		resolved URL rides on the item as '_preresolved' so play_file does not resolve it a second time."""
		if not self._nextep_autoplay(): return True
		from modules.kodi_utils import logger
		url = item.get('_preresolved') or self.resolve_sources(item)
		if not url:
			logger('SmartPlay precheck', 'did not resolve: %s' % (item.get('name') or '')[:80])
			return False
		verdict = _probe_stream(url)
		logger('SmartPlay precheck', '%s: %s' % ({True: 'ok', False: 'dead link', None: 'could not tell; playing'}[verdict], (item.get('name') or '')[:80]))
		if verdict is False: return False
		item['_preresolved'] = url
		return True

	def _mark_dead(self, item):
		try:
			if item.get('hash'): self._sticky_dead_hashes.add(str(item['hash']).lower())
		except Exception: pass

	def _sticky_load_all(self):
		try:
			raw = get_setting('deadlight.smartplay.state', '')
			if not raw or raw == 'empty_setting': return {}
			data = json.loads(raw)
			return data if isinstance(data, dict) else {}
		except: return {}

	def _sticky_save_all(self, data):
		try:
			from caches.settings_cache import set_setting
			set_setting('smartplay.state', json.dumps(data) if data else 'empty_setting')
		except: pass

	def _sticky_reset_play_state(self):
		self.sticky_pending = False   # LOCAL PATCH 2026-09-27: a follow armed for a play that failed must not save
		self.resolve_dialog_made = False
		self.progress_dialog, self.progress_thread = None, None
		self.playback_successful, self.cancel_all_playback, self.user_cancelled = None, False, False

	def _sticky_match(self, results):
		from modules.kodi_utils import logger
		import re
		# LOCAL PATCH 2026-08-31: this returns None for six different reasons and only ONE of
		# them -- a sticky entry exists for this show but nothing in the results matches it --
		# should change what play_source does. Flag that case specifically; every early
		# return below leaves it False so unrelated paths keep plain upstream behaviour.
		self.sticky_miss = False
		self.sticky_no_pin = False   # LOCAL PATCH 2026-10-08: SmartPlay asked, nothing pinned for this show (see play_source)
		if not self._smartplay_enabled(): return None
		# LOCAL PATCH 2026-08-31 (doc only): tested by KEY PRESENCE, not value -- passing
		# prescrape:'false' still disables SmartPlay. Right today by accident: every branch
		# of the rescrape menu (dialogs.py:784-889) and the autoscrape chain
		# (episode_tools.py:96) set the key and all of them SHOULD let the user choose.
		# The next caller to add it for an unrelated reason turns SmartPlay off unaware.
		if 'prescrape' in self.params: return None
		if self.scrape_count > 1:
			logger('SmartPlay', 'in-dialog rescrape detected; bypassing sticky match to let user pick')
			return None
		if not results: return None
		# LOCAL PATCH 2026-09-04: drop anything this attempt has already proved dead before
		# any tier looks at it, so the name tiers cannot re-offer it either.
		_dead = getattr(self, '_sticky_dead_hashes', None)
		if _dead:
			_before = len(results)
			results = [i for i in results if (i.get('hash') or '').lower() not in _dead]
			if len(results) != _before:
				logger('SmartPlay', 'skipping %d result(s) whose resolve already failed this attempt'
					% (_before - len(results),))
			if not results: return None
		state = self._sticky_load_all().get(str(self.tmdb_id))
		if not state:
			self.sticky_no_pin = True
			return None
		saved_hash = (state.get('hash') or '').lower()
		saved_name = state.get('last_name') or ''
		# LOCAL PATCH 2026-09-27: the same torrent as a SEASON pack recorded for another season cannot be the pick --
		# its file for this episode number is the other season's (see _sticky_pack_play: Tanya S2E2 replayed S1E2).
		# Same hash, or the same exact name, is that same torrent, so both tiers stand down; the same-release tiers
		# below still follow the pin to this season's release.
		_other_season_pack = False
		try:
			_pk = state.get('pack') or {}
			_other_season_pack = (self.media_type == 'episode' and _pk.get('package') == 'season'
				and _pk.get('season') is not None and int(_pk['season']) != int(self.season))
		except Exception: pass
		if _other_season_pack: logger('SmartPlay', 'pin is a season pack for another season; skipping its hash / exact-name match')
		if saved_hash and not _other_season_pack:
			for item in results:
				if (item.get('hash') or '').lower() == saved_hash:
					logger('SmartPlay hash match', '%s' % saved_hash[:12])
					return item
		if saved_name:
			lp = re.sub(r'\[[0-9A-Fa-f]{8,}\]', '', saved_name).strip()
			for item in results:
				rel = re.sub(r'\[[0-9A-Fa-f]{8,}\]', '', item.get('name', '') or '').strip()
				if rel == lp and not _other_season_pack:
					logger('SmartPlay name exact match', rel[:80])
					return item
			if self.media_type == 'episode':
				# LOCAL PATCH 2026-08-31: this fallback exists to follow a sticky source to the
				# NEXT episode -- same group, same quality, one number changed. It used to check
				# only that a candidate matched the saved name except for L characters at some
				# digit position, and never that those characters were the episode being asked
				# for; startswith/endswith do not constrain length either. With S01E05 sticky and
				# episode 6 requested it therefore matched S01E01 (whichever came first in the
				# scrape), S02E05, S01E0999, even a 2080p re-encode -- reported as "it just plays
				# the first episode it finds" whenever the exact sticky source was gone.
				#
				# Three guards now: the lengths must agree so it is a substitution rather than a
				# prefix, the substituted digits must BE the wanted episode, and the result is
				# confirmed with seas_ep_filter so no other digit in the name can stand in for
				# the episode number.
				ep_forms = []
				for _form in (str(self.episode or 0), str(self.episode or 0).zfill(2)):
					if _form not in ep_forms: ep_forms.append(_form)
				for ep in ep_forms:
					L = len(ep)
					digit_positions = [i for i in range(len(lp) - L + 1) if lp[i:i + L].isdigit()]
					if not digit_positions: continue
					for item in results:
						rel = re.sub(r'\[[0-9A-Fa-f]{8,}\]', '', item.get('name', '') or '').strip()
						if len(rel) != len(lp): continue
						for pos in digit_positions:
							if rel[pos:pos + L] != ep: continue
							if not (rel.startswith(lp[:pos]) and rel.endswith(lp[pos + L:])): continue
							try:
								if not seas_ep_filter(int(self.season), int(self.episode), rel): continue
							except Exception: continue
							logger('SmartPlay name position match', rel[:80])
							return item
				# LOCAL PATCH 2026-09-01: same-release tier. The position match above can only follow a
				# pin when ONE digit run changes, so it fails outright on names that embed the episode
				# TITLE: 'Naruto.S01E01.Enter.Naruto.Uzumaki...-iVy' against S01E02's '<other title>'
				# differ in LENGTH and every candidate is rejected before a digit is examined. That is
				# every AIOStreams pin, because that path has no torrent to re-index --
				# _sticky_aiostreams_play has to find a DIFFERENT stream for the next episode and knows
				# it only by name. Observed: 'unmatched in 10 results' for e=2 and e=3, while e=1
				# matched exactly because the pin WAS e=1.
				#
				# So follow the release's stable identity -- group, source family, quality -- and let
				# seas_ep_filter be the sole authority on WHICH episode. That gate is not optional:
				# 847bf62 exists because a loose matcher replayed the wrong episode, and every test
				# here is looser than the one it follows. No group in the pin (an underscore-separated
				# group, say) means no tier -- fall through to the picker rather than guess.
				pin_group = release_group(lp)
				# LOCAL PATCH 2026-09-03: say WHY the tier found nothing. It used to report only
				# 'unmatched in N results', which is indistinguishable between 'the tier never ran
				# because the pin had no parseable group' and 'it ran and every candidate failed on
				# one axis'. Both happened on Shield Hero within four minutes and the log could not
				# tell them apart. Same idea as nyaa's rejects={...} line, which is what made the
				# One Piece numbering bug findable.
				_t4 = {}
				if not pin_group:
					logger('sticky.tier4', 'skipped: no parseable group in pin %r' % lp[:70])
				if pin_group:
					pin_source = release_source(release_norm(lp))
					pin_quality = get_release_quality(lp.lower())
					pin_service = release_service(release_norm(lp))
					# LOCAL PATCH 2026-10-08: and its HDR format. 4KHDHub posts every episode twice, DV.HDR and plain
					# H.265, with the same group, service and quality, and this tier took the bigger file: Reacher S04E08's
					# plain copy (8.21 GB) beat the DV one (7.99 GB) the user had picked, and the pin moved onto it.
					pin_dr = release_dynamic_range(lp)
					# LOCAL PATCH 2026-09-27: a name 4KHDHub cut at 100 characters may have lost its group and even
					# its source ('...S02E07.The.Kidnapping.and.Confinement.of.Beast.Girls.1080p.CR.W'). Such a name
					# is silent on those two, so it is judged on what survived -- episode, quality and service --
					# and only when it names a service, or episode + quality alone would be far too loose.
					pin_cut, pin_group_lost = name_was_cut(lp), group_lost_to_cut(lp)
					same_release = []
					for item in results:
						rel = item.get('name', '') or ''
						if not rel:
							_t4['no_name'] = _t4.get('no_name', 0) + 1
							continue
						try:
							if not seas_ep_filter(int(self.season), int(self.episode), rel):
								_t4['episode'] = _t4.get('episode', 0) + 1
								continue
						except Exception:
							_t4['episode_error'] = _t4.get('episode_error', 0) + 1
							continue
						rel_cut = name_was_cut(rel)
						# LOCAL PATCH 2026-10-11: a group that still MATCHES is not lost. 4KHDHub cuts the release name at 100
						# characters and the scraper appends the site ('...Enemy.Appears.1080p. pixeldrain | 4KHDHub'), so
						# group_lost_to_cut is true while release_group reads '4khdhub' from that label -- the pin's own group.
						# Treated as unknown, the cut name could only pass on a service it had lost (Tojima S01E08, 22:22).
						rel_group_match = same_group(release_group(rel), pin_group, 1 if (rel_cut or pin_cut) else 3)
						group_unknown = bool(pin_service) and (pin_group_lost or group_lost_to_cut(rel)) and not rel_group_match
						if not group_unknown and not same_group(release_group(rel), pin_group, 1 if (rel_cut or pin_cut) else 3):
							_t4['group'] = _t4.get('group', 0) + 1
							continue
						# Normalised once: release_source and release_service both want it, and this was
						# running release_norm twice for every candidate.
						rel_norm = release_norm(rel)
						rel_source = release_source(rel_norm)
						source_unknown = bool(pin_service) and ((pin_cut and not pin_source) or (rel_cut and not rel_source))
						# LOCAL PATCH 2026-10-11: and either side silent once the group matched -- the PIN can be the cut name:
						# after E08 played, Tojima's pin was '...Enemy.Appears.1080p. pixeldrain | 4KHDHub' (no source, no
						# service), and E09's 4KHDHub copies saying 'CR.WEB-DL' were refused on source ('web' vs '').
						if rel_group_match and (not rel_source or not pin_source): source_unknown = True
						if rel_source != pin_source and not source_unknown:
							_t4['source'] = _t4.get('source', 0) + 1
							continue
						if get_release_quality(rel.lower()) != pin_quality:
							_t4['quality'] = _t4.get('quality', 0) + 1
							continue
						# A pin that names its service must stay on it. Only enforced when the PIN
						# carries a tag: an untagged pin has told us nothing to hold it to, and the
						# picker is a fine outcome when nothing qualifies.
						# LOCAL PATCH 2026-10-11: a name SILENT on the service is not a different service -- when its group
						# matched for real. 4KHDHub's titles carry it only when the episode title leaves room: Tojima S01E07
						# '...Let.Me.Join.Shocker.1080p.CR.WEB-DL.AAC2.0', S01E08 '...When.A.Dangerous.Enemy.Appears.1080p.
						# pixeldrain | 4KHDHub' -- same release, rejected on service, so SmartPlay left the pinned 4KHDHub copy
						# for a torrent. A name naming ANOTHER service is still refused, and one that says the pin's service
						# sorts ahead of a silent one (below).
						rel_service = release_service(rel_norm)
						if pin_service and rel_service != pin_service and (rel_service or group_unknown):
							_t4['service'] = _t4.get('service', 0) + 1
							continue
						# Both must say: a cut name silent on it ('') is not held against either side.
						rel_dr = release_dynamic_range(rel)
						if pin_dr and rel_dr and rel_dr != pin_dr:
							_t4['dynamic_range'] = _t4.get('dynamic_range', 0) + 1
							continue
						same_release.append(item)
					if not same_release:
						logger('sticky.tier4', 'no candidate matched pin group=%s source=%s quality=%s service=%s range=%s -- rejected on %s'
									% (pin_group, pin_source, pin_quality, pin_service or '-', pin_dr or '-', _t4 or '{}'))
					if same_release:
						# Largest first, as pick_episode_files does out of a pack: among identical
						# releases of one episode the biggest file is the real one, not a sample.
						# A candidate that SAYS the pin's format goes ahead of one that cannot say (LOCAL PATCH 2026-10-08).
						# LOCAL PATCH 2026-10-25 (4.0.5): a copy from the pin's own provider goes first. Size used to decide, so
						# a missed single-provider pin (HDHub answered 67 ms past the cap) lost to a larger TorBox pack of the same
						# release, and saving that play moved the pin off PixelDrain for every later episode (Avatar S2E4, 12:16).
						pin_provider = state.get('scrape_provider') or ''
						# Then the pin's host: 4KHDHub serves one file on FSL-V2 AND PixelDrain at the same size, so every other
						# key tied and result order chose (the FSL pin of S2E4, 12:40). Pins saved before 'hoster' existed: no effect.
						pin_hoster = (state.get('hoster') or '').lower()
						same_release.sort(key=lambda i: (bool(pin_provider) and i.get('scrape_provider') == pin_provider,
							bool(pin_hoster) and (i.get('hoster') or '').lower() == pin_hoster,
							bool(pin_dr) and release_dynamic_range(i.get('name', '')) == pin_dr,
							bool(pin_service) and release_service(release_norm(i.get('name', '') or '')) == pin_service, i.get('size') or 0), reverse=True)
						best = same_release[0]
						logger('SmartPlay same-release match', (best.get('name', '') or '')[:80])
						return best
		# Reached only when a sticky entry EXISTS and no tier matched it -- not hash, not exact
		# name, not position, not same-release. The saved source is genuinely absent here.
		self.sticky_miss = True
		logger('SmartPlay', 'sticky entry present but unmatched in %s results' % len(results))
		return None

	def _sticky_save(self, source):
		from modules.kodi_utils import logger
		if not self._smartplay_enabled(): return
		if not source or not self.tmdb_id: return
		try:
			entry = {
				'last_name': source.get('name', '') or '',
				'hash': (source.get('hash') or '').lower(),
				'scrape_provider': source.get('scrape_provider', ''),
				'hoster': source.get('hoster', ''),   # LOCAL PATCH 2026-10-25 (4.0.5): FSL-V2 / PixelDrain (Direct Streams), see _sticky_match
				'ts': int(time.time()),
			}
			pkg_raw = source.get('package', '')
			cache_provider = source.get('cache_provider', '')
			magnet_url = source.get('url') or source.get('url_dl') or ''
			scrape_provider = source.get('scrape_provider', '')
			if cache_provider in ('Real-Debrid', 'Premiumize.me', 'AllDebrid', 'TorBox') and magnet_url and entry['hash']:
				if pkg_raw in ('show', 'season'): pack_default = pkg_raw
				elif self.media_type != 'episode': pack_default = ''
				# LOCAL PATCH 2026-09-06: was unconditionally 'season' for every episode pin, which is
				# what made pack-play fail on every transition. See _SINGLE_FILE_NAME.
				elif _SINGLE_FILE_NAME.search(entry['last_name'] or ''): pack_default = 'episode'
				else: pack_default = 'season'
				entry['pack'] = {
					'type': 'debrid',
					'cache_provider': cache_provider,
					'url': magnet_url,
					'hash': entry['hash'],
					'name': entry['last_name'],
					'package': pack_default,
					# LOCAL PATCH 2026-09-06: which episode this pin actually holds, so a single-file
					# pin can still pack-play an instant REPLAY of the same episode while being
					# skipped for every other one.
					'season': getattr(self, 'season', None),
					'episode': getattr(self, 'episode', None),
					'quality': source.get('quality', 'SD'),
					'size': source.get('size', 0),
					'size_label': source.get('size_label', ''),
					'extraInfo': source.get('extraInfo', ''),
					'debrid': source.get('debrid', cache_provider),
					'scrape_provider': scrape_provider or 'external',
					'media_type': self.media_type,
				}
			elif scrape_provider == 'aiostreams':
				entry['pack'] = {
					'type': 'aiostreams',
					'name': entry['last_name'],
					'hash': entry['hash'],
					'media_type': self.media_type,
				}
			data = self._sticky_load_all()
			# LOCAL PATCH 2026-09-27: now that the pin follows each episode, it must not drift onto a name
			# 4KHDHub cut at 100 characters -- a pin reading '...H.264-D' prefix-matches any group starting
			# with D. When the new name was cut, the old one was not, and they are the same group, keep the
			# old name as the release's identity; hash, time and pack details still move on.
			try:
				prev_name = (data.get(str(self.tmdb_id)) or {}).get('last_name') or ''
				new_name = entry['last_name']
				same_kind = (get_release_quality(new_name.lower()) == get_release_quality(prev_name.lower())
					and release_service(release_norm(new_name)) == release_service(release_norm(prev_name)))
				if (prev_name and name_was_cut(new_name) and not name_was_cut(prev_name)
						and (same_group(release_group(new_name), release_group(prev_name), 1)
							or (group_lost_to_cut(new_name) and same_kind))):
					logger('SmartPlay save', 'new name was cut by 4KHDHub; keeping %s as the pinned name' % prev_name[:80])
					entry['last_name'] = prev_name
			except Exception: pass
			data[str(self.tmdb_id)] = entry
			if len(data) > 10:
				data = dict(sorted(data.items(), key=lambda kv: kv[1].get('ts', 0), reverse=True)[:10])
			self._sticky_save_all(data)
			logger('SmartPlay save', 'tmdb=%s pack=%s host=%s name=%s' % (self.tmdb_id, 'pack' in entry, entry['hoster'] or '-', entry['last_name'][:80]))
		except Exception as e: logger('SmartPlay save exception', str(e))

	def _sticky_touch(self):
		"""LOCAL PATCH 2026-09-07: refresh the pin timestamp after a successful pack-play.
		_sticky_save only runs when a source is chosen in the results window, and the pin
		store is a 10-entry LRU on ts -- so a show watched daily via pack-play never had its
		stamp touched, and ten picker choices on OTHER shows would silently evict the one
		pin that was working best. Touch only; nothing else about the pin changes."""
		try:
			data = self._sticky_load_all()
			entry = data.get(str(self.tmdb_id))
			if not entry: return
			entry['ts'] = int(time.time())
			self._sticky_save_all(data)
		except Exception: pass

	def _prefer_pinned_group(self, results):
		"""LOCAL PATCH 2026-09-07: soft group affinity for the best-match fallback.
		_sticky_match tier 4 demands group AND source AND quality AND service; on a miss the
		fallback then played results[0] blind. The 10:14 BLACK TORCH miss rejected five
		candidates on group alone -- their other axes matched -- so a same-group release at
		another quality was sitting right there. Stable partition: same-group items first,
		the rest after, each half keeping the scrape's own order. Not a new tier: it changes
		nothing about WHICH episode plays (seas_ep_filter still gates every item promoted),
		only which of the already-acceptable results is tried first."""
		try:
			state = self._sticky_load_all().get(str(self.tmdb_id)) or {}
			lp = re.sub(r'\[[0-9A-Fa-f]{8,}\]', '', state.get('last_name') or '').strip()
			pin_group = release_group(lp) if lp else None
			if not pin_group: return results
			same, rest = [], []
			for item in results:
				rel = item.get('name', '') or ''
				ok = False
				if rel and same_group(release_group(rel), pin_group, 1 if (name_was_cut(rel) or name_was_cut(lp)) else 3):
					if self.media_type == 'episode':
						try: ok = bool(seas_ep_filter(int(self.season), int(self.episode), rel))
						except Exception: ok = False
					else: ok = True
				(same if ok else rest).append(item)
			if same:
				from modules.kodi_utils import logger
				logger('SmartPlay', 'group affinity: %d of %d results share pin group %s; trying those first' % (len(same), len(results), pin_group))
				return same + rest
			return results
		except Exception:
			return results

	def _sticky_pack_play(self):
		if not self._smartplay_enabled(): return False
		# LOCAL PATCH 2026-08-31 (doc only): tested by KEY PRESENCE, not value -- passing
		# prescrape:'false' still disables SmartPlay. Right today by accident: every branch
		# of the rescrape menu (dialogs.py:784-889) and the autoscrape chain
		# (episode_tools.py:96) set the key and all of them SHOULD let the user choose.
		# The next caller to add it for an unrelated reason turns SmartPlay off unaware.
		if 'prescrape' in self.params: return False
		state = self._sticky_load_all().get(str(self.tmdb_id)) or {}
		pack = state.get('pack')
		# LOCAL PATCH 2026-09-27: a pin with no pack but a single DeadLight provider behind it
		# (Reacher, tmdb 108978, pinned to http_streams) used to wait out the FULL scrape --
		# every torrent provider plus the debrid cache check -- only for _sticky_match to pick
		# the one provider's row. Ask that provider alone first; on no match (or a failed play)
		# fall through to today's full scrape and its sticky-miss picker.
		if not pack:
			provider = state.get('scrape_provider') or ''
			if provider in _SINGLE_PROVIDER_PINS: return self._sticky_provider_play(provider)
			return False
		ptype = pack.get('type') or ('debrid' if pack.get('cache_provider') else '')
		# LOCAL PATCH 2026-09-27: aiostreams before the name tests below. Those ask whether a
		# pinned TORRENT can hold the wanted episode; an aiostreams pin has no torrent -- its path
		# scrapes the wanted episode fresh -- so a pin named S01E06 was skipped for E07, the very
		# case the same-release tier in _sticky_match exists for.
		if ptype == 'aiostreams': return self._sticky_provider_play('aiostreams')
		# LOCAL PATCH 2026-09-06 (revised): key this on the pin's own NAME, not on the stored
		# package label. The first version required package=='episode' plus a recorded
		# season/episode and so missed both real cases in kodi.log the same day:
		#   - tmdb 285993 was pinned BEFORE the patch, has neither field, and kept paying the
		#     futile resolve (12:33:15 -> 12:33:17 'resolve_cached returned None').
		#   - tmdb 260463 WAS saved by patched code, but its provider name carries no file
		#     extension ('...S01E22.1080p.CR.WEB-DL.AAC.2'), so it was still labelled 'season'.
		# A name saying SxxExx names ONE episode; if that is not the episode being asked for,
		# the torrent cannot hold it -- skip to the scrape and let _sticky_match's same-release
		# tiers follow the pin. A genuine pack ('...S01.1080p', no Exx) has no marker and is
		# untouched. Name-keyed, so it also heals pins saved before today with no re-save.
		# seas_ep_filter stays non-strict on purpose: a false positive only means we do NOT
		# skip, i.e. exactly today's behaviour.
		_pin_name = pack.get('name') or ''
		if self.media_type == 'episode' and _EPISODE_MARKER.search(_pin_name):
			try: _wanted = seas_ep_filter(int(self.season), int(self.episode), _pin_name)
			except Exception: _wanted = True
			if not _wanted:
				from modules.kodi_utils import logger
				logger('SmartPlay pack-play', 'pin names one episode (%s); skipping pack resolve for S%sE%s'
					% (_pin_name[:60], self.season, self.episode))
				return False
		# LOCAL PATCH 2026-09-07: the season-pack counterpart of the check above. A pin named
		# '...S01.2160p...' (tmdb 323557, Lion) IS a pack, so the Exx test rightly leaves it
		# alone -- but once S01 is finished and S02E01 is requested, pack-play would search the
		# S01 torrent for it: the same futile resolve, different shape. One Sxx token and no Exx
		# names one season; if that is not the season requested, skip. Multi-season packs
		# ('S01-S05', 'S01.S02') carry several tokens and are left alone, since any of them
		# might hold the episode. The recorded pack.season is preferred when the pin has it;
		# the name is the fallback for pins saved before it was recorded.
		if self.media_type == 'episode' and not _EPISODE_MARKER.search(_pin_name):
			_seasons = _season_tokens(_pin_name)
			if len(_seasons) == 1:
				try:
					_pin_season = pack.get('season')
					_pin_season = int(_pin_season) if _pin_season is not None else int(_seasons[0])
					if _pin_season != int(self.season):
						from modules.kodi_utils import logger
						logger('SmartPlay pack-play', 'pin is a season pack for S%02d (%s); skipping pack resolve for S%sE%s'
							% (_pin_season, _pin_name[:50], self.season, self.episode))
						return False
				except Exception: pass
			# LOCAL PATCH 2026-09-13: the anime absolute-numbering gap. Reached when the name
			# carries NO Exx and NO Sxx at all -- the fansub shape, 'Okusama.ga.Seitokaichou!.-.03.
			# [...].mkv'. Both tests above are keyed on the pin NAME, and neither can read that,
			# so pack-play went on to resolve the torrent for whatever episode was asked next.
			# That is the wrong-episode bug: the pin holds exactly episode 03 and nothing else.
			# The pin itself already knows. _sticky_save saw the name end '.mkv', so
			# _SINGLE_FILE_NAME matched and package was written 'episode', alongside the season
			# and episode it was pinned for. Those ints are written by our own code rather than
			# parsed out of a provider string, so once the name has told us nothing they are the
			# only trustworthy thing left -- this is the metadata test from the first 2026-09-06
			# version, restored as a FALLBACK rather than as the primary test, so the two cases
			# that made it fail then (no recorded fields; name with no extension) still take the
			# name path above and are unaffected.
			# elif, so a pin with one or more Sxx tokens keeps the season-pack behaviour above.
			elif not _seasons:
				try:
					_pin_pkg = pack.get('package') or ''
					_pin_s, _pin_e = pack.get('season'), pack.get('episode')
					# Both halves must be certain before skipping. package=='episode' means
					# _SINGLE_FILE_NAME matched at save time, i.e. the pin is ONE file, and both
					# ints must actually be recorded -- a pin saved before 2026-09-06 has neither
					# and must fall through rather than be guessed at. The errors here are
					# asymmetric: NOT skipping costs one futile ~1.5s resolve_cached and lands on
					# today's behaviour, while skipping wrongly loses a pack-play that would have
					# worked, so anything less than certain falls through.
					# LOCAL PATCH 2026-09-27: a SEASON pack whose name states no season at all. Saga of Tanya the Evil's
					# 'The.Saga.of.Tanya.the.Evil.(BD.RMX.1080p.FLAC).[Dual-Audio]' was pinned on S1E2 (package 'season',
					# season 1); asked for S2E2 it pack-played, and the pack's episode-2 file IS S1E2 -- the episode just
					# watched played again (19:16:13, 1421 s both times; 15:44 did the same for S2E10). Not skipping is
					# not the harmless outcome the note below assumes when the pack holds a DIFFERENT season: it plays
					# the wrong episode. The recorded season is our own TMDb-space int, so a filename's absolute number
					# cannot mislead it. A 'show' pack spans seasons and is left alone.
					if _pin_pkg == 'season' and _pin_s is not None and int(_pin_s) != int(self.season):
						from modules.kodi_utils import logger
						logger('SmartPlay pack-play', 'pin is a season pack recorded for S%02d (%s); skipping pack resolve for S%sE%s'
							% (int(_pin_s), _pin_name[:50], self.season, self.episode))
						return False
					if _pin_pkg == 'episode' and _pin_s is not None and _pin_e is not None:
						# Compare the PAIR, and compare it in TMDb space. Both sides were written
						# from self.season/self.episode -- the pin's copy at save time, ours now --
						# so the filename's absolute '03' never enters the comparison and cannot
						# mislead it. That is the whole reason this test works where the name tests
						# cannot. != rather than an unconditional skip keeps the instant REPLAY the
						# 2026-09-06 patch added: same episode asked for again still pack-plays.
						# int() both sides -- self.season/self.episode are strings on this path.
						if (int(_pin_s), int(_pin_e)) != (int(self.season), int(self.episode)):
							from modules.kodi_utils import logger
							logger('SmartPlay pack-play', 'pin is a single file holding S%02dE%02d (%s); skipping pack resolve for S%sE%s'
								% (int(_pin_s), int(_pin_e), _pin_name[:50], self.season, self.episode))
							return False
				# The except stays -- nothing here may raise into pack-play -- but it must not be
				# SILENT. int() is the realistic raiser: self.season/self.episode are strings on
				# this path and a pin could hold '' or a non-numeric from an older save. Swallowed
				# quietly, the skip simply never fires and the symptom is the wrong episode playing
				# with no line in the log saying why -- indistinguishable from the patch not being
				# installed at all. Falling through is still the right behaviour; only the silence
				# is wrong.
				except Exception as e:
					try:
						from modules.kodi_utils import logger
						logger('SmartPlay pack-play', 'single-file pin test failed (%s: %s); pin s=%r e=%r asked s=%r e=%r -- proceeding with pack resolve'
							% (type(e).__name__, e, pack.get('season'), pack.get('episode'), self.season, self.episode))
					except Exception: pass
		if ptype == 'debrid': return self._sticky_debrid_play(pack)
		return False

	def _sticky_debrid_play(self, pack):
		from modules.kodi_utils import logger
		cache_provider = pack.get('cache_provider', '')
		info_hash = pack.get('hash', '')
		magnet_url = pack.get('url', '')
		pack_type = pack.get('package', 'season')
		if not (cache_provider and info_hash and magnet_url): return False
		is_episode = self.media_type == 'episode'
		logger('SmartPlay pack-play[debrid]', 'cache=%s hash=%s media=%s s=%s e=%s' % (cache_provider, info_hash[:12], self.media_type, self.season, self.episode))
		try: title = self.meta.get('title', '') if isinstance(getattr(self, 'meta', None), dict) else ''
		except: title = ''
		try:
			kodi_utils.show_busy_dialog()
			if is_episode:
				# LOCAL PATCH 2026-08-27: this path is a pack by definition, so the anime
				# numbering alternatives matter here even more than on the normal resolve path.
				_cands = anime_episode_candidates(self.meta, (self.meta or {}).get('tmdb_id'), int(self.season), int(self.episode))
				url = self.resolve_cached(cache_provider, magnet_url, info_hash, title, int(self.season), int(self.episode), pack_type in ('show', 'season'), _cands)
			else:
				url = self.resolve_cached(cache_provider, magnet_url, info_hash, title, None, None, False)
		except Exception as e:
			logger('SmartPlay pack-play[debrid] resolve error', str(e))
			url = None
		finally:
			kodi_utils.hide_busy_dialog()
		if not url:
			# LOCAL PATCH 2026-09-04: remember that this hash did not resolve, so the fallback
			# scrape below does not hand it straight back. The pin is unchanged in state, so
			# _sticky_match's hash tier matched the very same torrent seconds later and played
			# it into the same failure -- observed on Chainsmoker Cat S01E09:
			#   09:07:59  pack-play[debrid] resolve_cached returned None
			#   09:08:02  SmartPlay hash match e24a8dcced8f      <- the hash that just failed
			#   09:08:04  sticky-matched source failed; showing picker
			# Instance-scoped on purpose: it is one playback attempt's verdict, not a lasting
			# judgement on the torrent, and playback_prep runs pack-play and the scrape on the
			# same Sources object. The pin itself is deliberately left alone.
			try:
				if info_hash: self._sticky_dead_hashes.add(str(info_hash).lower())
			except Exception: pass
			logger('SmartPlay pack-play[debrid]', 'resolve_cached returned None; falling back to scrape')
			return False
		source = {
			'name': pack.get('name', ''),
			'display_name': pack.get('name', ''),
			'quality': pack.get('quality', 'SD'),
			'size': pack.get('size', 0),
			'size_label': pack.get('size_label', '0.00 GB'),
			'extraInfo': pack.get('extraInfo', ''),
			'url': magnet_url,
			'url_dl': magnet_url,
			'id': info_hash,
			'hash': info_hash,
			'cache_provider': cache_provider,
			'debrid': pack.get('debrid', cache_provider),
			'scrape_provider': pack.get('scrape_provider', 'external'),
			'package': pack_type,
			'local': False,
			'direct': False,
		}
		# LOCAL PATCH 2026-10-08: resolve_cached above already gave the link -- check it before the countdown stops the
		# episode, and hand it to play_file so it is not resolved a second time
		# LOCAL PATCH 2026-10-25: on every pack-play, not only the autoplay handoff -- a play the user started resolved the
		# pack again in play_file: a second TorBox round (two CDN hosts per play), 2-3 s (log 2026-10-24 19:09:58, 22:10:34)
		source['_preresolved'] = url
		if not self._precheck_pinned(source):
			self._mark_dead(source)
			logger('SmartPlay pack-play[debrid]', 'pinned link is down; falling back to scrape')
			return False
		try: self.play_file([source], source)
		except Exception as e: logger('SmartPlay pack-play[debrid] play_file error', str(e))
		if self.playback_successful:
			self._sticky_touch()   # LOCAL PATCH 2026-09-07: keep a working pin from ageing out of the LRU
			return True
		# LOCAL PATCH 2026-07-02: check user_cancelled (set only on genuine user Back-press /
		# next-ep cancel), NOT cancel_all_playback (which also fires on playback failure —
		# exhaustion / monitor exception). Prior code treated any cancel_all_playback=True as
		# user-cancel, so a bad sticky source silently closed the picker instead of falling
		# through to a fresh scrape. Now: user-cancel → return True (preserve sticky, no
		# retry); playback failure → return False (fresh scrape → picker opens).
		if self.user_cancelled:
			logger('SmartPlay pack-play[debrid]', 'user cancelled; aborting (no fallback scrape)')
			self._sticky_reset_play_state()
			return True
		logger('SmartPlay pack-play[debrid]', 'play_file failed; falling back to scrape')
		self._sticky_reset_play_state()
		return False

	def _sticky_provider_play(self, provider):
		# LOCAL PATCH 2026-09-27: was _sticky_aiostreams_play; now any one internal provider
		# (_SINGLE_PROVIDER_PINS, plus aiostreams via its pack). Raw provider results, as the
		# aiostreams version always used: the pin was chosen from filtered results, and every
		# tier past the hash is gated on seas_ep_filter.
		from modules.kodi_utils import logger
		tag = 'SmartPlay pack-play[%s]' % provider
		if provider not in (self.active_internal_scrapers or []):
			logger(tag, 'provider not enabled; falling back to scrape')
			return False
		logger(tag, 'media=%s s=%s e=%s' % (self.media_type, self.season, self.episode))
		try:
			provider_source = manual_function_import('scrapers.%s' % provider, 'source')
			info = getattr(self, 'search_info', None) or {
				'media_type': self.media_type,
				'imdb_id': self.meta.get('imdb_id') if isinstance(getattr(self, 'meta', None), dict) else '',
				'title': self.meta.get('title', '') if isinstance(getattr(self, 'meta', None), dict) else '',
				'year': self.meta.get('year', '') if isinstance(getattr(self, 'meta', None), dict) else '',
				'season': self.season,
				'episode': self.episode,
				'aliases': self.meta.get('aliases', []) if isinstance(getattr(self, 'meta', None), dict) else [],
				'ep_name': self.meta.get('ep_name', '') if isinstance(getattr(self, 'meta', None), dict) else '',
			}
			# LOCAL PATCH 2026-09-27: say what SmartPlay is doing in the loading window instead of a bare busy spinner
			# (the next-episode handoff runs in the background and has no window, so it keeps the spinner)
			name = provider_panel_name(provider)
			self._smartplay_status('SmartPlay: looking for your pinned release on %s' % name)
			if not self.background:
				if not self.progress_dialog: self._make_progress_dialog()
				try: self.progress_dialog.update_scraper(0, 0, 0, 0, 0, '', 0, providers=[(provider, provider_panel_name(provider), 'running', 0)],
														phase='Checking Pinned Provider', detail=name)
				except Exception: pass
			else: kodi_utils.show_busy_dialog()
			# LOCAL PATCH 2026-10-24: capped at _PIN_SCRAPE_CAP; a late scrape is left to finish on its own thread
			box = []
			def _scrape():
				try: box.append(provider_source().results(info) or [])
				except Exception as e: logger(tag + ' scrape error', str(e))
			worker = Thread(target=_scrape, daemon=True)
			worker.start()
			worker.join(_PIN_SCRAPE_CAP)
			if worker.is_alive(): logger(tag, 'no answer in %d s' % _PIN_SCRAPE_CAP)
			results = box[0] if box else []
		except Exception as e:
			logger(tag + ' scrape error', str(e))
			results = []
		finally:
			kodi_utils.hide_busy_dialog()
		matched = self._sticky_match(results) if results else None
		if matched is None:
			logger(tag, ('no match in %d results; falling back to scrape' % len(results)) if results else 'no results; falling back to scrape')
			self._smartplay_status('SmartPlay: pinned release not found - searching all providers')
			return False
		# LOCAL PATCH 2026-10-08: a dead link is found out while the episode still plays; the full scrape then offers
		# the release's other copies (play_source checks those the same way)
		if not self._precheck_pinned(matched):
			self._mark_dead(matched)
			logger(tag, 'pinned link is down; falling back to scrape')
			return False
		self._smartplay_status('SmartPlay: playing your pinned release')
		self.sticky_pending = True   # LOCAL PATCH 2026-09-27: the pin follows the episode (see play_source)
		try: self.play_file([matched], matched)
		except Exception as e: logger(tag + ' play_file error', str(e))
		if self.playback_successful:
			self._sticky_touch()   # LOCAL PATCH 2026-09-07: keep a working pin from ageing out of the LRU
			return True
		# LOCAL PATCH 2026-07-02: see _sticky_debrid_play — check user_cancelled, not
		# cancel_all_playback.
		if self.user_cancelled:
			logger(tag, 'user cancelled; aborting (no fallback scrape)')
			self._sticky_reset_play_state()
			return True
		# LOCAL PATCH 2026-09-27: same as _sticky_debrid_play -- without this the fallback scrape's
		# hash tier matched the stream that had just failed and played it into the same failure.
		try:
			if matched.get('hash'): self._sticky_dead_hashes.add(str(matched['hash']).lower())
		except Exception: pass
		logger(tag, 'play_file failed; falling back to scrape')
		self._sticky_reset_play_state()
		return False

	def append_folder_scrapers(self, current_list):
		current_list.extend(self.folder_sources())

	def get_folderscraper_info(self):
		folder_info = [(get_setting('deadlight.%s.display_name' % i), i, settings.source_folders_directory(self.media_type, i))
						for i in ('folder1', 'folder2', 'folder3', 'folder4', 'folder5')]
		return [i for i in folder_info if not i[0] in (None, 'None', '') and i[2]]

	def scrapers_dialog(self):
		def _scraperDialog():
			monitor = kodi_utils.kodi_monitor()
			start_time = time.time()
			while not self.progress_dialog.iscanceled() and not monitor.abortRequested():
				try:
					remaining_providers = [x.getName() for x in _threads if x.is_alive() is True]
					self._process_internal_results()
					current_progress = max((time.time() - start_time), 0)
					percent = int((current_progress/float(25))*100)
					# LOCAL PATCH 2026-09-27: one row per provider; the bar shows providers done, the timer still ends it
					counts = getattr(self, 'provider_counts', {})
					rows = [(x.getName(), provider_panel_name(x.getName()),
							'running' if x.is_alive() else ('done' if counts.get(x.getName()) else 'none'), counts.get(x.getName(), 0)) for x in _threads]
					done = len([r for r in rows if r[2] != 'running'])
					left = max(0, int(round(25 - current_progress)))
					shown = percent if len(rows) <= 1 else 100.0 * done / len(rows)
					self.progress_dialog.update_scraper(self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total, '', shown,
						providers=rows, phase='Searching Providers', detail='%d of %d done  ·  %ds left' % (done, len(rows), left),
						time_pct=None if len(rows) <= 1 else percent, late=left <= 3,
						hidden=self.window_counter.line() if hasattr(self, 'window_counter') else '')
					kodi_utils.sleep(self.sleep_time)
					if len(remaining_providers) == 0: break
					if percent >= 100: break
				except:	return self._kill_progress_dialog()
		if self.prescrape: scraper_list, _threads = self.prescrape_scrapers, self.prescrape_threads
		else: scraper_list, _threads = self.providers, self.threads
		self.internal_scrapers = self._get_active_scraper_names(scraper_list)
		if not self.internal_scrapers: return
		_scraperDialog()

	# LOCAL PATCH 2026-09-02: never draw the picker over a still-playing episode when the
	# scrape was the AUTOMATIC next-episode handoff.
	#
	# The next-ep alert fires at outro_start -- measured on Lanterns S01E02:
	# 'source=introdb_outro_start window_time=123s (4.0% before end of 3093s)' -- so the
	# scrape runs while the credits are still rolling. When SmartPlay could not chain, the
	# picker appeared over those last two minutes. Observed: picker at 19:20:10 against
	# CVideoPlayer::CloseFile() at 19:20:49, 38 seconds later.
	#
	# autoscrape_nextep_handler already waits (`while player.isPlayingVideo()`), and so does
	# random_continual_handler; the autoplay path never got it. Putting the wait in
	# display_results covers every route into the picker for that flow, including a rescrape
	# from _process_post_results, and is idempotent where the caller already waited.
	#
	# Gated on play_type, NOT on autoplay_nextep: that flag is simply the
	# autoplay_next_episode SETTING for an ordinary manual play (log shows
	# 'background=False autoplay_nextep=True' on hand-started scrapes), so keying off it
	# would also delay a picker the user opened mid-episode on purpose -- the usual reason
	# being a stalling stream they want to replace NOW. play_type is set only by
	# episode_tools' next-episode handoff and is '' for anything the user started.
	_NEXTEP_PLAY_TYPES = ('autoplay_nextep', 'autoscrape_nextep')

	# LOCAL PATCH 2026-10-15: SmartPlay missed, so the next episode needs a source picked. Nothing is cut any more: at the
	# credits (window_time before the end, as autoplay_nextep_handler) the Up Next card opens as a Choose Source card --
	#   Choose Source   -> True now: the list opens OVER the playing episode (picking starts the next one; closing it
	#                      leaves you in the episode)
	#   Watch Credits / no answer -> the episode plays to its real end, preview / post-credits scene included, then True
	#   Stop After This / Back    -> False: no list
	# Replaces the 2026-09-03 rule that stopped the episode at the credits and opened the list (Tojima E21 / E22,
	# 2026-10-15: the ED and anything after it lost). Answers False too when the episode was CUT SHORT while we waited
	# (the user's Stop, a dead stream) -- _finished_naturally, the handler's own test.
	def _wait_out_playback(self):
		if getattr(self, 'play_type', '') not in self._NEXTEP_PLAY_TYPES: return True
		last = [None]
		def _remaining(player):
			try: last[0] = player.getTotalTime() - player.getTime()
			except Exception: pass
			return last[0]
		try:
			player = kodi_utils.kodi_player()
			if not player.isPlayingVideo(): return True
			_ns = getattr(self, 'nextep_settings', None) or {}
			_window = _ns.get('window_time') or 0
			while player.isPlayingVideo():
				_left = _remaining(player)
				if _left is None or round(_left) <= _window: break
				kodi_utils.sleep(500)
			if not player.isPlayingVideo(): return self._finished_naturally(last[0])
			# LOCAL PATCH 2026-10-15 (later): the card counts the ALERT time (autoplay_alert_countdown_sec), as the Up Next
			# card does, and no answer is 'stop' -- the episode is stopped and the list opens (user's call). Only where what
			# is left is credits: with content after the outro, or a percentage-guessed point, it still counts to the real
			# end ('to_end', _make_nextep_dialog), and 'stop' then lands at the end itself.
			_counts_to_end = _ns.get('timing_confidence') == 'low' or bool(_ns.get('content_after'))
			if _ns.get('use_window', True):
				kodi_utils.logger_debug('DialogFlash display_results', 'no auto-play; Choose Source card (source=%s)' % _ns.get('transition_source'))
				action = self._make_nextep_dialog(default_action='stop', choose=True)
			else:
				_early = getattr(self, 'picker_notice', None) or 'Next up'
				kodi_utils.notification('%s - choose a source when this episode ends' % _early.split(' - ')[0], 8000)
				action = 'close'
			kodi_utils.logger_debug('DialogFlash display_results', 'Choose Source card answered %r' % action)
			if action == 'play': return True
			if action == 'cancel': return False
			if action == 'stop':
				if player.isPlayingVideo():
					kodi_utils.logger_debug('DialogFlash display_results', 'Choose Source card: no answer -- stopping the episode, opening the list')
					try:
						mark_internal_stop()   # ours, not the user's -- see onPlayBackStopped
						player.stop()
					except Exception: pass
					while player.isPlayingVideo(): kodi_utils.sleep(100)
					return True
				# over before the countdown ran out: the real end on a card counting to it, else cut short (a dead stream)
				return True if _counts_to_end else self._finished_naturally(last[0])
			# The card answers 'cancel' itself on the user's Stop, so a card still open at a natural end comes back 'close'
			# with the episode over -- 'last' is then from when it opened, not the end; no position test for that.
			if not player.isPlayingVideo(): return True
			_remaining(player)
			while player.isPlayingVideo():
				_remaining(player)
				kodi_utils.sleep(250)
			return self._finished_naturally(last[0])
		except Exception: return True

	def _finished_naturally(self, last_remaining):
		if last_remaining is not None and last_remaining > NEXTEP_END_TOLERANCE:
			stopped = True
			# LOCAL PATCH 2026-10-15: a STREAM that died is not the user's Stop -- say so, or the chain just seems to hang.
			# onPlayBackStopped lands ~2.5 s after the player flips, so give it 3 s before deciding it was not the user.
			for _i in range(12):
				if kodi_utils.get_property(PLAYBACK_STOPPED_PROP) == 'true': break
				kodi_utils.sleep(250)
			else: kodi_utils.notification('Playback ended early - next episode not started', 6000)
		else:
			kodi_utils.sleep(600)   # onPlayBackStopped lands ~2.5 s after the player flips; the position test usually decides first
			stopped = kodi_utils.get_property(PLAYBACK_STOPPED_PROP) == 'true'
		if stopped: kodi_utils.logger_debug('DialogFlash display_results', 'episode cut short (last %s s from the end) -- no picker' % (None if last_remaining is None else int(last_remaining)))
		return not stopped

	def display_results(self, results):
		if not self._wait_out_playback(): return self._kill_progress_dialog()
		# LOCAL PATCH 2026-09-20: fire the SmartPlay notice HERE rather than where the miss
		# or failure was detected. _wait_out_playback above blocks until the current episode
		# finishes, so on the autoplay path the picker opens long after the decision was made:
		# measured at 67s on 2026-09-20, miss logged 14:53:04 and sources_results.xml loaded at
		# 14:54:11. The 3s toast had timed out well before then, so the picker arrived with
		# nothing on screen explaining why SmartPlay had not just played the pinned source.
		#
		# Foreground is unaffected: nothing is playing, _wait_out_playback returns at once and
		# the toast still appears immediately. Set by play_source only, so every other caller
		# of display_results is untouched.
		_notice = getattr(self, 'picker_notice', None)
		if _notice:
			self.picker_notice = None
			kodi_utils.notification(_notice, 3000)
		window_format, window_number = settings.results_format()
		action, chosen_item = open_window(('windows.sources', 'SourcesResults'), 'sources_results.xml',
				window_format=window_format, window_id=window_number, results=results, meta=self.meta, episode_group_label=self.episode_group_label,
				scraper_settings=self.scraper_settings, prescrape=self.prescrape, filters_ignored=self.filters_ignored,
				uncached_results=self.uncached_results, external_cache_check=self.external_cache_check)
		if not action: self._kill_progress_dialog()
		elif action == 'play':
			# LOCAL PATCH 2026-09-15: ARM the pin here, do not write it. This used to call
			# _sticky_save(chosen_item) before play_file had tried anything, so a source that
			# never played was pinned anyway and SmartPlay then reached for that dead release on
			# every following episode -- the pin had to be cleared by hand to escape it.
			#
			# Two things were wrong, not one. play_file does not only try the chosen source: it
			# builds [source] + items_next + items_prev and falls through on failure, so when the
			# pick failed and a LATER source played, the pin recorded the one that did not work.
			# player.playback_close_dialogs writes it instead, at the moment playback is actually
			# confirmed, and pins self.playing_item -- whatever is really on screen.
			self.sticky_pending = True
			# LOCAL PATCH 2026-09-03: the user has just chosen this source by hand, so the
			# next-episode countdown must not then ask whether to play it. See
			# continue_resolve_check.
			self.chosen_by_user = True
			return self.play_file(results, chosen_item)
		elif self.prescrape and action == 'perform_full_search':
			self.prescrape, self.clear_properties = False, False
			return self.get_sources()
		elif action == 'cache_change_rescrape':
			self.external_cache_check = chosen_item == 'true'
			self.sources, self.orig_results, self.threads = [], [], []
			self.prescrape, self.clear_properties = False, False
			return self.get_sources()

	def _get_active_scraper_names(self, scraper_list):
		return [i[2] for i in scraper_list]

	def _tb_down_only(self):
		"""LOCAL PATCH 2026-10-25 (4.0.6): TorBox is the only debrid and is stalling (torbox_api.not_answering)."""
		try:
			if list(self.debrid_enabled or []) != ['TorBox']: return False
			from apis.torbox_api import not_answering
			return bool(not_answering())
		except Exception: return False

	def _process_post_results(self):
		# LOCAL PATCH 2026-10-25 (4.0.6): while TorBox is the reason, no retry that scrapes torrents again against the same dead
		# service -- only 'Access Filtered Results', whose rows can be Direct Streams -- and the no-results dialog says why
		if self._tb_down_only():
			self.retry_actions = [a for a in self.retry_actions if a[0] == 'ignore_filters']
			self._no_results_reason = 'TorBox is not answering, so no torrent can play. Try again in a minute.'
		if not self.retry_actions: return self._no_results(getattr(self, '_no_results_reason', None))
		next_action, next_setting, order = self.retry_actions.pop(0)
		if next_action == 'cache_ignored':
			if next_setting in (1, 2) and self.active_external and self.orig_results and self.external_cache_check \
																				and debrid.debrid_for_ext_cache_check(self.debrid_enabled):
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With Cache Check Disabled?'):
					self.threads, self.prescrape, self.external_cache_check = [], False, False
					return self.get_sources()
			return self._process_post_results()
		if next_action == 'imdb_year':
			if next_setting in (1, 2) and self.active_external and not self.orig_results and not self.meta.get('custom_year'):
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With IMDb Year Data?'):
					from apis.imdb_api import imdb_year_check
					imdb_year = str(imdb_year_check(self.meta.get('imdb_id')))
					if imdb_year != self.get_search_year():
						self.meta['custom_year'] = imdb_year
						self.make_search_info()
						self.threads, self.prescrape = [], False
						return self.get_sources()
			return self._process_post_results()
		if next_action == 'with_all':
			if next_setting in (1, 2) and self.active_external:
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With All Scrapers?'):
					self.threads, self.disabled_ext_ignored, self.prescrape, self.all_scrapers_retry = [], True, False, True
					return self.get_sources()
			return self._process_post_results()
		if next_action == 'episode_group':
			if next_setting in (1, 2) and self.media_type == 'episode':
				if next_setting == 1 \
											or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With Custom Episode Group if Possible?'):
					if self.episode_group_used:
						self.params.update({'custom_season': None, 'custom_episode': None, 'episode_group_label': '[B]CUSTOM GROUP: S%02dE%02d[/B]' % (self.season, self.episode),
											'skip_episode_group_check': True})
						self.threads, self.disabled_ext_ignored, self.prescrape = [], True, False
						return self.playback_prep()
					if next_setting == 2:
						from indexers.dialogs import episode_groups_choice
						try: group_id = episode_groups_choice({'meta': self.meta, 'poster': self.meta['poster']})
						except: group_id = None
					else:
						try: group_id = metadata.episode_groups(self.tmdb_id)[0]['id']
						except: group_id = None
					if group_id:
						try: group_details = metadata.group_episode_data(metadata.group_details(group_id), None, self.season, self.episode)
						except: group_details = None
						if group_details:
							season, episode = group_details['season'], group_details['episode']
							self.params.update({'custom_season': season, 'custom_episode': episode, 'episode_group_label': '[B]CUSTOM GROUP: S%02dE%02d[/B]' % (season, episode)})
							self.threads, self.disabled_ext_ignored, self.prescrape = [], True, False
							return self.playback_prep()
			return self._process_post_results()
		if next_action == 'ignore_filters':
			if next_setting in (1, 2) and self.orig_results and not self.background:
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results. Access Filtered Results?'):
					if self.autoplay: kodi_utils.notification('Filters Ignored & Autoplay Disabled')
					self.threads, self.ignore_scrape_filters, self.disabled_ext_ignored, self.autoplay = [], True, True, False
					return self.get_sources()
			return self._process_post_results()

	def _no_results(self, reason=None):
		self._kill_progress_dialog()
		try: kodi_utils.hide_busy_dialog()
		except: pass
		if self.background: return kodi_utils.notification('[B]Next Up:[/B] %s' % ('TorBox is not answering' if reason else 'No Results'), 5000)
		title = self.meta.get('title') or self.meta.get('rootname') or ''
		text = 'No sources found' + ((' for [B]%s[/B]' % title) if title else '')
		if reason: text = '%s[CR]%s' % (text, reason)   # LOCAL PATCH 2026-10-25 (4.0.6)
		try: kodi_utils.ok_dialog(heading='No Results', text=text)
		except: kodi_utils.notification('No Results', 3000)

	def get_search_title(self):
		search_title = self.meta.get('custom_title', None) or self.meta.get('english_title') or self.meta.get('title')
		return search_title

	def get_search_year(self):
		year = self.meta.get('custom_year', None) or self.meta.get('year')
		return year

	def get_season(self):
		season = self.meta.get('custom_season', None) or self.meta.get('season')
		try: season = int(season)
		except: season = None
		return season

	def get_episode(self):
		episode = self.meta.get('custom_episode', None) or self.meta.get('episode')
		try: episode = int(episode)
		except: episode = None
		return episode

	def get_ep_name(self):
		ep_name = None
		if self.meta['media_type'] == 'episode':
			ep_name = self.meta.get('ep_name')
			try: ep_name = safe_string(remove_accents(ep_name))
			except: ep_name = safe_string(ep_name)
		return ep_name

	def _process_internal_results(self):
		for i in self.internal_scrapers:
			win_property = kodi_utils.get_property('deadlight.internal_results.%s' % i)
			if win_property in ('checked', '', None): continue
			try: sources = json.loads(win_property)
			except: continue
			kodi_utils.set_property('deadlight.internal_results.%s' % i, 'checked')
			self._sources_quality_count(sources)
			if not hasattr(self, 'provider_counts'): self.provider_counts = {}
			self.provider_counts[i] = len(sources)   # LOCAL PATCH 2026-09-27: per-provider rows
	
	def _sources_quality_count(self, sources):
		# LOCAL PATCH 2026-09-30: each release once, and only what the list will show (source_utils.WindowCounter)
		if not hasattr(self, 'window_counter'): self.window_counter = WindowCounter(self._window_countable)
		sources = self.window_counter.keep(sources)
		for item in self.count_tuple: setattr(self, item[0], getattr(self, item[0]) + item[2](sources, item[1]))

	# LOCAL PATCH 2026-10-19 (SD-tag option B, user's call): a file whose resolution NOTHING states -- no token in its
	# name, the scraper's 'unknown' -- is labelled SD by default and so dropped by a 4K / 1080p quality filter, even when it
	# is the only copy (JoJo S0E6 / E7, Kishibe Rohan: Comet 'unknown', TorBox listing names). Only when the quality filter
	# would leave NOTHING, such rows are kept and shown as UNKNOWN ('quality_unknown'; still 'SD' for sorting). For an
	# episode the file name must also carry the show's name or the episode's title: hash d3ce79f039, the 2000 Stardust
	# Crusaders OVA that Comet relabelled 'S00E07.mkv', names neither.
	_STATED_LOW = re.compile(r'(?<![0-9])(?:480|576|360|240)[pi]?(?![0-9])|\bsd\b|dvd|vhs', re.I)

	def _unknown_resolution_fallback(self, results):
		def _norm(text): return re.sub(r'[^a-z0-9]', '', str(text or '').lower())
		names = []
		if self.media_type == 'episode':
			meta = getattr(self, 'meta', None) or {}
			for key in ('title', 'original_title', 'english_title', 'ep_name'):
				if _norm(meta.get(key)): names.append(_norm(meta.get(key)))
			for alias in (meta.get('alternative_titles') or [])[:20]:
				if len(_norm(alias)) >= 4: names.append(_norm(alias))
		kept = []
		for item in results:
			if item.get('quality', 'SD') != 'SD': continue
			text = ' '.join(str(item.get(k) or '') for k in ('name', 'display_name'))
			if get_release_quality(text.lower()) or self._STATED_LOW.search(text): continue   # a resolution IS stated
			if names and not any(n in _norm(text) for n in names): continue
			item['quality_unknown'] = True
			kept.append(item)
		if kept: kodi_utils.logger('###quality.unknown###', '%d row(s) kept with no stated resolution (the quality filter left none)' % len(kept))
		return kept

	def _quality_filter(self):
		setting = 'results_quality_%s' % self.media_type if not self.autoplay else 'autoplay_quality_%s' % self.media_type
		filter_list = settings.quality_filter(setting)
		# LOCAL PATCH 2026-09-30: Include means include. Upstream added CAM / SCR / TELE only when SD was allowed too, so
		# with the quality setting at '4K, 1080p' the switch did nothing -- and once relabel_in_cinemas turns every
		# result of a film still in cinemas into CAM, it emptied The Odyssey's list with pre-releases switched on.
		if self.include_prerelease_results: filter_list = list(filter_list) + ['SCR', 'CAM', 'TELE']
		return filter_list

	def _get_size_rank(self, item):
		if self.weight_size: return item['size'] * 2 if 'HEVC' in item['extraInfo'] else item['size']
		else: return item['size']

	def _get_quality_rank(self, quality):
		return {'4K': 1, '1080p': 2, '720p': 3, 'SD': 4, 'SCR': 5, 'CAM': 5, 'TELE': 5}[quality]

	def _get_provider_rank(self, account_type):
		return self.provider_sort_ranks.get(account_type) or 11   # LOCAL PATCH 2026-10-03: .get -- one unknown debrid broke sorting for the whole scrape

	def _sort_folder_to_top(self, provider):
		if provider == 'folders': return 0
		else: return 1

	def _sort_uncached_results(self, results):
		# LOCAL PATCH 2026-10-25 (4.0.5): one-pass split (was `not i in uncached`, quadratic: 21 ms -> 0.4 ms measured)
		cached, uncached = [], []
		for i in results: (uncached if 'Uncached' in i.get('cache_provider', '') else cached).append(i)
		return cached + uncached

	def get_meta(self):
		prefetched = self.params.get('_prefetched_meta') if isinstance(self.params, dict) else None
		if (self.media_type == 'episode' and isinstance(prefetched, dict)
				and 'tvshow_plot' in prefetched and 'season_data' in prefetched):
			self.meta = prefetched
			self.meta.update({'playcount': self.playcount, 'watch_count': self.watch_count,
							'custom_season': self.custom_season, 'custom_episode': self.custom_episode})
		elif self.media_type == 'movie':
			self.meta = metadata.movie_meta('tmdb_id', self.tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
		else:
			try:
				self.meta = metadata.tvshow_meta('tmdb_id', self.tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
				episodes_data = metadata.episodes_meta(self.season, self.meta)
				episode_data = [i for i in episodes_data if i['episode'] == self.episode][0]
				ep_thumb = episode_data.get('thumb', None) or self.meta.get('fanart') or ''
				episode_type = episode_data.get('episode_type', '')
				self.meta.update({'season': episode_data['season'], 'episode': episode_data['episode'], 'premiered': episode_data['premiered'], 'episode_type': episode_type,
								'ep_name': episode_data['title'], 'ep_thumb': ep_thumb, 'plot': episode_data['plot'], 'tvshow_plot': self.meta['plot'],
								'ep_duration': episode_data.get('duration', 0),   # LOCAL PATCH 2026-10-01: the results panel's bitrate
								'playcount': self.playcount, 'watch_count': self.watch_count, 'custom_season': self.custom_season, 'custom_episode': self.custom_episode})
				self.meta.update(metadata.episode_rating_fields(episode_data))   # LOCAL PATCH 2026-10-19: the OSD's episode rating
			except: pass
		self.meta.update({'media_type': self.media_type, 'background': self.background, 'custom_title': self.custom_title, 'custom_year': self.custom_year})

	def make_search_info(self):
		title, year, ep_name = self.get_search_title(), self.get_search_year(), self.get_ep_name()
		aliases = make_alias_dict(self.meta, title)
		expiry_times = get_cache_expiry(self.media_type, self.meta, self.season)
		self.search_info = {'media_type': self.media_type, 'title': title, 'year': year, 'tmdb_id': self.tmdb_id, 'imdb_id': self.meta.get('imdb_id'), 'aliases': aliases,
							'season': self.get_season(), 'episode': self.get_episode(), 'tvdb_id': self.meta.get('tvdb_id'), 'ep_name': ep_name, 'expiry_times': expiry_times,
							'total_seasons': self.meta.get('total_seasons', 1),
							'premiered': str(self.meta.get('premiered') or '')[:10] if self.media_type == 'episode' else ''}   # LOCAL PATCH 2026-10-24: check_title(air_date=)
		# http_streams' _drop_other_episodes keeps a row named by any of these; only external.py's own data had them, so
		# an anime release named by cour / season numbering (Re:ZERO S01E27 as S02E02) lost its Direct Streams rows.
		if self.media_type == 'episode':
			try: self.search_info['episode_candidates'] = anime_episode_candidates(self.meta, self.tmdb_id, int(self.search_info['season']), int(self.search_info['episode']))
			except Exception: pass

	def _get_module(self, module_type, function):
		if module_type == 'external': module = function.source(*self.external_args)
		elif module_type == 'folders': module = function[0](*function[1])
		else: module = function()
		return module

	def _clear_properties(self):
		def_internal = self.default_internal_scrapers
		for item in def_internal: kodi_utils.clear_property('deadlight.internal_results.%s' % item)
		if self.active_folders:
			for item in self.folder_info: kodi_utils.clear_property('deadlight.internal_results.%s' % item[0])

	def _make_progress_dialog(self):
		from modules.kodi_utils import logger_debug as logger
		logger('DialogFlash _make_progress_dialog', 'creating new SourcesPlayback (background=%s, autoplay_nextep=%s)' % (self.background, getattr(self, 'autoplay_nextep', 'n/a')))
		try:
			self.progress_dialog = create_window(('windows.sources', 'SourcesPlayback'), 'sources_playback.xml', meta=self.meta)
			self.progress_thread = Thread(target=self.progress_dialog.run)
			self.progress_thread.start()
			# LOCAL PATCH 2026-09-27: a SmartPlay status set before this window existed (a background handoff)
			if getattr(self, 'smartplay_note', ''): self.progress_dialog.set_smartplay(self.smartplay_note)
		except Exception as e:
			kodi_utils.logger('SourcesPlayback init failed', str(e))
			self.progress_dialog, self.progress_thread = None, None
			try: kodi_utils.close_all_dialog()
			except: pass

	def _smartplay_status(self, text):
		"""LOCAL PATCH 2026-09-27: the SmartPlay line in the loading window. Kept on self so a window made later shows it."""
		self.smartplay_note = text
		try:
			if self.progress_dialog: self.progress_dialog.set_smartplay(text)
		except Exception: pass

	def _make_resolve_dialog(self):
		from modules.kodi_utils import logger_debug as logger
		logger('DialogFlash _make_resolve_dialog', 'resolve_dialog_made=%s progress_dialog=%s' % (self.resolve_dialog_made, self.progress_dialog is not None))
		self.resolve_dialog_made = True
		if not self.progress_dialog: self._make_progress_dialog()
		self.progress_dialog.enable_resolver()

	def _make_resume_dialog(self, percent):
		if not self.progress_dialog: self._make_progress_dialog()
		self.progress_dialog.enable_resume(percent)
		return self.progress_dialog.resume_choice

	def _make_nextep_dialog(self, default_action='cancel', choose=False):
		# LOCAL PATCH 2026-08-25: pass the timing tier through to the dialog. `chapters_detected`
		# used to be threaded here and was never read by anything; it is replaced by
		# countdown_mode, which actually drives how NextEpisode counts down:
		#   'fixed'  -> HIGH confidence (IntroDB outro / chapter): count N seconds into the
		#               credits, then autoplay. Netflix-style.
		#   'to_end' -> LOW confidence (percentage fallback): the alert point is arbitrary, so
		#               count down the real remaining playback time and only autoplay at the
		#               true end of the video. Prevents cutting ~125s of episode at defaults.
		ns = getattr(self, 'nextep_settings', None)
		if not isinstance(ns, dict): ns = {}
		# LOCAL PATCH 2026-10-15: also to the real end when there is content after the outro (player.info_next_ep
		# 'content_after': a preview / post-credits scene is not credits). The Choose Source card counts the alert time like
		# this one since the later 10-15 change (its no-answer stop is safe only on credits, see _wait_out_playback).
		countdown_mode = 'to_end' if (ns.get('timing_confidence') == 'low' or ns.get('content_after')) else 'fixed'
		try:
			action = open_window(('windows.playback_notifications', 'NextEpisode'), 'playback_notifications.xml',
								meta=self.meta, default_action=default_action,
								countdown_mode=countdown_mode, total_time=ns.get('total_time'), choose=choose)
		except: action = 'cancel'
		return action

	def _make_still_watching_dialog(self, check_text):
		try: action = open_window(('windows.playback_notifications', 'StillWatching'), 'playback_notifications.xml', meta=self.meta, check_text=check_text)
		except: action = False   # LOCAL PATCH 2026-10-15: was 'no', which callers read as yes (StillWatching.onAction)
		return action

	def _kill_progress_dialog(self):
		from modules.kodi_utils import logger_debug as logger
		import traceback
		caller = traceback.extract_stack(limit=2)[-2]   # LOCAL PATCH 2026-10-25 (4.0.5): the caller only, not the whole stack
		logger('DialogFlash _kill_progress_dialog', 'called from %s:%d in %s' % (caller.filename.rsplit('\\', 1)[-1], caller.lineno, caller.name))
		success = 0
		try:
			self.progress_dialog.close()
			success += 1
		except: pass
		try:
			self.progress_thread.join()
			success += 1
		except: pass
		if success != 2:
			try: kodi_utils.close_all_dialog()
			except: pass
		self.progress_dialog, self.progress_thread = None, None

	def debridPacks(self, debrid_provider, name, magnet_url, info_hash, download=False):
		# LOCAL PATCH 2026-10-03: an uncached pack has no file list to browse yet. Its provider arrives as 'Uncached TorBox',
		# which the table below does not name, so Browse Pack raised KeyError: 'Uncached TorBox' (kodi.log 17:34).
		if str(debrid_provider or '').startswith('Uncached'):
			kodi_utils.notification('Pack not cached on %s yet' % str(debrid_provider).replace('Uncached', '', 1).strip())
			return None
		# LOCAL PATCH 2026-10-03: looked up before the busy dialog, so a name the table lacks cannot leave the spinner up
		debrid_info = {'Real-Debrid': 'rd_browse', 'Premiumize.me': 'pm_browse', 'AllDebrid': 'ad_browse', 'TorBox': 'tb_browse'}.get(debrid_provider)
		if not debrid_info: return kodi_utils.notification('No debrid service for this source')
		kodi_utils.show_busy_dialog()
		debrid_function = self.debrid_importer(debrid_info)
		try: debrid_files = debrid_function().display_magnet_pack(magnet_url, info_hash)
		except: debrid_files = None
		kodi_utils.hide_busy_dialog()
		if not debrid_files: return kodi_utils.notification('Error')
		debrid_files.sort(key=lambda k: k['filename'].lower())
		if download: return debrid_files, debrid_function
		list_items = [{'line1': '%.2f GB | %s' % (float(item['size'])/1073741824, clean_file_name(item['filename']).upper())} for item in debrid_files]
		kwargs = {'items': json.dumps(list_items), 'heading': name, 'enumerate': 'true', 'narrow_window': 'true'}
		chosen_result = kodi_utils.select_dialog(debrid_files, **kwargs)
		if chosen_result is None: return None
		link = self.resolve_internal(debrid_info, chosen_result['link'], '')
		name = chosen_result['filename']
		self._kill_progress_dialog()
		return DeadLightPlayer().run(link, 'video')

	def play_file(self, results, source={}):
		self.last_resolve_reason = None   # LOCAL PATCH 2026-10-15: per call (a sticky-pack fallback runs this twice)
		# LOCAL PATCH 2026-07-02: user_cancelled is set only when the user actively pressed
		# Back / cancel; distinct from cancel_all_playback which fires on both user-cancel
		# and playback failure (all sources exhausted / monitor exception). Sticky-fallback
		# checks user_cancelled — the former case keeps the sticky, the latter should fall
		# through to a fresh scrape so the picker opens.
		self.playback_successful, self.cancel_all_playback, self.user_cancelled = None, False, False
		retry_easynews = settings.easynews_playback_method('retry')
		retry_easynews_limit = settings.easynews_playback_method_retries()
		try:
			kodi_utils.hide_busy_dialog()
			url = None
			results = [i for i in results if not 'Uncached' in i.get('cache_provider', '')]
			if not source: source = results[0]
			items = [source]
			if not self.limit_resolve: 
				source_index = results.index(source)
				results.remove(source)
				items_prev = results[:source_index]
				items_prev.reverse()
				items_next = results[source_index:]
				items = items + items_next + items_prev
			processed_items = []
			processed_items_append = processed_items.append
			from windows.sources import resolve_tags_line
			for count, item in enumerate(items, 1):
				resolve_item = dict(item)
				provider = item['scrape_provider']
				if provider == 'external': provider = item['debrid'].replace('.me', '')
				elif provider == 'folders': provider = item['source']
				# LOCAL PATCH 2026-09-27: laid out like the episode block above it (SourcesPlayback.set_resolver_properties:
				# one bold heading line, then plain text) -- the heading carries number, provider, quality and size; the
				# codec details and the release name follow in plain text, the name in its own case rather than upper.
				# LOCAL PATCH 2026-09-29: no '01 -' counter (the phase line above says 'source n of N', amber from the
				# second on). Tags in kind order (windows.sources.resolve_tags_line); the release name a darker grey
				# than the box's FFB7B4BB text, so it steps back behind the tags.
				# LOCAL PATCH 2026-09-29: the service as it writes itself ('TorBox', 'Easynews', not 'TORBOX')
				heading_name = provider if item['scrape_provider'] in ('external', 'folders') else provider_panel_name(provider)
				heading = '%s  ·  %s  ·  %s' % (heading_name, item['quality'], item['size_label'])
				display_name = item['display_name']
				extra_info = resolve_tags_line(item['extraInfo'], display_name)
				body = '%s[CR][COLOR FF85828A]%s[/COLOR]' % (extra_info, display_name) if extra_info else '[COLOR FF85828A]%s[/COLOR]' % display_name
				resolve_item['resolve_display'] = '[B]%s[/B][CR]%s' % (heading, body)
				resolve_item['resolve_parts'] = (heading, extra_info)
				processed_items_append(resolve_item)
				if provider == 'easynews' and retry_easynews:
					for retry in range(1, retry_easynews_limit):
						resolve_item = dict(item)
						resolve_item['resolve_display'] = '[B]%s  ·  Retry %s[/B][CR]%s' % (heading, retry, body)
						processed_items_append(resolve_item)
			items = list(processed_items)
			if not self.continue_resolve_check(): return self._kill_progress_dialog()
			kodi_utils.hide_busy_dialog()
			self.playback_percent = self.get_playback_percent()
			if self.playback_percent == None: return self._kill_progress_dialog()
			if not self.resolve_dialog_made: self._make_resolve_dialog()
			# LOCAL PATCH 2026-09-26: the fixed sleep(1000) that stood here for background (next-episode)
			# plays is gone. Timed on a handoff: player.stop() in autoplay_nextep_handler already blocks
			# until Kodi has closed the old file (4.8 s with the HDR display reset), so the extra second
			# only lengthened the gap before the next file was handed over.
			monitor = kodi_utils.kodi_monitor()
			from modules.kodi_utils import logger_debug as _dflogger   # LOCAL PATCH 2026-10-25 (4.0.5): DialogFlash traces at DEBUG
			_dflogger('DialogFlash play_file loop', 'items=%d background=%s autoplay=%s autoplay_nextep=%s' % (len(items), self.background, self.autoplay, getattr(self, 'autoplay_nextep', 'n/a')))
			for count, item in enumerate(items, 1):
				try:
					_dflogger('DialogFlash play_file iter %d' % count, 'name=%s' % (item.get('name', '')[:60]))
					kodi_utils.hide_busy_dialog()
					if not self.progress_dialog: break
					self.progress_dialog.reset_is_cancelled()
					# LOCAL PATCH 2026-09-27: the bar counts sources tried; the heading says which one
					# LOCAL PATCH 2026-09-27 (second pass): ONE bar for the whole resolve. Each source owns a slice of it:
					# the debrid resolve fills its first half, Kodi opening the stream its second (player.py maps its
					# start-wait counter onto _bar_span). Before, this set 100% once the link resolved and the player
					# then restarted its own 0-100 count -- screenshots 72-74: 0, full, back to 1%.
					# LOCAL PATCH 2026-10-25: each source gets the WHOLE bar (a fallback starts it over, amber, 'Source 2 of N' says
					# which). Sliced by len(items), a pick from the results -- every result is a fallback, 86 on 10-25 10:34 / 10:36 --
					# gave the first source 1.2 % of the bar, under the 1 % the fill stays hidden: the bar never moved.
					_slice, _lo = 100.0, 0.0
					self._bar_span = (_lo + _slice / 2.0, _lo + _slice)
					# LOCAL PATCH 2026-09-29: amber (the bar's late colour) from the second source on -- a fallback is running
					_source_n = 'Source %d of %d' % (count, len(items))
					if count > 1: _source_n = '[COLOR FFE0AA46]%s[/COLOR]' % _source_n
					self.progress_dialog.update_resolver(text=item['resolve_display'], percent=_lo, detail=_source_n)
					self.progress_dialog.busy_spinner()
					if count > 1:
						kodi_utils.sleep(200)
						try: del player
						except: pass
					url, self.playback_successful, self.cancel_all_playback, self.user_cancelled = None, None, False, False
					self.playing_filename = item['name']
					self.playing_item = item
					player = DeadLightPlayer()
					try:
						if self.progress_dialog.iscanceled() or monitor.abortRequested(): break
						# LOCAL PATCH 2026-10-08: a pinned source checked before the handoff (_precheck_pinned) is already resolved
						kodi_utils.clear_property(RESOLVE_REASON_PROP)
						url = item.get('_preresolved') or self.resolve_sources(item)
						if url:
							self.last_resolve_reason = None   # a reason belongs to the source that failed, not a later one
							resolve_percent = self._bar_span[0]   # LOCAL PATCH 2026-09-27: the link is resolved -- half this slice
							self.progress_dialog.busy_spinner('false')
							self.progress_dialog.update_resolver(text=self._pack_file_display(item), percent=resolve_percent,
								detail='%s  ·  Starting playback' % _source_n)
							kodi_utils.sleep(50)   # one GUI tick for the update above; was 200 ms (2026-09-26)
							player.run(url, self)
						else:
							# LOCAL PATCH 2026-10-15: say why this source failed, on the window, before trying the next. The debrid
							# resolvers' reasons ('no file for this episode', 'not cached on RD') reached only the log.
							self.last_resolve_reason = kodi_utils.get_property(RESOLVE_REASON_PROP) or None
							if self.last_resolve_reason:
								try:
									self.progress_dialog.update_resolver(percent=self._bar_span[0], detail='%s%s' % (self.last_resolve_reason,
										'  ·  trying the next source' if count < len(items) else ''))
									kodi_utils.sleep(900)   # long enough to read
								except Exception: pass
							continue
						if self.cancel_all_playback: break
						if self.playback_successful: break
						if count == len(items):
							self.cancel_all_playback = True
							mark_internal_stop()   # LOCAL PATCH 2026-08-26: our stop, not the user's
							player.stop()
							break
					except: pass
				except: pass
		except: self._kill_progress_dialog()
		if self.cancel_all_playback: return self._kill_progress_dialog()
		if not self.playback_successful or not url: self.playback_failed_action()
		try: del monitor
		except: pass

	def get_playback_percent(self):
		if self.media_type == 'movie': percent = watched_status.get_progress_status_movie(watched_status.get_bookmarks_movie(), str(self.tmdb_id))
		elif any((self.random, self.random_continual)): return 0.0
		else: percent = watched_status.get_progress_status_episode(watched_status.get_bookmarks_episode(self.tmdb_id, self.season), self.episode)
		if not percent: return 0.0
		action = self.get_resume_status(percent)
		if action == 'cancel': return None
		if action == 'start_over':
			watched_status.erase_bookmark(self.media_type, self.tmdb_id, self.season, self.episode)
			return 0.0
		return float(percent)

	def get_resume_status(self, percent):
		if settings.auto_resume(self.media_type, self.autoplay): return float(percent)
		return self._make_resume_dialog(percent)

	def playback_failed_action(self):
		self._kill_progress_dialog()
		# LOCAL PATCH 2026-10-15: a failed play said nothing when no source resolved -- the window just closed. Not when a
		# full search follows (below), which keeps going.
		# Only with a resolver's reason: a play error already has the player's own 'Playback Failed' (player.run_error).
		_why = getattr(self, 'last_resolve_reason', None)
		if _why and not (self.prescrape and self.autoplay): kodi_utils.notification('Playback failed - %s' % _why, 6000)
		if self.prescrape and self.autoplay:
			self.resolve_dialog_made, self.prescrape, self.prescrape_sources = False, False, []
			self.get_sources()

	def still_watching_check(self):
		watching_check = self.nextep_settings['watching_check']
		if watching_check == 0: return True
		player = kodi_utils.kodi_player()
		# LOCAL PATCH 2026-10-15: nothing playing is not a 'no'. Returning False here cancelled autoplay whenever the
		# episode had already ended when the scrape came back (outro auto-skip seeks to the end ~3 s before the
		# handoff; a slow scrape) -- the case the 2026-07-22 note in autoplay_nextep_handler, this function's only
		# caller, keeps the alert for. That handler tells a Stop from a natural end itself (PLAYBACK_STOPPED_PROP,
		# ended_before_window). The question waits for the next handoff: StillWatching cannot be shown without
		# playback (its countdown runs while the player plays), so the count is left as it is.
		if not player.isPlayingVideo(): return True
		watch_count = self.meta.get('watch_count')
		if watch_count == watching_check: still_watching, watch_count = self._make_still_watching_dialog('Are you still watching [B]%s[/B]?'), 0
		else: still_watching = True
		watch_count += 1
		self.meta['watch_count'] = watch_count
		return still_watching

	def continue_resolve_check(self):
		try:
			if not self.background or self.autoscrape_nextep: return True
			# LOCAL PATCH 2026-09-03: a source picked out of the picker is already the user's
			# answer to 'play the next episode?', so do not put the countdown up afterwards.
			# Observed: picker at 10:01:56, then the NextEpisode dialog at 10:02:01 with
			# 'entry playing=False' -- asking whether to start something the user had just
			# selected, after playback had already finished. The alert exists for the AUTOMATIC
			# handoff, where nothing has been chosen yet.
			if getattr(self, 'chosen_by_user', False):
				kodi_utils.logger('autoplay_nextep_handler', 'skipped: source was chosen from the picker')
				return True
			# LOCAL PATCH 2026-10-08: asked once per handoff. A failed sticky pack-play falls back to a scrape on this
			# same object, and its play_file came back here: the previous episode was gone by then, so the handler read
			# the dead stream's stop as the user's and refused -- Reacher S04E06 at 17:02:58 never tried the
			# same-release match it had just found ('sticky-matched source failed' without a resolve).
			if getattr(self, 'nextep_answered', False):
				kodi_utils.logger('autoplay_nextep_handler', 'skipped: next episode already confirmed this handoff')
				return True
			if self.autoplay_nextep: return self.autoplay_nextep_handler()
			return self.random_continual_handler()
		except: return False

	def random_continual_handler(self):
		kodi_utils.notification('[B]Next Up:[/B] %s S%02dE%02d' % (self.meta.get('title'), self.meta.get('season'), self.meta.get('episode')), 6500, self.meta.get('poster'))
		player = kodi_utils.kodi_player()
		while player.isPlayingVideo(): kodi_utils.sleep(100)
		self._make_resolve_dialog()
		return True

	def autoplay_nextep_handler(self):
		from modules.kodi_utils import logger as _dflogger
		if not self.nextep_settings:
			_dflogger('autoplay_nextep_handler', 'no nextep_settings — aborting')
			return False
		if not self.still_watching_check():
			kodi_utils.notification('Cancel Autoplay', icon=self.meta.get('poster'))
			return False
		player = kodi_utils.kodi_player()
		use_window, window_time, default_action = self.nextep_settings['use_window'], self.nextep_settings['window_time'], self.nextep_settings['default_action']
		playing_at_entry = player.isPlayingVideo()
		_dflogger('autoplay_nextep_handler', 'entry playing=%s use_window=%s window_time=%s default_action=%s' % (playing_at_entry, use_window, window_time, default_action))
		# LOCAL PATCH 2026-07-22: the outer isPlayingVideo() check used to gate this
		# entire block was blocking the dialog when the previous episode ended before
		# we got here (outro auto-skip + slow scrape race). Now we open the dialog
		# regardless — we only wait for the timing window if the video IS still playing.
		action = None if use_window else 'close'
		continue_nextep = False
		last_remaining = None   # DIAG/fallback 2026-08-25: position at last sample
		if playing_at_entry:
			try: total_time = player.getTotalTime()
			except: total_time = 0
			while player.isPlayingVideo():
				try:
					remaining_time = round(total_time - player.getTime())
					last_remaining = remaining_time
					if remaining_time <= window_time:
						continue_nextep = True
						break
					kodi_utils.sleep(1000)
				except: pass
		# If we exit the wait loop because playback ended (or we never entered it because
		# playback was already over), fall through to showing the dialog anyway — user's
		# intent was autoplay-with-alert. Only suppress on explicit cancel.
		# LOCAL PATCH 2026-08-21: ...but a plain Stop is ALSO an explicit cancel. It sets
		# neither cancel_all_playback nor user_cancelled (those are only set on
		# progress-dialog cancel / exception), so this fallback used to fire on a normal
		# Stop and pop Next Up after the video was already closed. DeadLightPlayer's
		# onPlayBackStopped/onPlayBackEnded now record the verdict in a window property
		# (an instance flag can't be used — this runs on a fresh Sources() from
		# episode_tools.auto_nextep, not the player's sources_object).
		if not continue_nextep:
			# Reaching here means the wait loop exited WITHOUT ever hitting the alert
			# window. A natural end cannot do that: as playback nears the end,
			# remaining_time drops below window_time and the loop breaks with
			# continue_nextep=True first. So an exit while remaining is still ABOVE
			# window_time means playback was cut short — the user pressed Stop.
			#
			# This position test is the primary signal because it needs no callback.
			# onPlayBackStopped is authoritative but Kodi delivers it ~2.5s after
			# isPlayingVideo() flips (measured: loop exit 10:55:54.86, callback
			# 10:55:57.31), long after this gate has already decided.
			ended_before_window = last_remaining is not None and last_remaining > window_time
			# LOCAL PATCH 2026-09-24: playback already over when we got here, so there was no position
			# to test above -- ask the player where it last saw it. Kodi reports a stream that DIES as
			# a natural end (onPlayBackEnded), so the stop verdict below never fires for it: Reacher
			# S01E05 closed on 'eof reading from demuxer' 17 minutes into 50 and this still opened the
			# alert. An episode that really reached its end, including the outro-skip / slow-scrape
			# race below, was last seen within seconds of it.
			if last_remaining is None:
				try: _player_last = float(kodi_utils.get_property(PLAYBACK_LAST_REMAINING_PROP) or '')
				except (TypeError, ValueError): _player_last = None
				if _player_last is not None and _player_last > NEXTEP_END_TOLERANCE:
					ended_before_window = True
					last_remaining = _player_last
			user_stopped = kodi_utils.get_property(PLAYBACK_STOPPED_PROP) == 'true'
			if not user_stopped and not ended_before_window:
				# Inconclusive — give the late callback a brief chance before allowing.
				kodi_utils.sleep(600)
				user_stopped = kodi_utils.get_property(PLAYBACK_STOPPED_PROP) == 'true'
			if user_stopped or ended_before_window or getattr(self, 'cancel_all_playback', False) or getattr(self, 'user_cancelled', False):
				_dflogger('autoplay_nextep_handler', 'suppressing dialog — user_stopped=%s ended_before_window=%s (last_remaining=%s window_time=%s)'
					% (user_stopped, ended_before_window, last_remaining, window_time))
			else:
				# last_remaining is None => playback was already over when we got here
				# (outro auto-skip + slow scrape race, the 2026-07-22 case). Alert is wanted.
				continue_nextep = True
		_dflogger('autoplay_nextep_handler', 'pre-dialog continue_nextep=%s cancel_all=%s user_cancelled=%s' % (continue_nextep, getattr(self, 'cancel_all_playback', False), getattr(self, 'user_cancelled', False)))
		if continue_nextep:
			if use_window:
				_dflogger('autoplay_nextep_handler', 'opening NextEpisode dialog default_action=%s' % default_action)
				action = self._make_nextep_dialog(default_action=default_action)
				_dflogger('autoplay_nextep_handler', 'dialog returned action=%r' % action)
			else:
				kodi_utils.notification('[B]Next Up:[/B] %s S%02dE%02d' \
					% (self.meta.get('title'), self.meta.get('season'), self.meta.get('episode')), 6500, self.meta.get('poster'))
			if not action: action = default_action
			_dflogger('autoplay_nextep_handler', 'final action=%r' % action)
			if action == 'cancel':
				# Set cancel_all_playback so _sticky_pack_play upstream sees user-cancel
				# (without this, sticky pack-play sees play_file returning unsuccessfully
				# and falls back to a full scrape — re-firing the popup at episode end).
				self.cancel_all_playback, self.user_cancelled = True, True
				return False
			elif action == 'pause':
				self.cancel_all_playback, self.user_cancelled = True, True
				mark_internal_stop()   # LOCAL PATCH 2026-08-26: our stop, not the user's
				try: player.stop()
				except: pass
				return False
			elif action == 'play':
				self._make_resolve_dialog()
				# LOCAL PATCH 2026-08-26: this stop is OURS -- we are handing off to the next
				# episode. Unmarked, onPlayBackStopped recorded it as a user stop, and the
				# handler invocation for the NEW episode then read that stale verdict and
				# suppressed itself. When the sticky source failed, that also blocked
				# SmartPlay's fallback scrape, turning a recoverable failure into a dead stop.
				mark_internal_stop()
				try: player.stop()
				except: pass
				self.nextep_answered = True   # LOCAL PATCH 2026-10-08: see continue_resolve_check
				return True
			else:
				while player.isPlayingVideo(): kodi_utils.sleep(100)
				self._make_resolve_dialog()
				self.nextep_answered = True
				return True
		else: return False

	def autoscrape_nextep_handler(self):
		if settings.autoscrape_confirm():
			if not self._make_still_watching_dialog('Autoscrape Next Episode of [B]%s[/B]?'): return kodi_utils.notification('Cancel Autoscrape', icon=self.meta.get('poster'))
		player = kodi_utils.kodi_player()
		if player.isPlayingVideo():
			results = self.get_sources()
			if not results: return kodi_utils.notification(33092, 3000)
			else:
				kodi_utils.notification('[B]Next Episode Ready:[/B] %s S%02dE%02d' \
						% (self.meta.get('title'), self.meta.get('season'), self.meta.get('episode')), 6500, self.meta.get('poster'))
				while player.isPlayingVideo(): kodi_utils.sleep(100)
			self.display_results(results)
		else: return

	def debrid_importer(self, debrid_provider):
		return manual_function_import(*self.debrids[debrid_provider])

	def _pack_file_display(self, item):
		"""LOCAL PATCH 2026-09-29: a pack's release name says nothing about which episode plays. Once resolve_cached has
		picked the file (source_utils.pick_episode_files publishes it as deadlight.playing.pack_file, cleared at every
		resolve), the block shows that file in the release name's place -- same line count, so the 145 px box still
		fits. '' (text unchanged) for a non-pack, or when the file is only the release name again."""
		try:
			if 'package' not in item: return ''
			picked = (kodi_utils.get_property('deadlight.playing.pack_file') or '').strip()
			picked = picked.replace(chr(92), '/').rsplit('/', 1)[-1]
			if not picked or picked.rsplit('.', 1)[0].lower() == (item.get('name') or '').lower(): return ''
			heading, extra_info = item['resolve_parts']
			file_line = '[COLOR FF6E6E6E]File[/COLOR]  [COLOR FF85828A]%s[/COLOR]' % picked
			return '[B]%s[/B][CR]%s' % (heading, '%s[CR]%s' % (extra_info, file_line) if extra_info else file_line)
		except Exception: return ''

	def resolve_sources(self, item, meta=None):
		if meta: self.meta = meta
		url = None
		try:
			if 'cache_provider' in item:
				cache_provider = item['cache_provider']
				if self.meta['media_type'] == 'episode':
					if hasattr(self, 'search_info'):
						title, season, episode, pack = self.search_info['title'], self.search_info['season'], self.search_info['episode'], 'package' in item
					else: title, season, episode, pack = self.get_ep_name(), self.get_season(), self.get_episode(), 'package' in item
				else: title, season, episode, pack = self.get_search_title(), None, None, False
				# LOCAL PATCH 2026-08-27: anime files inside a pack are not numbered the way
				# TMDb numbers them, so the debrid layer needs the alternatives to find the
				# right file. Empty for everything that is not anime.
				# LOCAL PATCH 2026-09-22: the RAW TMDb pair, matching scrapers/external.py. season and
				# episode above come from search_info, i.e. get_season()/get_episode(), which return an
				# assigned episode group's rewrite. anime_episode_candidates spends its pair on
				# series_absolute_episode and find_cour_by_tmdb_coords, both of which read TMDb
				# numbering, so a group turned Re:ZERO's TMDb S1E27 into [(2, 87), (2, 2)] on an
				# 85-episode show -- a number no file carries -- while losing (2, 1), which is what the
				# releases are named. This is the FILE PICKING half of the same fault; leaving it would
				# make the size shown in the picker disagree with the file the resolver opens.
				# season/episode themselves are passed on unchanged -- only the candidates move.
				_raw_s = self.meta.get('season', season)
				_raw_e = self.meta.get('episode', episode)
				ep_candidates = anime_episode_candidates(self.meta, self.meta.get('tmdb_id'), _raw_s, _raw_e) if season is not None else []
				if cache_provider in ('Real-Debrid', 'Premiumize.me', 'AllDebrid', 'TorBox'):
					url = self.resolve_cached(cache_provider, item['url'], item['hash'], title, season, episode, pack, ep_candidates)
				# LOCAL PATCH 2026-10-11: the same torrent on the other debrid(s) it is cached on (collapse_debrid_twins), before
				# the play loop moves on to another release. The row then names the debrid that played it.
				for fallback in ([] if url else item.get('debrid_fallbacks') or []):
					if fallback not in ('Real-Debrid', 'Premiumize.me', 'AllDebrid', 'TorBox'): continue
					kodi_utils.logger('debrid twins', '%s failed on %s -- trying %s' % (item.get('hash'), cache_provider, fallback))
					url = self.resolve_cached(fallback, item['url'], item['hash'], title, season, episode, pack, ep_candidates)
					if url:
						item['cache_provider'], item['debrid'] = fallback, fallback
						break
			elif item.get('url_fallbacks') and item.get('scrape_provider') == 'http_streams':
				url = self._resolve_direct_fallbacks(item)
			elif item.get('scrape_provider', None) in self.default_internal_scrapers:
				url = self.resolve_internal(item['scrape_provider'], item['id'], item['url_dl'], item.get('direct_debrid_link', False))
			else: url = item['url']
		except: pass
		return url

	def _resolve_direct_fallbacks(self, item):
		"""LOCAL PATCH 2026-10-24: a Direct Streams release on several hosts (scrapers/http_streams._merge_host_copies): the
		first that answers, its own link first and PixelDrain last. None answering, the row's own link as before -- so
		a check that cannot reach the host never makes a playable link worse than it was."""
		try: kodi_utils.set_property('deadlight.playing.pack_file', '')
		except Exception: pass
		from scrapers.http_streams import source as http_streams
		links = [item['url_dl']] + [u for u in item.get('url_fallbacks') or [] if u]
		for n, link in enumerate(links):
			if http_streams.direct_url_alive(link):
				if n:
					kodi_utils.logger('direct hosts', '%s: %d of %d hosts did not answer -- playing host %d' % (item.get('name'), n, len(links), n + 1))
					item['url_dl'] = link
				return link
		kodi_utils.logger('direct hosts', '%s: none of %d hosts answered the check -- trying the first anyway' % (item.get('name'), len(links)))
		return item['url_dl']

	def resolve_cached(self, debrid_provider, item_url, _hash, title, season, episode, pack, ep_candidates=None):
		# LOCAL PATCH 2026-08-31: cleared at both resolution entry points so a pack file
		# recorded by a previous playback cannot leak into this one.
		try: kodi_utils.set_property('deadlight.playing.pack_file', '')
		except Exception: pass
		debrid_function = self.debrid_importer(debrid_provider)
		store_to_cloud = settings.store_resolved_to_cloud(debrid_provider, pack)
		try: url = debrid_function().resolve_magnet(item_url, _hash, store_to_cloud, title, season, episode, ep_candidates)
		except: url = None
		return url

	def resolve_internal(self, scrape_provider, item_id, url_dl, direct_debrid_link=False):
		try: kodi_utils.set_property('deadlight.playing.pack_file', '')
		except Exception: pass
		url = None
		try:
			if direct_debrid_link or scrape_provider == 'folders': url = url_dl
			elif scrape_provider == 'easynews':
				from indexers.easynews import resolve_easynews
				url = resolve_easynews({'url_dl': url_dl, 'play': 'false'})
			else:
				debrid_function = self.debrid_importer(scrape_provider)
				if any(i in scrape_provider for i in ('rd_', 'ad_', 'tb_')):
					url = debrid_function().unrestrict_link(item_id)
				else:
					if '_cloud' in scrape_provider: item_id = debrid_function().get_item_details(item_id)['link']
					url = debrid_function().add_headers_to_url(item_id)
		except: pass
		return url

	def _quality_length(self, items, quality):
		return len([i for i in items if i['quality'] == quality])

	def _quality_length_sd(self, items, dummy):
		return len([i for i in items if i['quality'] in ('SD', 'CAM', 'TELE', 'SYNC')])

	def _quality_length_final(self, items, dummy):
		return len(items)
