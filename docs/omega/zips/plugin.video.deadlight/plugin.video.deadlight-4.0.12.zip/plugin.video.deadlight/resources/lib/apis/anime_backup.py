# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-21: backup anime catalogues for when AniList does not answer.
#
# AniList went dark again on 2026-10-21 ('The AniList API has been temporarily disabled due to severe stability
# issues', every request, signed in or not) and every anime menu and home widget came up empty. anilist_api.
# _cached_page now hands the page it could not get to page() here, which answers it from MyAnimeList, then Kitsu.
#
# The AniList page's own variables say which list it is (season + year, a year alone, a format, the sort, a search),
# so every browse row gets its backup with no per-row code. Each source takes only what it can answer FAITHFULLY:
#   MAL:   search, a season (by members / score), all-time popularity / score / favourites. Its format rankings
#          (movie, ova, special) are sorted by SCORE, not popularity, it has no year filter and no ONA / TV short
#          ranking -- those go to Kitsu.
#   Kitsu: everything above plus a year, and the formats (no TV shorts: Kitsu has no such subtype).
#   Trending (AniList only) is served as popularity over the same period -- the closest list either source has.
# Measured 2026-10-21 while AniList was down: MAL answered 503 'maintenance mode' (and Jikan, which scrapes MAL, timed
# out), Kitsu answered every list in 0.6-3 s. Hence both, in that order.
#
# Items come back in AniList's shape (id, idMal, title, format, startDate) so indexers/anilist_lists._render takes them
# unchanged. Kitsu's mappings carry the AniList and MAL ids; a MAL row gets its AniList id from Fribb. With the AniList
# id a backup row resolves exactly as the AniList row would -- same TMDb resolution cache, same cour handling. No
# averageScore or tags: the AniList chip must not show another site's score.
# LOCAL PATCH 2026-10-22: coverImage IS carried now (user's call) -- each entry's own poster, so a later cour shows its own
# key visual as AniList's covers do, not the show's (indexers/anilist_lists._render puts it on the tile). MAL main_picture
# 'large' (315-424 x 450-600; 'medium' is 225 wide) and Kitsu posterImage 'large' (550 x 780; 'original' reaches 4096 tall).

from caches.lists_cache import lists_cache_object
from caches.base_cache import is_failed_result
from modules.kodi_utils import make_session, logger, cooldown_active, start_cooldown, get_property, set_property, notification
from modules.utils import safe_err   # LOCAL PATCH 2026-10-25 (4.0.5): request errors logged without their url / query keys

_KITSU_URL = 'https://kitsu.app/api/edge/%s'
_kitsu_session = make_session('https://kitsu.app')
_CACHE_HOURS = 12
_COOLDOWN_SECS = 600            # a source that failed is not asked again for 10 min (a MAL timeout is 20 s a page)
_COOLDOWN_PROP = 'deadlight.anime_backup.cooldown.%s'
_SOURCE_NAMES = {'mal': 'MyAnimeList', 'kitsu': 'Kitsu'}

_SEASON_NAMES = {'WINTER': 'winter', 'SPRING': 'spring', 'SUMMER': 'summer', 'FALL': 'fall'}
_MAL_FORMATS = {'tv': 'TV', 'ova': 'OVA', 'movie': 'MOVIE', 'special': 'SPECIAL', 'tv_special': 'SPECIAL', 'ona': 'ONA',
				'music': 'MUSIC'}
_KITSU_FORMATS = {'TV': 'TV', 'movie': 'MOVIE', 'OVA': 'OVA', 'ONA': 'ONA', 'special': 'SPECIAL', 'music': 'MUSIC'}
_KITSU_SUBTYPES = {'TV': 'TV', 'MOVIE': 'movie', 'OVA': 'OVA', 'ONA': 'ONA', 'SPECIAL': 'special'}
_MAL_FIELDS = 'id,title,alternative_titles,start_date,media_type,start_season,main_picture'


def _spec(variables):
	"""The list an AniList page's variables describe, or None when no backup can stand in for it."""
	v = variables or {}
	if v.get('genre') or v.get('status'): return None
	per_page = int(v.get('perpage') or 20)
	page_no = int(v.get('page') or 1)
	if v.get('search'): return {'kind': 'search', 'q': str(v['search']).strip(), 'page': page_no, 'per_page': per_page}
	fmt = list(v.get('format') or [])
	if len(fmt) > 1: return None
	sort = (v.get('sort') or ['POPULARITY_DESC'])[0]
	order = {'SCORE_DESC': 'score', 'FAVOURITES_DESC': 'favourites'}.get(sort, 'popularity')   # TRENDING: popularity
	year = str(v.get('year') or '').rstrip('%')
	return {'kind': 'browse', 'season': v.get('season'), 'year': int(year) if year.isdigit() else None,
			'format': fmt[0] if fmt else None, 'order': order, 'page': page_no, 'per_page': per_page}


def _date(text):
	parts = [int(p) if p.isdigit() else None for p in str(text or '').split('-')[:3]]
	parts += [None] * (3 - len(parts))
	return {'year': parts[0], 'month': parts[1], 'day': parts[2]}


def _anilist_for_mal(mal_id):
	try:
		from caches.fribb_mappings import mal_to_fribb
		return (mal_to_fribb(mal_id) or {}).get('anilist_id')
	except Exception: return None


def _item(source, anilist_id, mal_id, fmt, romaji, english, native, start_date, cover=None):
	try: anilist_id = int(anilist_id) if anilist_id else None
	except (TypeError, ValueError): anilist_id = None
	try: mal_id = int(mal_id) if mal_id else None
	except (TypeError, ValueError): mal_id = None
	if not (anilist_id or mal_id): return None   # no id to resolve or cache it by
	item = {'id': anilist_id, 'idMal': mal_id, 'format': fmt, 'startDate': _date(start_date),
			'title': {'romaji': romaji or None, 'english': english or None, 'native': native or None}, 'backup_source': source}
	if cover: item['coverImage'] = {'extraLarge': None, 'large': cover}
	return item


# ─── MyAnimeList (the user's client id, no login) ───────────────────────────

def _mal_request(spec):
	"""(path, params, season_filter) for a spec MAL answers faithfully, else None."""
	offset = (spec['page'] - 1) * spec['per_page']
	params = {'limit': spec['per_page'], 'offset': offset, 'fields': _MAL_FIELDS}
	if spec['kind'] == 'search':
		if len(spec['q']) < 3: return None   # MAL refuses shorter queries
		return 'anime', dict(params, q=spec['q']), None
	if spec['format']: return None
	if spec['season'] and spec['year']:
		season = _SEASON_NAMES.get(spec['season'])
		if not season: return None
		sort = 'anime_score' if spec['order'] == 'score' else 'anime_num_list_users'
		return 'anime/season/%d/%s' % (spec['year'], season), dict(params, sort=sort), (spec['year'], season)
	if spec['year'] or spec['season']: return None
	ranking = {'popularity': 'bypopularity', 'score': 'all', 'favourites': 'favorite'}[spec['order']]
	return 'anime/ranking', dict(params, ranking_type=ranking), None


def _mal_answers(spec):
	from apis import mal_api
	return mal_api.mal_metadata_available() and _mal_request(spec) is not None


def _mal_page(spec):
	from apis import mal_api
	path, params, season_filter = _mal_request(spec)
	res = mal_api.call_mal(path, params=params, auth=False, timeout=6)
	if res is None: return {'success': False}
	items = []
	for row in res.get('data') or []:
		node = row.get('node') or {}
		# MAL's season list holds every show AIRING then (One Piece is in all of them); AniList's holds the ones that
		# STARTED then. Keep only those.
		if season_filter:
			start = node.get('start_season') or {}
			if (start.get('year'), start.get('season')) != season_filter: continue
		alt = node.get('alternative_titles') or {}
		item = _item('mal', _anilist_for_mal(node.get('id')), node.get('id'), _MAL_FORMATS.get(node.get('media_type')),
				node.get('title'), alt.get('en'), alt.get('ja'), node.get('start_date'),
				(node.get('main_picture') or {}).get('large') or (node.get('main_picture') or {}).get('medium'))
		if item: items.append(item)
	return {'items': items, 'has_next': bool((res.get('paging') or {}).get('next'))}


# ─── Kitsu (public, no key) ──────────────────────────────────────────────────

def _kitsu_params(spec):
	per_page = min(spec['per_page'], 20)   # Kitsu's page limit
	params = {'page[limit]': per_page, 'page[offset]': (spec['page'] - 1) * per_page, 'include': 'mappings',
			'fields[anime]': 'canonicalTitle,titles,subtype,startDate,posterImage,mappings',
			'fields[mappings]': 'externalSite,externalId'}
	if spec['kind'] == 'search':
		params['filter[text]'] = spec['q']
		return params
	if spec['format']:
		subtype = _KITSU_SUBTYPES.get(spec['format'])
		if not subtype: return None   # TV_SHORT
		params['filter[subtype]'] = subtype
	if spec['season']:
		season = _SEASON_NAMES.get(spec['season'])
		if not season: return None
		params['filter[season]'] = season
	if spec['year']: params['filter[seasonYear]'] = spec['year']
	dated = bool(spec['season'] or spec['year'])
	# Kitsu's ranks are all-time; within a season or year, sort on the counts themselves
	if spec['order'] == 'score': params['sort'] = '-averageRating' if dated else 'ratingRank'
	elif spec['order'] == 'favourites': params['sort'] = '-favoritesCount'
	else: params['sort'] = '-userCount' if dated else 'popularityRank'
	return params


def _kitsu_answers(spec): return _kitsu_params(spec) is not None


def _kitsu_page(spec):
	params = _kitsu_params(spec)
	try:
		r = _kitsu_session.get(_KITSU_URL % 'anime', params=params, timeout=15,
				headers={'Accept': 'application/vnd.api+json', 'Content-Type': 'application/vnd.api+json'})
		if not r.ok:
			logger('Kitsu', 'HTTP %s: %s' % (r.status_code, r.text[:200]))
			return {'success': False}
		res = r.json()
	except Exception as e:
		logger('Kitsu', safe_err(e))
		return {'success': False}
	mappings = {}
	for inc in res.get('included') or []:
		if inc.get('type') == 'mappings':
			a = inc.get('attributes') or {}
			mappings[inc.get('id')] = (a.get('externalSite'), a.get('externalId'))
	items = []
	for row in res.get('data') or []:
		a = row.get('attributes') or {}
		ext = {}
		for m in ((row.get('relationships') or {}).get('mappings') or {}).get('data') or []:
			site, ext_id = mappings.get(m.get('id'), (None, None))
			if site and ext_id: ext.setdefault(site, ext_id)
		mal_id = ext.get('myanimelist/anime')
		titles = a.get('titles') or {}
		item = _item('kitsu', ext.get('anilist/anime') or _anilist_for_mal(mal_id), mal_id, _KITSU_FORMATS.get(a.get('subtype')),
				titles.get('en_jp') or a.get('canonicalTitle'), titles.get('en') or titles.get('en_us'), titles.get('ja_jp'),
				a.get('startDate'), (a.get('posterImage') or {}).get('large') or (a.get('posterImage') or {}).get('medium'))
		if item: items.append(item)
	return {'items': items, 'has_next': bool((res.get('links') or {}).get('next'))}


# ─── Entry point ─────────────────────────────────────────────────────────────

_SOURCES = (('mal', _mal_answers, _mal_page), ('kitsu', _kitsu_answers, _kitsu_page))


def _cache_key(source, spec):
	# _v2 (2026-10-22): pages carry coverImage now; a v1 page (12 h) would have shown fanart.tv / TMDb posters until it lapsed
	return 'anime_backup_v2_%s_%s' % (source, '_'.join('%s=%s' % (k, spec[k]) for k in sorted(spec)))


def _announce(source):
	"""One toast per Kodi session -- the same property AniList's own outage warning uses, so it is one or the other."""
	logger('anime backup', 'AniList did not answer; this list came from %s' % _SOURCE_NAMES[source])
	if get_property('deadlight.anilist.outage_warned') == 'true': return
	set_property('deadlight.anilist.outage_warned', 'true')
	notification('AniList is not answering - anime lists from %s for now' % _SOURCE_NAMES[source], 5000)


def page(variables, first=None, announce=True):
	"""{'items': [...], 'has_next': bool} for an AniList page, or {} when no source here has it.
	first: the source to ask before the other ('mal' / 'kitsu') -- LOCAL PATCH 2026-10-22, the Anime Catalogues setting
	(anilist_api._cached_page asks here BEFORE AniList then, and only falls back to AniList if both fail). announce=False
	there: a list the user chose a service for is no outage, so no toast."""
	spec = _spec(variables)
	if not spec: return {}
	sources = sorted(_SOURCES, key=lambda s: s[0] != first) if first else _SOURCES
	for source, answers, fetch in sources:
		if not answers(spec) or cooldown_active(_COOLDOWN_PROP % source): continue
		def _fetch(_dummy, _fetch_page=fetch, _spec=spec):
			res = _fetch_page(_spec)
			# answered with nothing and no further page: past the end (kept 0.3 h, as an empty AniList page is). A MAL
			# season page can hold only carried-over shows and still have a next one, so that is kept as it is.
			if not is_failed_result(res) and not res.get('items') and not res.get('has_next'): return {}
			return res
		try: result = lists_cache_object(_fetch, _cache_key(source, spec), 1, expiration=_CACHE_HOURS)
		except Exception: result = {'success': False}
		if is_failed_result(result):
			start_cooldown(_COOLDOWN_PROP % source, _COOLDOWN_SECS)
			logger('anime backup', '%s did not answer - not asked again for %d min' % (_SOURCE_NAMES[source], _COOLDOWN_SECS // 60))
			continue
		if not result: return {}   # past the end: no other source pages in step with this one
		if announce: _announce(source)
		return result
	return {}
