# ported from Gears (script.module.gearsscrapers 1.6.2), itself from Starfleet's torrent_sources.py
"""
	DeadLight magneto -- LOCAL PATCH 2026-10-14

	torrentdownloads.pro's RSS search feed: one request returns info_hash, title, size and seeders per row, no detail
	pages. A different site from torrentdownload.py (torrentdownload.info), which this network resets about half the time.
	Searched by NAME, so it also covers titles with no IMDb id. Measured live 2026-10-14 (gears_probe / gears_overlap):
	Sholay (1975) 48 rows, 46 of them not on Torrentio or apibay; Oppenheimer 49 (11 new); Reacher S02E01 20 (15 new);
	~1 s each. Uses self.items, not self.sources: assigning a list to self.sources hides the method (animetosho.py's trap).
"""

import re
from urllib.parse import quote
from html import unescape
from magneto.modules import client
from magneto.modules import source_utils

_RE_ITEM = re.compile(
	r'<info_hash>([a-fA-F0-9]{40})</info_hash>.*?'
	r'<title>(.+?)</title>.*?'
	r'<size>(\d+)</size>.*?'
	r'<seeders>(\d+)</seeders>',
	re.IGNORECASE | re.DOTALL)


class source:
	priority = 3
	pack_capable = False
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		self.language = ['en']
		self.base_link = 'https://www.torrentdownloads.pro'
		self.min_seeders = 0

	def sources(self, data, hostDict):
		self.items = []
		if not data: return self.items
		items_append = self.items.append
		try:
			aliases = data['aliases']
			year = data['year']
			if 'tvshowtitle' in data:
				title = data['tvshowtitle'].replace('&', 'and').replace('/', ' ').replace('$', 's')
				episode_title = data['title']
				hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
				air_date = data.get('premiered')   # LOCAL PATCH 2026-10-24: date-named releases (source_utils.air_date_pattern)
				cat = '8'
			else:
				title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
				episode_title = None
				hdlr = year
				air_date = None
				cat = '4'
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()

			query = '%s %s' % (title, hdlr)
			url = '%s/rss.xml?new=1&type=search&cid=%s&search=%s' % (self.base_link, cat, quote(query))
			html = client.request(url, timeout=10)
			if data.get('date_search') and air_date:   # LOCAL PATCH 2026-10-24: and by air date for a date-released show (source_utils.air_date_query) (one RSS feed read after the other)
				html = (html or '') + (client.request('%s/rss.xml?new=1&type=search&cid=%s&search=%s' % (self.base_link, cat, quote('%s %s' % (title, source_utils.air_date_query(air_date)))), timeout=10) or '')
			if not html: return self.items

			for m in _RE_ITEM.finditer(html):
				hash, name, size_b, seeders = m.group(1).lower(), m.group(2).strip(), int(m.group(3)), int(m.group(4))
				name = source_utils.clean_name(unescape(name))   # LOCAL PATCH 2026-10-15: RSS escapes '&' -- 'Law &amp; Order' failed the title check
				if not name: continue

				if not source_utils.check_title(title, aliases, name, hdlr, year, air_date=air_date): continue
				name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue
				if self.min_seeders > seeders: continue

				url_magnet = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
				quality, info = source_utils.get_release_quality(name_info, url_magnet)
				try:
					dsize, isize = source_utils._size('%.1f GB' % (size_b / 1073741824)) if size_b >= 1073741824 else source_utils._size('%d MB' % (size_b // 1048576))
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)

				items_append({'provider': 'torrentdownloads', 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name,
					'name_info': name_info, 'quality': quality, 'language': 'en', 'url': url_magnet, 'info': info,
					'direct': False, 'debridonly': True, 'size': dsize})
			return self.items
		except:
			source_utils.scraper_error('TORRENTDOWNLOADS')
			return self.items
