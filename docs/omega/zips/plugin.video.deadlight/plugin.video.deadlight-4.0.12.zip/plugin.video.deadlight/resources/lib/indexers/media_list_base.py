# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-19: the methods indexers/movies.Movies and indexers/tvshows.TVShows held byte-identical copies of.
# fetch_list / worker / _prefetch / __init__ are NOT here: the two have drifted on purpose (TV's is_random guard on Next
# Page, its exit_params handling, movie sets), see the 10-19 audit.
from modules import settings
from modules.utils import paginate_list


class MediaListBase:
	def _size_pool_for_cold_page(self):
		"""LOCAL PATCH 2026-10-03 (3.0.8): a TMDb list page that was not cached warmed SEARCH_POOL connections while it was
		fetched (tmdb_api._list_data); its details then use that many workers, as a search does."""
		try:
			from apis import tmdb_api
			if tmdb_api.LAST_LIST_COLD: self.search_pool = tmdb_api.SEARCH_POOL
		except Exception: pass

	def context_menu(self, context_menu_items):
		if self.custom_cm_menu:
			try: context_menu_items = sorted([i for i in context_menu_items if i[0] in self.cm_sort_order], key=lambda k: self.cm_sort_order[k[0]])
			except: pass
		return [i[1] for i in context_menu_items]

	def paginate_list(self, data, page_no):
		if settings.paginate(self.is_external):
			limit = settings.page_limit(self.is_external)
			data, total_pages = paginate_list(data, page_no, limit, self.paginate_start)
			if self.is_external: self.paginate_start = limit
		else: total_pages = 1
		return data, total_pages
