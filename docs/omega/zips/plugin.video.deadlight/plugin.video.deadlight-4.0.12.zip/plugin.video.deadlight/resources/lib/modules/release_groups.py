# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-25: known release groups, in one place for the two things that use them:
#   windows/sources.group_display  -- the picker's Group column, bold in its tier colour (since 2026-10-02)
#   sources.sort_results           -- 'Prefer Known Release Groups' (Settings > Results), the idea ported from Red Light
#                                     (The Red Wizard, its #219): a tie-break right after the quality key of the chosen
#                                     Results Sorting, so a known group never jumps quality and the filters are untouched.
#
# The tiers are DeadLight's own, not Red Light's shorter list: from TRaSH Guides (github.com/TRaSH-Guides/Guides,
# docs/json/{radarr,sonarr}/cf, read 2026-10-02), Radarr and Sonarr together: GOLD = tier 01 of Remux, UHD Bluray, HD
# Bluray and WEB; BLUE = their tiers 02-03; ANIME = Anime BD tiers 01-03 and Anime Web tiers 01-02, plus SeaDex's own best
# groups (releases.moe, read the same day: marked best >= 20 times and at least as often as alternative). A group in two
# lists takes the higher. Lower anime tiers (Erai-Raws, SubsPlease...) stay unlisted. Names are matched lower-case without
# '@' or edge dashes ('-ZR-' -> 'zr'). To refresh: re-read the same JSON files and rebuild these three tuples.
#
# The group is the row's release_group field (scrapers/external.process_sources fills it with the fansub group magneto's
# clean_name() cuts off the front of the name), else source_utils.release_group of its name. Measured on 939 cached names
# (2026-10-25): a group read from 56 % of films and 41 % of TV; anime went from 20 % to the fansub groups being kept.
from modules.source_utils import release_group

_TIER_GOLD = (
	'3l', 'abbie', 'ajp69', 'apex', 'atelier', 'bbq', 'bizkit', 'bluranium', 'blutonium', 'bmf', 'byndr', 'c0ke',
	'casstudio', 'chotab', 'cinephiles', 'cmrg', 'crfw', 'crisc', 'crud', 'ctrlhd', 'd-z0n3', 'dariush', 'decibel',
	'don', 'ebp', 'edph', 'flux', 'framestor', 'geek', 'gnome', 'hone', 'kings', 'kitsune', 'lolhd', 'madsky',
	'mainframe', 'monkee', 'ncmt', 'nosivid', 'ntb', 'ntg', 'piramidhead', 'pmp', 'pter', 'qoq', 'rawr', 'rtn', 'sic',
	't6d', 'tayto', 'tdd', 'tepes', 'thefarm', 'tnp', 'tommy', 'viethd', 'visum', 'w4nk3r', 'wildcat', 'zorosenpai',
	'zq')
_TIER_BLUE = (
	'12gaugeshotgun', '3ctweb', 'bhdstudio', 'bloom', 'btw', 'cinefeel', 'cit', 'coo7', 'db', 'deep', 'dooky',
	'dracula', 'ea', 'end', 'epsilon', 'ethics', 'fc', 'flights', 'gnomission', 'hallowed', 'hidt', 'hifi', 'hisd',
	'hqmux', 'ift', 'ijp', 'ika', 'it00nz', 'jetix', 'khn', 'kimchi', 'kralimarko', 'lazy', 'lord', 'miu', 'mzabi',
	'ninjacentral', 'npms', 'nyh', 'orbitron', 'phoenix', 'playbd', 'playhd', 'playweb', 'psig', 'ptp', 'randombytes',
	'roccat', 'rtfm', 'sa89', 'sbr', 'sdcc', 'sicfoi', 'sigma', 'slignome', 'smurf', 'sphd', 'spirit', 'sumvision',
	'surfinbird', 'swaglander', 't4h', 'toa', 'triton', 'tvsmash', 'vision', 'webdv', 'welp', 'xebec')
_TIER_ANIME = (
	'0x539', 'a&c', 'aergia', 'arc', 'arg0', 'arid', 'asakura', 'b00ba', 'baws', 'bbt-rmx', 'beatrice', 'beatrice-raws',
	'blackrose', 'cappybara', 'chucksmux', 'crucible', 'cunny', 'cunnysseur', 'cyan', 'cytox', 'dae', 'demihuman',
	'doc', 'fatesucks', 'fig', 'fle', 'flugel', 'foxtrot', 'gao', 'getittwisted', 'gsk_kun', 'half-baked', 'hatsubs',
	'hchcsen', 'headpatter', 'hydes', 'inka-subs', 'johntitor', 'jysze', 'kawatare', 'koala', 'kulot', 'lacroix',
	'lazyremux', 'legion', 'lostyears', 'lulu', 'lys1th3a', 'mald', 'mcballs', 'meakes', 'mehul', 'moxie', 'mtbb',
	'mysteria', 'nan0', 'nekotan', 'netaro', 'noiy', 'not-vodes', 'npz', 'ntrx', 'okay-subs', 'orphan', 'p9', 'pizza',
	'pmr', 'poopoo', 'rain', 'reza', 'rmx', 'rudy', 'sam', 'scy', 'sekkon', 'serendipity', 'setsugen', 'sgt', 'slyfox',
	'smol', 'solce', 'som', 'subsmix', 'sylvar', 'tenshi', 'ttga', 'uba', 'vodes', 'wap', 'yuri', 'z4st1n', 'zerobuild',
	'zr')
# tier ids, as windows/sources colours them (1 gold, 2 blue, 3 anime pink); a group in two lists takes the higher
GROUP_TIERS = dict([(g, 3) for g in _TIER_ANIME] + [(g, 2) for g in _TIER_BLUE] + [(g, 1) for g in _TIER_GOLD])
GROUP_TIERS['z0n3'] = GROUP_TIERS['d-z0n3']   # release_group reads D-Z0N3's own hyphen as the separator
# sort weight per tier id: gold first, blue next; an anime list never sorts against a film's, so anime only has to lead
# the unlisted groups
_BOOST = {1: 3, 2: 2, 3: 3}


def group_key(group):
	return (group or '').lower().replace('@', '').strip().strip('-')


def release_group_boost(item):
	"""0-3 for a row from a known group, 0 otherwise (never raises)."""
	try:
		tier = GROUP_TIERS.get(group_key(item.get('release_group')))
		if not tier:
			for key in ('name', 'display_name'):
				tier = GROUP_TIERS.get(group_key(release_group(item.get(key) or '')))
				if tier: break
		return _BOOST.get(tier, 0)
	except Exception: return 0
