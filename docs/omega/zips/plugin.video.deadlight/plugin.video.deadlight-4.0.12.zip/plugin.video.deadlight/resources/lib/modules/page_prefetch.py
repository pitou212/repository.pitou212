# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-10-02: warm the next page of a catalogue list after this one is on screen.
#
# Next Page on a TMDb / Trakt catalogue cost ~1.2 s: one list call plus ~20 cold TMDb detail calls, all before the
# directory could be delivered. A page whose list response and metas are already cached builds in ~50 ms. So while a
# page is built, fetch_list records how to get the NEXT page's ids (queue); deadlight.py calls run() once routing() has
# returned -- endOfDirectory has already delivered the list, as with the rating backfills -- and run() makes the same
# list call (filling the lists cache) and the same tvshow_meta / movie_meta calls (filling the meta cache).
#
# Only in-addon browsing: never on a widget call (widgets load in bursts, see metadata.flush_rating_backfills), never for
# searches (their art is deferred for the whole process) or random lists. Rating backfills the warm-up would trigger are
# queued and dropped, not run: the metas keep their stale stamps, so the backfills queue again when the page is
# actually opened -- a page nobody opens spends no OMDb / AniList quota.
_PENDING = None
_BUSY_PROP = 'deadlight.page_prefetch_busy'   # LOCAL PATCH 2026-10-16: '<start time>' while a prefetch runs, in any process
PROCESS_START = None

def queue(media_type, id_type, fetch_ids, **meta_kwargs):
	"""fetch_ids() -> the next page's ids, exactly as fetch_list would build self.list for it. LOCAL PATCH 2026-10-16:
	media_type 'mixed' (AniList lists: shows and films on one page) -> fetch_ids() gives (media_type, ids) pairs."""
	global _PENDING
	_PENDING = (media_type, id_type, fetch_ids, meta_kwargs)

def run():
	global _PENDING
	pending, _PENDING = _PENDING, None
	if not pending: return
	from modules import kodi_utils
	if kodi_utils.external(): return
	_warm_pending(pending)

def _warm_pending(pending):
	"""The warm itself -- run() for the page just browsed, warm_widget_pages() for a widget's next page."""
	import time
	from modules import kodi_utils, settings
	media_type, id_type, fetch_ids, meta_kwargs = pending
	monitor = kodi_utils.kodi_monitor()
	if monitor.abortRequested(): return
	from modules import metadata
	from modules.utils import get_datetime, get_current_timestamp, TaskPool
	start = time.time()
	kodi_utils.set_property(_BUSY_PROP, '%.3f' % start)
	metadata._DEFERRED = []   # swallow the rating backfills; see the note above
	try:
		ids = [i for i in (fetch_ids() or []) if i]
		if not ids: return
		pairs = ids if media_type == 'mixed' else [(media_type, i) for i in ids]
		if media_type == 'mixed': meta_kwargs = {}   # movie_meta takes no is_anime_list
		api_key, mpaa_region = settings.tmdb_api_key(), settings.mpaa_region()
		current_date, current_time = get_datetime(), get_current_timestamp()
		# LOCAL PATCH 2026-10-16: and the status chip of shows being / been watched -- their full chip asks TVmaze while the
		# row is built (metadata._tv_renewal, two requests a show), which a warm page still waited on: 2.1 s on three of six
		# Trakt pages (log 2026-10-16 21:23). Unwatched shows get the request-free light chip and need nothing here.
		watched = {}
		if any(mt == 'tvshow' for mt, _i in pairs):
			from modules import watched_status
			watched = watched_status.watched_info_tvshow(watched_status.get_database(settings.watched_indicators())) or {}
		def _warm(mt, _id):   # TaskPool unpacks each (media_type, id) pair into the arguments
			if monitor.abortRequested(): return
			function = metadata.tvshow_meta if mt == 'tvshow' else metadata.movie_meta
			meta = function(id_type, _id, api_key, mpaa_region, current_date, current_time, **meta_kwargs)
			# LOCAL PATCH 2026-10-16: unwatched ones too -- their light chip queues a TVmaze lookup (metadata._queue_tvmaze),
			# run below with the other prefetch work instead of being swallowed with the rating backfills
			if mt == 'tvshow' and isinstance(meta, dict): metadata.show_status_props(meta, light=str(meta.get('tmdb_id')) not in watched)
			# LOCAL PATCH 2026-10-25 (4.0.5): and an anime tile's season count. Since 10-24 it counts cours, which for a flat
			# TMDb season runs Fribb's repair -- the season's TMDb episode list + AniList air dates. Not warmed, a page of new
			# anime still waited on it: AniList Trending p2 cold 4.5 s, 2.8 s of it five season lists (2026-10-25 14:16).
			if mt == 'tvshow' and isinstance(meta, dict) and metadata.is_anime_check(meta): metadata.shown_season_count(meta)
		[i.join() for i in TaskPool().tasks(_warm, pairs, min(len(pairs), 6))]
		tvmaze = [item[0] for item in (metadata._DEFERRED or []) if item[3] == (metadata._tvmaze_backfill,)]
		if tvmaze and not monitor.abortRequested(): [i.join() for i in TaskPool().tasks(metadata._tvmaze_backfill, tvmaze, min(len(tvmaze), 4))]
		kodi_utils.logger('page prefetch', '%s: %d titles in %.2f s' % (media_type, len(ids), time.time() - start))
	except Exception as e: kodi_utils.logger('page prefetch', 'failed: %s' % e)
	finally:
		metadata._DEFERRED = None
		kodi_utils.clear_property(_BUSY_PROP)


# LOCAL PATCH 2026-10-25 (4.0.5): a WIDGET's next page, warmed later by the service. run() skips widget calls on purpose
# (widgets load in bursts; a hung Kodi once showed ~25 widget threads deadlocked on the GIL -- metadata.flush_rating_backfills),
# so Next Page on a widget was always cold: AniList Trending p2 opened from its widget, 5.43 s (log 2026-10-25 14:16:26; warm,
# 28 ms). Now a widget call only RECORDS its next page (note_widget_page: one window property, no network) and the service
# (WidgetPageWarmer) starts warm_widget_pages as a separate plugin call once no widget has loaded for _WIDGET_QUIET seconds
# and nothing plays -- each list at most once per _WIDGET_WARM_EVERY. AniList browse lists only: their next page is fully
# described by (browse_type, page) and is the slow case; a TMDb / Trakt widget's ids come from its builder's state.
_WIDGET_PAGES_PROP = 'deadlight.widget_pages'   # {key: {'kind', 'args'}} -- JSON, shared by every Kodi process
WIDGET_LAST_PROP = 'deadlight.widget_last'      # time of the last widget call (deadlight.py)
_WIDGET_WARMED_KEY = 'widget_pages_warmed'      # main_cache {key: time warmed}
_WIDGET_WARM_EVERY, _WIDGET_QUIET, _WIDGET_MAX = 6 * 3600, 30, 8

def note_widget_page(kind, args):
	try:
		import json
		from modules import kodi_utils
		try: pending = json.loads(kodi_utils.get_property(_WIDGET_PAGES_PROP) or '{}')
		except ValueError: pending = {}
		key = '%s:%s' % (kind, json.dumps(args, sort_keys=True))
		if key in pending: return
		pending[key] = {'kind': kind, 'args': args}
		kodi_utils.set_property(_WIDGET_PAGES_PROP, json.dumps(pending))
	except Exception: pass

def widget_pages_due():
	"""For the service: True when a recorded widget page is due and the widgets have been quiet for _WIDGET_QUIET s."""
	try:
		import json, time
		from modules import kodi_utils
		raw = kodi_utils.get_property(_WIDGET_PAGES_PROP)
		if not raw or raw == '{}': return False
		try: last = float(kodi_utils.get_property(WIDGET_LAST_PROP) or 0)
		except ValueError: last = 0
		return time.time() - last >= _WIDGET_QUIET
	except Exception: return False

def _anilist_browse_ids(args):
	from indexers.anilist_lists import browse_fetcher, _next_page_ids
	fetcher = browse_fetcher(args['browse_type'], args.get('genre'))[0]   # LOCAL PATCH 2026-10-27: genre widgets too
	return 'mixed', 'trakt_dict', lambda: _next_page_ids(fetcher, int(args['page']))

_WIDGET_KINDS = {'anilist_browse': _anilist_browse_ids}

def warm_widget_pages(params=None):
	"""Router entry (mode=page_prefetch.warm_widget_pages), started by the service. Takes the recorded pages, skips any list
	warmed in the last _WIDGET_WARM_EVERY, and warms the rest one after another -- stopping for playback or Kodi quitting."""
	import json, time
	from modules import kodi_utils
	from caches.main_cache import main_cache
	try: pending = json.loads(kodi_utils.get_property(_WIDGET_PAGES_PROP) or '{}')
	except ValueError: pending = {}
	kodi_utils.clear_property(_WIDGET_PAGES_PROP)
	now = time.time()
	warmed = dict((k, t) for k, t in (main_cache.get(_WIDGET_WARMED_KEY) or {}).items() if now - t < _WIDGET_WARM_EVERY)
	todo = [(k, v) for k, v in pending.items() if k not in warmed and v.get('kind') in _WIDGET_KINDS][:_WIDGET_MAX]
	if not todo: return
	monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
	done = 0
	for key, entry in todo:
		if monitor.abortRequested() or player.isPlayingVideo(): break
		warmed[key] = time.time()
		main_cache.set(_WIDGET_WARMED_KEY, warmed, expiration=_WIDGET_WARM_EVERY // 3600)
		try:
			media_type, id_type, fetch_ids = _WIDGET_KINDS[entry['kind']](entry['args'])
			_warm_pending((media_type, id_type, fetch_ids, {}))
			done += 1
		except Exception as e: kodi_utils.logger('page prefetch', 'widget page %s failed: %s' % (key, e))
	kodi_utils.logger('page prefetch', 'widget pages warmed: %d of %d recorded (%d skipped, warmed < %d h ago)'
		% (done, len(pending), len(pending) - len(todo), _WIDGET_WARM_EVERY // 3600))


# LOCAL PATCH 2026-10-16: one ###page timing### line per catalogue page browsed in the addon, to see where the wait goes:
# from this process's start (Kodi's own interpreter start-up is before it and not counted), the list request, the rows,
# how many titles came from the meta cache (a prefetched page: all of them) and whether a prefetch was still running
# in another process when this page started -- Next clicked before the previous page's prefetch was done.
def mark_start():
	global PROCESS_START
	import time
	PROCESS_START = time.time()

def page_marks():
	"""(now, prefetch busy since or None, meta counts) at the start of a page build."""
	import time
	from modules import kodi_utils
	from modules.metadata import META_COUNTS
	try: busy = float(kodi_utils.get_property(_BUSY_PROP) or 0) or None
	except ValueError: busy = None
	return time.time(), busy, dict(META_COUNTS)

def log_page(media_type, action, page_no, rows, marks, rows_start):
	import time
	from modules import kodi_utils
	from modules.metadata import META_COUNTS
	try:
		t0, busy, counts = marks
		now = time.time()
		cached, fetched = META_COUNTS['cached'] - counts['cached'], META_COUNTS['fetched'] - counts['fetched']
		startup = (' (+%.2f s start-up)' % (t0 - PROCESS_START)) if PROCESS_START else ''
		prefetch = (', a prefetch was still running (%.1f s in)' % (t0 - busy)) if busy else ''
		kodi_utils.logger('page timing', '%s %s p%s: %.2f s%s -- list %.2f s, rows %.2f s; %d rows, %d titles cached / %d from TMDb%s'
			% (media_type, action, page_no, now - t0, startup, (rows_start or now) - t0, now - (rows_start or now), rows, cached, fetched, prefetch))
	except Exception: pass
