# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-10-15: per-call reset of module state, for Reuse Language Invoker.

With reuselanguageinvoker=false (DeadLight's default) every plugin call is a fresh interpreter and none of this matters.
With it on, Kodi re-runs deadlight.py in the SAME interpreter: every module stays imported, and everything a module
decided or memoised "for this process" would carry into the next call -- a listing's deferral decision into a RunPlugin
action, one search's flags into the next, a settings value read once into every later call, a week-old Fribb index past
the service's weekly download (the service runs in its own interpreter, so this one never hears of it).

begin() runs first thing in every call (deadlight.py) and puts back what a fresh interpreter would have. It only touches
modules this interpreter has already imported (sys.modules) and imports nothing -- with reuse off nothing is loaded yet,
so it costs a dict lookup per module. Kept on purpose: HTTP sessions, the settings defaults list, content-addressed
memos (chips: a strip's file name hashes its content), and memos that time themselves out (source_utils' cached-page
memo and DMM token, 120 / 240 s).

Audit 2026-10-15 (module-level containers, `global` writers, settings read at import, daemon threads) -- a new piece
of per-process state belongs in _RESETS below."""
import os, sys

_RESETS = (
	# module, attribute, value (a callable is called with the module and returns the value)
	('modules.metadata', '_DEFERRED', lambda m: [] if m._listing_process() else None),
	('modules.metadata', '_DEFER_ART', False),
	('modules.metadata', '_SPLIT_COURS', None),            # settings snapshot (anime.split_cours)
	('apis.tmdb_api', '_LIGHT_SEARCH', False),
	('apis.tmdb_api', '_PREWARM', None),
	('apis.tmdb_api', 'LAST_LIST_COLD', False),
	('apis.tmdb_api', '_LIST_WARMED', False),             # LOCAL PATCH 2026-10-20
	('modules.page_prefetch', '_PENDING', None),
	('modules.scrape_prewarm', '_PENDING', None),
	('modules.kodi_utils', '_kodi_monitor_instance', None),
	('modules.kodi_utils', '_kodi_player_instance', None),
)

_CLEARS = (
	# module, container attribute -- emptied in place (callers may hold a reference to it)
	('apis.anilist_api', '_SCORES_PRIMED'),
	('apis.fanart_api', '_SETTINGS'),                      # settings snapshot (fanarttv.enabled / key)
	('apis.fanart_api', '_MEMO'),
	('modules.metadata', '_SETTING_MEMO'),                 # settings snapshot (tv / anime air-time choices, 30 s)
	('modules.settings', '_GRACE_MEMO'),                   # settings snapshot (episodes.air_grace, 30 s)
	('apis.tvdb_api', '_MEMO'),
	('apis.tvdb_api', '_PATH_MEMO'),                       # LOCAL PATCH 2026-10-20: shared /extended answers
	('indexers.episodes', '_TVDB_POSTER_MEMO'),
	('modules.kodi_utils', '_ROW_ERRORS_SEEN'),
	('windows.sources', '_build_times'),
)

_fribb_stamp = [None]


def begin():
	modules = sys.modules
	for name, attr, value in _RESETS:
		module = modules.get(name)
		if module is None or not hasattr(module, attr): continue
		try: setattr(module, attr, value(module) if callable(value) else value)
		except Exception: pass
	for name, attr in _CLEARS:
		container = getattr(modules.get(name), attr, None)
		try: container.clear()
		except Exception: pass
	_introdb_inflight(modules.get('apis.introdb_api'))
	_fribb_freshness(modules.get('caches.fribb_mappings'))


def _introdb_inflight(module):
	"""Drop finished prefetches: a key left in _INFLIGHT makes prefetch_segments skip that episode for good."""
	inflight = getattr(module, '_INFLIGHT', None)
	if not inflight: return
	try:
		for key, (done, _thread) in list(inflight.items()):
			if done.is_set(): inflight.pop(key, None)
	except Exception: pass


def _fribb_freshness(module):
	"""Reload the Fribb index when the service has replaced its file since this interpreter loaded it."""
	if module is None: return
	try:
		stamp = tuple(os.path.getmtime(f) if os.path.exists(f) else 0 for f in (module._SLIM_FILE, module._MAPPINGS_FILE))
	except Exception: return
	if _fribb_stamp[0] is not None and stamp != _fribb_stamp[0]:
		try: module.clear_cache()
		except Exception: pass
	_fribb_stamp[0] = stamp
