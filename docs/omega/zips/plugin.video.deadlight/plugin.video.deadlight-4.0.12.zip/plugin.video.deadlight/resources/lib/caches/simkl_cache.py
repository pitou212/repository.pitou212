# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-29: SIMKL cache module — same-shape as mdblist_cache.py.
# KV blob table `simkl_data` + watched + progress + watched_status tables so
# SIMKL can be selected via watched_indicators == 3 the same way trakt (1) and
# mdblist (2) are.
from caches.base_cache import connect_database, kv_encode, kv_decode, ProviderCache


# LOCAL PATCH 2026-10-19: the class body lives in base_cache.ProviderCache (shared with Trakt / MDBList; adds allow_empty).
# keep_local_progress: SIMKL has no resume-point API (see ProviderCache).
class SimklCache(ProviderCache):
	def __init__(self): ProviderCache.__init__(self, 'simkl_db', 'simkl_data', keep_local_progress=True)


simkl_cache = SimklCache()


# ═══════════════════════════════════════════════════════════════════════════
#  List caching (per-list-type keyed) — populated by indexers/simkl_lists.py
#  Follows mdblist_cache.simkl_cache_object pattern.
# ═══════════════════════════════════════════════════════════════════════════

def simkl_cache_object(function, string, *args, expiration=None):
	"""Read-through cache for arbitrary SIMKL fetches. Same signature as
	trakt_cache.trakt_cache_object so callers stay uniform."""
	result = simkl_cache.get(string)
	if result is not None: return result
	result = function(*args)
	if result is not None:
		simkl_cache.set(string, result)
	return result


# ═══════════════════════════════════════════════════════════════════════════
#  Cache invalidation — called on write ops and by SIMKLMonitor when activity
#  timestamps change.
# ═══════════════════════════════════════════════════════════════════════════

def clear_simkl_list(list_type, status=None):
	"""Clear a single cached list. list_type in {movies, shows, anime}. status optional."""
	string = 'simkl_%s_%s' % (list_type, status) if status else 'simkl_%s' % list_type
	try:
		dbcon = connect_database('simkl_db')
		if status:
			dbcon.execute('DELETE FROM simkl_data WHERE id=?', (string,))
		else:
			dbcon.execute('DELETE FROM simkl_data WHERE id LIKE ?', ('simkl_%s_%%' % list_type,))
	except: pass


def clear_simkl_lists_cache():
	"""Nuke all cached lists — called by SIMKLMonitor when /sync/activities
	shows any timestamp change. Preserves watched/progress tables (those are
	rebuilt by the next indicators-sync)."""
	try:
		dbcon = connect_database('simkl_db')
		dbcon.execute('DELETE FROM simkl_data')
	except: pass