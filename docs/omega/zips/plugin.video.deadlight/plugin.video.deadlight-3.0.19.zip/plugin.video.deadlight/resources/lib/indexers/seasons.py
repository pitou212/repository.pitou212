# -*- coding: utf-8 -*-
import sys
import re
from modules import kodi_utils, settings
from modules.metadata import tvshow_meta, season_trailer_for, display_genres
from modules.utils import get_datetime, adjust_premiered_date, TaskPool
from modules.watched_status import get_database, watched_info_season, get_watched_status_season, get_progress_status_season, watched_info_episode
# logger = kodi_utils.logger

# LOCAL PATCH 2026-08-27: anime cours as season rows.
#
# TMDb groups anime by its own season layout, which is often not how the show
# aired. Frieren is one TMDb season of 38 episodes but two cours of 28 and 10, so
# TMDb episode 30 is really cour 2 episode 2. Fribb already records the boundaries
# offline, so the season list can show one row per cour with no extra service.
#
# This is presentation only. (season, episode) stays TMDb's everywhere it is used
# as an identity -- play urls, watched state, bookmarks, Trakt/Simkl sync and the
# scrapers -- because renumbering those would orphan existing watch history.
def _aired_per_season(season_data, total_seasons, total_aired_eps):
	"""{season_number: aired episode count}, mirroring the running total the
	season loop keeps: every season but the last reports its full TMDb count, and
	the last gets whatever is left of total_aired_eps."""
	out, acc = {}, 0
	# Ascending order matters: the running total is what decides how much of the
	# final season has actually aired.
	for item in sorted(season_data, key=lambda i: i.get('season_number') or 0):
		sn, ec = item.get('season_number'), item.get('episode_count') or 0
		if sn is None or sn == 0: continue
		if sn < total_seasons:
			out[sn] = ec
			acc += ec
		else: out[sn] = (total_aired_eps or 0) - acc
	return out


def _cour_watched_count(episode_rows, season_number, offset, length):
	"""How many episodes of one cour are watched.

	watched_info_season() only counts per TMDb season, which cannot be split, so
	the per-episode rows are counted directly. Rows are (season, episode) with
	TMDb numbering, so the cour covers offset+1 .. offset+length."""
	if not episode_rows: return 0
	total = 0
	for row in episode_rows:
		try: s, e = int(row[0]), int(row[1])
		except (TypeError, ValueError, IndexError): continue
		if s == season_number and offset < e <= offset + length: total += 1
	return total


def _prefetch_anizip(tmdb_id):
	"""LOCAL PATCH 2026-10-20: the ani.zip answers this show's episode map will read, fetched AT ONCE before the per-season
	loop asks them one by one. A cold older anime (Psycho-Pass: 3 seasons) spent 2.16 s of a 3.6 s first season list on
	three ani.zip requests in a row. Only answers not cached yet, at most 8 at once, once per show a week; it only fills
	the cache -- the map is built by the same code from it afterwards."""
	try:
		from threading import Thread
		from caches import fribb_mappings, anizip_mappings
		from caches.lists_cache import lists_cache
		# once per show a week: a long-running show's Fribb rows include OVAs / specials the map may never read, and
		# without this each visit would fetch the next 8 of them
		flag = 'anizip_prefetched_%s' % tmdb_id
		if lists_cache.get(flag): return
		lists_cache.set(flag, 1, expiration=168)
		todo, seen = [], set()
		for row in fribb_mappings.tmdb_tv_to_fribb_rows(int(tmdb_id)) or []:
			pair = (row.get('anilist_id'), row.get('anidb_id'))
			if not any(pair) or pair in seen: continue
			seen.add(pair)
			key = ('anilist_id', pair[0]) if pair[0] else ('anidb_id', pair[1])
			if lists_cache.get(anizip_mappings._CACHE_KEY % key) is None: todo.append(pair)
		threads = [Thread(target=anizip_mappings.anizip_entry_dates, args=pair) for pair in todo[:8]]
		for t in threads: t.start()
		for t in threads: t.join(15)
	except Exception: pass

def _expand_anime_cours(meta, season_data):
	"""season_data with multi-cour seasons replaced by one entry per cour.

	Returns the list unchanged when the setting is off, the show is not anime, or
	Fribb has no split for any of its seasons -- so non-anime and single-cour shows
	keep the existing code path exactly.
	"""
	if not settings.anime_split_cours(): return season_data
	try:
		from modules.metadata import is_anime_check
		if not is_anime_check(meta): return season_data
		from caches import fribb_mappings
		if not fribb_mappings.is_available(): return season_data
	except Exception: return season_data
	tmdb_id = meta.get('tmdb_id')
	_prefetch_anizip(tmdb_id)   # LOCAL PATCH 2026-10-20
	split = {}
	for item in season_data:
		sn = item.get('season_number')
		if not sn: continue      # never split specials
		try: cours = fribb_mappings.cours_for_tmdb_season(tmdb_id, sn, item.get('episode_count') or 0)
		except Exception: cours = []
		if cours: split[sn] = cours
	# LOCAL PATCH 2026-10-09: one row per RELEASE season (Fribb's season.tvdb), not per AniList entry. A TMDb season is
	# split only where the release season changes -- Frieren S1 (tvdb 1 + 2), Re:ZERO S1 (tvdb 1-4) -- and the cours of
	# one release season are merged back: JoJo's Battle in Egypt was a row beside Stardust Crusaders, and Stone Ocean
	# was 'STONE OCEAN' / 'Season 5 Part 2' / 'Season 5 Part 3' for one season TMDb already names. Measured over 11
	# shows: JoJo 9 -> 6 rows, Re:ZERO 5 -> 4, Dr. STONE 7 -> 4, Mushoku 5 -> 3; Frieren, Apothecary, JJK unchanged.
	# One bulk AniList request names every cour of the show; each id is also written
	# to the per-id cache, so later single lookups never hit the network.
	# LOCAL PATCH 2026-08-27: the same bulk call now also returns each cour's cover
	# art, so every cour row can show its own poster instead of them all sharing the
	# TMDb season's. No extra request -- coverImage rides along in the query that was
	# already being made to name the cours.
	# LOCAL PATCH 2026-10-03 (Batch 4): by each cour's AniList id (Fribb's row names the exact entry), by MAL id only
	# for a cour without one. By MAL id, Steel Ball Run's 1st STAGE cour was labelled and postered as '2nd & 3rd
	# STAGE': MAL 61469 is both AniList entries. Keys are ('a', id) / ('m', id) -- the two id spaces overlap.
	titles, titles_en, art = {}, {}, {}
	def _ck(c): return ('a', int(c['anilist'])) if c.get('anilist') else ('m', int(c['mal'])) if c.get('mal') else None
	try:
		from apis.anilist_api import anilist_media_bulk, anilist_media_bulk_by_id
		all_cours = [c for cs in split.values() for c in cs]
		al_ids = [c['anilist'] for c in all_cours if c.get('anilist')]
		mal_ids = [c['mal'] for c in all_cours if c.get('mal') and not c.get('anilist')]
		recs = {}
		if al_ids: recs.update((('a', k), v) for k, v in (anilist_media_bulk_by_id(al_ids) or {}).items())
		if mal_ids: recs.update((('m', k), v) for k, v in (anilist_media_bulk(mal_ids) or {}).items())
		titles = {k: v.get('title') for k, v in recs.items() if v.get('title')}
		titles_en = {k: v.get('title_en') for k, v in recs.items() if v.get('title_en')}
		art = {k: v.get('poster') for k, v in recs.items() if v.get('poster')}
	except Exception: titles, titles_en, art = {}, {}, {}
	# LOCAL PATCH 2026-10-16: cours whose AniList titles name DIFFERENT seasons are not merged, even under one TVDB season.
	# TVDB files Bungou Stray Dogs as S1 = Seasons 1+2, S2 = Season 3, S3 = Seasons 4+5, so the list read 'Season 1' /
	# '3' / '4'. A title naming no season ('Bungou Stray Dogs', 'STONE OCEAN Part 2') belongs with the group before it
	# (the first one: season 1); 'Re:ZERO 2nd Season' and '... 2nd Season Part 2' still merge.
	for sn in list(split):
		groups = []
		for cour in split[sn]:
			try: rel = (fribb_mappings.find_cour_by_tmdb_coords(tmdb_id, sn, cour['offset'] + 1) or {}).get('cour_season')
			except Exception: rel = None
			named = _title_season(titles.get(_ck(cour)))
			ts = named if named is not None else (groups[-1]['ts'] if groups else 1)
			if groups and groups[-1]['rel'] == rel and groups[-1]['ts'] == ts:
				groups[-1]['cours'].append(cour)
			else: groups.append({'rel': rel, 'ts': ts, 'cours': [cour]})
		if len(groups) < 2:
			del split[sn]
			continue
		merged = []
		for g in groups:
			first = dict(g['cours'][0])
			first['length'] = sum(c['length'] for c in g['cours'])
			first['_merged'] = len(g['cours']) > 1
			# rows sharing this AniList season -- 1 means the row is a whole season, not 'Part N' of TVDB's grouping
			first['_ts_rows'] = sum(1 for g2 in groups if g2['ts'] == g['ts'])
			merged.append(first)
		split[sn] = merged
	if not split: return season_data
	out = []
	for item in season_data:
		cours = split.get(item.get('season_number'))
		if not cours:
			out.append(item)
			continue
		# the first cour's title is the show's base name in the same language as the
		# others, which makes it the best prefix to strip
		_get = lambda d, c: d.get(_ck(c))
		base_title = _get(titles, cours[0])
		base_en = _get(titles_en, cours[0])
		for cour in cours:
			entry = dict(item)
			entry['episode_count'] = cour['length']
			entry['_cour_offset'] = cour['offset']
			entry['_cour_len'] = cour['length']
			name = _get(titles, cour)
			# LOCAL PATCH 2026-09-23: label in English when AniList has it -- 'The Separation'
			# rather than 'Sennen Kessen-hen - Ketsubetsu-tan'. The prefix to trim must be in the
			# SAME language as the name, so a cour with no English title keeps the romaji pair
			# (and a base with none falls back to the romaji base, which then simply fails to
			# trim and hands over to the TMDb show title, as before).
			_name_en = _get(titles_en, cour)
			_base = base_title
			if _name_en: name, _base = _name_en, (base_en or base_title)
			info = {}
			try: info = fribb_mappings.find_cour_by_tmdb_coords(tmdb_id, item.get('season_number'), cour['offset'] + 1) or {}
			except Exception: pass
			# Falls back through TMDb's season poster to the show poster in _process().
			cour_art = _get(art, cour)
			if cour_art: entry['_cour_poster'] = cour_art
			# LOCAL PATCH 2026-08-29: keep the AniList id. `info` was already being fetched
			# for the label and this was thrown away, so Mark Watched had no way to reach
			# AniList -- see the mark_season push in watched_status.
			# A merged row spans several entries: no single id, so mark_season pushes each entry its own episodes.
			if info.get('anilist') and not cour.get('_merged'): entry['_cour_anilist'] = info['anilist']
			# LOCAL PATCH 2026-09-16: and its TVDB season number, so a cour can look up its
			# OWN TVDB season poster. `info` was already being fetched for the label, and
			# cour_season is Fribb's season.tvdb -- the number releases and TVDB both use.
			if info.get('cour_season') is not None: entry['_cour_tvdb_season'] = info['cour_season']
			if cour.get('_merged'):
				# the first part's name minus its 'Part 1' / 'Cour 1' -- the row is the whole release season
				name = _TRAILING_PART_RE.sub('', name or '') or None
				entry['_cour_title'] = _short_cour_label(name, _base, meta.get('title'), info.get('cour_season'), 1, 1,
					item.get('season_number'))
			else:
				_parts = 1 if cour.get('_ts_rows') == 1 else (info.get('cour_part_count') or len(cours))   # LOCAL PATCH 2026-10-16
				entry['_cour_title'] = _short_cour_label(
					name, _base, meta.get('title'), info.get('cour_season'),
					info.get('cour_part') or cour['index'], _parts,
					item.get('season_number'))
			entry['_cour_title'] = _numbered_label(entry['_cour_title'], info.get('cour_season'), _title_season(_get(titles, cour)))
			out.append(entry)
	return out


_SPECIAL_PREFIX = 'SP · '
def _special_rows(meta, season_data):
	"""LOCAL PATCH 2026-10-17: TMDb's Specials season as one row per run of specials, each placed between the seasons it aired
	between (setting anime.specials = 'In Airing Order').

	A run is consecutive specials sharing a name stem (fribb_mappings.special_groups: Monogatari's 49 become Ghostory, Tsubasa Cat,
	Nekomonogatari Kuro, Summary, Hanamonogatari, Tsukimonogatari, Koyomimonogatari ...). A row is a slice of season 0
	(_cour_offset / _cour_len, as a cour row is of its season), so its episode list, watched count and progress are that
	run's alone. It goes before the first season row that started after it; one that aired after every season goes last,
	one with no air date yet is left out. Cour rows are dated by their first episode (cached episode lists). Any failure
	leaves the list as the Specials folder would have."""
	try:
		special = next((i for i in season_data if i.get('season_number') == 0), None)
		if not special: return season_data
		from modules.metadata import episodes_meta
		from caches.fribb_mappings import special_groups   # LOCAL PATCH 2026-10-17: shared with the season-0 id map
		groups = special_groups(episodes_meta(0, meta) or [])
		if not groups: return season_data
		import datetime
		today = datetime.date.today().isoformat()
		def _day(e): return (e.get('premiered') or '')[:10]
		rows = [i for i in season_data if i.get('season_number') != 0]
		# each season row's start: TMDb's season date, or a cour's first episode
		starts, season_eps = [], {}
		for r in rows:
			start = r.get('air_date') or ''
			if r.get('_cour_offset'):
				sn = r.get('season_number')
				if sn not in season_eps:
					season_eps[sn] = dict((int(x['episode']), _day(x)) for x in (episodes_meta(sn, meta) or []) if x.get('episode'))
				start = season_eps[sn].get(int(r['_cour_offset']) + 1) or start
			starts.append(start[:10])
		out = list(rows)
		# oldest first: each lands right before the next season, after the runs already placed in the same gap
		for g in sorted(groups, key=lambda g: (_day(g['eps'][0]) or '9999', int(g['eps'][0]['episode']))):
			first = _day(g['eps'][0])
			if not first: continue
			entry = dict(special)
			entry.update({'episode_count': len(g['eps']), '_cour_offset': int(g['eps'][0]['episode']) - 1, '_cour_len': len(g['eps']),
						'_cour_title': '%s%s' % (_SPECIAL_PREFIX, g['stem']), 'air_date': first, 'name': g['stem'],
						'_special_aired': sum(1 for e in g['eps'] if _day(e) and _day(e) <= today)})
			if len(g['eps']) == 1 and g['eps'][0].get('plot'): entry['overview'] = g['eps'][0]['plot']
			at = next((k for k, s in enumerate(starts) if s and s > first), len(rows))
			# before that season's row (found by identity: two season dicts can compare equal), or at the end
			out.insert(next((k for k, r in enumerate(out) if r is rows[at]), len(out)) if at < len(rows) else len(out), entry)
		return out
	except Exception:
		from modules.kodi_utils import logger
		logger('anime specials', 'airing-order rows failed for tmdb %s' % meta.get('tmdb_id'))
		return season_data


_NUMBERED_LABEL_RE = re.compile(r'^season\s*(\d+)\b', re.I)


_TITLE_SEASON_RE = re.compile(r'(?i)(?<![a-z0-9])(?:(\d{1,2})(?:st|nd|rd|th)\s+season|season\s+(\d{1,2}))(?![a-z0-9])')


def _title_season(title):
	"""LOCAL PATCH 2026-10-16: the season an AniList (romaji) title names -- 'Bungou Stray Dogs 3rd Season' -> 3 -- or None."""
	m = _TITLE_SEASON_RE.search(title or '')
	return int(m.group(1) or m.group(2)) if m else None


def _numbered_label(label, release_season, title_season=None):
	"""LOCAL PATCH 2026-10-09: a bare 'Season N ...' label whose N is not the release season (season.tvdb) becomes
	'Season <release season>'. AniList's English title can be a streaming service's numbering: Tokyo Revengers' Tenjiku
	entry is 'Tokyo Revengers Season 2 Part 2', so the row read 'Season 2 Part 2' for TVDB season 3. A label whose number
	agrees, or that is a name ('War of the Three Titans Arc'), is kept."""
	m = _NUMBERED_LABEL_RE.match(label or '')
	if not m or not release_season or int(m.group(1)) == int(release_season): return label
	# LOCAL PATCH 2026-10-16: the entry's own AniList title says so ('Bungou Stray Dogs 3rd Season' under TVDB season 2)
	if title_season is not None and int(m.group(1)) == title_season: return label
	return 'Season %s' % release_season


_ROMAN_RE = re.compile(r'^[IVX]+$')
_SMALL_WORDS = {'a', 'an', 'and', 'as', 'at', 'by', 'for', 'in', 'of', 'on', 'or', 'the', 'to', 'vs'}


def _soft_caps(title):
	"""LOCAL PATCH 2026-10-09: a season name TMDb keeps in capitals, in title case -- JoJo's list read 'Phantom Blood & Battle
	Tendency', 'Golden Wind', then 'STONE OCEAN' and 'STEEL BALL RUN'. Only an all-capitals name with 4+ letters is touched
	(so 'SAO' or 'K' stay); Roman numerals and words with digits keep their case ('PART II' -> 'Part II'), small words go
	lower case after the first, and hyphenated parts are capitalised separately. Brand casing cannot be recovered: "JOJO'S"
	becomes "Jojo's", not "JoJo's"."""
	if not title: return title
	letters = [c for c in title if c.isalpha()]
	if len(letters) < 4 or title != title.upper(): return title
	words = title.split(' ')
	out = []
	for i, word in enumerate(words):
		if _ROMAN_RE.match(word) or any(c.isdigit() for c in word): out.append(word)
		elif i and word.lower() in _SMALL_WORDS: out.append(word.lower())
		else: out.append('-'.join(part[:1].upper() + part[1:].lower() for part in word.split('-')))
	return ' '.join(out)


_BARE_PART_RE = re.compile(r'^(?:part|cour)\s*\d+$', re.I)
_BARE_YEAR_RE = re.compile(r'^\(?(?:19|20)\d{2}\)?$')
_TRAILING_PART_RE = re.compile(r'[\s:\-–—]*(?:part|cour)\s*(?:\d+|one|1st)$', re.I)


def _trim_title_prefix(full, prefix):
	"""`full` with `prefix` and any separator removed, or None if it is not a prefix."""
	if not full or not prefix: return None
	if not full.lower().startswith(prefix.lower()): return None
	return full[len(prefix):].strip(' :-–—.·|/')


def _short_cour_label(full, base, show_title, cour_season, part, part_count, season_number):
	"""A season-row label with the show name taken off the front.

	LOCAL PATCH 2026-08-27. AniList gives the cour's whole name, which is mostly the
	show's: under Frieren the rows read 'Sousou no Frieren' and 'Sousou no Frieren 2nd
	Season'. The row already sits inside the show, so only the tail carries meaning.

	Trimming the FIRST cour's title first is what makes arc names survive -- Bleach's
	cours differ by 'Sennen Kessen-hen - Ketsubetsu-tan', which is worth showing and
	which a generic 'Part 2' would throw away.

	Falls back to the release season number (season.tvdb, so it matches what the
	episodes inside will be numbered as) rather than TMDb's."""
	candidates = []
	for prefix in (base, show_title):
		trimmed = _trim_title_prefix(full, prefix)
		if trimmed: candidates.append(trimmed)
	# Anything still long is the show's name in another language, not a cour marker.
	num = cour_season if cour_season else season_number
	for c in candidates:
		if len(c) > 40: continue
		# LOCAL PATCH 2026-10-12: a remake's AniList title carries its year ('Ranma1/2 (2024)'), so the trim left the row
		# reading '(2024)'. A year on its own says nothing the row needs.
		if _BARE_YEAR_RE.match(c): continue
		# 'Part 2' on its own repeats across seasons -- Attack on Titan would list two
		# rows both reading 'Part 2'. Named arcs ('Ketsubetsu-tan') are already unique,
		# so only the bare markers get the season put back in front.
		if _BARE_PART_RE.match(c): return 'Season %s %s' % (num, c)
		# LOCAL PATCH 2026-10-16: an English title that is the show's name plus a number ('Bungo Stray Dogs 3') left a bare '3'
		if c.isdigit() and len(c) <= 2: return 'Season %s' % c
		return c
	# Nothing distinguishing left (usually cour 1, whose title IS the show title).
	if part_count and part_count > 1: return 'Season %s Part %s' % (num, part)
	return 'Season %s' % num


def _warm_season_art(meta, current_date=None, current_time=None):
	"""LOCAL PATCH 2026-10-20: run after a season list is on screen (metadata._DEFERRED) for a show whose fanart.tv / TVDB
	season art was not cached: fetches both at once, so the next visit has them. Nothing is shown from here."""
	try:
		from threading import Thread
		from modules.metadata import is_anime_check
		tvdb_id = meta.get('tvdb_id')
		mode = str(settings.get_setting('deadlight.%s.artwork_provider' % ('anime' if is_anime_check(meta) else 'tvshow'), '0'))
		thread = None
		if mode in ('1', '2', '3'):
			from apis.tvdb_api import season_posters
			thread = Thread(target=season_posters, args=(tvdb_id,))
			thread.start()
		if mode == '3':
			from apis.fanart_api import fanart_season_art
			fanart_season_art(tvdb_id)
		if thread is not None: thread.join(25)
	except Exception: pass

def build_season_list(params):
	def _process():
		total_aired_eps, episode_count = meta_get('total_aired_eps'), 0
		for item in season_data:
			try:
				cm = []
				cm_append = cm.append
				listitem = make_listitem()
				set_properties = listitem.setProperties
				item_get = item.get
				overview, poster_path, air_date = item_get('overview'), item_get('poster_path'), item_get('air_date')
				season_number, aired_eps = item_get('season_number'), item_get('episode_count')
				season_special = season_number == 0
				# A cour row carries the TMDb season it lives in plus its slice of it. Its
				# aired count has to be settled here, before `unaired` is derived below, so
				# that a cour which has not started yet is greyed out like an unaired season.
				cour_offset, cour_len = item_get('_cour_offset'), item_get('_cour_len')
				is_cour = cour_offset is not None
				if is_cour and item_get('_special_aired') is not None: aired_eps = item_get('_special_aired')   # LOCAL PATCH 2026-10-17
				elif is_cour:
					aired_eps = max(0, min(cour_len, aired_map.get(season_number, cour_len) - cour_offset))
				else:
					# LOCAL PATCH 2026-09-12: a plain season needs its aired count settled here
					# too. TMDb's `episode_count` is the season's DECLARED length, not how much
					# of it has aired, and an announced-but-unaired season is published with a
					# placeholder count of 1 -- so `unaired = aired_eps == 0` below was never
					# true for one and `episodes.include_unaired = false` never dropped it.
					# The running-total correction further down computes the real figure, but
					# it runs AFTER the drop test, far too late to prevent the row.
					# Observed 2026-09-12: Reincarnated as a Sword S2 (airs 2026-10-08) and
					# Blue Box S2 (airs 2026-10-04) both listed with 0 playable episodes. On
					# Blue Box it also produced a DUPLICATE "Season 2" -- its 25-episode TMDb
					# S1 splits into two cour rows that display as Season 1 and Season 2, so
					# the phantom TMDb S2 collided with the second cour.
					# max(0, ...) like the cour branch: the last season's figure is a
					# subtraction and can come out NEGATIVE when TMDb's declared counts
					# overshoot total_aired_eps (Stuart Fails to Save the Universe: S1
					# declares 10, only 8 aired, so S2 computes to -2). Unclamped, the
					# `aired_eps == 0` test below would read -2 as "aired" and surface a
					# season that was previously hidden.
					aired_eps = max(0, aired_map.get(season_number, aired_eps))
				# LOCAL PATCH 2026-08-26: this season's own trailer when TMDb has one
				# (~54% do), else the show trailer hoisted below.
				season_trailer = season_trailer_for(meta, season_number, trailer)
				if is_cour: title = _soft_caps(item_get('_cour_title'))
				elif use_name: title = _soft_caps(item_get('name', None)) or 'Season %s' % season_number
				else: title = 'Season %s' % season_number
				if custom_order is not None: title = '%s - %s' % (show_title, title)
				# LOCAL PATCH 2026-08-27: a cour gets its own AniList cover. Without this every
				# cour of one TMDb season showed that season's single poster, so Bleach's
				# Thousand-Year Blood War cours were indistinguishable in the list.
				poster = 'https://image.tmdb.org/t/p/w500%s' % poster_path if poster_path is not None else show_poster
				# LOCAL PATCH 2026-09-14: TVDB's season poster, when TVDB is the chosen provider.
				# Sits BELOW the AniList cour cover deliberately: a cour cover identifies one
				# cour, a TVDB season poster only identifies the TMDb season those cours share,
				# so letting it win would undo the 2026-08-27 fix that made Bleach's
				# Thousand-Year Blood War cours distinguishable from each other.
				# LOCAL PATCH 2026-09-16: key on the COUR's tvdb season when there is one.
				# Keying on season_number handed every cour of a TMDb season the same TVDB
				# poster, which for Re:ZERO -- one TMDb season covering four cours -- meant
				# all four showed TVDB season 1's. Fribb's season.tvdb is 1,2,2,3,4 for them.
				# LOCAL PATCH 2026-09-26: TVDB and/or fanart.tv, merged in provider order -- see
				# _season_posters where it is built. The same cour key picks the season landscape.
				_cs = item_get('_cour_tvdb_season')
				if _season_posters:
					poster = (_season_posters.get(_cs) if _cs is not None else None) 							 or _season_posters.get(season_number) or poster
				season_landscape = ((_season_landscapes.get(_cs) if _cs is not None else None)
									or _season_landscapes.get(season_number) or show_landscape)
				poster = item_get('_cour_poster') or poster
				thumb = poster or show_landscape or show_fanart
				try: year = air_date.split('-')[0]
				except: year = show_year or '2050'
				plot = overview or show_plot
				try: premiered = adjust_premiered_date(air_date, adjust_hours)[1]
				except: premiered = ''
				unaired = aired_eps == 0
				# LOCAL PATCH 2026-08-29: a season with zero aired episodes has nothing to
				# play, so it is dropped rather than listed red-italicised -- matching what
				# the episode list now does, and what POV's show_unaired does for both.
				# Specials are exempt: season 0 legitimately holds already-aired OVAs and
				# shorts, and aired_eps can read 0 for them through missing air dates.
				# continue, NOT return: _process() loops over season_data, so returning would
				# also drop every season AFTER the first unaired one.
				# LOCAL PATCH 2026-09-12: never drop under custom_order. That path filters
				# season_data to one requested season and the caller takes list_items[0]
				# (Trakt lists, Continue Watching), so dropping it raises IndexError instead
				# of hiding a row. Rare before, because aired_eps came from TMDb and was
				# almost never 0; routine now that the real aired count is used above.
				if unaired and not season_special and not include_unaired and custom_order is None: continue
				# LOCAL PATCH 2026-09-03 (Red Light 2.3.1 port): Specials gets its own branch and
				# its own counts. It used to share the unaired branch, which was wrong twice over.
				#
				# First, that branch assigned `total_watched, total_unwatched` -- names used NOWHERE
				# else in this file. The values the row actually renders are `watched`/`unwatched`
				# (see set_properties below), which the branch never touched, so they kept whatever
				# the PREVIOUS loop iteration left behind. season_data sorts Specials last, so the
				# Specials row reliably showed the latest regular season's tally -- Red Light's
				# report of 'S5 10/10' appearing as 'Specials 10/37'. The intended zeroing never
				# happened either; it was written to the dead names.
				#
				# Second, zeroing is not what Specials wants. Season 0 holds real, already-aired
				# OVAs and shorts that can legitimately be watched, so it is counted like any other
				# season. Only a genuinely unaired season has nothing to count.
				if unaired:
					progress, playcount, watched, unwatched = 0, 0, 0, aired_eps
					title = '[COLOR red][I]%s[/I][/COLOR]' % title
				elif season_special and not is_cour:
					title = 'Specials'
					playcount, watched, unwatched = get_watched_status_season(watched_info.get(season_number, None), aired_eps)
					progress = get_progress_status_season(watched, aired_eps)
				else:
					if is_cour:
						# watched_info_season() counts per TMDb season and cannot be sliced,
						# so a cour is counted from the per-episode rows instead.
						playcount, watched, unwatched = get_watched_status_season(
							_cour_watched_count(episode_watched_rows, season_number, cour_offset, cour_len), aired_eps)
					else:
						# LOCAL PATCH 2026-10-15: aired_eps was settled above from aired_map, which runs this same
						# running total over the UNSPLIT TMDb seasons. Recomputing it here as total_aired_eps minus
						# a running count that only plain rows advanced gave the last season the episodes of any
						# earlier season shown as cour rows (TMDb S1 of 24 as two cours + S2 with 5 aired: S2
						# showed 29 episodes, 5 watched read 17 %).
						playcount, watched, unwatched = get_watched_status_season(watched_info.get(season_number, None), aired_eps)
					progress = get_progress_status_season(watched, aired_eps)
				visible_progress = 0 if progress == 100 else progress
				_ep_list_params = {'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': season_number}
				# `season` stays the TMDb one -- the cour is expressed as a slice of it.
				if is_cour: _ep_list_params.update({'cour_offset': cour_offset, 'cour_len': cour_len,
					  'cour_title': title, 'cour_poster': item_get('_cour_poster') or ''})
				url_params = build_url(_ep_list_params)
				extras_params = build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'tvshow', 'is_external': is_external, 'season': season_number})
				options_params = build_url({'mode': 'options_menu_choice', 'content': 'season', 'tmdb_id': tmdb_id, 'poster': show_poster, 'is_external': is_external})
				cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
				cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
				# LOCAL PATCH 2026-08-29: cour rows get Mark Watched/Unwatched again.
				#
				# They were suppressed because mark_season took only a season number and would
				# have marked the sibling cours too -- Reincarnated as a Slime season 2 is two
				# cours of 12, so marking part 2 would also have marked part 1. mark_season now
				# takes the range and pushes an episode list, so the mark is exact and the
				# suppression is no longer needed.
				_mark_params = {'mode': 'watched_status.mark_season', 'title': show_title, 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season_number}
				if is_cour: _mark_params.update({'cour_offset': cour_offset, 'cour_len': cour_len})
				# AniList counts progress WITHIN an entry, and an entry is one cour, so the
				# push needs the entry id and how many episodes complete it. For an unsplit
				# season the entry is the whole season, resolved in mark_season from S/E 1.
				_al = item_get('_cour_anilist')
				if _al: _mark_params['anilist_id'] = _al
				if playcount:
					if hide_watched: continue
				elif not unaired:   # LOCAL PATCH 2026-10-19: specials too -- mark_season takes season 0 now
					cm_append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url(dict(_mark_params, action='mark_as_watched')))])
				if progress:
					cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url(dict(_mark_params, action='mark_as_unwatched')))])
				set_properties({'watchedepisodes': str(watched), 'unwatchedepisodes': str(unwatched)})
				set_properties({'totalepisodes': str(aired_eps), 'watchedprogress': str(visible_progress),
								'deadlight.extras_params': extras_params, 'deadlight.options_params': options_params})
				if is_external:
					cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
							['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
				if custom_cm_menu:
					try: cm = sorted([i for i in cm if i[0] in cm_sort_order], key=lambda k: cm_sort_order[k[0]])
					except: pass
				cm = [i[1] for i in cm]
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setMediaType('season'), info_tag.setTitle(title), info_tag.setOriginalTitle(orig_title), info_tag.setTvShowTitle(show_title), info_tag.setIMDBNumber(imdb_id)
				# A cour row still lives in its TMDb season, but should present the season
				# number releases use -- both Frieren cours are TMDb season 1.
				_display_season = season_number
				if is_cour and not season_special:
					try:
						from modules.metadata import cour_display_numbers
						_display_season = cour_display_numbers(meta, season_number, cour_offset + 1)[0]
					except Exception: pass
				info_tag.setSeason(_display_season), info_tag.setPlot(plot), info_tag.setDuration(episode_run_time), info_tag.setPlaycount(playcount), info_tag.setGenres(genre)
				info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str_tmdb_id, 'tvdb': str_tvdb_id})
				info_tag.setTvShowStatus(status), info_tag.setFirstAired(premiered), info_tag.setStudios(studio), info_tag.setYear(int(year))
				info_tag.setRating(rating), info_tag.setVotes(votes), info_tag.setMpaa(mpaa), info_tag.setCountries(country), info_tag.setTrailer(season_trailer)
				info_tag.setCast([kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
				listitem.setLabel(title)
				# LOCAL PATCH 2026-09-14: season./tvshow. art keys dropped, see the note at _art in indexers/episodes.py.
				# LOCAL PATCH 2026-09-15: season rows inherit the show's extra_fanart_list, the same
				# way episode rows have since 2026-08-06. They were the one row type with no fanartN
				# at all, so AF3's artwork gallery was empty on a season.
				_season_art = {'poster': poster, 'fanart': show_fanart, 'clearlogo': show_clearlogo,
								'landscape': season_landscape, 'thumb': thumb, 'icon': season_landscape}
				for _idx, _bg in enumerate(show_extra_fanart, start=1): _season_art['fanart%d' % _idx] = _bg
				listitem.setArt(_season_art)
				listitem.addContextMenuItems(cm)
				yield (url_params, listitem, True)
			except: kodi_utils.log_row_error('seasons')
	kodi_actor, make_listitem, build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
	poster_empty, fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	watched_indicators, adjust_hours, hide_watched = settings.watched_indicators(), settings.date_offset(), is_external and settings.widget_hide_watched()
	current_date = get_datetime()
	cm_sort_order = settings.cm_sort_order()
	custom_cm_menu = cm_sort_order != settings.cm_default_order()
	rpdb_info = settings.rpdb_info('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	use_name = settings.use_season_name()
	include_unaired = settings.include_unaired_episodes()
	meta = tvshow_meta('tmdb_id', params['tmdb_id'], settings.tmdb_api_key(), settings.mpaa_region(), current_date)
	meta_get = meta.get
	tmdb_id, tvdb_id, imdb_id, show_title, show_year = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id'), meta_get('title'), meta_get('year') or '2050'
	orig_title, status, show_plot = meta_get('original_title', ''), meta_get('status'), meta_get('plot')
	str_tmdb_id, str_tvdb_id, rating, genre = str(tmdb_id), str(tvdb_id), meta_get('rating'), display_genres(meta)
	cast = meta_get('short_cast', []) or meta_get('cast', []) or []
	mpaa, votes, trailer, studio, country = meta_get('mpaa'), meta_get('votes'), str(meta_get('trailer')), meta_get('studio'), meta_get('country')
	episode_run_time, season_data, total_seasons = meta_get('duration'), meta_get('season_data'), meta_get('total_seasons')
	# LOCAL PATCH 2026-09-14: TVDB season posters, when TVDB is the chosen provider for
	# this kind. Resolved once per list build rather than per row: two cached requests
	# (/series/{id}/artworks and /series/{id}/extended) cover the whole season list.
	#
	# The season number has to come from /extended because artworks carry a seasonId and
	# never a number, and TVDB files several orderings per series, so only the OFFICIAL
	# seasons line up with the TMDb numbering used everywhere else here.
	_season_posters, _season_landscapes = {}, {}
	try:
		from modules.metadata import is_anime_check
		_kind = 'anime' if is_anime_check(meta) else 'tvshow'
		_mode = str(settings.get_setting('deadlight.%s.artwork_provider' % _kind, '0'))
		# LOCAL PATCH 2026-09-26: fanart.tv DOES have a season dimension -- `seasonposter` and
		# `seasonthumb` carry a season number in TVDB numbering (the 2026-09-16 note here said it
		# had none, which was wrong). Posters now merge in provider order: mode 3 prefers
		# fanart.tv's, the TVDB modes TVDB's, each filling the other's gaps. Mode 0 keeps TMDb's
		# own season poster, as before. Landscapes come from fanart.tv in EVERY mode: seasonthumb
		# is the only per-season landscape any provider has (TVDB season art is posters and
		# banners only), and without it every season row showed the show's landscape. The
		# payload is the same 7-day cached one the show's backgrounds and logo already use.
		# LOCAL PATCH 2026-10-19: fanart.tv only when it is the chosen provider (mode 3). In TMDb / TVDB modes it was asked for
		# season landscapes alone, which it almost never has -- 2 of ~15 shows browsed on 10-19, Black Clover none -- so the
		# tiles showed the show's landscape anyway while the list waited up to 2.5 s on fanart.tv. The setting now means what
		# it says: TMDb mode asks no one else here, the TVDB modes TVDB.
		_fanart_season = {'poster': {}, 'landscape': {}}
		# LOCAL PATCH 2026-10-20: fanart.tv and TVDB asked AT THE SAME TIME (were one after the other). On an anime's first
		# season list of the week the two -- three requests, each a cold connection to a different host -- were 1.1-2.2 s
		# of a 1.2-2.7 s list (10-20 morning); TMDb-mode TV asks neither, which is why only anime was slow.
		# LOCAL PATCH 2026-10-20 (user's call): only what is ALREADY cached. A show whose fanart.tv / TVDB season art is not
		# shows TMDb's season posters now and has that art fetched after the list is on screen (_warm_season_art), for the
		# next visit -- an anime's first season list of the week was 1.3-1.4 s, 0.55 s of it TVDB and ~0.45 s loading
		# `requests` for it, against 0.23 s for a cached one.
		_cold = False
		if _mode == '3':
			from apis.fanart_api import fanart_season_art_cached
			_cached_fanart = fanart_season_art_cached(tvdb_id)
			if _cached_fanart is None: _cold = True
			else: _fanart_season = _cached_fanart
		_season_landscapes = _fanart_season['landscape']
		# LOCAL PATCH 2026-09-16: mode 3 fetches TVDB's too -- ranked by score, the closest TVDB
		# equivalent to "most liked", for the seasons fanart.tv has no poster for.
		if _mode in ('1', '2', '3'):
			from apis.tvdb_api import season_posters_cached
			_tvdb = season_posters_cached(tvdb_id)
			if _tvdb is None: _cold, _tvdb = True, {}
			# the later dict wins; {**a, **b}, not dict(a, **b), which rejects the int season keys
			_season_posters = {**_tvdb, **_fanart_season['poster']} if _mode == '3' else {**_fanart_season['poster'], **_tvdb}
		if _cold:
			from modules import metadata as _md
			if _md._DEFERRED is not None: _md._DEFERRED.append((meta, None, None, (_warm_season_art,)))
		# DIAGNOSTIC 2026-09-14: logs on EVERY season list, not only on failure. A bare
		# `except: pass` here was indistinguishable from "the feature is off", which is
		# exactly the ambiguity that cost an hour on the Continue Watching bug.
		kodi_utils.logger('season_art', 'kind=%s mode=%s tvdb_id=%s posters=%s landscapes=%s%s'
						  % (_kind, _mode, tvdb_id, sorted(_season_posters), sorted(_season_landscapes), ' (not cached: fetched after the list)' if _cold else ''))
	except Exception as e:
		try: kodi_utils.logger('season_art error', '%s: %s' % (type(e).__name__, str(e)[:160]))
		except Exception: pass
	if rpdb_api_key:
		try: show_poster = meta_get('rpdb_poster') % rpdb_api_key + rpdb_format
		except: show_poster = meta_get('poster') or poster_empty
	else: show_poster = meta_get('poster') or poster_empty
	show_fanart = meta_get('fanart') or fanart_empty
	show_extra_fanart = meta_get('extra_fanart_list') or []   # LOCAL PATCH 2026-09-15
	show_clearlogo, show_landscape = meta_get('clearlogo') or '', meta_get('landscape') or ''
	custom_order = params.get('custom_order', None)
	# LOCAL PATCH 2026-10-17: anime has its own specials setting (settings.anime_specials); 'airing' keeps season 0 here and
	# _special_rows turns it into rows after the cour split below
	_specials = settings.show_specials()
	_anime_specials = None
	if custom_order is None:
		try:
			from modules.metadata import is_anime_check
			if is_anime_check(meta): _anime_specials = settings.anime_specials(); _specials = _anime_specials != 'hidden'
		except Exception: pass
	if custom_order is None and _specials: season_data.sort(key=lambda i: (i['season_number'] == 0, i['season_number']))
	elif custom_order is not None: season_data = [i for i in season_data if i['season_number'] == params['season']]
	else:
		season_data = [i for i in season_data if not i['season_number'] == 0]
		season_data.sort(key=lambda k: k['season_number'])
	watched_info = watched_info_season(tmdb_id, get_database(watched_indicators))
	# Anime whose TMDb seasons bundle several cours get one row per cour. Skipped
	# for custom_order, which renders a single season inside another list and
	# returns list_items[0] -- splitting there would silently drop the later cours.
	if custom_order is None: season_data = _expand_anime_cours(meta, season_data)
	if _anime_specials == 'airing': season_data = _special_rows(meta, season_data)
	# LOCAL PATCH 2026-09-12: aired_map is built for EVERY show now, not only cour ones --
	# _process needs the true aired count to decide `unaired` for plain seasons as well.
	# Cheap: one pass over season_data, no I/O. The per-episode watched rows stay gated on
	# cours, since only a cour row has to count watched state by slice.
	aired_map = _aired_per_season(meta_get('season_data') or [], total_seasons, meta_get('total_aired_eps'))
	if any('_cour_offset' in i for i in season_data):
		episode_watched_rows = watched_info_episode(tmdb_id, get_database(watched_indicators))
	else: episode_watched_rows = []
	list_items = list(list(_process()))
	if custom_order is not None: return (list_items[0], custom_order)
	kodi_utils.add_items(handle, list_items)
	kodi_utils.set_content(handle, 'seasons')
	kodi_utils.set_category(handle, show_title)
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	kodi_utils.set_view_mode('view.seasons', 'seasons', is_external)
	# LOCAL PATCH 2026-08-09: auto-focus the earliest not-fully-watched season
	# so opening a show lands on "where you're up to" instead of Season 1.
	# Shares the episodes-list autoscroll setting + firing mechanism.
	if not is_external and settings.autoscroll_unwatched():
		try:
			target = None
			for idx, (_u, _li, _isf) in enumerate(list_items):
				try:
					info = _li.getVideoInfoTag()
					if info.getPlayCount() > 0: continue          # fully-watched season
					t = info.getTitle() or ''
					if t.startswith('[COLOR red]') or t == 'Specials' or t.startswith(_SPECIAL_PREFIX): continue  # unaired / specials
					target = idx
					break
				except: continue
			if target: kodi_utils.autoscroll_focus(target, len(list_items))
		except: pass

def single_seasons(seasons_list):
	season_results = []
	threads = TaskPool().tasks(lambda x: season_results.append(build_season_list(x)), seasons_list, min(len(seasons_list), settings.max_threads()))
	[i.join() for i in threads]
	return [i for i in season_results if i]
