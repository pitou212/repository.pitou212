# -*- coding: utf-8 -*-
from datetime import datetime, timezone
from threading import Thread
# LOCAL PATCH 2026-10-19: the three provider APIs load on first use. Every list and widget imports this module, and
# importing all three (with their caches) cost every call ~15 ms of start-up, though a TMDb list or widget calls none.
def _lazy(module, name):
	def call(*args, **kwargs):
		import importlib
		return getattr(importlib.import_module(module), name)(*args, **kwargs)
	call.__name__ = name
	return call

trakt_watched_status_mark, trakt_official_status, trakt_progress, trakt_get_hidden_items = (_lazy('apis.trakt_api', n) for n in
	('trakt_watched_status_mark', 'trakt_official_status', 'trakt_progress', 'trakt_get_hidden_items'))
# LOCAL PATCH 2026-07-23: MDBList as watched_indicators == 2 (see settings.py).
mdbl_watched_unwatched, mdbl_progress, mdbl_get_hidden_items, hide_unhide_mdbl_items, mdbl_queue_progress, mdbl_pending_drop, \
	mdblist_on_cooldown, mdbl_acked_write = (_lazy('apis.mdblist_api', n) for n in ('mdbl_watched_unwatched', 'mdbl_progress',
	'mdbl_get_hidden_items', 'hide_unhide_mdbl_items', 'mdbl_queue_progress', 'mdbl_pending_drop', 'mdblist_on_cooldown', 'mdbl_acked_write'))
# LOCAL PATCH 2026-07-29: SIMKL as watched_indicators == 3. Supports movies + shows + anime
# and uniquely offers "On Hold" as a first-class status alongside Watching/Completed/Dropped/PTW.
simkl_mark_watched, simkl_mark_unwatched, simkl_add_to_list, simkl_list = (_lazy('apis.simkl_api', n) for n in
	('simkl_mark_watched', 'simkl_mark_unwatched', 'simkl_add_to_list', 'simkl_list'))
from caches.base_cache import connect_database, database, set_tombstones, clear_tombstones, write_transaction
from caches.trakt_cache import clear_trakt_collection_watchlist_data
from caches.mdblist_cache import clear_mdbl_collection_watchlist_data
from caches.simkl_cache import clear_simkl_lists_cache
from modules.kodi_utils import kodi_progress_background, sleep, get_video_database_path, notification, kodi_refresh, get_property, set_property, auto_kodi_refresh
from modules.utils import get_datetime, adjust_premiered_date, sort_for_article, TaskPool, get_current_timestamp
from modules import metadata, settings
# from modules.kodi_utils import logger

def get_database(watched_indicators=None):
	# LOCAL PATCH 2026-07-23 / 2026-07-29: add mdblist_db → watched_indicators == 2,
	# simkl_db → watched_indicators == 3.
	return connect_database({0: 'watched_db', 1: 'trakt_db', 2: 'mdblist_db', 3: 'simkl_db'}[watched_indicators if watched_indicators is not None else settings.watched_indicators()])

# def cache_watched_tvshow_status(function, status_type, watched_indicators=None):
# 	watched_indicators = watched_indicators or settings.watched_indicators()
# 	dbcon = get_database(watched_indicators)
# 	cache = dbcon.execute('SELECT media_id, status FROM watched_status WHERE db_type = ?', (status_type,)).fetchone()
# 	if cache is not None:
# 		expiration, result = cache
# 		if int(expiration) > get_timestamp(): return eval(result)
# 		clear_cache_watched_tvshow_status(watched_indicators, (status_type,))
# 	result = function(status_type)
# 	dbcon.execute('INSERT OR REPLACE INTO watched_status VALUES (?, ?, ?)', (status_type, get_timestamp(12), repr(result)))
# 	return result or []

# def clear_cache_watched_tvshow_status(watched_indicators=None, status_types=('watched', 'progress')):
# 	try:
# 		watched_indicators = watched_indicators or settings.watched_indicators()
# 		dbcon = get_database()
# 		for status in status_types: dbcon.execute('DELETE FROM watched_status WHERE db_type = ?', (status,))
# 		dbcon.execute('VACUUM')
# 		return True
# 	except: return False

def get_hidden_progress_items(watched_indicators):
	try:
		if watched_indicators == 0:
			watched_db = get_database()
			watched_info = watched_db.execute('SELECT status FROM watched_status WHERE db_type = ?', ('hidden_progress_items',)).fetchone()[0]
			return eval(watched_info) or []
		elif watched_indicators == 2:
			return mdbl_get_hidden_items('dropped')
		elif watched_indicators == 3:
			# LOCAL PATCH 2026-07-29 / 2026-07-30: SIMKL treats 'dropped' AND 'hold' as
			# shows the user has intentionally stopped watching. Both should be hidden
			# from Next Episodes / In Progress. Fetch across BOTH 'shows' and 'anime'
			# list_types since SIMKL treats anime as a separate type on the all-items
			# endpoint. Union all TMDb IDs.
			hidden = []
			for list_type in ('shows', 'anime'):
				for status in ('dropped', 'hold'):
					try:
						data = simkl_list(list_type, status) or {}
						for it in (data.get(list_type) or []):
							try:
								tmdb = (it.get('show') or {}).get('ids', {}).get('tmdb')
								if tmdb: hidden.append(int(tmdb))
							except Exception: continue
					except Exception: continue
			return hidden
		else: return trakt_get_hidden_items('dropped')
	except: return []

def update_hidden_progress(media_id):
	watched_indicators = settings.watched_indicators()
	current_hidden = get_hidden_progress_items(watched_indicators)
	new_hidden = [i for i in current_hidden if i != int(media_id)]
	if new_hidden == current_hidden: return
	if watched_indicators == 0: function = hide_unhide_progress_items
	elif watched_indicators == 2:
		# MDBList uses hide_unhide_mdbl_items(action, mediatype, media_id, list_type)
		return hide_unhide_mdbl_items('unhide', 'shows', media_id, 'dropped')
	elif watched_indicators == 3:
		# LOCAL PATCH 2026-07-29: SIMKL undrop → move show back to 'watching' status.
		# SIMKL doesn't have a "remove from dropped" endpoint per se — moving to
		# another list implicitly removes from the old one.
		simkl_add_to_list('shows', 'tmdb', int(media_id), 'watching')
		clear_simkl_lists_cache()
		return
	else: from apis.trakt_api import hide_unhide_progress_items as function
	function({'action': 'undrop', 'media_type': 'shows', 'media_id': media_id, 'section': 'dropped', 'refresh': 'false'})

def hide_unhide_progress_items(params):
	action, media_id, refresh = params['action'], int(params.get('media_id', '0')), params.get('refresh', 'true') == 'true'
	current_items = get_hidden_progress_items(0) or []
	if action == 'drop': current_items.append(media_id)
	else: current_items.remove(media_id)
	watched_db = get_database()
	watched_info = watched_db.execute('INSERT OR REPLACE INTO watched_status VALUES (?, ?, ?)', ('hidden_progress_items', 'hidden', repr(current_items),))
	if refresh: kodi_refresh()

def get_last_played_value(watched_indicators):
	if watched_indicators == 0: return datetime.now().strftime('%Y-%m-%d %H:%M:%S')
	else: return datetime.now(timezone.utc).replace(tzinfo=None).strftime('%Y-%m-%dT%H:%M:%S.000Z')

# LOCAL PATCH 2026-10-03 (Batch 2): a removal leaves a tombstone so a sync already downloading cannot put the
# row back (base_cache.replace_watched_rows / replace_progress_rows); re-adding the row lifts it. Provider
# databases only: watched_indicators 0 has no sync. rows: (db_type, media_id, season, episode, ...).
def _mark_removed(watched_indicators, dbcon, kind, rows):
	if watched_indicators == 0 or not rows: return
	try: set_tombstones(dbcon, kind, rows, get_last_played_value(watched_indicators))
	except Exception: pass

def _mark_restored(watched_indicators, dbcon, kind, rows):
	if watched_indicators == 0 or not rows: return
	try: clear_tombstones(dbcon, kind, rows)
	except Exception: pass

def make_batch_insert(action, media_type, media_id, season, episode, last_played, title):
	if action == 'mark_as_watched': return (media_type, media_id, season, episode, last_played, title)
	else: return (media_type, media_id, season, episode)

def refresh_container(refresh=True):
	if refresh: kodi_refresh()

def active_tvshows_information(status_type):
	def _process(item):
		media_id = item['media_id']
		meta = metadata.tvshow_meta('tmdb_id', media_id, api_key, mpaa_region, get_datetime())
		watched_status = get_watched_status_tvshow(watched_info[media_id], meta.get('total_aired_eps'))[0]
		airing_status = meta.get('status', '')
		if status_type == 'watched':
			if watched_status == 1:
				if not include_other and airing_status not in ('Ended', 'Canceled'): return
				results_append(item)
		else:
			if watched_status == 0: results_append(item)
			elif include_other and airing_status not in ('Ended', 'Canceled'): results_append(item)
	results = []
	results_append = results.append
	watched_indicators = settings.watched_indicators()
	watched_info = watched_info_tvshow()
	if status_type == 'progress':
		hidden_items = get_hidden_progress_items(settings.watched_indicators())
		for k in hidden_items: watched_info.pop(str(k), None)
	api_key, mpaa_region = settings.tmdb_api_key(), settings.mpaa_region()
	watched_items = watched_info.items()
	data = [v for k, v in watched_items]
	progress_location = settings.tv_progress_location()
	if status_type == 'watched': include_other = progress_location in (0, 2)
	else: include_other = progress_location in (1, 2)
	threads = TaskPool().tasks(_process, data, min(len(data), settings.max_threads()))
	[i.join() for i in threads]
	return results

def watched_info_movie(watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		watched_info = watched_db.execute('SELECT media_id, title, last_played FROM watched WHERE db_type = ?', ('movie',)).fetchall()
		return dict([(i[0], {'media_id': i[0], 'title': i[1], 'last_played': i[2]}) for i in watched_info])
	except: return {}

def get_watched_status_movie(watched_info, media_id):
	if not watched_info: return 0
	try:
		watched = 1 if media_id in watched_info else 0
		return watched
	except: return 0

def get_bookmarks_movie(watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		info = watched_db.execute('SELECT media_id, resume_point, curr_time, resume_id FROM progress WHERE db_type = ?', ('movie',)).fetchall()
		info = dict([(i[0], {'media_id': i[0], 'resume_point': i[1], 'curr_time': i[2], 'resume_id': i[3]}) for i in info])
	except: info = {}
	return info

def get_progress_status_movie(progress_info, media_id):
	try: percent = str(round(float(progress_info[media_id]['resume_point'])))
	except: percent = None
	return percent

def watched_info_tvshow(watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		# LOCAL PATCH 2026-08-05 (Red Light R4 port): exclude S0 specials from
		# COUNT(*) so playcount/progress align with total_aired_eps (which
		# already excludes S0). Otherwise a fully-watched-including-specials
		# show reads total_played > aired_eps → clamped to aired but the S0
		# rows still shift MAX(season/episode) toward S0 rows for get_next_episodes.
		exclude_specials = settings.exclude_specials_from_progress()
		if exclude_specials:
			data = watched_db.execute('SELECT media_id, season, episode, title, MAX(last_played), COUNT(*) AS COUNTER FROM watched WHERE db_type = ? AND season != 0 GROUP BY media_id',
									('episode',)).fetchall()
		else:
			data = watched_db.execute('SELECT media_id, season, episode, title, MAX(last_played), COUNT(*) AS COUNTER FROM watched WHERE db_type = ? GROUP BY media_id',
									('episode',)).fetchall()
		return dict([(i[0], {'media_id': i[0], 'season': i[1], 'episode': i[2], 'title': i[3], 'last_played': i[4], 'total_played': i[5]}) for i in data])
	except: return {}

def get_watched_status_tvshow(watched_info, aired_eps):
	if not watched_info: return 0, 0, aired_eps
	try:
		watched = min(watched_info['total_played'], aired_eps)
		unwatched = aired_eps - watched
		if watched >= aired_eps: playcount = 1
		else: playcount = 0
		return playcount, watched, unwatched
	except: return 0, 0, aired_eps

def get_progress_status_tvshow(watched, aired_eps):
	try: progress = int((float(watched)/aired_eps)*100) or 1
	except: progress = 1
	return progress

def watched_info_season(media_id, watched_db=None):
	if not watched_db: watched_db = get_database()
	try: watched_info = dict(watched_db.execute('SELECT season, COUNT(*) AS COUNTER FROM watched WHERE db_type = ? AND media_id = ? GROUP BY media_id, season',
							('episode', str(media_id))).fetchall())
	except: watched_info = {}
	return watched_info

def get_watched_status_season(watched_info, aired_eps):
	if not watched_info: return 0, 0, aired_eps
	try:
		watched = min(watched_info, aired_eps)
		unwatched = aired_eps - watched
		if watched >= aired_eps: playcount = 1
		else: playcount = 0
		return playcount, watched, unwatched
	except: return 0, 0, aired_eps

def get_progress_status_season(watched, aired_eps):
	try: progress = int((float(watched)/aired_eps)*100)
	except: progress = 0
	return progress

def watched_info_episode(media_id, watched_db=None):
	if not watched_db: watched_db = get_database()
	try: watched_info = watched_db.execute('SELECT season, episode FROM watched WHERE db_type = ? AND media_id = ?', ('episode', str(media_id))).fetchall()
	except: watched_info = []
	return watched_info

# LOCAL PATCH 2026-10-02: every show's watched episodes in ONE query, for lists that walk many shows (Next Episodes,
# Continue Watching: 184-250 shows each). {media_id (str): [(season, episode), ...]} -- per show the same rows, in the
# same order and with the same values, as watched_info_episode(media_id) returns. The per-show queries queued on one
# connection from up to 32 pool threads: 184 of them summed ~3 s of thread time for an 18 ms job.
def watched_info_episodes_all(watched_db=None):
	if not watched_db: watched_db = get_database()
	result = {}
	try:
		for media_id, season, episode in watched_db.execute('SELECT media_id, season, episode FROM watched WHERE db_type = ?', ('episode',)).fetchall():
			result.setdefault(str(media_id), []).append((season, episode))
	except: return None
	return result

def get_watched_status_episode(watched_info, season_episode):
	if season_episode in watched_info: return 1
	return 0

def get_bookmarks_episode(media_id, season, watched_db=None):
	if not watched_db: watched_db = get_database()
	try:
		info = watched_db.execute('SELECT resume_point, curr_time, resume_id, episode FROM progress WHERE db_type = ? AND media_id = ? AND season = ?',
			('episode', str(media_id), int(season))).fetchall()
		info = dict([(i[3], {'resume_point': i[0], 'curr_time': i[1], 'resume_id': i[2]}) for i in info])
	except: info = {}
	return info

def get_bookmarks_episodes_all(watched_db=None):
	"""LOCAL PATCH 2026-10-03 (3.0.8): every episode resume point in one query -- {(media_id, season): {episode: {...}}}.
	For the long episode lists, which read them one show at a time (watched_info_episodes_all is the same idea)."""
	if not watched_db: watched_db = get_database()
	result = {}
	try:
		for media_id, season, episode, resume_point, curr_time, resume_id in watched_db.execute(
				'SELECT media_id, season, episode, resume_point, curr_time, resume_id FROM progress WHERE db_type = ?', ('episode',)).fetchall():
			try: key = (str(media_id), int(season))
			except (TypeError, ValueError): continue
			result.setdefault(key, {})[episode] = {'resume_point': resume_point, 'curr_time': curr_time, 'resume_id': resume_id}
	except: return None
	return result

def get_bookmarks_all_episode(media_id, total_seasons, watched_db=None):
	if not watched_db: watched_db = get_database()
	all_seasons_info = {}
	for season in range(1, total_seasons + 1):
		try:
			season_info = get_bookmarks_episode(media_id, season, watched_db)
			all_seasons_info[season] = season_info
		except: pass
	return all_seasons_info

def get_progress_status_episode(progress_info, episode):
	try: percent = str(round(float(progress_info[episode]['resume_point'])))
	except: percent = None
	return percent

def get_progress_status_all_episode(progress_info, season, episode):
	try: percent = str(round(float(progress_info[season][episode]['resume_point'])))
	except: percent = None
	return percent

def get_resume_seconds(progress, duration):
	return float(int(float(progress)/100 * duration))


def erase_bookmark(media_type, media_id, season='', episode='', refresh='false'):
	try:
		watched_indicators = settings.watched_indicators()
		watched_db = get_database(watched_indicators)
		# LOCAL PATCH 2026-10-03 (Batch 2): only with a real resume_id. A row DeadLight wrote itself has 0, and the
		# clear went out as sync/playback/0 (Trakt) or {'id': 0} (MDBList): a request that can clear nothing.
		if watched_indicators == 1:
			try:
				if media_type == 'episode': resume_id = get_bookmarks_episode(str(media_id), season, watched_db)[int(episode)]['resume_id']
				else: resume_id = get_bookmarks_movie()[str(media_id)]['resume_id']
				if resume_id:
					sleep(1000)
					trakt_progress('clear_progress', media_type, media_id, 0, season, episode, resume_id)
			except: pass
		elif watched_indicators == 2:
			mdbl_pending_drop(media_type, media_id, season, episode)   # LOCAL PATCH 2026-09-24: never re-send it
			try:
				if media_type == 'episode': resume_id = get_bookmarks_episode(str(media_id), season, watched_db)[int(episode)]['resume_id']
				else: resume_id = get_bookmarks_movie()[str(media_id)]['resume_id']
				if resume_id:
					sleep(1000)
					mdbl_progress('clear_progress', media_type, media_id, 0, season, episode, resume_id)
			except: pass
		watched_db.execute('DELETE FROM progress where db_type = ? and media_id = ? and season = ? and episode = ?', (media_type, media_id, season, episode))
		_mark_removed(watched_indicators, watched_db, 'unprogress', [(media_type, media_id, season, episode)])
		refresh_container(refresh == 'true')
	except: pass

def batch_erase_bookmark(watched_indicators, insert_list, action):
	try:
		watched_db = get_database(watched_indicators)
		if action == 'mark_as_watched': modified_list = [(i[0], i[1], i[2], i[3]) for i in insert_list]
		else: modified_list = insert_list
		if watched_indicators in (1, 2):
			progress_fn = trakt_progress if watched_indicators == 1 else mdbl_progress
			def _process():
				for i in insert_list:
					if watched_indicators == 2: mdbl_pending_drop(i[0], i[1], i[2], i[3])   # LOCAL PATCH 2026-09-24
					try:
						media_id, season, episode = i[1], i[2], i[3]
						resume_id = get_bookmarks_episode(str(media_id), season, watched_db)[int(episode)]['resume_id']
						if not resume_id: continue   # LOCAL PATCH 2026-10-03 (Batch 2): see erase_bookmark
						sleep(1000)
						progress_fn('clear_progress', i[0], i[1], 0, i[2], i[3], resume_id)
					except: pass
			Thread(target=_process).start()
		with write_transaction(watched_db):   # LOCAL PATCH 2026-10-03 (Batch 2): one write, never half-seen by a sync
			watched_db.executemany('DELETE FROM progress where db_type = ? and media_id = ? and season = ? and episode = ?', modified_list)
			_mark_removed(watched_indicators, watched_db, 'unprogress', modified_list)
	except: pass

def set_bookmark(params):
	try:
		media_type, tmdb_id, curr_time, total_time = params.get('media_type'), params.get('tmdb_id'), params.get('curr_time'), params.get('total_time')
		refresh = False if params.get('from_playback', 'false') == 'true' else True
		title, season, episode = params.get('title'), params.get('season'), params.get('episode')
		adjusted_current_time = float(curr_time) - 5
		resume_point = round(adjusted_current_time/float(total_time)*100,1)
		watched_indicators = settings.watched_indicators()
		if watched_indicators == 1:
			if trakt_official_status(media_type) == False: return
			else: trakt_progress('set_progress', media_type, tmdb_id, resume_point, season, episode, refresh_trakt=True)
		elif watched_indicators == 2:
			# LOCAL PATCH 2026-09-24: the local row FIRST, so resume works whatever MDBList says,
			# then the save; a refused save is queued and re-sent (mdblist_api._PENDING_KEY). On a
			# known cooldown the call is not even made -- it would only answer 429 again. A save
			# MDBList takes supersedes any older queued one for the same item. The local row has no
			# MDBList resume_id; the sync that follows a successful save brings the real one.
			dbcon = get_database(watched_indicators)
			dbcon.execute('INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
						(media_type, tmdb_id, season, episode, str(resume_point), str(curr_time), get_last_played_value(watched_indicators), 0, title))
			if not mdblist_on_cooldown() and mdbl_progress('set_progress', media_type, tmdb_id, resume_point, season, episode, refresh_mdb=True):
				mdbl_pending_drop(media_type, tmdb_id, season, episode)
			else:
				mdbl_queue_progress(media_type, tmdb_id, resume_point, season, episode, curr_time, title)
		elif watched_indicators == 3:
			# LOCAL PATCH 2026-07-29: SIMKL has no resume-point API — record locally only
			# in simkl_db.progress so DeadLight can show a resume bar. Real scrobble at
			# playback stop (>=90%) is handled by modules/player.py hook (Phase E).
			erase_bookmark(media_type, tmdb_id, season, episode)
			last_played = get_last_played_value(watched_indicators)
			dbcon = get_database(watched_indicators)
			dbcon.execute('INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
						(media_type, tmdb_id, season, episode, str(resume_point), str(curr_time), last_played, 0, title))
		else:
			erase_bookmark(media_type, tmdb_id, season, episode)
			last_played = get_last_played_value(watched_indicators)
			dbcon = get_database(watched_indicators)
			dbcon.execute('INSERT OR REPLACE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
						(media_type, tmdb_id, season, episode, str(resume_point), str(curr_time), last_played, 0, title))
		# LOCAL PATCH 2026-10-03 (Batch 2): a resume point saved again is no longer a cleared one (SIMKL's
		# branch tombstones it through erase_bookmark a few lines up).
		_mark_restored(watched_indicators, get_database(watched_indicators), 'unprogress', [(media_type, tmdb_id, season, episode)])
		refresh_container(refresh)
	except: pass

def mark_movie(params):
	action, media_type = params.get('action'), 'movie'
	refresh, from_playback = params.get('refresh', 'true') == 'true', params.get('from_playback', 'false') == 'true'
	if from_playback: refresh = False
	tmdb_id, title = params.get('tmdb_id'), params.get('title')
	watched_indicators = settings.watched_indicators()
	# LOCAL PATCH 2026-09-22 (Red Light 2.6.2 port): on the PLAYBACK path the local tick is
	# written BEFORE the provider call. Every provider branch below ends a failure with
	# `return notification('Error')`, which skipped the local write at the bottom entirely --
	# so a network blip at the end of an episode lost the tick locally as well as remotely,
	# and nothing retried it. Writing first means the thing the user actually did is recorded
	# whatever the network does.
	#
	# The trailing call is left in place rather than made conditional: both statements it runs
	# are idempotent (INSERT OR REPLACE / DELETE), so the second write is a no-op beyond a
	# fresher last_played, and leaving it keeps the non-playback path byte-identical.
	#
	# Deliberately scoped to from_playback. A manual mark is made while the user is watching
	# the UI, so there an Error toast with no local change is the honest outcome. Note the
	# local table is a MIRROR of the provider: if the remote write really did fail, the next
	# sync rebuilds the mirror from the provider and the tick goes away again. That is
	# correct -- the provider stays the source of truth -- but it is why this is not a
	# substitute for a retry queue.
	if from_playback:
		watched_status_mark(watched_indicators, media_type, tmdb_id, action, title=title)
	if watched_indicators == 1:
		if from_playback and trakt_official_status(media_type) == False: sleep(1000)
		elif not trakt_watched_status_mark(action, 'movies', tmdb_id): return notification('Error')
		clear_trakt_collection_watchlist_data('watchlist', media_type)
	elif watched_indicators == 2:
		# LOCAL PATCH 2026-10-03 (3.0.8): mdbl_acked_write -- the sync after this mark skips the full re-download
		if not mdbl_acked_write(lambda: mdbl_watched_unwatched(action, 'movies', tmdb_id), ('watched_at',)): return notification('Error')
		clear_mdbl_collection_watchlist_data('watchlist')
	elif watched_indicators == 3:
		# LOCAL PATCH 2026-07-29: SIMKL mark movie watched/unwatched.
		fn = simkl_mark_watched if action == 'mark_as_watched' else simkl_mark_unwatched
		if not fn('movies', 'tmdb', int(tmdb_id)): return notification('Error')
		clear_simkl_lists_cache()
	watched_status_mark(watched_indicators, media_type, tmdb_id, action, title=title)
	refresh_container(refresh)

def mark_tvshow(params):
	title, action, tmdb_id = params.get('title', ''), params.get('action'), params.get('tmdb_id')
	try: tvdb_id = int(params.get('tvdb_id', '0'))
	except: tvdb_id = 0
	watched_indicators = settings.watched_indicators()
	progress_backround = kodi_progress_background()
	progress_backround.create('[B]Please Wait..[/B]', '')
	if watched_indicators == 1:
		if not trakt_watched_status_mark(action, 'shows', tmdb_id, tvdb_id): return progress_backround.close(), notification('Error')
		clear_trakt_collection_watchlist_data('watchlist', 'tvshow')
	elif watched_indicators == 2:
		if not mdbl_acked_write(lambda: mdbl_watched_unwatched(action, 'shows', tmdb_id, tvdb_id), ('episode_watched_at',)): return progress_backround.close(), notification('Error')
		clear_mdbl_collection_watchlist_data('watchlist')
	elif watched_indicators == 3:
		# LOCAL PATCH 2026-07-29: SIMKL mark whole show — no seasons kwarg = mark all.
		fn = simkl_mark_watched if action == 'mark_as_watched' else simkl_mark_unwatched
		if not fn('shows', 'tmdb', int(tmdb_id)): return progress_backround.close(), notification('Error')
		clear_simkl_lists_cache()
	current_date = get_datetime()
	insert_list = []
	insert_append = insert_list.append
	meta = metadata.tvshow_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
	season_data = meta['season_data']
	season_data = [i for i in season_data if i['season_number'] > 0]
	total = len(season_data)
	last_played = get_last_played_value(watched_indicators)
	for count, item in enumerate(season_data, 1):
		season_number = item['season_number']
		ep_data = metadata.episodes_meta(season_number, meta)
		for ep in ep_data:
			season_number = ep['season']
			ep_number = ep['episode']
			display = '%s - S%.2dE%.2d' % (title, int(season_number), int(ep_number))
			progress_backround.update(int(float(count)/float(total)*100), '[B]Please Wait..[/B]', display)
			episode_date, premiered = adjust_premiered_date(ep['premiered'], settings.date_offset())
			if episode_date and current_date < episode_date: continue
			insert_append(make_batch_insert(action, 'episode', tmdb_id, season_number, ep_number, last_played, title))
	batch_watched_status_mark(watched_indicators, insert_list, action)
	progress_backround.close()
	refresh_container()

def mark_season(params):
	season = int(params.get('season'))
	# LOCAL PATCH 2026-10-19: specials can be marked as a season too (was 'Failed', as mark_episode until 10-18). Trakt,
	# MDBList and SIMKL take season 0 like any other (int(season) in each payload); the AniList / MAL season push is
	# skipped below, as a special is not the regular cour's progress.
	insert_list = []
	insert_append = insert_list.append
	action, title, tmdb_id = params.get('action'), params.get('title'), params.get('tmdb_id')
	try: tvdb_id = int(params.get('tvdb_id', '0'))
	except: tvdb_id = 0
	# LOCAL PATCH 2026-08-29: optional cour range, for anime seasons split into parts.
	#
	# A cour is a SLICE of a TMDb season -- Reincarnated as a Slime season 2 is two cours of
	# 12 -- so the season-level provider call would mark the sibling cours as well. That is
	# why the season row for a cour had no Mark Watched at all. With an offset and length the
	# range is exact: TMDb episodes offset+1 .. offset+length within `season`, pushed as an
	# episode LIST, which all three providers accept in a single call.
	try:
		cour_offset = int(params.get('cour_offset', '') or -1)
		cour_len = int(params.get('cour_len', '') or 0)
	except (TypeError, ValueError):
		cour_offset, cour_len = -1, 0
	is_cour = cour_offset >= 0 and cour_len > 0
	cour_eps = list(range(cour_offset + 1, cour_offset + cour_len + 1)) if is_cour else []
	watched_indicators = settings.watched_indicators()
	heading = '[B]Mark Watched %s[/B]' if action == 'mark_as_watched' else '[B]Mark Unwatched %s[/B]'
	if watched_indicators == 1:
		if is_cour:
			if not trakt_watched_status_mark(action, 'episodes', tmdb_id, tvdb_id, season, None, 'tmdb', cour_eps): return notification('Error')
		elif not trakt_watched_status_mark(action, 'season', tmdb_id, tvdb_id, season): return notification('Error')
		clear_trakt_collection_watchlist_data('watchlist', 'tvshow')
	elif watched_indicators == 2:
		if is_cour:
			if not mdbl_acked_write(lambda: mdbl_watched_unwatched(action, 'episodes', tmdb_id, tvdb_id, season, None, 'tmdb', cour_eps),
									('episode_watched_at',)): return notification('Error')
		elif not mdbl_acked_write(lambda: mdbl_watched_unwatched(action, 'season', tmdb_id, tvdb_id, season), ('episode_watched_at',)): return notification('Error')
		clear_mdbl_collection_watchlist_data('watchlist')
	elif watched_indicators == 3:
		# LOCAL PATCH 2026-07-29: SIMKL mark a whole season — episodes list omitted
		# marks all episodes in that season. A cour names its episodes instead.
		if is_cour: seasons = [{'number': int(season), 'episodes': [{'number': e} for e in cour_eps]}]
		else: seasons = [{'number': int(season)}]
		fn = simkl_mark_watched if action == 'mark_as_watched' else simkl_mark_unwatched
		if not fn('shows', 'tmdb', int(tmdb_id), seasons=seasons): return notification('Error')
		clear_simkl_lists_cache()
	progress_backround = kodi_progress_background()
	progress_backround.create('[B]Please Wait..[/B]', '')
	current_date = get_datetime()
	meta = metadata.tvshow_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
	ep_data = metadata.episodes_meta(season, meta)
	last_played = get_last_played_value(watched_indicators)
	if is_cour: ep_data = [i for i in ep_data if i['episode'] in cour_eps]
	for count, item in enumerate(ep_data, 1):
		season_number = item['season']
		ep_number = item['episode']
		display = '%s - S%.2dE%.2d' % (title, season_number, ep_number)
		episode_date, premiered = adjust_premiered_date(item['premiered'], settings.date_offset())
		if episode_date and current_date < episode_date: continue
		progress_backround.update(int(float(count) / float(len(ep_data)) * 100), '[B]Please Wait..[/B]', display)
		insert_append(make_batch_insert(action, 'episode', tmdb_id, season_number, ep_number, last_played, title))
	batch_watched_status_mark(watched_indicators, insert_list, action)
	# len(insert_list) is the count actually marked -- unaired episodes were skipped
	# above -- so a part-aired season reports honest progress instead of COMPLETED.
	if season != 0:   # LOCAL PATCH 2026-10-19: see the top of mark_season
		_anilist_mark_season(tmdb_id, season, action, len(insert_list), params.get('anilist_id'), cour_eps)
		_mal_mark_season(tmdb_id, season, action, len(insert_list), cour_eps)   # LOCAL PATCH 2026-10-02: own gate, own call
	progress_backround.close()
	refresh_container()

def _anilist_mark_season(tmdb_id, season, action, marked_count, anilist_id=None, cour_eps=None):
	"""Push a season/cour mark to AniList. Best-effort -- never blocks the local mark.

	LOCAL PATCH 2026-08-29. AniList is not one of the watched_indicators providers, and the
	only push that existed was player._anilist_scrobble, so AniList knew about episodes you
	PLAYED and nothing about episodes you MARKED. Marking a season silently left it behind.

	It needs its own path because it does not speak TMDb numbering: progress counts WITHIN
	an entry, and an entry is one cour. Frieren S01E30 is entry 182255 progress 2, not 30.
	A whole-cour mark is the easy case -- the entry is completed outright, so progress is
	simply how many episodes were marked.

	marked_count excludes unaired episodes, so a part-aired season reports real progress and
	anilist_set_progress picks CURRENT rather than COMPLETED. Unwatching sends 0, which it
	maps to PLANNING.
	"""
	try:
		from modules.settings import anilist_user_active
		if not anilist_user_active(): return
		if action == 'mark_as_watched' and not marked_count: return
		from apis.anilist_api import anilist_set_progress
		if anilist_id:
			anilist_set_progress(anilist_id, marked_count if action == 'mark_as_watched' else 0)
			return
		# LOCAL PATCH 2026-10-09: an unsplit season, or a season row that merges several cours of one release season
		# (Stone Ocean's three parts, Re:ZERO S2's two halves), spans several AniList entries -- each gets the episodes
		# of the range that are its own. It used to push the whole count to the entry of the first episode only.
		from caches import fribb_mappings
		eps = (cour_eps or list(range(1, marked_count + 1)))[:marked_count]   # unaired episodes are the skipped tail
		per_entry = {}
		for ep in eps:
			_al = (fribb_mappings.find_cour_by_tmdb_coords(int(tmdb_id), int(season), ep) or {}).get('anilist')
			if _al: per_entry[_al] = per_entry.get(_al, 0) + 1
		for _al, count in per_entry.items():
			anilist_set_progress(_al, count if action == 'mark_as_watched' else 0)
	except Exception as e:
		from modules.kodi_utils import logger
		logger('anilist season mark', str(e))

def _mal_mark_season(tmdb_id, season, action, marked_count, cour_eps=None):
	"""LOCAL PATCH 2026-10-02: the same season / cour mark, pushed to MyAnimeList. Best-effort, like the AniList one.

	Each MAL entry in range gets its own episodes -- one entry per cour, as on AniList. Sets the count
	exactly (not raise-only): marking or unmarking is the user asking for that number."""
	try:
		from modules.settings import mal_user_active
		if not mal_user_active(): return
		if action == 'mark_as_watched' and not marked_count: return
		from caches import fribb_mappings
		from apis.mal_api import mal_set_progress
		# LOCAL PATCH 2026-10-09: per entry, as _anilist_mark_season -- a merged season row spans several MAL entries
		eps = (cour_eps or list(range(1, marked_count + 1)))[:marked_count]
		per_entry = {}
		for ep in eps:
			_mal = (fribb_mappings.find_cour_by_tmdb_coords(int(tmdb_id), int(season), ep) or {}).get('mal')
			if _mal: per_entry[_mal] = per_entry.get(_mal, 0) + 1
		for _mal, count in per_entry.items():
			mal_set_progress(_mal, count if action == 'mark_as_watched' else 0)
	except Exception as e:
		from modules.kodi_utils import logger
		logger('mal season mark', str(e))


def mark_episode(params):
	season, episode, title = int(params.get('season')), int(params.get('episode')), params.get('title')
	# LOCAL PATCH 2026-10-18: specials are marked like any episode (was 'Failed', so a finished special -- now a normal
	# path with Anime Specials -- was never ticked). Progress / Next Episodes still honour exclude_specials_from_progress.
	action, media_type = params.get('action'), 'episode'
	refresh, from_playback = params.get('refresh', 'true') == 'true', params.get('from_playback', 'false') == 'true'
	if from_playback: refresh = False
	tmdb_id = params.get('tmdb_id')
	try: tvdb_id = int(params.get('tvdb_id', '0'))
	except: tvdb_id = 0
	watched_indicators = settings.watched_indicators()
	# LOCAL PATCH 2026-09-22 (Red Light 2.6.2 port): on the PLAYBACK path the local tick is
	# written BEFORE the provider call. Every provider branch below ends a failure with
	# `return notification('Error')`, which skipped the local write at the bottom entirely --
	# so a network blip at the end of an episode lost the tick locally as well as remotely,
	# and nothing retried it. Writing first means the thing the user actually did is recorded
	# whatever the network does.
	#
	# The trailing call is left in place rather than made conditional: both statements it runs
	# are idempotent (INSERT OR REPLACE / DELETE), so the second write is a no-op beyond a
	# fresher last_played, and leaving it keeps the non-playback path byte-identical.
	#
	# Deliberately scoped to from_playback. A manual mark is made while the user is watching
	# the UI, so there an Error toast with no local change is the honest outcome. Note the
	# local table is a MIRROR of the provider: if the remote write really did fail, the next
	# sync rebuilds the mirror from the provider and the tick goes away again. That is
	# correct -- the provider stays the source of truth -- but it is why this is not a
	# substitute for a retry queue.
	if from_playback:
		watched_status_mark(watched_indicators, media_type, tmdb_id, action, season, episode, title)
	if watched_indicators == 1:
		if from_playback and trakt_official_status(media_type) == False: sleep(1000)
		elif not trakt_watched_status_mark(action, media_type, tmdb_id, tvdb_id, season, episode): return notification('Error')
		clear_trakt_collection_watchlist_data('watchlist', 'tvshow')
	elif watched_indicators == 2:
		if not mdbl_acked_write(lambda: mdbl_watched_unwatched(action, 'episode', tmdb_id, tvdb_id, season, episode), ('episode_watched_at',)): return notification('Error')
		# LOCAL PATCH 2026-10-03 (3.0.8): no watchlist clear on a single episode. It cost a full watchlist re-download on the
		# next open after every episode watched; one episode never changes the watchlist, and if MDBList ever does move it,
		# watchlisted_at moves and the sync clears it (mdbl_sync_activities). Movie/show/season marks keep theirs.
	elif watched_indicators == 3:
		# LOCAL PATCH 2026-07-29: SIMKL mark single episode.
		seasons = [{'number': int(season), 'episodes': [{'number': int(episode)}]}]
		fn = simkl_mark_watched if action == 'mark_as_watched' else simkl_mark_unwatched
		if not fn('shows', 'tmdb', int(tmdb_id), seasons=seasons): return notification('Error')
		clear_simkl_lists_cache()
		# LOCAL PATCH 2026-09-19: if that episode ended a cour, put the next one on Watching.
		# SIMKL files each cour as its own entry, so otherwise it has to be added by hand.
		# Self-gates on anime via Fribb and is a no-op mid-cour; never on an unwatch.
		if action == 'mark_as_watched':
			try:
				from apis.simkl_api import simkl_advance_cour
				if simkl_advance_cour(tmdb_id, season, episode): clear_simkl_lists_cache()
			except Exception: pass
	watched_status_mark(watched_indicators, media_type, tmdb_id, action, season, episode, title)
	update_hidden_progress(tmdb_id)
	refresh_container(refresh)

def unmark_previous_episode(params):
	try:
		season, episode = int(params.get('season')), int(params.get('episode'))
		if episode == 1:
			season = params['season'] = season - 1
			meta = metadata.tvshow_meta('tmdb_id', params.get('tmdb_id'), settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
			params['episode'] = episode = next((i for i in meta['season_data'] if i['season_number'] == season))['episode_count']
		else: episode = params['episode'] = episode - 1
		return mark_episode(params)
	except: notification('Error')

def watched_status_mark(watched_indicators, media_type='', media_id='', action='', season='', episode='', title=''):
	try:
		last_played = get_last_played_value(watched_indicators)
		dbcon = get_database(watched_indicators)
		row = [(media_type, media_id, season, episode)]
		if action == 'mark_as_watched':
			dbcon.execute('INSERT OR REPLACE INTO watched VALUES (?, ?, ?, ?, ?, ?)', (media_type, media_id, season, episode, last_played, title))
			_mark_restored(watched_indicators, dbcon, 'unwatched', row)
		elif action == 'mark_as_unwatched':
			dbcon.execute('DELETE FROM watched WHERE (db_type = ? and media_id = ? and season = ? and episode = ?)', (media_type, media_id, season, episode))
			_mark_removed(watched_indicators, dbcon, 'unwatched', row)   # LOCAL PATCH 2026-10-03 (Batch 2)
		erase_bookmark(media_type, media_id, season, episode)
		# if media_type == 'episode': clear_cache_watched_tvshow_status()
	except: notification('Error')

def batch_watched_status_mark(watched_indicators, insert_list, action):
	try:
		dbcon = get_database(watched_indicators)
		# LOCAL PATCH 2026-10-03 (Batch 2): one transaction with its tombstones, so a sync never sees half a season
		with write_transaction(dbcon):
			if action == 'mark_as_watched':
				dbcon.executemany('INSERT OR IGNORE INTO watched VALUES (?, ?, ?, ?, ?, ?)', insert_list)
				_mark_restored(watched_indicators, dbcon, 'unwatched', insert_list)
			elif action == 'mark_as_unwatched':
				dbcon.executemany('DELETE FROM watched WHERE (db_type = ? and media_id = ? and season = ? and episode = ?)', insert_list)
				_mark_removed(watched_indicators, dbcon, 'unwatched', insert_list)
		batch_erase_bookmark(watched_indicators, insert_list, action)
		# clear_cache_watched_tvshow_status()
	except: notification('Error')

# LOCAL PATCH 2026-08-05 (Red Light R3 port): refresh provider watched data
# before building In-Progress + Next-Episodes lists so freshly-watched-elsewhere
# episodes surface immediately instead of waiting for the next 60min sync tick.
# LOCAL PATCH 2026-08-29: throttled. The comment here used to claim this was "cheap when
# already-synced (each provider's sync_activities compares timestamps and returns 'no
# changes' quickly)". Measurement says otherwise: comparing timestamps requires FETCHING
# the remote ones first, so every call is a network round-trip whether or not anything
# changed. Five consecutive calls timed 0.65 / 0.29 / 0.29 / 0.35 / 0.29 s -- roughly 8x
# the entire rest of a widget build (0.037s for 21 rows warm), and it runs on every
# get_next_episodes() and get_in_progress_tvshows().
#
# It is also mostly redundant: the provider monitors in service.py poll the same endpoint
# every 60 minutes, so the synchronous call only catches changes from the last hour.
#
# The guard lives in a WINDOW PROPERTY, not a module global, because reuselanguageinvoker
# is false: every widget is its own Python process, so a global would reset each time and
# throttle nothing. Window properties live in Kodi's GUI process and are shared across
# invocations -- exactly the scope wanted, so two widgets on one home screen sync once
# between them rather than twice.
#
# Staleness is bounded and safe. ws.mark_episode writes the provider's own local table at
# playback end, so anything watched in DeadLight is already current in the DB the widgets
# read; this sync only pulls in changes made elsewhere (phone, web).
#
# Failure is silent -- falls back to cached DB.
_SYNC_GUARD_PROP = 'deadlight.provider_sync_at'
_SYNC_GUARD_SECONDS = 60

def _refresh_provider_watched():
	try:
		wi = settings.watched_indicators()
		now = get_current_timestamp()
		try:
			# Provider id is part of the value: switching watched_indicators must not
			# inherit the previous provider's timestamp and skip its first sync.
			last_wi, last_at = get_property(_SYNC_GUARD_PROP).split(':')
			if int(last_wi) == wi and 0 <= now - int(last_at) < _SYNC_GUARD_SECONDS: return
		except Exception: pass   # unset or malformed -> fall through and sync
		# Stamped BEFORE the sync, not after, so two widgets starting together do not both
		# find the guard cold. That narrows the race rather than closing it; losing it
		# means two syncs, which is exactly today's unconditional behaviour.
		set_property(_SYNC_GUARD_PROP, '%s:%s' % (wi, now))
		if wi == 1: from apis.trakt_api import trakt_sync_activities as sync
		elif wi == 2: from apis.mdblist_api import mdbl_sync_activities as sync
		elif wi == 3: from apis.simkl_api import simkl_sync_activities as sync
		else: return
		# LOCAL PATCH 2026-09-26: off the render path. The sync used to run inline, so every first
		# widget render per minute waited ~0.3 s of round-trip -- 1.5-3x the build itself -- for a
		# check that almost always says 'not needed'. Now the list renders from the local DB and the
		# sync runs behind it; only when it actually pulled changes ('success' from all three
		# providers) do the widgets reload, which re-enters here inside the guard window and so
		# cannot loop. Non-daemon thread: the plugin process stays alive until it finishes.
		Thread(target=_sync_then_refresh, args=(sync,)).start()
	except Exception: pass

def _sync_then_refresh(sync):
	try:
		# LOCAL PATCH 2026-10-03: through the coalescer, like every other automatic reload. A bare kodi_refresh()
		# here was logged nowhere and folded into nothing: the 18:12 burst of 3-4 Continue Watching builds had no
		# widget.refresh line at all.
		if sync() == 'success': auto_kodi_refresh('provider sync')
	except Exception: pass


def get_next_episodes(nextep_content):
	_refresh_provider_watched()
	watched_db = get_database()
	if nextep_content == 0:
		data = watched_db.execute('''WITH cte AS (SELECT *, ROW_NUMBER() OVER (PARTITION BY media_id ORDER BY season DESC, episode DESC) rn FROM watched WHERE db_type == ?)
									SELECT media_id, season, episode, title, last_played FROM cte WHERE rn = 1''', ('episode',)).fetchall()
	else:
		data = watched_db.execute('SELECT media_id, season, episode, title, MAX(last_played), COUNT(*) AS COUNTER FROM watched WHERE db_type = ? GROUP BY media_id',
								('episode',)).fetchall()
	data = [{'media_ids': {'tmdb': int(i[0])}, 'season': int(i[1]), 'episode': int(i[2]), 'title': i[3], 'last_played': i[4]} for i in data]
	data.sort(key=lambda x: (x['last_played']), reverse=True)
	return data
	
def get_next(season, episode, watched_info, season_data, nextep_content):
	# LOCAL PATCH 2026-08-05 (Red Light R1 port): absolute-numbered anime
	# (One Piece S23E1170, Naruto Shippuden S1E500) reports an episode number
	# that exceeds any single season's episode_count. The naive +1 fallback
	# then rolls to `season+1, episode=1` which lands out-of-range → show
	# disappears from Next Episodes. Detect this case by comparing the
	# watched episode number against the max episode_count in season_data;
	# if the watched number is larger than any single season, treat it as
	# absolute and map back to the correct (season, episode) tuple by
	# walking season_data sequentially.
	# LOCAL PATCH 2026-10-15: specials stay specials. Season 0 went through the absolute remap below (S0E12 with no regular
	# season that long became some mid-series episode) and the +1 rollover (after the last special: S1E1).
	if season == 0:
		try: count = next((i.get('episode_count') for i in season_data or [] if i.get('season_number') == 0), None)
		except Exception: count = None
		return (0, episode + 1) if count and episode and episode < count else (None, None)
	if season_data and episode:
		try:
			ordered_seasons = sorted([i for i in season_data if i.get('season_number', 0) != 0], key=lambda x: x['season_number'])
			max_season_count = max([i.get('episode_count', 0) for i in ordered_seasons] or [0])
			if episode > max_season_count and ordered_seasons:
				# Absolute-numbered — walk seasons summing episode_count to find true (season, ep)
				running_total = 0
				for s in ordered_seasons:
					ec = s.get('episode_count', 0)
					if running_total + ec >= episode:
						season = s.get('season_number')
						episode = episode - running_total
						break
					running_total += ec
		except Exception: pass
	if episode == 0: episode = 1
	elif nextep_content == 0:
		try:
			episode_count = next((i['episode_count'] for i in season_data if i['season_number'] == season), None)
			# LOCAL PATCH 2026-10-15: a season season_data does not list has no next. `episode < None` raised into the except
			# below, which returned the CURRENT (season, episode) as the next one -- the chain replayed what was just watched.
			if episode_count is None: return None, None
			rollover = not episode < episode_count
			# LOCAL PATCH 2026-10-03: no rolling into a season the show does not list. 234 of 273 shows in
			# Continue Watching had none, so every build asked episodes_meta for each, and the misses are cached
			# as '[]' for 96 h -- 223 of them written in one build, so they all expire together and the next
			# build sent ~235 TMDb requests (x3-4 widget processes). season_data is already in the show meta.
			if rollover and not any(i.get('season_number') == season + 1 and (i.get('episode_count') or 0) > 0 for i in season_data):
				return None, None
			season = season if not rollover else season + 1
			episode = episode + 1 if not rollover else 1
		except Exception: return None, None   # LOCAL PATCH 2026-10-15: see above -- never the current episode as 'next'
	else:
		try:
			next_episode = 0
			relevant_seasons = [i for i in season_data if i['season_number'] >= season]
			for item in relevant_seasons:
				episode_count, item_season = item['episode_count'], item['season_number']
				if season == item_season:
					if episode >= episode_count:
						item_season, next_episode = None, None
						continue
					episode_range = range(episode + 1, episode_count + 1)
				else: episode_range = range(1, episode_count + 1)
				next_episode = next((i for i in episode_range if not get_watched_status_episode(watched_info, (item_season, i))), None)
				if next_episode: break
			# LOCAL PATCH 2026-10-18: the None, None was overwritten on the next line, and the bare except returned the
			# input pair -- the 10-15 'current episode offered as next' bug, still alive in this (unwatched-first) branch.
			if next_episode: season, episode = item_season, next_episode
			else: season, episode = None, None
		except: return None, None
	return season, episode

def get_in_progress_movies(dummy_arg, page_no):
	dbcon = get_database()
	data = dbcon.execute('SELECT media_id, title, last_played FROM progress WHERE db_type = ?', ('movie',)).fetchall()
	data = [{'media_id': i[0], 'title': i[1], 'last_played': i[2]} for i in data if not i[0] == '']
	if settings.lists_sort_order('progress') == 0: data = sort_for_article(data, 'title', settings.ignore_articles())
	else: data = sorted(data, key=lambda x: x['last_played'], reverse=True)
	return data

def get_in_progress_tvshows(dummy_arg, page_no):
	# results = cache_watched_tvshow_status(active_tvshows_information, 'progress')
	_refresh_provider_watched()  # LOCAL PATCH 2026-08-05 (Red Light R3 port)
	results = active_tvshows_information('progress')
	if settings.lists_sort_order('progress') == 0: results = sort_for_article(results, 'title', settings.ignore_articles())
	else: results = sorted(results, key=lambda x: x['last_played'], reverse=True)
	return results

# LOCAL PATCH 2026-09-04: accept a pre-computed hidden set.
#
# This used to derive it itself -- AND re-read settings.watched_indicators() to do so, even
# when the caller had already resolved both. On a Continue Watching render that meant
# get_hidden_progress_items ran three times for one widget (here, in
# indexers/continue_watching.build_continue_watching, and in
# indexers/episodes.continue_watching_plan). Cost per call depends on the provider: under
# watched_indicators=3 it is FOUR simkl_list() reads, so 12 per render; under 1 it is a
# trakt_cache read plus a repr eval each time.
#
# Default None preserves every existing call site's behaviour.
def get_in_progress_episodes(hidden=None):
	dbcon = get_database()
	data = dbcon.execute('SELECT media_id, season, episode, resume_point, last_played, title FROM progress WHERE db_type = ?', ('episode',)).fetchall()
	if hidden is None: hidden = get_hidden_progress_items(settings.watched_indicators()) or []
	hidden = hidden if isinstance(hidden, set) else set(hidden)
	if hidden:
		def _hidden(mid):
			try: return int(mid) in hidden
			except: return False
		data = [i for i in data if not _hidden(i[0])]
	episode_list = [{'media_ids': {'tmdb': i[0]}, 'season': int(i[1]), 'episode': int(i[2]), 'resume_point': float(i[3]), 'date': i[4], 'title': i[5]} for i in data]
	if settings.lists_sort_order('progress') == 0: episode_list = sort_for_article(episode_list, 'title', settings.ignore_articles())
	else: episode_list.sort(key=lambda k: k['date'], reverse=True)
	return episode_list

# LOCAL PATCH 2026-10-06: the Dropped lists under Movies, TV Shows and Anime (navigator_cache), from the selected watched
# provider: SIMKL's 'dropped' lists (movies, shows + anime), MDBList's sync/dropped, Trakt's hidden 'dropped', or the local
# hidden list. Only SIMKL drops movies, so Movies > Dropped is shown only with SIMKL (navigator.main, 'watched_provider').
# Provider order, duplicates removed; the anime / TV split is the list builder's (is_anime_list), as for In Progress.
def get_dropped_items(media_type, page_no):
	chosen, ids = settings.watched_indicators(), []
	try:
		if chosen == 3:
			if settings.simkl_user_active():
				from indexers.simkl_lists import _split_items
				for list_type in (('movies',) if media_type == 'movie' else ('shows', 'anime')):
					movies, shows = _split_items((simkl_list(list_type, 'dropped') or {}).get(list_type) or [], list_type)
					ids.extend(i['tmdb'] for i in (movies if media_type == 'movie' else shows))
		elif media_type == 'movie': pass   # Trakt, MDBList and the local list drop shows only
		elif chosen == 2:
			if settings.mdblist_user_active(): ids = mdbl_get_hidden_items('dropped') or []
		elif chosen == 1:
			if settings.trakt_user_active(): ids = trakt_get_hidden_items('dropped') or []
		else: ids = get_hidden_progress_items(0) or []
	except Exception: ids = []
	seen, results = set(), []
	for i in ids:
		try: i = str(int(i))
		except (TypeError, ValueError): continue
		if i not in seen:
			seen.add(i)
			results.append({'media_id': i})
	return results

def get_watched_items(media_type, page_no):
	if media_type == 'tvshow': results = active_tvshows_information('watched')
	else: results = [v for k,v in watched_info_movie().items()]
	if settings.lists_sort_order('watched') == 0: results = sort_for_article(results, 'title', settings.ignore_articles())
	else: results = sorted(results, key=lambda x: x['last_played'], reverse=True)
	return results

def get_recently_watched(media_type, short_list=0):
	watched_indicators = settings.watched_indicators()
	if media_type == 'movie':
		watched_movies = watched_info_movie().items()
		data = sorted([v for k,v in watched_movies], key=lambda x: x['last_played'], reverse=True)
		if short_list: data = data[:20]
	elif media_type == 'tvshow':
		watched_tvshows = watched_info_tvshow().items()
		data = sorted([v for k,v in watched_tvshows], key=lambda x: x['last_played'], reverse=True)
		if short_list: data = data[:20]
	else:
		dbcon = get_database(watched_indicators)
		data = dbcon.execute('SELECT media_id, season, episode, title, last_played FROM watched WHERE db_type = ? ORDER BY last_played DESC', ('episode',)).fetchall()
		data = [{'media_ids': {'tmdb': int(i[0])}, 'season': int(i[1]), 'episode': int(i[2]), 'title': i[3], 'last_played': i[4]}
					for i in data]
		if short_list: data = data[:20]
	return data
