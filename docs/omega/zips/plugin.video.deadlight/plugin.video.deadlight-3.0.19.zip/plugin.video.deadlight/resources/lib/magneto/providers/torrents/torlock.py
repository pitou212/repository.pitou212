# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-10-21: torlock -- Torlock's torznab API (www.torlock.com/torznab/api), searched by NAME. Ported from
	POV 6.10.17 (magneto upstream is no longer maintained; POV is the source now) and laid out like knaben.py.

	The torlock tested on 2026-09-28 scraped torlock2.com's HTML (reachable, not bundled). POV moved it to this API.
	Tested 2026-10-21 from this PC: 3/3 answers; Reacher S02E01 33 rows -- 25 that Torrentio lacks, all of them S02E01,
	17 seeded (NTb 1080p AMZN, FLUX 2160p DV, ELiTE / MeGusta x265) -- and Oppenheimer 100 rows, 39 Torrentio lacks.
	On by default (user's call), unlike the other name-search providers.

	API: /torznab/api?t=<tvsearch|movie>&q=<query>   No key. RSS/torznab XML: <item><title>, <size> (bytes) and
	<torznab:attr name="infohash|seeders|..." value="..."/>. Parsed with the standard library as bitmagnet.py does --
	it resolves no external entities, and Kodi's expat caps entity expansion.
"""

import re
import xml.etree.ElementTree as ET
from urllib.parse import quote_plus
from magneto.modules import client
from magneto.modules import source_utils
from magneto.modules import workers

_TORZNAB = '{http://torznab.com/schemas/2015/feed}attr'
_MOVIES, _TV = 'movie', 'tvsearch'


class source:
	priority = 3
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		self.language = ['en']
		self.base_link = 'https://www.torlock.com'
		self.search_link = '/torznab/api?t=%s&q=%s'
		self.min_seeders = 0

	def _query(self, category, query):
		"""torlock's rows for one query as {'title', 'size', 'infohash', 'seeders', ...}: rows with a hash, each hash once per
		scrape."""
		url = '%s%s' % (self.base_link, self.search_link % (category, quote_plus(query)))
		results = client.request(url, timeout=7)
		if not results: return []
		if '<!DOCTYPE' in results[:2048].upper(): return []   # a torznab feed never declares one; refuse any entity declarations
		rows = []
		for item in ET.fromstring(results).iter('item'):
			try:
				row = {'title': item.findtext('title') or '', 'size': item.findtext('size')}
				for attr in item.findall(_TORZNAB):
					if attr.get('name'): row[attr.get('name')] = attr.get('value')
				hash = (row.get('infohash') or '').lower()
				if len(hash) != 40 or hash in self.seen or not row['title']: continue
				self.seen.add(hash)
				row['infohash'] = hash
				rows.append(row)
			except: continue
		return rows

	def _item(self, row, name, name_info):
		"""The common part of an episode / movie / pack row, or None when it is below min_seeders."""
		try: seeders = int(row.get('seeders') or 0)
		except: seeders = 0
		if self.min_seeders > seeders: return None
		hash = row['infohash']
		url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
		quality, info = source_utils.get_release_quality(name_info, url)
		try:
			dsize, isize = source_utils.convert_size(float(row.get('size') or 0), to='GB')
			info.insert(0, isize)
		except: dsize = 0
		return {'provider': 'torlock', 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name, 'name_info': name_info,
				'quality': quality, 'language': 'en', 'url': url, 'info': ' | '.join(info), 'direct': False, 'debridonly': True, 'size': dsize}

	def sources(self, data, hostDict):
		self.items = []
		if not data: return self.items
		self.seen = set()
		try:
			self.aliases = data['aliases']
			self.year = data['year']
			if 'tvshowtitle' in data:
				self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
				self.episode_title = data['title']
				self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
				category = _TV
			else:
				self.title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
				self.episode_title = None
				self.hdlr = self.year
				category = _MOVIES
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			self.get_sources(category, '%s %s' % (re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title), self.hdlr))
			return self.items
		except:
			source_utils.scraper_error('TORLOCK')
			return self.items

	def get_sources(self, category, query):
		try: rows = self._query(category, query)
		except:
			source_utils.scraper_error('TORLOCK')
			return
		for row in rows:
			try:
				name = source_utils.clean_name(row['title'])
				if not source_utils.check_title(self.title, self.aliases, name, self.hdlr, self.year): continue
				name_info = source_utils.info_from_name(name, self.title, self.year, self.hdlr, self.episode_title)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				if not self.episode_title: # episodes returned by a movie query
					ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
					name_lower = name.lower()
					if any(re.search(item, name_lower) for item in ep_strings): continue
				item = self._item(row, name, name_info)
				if item: self.items.append(item)
			except:
				source_utils.scraper_error('TORLOCK')

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		self.items = []
		if not data: return self.items
		self.seen = set()
		try:
			self.search_series = search_series
			self.total_seasons = total_seasons
			self.bypass_filter = bypass_filter
			self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			self.aliases = data['aliases']
			self.imdb = data['imdb']
			self.year = data['year']
			self.season_x = data['season']
			self.season_xx = self.season_x.zfill(2)
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			query = re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title)
			if search_series: queries = [query + ' Season', query + ' Complete']
			else: queries = [query + ' S%s' % self.season_xx, query + ' Season %s' % self.season_x]
			threads = [workers.Thread(self.get_sources_packs, q) for q in queries]
			[i.start() for i in threads]
			[i.join() for i in threads]
			return self.items
		except:
			source_utils.scraper_error('TORLOCK')
			return self.items

	def get_sources_packs(self, query):
		try: rows = self._query(_TV, query)
		except:
			source_utils.scraper_error('TORLOCK')
			return
		for row in rows:
			try:
				name = source_utils.clean_name(row['title'])
				episode_start, episode_end = 0, 0
				if not self.search_series:
					if not self.bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(self.title, self.aliases, self.year, self.season_x, name)
						if not valid: continue
					package = 'season'
				else:
					if not self.bypass_filter:
						valid, last_season = source_utils.filter_show_pack(self.title, self.aliases, self.imdb, self.year, self.season_x, name, self.total_seasons)
						if not valid: continue
					else: last_season = self.total_seasons
					package = 'show'
				name_info = source_utils.info_from_name(name, self.title, self.year, season=self.season_x, pack=package)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				item = self._item(row, name, name_info)
				if not item: continue
				item['package'] = package
				if self.search_series: item['last_season'] = last_season
				elif episode_start: item.update(source_utils.pack_range_fields(episode_start, episode_end))
				self.items.append(item)
			except:
				source_utils.scraper_error('TORLOCK')
