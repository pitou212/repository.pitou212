# -*- coding: utf-8 -*-
"""
	LOCAL PATCH 2026-10-19: knaben -- Knaben's JSON search API (api.knaben.org/v2), searched by NAME.

	Back in bitsearch's place (bitsearch.eu: Cloudflare 520 / 7 s timeouts on every TV query, 2026-10-19). The 09-28
	knaben scraped HTML and took seconds per search, so it was dropped for apibay on 09-29. Upstream magneto 6.10.04
	moved it to this API. Timed 2026-10-19: 0.7-1.6 s per query, Oppenheimer 104 rows, The Bear S03 150 rows, the
	Monster: The Lizzie Borden Story S01E01 row (no IMDb id on TMDb -- why name search is bundled at all).

	API: https://api.knaben.org/v2/search?dead&o=date&c=<category>&q=<query>   No key.
	  {'hits': [{'title', 'hash' (upper case), 'seeders', 'bytes', 'tracker', ...}], 'total': {...}}
	  c=3000000 movies, c=2000000 TV. An aggregator: most rows are The Pirate Bay's (so apibay overlaps), plus
	  YTS, 1337x and others. Its matching is loose (The Bear S03E01 also returns 'The Great S03E01 ... the Bear'),
	  so check_title does the real filtering. One answer seen truncated mid-JSON: a parse error is a failed query.

	Laid out like apibay.py (episode / season-pack / show-pack queries in parallel threads), using client.request
	so the loading window's ok / failed tally sees it.
"""

import json
import re
from urllib.parse import quote_plus
from magneto.modules import client
from magneto.modules import source_utils
from magneto.modules import workers

_MOVIES, _TV = '3000000', '2000000'


class source:
	priority = 3
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	def __init__(self):
		self.language = ['en']
		self.base_link = 'https://api.knaben.org'
		self.search_link = '/v2/search?dead&o=date&c=%s&q=%s'
		self.min_seeders = 0

	def _query(self, category, query):
		"""knaben's rows for one query: rows with a hash, each hash once per scrape."""
		url = '%s%s' % (self.base_link, self.search_link % (category, quote_plus(query)))
		results = client.request(url, timeout=5)
		if not results: return []
		rows = []
		for row in json.loads(results).get('hits') or []:
			hash = (row.get('hash') or '').lower()
			if len(hash) != 40 or hash in self.seen: continue
			self.seen.add(hash)
			rows.append(row)
		return rows

	def _item(self, row, name, name_info):
		"""The common part of an episode / movie / pack row, or None when it is below min_seeders."""
		try: seeders = int(row.get('seeders') or 0)
		except: seeders = 0
		if self.min_seeders > seeders: return None
		hash = row['hash'].lower()
		url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
		quality, info = source_utils.get_release_quality(name_info, url)
		try:
			dsize, isize = source_utils.convert_size(float(row.get('bytes') or 0), to='GB')
			info.insert(0, isize)
		except: dsize = 0
		return {'provider': 'knaben', 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name, 'name_info': name_info,
				'quality': quality, 'language': 'en', 'url': url, 'info': ' | '.join(info), 'direct': False, 'debridonly': True, 'size': dsize}

	def sources(self, data, hostDict):
		self.items = []
		if not data: return self.items
		self.seen = set()
		try:
			self.aliases = data['aliases']
			self.year = data['year']
			if 'tvshowtitle' in data:
				self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
				self.episode_title = data['title']
				self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
				category = _TV
			else:
				self.title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
				self.episode_title = None
				self.hdlr = self.year
				category = _MOVIES
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			self.get_sources(category, '%s %s' % (re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title), self.hdlr))
			return self.items
		except:
			source_utils.scraper_error('KNABEN')
			return self.items

	def get_sources(self, category, query):
		try: rows = self._query(category, query)
		except:
			source_utils.scraper_error('KNABEN')
			return
		for row in rows:
			try:
				name = source_utils.clean_name(row['title'])
				if not source_utils.check_title(self.title, self.aliases, name, self.hdlr, self.year): continue
				name_info = source_utils.info_from_name(name, self.title, self.year, self.hdlr, self.episode_title)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				if not self.episode_title: # episodes returned by a movie query
					ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
					name_lower = name.lower()
					if any(re.search(item, name_lower) for item in ep_strings): continue
				item = self._item(row, name, name_info)
				if item: self.items.append(item)
			except:
				source_utils.scraper_error('KNABEN')

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		self.items = []
		if not data: return self.items
		self.seen = set()
		try:
			self.search_series = search_series
			self.total_seasons = total_seasons
			self.bypass_filter = bypass_filter
			self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			self.aliases = data['aliases']
			self.imdb = data['imdb']
			self.year = data['year']
			self.season_x = data['season']
			self.season_xx = self.season_x.zfill(2)
			self.undesirables = source_utils.get_undesirables()
			self.check_foreign_audio = source_utils.check_foreign_audio()
			query = re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title)
			if search_series: queries = [query + ' Season', query + ' Complete']
			else: queries = [query + ' S%s' % self.season_xx, query + ' Season %s' % self.season_x]
			threads = [workers.Thread(self.get_sources_packs, q) for q in queries]
			[i.start() for i in threads]
			[i.join() for i in threads]
			return self.items
		except:
			source_utils.scraper_error('KNABEN')
			return self.items

	def get_sources_packs(self, query):
		try: rows = self._query(_TV, query)
		except:
			source_utils.scraper_error('KNABEN')
			return
		for row in rows:
			try:
				name = source_utils.clean_name(row['title'])
				episode_start, episode_end = 0, 0
				if not self.search_series:
					if not self.bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(self.title, self.aliases, self.year, self.season_x, name)
						if not valid: continue
					package = 'season'
				else:
					if not self.bypass_filter:
						valid, last_season = source_utils.filter_show_pack(self.title, self.aliases, self.imdb, self.year, self.season_x, name, self.total_seasons)
						if not valid: continue
					else: last_season = self.total_seasons
					package = 'show'
				name_info = source_utils.info_from_name(name, self.title, self.year, season=self.season_x, pack=package)
				if source_utils.remove_lang(name_info, self.check_foreign_audio): continue
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				item = self._item(row, name, name_info)
				if not item: continue
				item['package'] = package
				if self.search_series: item['last_season'] = last_season
				elif episode_start: item.update(source_utils.pack_range_fields(episode_start, episode_end))
				self.items.append(item)
			except:
				source_utils.scraper_error('KNABEN')
