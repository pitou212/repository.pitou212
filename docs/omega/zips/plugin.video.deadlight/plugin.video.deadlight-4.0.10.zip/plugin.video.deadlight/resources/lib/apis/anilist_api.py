# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-28: AniList (GraphQL) browse client.
# Ported from Otaku's AniListBrowser.py (~1644 LOC) but stripped down to the
# minimal browse surface DeadLight needs. Jikan/MAL was the original target
# but is shutting down Oct 2026 — AniList (community-owned, GraphQL, no auth
# for browse, 30 req/min -- was 90; AniList lowered it, X-RateLimit-Limit read 30 on
# 2026-09-06) is the actively-maintained replacement.
#
# Endpoint: https://graphql.anilist.co
# Docs: https://anilist.gitbook.io/anilist-apiv2-docs/
# All browse methods return: {'items': [...], 'has_next': bool, 'page': int}

import datetime
import json as _json
import time

from caches.lists_cache import lists_cache_object, lists_cache
from caches.base_cache import is_failed_result
from caches.settings_cache import get_setting, set_setting
from modules.kodi_utils import make_session, logger, notification, ok_dialog, kodi_dialog, get_property, set_property, qr_dialog, cooldown_active, start_cooldown
from modules.utils import safe_err   # LOCAL PATCH 2026-10-25 (4.0.5): request errors logged without their url / query keys

_ANILIST_URL = 'https://graphql.anilist.co'
_APP_REGISTER_URL = 'https://anilist.co/settings/developer'

session = make_session(_ANILIST_URL)


# ═══════════════════════════════════════════════════════════════════════════
#  Account layer (LOCAL PATCH 2026-08-29)
#
#  Everything above the mutations stays anonymous -- browse never needs a token and must
#  keep working for users who never log in. Settings accessors strip whitespace, matching
#  simkl_api._client_id, because these values arrive by copy-paste.
# ═══════════════════════════════════════════════════════════════════════════

def _setting(name):
	val = (get_setting('deadlight.anilist.%s' % name, '') or '').strip()
	return val if val and val != 'empty_setting' else ''


def _access_token(): return _setting('token')


def _auth_headers():
	token = _access_token()
	return {'Authorization': 'Bearer %s' % token} if token else {}


def anilist_user_active():
	return bool(_access_token() and _setting('user'))

_SEASONS = ('WINTER', 'SPRING', 'SUMMER', 'FALL')

# GraphQL fragment for the minimal Media fields we need to hand off to TMDb.
# Full field list (title/coverImage/description/format/episodes/status/genres/
# duration/countryOfOrigin/averageScore/startDate) is what Otaku pulls too —
# reused so we can display richer info later without re-fetching.
_MEDIA_FIELDS = '''
	id
	idMal
	title { romaji english native }
	coverImage { extraLarge large }
	bannerImage
	startDate { year month day }
	endDate { year }
	description
	format
	episodes
	status
	genres
	# LOCAL PATCH 2026-08-29: AniList tags are far more specific than TMDb genres
	# ("Female Protagonist", "Time Manipulation", "Episodic"). rank is 0-100 and
	# isMediaSpoiler marks the ones that give plot away -- both are needed to filter
	# sensibly, so pull all three fields.
	tags { name rank category isMediaSpoiler }
	duration
	averageScore
	countryOfOrigin
	trailer { id site }
'''


def _current_season():
	"""Return (season_enum, year) for the current calendar quarter."""
	now = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
	season = _SEASONS[(now.month - 1) // 3]
	return season, now.year


def _shift_season(base_season, base_year, direction):
	"""Advance/rewind by one season. direction=+1 for next, -1 for last."""
	idx = _SEASONS.index(base_season)
	new_idx = (idx + direction) % 4
	new_season = _SEASONS[new_idx]
	# Year rolls over on WINTER→FALL (backwards) or FALL→WINTER (forwards).
	if direction == 1 and base_season == 'FALL':
		return new_season, base_year + 1
	if direction == -1 and base_season == 'WINTER':
		return new_season, base_year - 1
	return new_season, base_year


def _season_for(period):
	"""period ∈ {'this', 'next', 'last'} → (season_enum, year)."""
	base_season, base_year = _current_season()
	if period == 'this': return base_season, base_year
	if period == 'next': return _shift_season(base_season, base_year, +1)
	if period == 'last': return _shift_season(base_season, base_year, -1)
	return base_season, base_year


# ═══════════════════════════════════════════════════════════════════════════
#  GraphQL POST + response cache
# ═══════════════════════════════════════════════════════════════════════════

def _warn_once(user_msg, log_msg):
	"""LOCAL PATCH 2026-09-07: one toast per Kodi session, same shape as
	scrapers/aiostreams._warn_once. The window property dies with Kodi, so the next
	session warns again if the outage persists -- which is the right cadence."""
	logger('AniList outage', log_msg)
	if get_property('deadlight.anilist.outage_warned') == 'true': return
	set_property('deadlight.anilist.outage_warned', 'true')
	notification(user_msg, 5000)


def _post_anilist(query, variables, auth=False, node='Page'):
	"""Uncached POST. lists_cache_object handles caching around this.

	auth=True attaches the user's bearer token -- required for anything touching Viewer or
	SaveMediaListEntry. node names the field to unwrap from `data`; the browse queries all
	return a Page, the account queries and mutations do not, so they pass node=None and get
	the whole `data` object back.
	"""
	# LOCAL PATCH 2026-10-20: while AniList's own back-off runs (a 429 / 5xx / timeout started it: _start_score_cooldown),
	# no request but the account ones (auth=True: list edits, scrobbles). Every other caller still sent one and waited for
	# the next 429 -- two season lists on 10-20 spent 1.0-1.5 s each on a cour-name lookup AniList refused, a minute after
	# a cold Trending page 2 used up its allowance. None is the failure every caller already handles, and none caches it.
	if not auth and anilist_score_on_cooldown(): return None
	try:
		# LOCAL PATCH 2026-09-07: browse now sends the bearer token WHEN ONE EXISTS. It used
		# to go out strictly anonymous, on the sound reasoning that browse never needed auth
		# and had to keep working for users who never log in. AniList inverted that on
		# 2026-09-07 by disabling anonymous access -- verified with one query sent twice,
		# differing only in this header:
		#   no auth   -> HTTP 403 'The AniList API has been temporarily disabled due to
		#                severe stability issues.'
		#   w/ bearer -> HTTP 200, full payload
		# _auth_headers() already yields {} with no token, so a logged-out user keeps exactly
		# the old anonymous request. Not a temporary hack: sending a token we hold is correct
		# either way, and the retry below keeps it safe once anonymous access returns.
		headers = _auth_headers() or None
		r = session.post(_ANILIST_URL, json={'query': query, 'variables': variables},
						headers=headers, timeout=15)
		# LOCAL PATCH 2026-09-07: if the TOKEN is what got us rejected on a call that never
		# needed one, fall back to the anonymous request this used to make. Without it a stale
		# token would break browse for everyone the moment AniList re-enables anonymous
		# access -- turning today's fix into tomorrow's outage. auth=True is excluded: those
		# calls are meaningless without a user.
		# 400 is in the list because that is what AniList actually answers for a bad token:
		# {"data": null, "errors": [{"message": "Invalid token", "status": 400}]} -- NOT 401,
		# which the first version of this retry assumed and so never fired. A genuinely
		# malformed query also yields 400; retrying that anonymously just fails again, one
		# wasted request in an already-broken case.
		if r.status_code in (400, 401, 403) and not auth and headers:
			logger('AniList: token rejected on browse', 'HTTP %s -- retrying anonymously' % r.status_code)
			r = session.post(_ANILIST_URL, json={'query': query, 'variables': variables},
							headers=None, timeout=15)
		# A dead or revoked token answers 400/401 with an errors array; treat it like any
		# other miss rather than raising into a caller that may be tearing down playback.
		# LOCAL PATCH 2026-09-07: say so when AniList itself is down. Its 2026-09-07 outage
		# answered anonymous calls with 403 and a specific message, and this function swallowed
		# that to None -- every menu simply came up empty, which reads as "the add-on broke".
		# Only reached when no token was sent, or the token was rejected and the anonymous
		# retry above also failed: exactly the users the token fix cannot help.
		if r.status_code == 403 and not auth:
			try: _msg = str((r.json().get('errors') or [{}])[0].get('message', ''))
			except Exception: _msg = ''
			if 'disabled' in _msg.lower():
				# LOCAL PATCH 2026-10-21: the lists fall back to MyAnimeList / Kitsu now (apis/anime_backup.py), and the
				# outage backs off like a 5xx does: each page asked twice (token, then anonymous) and was refused twice
				# before the backup could start, and every score lookup did the same.
				_warn_once('AniList has disabled its API (stability issues) - anime lists from MyAnimeList / Kitsu until it returns',
					'anonymous browse refused by AniList: %s' % _msg[:120])
				_start_score_cooldown(600, 'API disabled')
		if r.status_code in (400, 401) and auth:
			logger('AniList: auth rejected', 'HTTP %s -- token may be expired or revoked' % r.status_code)
			return None
		# LOCAL PATCH 2026-09-15: record a throttle. raise_for_status turns a 429 into the
		# same None every other failure produces, so per-title callers (the rating chip's
		# anilist_average_score) had no way to tell "AniList is rate-limiting us" from "this
		# title has no score" and would keep paying for guaranteed failures. Net behaviour is
		# unchanged for existing callers -- a 429 already ended up as None.
		if r.status_code == 429:
			try: _retry = int(r.headers.get('Retry-After') or 60)
			except (TypeError, ValueError): _retry = 60
			_start_score_cooldown(max(30, min(_retry, 3600)), 'HTTP 429')
			return None
		# LOCAL PATCH 2026-10-15: AniList DOWN backs off too, not only a 429 -- see the except below.
		if r.status_code >= 500:
			_start_score_cooldown(600, 'HTTP %s' % r.status_code)
			return None
		r.raise_for_status()
		data = r.json()
		if 'errors' in data:
			if auth: logger('AniList: query errors', str(data['errors'])[:200])
			return None
		data = data.get('data') or {}
		return data if node is None else data.get(node)
	# LOCAL PATCH 2026-10-15: a timeout or a refused connection starts the same cooldown a 429 does (10 min). Nothing
	# backed off from an unreachable AniList: metadata._anilist_air_times asks once per recent episode of an airing
	# season (up to ~12), each up to this 15 s timeout, inside a widget -- and again on every read of that season.
	# LOCAL PATCH 2026-10-19: requests' exceptions imported HERE, not at module level -- that one line loaded all of
	# requests (~0.3 s) on every AniList page and widget, cached or not (reuselanguageinvoker is off: each call is a
	# fresh interpreter). By the time a request has raised, the lazy session has imported it anyway.
	except Exception as e:
		try:
			from requests import exceptions as _rq_exc
			if isinstance(e, (_rq_exc.Timeout, _rq_exc.ConnectionError)): _start_score_cooldown(600, type(e).__name__)
		except Exception: pass
		return None


# LOCAL PATCH 2026-10-03 (3.0.8): 20 per browse page, matching the TMDb catalogue pages. Every row is a full TMDb meta
# build (Fribb -> TMDb id -> tvshow_meta) and a cold one costs a request; 25 made the AniList pages the slowest
# catalogue in the add-on for no visible gain (one screen of a poster wall shows 10-14).
_BROWSE_PAGE_SIZE = 20

def _cached_page(cache_key, query, variables):
	"""Return {'items': [...], 'has_next': bool} from a cached AniList query.
	lists_cache_object stores the pickled result under `string=cache_key`."""
	# LOCAL PATCH 2026-10-22: Anime Catalogues = MyAnimeList / Kitsu -- that service first (the other one for a list it cannot
	# answer), AniList only when both fail. AniList chosen: AniList first and the backup on failure, as below.
	from modules.settings import anime_catalogue_provider
	provider = anime_catalogue_provider()
	if provider != 'anilist':
		try:
			from apis.anime_backup import page as backup_page
			chosen = backup_page(variables, first=provider, announce=False)
			if chosen: return chosen
		except Exception as e: logger('anime catalogues', '%s failed: %s' % (provider, safe_err(e)))
	def _fetch(_dummy_arg):
		res = _post_anilist(query, variables)
		# LOCAL PATCH 2026-09-07: return {} on FAILURE rather than an empty-but-valid-looking
		# page. lists_cache_object drops its TTL to 0.3 only for [] / {} / '' / None
		# (lists_cache.py:43), and {'items': [], 'has_next': False} is a populated dict -- so a
		# failed request was cached for the FULL duration. During the AniList anonymous-access
		# outage that meant every menu opened went blank and stayed blank long after the API
		# recovered. All three callers already coalesce a falsy return via
		# `or {'items': [], 'has_next': False}`, so nothing downstream changes.
		# LOCAL PATCH 2026-10-19: a request that got no answer (429, 5xx, timeout) is {'success': False}, which
		# base_cache.cache_ttl never stores -- it was {} and so kept 0.3 h, and one 23-second AniList throttle on 10-19
		# blanked all 18 browse pages (every anime menu row and home widget) for 18 minutes. The next open asks again;
		# an answered-but-empty page below keeps the short TTL.
		if not res: return {'success': False}
		items = res.get('ANIME') or res.get('media') or []
		# LOCAL PATCH 2026-09-30: an EMPTY page is a failure too. At 09:31 all four home rows (airing
		# last / this / next season, trending this season) cached {'items': [], ...} for the full
		# 24 h -- AniList had answered, but with nothing -- and stayed blank for the rest of the day
		# while the API was fine again. A browse page is never legitimately empty except one past
		# the last, and that one costing a re-ask every ~18 min is nothing.
		if not items: return {}
		_prime_entries(items)   # LOCAL PATCH 2026-10-20: the page's entries (episodes, titles, covers) -- see anilist_entries
		return {
			'items': items,
			'has_next': (res.get('pageInfo') or {}).get('hasNextPage', False),
		}
	# lists_cache_object signature: (function, string, *args) — pass a
	# throwaway arg since _fetch requires one.
	# LOCAL PATCH 2026-08-29: key suffixed _t1 when `tags` joined _MEDIA_FIELDS. Pages cached
	# before that lack the field entirely and would show no tags until the 48h TTL lapsed.
	# LOCAL PATCH 2026-10-03 (3.0.8): _t2 -- browse pages are 20 items now (see _BROWSE_PAGE_SIZE); a _t1 row holds 25.
	result = lists_cache_object(_fetch, '%s_t2' % cache_key, 1)
	# LOCAL PATCH 2026-10-21: AniList did not answer (down, throttling, backing off) -- the same list from MyAnimeList or
	# Kitsu (apis/anime_backup.py) rather than an empty menu. Only a failure: an answered empty page is the end of a list.
	if is_failed_result(result):
		try:
			from apis.anime_backup import page as backup_page
			return backup_page(variables)
		except Exception as e:
			logger('anime backup', 'failed: %s' % safe_err(e))
			return {}   # the callers' `or {'items': [], ...}` takes it from here
	# LOCAL PATCH 2026-10-20: the page already carries each title's score, tags and genres (_MEDIA_FIELDS) -- prime them,
	# so the rating flush after the list (metadata._prime_anilist_scores) does not ask AniList for them again
	for media in (result or {}).get('items') or []:
		try:
			if 'averageScore' in media and int(media['id']) not in _SCORES_PRIMED: _SCORES_PRIMED[int(media['id'])] = _score_record(media)
		except (KeyError, TypeError, ValueError): continue
	return result


# ═══════════════════════════════════════════════════════════════════════════
#  Query templates
# ═══════════════════════════════════════════════════════════════════════════

_BROWSE_QUERY = '''
query (
	$page: Int = 1,
	$perpage: Int = 25,
	$type: MediaType,
	$isAdult: Boolean = false,
	$season: MediaSeason,
	$year: String,
	$status: MediaStatus,
	$format: [MediaFormat],
	$genre: [String],
	$sort: [MediaSort] = [POPULARITY_DESC, SCORE_DESC]
) {
	Page(page: $page, perPage: $perpage) {
		pageInfo { hasNextPage }
		ANIME: media(
			type: $type,
			season: $season,
			startDate_like: $year,
			sort: $sort,
			status: $status,
			format_in: $format,
			genre_in: $genre,
			isAdult: $isAdult
		) {
''' + _MEDIA_FIELDS + '''
		}
	}
}
'''

_SEARCH_QUERY = '''
query ($page: Int = 1, $perpage: Int = 25, $search: String, $type: MediaType, $isAdult: Boolean = false) {
	Page(page: $page, perPage: $perpage) {
		pageInfo { hasNextPage }
		ANIME: media(
			search: $search,
			type: $type,
			sort: SEARCH_MATCH,
			isAdult: $isAdult
		) {
''' + _MEDIA_FIELDS + '''
		}
	}
}
'''


# ═══════════════════════════════════════════════════════════════════════════
#  Public browse methods — one per menu entry
#  All return {'items': [...], 'has_next': bool, 'page': int}
# ═══════════════════════════════════════════════════════════════════════════

def _airing_season(period, sort, page_no):
	season, year = _season_for(period)
	variables = {
		'page': int(page_no),
		'perpage': _BROWSE_PAGE_SIZE,
		'type': 'ANIME',
		'season': season,
		'year': '%s%%' % year,
		'sort': [sort],
	}
	cache_key = 'anilist_airing_%s_%s_%s' % (period, sort, page_no)
	res = _cached_page(cache_key, _BROWSE_QUERY, variables) or {'items': [], 'has_next': False}
	res['page'] = int(page_no)
	return res


# LOCAL PATCH 2026-09-04: fmt/genre ride the same engine. AniList's media() takes
# format_in and genre_in alongside everything already passed, so a format row is the
# existing ranked browse with one more filter -- not a new code path. This is where
# Otaku's Movies / TV Shorts / OVAs / ONAs / Specials rows come from; same API.
def _ranked(sort, period_mode, page_no, fmt=None, genre=None):
	"""period_mode ∈ {'all_time', 'this_year', 'last_year', 'this_season', 'last_season'}"""
	variables = {
		'page': int(page_no),
		'perpage': _BROWSE_PAGE_SIZE,
		'type': 'ANIME',
		'sort': [sort],
	}
	if period_mode == 'this_year':
		variables['year'] = '%s%%' % datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None).year
	elif period_mode == 'last_year':
		variables['year'] = '%s%%' % (datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None).year - 1)
	elif period_mode == 'this_season':
		season, year = _season_for('this')
		variables['season'] = season
		variables['year'] = '%s%%' % year
	elif period_mode == 'last_season':
		season, year = _season_for('last')
		variables['season'] = season
		variables['year'] = '%s%%' % year
	# 'all_time' -> no year/season filter
	if fmt: variables['format'] = list(fmt)
	if genre: variables['genre'] = list(genre)
	# the filters MUST reach the cache key or every format row would serve whichever one
	# was fetched first out of lists_cache.
	cache_key = 'anilist_%s_%s_%s%s%s' % (sort, period_mode, page_no,
			'_f' + '.'.join(fmt) if fmt else '', '_g' + '.'.join(genre) if genre else '')
	res = _cached_page(cache_key, _BROWSE_QUERY, variables) or {'items': [], 'has_next': False}
	res['page'] = int(page_no)
	return res


# Season / airing
# LOCAL PATCH 2026-10-20: this / last season are the SAME request as Popular This Season / Trending Last Season (same
# variables, same query) and were cached under a second key, so each was fetched twice -- the page prefetch doubled it.
# They go through _ranked now and share one cache row. Next season has no _ranked twin.
def anilist_airing_this_season(page_no): return _ranked('POPULARITY_DESC', 'this_season', page_no)
def anilist_airing_next_season(page_no): return _airing_season('next', 'POPULARITY_DESC', page_no)
def anilist_airing_last_season(page_no): return _ranked('TRENDING_DESC', 'last_season', page_no)

# Trending
def anilist_trending_this_season(page_no): return _ranked('TRENDING_DESC', 'this_season', page_no)
def anilist_trending_this_year(page_no):   return _ranked('TRENDING_DESC', 'this_year', page_no)
def anilist_trending_all_time(page_no):    return _ranked('TRENDING_DESC', 'all_time', page_no)

# Popular
def anilist_popular_this_season(page_no):  return _ranked('POPULARITY_DESC', 'this_season', page_no)
def anilist_popular_this_year(page_no):    return _ranked('POPULARITY_DESC', 'this_year', page_no)
def anilist_popular_all_time(page_no):     return _ranked('POPULARITY_DESC', 'all_time', page_no)

# Top rated
def anilist_top_100(page_no):              return _ranked('SCORE_DESC', 'all_time', page_no)

# Most favorited
def anilist_favourites_all_time(page_no):  return _ranked('FAVOURITES_DESC', 'all_time', page_no)

# LOCAL PATCH 2026-09-04: periods the engine already supported but nothing exposed.
def anilist_popular_last_year(page_no):    return _ranked('POPULARITY_DESC', 'last_year', page_no)
def anilist_trending_last_season(page_no): return _ranked('TRENDING_DESC', 'last_season', page_no)

# LOCAL PATCH 2026-09-04: browse by format. MUSIC is deliberately absent -- _classify in
# indexers/anilist_lists.py returns None for it and _render drops those items, so a Music
# row would fetch happily and then display nothing.
def anilist_movies(page_no):     return _ranked('POPULARITY_DESC', 'all_time', page_no, fmt=['MOVIE'])
def anilist_tv_shorts(page_no):  return _ranked('POPULARITY_DESC', 'all_time', page_no, fmt=['TV_SHORT'])
def anilist_ovas(page_no):       return _ranked('POPULARITY_DESC', 'all_time', page_no, fmt=['OVA'])
def anilist_onas(page_no):       return _ranked('POPULARITY_DESC', 'all_time', page_no, fmt=['ONA'])
def anilist_specials(page_no):   return _ranked('POPULARITY_DESC', 'all_time', page_no, fmt=['SPECIAL'])


# Search
def anilist_search(query, page_no):
	variables = {'page': int(page_no), 'perpage': 25, 'search': query, 'type': 'ANIME'}
	cache_key = 'anilist_search_%s_%s' % (query, page_no)
	res = _cached_page(cache_key, _SEARCH_QUERY, variables) or {'items': [], 'has_next': False}
	res['page'] = int(page_no)
	return res


# ═══════════════════════════════════════════════════════════════════════════
#  Romaji title lookup by MAL id
#
#  LOCAL PATCH 2026-08-10: replaces the `mal_title` column of the retired
#  Goldenfreddy anime_mappings DB (upstream frozen since 2026-05-31, so it was
#  missing titles for ~30% of current-season anime — exactly the shows most
#  likely to be scraped). AniList always has them and is authoritative.
#
#  Romaji titles are what anime torrent releases actually use (Nyaa lists
#  "Tensei Shitara Slime Datta Ken", not TMDb's "That Time I Got Reincarnated
#  as a Slime"), so this feeds the nyaa search-alias path in scrapers/external.py.
#
#  Cost: ~600ms per uncached call, so results are cached 30 days — romaji titles
#  never change. The bulk variant fetches every cour of a show in ONE request,
#  so scraping any episode of a show warms the whole franchise at once.
# ═══════════════════════════════════════════════════════════════════════════

# LOCAL PATCH 2026-10-03 (Batch 4): MAL ids are NOT unique on AniList. MAL 61469 (Steel Ball Run) is both 190327
# '1st STAGE' (1 ep) and 210482 '2nd & 3rd STAGE' (11 eps). Every MAL-keyed query below asks for `id` and `sort: ID`
# so a split comes back in a known order and can be resolved on purpose (_pick_per_mal) instead of by whichever
# entry a loop saw last. 25 MAL ids per request: a split returns more rows than ids, and the page holds 50.
_MAL_CHUNK = 25

_ROMAJI_BY_MAL_QUERY = '''
query ($idMal: Int) {
	Page(page: 1, perPage: 1) {
		ANIME: media(idMal: $idMal, type: ANIME, sort: ID) {
			id
			idMal
			title { romaji english native }
		}
	}
}
'''

_ROMAJI_BULK_QUERY = '''
query ($idMal_in: [Int]) {
	Page(page: 1, perPage: 50) {
		ANIME: media(idMal_in: $idMal_in, type: ANIME, sort: ID) {
			id
			idMal
			title { romaji english native }
			coverImage { extraLarge large }
		}
	}
}
'''

_MEDIA_BULK_BY_ID_QUERY = '''
query ($ids: [Int]) {
	Page(page: 1, perPage: 50) {
		ANIME: media(id_in: $ids, type: ANIME) {
			id
			idMal
			episodes
			startDate { year month day }
			title { romaji english native }
			coverImage { extraLarge large }
		}
	}
}
'''


def _fribb_anilist_for_mal(mal_id):
	try:
		from caches.fribb_mappings import mal_to_fribb
		return int((mal_to_fribb(mal_id) or {}).get('anilist_id') or 0) or None
	except Exception: return None


def _pick_per_mal(medias):
	"""({mal_id: media}, {split mal ids}) from AniList media nodes. When one MAL id came back as several entries,
	the one Fribb maps that MAL id to wins (Fribb's row is what every other id lookup here follows), else the
	lowest AniList id -- the original entry, which is also what the single-id lookup has always returned."""
	groups = {}
	for media in medias or []:
		try: groups.setdefault(int(media.get('idMal')), []).append(media)
		except (TypeError, ValueError): continue
	out, split = {}, set()
	for mid, nodes in groups.items():
		nodes = sorted(nodes, key=lambda m: int(m.get('id') or 0))
		pick = nodes[0]
		if len(nodes) > 1:
			split.add(mid)
			want = _fribb_anilist_for_mal(mid)
			pick = next((m for m in nodes if want and int(m.get('id') or 0) == want), nodes[0])
		out[mid] = pick
	return out, split

_TITLE_CACHE_HOURS = 720   # 30 days — romaji titles are immutable in practice


def _pick_romaji(media):
	"""Prefer romaji (what release groups use), fall back to native then english."""
	t = (media or {}).get('title') or {}
	return t.get('romaji') or t.get('native') or t.get('english') or None


def anilist_romaji_for_mal(mal_id):
	"""MAL id -> romaji title (str) or None. Cached 30 days."""
	if not mal_id: return None
	try: mal_id = int(mal_id)
	except (TypeError, ValueError): return None
	def _fetch(_dummy):
		res = _post_anilist(_ROMAJI_BY_MAL_QUERY, {'idMal': mal_id})
		# Distinguish "request failed" from "AniList genuinely has no such id":
		# returning {} makes lists_cache_object apply its 0.3h short TTL, so a
		# transient network blip is retried in ~18min instead of poisoning the
		# cache for 30 days. A real miss caches the '' sentinel for the full TTL.
		if res is None: return {}
		media = res.get('ANIME') or res.get('media') or []
		return {'title': (_pick_romaji(media[0]) if media else None) or ''}
	# LOCAL PATCH 2026-10-03 (Batch 4): new key. The old anilist_romaji_<mal> rows were warmed by anilist_media_bulk's
	# last-wins loop, so a split MAL id could hold the wrong entry's title for 30 days (anilist_romaji_61469 held
	# '2nd & 3rd STAGE'). They expire on their own; nothing reads them now.
	out = lists_cache_object(_fetch, 'anilist_romaji_mal_%s' % mal_id, 1, expiration=_TITLE_CACHE_HOURS)
	return (out or {}).get('title') or None


def _pick_cover(media):
	"""Best cover image URL for a media node, or None.

	LOCAL PATCH 2026-08-27: each cour of an anime is its own AniList entry with its own
	cover, which is what makes per-cour season art possible -- Bleach TYBW cour 1 is
	bx116674 and cour 2 (Ketsubetsu-tan) is bx159322, genuinely different images.
	"""
	c = (media or {}).get('coverImage') or {}
	return c.get('extraLarge') or c.get('large') or None


def anilist_media_bulk(mal_ids):
	"""Fetch title AND cover art for up to 50 MAL ids in ONE request.

	Returns {mal_id: {'title': str|None, 'poster': str|None}}.

	LOCAL PATCH 2026-08-27: this is the old anilist_romaji_bulk widened to carry the
	cover image. It costs nothing extra -- the request was already being made to name
	the cours, and coverImage simply rides along in the same query.
	"""
	ids = []
	for m in (mal_ids or []):
		try: ids.append(int(m))
		except (TypeError, ValueError): continue
	if not ids: return {}
	ids = ids[:50]
	# LOCAL PATCH 2026-10-19: cached a week per id set, as anilist_media_bulk_by_id. It was asked on EVERY anime season list
	# with a cour Fribb names by MAL id only (JoJo's newest cour, placed by air date): 1.1-1.5 s of a 1.2-1.6 s list.
	# A failed request is {'success': False}, never stored (base_cache.cache_ttl): the next list asks again.
	def _fetch(_dummy):
		medias = []
		for i in range(0, len(ids), _MAL_CHUNK):   # LOCAL PATCH 2026-10-03 (Batch 4): see _MAL_CHUNK
			res = _post_anilist(_ROMAJI_BULK_QUERY, {'idMal_in': ids[i:i + _MAL_CHUNK]})
			if res is None: return {'success': False}
			medias += res.get('ANIME') or res.get('media') or []
		return {'medias': medias}
	got = lists_cache_object(_fetch, 'anilist_mal_bulk_%s' % '_'.join(str(i) for i in sorted(ids)), 1, expiration=168)
	if not isinstance(got, dict) or is_failed_result(got): return {}
	picked, split = _pick_per_mal(got.get('medias') or [])
	out = {}
	for mid, media in picked.items():
		title, poster = _pick_romaji(media), _pick_cover(media)
		# LOCAL PATCH 2026-09-23: the English title as well, for DISPLAY only. It was already in
		# the reply and thrown away. 'title' stays romaji -- external.py matches releases with it.
		title_en = ((media.get('title') or {}).get('english') or '').strip() or None
		if title or poster: out[mid] = {'title': title, 'title_en': title_en, 'poster': poster}
	# Warm the per-id cache so subsequent single lookups are free -- except for a split MAL id, whose title
	# depends on which entry is meant; that one is left to the single lookup.
	for mid, rec in out.items():
		if mid in split: continue
		try:
			lists_cache_object(lambda _d, _r=rec: dict(_r), 'anilist_romaji_mal_%s' % mid, 1, expiration=_TITLE_CACHE_HOURS)
		except Exception: pass
	return out


# LOCAL PATCH 2026-10-20: ONE per-id store for what every cour lookup asks of an AniList entry -- idMal, episode count,
# romaji / English title, cover. Five functions fetched overlapping parts of it under their own keys, most keyed by the
# whole id SET (anilist_epcounts_id_A_B, anilist_cours_A_B): a season list, its episode list and the scrape prewarm asked
# AniList about the same 2-3 entries up to five times (traced on Frieren 10-20), and AniList's per-minute allowance is
# what throttles anime browsing. Now: anilist_entry_<id>, the missing ids in one request, and a browse page writes its
# own titles in for free (_prime_entries -- _MEDIA_FIELDS carries every field). An unknown id is stored as such a day; a
# failed request stores nothing. A still-airing entry's count is null until AniList fixes it, so that row lives a day.
_ENTRY_HOURS, _ENTRY_OPEN_HOURS, _ENTRY_UNKNOWN_HOURS = 720, 24, 24

def _entry_record(media):
	try: mal = int(media.get('idMal') or 0) or None
	except (TypeError, ValueError): mal = None
	try: episodes = int(media['episodes']) if media.get('episodes') is not None else None
	except (TypeError, ValueError): episodes = None
	rec = {'idMal': mal, 'episodes': episodes, 'title': _pick_romaji(media), 'poster': _pick_cover(media),
			'title_en': ((media.get('title') or {}).get('english') or '').strip() or None}
	# LOCAL PATCH 2026-10-25 (4.0.5): the premiere date, for the cour checks (caches/fribb_mappings._e1_date). Only when the
	# reply carried startDate, so an entry cached before it -- or primed from a browse page without it -- reads as not known.
	if 'startDate' in media:
		sd = media.get('startDate') or {}
		try: rec['start'] = '%04d-%02d-%02d' % (int(sd['year']), int(sd['month']), int(sd['day']))
		except (KeyError, TypeError, ValueError): rec['start'] = None
	return rec

def _store_entry(anilist_id, rec):
	hours = _ENTRY_UNKNOWN_HOURS if rec.get('unknown') else _ENTRY_HOURS if rec.get('episodes') is not None else _ENTRY_OPEN_HOURS
	try: lists_cache.set('anilist_entry_%s' % anilist_id, rec, expiration=hours)
	except Exception: pass

def _prime_entries(medias):
	"""Entries from media nodes another query already returned (a browse page). Only nodes carrying every field."""
	for media in medias or []:
		try:
			if 'episodes' in media and 'idMal' in media and 'title' in media and 'coverImage' in media:
				_store_entry(int(media['id']), _entry_record(media))
		except (KeyError, TypeError, ValueError): continue

def anilist_start_dates(anilist_ids, cached_only=False):
	"""LOCAL PATCH 2026-10-25 (4.0.5): {anilist_id: 'YYYY-MM-DD'} -- each entry's premiere, from the same per-id cache and
	50-a-request query as anilist_entries (an entry cached before startDate was asked is fetched again, once)."""
	return dict((a, rec['start']) for a, rec in anilist_entries(anilist_ids, cached_only, need_start=True).items() if rec.get('start'))

def anilist_entries(anilist_ids, cached_only=False, need_start=False):
	"""{anilist_id: {'idMal', 'episodes', 'title', 'title_en', 'poster'}} for the ids AniList knows. Cached ids are read,
	the rest go out 50 per request (cached_only: never -- widget calls). A failed request leaves its ids out, uncached.
	need_start: an entry cached without 'start' (before 4.0.5) counts as missing."""
	ids = []
	for a in (anilist_ids or []):
		try: a = int(a)
		except (TypeError, ValueError): continue
		if a not in ids: ids.append(a)
	out, missing = {}, []
	for a in ids:
		try: hit = lists_cache.get('anilist_entry_%s' % a)
		except Exception: hit = None
		if not isinstance(hit, dict) or (need_start and not hit.get('unknown') and 'start' not in hit): missing.append(a)
		elif not hit.get('unknown'): out[a] = hit
	if cached_only: return out
	for i in range(0, len(missing), 50):
		chunk = missing[i:i + 50]
		res = _post_anilist(_MEDIA_BULK_BY_ID_QUERY, {'ids': chunk})
		if res is None: break   # failed (or AniList's cooldown): nothing stored, asked again next time
		got = {}
		for media in (res.get('ANIME') or res.get('media') or []):
			try: got[int(media['id'])] = _entry_record(media)
			except (KeyError, TypeError, ValueError): continue
		for a in chunk:
			rec = got.get(a) or {'unknown': True}
			_store_entry(a, rec)
			if a in got: out[a] = rec
		if i + 50 < len(missing): time.sleep(_RATE_MIN_INTERVAL)
	return out


def anilist_media_bulk_by_id(anilist_ids):
	"""LOCAL PATCH 2026-10-03 (Batch 4): anilist_media_bulk keyed by AniList id -- {anilist_id: {'title', 'title_en',
	'poster'}}. For cours, whose Fribb row names the exact AniList entry. LOCAL PATCH 2026-10-20: from anilist_entries
	(it was cached a week per id SET, anilist_cours_<ids>, so one season's cours and all split seasons' cours were two
	requests for the same entries)."""
	return dict((a, {'title': rec.get('title'), 'title_en': rec.get('title_en'), 'poster': rec.get('poster')})
				for a, rec in anilist_entries(anilist_ids).items() if rec.get('title') or rec.get('poster'))


# LOCAL PATCH 2026-10-02: full media for a list of MAL ids, for the MyAnimeList lists (indexers/mal_lists.py).
# MAL's own API carries little art and none of the cour metadata the tiles need; AniList has both for every MAL id,
# in exactly the shape anilist_lists._render already reads. 50 ids per request (AniList: 30 requests a minute).
_MEDIA_BY_MAL_QUERY = '''
query ($idMal_in: [Int]) {
	Page(page: 1, perPage: 50) {
		media(idMal_in: $idMal_in, type: ANIME, sort: ID) { %s }
	}
}
''' % _MEDIA_FIELDS


def anilist_media_by_mal(mal_ids):
	"""{mal_id: AniList media dict} for every MAL id AniList knows. Unknown ids are simply absent."""
	ids = []
	for m in (mal_ids or []):
		try: ids.append(int(m))
		except (TypeError, ValueError): continue
	# LOCAL PATCH 2026-10-03 (Batch 4): 25 ids a request, not 50 -- a split MAL id returns two rows, so 50 ids could
	# need more than the page's 50 and the overflow was dropped ("not on AniList, not shown"). One entry per MAL id,
	# chosen by _pick_per_mal rather than by whichever came last.
	medias = []
	for i in range(0, len(ids), _MAL_CHUNK):
		res = _post_anilist(_MEDIA_BY_MAL_QUERY, {'idMal_in': ids[i:i + _MAL_CHUNK]})
		medias += (res or {}).get('media') or []
	return _pick_per_mal(medias)[0]


def anilist_romaji_bulk(mal_ids):
	"""{mal_id: romaji}. Thin wrapper kept so existing callers are untouched."""
	return {mid: rec['title'] for mid, rec in (anilist_media_bulk(mal_ids) or {}).items()
			if rec.get('title')}


# LOCAL PATCH 2026-09-01: per-cour episode counts, for the Fribb flat-season repair in
# caches/fribb_mappings._anilist_boundaries. Fribb records no episode_offset for a show it
# labels one-cour-per-season, so when TMDb has flattened those cours into a single season
# the boundaries have to come from elsewhere. AniList knows each cour's length because each
# cour is its own AniList entry -- the same property _pick_cover relies on for cour art.
_EPISODES_BULK_QUERY = '''
query ($ids: [Int]) {
	Page(page: 1, perPage: 50) {
		ANIME: media(idMal_in: $ids, type: ANIME, sort: ID) {
			id
			idMal
			episodes
		}
	}
}
'''

_EPISODES_BY_ID_QUERY = '''
query ($ids: [Int]) {
	Page(page: 1, perPage: 50) {
		ANIME: media(id_in: $ids, type: ANIME) {
			id
			idMal
			episodes
		}
	}
}
'''

# A finished cour's episode count never changes. A still-airing one reports null and is
# simply absent from the result, so 7 days only governs how soon it is re-asked.
_EPISODE_COUNT_CACHE_HOURS = 168


def anilist_episode_counts(ids, by='mal', cached_only=False):
	"""{id: episode_count} for up to 50 ids, by MAL id (by='mal') or AniList id (by='id').

	Ids AniList does not know, and cours it reports with `episodes: null` (still
	airing, final count not yet fixed), are ABSENT from the returned dict rather
	than present as zero -- callers must treat a missing id as unknown.
	LOCAL PATCH 2026-10-03 (Batch 4): so is a MAL id AniList splits into several entries -- it has no single count
	(MAL 61469 was counted 11, the '2nd & 3rd STAGE' entry, when the 1st STAGE cour is 1 episode).
	"""
	by_id = by == 'id'
	clean = []
	for m in (ids or []):
		try: clean.append(int(m))
		except (TypeError, ValueError): continue
	if not clean: return {}
	ids = sorted(set(clean))[:50]
	# LOCAL PATCH 2026-10-20: by AniList id, from the per-id entry store (anilist_entries). This was cached per id SET --
	# _checked_offsets, _tail_entries and three other fribb_mappings callers ask for different subsets of one show's cours,
	# so each fetched counts another had just stored. By MAL id stays as it was (a split MAL id has no single count).
	if by_id:
		return dict((a, rec['episodes']) for a, rec in anilist_entries(ids, cached_only=cached_only).items()
					if rec.get('episodes') is not None)
	def _fetch(_dummy):
		out, seen = {}, {}
		for i in range(0, len(ids), 50 if by_id else _MAL_CHUNK):
			res = _post_anilist(_EPISODES_BY_ID_QUERY if by_id else _EPISODES_BULK_QUERY, {'ids': ids[i:i + (50 if by_id else _MAL_CHUNK)]})
			# None is a failed request; {} then earns lists_cache_object's 0.3h TTL so a
			# blip is retried in ~18min instead of being cached for a week.
			if res is None: return {}
			for media in (res.get('ANIME') or res.get('media') or []):
				key, eps = media.get('id' if by_id else 'idMal'), media.get('episodes')
				if key is None: continue
				seen[key] = seen.get(key, 0) + 1
				if eps is None: continue
				try: out[int(key)] = int(eps)
				except (TypeError, ValueError): pass
		for key, n in seen.items():
			if n > 1: out.pop(int(key), None)
		return out
	key = 'anilist_epcounts_%s_%s' % ('id' if by_id else 'mal', '_'.join(str(i) for i in ids))
	# LOCAL PATCH 2026-10-16: cached_only -- the stored answer or {}, never a request (widget calls, see
	# fribb_mappings._checked_offsets)
	if cached_only:
		try: result = lists_cache.get(key)
		except Exception: result = None
	else: result = lists_cache_object(_fetch, key, 1, expiration=_EPISODE_COUNT_CACHE_HOURS)
	# LOCAL PATCH 2026-09-04: normalise keys to int. _fetch builds {int mal_id: int count} and
	# the only caller (fribb_mappings._anilist_boundaries) looks up counts.get(int(mal_id)),
	# but JSON stringifies int dict keys -- so once lists_cache serialises as JSON a cached
	# row comes back keyed '41487' and every lookup misses. That would not raise: it returns
	# 0, which _anilist_boundaries reads as "unknown cour length" and abandons the whole
	# cour-split repair. Format-agnostic here rather than coerced in the cache layer, so
	# legacy repr rows with real int keys keep working too.
	if not isinstance(result, dict): return {}
	out = {}
	for k, v in result.items():
		try: out[int(k)] = v
		except (TypeError, ValueError): continue
	return out


# ═══════════════════════════════════════════════════════════════════════════
#  Authenticated surface (LOCAL PATCH 2026-08-29)
#
#  CORRECTED 2026-08-29: the first cut of this used the implicit grant
#  (response_type=token) on the theory that it avoided needing a client secret. AniList
#  does not support that grant. Probing the token endpoint settles it -- grant_type
#  implicit/token returns "unsupported_grant_type" (the grant is not offered at all) while
#  authorization_code / refresh_token return "invalid_client" (offered, credentials wrong).
#
#  So this is the Authorization Code (PIN) flow, which DOES require the client secret:
#    1. user registers a client with Redirect URL exactly https://anilist.co/api/v2/oauth/pin
#    2. authorize with response_type=code -> AniList displays a PIN (the auth code)
#    3. POST that code + client_id + client_secret to the token endpoint
#    4. back comes a ~1-year access_token plus a refresh_token
#
#  The 1-year life is why there is still no refresh loop here: a background task that fires
#  once a year is untestable dead code. The refresh token is stored anyway so re-auth can be
#  automated later, and a rejected token is logged loudly by _post_anilist instead of failing
#  silently. This is still far lighter than MAL, whose token expires every 31 days.
# ═══════════════════════════════════════════════════════════════════════════

_AUTHORIZE_URL = 'https://anilist.co/api/v2/oauth/authorize?client_id=%s&redirect_uri=%s&response_type=code'
_TOKEN_URL = 'https://anilist.co/api/v2/oauth/token'
_REDIRECT_URI = 'https://anilist.co/api/v2/oauth/pin'

_VIEWER_QUERY = '''
query {
	Viewer { id name }
}
'''

_LAST_ACTIVITY_QUERY = '''
query {
	Viewer {
		updatedAt
		statistics { anime { count } }
	}
}
'''


def _exchange_code(client_id, client_secret, code):
	"""Swap the PIN for a token. Returns the token dict or None."""
	try:
		r = session.post(_TOKEN_URL, json={
			'grant_type': 'authorization_code',
			'client_id': client_id,
			'client_secret': client_secret,
			'redirect_uri': _REDIRECT_URI,
			'code': code,
		}, headers={'Content-Type': 'application/json', 'Accept': 'application/json'}, timeout=20)
		data = r.json()
		if r.status_code != 200 or 'access_token' not in data:
			# Surface AniList's own wording -- 'invalid_client' means the id/secret pair is
			# wrong, 'invalid_grant' means the PIN was stale or already spent.
			logger('AniList: token exchange failed', '%s %s' % (r.status_code, str(data)[:200]))
			return None
		return data
	except Exception as e:
		logger('AniList: token exchange error', safe_err(e))
		return None


def anilist_authenticate(dummy=''):
	"""Authorise against the user's own AniList client. Called from the settings Authorize row."""
	client_id, client_secret = _setting('client_id'), _setting('client_secret')
	if not client_id or not client_secret:
		# LOCAL PATCH 2026-09-30: with a QR code of the developer page (kodi_utils.qr_dialog)
		qr_dialog('AniList Authorize', _APP_REGISTER_URL,
			'[B]Step 1:[/B] Scan the [B]QR code[/B] or open [B]%s[/B] and create a new client.[CR]'
			'[B]Step 2:[/B] Set its [B]Redirect URL[/B] to exactly:   [COLOR gold]%s[/COLOR][CR]'
			'[B]Step 3:[/B] Press [B]Back[/B], then enter its Client ID and Client Secret.'
			% (_APP_REGISTER_URL, _REDIRECT_URI))
		if not client_id:
			client_id = kodi_dialog().input('AniList Client ID')
			if not client_id: return notification('AniList Authorize Cancelled - no Client ID', 4000)
			client_id = client_id.strip()
			set_setting('anilist.client_id', client_id)
		if not client_secret:
			client_secret = kodi_dialog().input('AniList Client Secret')
			if not client_secret: return notification('AniList Authorize Cancelled - no Client Secret', 4000)
			client_secret = client_secret.strip()
			set_setting('anilist.client_secret', client_secret)

	auth_url = _AUTHORIZE_URL % (client_id, _REDIRECT_URI)
	try:
		from modules.utils import copy2clip
		copy2clip(auth_url)
	except Exception: pass

	# LOCAL PATCH 2026-09-30: with a QR code of the authorize link (kodi_utils.qr_dialog); on a TV the link opens on
	# a phone. The PIN AniList then shows is still entered on the next screen.
	if not qr_dialog('AniList Authorize', auth_url,
		'[B]Step 1:[/B] Scan the [B]QR code[/B], or open the link (copied to your clipboard):[CR]'
		'   [COLOR gold]%s[/COLOR][CR]'
		'[B]Step 2:[/B] Approve access. AniList shows you a PIN code.[CR]'
		'[B]Step 3:[/B] Press [B]Back[/B], then enter that PIN.' % auth_url):
		return notification('AniList Authorize timed out', 4000)

	code = kodi_dialog().input('Paste the AniList PIN')
	if not code: return notification('AniList Authorize Cancelled - no PIN', 4000)

	tokens = _exchange_code(client_id, client_secret, code.strip())
	if not tokens:
		return notification('AniList Authorize Failed - PIN rejected. Check the Client Secret and that the PIN is fresh.', 7000)
	set_setting('anilist.token', tokens['access_token'])
	if tokens.get('refresh_token'): set_setting('anilist.refresh', tokens['refresh_token'])
	if tokens.get('expires_in'):
		try: set_setting('anilist.expires', str(int(time.time()) + int(tokens['expires_in'])))
		except Exception: pass

	# Verify rather than trust the exchange -- confirms the token actually authenticates.
	viewer = (_post_anilist(_VIEWER_QUERY, {}, auth=True, node=None) or {}).get('Viewer') or {}
	if not viewer.get('id'):
		set_setting('anilist.token', 'empty_setting')
		return notification('AniList Authorize Failed - token did not authenticate.', 6000)

	set_setting('anilist.userid', str(viewer['id']))
	set_setting('anilist.user', viewer.get('name') or 'Authorized')
	# LOCAL PATCH 2026-10-03 (Batch 3): the lists cached for the previous (or no) account are not this one's.
	# Revoke already cleared them; sign-in did not, so a different account showed the old lists until they expired.
	_invalidate_lists()
	notification('AniList Authorized as %s' % (viewer.get('name') or 'user'), 5000)
	return True


def anilist_revoke_authentication(dummy=''):
	for name in ('token', 'user', 'userid', 'last_activity', 'refresh', 'expires'):
		set_setting('anilist.%s' % name, 'empty_setting')
	_invalidate_lists()
	notification('AniList Authorization Revoked', 4000)
	return True


def anilist_last_activity():
	"""Composite change key for the sync monitor.

	updatedAt alone misses deletions -- removing an entry does not bump it -- so the anime
	count rides along, the same pairing Otaku uses.
	"""
	if not anilist_user_active(): return None
	viewer = (_post_anilist(_LAST_ACTIVITY_QUERY, {}, auth=True, node=None) or {}).get('Viewer') or {}
	if not viewer: return None
	count = ((viewer.get('statistics') or {}).get('anime') or {}).get('count', 0)
	return '%s_%s' % (viewer.get('updatedAt', ''), count)


# ═══════════════════════════════════════════════════════════════════════════
#  List mutations
#
#  AniList counts `progress` WITHIN the entry, which is cour-relative. Callers must pass
#  the AniList id and episode number that fribb_mappings.find_cour_by_tmdb_coords returns
#  for the TMDb coordinates -- NOT TMDb's own episode number. Frieren TMDb S01E30 is entry
#  182255 progress 2, not entry 154587 progress 30.
# ═══════════════════════════════════════════════════════════════════════════

_SAVE_PROGRESS_MUTATION = '''
mutation ($mediaId: Int, $progress: Int, $status: MediaListStatus) {
	SaveMediaListEntry (mediaId: $mediaId, progress: $progress, status: $status) {
		id progress status
	}
}
'''

_SAVE_STATUS_MUTATION = '''
mutation ($mediaId: Int, $status: MediaListStatus) {
	SaveMediaListEntry (mediaId: $mediaId, status: $status) { id status }
}
'''

_SAVE_SCORE_MUTATION = '''
mutation ($mediaId: Int, $score: Float) {
	SaveMediaListEntry (mediaId: $mediaId, score: $score) { id score }
}
'''

_DELETE_ENTRY_MUTATION = '''
mutation ($id: Int) {
	DeleteMediaListEntry (id: $id) { deleted }
}
'''

# LOCAL PATCH 2026-10-02: this user's entry for one media, for the raise-only playback push.
_ENTRY_PROGRESS_QUERY = '''
query ($id: Int, $userId: Int) {
	MediaList (mediaId: $id, userId: $userId, type: ANIME) { progress status }
}
'''

# Entry episode counts are immutable once a show has finished airing and only ever grow
# for one that hasn't, so cache them as long as the romaji titles beside them.
_EPISODE_COUNT_CACHE_HOURS = _TITLE_CACHE_HOURS


def anilist_episode_count(anilist_id):
	"""Total episodes in an AniList entry, or None. LOCAL PATCH 2026-10-20: from the per-id entry store
	(anilist_entries) -- the bulk count, the cour titles and the browse page fill the same row, so this is usually free.
	It had its own key (anilist_epcount_<id>) and re-fetched counts the season list had just stored."""
	try: anilist_id = int(anilist_id)
	except (TypeError, ValueError): return None
	try: return (anilist_entries([anilist_id]).get(anilist_id) or {}).get('episodes')
	except Exception: return None


_SEASON_SEARCH_QUERY = '''query ($search: String, $from: FuzzyDateInt, $to: FuzzyDateInt) {
  Page(perPage: 15) { media(search: $search, type: ANIME, startDate_greater: $from, startDate_lesser: $to,
    format_in: [TV, TV_SHORT, ONA]) { id idMal format episodes startDate { year month day } } } }'''


def anilist_for_tmdb_season(titles, air_date):
	"""LOCAL PATCH 2026-10-04: the AniList entry that starts a TMDb season, found WITHOUT Fribb -- {'anilist', 'mal',
	'episodes', 'start'} or {}.

	For a season Fribb has not mapped yet. Black Clover's 2026 Season 2 (TMDb 73223 S2, from 2026-10-03) had no row the
	day it aired, so animetosho had no AniDB episode id, seadex no AniList id and torrentio/comet no Kitsu id -- while
	AniList (195604) and ani.zip (AniDB 19433, eid 316587, Kitsu 50024) already had it all.

	The match: an AniList TV / TV_SHORT / ONA entry found by the show's title whose start date is within 10 days of TMDb's
	date for the season. One candidate is taken; with several, only one starting within a day of TMDb's date. Anything
	else is no answer -- Frieren 2026-01-16 also finds a 6-episode ONA starting 01-19, which the one-day rule settles. A
	wrong entry would scrape a different show's episode, so every doubt ends in {}. Titles are tried in order (TMDb's
	name, then the original) until one finds candidates. Cached 24 h, the miss too: an entry AniList adds later is picked
	up the next day. A failed request is not cached (None from _post_anilist)."""
	# Not strptime: Kodi's embedded Python 3.8 breaks it on worker threads, and the scrape is one -- in Kodi this returned
	# {} on every call, silently, while every test outside Kodi passed (Black Clover S2E1 and Overgeared S1E1, 23:02-23:03).
	try:
		year, month, dom = (int(part) for part in str(air_date)[:10].split('-'))
		day = datetime.date(year, month, dom)
	except Exception: return {}
	titles = [t for t in dict.fromkeys(titles or []) if t]
	if not titles: return {}
	def _int(d): return int(d.strftime('%Y%m%d'))
	window = {'from': _int(day - datetime.timedelta(days=10)), 'to': _int(day + datetime.timedelta(days=10))}
	def _fetch(_dummy):
		for title in titles:
			res = _post_anilist(_SEASON_SEARCH_QUERY, dict(window, search=title))
			if res is None: return None
			rows = [m for m in (res.get('media') or []) if isinstance(m, dict)]
			if not rows: continue
			def _start(m):
				s = m.get('startDate') or {}
				try: return datetime.date(int(s['year']), int(s['month']), int(s['day']))
				except Exception: return None
			if len(rows) > 1: rows = [m for m in rows if _start(m) and abs((_start(m) - day).days) <= 1]
			if len(rows) != 1: return {'miss': '%d entries near %s for %r' % (len(rows), day, title)}
			m = rows[0]
			return {'anilist': m.get('id'), 'mal': m.get('idMal'), 'episodes': m.get('episodes'), 'start': str(_start(m))}
		return {'miss': 'no entry near %s' % day}
	try:
		key = 'anilist_season_%s_%s' % (day, '|'.join(titles).lower()[:80])
		found = lists_cache_object(_fetch, key, 1, expiration=24) or {}
	except Exception: return {}
	if found.get('miss'):
		logger('anilist season', 'no match: %s' % found['miss'])
		return {}
	return found



def _tmdb_episode_air_date(meta, season, number):
	"""Air date ('YYYY-MM-DD') of TMDb episode `number` of `season`, from the cached episode list."""
	try:
		from modules.metadata import episodes_meta, tmdb_air_day
		for item in episodes_meta(season, meta) or []:
			if int(item.get('episode') or 0) == int(number): return tmdb_air_day(item) or None   # LOCAL PATCH 2026-10-25: not a dub-shifted day
	except Exception: pass
	return None


def anilist_entry_for_tmdb_episode(meta, season, episode, air_dates=None):
	"""LOCAL PATCH 2026-10-05: the AniList entry holding TMDb episode (season, episode) of a season Fribb has not mapped,
	and the episode's number inside it -- {'anilist', 'mal', 'episodes', 'start', 'episode', 'offset'} -- or {} when none
	is found, or {'exhausted': found} when the episode runs past every entry tried.

	Moved here from scrapers/external._new_season_ids so the scrape and the AniList/MAL scrobble share one copy: the
	scrobble asked Fribb only and silently pushed nothing for such a show ('I'm Dating a Dark Summoner' S01E01 played to
	the end 2026-10-05: Trakt and SIMKL got /sync/history, AniList and MAL no request at all -- Fribb had no row, while
	this finds AniList 208025 / MAL 63509 from the season's air date).

	The entry is the one that STARTS this TMDb season (anilist_for_tmdb_season), so episode N of the season is episode N
	of the entry -- as long as the entry is that long. One too short means TMDb folded the next season into this one (A
	Wild Last Boss Appeared: a 12-episode season 1 + its 2nd Season as one TMDb season of 24): search again from the air
	date of the first TMDb episode after it and count from there. At most 3 steps; each is one AniList search, cached.
	air_dates ({TMDb episode: 'YYYY-MM-DD'}) stands in for the cached episode list -- metadata.episodes_meta passes it
	while it is still building that list (reading it from there would recurse)."""
	try: season, episode = int(season), int(episode)
	except (TypeError, ValueError): return {}
	if season < 1: return {}
	row = next((s for s in (meta.get('season_data') or []) if int(s.get('season_number') or -1) == season), None)
	if not row or not row.get('air_date'): return {}
	titles = [meta.get('tvshowtitle') or meta.get('title'), meta.get('original_title')]
	offset, start = 0, row['air_date']
	for _hop in range(4):
		found = anilist_for_tmdb_season(titles, start)
		if not found.get('anilist'): return {}
		if not found.get('episodes') or episode - offset <= int(found['episodes']): break
		offset += int(found['episodes'])
		start = air_dates.get(offset + 1) if air_dates is not None else _tmdb_episode_air_date(meta, season, offset + 1)
		if not start or _hop == 3: return {'exhausted': found}
	return dict(found, episode=episode - offset, offset=offset)


_SEQUEL_QUERY = '''query ($id: Int) { Media(id: $id) { relations { edges { relationType node {
  id type format status title { english romaji } startDate { year month day } season seasonYear } } } } }'''


def anilist_sequel(anilist_id):
	"""LOCAL PATCH 2026-10-13: the announced, not yet released TV / ONA sequel of an AniList entry -- {'title', 'start':
	{'year','month','day'}, 'season', 'season_year'} -- or {} when there is none, None when AniList did not answer.
	Mushoku Tensei III (178789) -> 'Mushoku Tensei III: Isekai Ittara Honki Dasu Part 2' (217434), 2027: TMDb only says
	'Returning Series' until it has an episode date. A movie / special sequel is not a next season. Cached 24 h."""
	try: anilist_id = int(anilist_id)
	except (TypeError, ValueError): return None
	def _fetch(_dummy):
		res = _post_anilist(_SEQUEL_QUERY, {'id': anilist_id}, node='Media')
		if res is None: return None
		for edge in ((res.get('relations') or {}).get('edges') or []):
			node = edge.get('node') or {}
			if edge.get('relationType') != 'SEQUEL' or node.get('type') != 'ANIME': continue
			if node.get('format') not in ('TV', 'TV_SHORT', 'ONA') or node.get('status') != 'NOT_YET_RELEASED': continue
			title = node.get('title') or {}
			return {'sequel': {'title': title.get('english') or title.get('romaji') or '', 'start': node.get('startDate') or {},
								'season': node.get('season'), 'season_year': node.get('seasonYear')}}
		return {'sequel': {}}
	try: got = lists_cache_object(_fetch, 'anilist_sequel_%s' % anilist_id, 1, expiration=24)
	except Exception: return None
	return got.get('sequel') if isinstance(got, dict) else None


_AIRING_QUERY = '''query ($id: Int, $after: Int) {
  Page(perPage: 50) { airingSchedules(mediaId: $id, episode_greater: $after, sort: EPISODE) { episode airingAt } } }'''

# LOCAL PATCH 2026-10-20: the schedule by TIME, with the entry riding along. metadata._anilist_air_times only touches
# episodes dated in the last 30 days (120 for a dub), later, or undated, so everything AniList schedules from
# _RECENT_AIR_DAYS ago on answers it whatever the entry's numbering. The warm-up (metadata._warm_air_times) fetched from
# episode 1 instead -- a 50+ episode entry then needed a second request from its recent episode -- and asked the
# episode count separately; Media here fills the per-id entry store (anilist_entries), so that is one request, not two.
_RECENT_AIR_DAYS = 150
_RECENT_AIRING_QUERY = '''query ($id: Int, $since: Int) {
  Page(perPage: 50) { airingSchedules(mediaId: $id, airingAt_greater: $since, sort: EPISODE) { episode airingAt } }
  Media(id: $id, type: ANIME) { id idMal episodes title { romaji english native } coverImage { extraLarge large } } }'''


def anilist_recent_air_times(anilist_id):
	"""{entry episode: airingAt (UTC epoch)} for every episode AniList schedules from _RECENT_AIR_DAYS ago on, {} when it
	has none, None when it did not answer (not cached). Cached 12 h; the entry itself goes to anilist_entries' store."""
	try: anilist_id = int(anilist_id)
	except (TypeError, ValueError): return None
	def _fetch(_dummy):
		res = _post_anilist(_RECENT_AIRING_QUERY, {'id': anilist_id, 'since': int(time.time()) - _RECENT_AIR_DAYS * 86400}, node=None)
		if res is None: return {'success': False}   # not stored (base_cache.cache_ttl)
		if isinstance(res.get('Media'), dict): _prime_entries([res['Media']])
		return {'times': dict((str(n['episode']), n['airingAt']) for n in ((res.get('Page') or {}).get('airingSchedules') or [])
								if isinstance(n, dict) and n.get('episode') and n.get('airingAt'))}
	try: got = lists_cache_object(_fetch, 'anilist_airtimes_recent_%s' % anilist_id, 1, expiration=12)
	except Exception: return None
	if not isinstance(got, dict) or 'times' not in got: return None
	return dict((int(k), int(v)) for k, v in got['times'].items())


def anilist_air_times(anilist_id, first_episode=1):
	"""LOCAL PATCH 2026-10-13: {entry episode: airingAt (UTC epoch)} from AniList's airing schedule, 50 episodes from
	`first_episode` on; {} when AniList has none, None when it did not answer (not cached, so the next list asks again).
	The broadcast time to the minute -- Overgeared (AniList 212888) E3 aired 2026-10-11 14:30 UTC and the Crunchyroll
	releases are timestamped 14:30-14:36, while TMDb, Trakt and AniDB all put it a week later (10-16). Cached 12 h."""
	try: anilist_id, first_episode = int(anilist_id), max(1, int(first_episode))
	except (TypeError, ValueError): return None
	# LOCAL PATCH 2026-10-20: answered from the entry's RECENT schedule (anilist_recent_air_times) whenever it reaches back
	# to first_episode -- the only episodes metadata._anilist_air_times asks about are recent ones. Only an older first
	# episode still asks from that episode (below), cached under its own key as before.
	recent = anilist_recent_air_times(anilist_id)
	if recent is None: return None
	if not recent: return {}
	if first_episode >= min(recent): return dict((k, v) for k, v in recent.items() if k >= first_episode)
	def _fetch(_dummy):
		res = _post_anilist(_AIRING_QUERY, {'id': anilist_id, 'after': first_episode - 1})
		if res is None: return None
		return {'times': dict((str(n['episode']), n['airingAt']) for n in (res.get('airingSchedules') or [])
								if isinstance(n, dict) and n.get('episode') and n.get('airingAt'))}
	try: got = lists_cache_object(_fetch, 'anilist_airtimes_%s_%s' % (anilist_id, first_episode), 1, expiration=12)
	except Exception: return None
	if not isinstance(got, dict) or 'times' not in got: return None
	return dict((int(k), int(v)) for k, v in got['times'].items())

def _invalidate_lists():
	"""Drop cached watchlist pages after we change something. Without this the user's own
	edit would not show until AniListMonitor next notices Viewer.updatedAt moved."""
	try:
		from caches.anilist_cache import clear_anilist_lists_cache
		clear_anilist_lists_cache()
	except Exception: pass


def _entry_progress(anilist_id):
	"""(progress, status) of this user's entry, (0, None) when it is not on the list, None when unknown.

	MediaList answers 'Not Found' for a title that is not on the list; _post_anilist logs that and returns None,
	so a missing entry and a failed request look alike. Both fall through to the write: the first is a new entry,
	and for the second a write is what the push did before raise-only existed."""
	user_id = _setting('userid')
	if not user_id: return None
	res = _post_anilist(_ENTRY_PROGRESS_QUERY, {'id': int(anilist_id), 'userId': int(user_id)}, auth=True, node='MediaList')
	if not res: return (0, None)
	return (res.get('progress') or 0, res.get('status'))


def anilist_set_progress(anilist_id, progress, status=None, raise_only=False):
	"""Set watched-episode count on an entry. Returns True on success.

	status=None picks it: COMPLETED once progress reaches the entry's episode count,
	CURRENT otherwise. An unknown count falls back to CURRENT -- understating progress is
	recoverable, marking a show complete early is not.
	"""
	if not anilist_user_active(): return False
	try:
		anilist_id, progress = int(anilist_id), int(progress)
	except (TypeError, ValueError): return False
	if progress < 0: return False
	# LOCAL PATCH 2026-10-02: an episode past the entry's own length means the cour mapping is off (Bungou Stray Dogs
	# S1E30 -> the 12-episode 2nd Season as 'episode 18'; Fribb has no boundaries for seasons 3-5). Not sent.
	total = anilist_episode_count(anilist_id) if progress else None
	if total and progress > int(total):
		logger('AniList progress', 'entry %s: ep %s is past its %s episodes - cour mapping off, not sent' % (anilist_id, progress, total))
		return False
	# LOCAL PATCH 2026-10-02: raise_only (playback). Rewatching episode 3 of a finished 12-episode cour used to set
	# the entry to CURRENT 3/12. Season marks and Unmark still pass False -- there the user asked for that number.
	if raise_only:
		current = _entry_progress(anilist_id)
		if current and current[0] >= progress:
			logger('AniList progress', 'entry %s: already at ep %s (%s), not lowering to %s' % (anilist_id, current[0], current[1], progress))
			return True
	if status is None:
		# LOCAL PATCH 2026-08-29: progress 0 is now reachable, for Mark Unwatched on a
		# season/cour row. It used to be rejected outright, which was right while the only
		# caller was the player -- a scrobble of 0 is meaningless. Deliberately PLANNING
		# rather than CURRENT: an entry with 0 watched episodes is not in progress, and
		# leaving it CURRENT would keep it in the "Watching" list forever.
		if progress == 0: status = 'PLANNING'
		else: status = 'COMPLETED' if (total and progress >= int(total)) else 'CURRENT'
	res = _post_anilist(_SAVE_PROGRESS_MUTATION,
						{'mediaId': anilist_id, 'progress': progress, 'status': status},
						auth=True, node='SaveMediaListEntry')
	if res:
		logger('AniList progress', 'entry %s -> ep %s (%s)' % (anilist_id, progress, status))
		_invalidate_lists()
	return bool(res)


def anilist_set_status(anilist_id, status):
	"""status in CURRENT / PLANNING / COMPLETED / DROPPED / PAUSED / REPEATING."""
	if not anilist_user_active(): return False
	res = _post_anilist(_SAVE_STATUS_MUTATION, {'mediaId': int(anilist_id), 'status': status},
						auth=True, node='SaveMediaListEntry')
	if res: _invalidate_lists()
	return bool(res)


def anilist_set_score(anilist_id, score):
	if not anilist_user_active(): return False
	res = _post_anilist(_SAVE_SCORE_MUTATION, {'mediaId': int(anilist_id), 'score': float(score)},
						auth=True, node='SaveMediaListEntry')
	if res: _invalidate_lists()
	return bool(res)


def anilist_delete_entry(entry_id):
	"""Takes the LIST ENTRY id (from MediaList.id), not the media id."""
	if not anilist_user_active(): return False
	res = _post_anilist(_DELETE_ENTRY_MUTATION, {'id': int(entry_id)}, auth=True,
						node='DeleteMediaListEntry')
	if (res or {}).get('deleted'): _invalidate_lists()
	return bool((res or {}).get('deleted'))


# ═══════════════════════════════════════════════════════════════════════════
#  List reads
# ═══════════════════════════════════════════════════════════════════════════

_MEDIA_LIST_QUERY = '''
query ($userId: Int, $status: MediaListStatus) {
	MediaListCollection (userId: $userId, type: ANIME, status: $status) {
		lists {
			entries {
				id
				progress
				score
				media { %s }
			}
		}
	}
}
''' % _MEDIA_FIELDS

_STATUSES = ('CURRENT', 'PLANNING', 'COMPLETED', 'PAUSED', 'DROPPED', 'REPEATING')


def anilist_media_list(status):
	"""All entries for one list status. Returns [{'entry_id','progress','score', **media}].

	MediaListCollection is not paged the way the browse queries are -- it returns the whole
	list in one response, grouped into custom lists which are flattened here.
	"""
	if not anilist_user_active(): return []
	if status not in _STATUSES: return []
	user_id = _setting('userid')
	if not user_id: return []
	res = _post_anilist(_MEDIA_LIST_QUERY, {'userId': int(user_id), 'status': status},
						auth=True, node='MediaListCollection')
	out = []
	for group in ((res or {}).get('lists') or []):
		for entry in (group.get('entries') or []):
			media = entry.get('media') or {}
			if not media.get('id'): continue
			item = dict(media)
			item['entry_id'] = entry.get('id')
			item['progress'] = entry.get('progress')
			item['user_score'] = entry.get('score')
			out.append(item)
	return out


# ═══════════════════════════════════════════════════════════════════════════
#  Bulk / throttled surface (LOCAL PATCH 2026-08-29)
#
#  Only the backfill tool needs these. AniList's measured limit is 30 requests/minute
#  (X-RateLimit-Limit: 30 -- the long-running degraded rate, not the documented 90), so a
#  150-write backfill is a five-minute job that MUST pace itself. The interactive paths
#  above make one or two requests and are deliberately left unthrottled.
# ═══════════════════════════════════════════════════════════════════════════

_RATE_MIN_INTERVAL = 2.2      # seconds between writes: 30/min with headroom
_RATE_FLOOR = 3               # start waiting for the reset once remaining drops this low
_last_request_at = [0.0]
_MEDIA_LIST_ALL_QUERY = '''
query ($userId: Int) {
	MediaListCollection (userId: $userId, type: ANIME) {
		lists {
			entries { id mediaId progress status }
		}
	}
}
'''


def anilist_media_list_all():
	"""Every entry on the user's anime list in ONE request: {media_id: {...}}.

	Deliberately does not select _MEDIA_FIELDS -- the backfill only needs to know what is
	already there and how far, and pulling full media for a 1000-entry list would be a
	large response for no gain.
	"""
	if not anilist_user_active(): return {}
	user_id = _setting('userid')
	if not user_id: return {}
	res = _post_anilist(_MEDIA_LIST_ALL_QUERY, {'userId': int(user_id)}, auth=True,
						node='MediaListCollection')
	out = {}
	for group in ((res or {}).get('lists') or []):
		for entry in (group.get('entries') or []):
			try: mid = int(entry['mediaId'])
			except (KeyError, TypeError, ValueError): continue
			out[mid] = {'entry_id': entry.get('id'),
						'progress': entry.get('progress') or 0,
						'status': entry.get('status')}
	return out


def anilist_covers_bulk(anilist_ids):
	"""{anilist_id: cover_url} for any number of ids, 50 per request.

	AniList art is per COUR, which is the whole point of using it: Fribb maps a TMDb show
	to one entry per cour and each has its own key visual, while TMDb carries a single
	show-level poster. Cached as long as the romaji titles beside it -- a cour's cover does
	not change -- so this is one request on first load and free thereafter.

	Reads and writes lists_cache directly rather than going through lists_cache_object: that
	helper caches whatever its callback returns, so a miss would store a null cover for the
	full 30 days instead of being retried.
	"""
	ids, out, missing = [], {}, []
	for a in (anilist_ids or []):
		try: a = int(a)
		except (TypeError, ValueError): continue
		if a not in ids: ids.append(a)
	for a in ids:
		cached = None
		try: cached = lists_cache.get('anilist_cover_%s' % a)
		except Exception: cached = None
		cover = (cached or {}).get('cover') if isinstance(cached, dict) else None
		if cover: out[a] = cover
		else: missing.append(a)
	# LOCAL PATCH 2026-10-20: the rest from the per-id entry store (anilist_entries) -- the same covers the season list's
	# cour rows fetch; this had its own query. Old anilist_cover_<id> rows are still read above.
	for a, rec in anilist_entries(missing).items():
		if rec.get('poster'): out[a] = rec['poster']
	return out


_TITLES_BY_ID_QUERY = '''
query ($ids: [Int]) {
	Page(page: 1, perPage: 50) {
		media(id_in: $ids, type: ANIME) { id title { romaji english native } synonyms }
	}
}
'''


def anilist_titles_by_id(anilist_ids):
	"""LOCAL PATCH 2026-10-03: {anilist_id: romaji title}, up to 50 ids in one uncached request.

	anilist_media_bulk is keyed by MAL id, and MAL ids are not unique on AniList: MAL 61469 (Steel Ball Run, whole
	series) is BOTH 190327 '1st STAGE' and 210482 '2nd & 3rd STAGE', and the later one overwrites the first. The
	Anime List Manager writes to the AniList id, so it names its entries by that id instead."""
	ids = []
	for a in (anilist_ids or []):
		try: a = int(a)
		except (TypeError, ValueError): continue
		if a not in ids: ids.append(a)
	if not ids: return {}
	return _fetch_titles_by_id(ids[:50]) or {}


def _fetch_titles_by_id(ids):
	"""{anilist_id: romaji} for the ids AniList knows, None when the request failed."""
	res = _post_anilist(_TITLES_BY_ID_QUERY, {'ids': ids[:50]}, node='Page')
	if res is None: return None
	out = {}
	for media in (res.get('media') or []):
		title = _pick_romaji(media)
		try:
			if title: out[int(media['id'])] = title
		except (KeyError, TypeError, ValueError): continue
	return out


def anilist_romaji_by_ids(anilist_ids):
	"""LOCAL PATCH 2026-10-03 (Batch 4): {anilist_id: romaji}, cached 30 days per id (anilist_romaji_id_<id>); the
	ids not cached go out in one request. The scraper's title source: Fribb names the exact AniList entry of a cour,
	so this cannot land on the wrong half of a split MAL id the way anilist_romaji_for_mal can."""
	ids = []
	for a in (anilist_ids or []):
		try: a = int(a)
		except (TypeError, ValueError): continue
		if a not in ids: ids.append(a)
	out, missing = {}, []
	for a in ids:
		hit = lists_cache.get('anilist_romaji_id_%s' % a)
		if hit is None: missing.append(a)
		elif hit.get('title'): out[a] = hit['title']
	# LOCAL PATCH 2026-10-20: the rest from the per-id entry store (anilist_entries), which the season list's cour names
	# have usually filled already -- this asked AniList again for titles it had just answered. Rows already under
	# anilist_romaji_id_<id> are still read above; new ones are written there no more.
	for a, rec in anilist_entries(missing).items():
		if rec.get('title'): out[a] = rec['title']
	return out


def anilist_romaji_for_id(anilist_id):
	try: return anilist_romaji_by_ids([anilist_id]).get(int(anilist_id))
	except (TypeError, ValueError): return None


# LOCAL PATCH 2026-08-29: pick the tags worth showing on a list row.
#
# Spoiler-flagged tags are dropped outright -- "Ending" or a named twist has no business on
# a browse row. The rest are ranked 0-100 by community vote and popular shows carry 30+, so
# only the top few survive or the row overflows any skin layout.
_TAG_LIMIT = 5


# LOCAL PATCH 2026-10-07: the tags are the anime's genres now (metadata.display_genres), so those that say nothing about
# what a show is about are dropped: who the main cast is ('Male Protagonist', 'Primarily Teen Cast', 'Ensemble Cast' --
# Cast-Main Cast), how it was made ('CGI' -- Technical), sexual content,
# and 'Heterosexual' / 'Nudity'. Below rank 60 a tag is a weak vote (Reborn as a Space Mercenary: School, Guns at 20).
# By NAME (AniList's MediaTagCollection, 2026-10-07), not only by category: AniList browse pages cached before the category
# was asked for carry none -- 'Primarily Male Cast / Shounen' still showed on Ace of Diamond. Kept from Cast-Main Cast:
# 'Anti-Hero' and 'Estranged Family', which say something about the story.
_TAG_SKIP_NAMES = frozenset((
	'Elderly Protagonist', 'Ensemble Cast', 'Female Protagonist', 'Male Protagonist', 'Primarily Adult Cast', 'Primarily Animal Cast',
	'Primarily Child Cast', 'Primarily Female Cast', 'Primarily Male Cast', 'Primarily Teen Cast',                       # Cast-Main Cast
	'4-koma', 'Achromatic', 'Advertisement', 'Anthology', 'CGI', 'Episodic', 'Flash', 'Full CGI', 'Full Color', 'Gekiga',
	'Graduation Project', 'Long Strip', 'Mixed Media', 'No Dialogue', 'Non-fiction', 'POV', 'Puppetry', 'Rotoscoping',
	'Short-Form Chapter', 'Stop Motion', 'Vertical Video',                                                              # Technical
	'Heterosexual', 'Nudity'))
_TAG_SKIP_CATEGORIES = ('Sexual Content',)
_TAG_MIN_RANK = 60
# The demographic is kept (user's call, 2026-10-07) and whatever its rank: it is the magazine the source ran in, not a vote
# on what the show is like, so a low rank is not a weak claim (Reborn as a Space Mercenary: Seinen at 20). It
# leads the list ('Seinen, Isekai, ...'), so the limit never cuts it.
_TAG_DEMOGRAPHICS = frozenset(('Josei', 'Kids', 'Seinen', 'Shoujo', 'Shounen'))


def anilist_tag_names(media, limit=_TAG_LIMIT):
	"""['Isekai', 'Elf', ...] -- highest-ranked non-spoiler tags first, without the kinds above."""
	try:
		tags = [t for t in (media.get('tags') or []) if t and not t.get('isMediaSpoiler') and t.get('name')
				and ((t.get('rank') or 0) >= _TAG_MIN_RANK or t['name'] in _TAG_DEMOGRAPHICS) and t['name'] not in _TAG_SKIP_NAMES
				and not str(t.get('category') or '').startswith(_TAG_SKIP_CATEGORIES)]
		tags.sort(key=lambda t: t.get('rank') or 0, reverse=True)
		demographic = [t['name'] for t in tags if t['name'] in _TAG_DEMOGRAPHICS][:1]
		rest = [t['name'] for t in tags if t['name'] not in _TAG_DEMOGRAPHICS]
		return demographic + rest[:limit - len(demographic)]
	except Exception:
		return []


# ═══════════════════════════════════════════════════════════════════════════
#  Per-title score, for the AF3 AniList rating chip (LOCAL PATCH 2026-09-15)
#
#  indexers/anilist_lists.py has published extra_anilist_rating since 2026-09-05, but only
#  for rows that came OUT of an AniList browse -- the score rode along in the page payload
#  and cost nothing. Every other TV list built its rows from TMDb, so the chip had no
#  source and sat blank on all 119 cached anime shows. This is the lookup for those.
#
#  One request per show, and the result is stored in the meta's extra_ratings, so it is
#  paid once per show per meta TTL rather than per render. AniList's measured limit is
#  30/min (see the bulk section above), which a cold page of ~20 rows stays inside; the
#  429 handler in _post_anilist backs the whole thing off if that ever stops being true.
# ═══════════════════════════════════════════════════════════════════════════

_SCORE_COOLDOWN_PROP = 'deadlight.anilist_score_cooldown_until'
# LOCAL PATCH 2026-10-07: the same request also brings the tags, which replace TMDb's genres on anime (metadata.display_genres)
# LOCAL PATCH 2026-10-15: and the genres, for the anime genre choice (setting anime.genre_provider) -- same request, no extra call.
_SCORE_FIELDS = 'averageScore tags { name rank category isMediaSpoiler } genres'
_SCORE_QUERY = '''
query ($id: Int) {
	Media (id: $id, type: ANIME) { %s }
}
''' % _SCORE_FIELDS


def anilist_score_on_cooldown():
	"""True while AniList has told us to back off. Checked before the request so a cold
	meta build skips it entirely, the same contract as omdb_on_cooldown."""
	return cooldown_active(_SCORE_COOLDOWN_PROP)


def _start_score_cooldown(secs, reason):
	try:
		start_cooldown(_SCORE_COOLDOWN_PROP, secs)
		logger('AniList', 'rate limited (%s) - skipping score lookups for %d min' % (reason, max(1, secs // 60)))
	except Exception: pass


# LOCAL PATCH 2026-10-03 (3.0.8): scores fetched in bulk for a whole page (metadata.flush_rating_backfills), then
# read here. One request per 50 shows instead of one per show: a list page logged 26 'AniList ratings' lines, each
# its own request against AniList's 30-a-minute limit. Per process only -- the scores land in each meta's cache.
_SCORES_PRIMED = {}

_SCORES_BULK_QUERY = '''
query ($ids: [Int]) {
	Page(page: 1, perPage: 50) {
		media(id_in: $ids, type: ANIME) { id %s }
	}
}
''' % _SCORE_FIELDS


def _score_record(media):
	return {'score': _score_text(media.get('averageScore')), 'tags': anilist_tag_names(media),
			'genres': [g for g in (media.get('genres') or []) if g]}


def _score_text(score):
	try: return '%.1f' % (float(score) / 10.0) if score else None
	except (TypeError, ValueError): return None


def anilist_scores_bulk(anilist_ids):
	"""Prime anilist_average_score for these ids. A failed request primes nothing (each title then asks alone)."""
	ids = []
	for a in (anilist_ids or []):
		try: a = int(a)
		except (TypeError, ValueError): continue
		if a not in ids and a not in _SCORES_PRIMED: ids.append(a)
	for i in range(0, len(ids), 50):
		if anilist_score_on_cooldown(): return
		chunk = ids[i:i + 50]
		res = _post_anilist(_SCORES_BULK_QUERY, {'ids': chunk}, node='Page')
		if res is None: return
		got = {}
		for media in (res.get('media') or []):
			try: got[int(media['id'])] = _score_record(media)
			except (KeyError, TypeError, ValueError): continue
		# an id AniList did not return is primed as {} -- answered, nothing there -- so it is not asked for again alone
		for a in chunk: _SCORES_PRIMED[a] = got.get(a, {})
		if i + 50 < len(ids): time.sleep(_RATE_MIN_INTERVAL)


def anilist_score_and_tags(anilist_id):
	"""{'score': '8.5' or None, 'tags': [...]} for ONE media id, or None when AniList did not answer.

	AniList scores out of 100. indexers/anilist_lists.py:329 already publishes
	'%.1f' % (score / 10.0), so both paths hand the chip the same shape. The tags are
	anilist_tag_names' top five non-spoiler ones.
	"""
	try: anilist_id = int(anilist_id)
	except (TypeError, ValueError): return None
	if anilist_id in _SCORES_PRIMED:
		primed = _SCORES_PRIMED[anilist_id] or {}
		return {'score': primed.get('score'), 'tags': primed.get('tags') or [], 'genres': primed.get('genres') or []}
	if anilist_score_on_cooldown(): return None
	data = _post_anilist(_SCORE_QUERY, {'id': anilist_id}, node='Media')
	if not isinstance(data, dict): return None
	return _score_record(data)


def anilist_average_score(anilist_id):
	"""averageScore for ONE media id as a '/10' string ('8.5'), or None."""
	return (anilist_score_and_tags(anilist_id) or {}).get('score')


# ═══════════════════════════════════════════════════════════════════════════
#  User recommendations (LOCAL PATCH 2026-10-09)
# ═══════════════════════════════════════════════════════════════════════════

_RECS_QUERY = '''
query ($ids: [Int]) {
	Page(page: 1, perPage: 50) {
		media(id_in: $ids, type: ANIME) {
			id
			recommendations(sort: RATING_DESC, perPage: 25) {
				nodes { rating mediaRecommendation { id idMal format } }
			}
		}
	}
}'''


def _recs_tmdb_id(rec, media_type):
	"""A recommended entry's TMDb id (int) via Fribb, or None. Films only from a Fribb MOVIE id and series only from a TV
	id, so a film never lands in a show list (Fribb's TV fallback for an ONA film would do exactly that)."""
	from caches import fribb_mappings
	row = fribb_mappings.anilist_to_fribb(rec.get('id')) or fribb_mappings.mal_to_fribb(rec.get('idMal'))
	ids = (row or {}).get('themoviedb_id')
	if not isinstance(ids, dict): return None
	value = ids.get('movie') if media_type == 'movie' else ids.get('tv')
	if isinstance(value, list): value = value[0] if value else None
	try: return int(value)
	except (TypeError, ValueError): return None


def anilist_recommend_seed(media_type, tmdb_id):
	"""True when a 'Because You Watched' seed can use AniList recommendations: an anime Fribb maps to an AniList entry.
	Anything else falls back to TMDb Recommended (indexers/navigator, indexers/random_lists)."""
	try:
		from caches import fribb_mappings
		if media_type == 'movie': return bool(fribb_mappings.anilist_for_tmdb_movie(tmdb_id))
		return any(r.get('anilist_id') for r in fribb_mappings.tmdb_tv_to_fribb_rows(tmdb_id))
	except Exception: return False


def anilist_recommended(media_info, page_no=1):
	"""'movie|<tmdb>' or 'tvshow|<tmdb>' -> {'results': [{'id': tmdb_id}, ...]}: what AniList users recommend for that anime.

	A show is several AniList entries (Frieren's two seasons, JoJo's nine parts), so every entry Fribb maps to the TMDb
	show is asked in one request and the votes are summed per TMDb title -- the same show recommended for season 1 and
	for season 2 counts once, with both votes. Entries of the source show itself (its other seasons) are dropped, and
	the format has to match: films in a film list, everything else in a show list. Entries Fribb cannot map to TMDb are
	dropped. Measured for Frieren, 2026-10-09: Violet Evergarden 1197 votes, Delicious in Dungeon 767, Elaina 508, To
	Your Eternity 423, Witch Hat Atelier 403 -- closer in tone than TMDb's, which runs to generic isekai."""
	media_type, tmdb_id = media_info.split('|')
	media_type = 'movie' if media_type == 'movie' else 'tvshow'
	tmdb_id = int(tmdb_id)

	def _fetch(_dummy):
		from caches import fribb_mappings
		if media_type == 'movie': source = [fribb_mappings.anilist_for_tmdb_movie(tmdb_id)]
		else: source = [r.get('anilist_id') for r in fribb_mappings.tmdb_tv_to_fribb_rows(tmdb_id)]
		source = sorted({int(i) for i in source if i})[:50]
		if not source: return {'results': [], 'page': 1, 'total_pages': 1}
		page = _post_anilist(_RECS_QUERY, {'ids': source})
		if page is None: return {'success': False}   # a failed request (429 included) is not stored: base_cache.is_failed_result
		votes, order = {}, []
		for media in page.get('media') or []:
			for node in ((media.get('recommendations') or {}).get('nodes') or []):
				rec, rating = node.get('mediaRecommendation') or {}, node.get('rating') or 0
				if rating <= 0 or not rec.get('id') or rec.get('id') in source: continue
				if (rec.get('format') == 'MOVIE') != (media_type == 'movie'): continue
				rec_tmdb = _recs_tmdb_id(rec, media_type)
				if not rec_tmdb or rec_tmdb == tmdb_id: continue
				if rec_tmdb not in votes: order.append(rec_tmdb)
				votes[rec_tmdb] = votes.get(rec_tmdb, 0) + rating
		ranked = sorted(order, key=lambda k: -votes[k])[:20]
		return {'results': [{'id': i} for i in ranked], 'page': 1, 'total_pages': 1}

	data = lists_cache_object(_fetch, 'anilist_recs_%s_%s' % (media_type, tmdb_id), 'foo', expiration=168)
	return data if (data or {}).get('results') is not None else {'results': [], 'page': 1, 'total_pages': 1}
