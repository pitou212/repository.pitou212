from jurialmunkey.parser import boolean
from jurialmunkey.ftools import cached_property
from tmdbhelper.lib.addon.consts import NO_UNAIRED_LABEL
from tmdbhelper.lib.addon.plugin import get_setting, executebuiltin, get_localized
from tmdbhelper.lib.api.contains import CommonContainerAPIs
from tmdbhelper.lib.addon.logger import TimerList


class ContainerDirectoryCommon(CommonContainerAPIs):
    default_cacheonly = False
    update_listing = False  # endOfDirectory(updateListing=) set True to replace current path
    plugin_category = ''  # Container.PluginCategory / ListItem.Property(widget)
    container_content = ''  # Container.Content({})
    container_update = ''  # Add path to call Containr.Update({}) at end of directory
    container_refresh = False  # True call Container.Refresh at end of directory
    sort_by_dbid = False
    kodi_details = False  # Permit Kodi library details; the item detail service applies the user's setting
    sync_details = True  # Permit synced play data; the item detail service applies the user's setting
    thumb_override = 0
    tmdb_id_lookup_params = ('imdb_id', 'tvdb_id', 'query', 'use_multisearch')  # Inputs that can resolve a tmdb_id

    def __init__(self, handle, paramstring, **kwargs):
        # plugin:// params configuration
        self.handle = handle  # plugin:// handle
        self.paramstring = paramstring  # plugin://plugin.video.themoviedb.helper?paramstring
        self.params = kwargs  # paramstring dictionary
        self.parent_params = kwargs.copy()  # TODO: CLEANUP

    @cached_property
    def log_timers(self):
        return get_setting('timer_reports', 'int') > 0

    @cached_property
    def timer_lists(self):
        return {}

    @cached_property
    def timer_report_time(self):
        return self.get_timer_report_time()

    def get_timer_report_time(self):
        from tmdbhelper.lib.addon.tmdate import get_current_date_time
        return get_current_date_time('%H:%M')

    @property
    def timer_report_name(self):
        return f'[{self.timer_report_time}] {self.paramstring}'

    @cached_property
    def sort_methods(self):
        return []  # List of kwargs dictionaries [{'sortMethod': SORT_METHOD_UNSORTED}]

    @cached_property
    def property_params(self):
        return {}

    @cached_property
    def filters(self):
        return {
            'filter_key': self.params.get('filter_key', None),
            'filter_value': self.params.get('filter_value', None),
            'filter_operator': self.params.get('filter_operator', None),
            'exclude_key': self.params.get('exclude_key', None),
            'exclude_value': self.params.get('exclude_value', None),
            'exclude_operator': self.params.get('exclude_operator', None)
        }

    @cached_property
    def is_widget(self):
        return boolean(self.params.get('widget', False))

    @cached_property
    def is_plugin_widget(self):
        # Internal callers, such as the recommendations window, build lists without a plugin handle.
        return self.is_widget and self.handle != -1

    @cached_property
    def is_cacheonly(self):
        return boolean(self.params.get('cacheonly', self.default_cacheonly))

    @cached_property
    def is_localonly(self):
        return boolean(self.params.get('localonly', False))

    @cached_property
    def is_detailed(self):
        if self.params.get('info') == 'details':
            return True
        return boolean(self.params.get('detailed', False))

    @cached_property
    def is_ratings(self):
        return boolean(self.params.get('ratings', False))

    @cached_property
    def is_translated(self):
        return boolean(self.params.get('translated', False))

    @cached_property
    def context_additions(self):
        if self.context_additions_make_node:
            return [(get_localized(32496), 'RunScript(plugin.video.themoviedb.helper,make_node)')]
        return []

    @cached_property
    def context_additions_make_node(self):
        return get_setting('contextmenu_make_node') if not self.is_widget else False

    @cached_property
    def sync_playdata(self):
        from tmdbhelper.lib.items.sync import SyncPlayData
        return SyncPlayData()

    @cached_property
    def pagination(self):
        if not boolean(self.params.get('nextpage', True)):
            return False
        if self.is_widget and not get_setting('widgets_nextpage'):
            return False
        return True

    @cached_property
    def is_labelformatting(self):
        return boolean(self.params.get('labelformatting', True))

    @cached_property
    def format_unaired_labels(self):
        return self.parent_params.get('info') not in NO_UNAIRED_LABEL

    @cached_property
    def hide_unaired(self):
        return boolean(self.parent_params.get('hide_unaired'))

    @cached_property
    def only_unaired(self):
        return boolean(self.parent_params.get('only_unaired'))

    @cached_property
    def item_finaliser(self):
        from tmdbhelper.lib.items.finaliser import ItemFinaliser
        return ItemFinaliser

    @cached_property
    def list_finaliser(self):
        from tmdbhelper.lib.items.finaliser import ListFinaliser
        return ListFinaliser

    @cached_property
    def action_discovery(self):
        with TimerList(self.timer_lists, '--disc', log_threshold=0, logging=self.log_timers):
            return self.get_action_discovery()

    def get_action_discovery(self):
        from tmdbhelper.lib.script.actions.discovery import ActionDiscovery
        return ActionDiscovery(self.sync_playdata.syncdata)

    @cached_property
    def context_menu_config(self):
        with TimerList(self.timer_lists, '--menu', log_threshold=0, logging=self.log_timers):
            return self.get_context_menu_config()

    def get_context_menu_config(self):
        from tmdbhelper.lib.items.context import ContextMenuConfig
        config = ContextMenuConfig(self)
        config.items  # Read the settings once for the whole list
        return config

    def get_item_finaliser(self, li):
        # Items use action discovery only through the shared context menu config.
        li.context_menu_config = self.context_menu_config
        return self.item_finaliser(self, li)

    def make_item(self, li):
        ci = self.get_item_finaliser(li)
        return ci.item if ci else None

    def make_items(self, items):
        make_items = self.list_finaliser(self, items).items
        make_items = self.sort_items_by_dbid(make_items) if self.sort_by_dbid else make_items
        return make_items

    def sort_items_by_dbid(self, items):
        items_dbid = [li for li in items if li and li.infolabels.get('dbid')]
        items_tmdb = [li for li in items if li and not li.infolabels.get('dbid')]
        return items_dbid + items_tmdb

    @staticmethod
    def build_detailed_items(items):
        return items

    def build_items(self, items):
        """ Build items in threads """

        items = self.build_detailed_items(items)

        # Finalise listitems in parallel threads
        with TimerList(self.timer_lists, '--make', log_threshold=0.001, logging=self.log_timers):
            items = self.make_items(items)

        return items

    def add_items(self, items):
        with TimerList(self.timer_lists, '--list', log_threshold=0.001, logging=self.log_timers):
            items = [(li.url, li.get_listitem(), li.is_folder) for li in items if li]
        with TimerList(self.timer_lists, '--dirs', log_threshold=0.001, logging=self.log_timers):
            from xbmcplugin import addDirectoryItems
            addDirectoryItems(self.handle, items)

    def set_mixed_content(self, response):
        lengths = [
            len(response.get('movies', [])),
            len(response.get('shows', [])),
            len(response.get('persons', [])),
            len(response.get('seasons', [])),
            len(response.get('episodes', []))
        ]

        if lengths.index(max(lengths)) == 0:
            self.container_content = 'movies'
        elif lengths.index(max(lengths)) == 1:
            self.container_content = 'tvshows'
        elif lengths.index(max(lengths)) == 2:
            self.container_content = 'actors'
        elif lengths.index(max(lengths)) == 3:
            self.container_content = 'seasons'
        elif lengths.index(max(lengths)) == 4:
            self.container_content = 'episodes'

    def set_params_to_container(self):
        params = {f'param.{k}': f'{v}' for k, v in self.params.items() if k and v}
        if self.handle == -1:
            return params
        from xbmcplugin import setProperty
        for k, v in params.items():
            setProperty(self.handle, k, v)  # Set params to container properties
        return params

    def finish_container(self):
        from xbmcplugin import setPluginCategory, setContent, endOfDirectory, addSortMethod
        setPluginCategory(self.handle, self.plugin_category)  # Container.PluginCategory
        setContent(self.handle, self.container_content)  # Container.Content
        for i in self.sort_methods:
            addSortMethod(self.handle, **i)
        endOfDirectory(self.handle, updateListing=self.update_listing)

    def get_collection_tmdb_id(self, tmdb_id=None, **kwargs):
        try:
            from tmdbhelper.lib.items.database.baseitem_factories.factory import BaseItemFactory
            sync = BaseItemFactory('movie')
            sync.tmdb_id = tmdb_id or self.query_database.get_tmdb_id(**kwargs)
            return sync.data['infoproperties']['set.tmdb_id']
        except (KeyError, TypeError, AttributeError):
            pass

    def get_tmdb_id(self):
        if self.params.get('info') == 'collection' and self.params.get('tmdb_type') == 'movie':
            self.params['tmdb_type'] = 'collection'
            self.params['tmdb_id'] = self.get_collection_tmdb_id(**self.params)
            return

        if self.params.get('tmdb_id'):
            return

        if not self.has_tmdb_id_lookup_params:
            self.params['tmdb_id'] = None  # Nothing to look up, so skip loading the query database
            return

        self.params['tmdb_id'] = self.query_database.get_tmdb_id(**self.params)

    @property
    def has_tmdb_id_lookup_params(self):
        return any(self.params.get(k) for k in self.tmdb_id_lookup_params)

    def prepare_item_details(self):
        """ Abstract method to prepare item details while the list is retrieved
        """
        return

    def get_items(self, **kwargs):
        """ Abstract method for getting items
        """
        return

    def refresh_after_finish(self):
        """ Abstract method to refresh data after the directory is returned to Kodi
        """
        return

    @cached_property
    def directory_items_properties_class(self):
        return self.get_directory_items_properties_class()

    def get_directory_items_properties_class(self):
        if not boolean(self.params.get('nextepisodes', False)):
            return
        from tmdbhelper.lib.items.directories.lists_nextepisodes import ListNextEpisodesProperties
        return ListNextEpisodesProperties

    def get_directory_items(self):
        with TimerList(self.timer_lists, 'get_list', logging=self.log_timers):
            items = self.get_items(**self.params)
            if self.directory_items_properties_class is None:
                return items
            list_properties = self.directory_items_properties_class(items, self.container_content)
            self.container_content = list_properties.container_content
            return list_properties.finalised_items

    def get_directory(self, items_only=False, build_items=True):

        if self.log_timers:
            self.timer_report_time  # Record when the directory began its work

        with TimerList(self.timer_lists, 'total', logging=self.log_timers):
            self.prepare_item_details()

            items = self.get_directory_items()

            if not items:
                return

            if not build_items:
                return items

            self.property_params.update(self.set_params_to_container())
            self.plugin_category = self.params.get('plugin_category') or self.plugin_category

            with TimerList(self.timer_lists, 'add_items', logging=self.log_timers):
                items = self.build_items(items)
                if items_only:
                    return items
                self.add_items(items)
            self.finish_container()

        if self.log_timers:
            from tmdbhelper.lib.files.futils import write_to_file
            from tmdbhelper.lib.addon.logger import log_timer_report, TimerReportLists
            from tmdbhelper.lib.addon.tmdate import get_todays_date
            report_data = log_timer_report(TimerReportLists(self.timer_lists).timer_lists, self.timer_report_name, logging=False)
            write_to_file(''.join(report_data), 'timer_report', f'{get_todays_date()}.txt', join_addon_data=True, append_to_file=True)

        if self.container_update:
            executebuiltin(f'Container.Update({self.container_update})')

        if self.container_refresh:
            executebuiltin('Container.Refresh')

        self.refresh_after_finish()


class ContainerDirectory(ContainerDirectoryCommon):

    @cached_property
    def lidc_cache_refresh(self):
        if self.is_cacheonly:
            return 'never'
        if self.is_detailed:
            return None
        return 'basic'

    @cached_property
    def lidc_ratings(self):
        """Lists with ratings receive them merged into their items by the item detail service."""
        if self.is_ratings:
            return 'merge'
        return None

    @cached_property
    def lidc(self):
        from tmdbhelper.lib.items.database.listitem import ListItemDetails
        lidc = ListItemDetails(self)
        lidc.parent_params = self.parent_params
        lidc.pagination = self.pagination
        lidc.cache_refresh = self.lidc_cache_refresh
        lidc.cache_translations = self.is_translated
        lidc.extendedinfo = self.is_detailed
        lidc.kodi_details = self.kodi_details
        lidc.sync_details = self.sync_details
        lidc.ratings = self.lidc_ratings
        return lidc

    def prepare_item_details(self):
        self.lidc.prepare(**self.params)

    def build_detailed_item(self, li):
        if li.infoproperties.get('label_override'):
            li.label = f"{li.infoproperties['label_override']}"
        if li.infoproperties.get('label_affix'):
            li.label = f"{li.infoproperties['label_affix']}. {li.label}"
        if li.infoproperties.get('plot_affix'):
            li.infolabels['plot'] = f"{li.infoproperties['plot_affix']}{li.infolabels.get('plot')}"
        return li

    def build_detailed_items(self, items):
        with TimerList(self.timer_lists, '--lidc', log_threshold=0.001, logging=self.log_timers):
            items = self.get_configured_listitems(items)
            items = [i for i in (self.build_detailed_item(li) for li in items if li) if i]
        self.add_details_rest_timer()
        return items

    def get_configured_listitems(self, items):
        items = self.lidc.configure_listitems_threaded(items)
        for name, seconds in self.lidc.client.timings.items():
            self.timer_lists[f' --{name}'] = [seconds]
        return items

    def add_details_rest_timer(self):
        """Report the --lidc time that the item detail timings do not account for, never below 0."""
        lidc_time = sum(self.timer_lists['--lidc'])
        self.timer_lists[' --rest'] = [max(lidc_time - sum(self.lidc.client.timings.values()), 0)]


class ContainerDefaultCacheDirectory(ContainerDirectory):
    default_cacheonly = False


class ContainerCacheOnlyDirectory(ContainerDirectory):
    default_cacheonly = True
