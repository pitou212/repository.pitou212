# -*- coding: utf-8 -*-
import xbmc
import json
from threading import Thread
from apis.trakt_api import make_trakt_slug
from caches.settings_cache import get_setting
from modules import kodi_utils as ku, settings as st, watched_status as ws
# logger = ku.logger

# LOCAL PATCH 2026-08-21: window property bridging "how did playback end?" from the
# player to the next-episode handler. It has to be a property, not an attribute:
# autoplay_nextep_handler runs on a NEW Sources() instance (episode_tools.auto_nextep
# does `Sources().playback_prep(...)`), so it can never see flags set on the player's
# own sources_object.
PLAYBACK_STOPPED_PROP = 'fenlight.playback_user_stopped'
# LOCAL PATCH 2026-08-26: marker for stops WE perform (autoplay handoff, stop-at-credits,
# failed-resolve teardown). Kodi fires onPlayBackStopped for those exactly as it does for a
# user pressing Stop, so without this our own handoff stop got recorded as "the user stopped"
# -- which then suppressed the very next-episode play we were in the middle of performing,
# and blocked SmartPlay's fallback scrape when a sticky source failed.
INTERNAL_STOP_PROP = 'fenlight.playback_internal_stop'


def mark_internal_stop():
	"""Call immediately BEFORE any Fen Light-initiated player.stop()."""
	try: ku.set_property(INTERNAL_STOP_PROP, 'true')
	except: pass


class FenLightPlayer(xbmc.Player):
	def __init__ (self):
		xbmc.Player.__init__(self)

	# ── Kodi playback-end callbacks ─────────────────────────────────────────
	# Previously unimplemented, which left no way to tell "user pressed Stop" apart
	# from "episode reached its end". cancel_all_playback / user_cancelled only get
	# set on progress-dialog cancel or an exception — a plain Stop set neither, so
	# autoplay_nextep_handler's fallback treated it as a natural end and popped the
	# Next Up dialog after the video had already been closed.
	# NOTE: Kodi delivers these ~2.5s after isPlayingVideo() flips (measured), so they
	# are too late to gate autoplay_nextep_handler on their own — that gate uses a
	# position test instead. They remain the authoritative verdict for anything that
	# polls, e.g. NextEpisode.monitor() dismissing an already-open alert on Stop.
	def onPlayBackStopped(self):
		# Fires for BOTH a user pressing Stop and any stop we perform ourselves. Only the
		# former is a real "user stopped" verdict -- see INTERNAL_STOP_PROP above.
		try:
			if ku.get_property(INTERNAL_STOP_PROP) == 'true':
				ku.clear_property(INTERNAL_STOP_PROP)
				ku.clear_property(PLAYBACK_STOPPED_PROP)
			else:
				ku.set_property(PLAYBACK_STOPPED_PROP, 'true')
		except: pass

	def onPlayBackEnded(self):
		# File played through to its natural end — next-episode alert is wanted.
		try: ku.clear_property(PLAYBACK_STOPPED_PROP)
		except: pass

	def onPlayBackStarted(self):
		# New file started; clear any verdict left over from the previous one.
		try: ku.clear_property(PLAYBACK_STOPPED_PROP)
		except: pass

	def run(self, url=None, obj=None):
		ku.hide_busy_dialog()
		self.clear_playback_properties()
		if not url: return self.run_error()
		try: return self.play_video(url, obj)
		except: return self.run_error()

	def play_video(self, url, obj):
		self.set_constants(url, obj)
		ku.volume_checker()
		self.play(self.url, self.make_listing())
		if not self.is_generic:
			self.check_playback_start()
			if self.playback_successful: self.monitor()
			else:
				self.sources_object.playback_successful = self.playback_successful
				self.sources_object.cancel_all_playback = self.cancel_all_playback
				# LOCAL PATCH 2026-07-02: propagate the user_cancelled flag distinct from
				# cancel_all_playback so downstream sticky-path can distinguish "user pressed
				# Back on resolve dialog" from "playback failed silently".
				self.sources_object.user_cancelled = getattr(self, 'user_cancelled', False)
				if self.cancel_all_playback: self.kill_dialog()
				mark_internal_stop()   # LOCAL PATCH 2026-08-26
				self.stop()
			try: del self.kodi_monitor
			except: pass

	def _playback_confirmed(self):
		"""True once Kodi is really PLAYING the file, not merely opening it.
		LOCAL PATCH 2026-09-06: extracted from the isPlayingVideo branch below so the
		timeout branch can ask the same question instead of duplicating it."""
		try:
			return bool(self.isPlayingVideo() and self.getTotalTime() not in ('0.0', '', 0.0, None)
				and ku.get_visibility('Window.IsActive(fullscreenvideo)'))
		except Exception:
			return False

	def check_playback_start(self):
		resolve_percent = 0
		self.user_cancelled = False
		# LOCAL PATCH 2026-09-06: extra loop iterations granted ONLY while Kodi already has
		# the file open -- 400 * 50ms = 20s on top of the counter, which reaches 100 in 334
		# iterations (16.7s of sleep, ~21s wall once per-iteration work is counted -- the
		# 2026-09-06 hang closed the stream 21.3s after OpenFile). See the branch below.
		open_grace = 400
		while self.playback_successful is None:
			ku.hide_busy_dialog()
			if not self.sources_object.progress_dialog: self.playback_successful = True
			elif self.sources_object.progress_dialog.skip_resolved(): self.playback_successful = False
			elif self.sources_object.progress_dialog.iscanceled() or self.kodi_monitor.abortRequested():
				# LOCAL PATCH 2026-07-02: mark user_cancelled True on progress-dialog cancel
				# (Back press by user); left False on abortRequested since Kodi shutdown isn't
				# meaningfully "user cancelled playback" — but the flag is only consulted by
				# sticky-fallback which never runs during shutdown anyway.
				self.cancel_all_playback, self.playback_successful, self.user_cancelled = True, False, True
			# LOCAL PATCH 2026-09-06: this used to fail outright the moment the counter ran out,
			# which killed streams that were merely SLOW to open -- and because the resulting
			# stop() lands while the demuxer is still opening, it deadlocked Kodi outright:
			#   10:26:44.805 OpenFile      10:26:45.795 Creating Demuxer
			#   10:27:06.062 CloseFile + 'waiting for threads to exit'   <- this branch firing
			#   10:27:08.797 T:22256 Opening stream / Display resolution ADJUST, then silence.
			# _playback_confirmed() needs isPlayingVideo() AND a non-zero getTotalTime() AND
			# fullscreenvideo -- none of which a healthy-but-slow open satisfies for many seconds.
			# So: if Kodi holds the file open, keep waiting (bounded by open_grace); if the grace
			# also runs out while it is STILL open, hand off to monitor() rather than calling
			# stop() mid-open, because closing at that moment is precisely what hangs. Only a
			# player holding nothing is failed here, where stop() has nothing to race.
			elif resolve_percent >= 100:
				if self._playback_confirmed(): self.playback_successful = True
				elif not self.isPlaying(): self.playback_successful = False
				elif open_grace > 0:
					# LOCAL PATCH 2026-09-07: leave evidence. This path is correct by construction and
					# unit-verified, but had not met a real slow open when it shipped; one line at entry
					# and one at exhaustion turn the next occurrence into proof instead of inference.
					if open_grace == 400: ku.logger('playback grace', 'resolve counter expired with the file still opening; holding up to 20s instead of stopping')
					open_grace -= 1
					resolve_percent = 99.74
				else:
					ku.logger('playback grace', 'grace exhausted with the file still open; handing to monitor() rather than calling stop()')
					self.playback_successful = True
			elif ku.get_visibility('Window.IsTopMost(okdialog)'):
				ku.execute_builtin('SendClick(okdialog, 11)')
				self.playback_successful = False
			elif self.isPlayingVideo():
				if self._playback_confirmed(): self.playback_successful = True
			resolve_percent = round(resolve_percent + 26.0/100, 1)
			self.sources_object.progress_dialog.update_resolver(percent=resolve_percent)
			ku.sleep(50)

	def playback_close_dialogs(self):
		self.sources_object.playback_successful = True
		# LOCAL PATCH 2026-09-15: write the SmartPlay pin here, not when the source was picked.
		# This runs once, from monitor()'s isPlayingVideo() loop, so reaching it means Kodi is
		# genuinely playing the file -- the earliest honest moment to call a source good.
		#
		# Saving at playback END would have been simpler but is wrong: the pin exists to be read
		# by the NEXT episode, and monitor() is still running then. playing_item is whichever
		# source play_file actually got playing, which is not necessarily the one chosen -- it
		# falls through to the rest of the list when a pick fails.
		try:
			_so = self.sources_object
			if getattr(_so, 'sticky_pending', False):
				_so.sticky_pending = False
				_so._sticky_save(getattr(_so, 'playing_item', None))
		except Exception: pass
		self.kill_dialog()
		ku.sleep(200)
		ku.close_all_dialog()

	def monitor(self):
		try:
			ensure_dialog_dead, total_check_time = False, 0
			if self.media_type == 'episode':
				play_random_continual = self.sources_object.random_continual
				play_random = self.sources_object.random
				disable_autoplay_next_episode = self.sources_object.disable_autoplay_next_episode
				if disable_autoplay_next_episode: ku.notification('Scrape with Custom Values - Autoplay Next Episode Cancelled', 4500)
				if any((play_random_continual, play_random, disable_autoplay_next_episode)): self.autoplay_nextep, self.autoscrape_nextep = False, False
				else: self.autoplay_nextep, self.autoscrape_nextep = self.sources_object.autoplay_nextep, self.sources_object.autoscrape_nextep
			else:
				show_stinger, stinger_use_chapters, stingers_percentage_fallback = st.stingers_show(), st.stingers_use_chapters(), st.stingers_percentage()
				play_random_continual, self.autoplay_nextep, self.autoscrape_nextep = False, False, False
			while total_check_time <= 30 and not ku.get_visibility('Window.IsActive(fullscreenvideo)'):
				ku.sleep(100)
				total_check_time += 0.10
			ku.hide_busy_dialog()
			ku.sleep(1000)
			# LOCAL PATCH 2026-09-05: `if st.auto_enable_subs(): self.showSubtitles(True)`
			# removed along with its playback.auto_enable_subs setting. It forced subtitles on
			# at playback start for every file, and sat in Playback Utilities directly above a
			# Subtitles section carrying an almost identically named row -- two settings, one
			# "Auto Enable Subtitles" and one "- Auto-Enable Subtitles", doing different things.
			# subtitles.auto_enable (default on) survives and is the better-scoped of the two:
			# it enables display when the scraper below has actually selected or downloaded a
			# track, rather than unconditionally.
			# LOCAL PATCH 2026-08-30: automatic subtitle download (ported from POV). Threaded
			# and self-gating -- it sleeps 2s before touching subtitle state, so it must not
			# hold up the playback loop below. Does nothing unless subtitles.auto_download is
			# on. See indexers/subtitles.py.
			try:
				from indexers.subtitles import SubtitleScraper
				Thread(target=SubtitleScraper(self, self.meta_get('poster', '')).run).start()
			except Exception: pass
			while self.isPlayingVideo():
				try:
					if not ensure_dialog_dead:
						ensure_dialog_dead = True
						self.playback_close_dialogs()
					ku.sleep(1000)
					try: self.total_time, self.curr_time = self.getTotalTime(), self.getTime()
					except: ku.sleep(250); continue
					self.current_point = round(float(self.curr_time/self.total_time * 100), 1)
					try: self._check_skip_segments()
					except: pass
					if self.current_point >= self.watched_tick_percent:
						if play_random_continual: self.run_random_continual(); break
						if not self.media_marked: self.media_watched_marker()
					if self.media_type == 'episode':
						if self.autoplay_nextep or self.autoscrape_nextep:
							if not self.nextep_info_gathered: self.info_next_ep()
							# LOCAL PATCH 2026-09-12: break only when an episode actually followed.
							# start_prep is window_time + scraper_time, so this fires scraper_time BEFORE
							# outro_start -- 24s on this box, 40s at the default results.timeout. Breaking
							# unconditionally killed this loop, and with it the per-second
							# _check_skip_segments, before curr_time could ever reach outro_start. So
							# skipsegment.stop_at_credits_no_next could NEVER fire on the finale /
							# next-not-yet-aired case it exists for: auto_nextep returned silently, the
							# loop broke, and the credits played out. Observed 2026-09-12 on Chainsmoker
							# Cat S01E10 (outro_start 1329s, loop broke at 1305s). Companion to the
							# 2026-09-05 fix in _check_skip_segments, which opened the same gate at the
							# near end while this one stayed shut at the far end.
							# Attempted once -- next_episode_info() costs a metadata lookup and this runs
							# every second.
							if not self.nextep_handoff_attempted and round(self.total_time - self.curr_time) <= self.start_prep:
								self.nextep_handoff_attempted = True
								if self.run_next_ep(): break
					elif show_stinger and not self.movie_stingers_run: 
						final_chapter = (self.final_chapter(75) or stingers_percentage_fallback) if stinger_use_chapters else stingers_percentage_fallback
						if self.current_point >= final_chapter: self.run_movie_stingers()
				except: pass
			ku.hide_busy_dialog()
			# LOCAL PATCH 2026-09-03: the loop has exited, so playback is OVER -- tell the
			# marker, and refresh here when the mark already landed earlier (at 90%, or from
			# the stop-at-credits path) since that write is long since committed.
			if not self.media_marked: self.media_watched_marker(playback_over=True)
			else: self._refresh_after_playback()
			self.clear_playback_properties()
			if getattr(self, 'active_skip_window', None):
				try: self.active_skip_window.request_close()
				except: pass
				self.active_skip_window = None
		except:
			ku.hide_busy_dialog()
			self.sources_object.playback_successful = False
			self.sources_object.cancel_all_playback = True
			return self.kill_dialog()

	def make_listing(self):
		listitem = ku.make_listitem()
		listitem.setPath(self.url)
		listitem.setContentLookup(False)
		if self.is_generic:
			info_tag = listitem.getVideoInfoTag(True)
			info_tag.setMediaType('video')
			info_tag.setFilenameAndPath(self.url)
		else:
			self.tmdb_id, self.imdb_id, self.tvdb_id = self.meta_get('tmdb_id', ''), self.meta_get('imdb_id', ''), self.meta_get('tvdb_id', '')
			self.media_type, self.title, self.year = self.meta_get('media_type'), self.meta_get('title'), self.meta_get('year')
			self.season, self.episode = self.meta_get('season', ''), self.meta_get('episode', '')
			poster = self.meta_get('poster') or ku.get_icon('box_office')
			fanart = self.meta_get('fanart') or ku.get_addon_fanart()
			clearlogo = self.meta_get('clearlogo') or ''
			duration, genre, trailer, mpaa = self.meta_get('duration'), self.meta_get('genre', ''), self.meta_get('trailer'), self.meta_get('mpaa')
			rating, votes = self.meta_get('rating'), self.meta_get('votes')
			premiered, studio, tagline = self.meta_get('premiered'), self.meta_get('studio', ''), self.meta_get('tagline')
			director, writer, country = self.meta_get('director', ''), self.meta_get('writer', ''), self.meta_get('country', '')
			cast = self.meta_get('short_cast', []) or self.meta_get('cast', []) or []
			listitem.setLabel(self.title)
			if self.media_type == 'movie':
				plot = self.meta_get('plot')
				listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo})
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setMediaType('movie'), info_tag.setTitle(self.title), info_tag.setOriginalTitle(self.meta_get('original_title')), info_tag.setPlot(plot)
				info_tag.setYear(int(self.year)), info_tag.setRating(rating), info_tag.setVotes(votes), info_tag.setMpaa(mpaa)
				info_tag.setDuration(duration), info_tag.setCountries(country), info_tag.setTrailer(trailer), info_tag.setPremiered(premiered)
				info_tag.setTagLine(tagline), info_tag.setStudios(studio), info_tag.setIMDBNumber(self.imdb_id), info_tag.setGenres(genre)
				info_tag.setWriters(writer), info_tag.setDirectors(director), info_tag.setUniqueIDs({'imdb': self.imdb_id, 'tmdb': str(self.tmdb_id)})
				info_tag.setCast([ku.kodi_actor()(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
			else:
				if st.avoid_episode_spoilers() and int(self.meta_get('playcount', '0')) == 0: plot = self.meta_get('tvshow_plot') or '* Hidden to Prevent Spoilers *'
				else: plot = self.meta_get('plot') or self.meta_get('tvshow_plot')
				# LOCAL PATCH 2026-09-14: tvshow. art keys dropped. AF3's OSD and TMDbHelper's player monitor
				# both read Player.Art(poster) / Art(clearlogo) first, and these carried the same values.
				listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo})
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setMediaType('episode'), info_tag.setTitle(self.meta_get('ep_name')), info_tag.setOriginalTitle(self.meta_get('original_title'))
				# LOCAL PATCH 2026-08-27: the OSD shows the numbering the viewer recognises.
				# self.season/self.episode stay TMDb's everywhere else in this class -- they
				# key the bookmark, the watched mark and the Trakt/Simkl scrobble.
				try:
					from modules.metadata import cour_display_numbers
					_ds, _de = cour_display_numbers(self.meta, self.season, self.episode)
				except Exception: _ds, _de = self.season, self.episode
				info_tag.setTvShowTitle(self.title), info_tag.setTvShowStatus(self.meta_get('status')), info_tag.setSeason(_ds), info_tag.setEpisode(_de)
				info_tag.setPlot(plot), info_tag.setYear(int(self.year)), info_tag.setRating(rating), info_tag.setVotes(votes)
				info_tag.setMpaa(mpaa), info_tag.setDuration(duration), info_tag.setTrailer(trailer), info_tag.setFirstAired(premiered)
				info_tag.setStudios(studio), info_tag.setIMDBNumber(self.imdb_id), info_tag.setGenres(genre), info_tag.setWriters(writer)
				info_tag.setDirectors(director), info_tag.setUniqueIDs({'imdb': self.imdb_id, 'tmdb': str(self.tmdb_id), 'tvdb': str(self.tvdb_id)})
				info_tag.setCast([ku.kodi_actor()(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
				info_tag.setFilenameAndPath(self.url)
			self.set_resume_point(listitem)
			self.set_playback_properties()
		return listitem

	def media_watched_marker(self, force_watched=False, playback_over=False):
		self.media_marked = True
		# LOCAL PATCH 2026-09-03: the write below runs in a Thread, so the refresh cannot
		# happen here -- it would race the DB insert and redraw the STALE indicator. The
		# flag is consumed by run_media_progress once the write has returned.
		if playback_over and not getattr(self, 'playback_chained', False): self.refresh_when_marked = True
		try:
			# getattr: the generic-video path skips the reset block above.
			if self.current_point >= getattr(self, 'watched_tick_percent', 90) or force_watched:
				watched_function = ws.mark_movie if self.media_type == 'movie' else ws.mark_episode
				watched_params = {'action': 'mark_as_watched', 'tmdb_id': self.tmdb_id, 'title': self.title, 'year': self.year, 'season': self.season, 'episode': self.episode,
									'tvdb_id': self.tvdb_id, 'from_playback': 'true'}
				Thread(target=self.run_media_progress, args=(watched_function, watched_params)).start()
				# LOCAL PATCH 2026-07-29: SIMKL secondary scrobble. When SIMKL is
				# authorized AND scrobble is enabled AND it's NOT the primary provider
				# (already handled via ws.mark_*), also push a watched signal to SIMKL.
				# Lets users keep Trakt/MDBList/local as primary while cross-syncing.
				try:
					if st.simkl_user_active() and st.simkl_scrobble_enabled() and st.watched_indicators() != 3:
						Thread(target=self._simkl_scrobble).start()
				except Exception: pass
				# LOCAL PATCH 2026-08-29: AniList anime scrobble. Independent of the SIMKL
				# branch above -- AniList is anime-only and carries the anime identity SIMKL
				# loses, so both can run. It self-gates on a Fribb hit, which is also the
				# anime test, so regular TV costs one offline dict lookup and no thread.
				try:
					if st.anilist_user_active() and st.anilist_scrobble_enabled():
						Thread(target=self._anilist_scrobble).start()
				except Exception: pass
			else:
				ku.clear_property('fenlight.random_episode_history')
				if self.current_point >= 5:
					progress_params = {'media_type': self.media_type, 'tmdb_id': self.tmdb_id, 'curr_time': self.curr_time, 'total_time': self.total_time,
									'title': self.title, 'season': self.season, 'episode': self.episode, 'from_playback': 'true'}
					Thread(target=self.run_media_progress, args=(ws.set_bookmark, progress_params)).start()
		except: pass

	def run_media_progress(self, function, params):
		try: function(params)
		except: pass
		# LOCAL PATCH 2026-09-03: ordering matters -- the mark is committed by the call
		# above, so this is the first safe moment to redraw. Covers the bookmark branch
		# too, which sets the resume bar and was equally invisible until now.
		if getattr(self, 'refresh_when_marked', False):
			self.refresh_when_marked = False
			self._refresh_after_playback()

	# LOCAL PATCH 2026-09-03: redraw the container once playback has finished.
	#
	# watched_status.mark_episode / mark_movie / set_bookmark all force `refresh = False`
	# whenever from_playback is set, and player.py always sets it. That is right for the
	# 90% mark -- the viewer is still watching, and a container redraw behind the video is
	# pure waste -- but it also silenced the redraw for the one moment it is wanted: the
	# episode is over and the list is about to come back into view. Nothing else refreshed
	# either; measured over a whole session with several playbacks, kodi_refresh() fired
	# exactly once, and from an unrelated path. So a finished episode kept its unwatched
	# indicator until the user navigated out of the list and back in.
	#
	# Owned here rather than by passing a flag down into watched_status, because 'playback
	# has ended' is knowledge this class has and that module does not -- from_playback is
	# true for the whole playback lifecycle and cannot express it.
	def _refresh_after_playback(self):
		if getattr(self, 'playback_chained', False): return
		try:
			ku.logger('watched.refresh', 'playback over -- refreshing container')
			ku.kodi_refresh()
		except Exception: pass

	# LOCAL PATCH 2026-07-29: SIMKL side-channel scrobble — mirrors what
	# watched_status.mark_movie/mark_episode do for the primary provider, but
	# targets SIMKL specifically. Only invoked when watched_indicators != 3
	# (i.e. SIMKL is NOT primary — this is cross-sync).
	def _simkl_scrobble(self):
		try:
			from apis.simkl_api import simkl_mark_watched
			if self.media_type == 'movie':
				simkl_mark_watched('movies', 'tmdb', int(self.tmdb_id))
			else:
				try: season, episode = int(self.season), int(self.episode)
				except: return
				seasons = [{'number': season, 'episodes': [{'number': episode}]}]
				simkl_mark_watched('shows', 'tmdb', int(self.tmdb_id), seasons=seasons)
		except Exception: pass

	# LOCAL PATCH 2026-08-29: AniList progress push. Anime only, and the Fribb lookup IS the
	# anime test -- the index holds nothing else, so a miss means "not anime, do nothing".
	#
	# The numbering is the whole point of routing through Fribb rather than sending TMDb's
	# episode number. AniList counts progress WITHIN an entry, and an entry is one cour:
	#   Ace of Diamond TMDb S01E43 -> entry 18689,  progress 43   (flat 75-episode run)
	#   Frieren        TMDb S01E30 -> entry 182255, progress 2    (cour 2 restarts at 1)
	# Sending 30 to entry 154587 would mark six episodes the user has not watched.
	def _anilist_scrobble(self):
		try:
			if self.media_type == 'movie': return
			try: season, episode = int(self.season), int(self.episode)
			except (TypeError, ValueError): return
			if not self.tmdb_id: return
			from caches import fribb_mappings
			cour = fribb_mappings.find_cour_by_tmdb_coords(int(self.tmdb_id), season, episode) or {}
			anilist_id, cour_ep = cour.get('anilist'), cour.get('cour_ep')
			if not anilist_id or not cour_ep: return
			from apis.anilist_api import anilist_set_progress
			anilist_set_progress(anilist_id, cour_ep)
		except Exception: pass

	def run_next_ep(self):
		"""Hand off to the next episode. Returns True only if one actually followed."""
		from modules.episode_tools import EpisodeTools
		self.playback_chained = True   # LOCAL PATCH 2026-09-03: no refresh, another episode follows
		if not self.media_marked: self.media_watched_marker(force_watched=True)
		# LOCAL PATCH 2026-09-12: playback_chained has to be set BEFORE the call -- playback_prep
		# may not return until the next episode is under way -- so clear it again when nothing
		# followed, or _refresh_after_playback would skip the container refresh on a finale.
		handed_off = EpisodeTools(self.meta, self.nextep_settings).auto_nextep()
		if not handed_off: self.playback_chained = False
		return handed_off

	def run_random_continual(self):
		from modules.episode_tools import EpisodeTools
		self.playback_chained = True   # LOCAL PATCH 2026-09-03: as run_next_ep
		if not self.media_marked: self.media_watched_marker(force_watched=True)
		EpisodeTools(self.meta).play_random_continual(False)

	def run_movie_stingers(self):
		self.movie_stingers_run = True
		stinger_keys = self.meta.get('stinger_keys', None)
		if not stinger_keys:
			try:
				keywords = self.meta.get('keywords', [])
				stinger_keys = [i['name'] for i in keywords['keywords'] if i['name'] in ('duringcreditsstinger', 'aftercreditsstinger')]
				self.meta['stinger_keys'] = stinger_keys
			except: pass
		if stinger_keys:
			from windows.base_window import open_window
			Thread(target=lambda: open_window(('windows.playback_notifications', 'StingersNotification'), 'playback_notifications.xml', meta=self.meta)).start()

	def set_resume_point(self, listitem):
		if self.playback_percent > 0.0: listitem.setProperty('StartPercent', str(self.playback_percent))

	def info_next_ep(self):
		# LOCAL PATCH 2026-08-25: flag moved into `finally`. It used to be set BEFORE the
		# body, so any exception hit the bare `except: pass` with start_prep/nextep_settings
		# never assigned -- monitor()'s `remaining <= self.start_prep` test then raised on
		# every tick into its own `except: pass`, silently killing autoplay for the whole
		# episode. Setting it in finally still guarantees single-shot, and the except now logs.
		try:
			play_type = 'autoplay_nextep' if self.autoplay_nextep else 'autoscrape_nextep'
			nextep_settings = st.auto_nextep_settings(play_type)
			watching_check = nextep_settings['watching_check']
			# LOCAL PATCH 2026-08-25: the silent +15s that used to be added here is gone.
			# sources.py already pops the StillWatching dialog on this exact condition
			# (watch_count == watching_check), so the bump was double-accounting -- it
			# shifted the alert 15s earlier for a prompt the user answers anyway.
			# LOCAL PATCH 2026-07-04 (Plan B: timing precision): transition-point priority chain
			# for the next-episode alert. Alert fires when `total_time - curr_time <= start_prep`.
			# `window_time` here = target seconds-before-end at which the alert should appear.
			# Priority chain (best signal first):
			#   1. IntroDB outro_end — fires AT the credits→next-ep transition. Was previously
			#      firing at outro_START (missed the last portion of the theme song / any
			#      post-outro preview clip). Now uses outro_end from api.introdb.app.
			#   2. IntroDB outro_start — fallback if outro_end missing from IntroDB response.
			#   3. Player.Chapters final_chapter — for BluRay/remux files with chapter markers,
			#      the last chapter typically IS the credits chapter (kept as before).
			#   4. Percentage fallback — nextep.window_percentage setting (kept as before).
			# All paths gated by their existing enable flags — IntroDB path only when
			# skipsegment.outro.mode == 'autoplay_countdown', chapter path only when use_chapters on.
			window_time = None
			transition_source = None
			# LOCAL PATCH 2026-07-22: post-outro-content gap heuristic.
			# Prefer outro_START (Netflix-style — countdown visible during outro) UNLESS
			# the episode has meaningful video AFTER the outro (anime next-ep preview,
			# post-credits scene, etc). In that case, fire alert at outro_END so the
			# user can watch the post-outro content first.
			# `post_outro_gap = total_time - outro_end`. Threshold 30s covers anime
			# previews (typically 30-60s). Below the threshold, the outro extends
			# essentially to the end of the video → fire at outro_start.
			POST_OUTRO_GAP_THRESHOLD = 30
			try:
				# LOCAL PATCH 2026-08-25: honor skipsegment.outro.mode. The comment above has
				# always claimed the IntroDB path is gated on 'autoplay_countdown' but nothing
				# ever checked it, so the outro drove alert timing in every mode.
				#
				# 55db566 briefly relaxed this to "only 'off' disqualifies" -- that was wrong
				# and is reverted here. outro.mode is not a style preference, it selects who
				# OWNS the outro segment, and the owners are mutually exclusive:
				#   autoplay_countdown -> the ALERT owns it: show at outro_start, count down,
				#                         autoplay. No skip competes.
				#   auto               -> the SKIPPER owns it: seek past the credits; the file
				#                         then ends and autoplay follows the natural-end path.
				#                         An alert here would flash and vanish as playback
				#                         jumps away, and the seek looks like a user stop.
				#   manual             -> the USER owns it (Skip button).
				#   off                -> nobody.
				# Only the alert-owned mode may drive alert timing; everything else falls
				# through to chapter/percentage.
				outro_mode = get_setting('fenlight.skipsegment.outro.mode', 'autoplay_countdown')
				outro = (getattr(self, 'skip_segments_data', None) or {}).get('outro') or []
				if outro_mode != 'autoplay_countdown': outro = []
				# LOCAL PATCH 2026-08-26: apply the same bogus-segment guard the skip path
				# already uses (_check_skip_segments, min 15s -- Red Light 1.6.7 port). The
				# two disagreed: a 12s intro was rejected for skipping while a 5s outro was
				# happily accepted for timing, producing window_time=5s on a 2848s episode.
				# A 5-second "outro" is not a credits sequence, it is bad IntroDB data (often
				# timings that belong to a different cut of the release). Reject and fall
				# through to chapter/percentage.
				MIN_OUTRO_SECONDS = 15
				if outro and self.total_time:
					outro_start = outro[0][0]
					outro_end = outro[0][1] if len(outro[0]) > 1 else None
					os_valid = outro_start is not None and 0 < outro_start < self.total_time
					oe_valid = outro_end is not None and 0 < outro_end < self.total_time
					# LOCAL PATCH 2026-08-26: cut mismatch. An outro_end beyond the runtime
					# means IntroDB's timings describe a LONGER cut than the file playing --
					# observed on Reacher s2e3: outro 2843->2985 (a normal 142s credits) against
					# a 2848s 2160p AMZN WEB-DL. outro_end was correctly rejected as
					# out-of-range but outro_start from the same record was still trusted,
					# yielding window_time=5s. Neither endpoint is usable, so drop the segment.
					# Tolerance matters: outro_end == total_time is the NORMAL case (credits
					# run to the file end), so only a mark meaningfully BEYOND the runtime
					# indicates a mismatched cut.
					if outro_end is not None and outro_end > self.total_time + 2:
						ku.logger('NextEp Timing', 'rejecting outro: end %.0fs exceeds runtime %.0fs (data is for a different cut)'
							% (outro_end, self.total_time))
						os_valid = oe_valid = False
					# Duration check when both ends are known.
					if os_valid and oe_valid and (outro_end - outro_start) < MIN_OUTRO_SECONDS:
						ku.logger('NextEp Timing', 'rejecting outro: duration %.1fs < %ds min'
							% (outro_end - outro_start, MIN_OUTRO_SECONDS))
						os_valid = oe_valid = False
					# The alert also needs to sit far enough from the end to be usable at all.
					if os_valid and (self.total_time - outro_start) < MIN_OUTRO_SECONDS:
						ku.logger('NextEp Timing', 'rejecting outro_start: only %.1fs before end (< %ds min)'
							% (self.total_time - outro_start, MIN_OUTRO_SECONDS))
						os_valid = False
					# Same floor for the outro_end path -- an end mark within seconds of the
					# file end leaves no usable window either.
					if oe_valid and (self.total_time - outro_end) < MIN_OUTRO_SECONDS:
						oe_valid = False
					if os_valid and oe_valid:
						post_outro_gap = self.total_time - outro_end
						if post_outro_gap < POST_OUTRO_GAP_THRESHOLD:
							# Outro at end of video — fire at outro_start (countdown during outro)
							window_time = max(0, self.total_time - outro_start)
							transition_source = 'introdb_outro_start'
						else:
							# Meaningful post-outro content — fire at outro_end
							window_time = max(0, self.total_time - outro_end)
							transition_source = 'introdb_outro_end'
					elif os_valid:
						# Only outro_start available — use it
						window_time = max(0, self.total_time - outro_start)
						transition_source = 'introdb_outro_start'
					elif oe_valid:
						# Only outro_end available — use it
						window_time = max(0, self.total_time - outro_end)
						transition_source = 'introdb_outro_end'
			except Exception as e:
				ku.logger('IntroDB outro parse error', str(e))
			if window_time is None and nextep_settings['use_chapters']:
				final_chapter = self.final_chapter(90)
				if final_chapter and self.total_time:
					window_time = round(((100 - final_chapter) / 100.0) * self.total_time)
					transition_source = 'chapter'
			if window_time is None:
				percentage = nextep_settings['window_percentage']
				window_time = round((percentage / 100.0) * self.total_time) if self.total_time else 0
				transition_source = 'percentage'
			window_time = round(window_time)
			use_window = nextep_settings['alert_method'] == 0
			default_action = nextep_settings['default_action']
			self.start_prep = nextep_settings['scraper_time'] + window_time
			# LOCAL PATCH 2026-08-25: tier the alert behaviour by how much the timing source
			# can be trusted. IntroDB outro genuinely marks "credits are rolling", so a short
			# countdown into them and then autoplaying is correct (Netflix-style). An
			# arbitrary point is not, and treating it the same meant autoplay cut real
			# episode. LOW confidence keeps the early alert (heads-up + scrape headroom) but
			# counts down to the true end of the video and only autoplays there -- and the
			# alert shows the REMAINING TIME rather than a countdown, because a countdown to
			# a number we guessed is a lie. Consumed by NextEpisode.monitor().
			#
			# LOCAL PATCH 2026-09-05: a final chapter counts as REAL DATA and keeps the
			# countdown, same as IntroDB outro. (I briefly demoted it to 'low' on the theory
			# that final_chapter(90) cannot tell a credits chapter from whichever chapter
			# happens to be last; reverted at the user's direction -- on their releases the
			# final chapter does mark the credits, and the countdown is wanted there.)
			#
			# The only change kept from that pass: a MISSING transition_source now reads as
			# low rather than high. `x != 'percentage'` treated None -- no timing source at
			# all -- as the most trustworthy case, which is backwards. Unreachable today
			# because the percentage branch always assigns, but it is the wrong default to
			# leave sitting there.
			timing_confidence = 'low' if transition_source in (None, 'percentage') else 'high'
			self.nextep_settings = {'use_window': use_window, 'window_time': window_time, 'default_action': default_action,
									'play_type': play_type, 'watching_check': watching_check,
									'timing_confidence': timing_confidence, 'transition_source': transition_source,
									'total_time': self.total_time}
			ku.logger('NextEp Timing', 'source=%s confidence=%s window_time=%ss (%.1f%% before end of %ds)' % (
				transition_source, timing_confidence, window_time, (window_time / max(self.total_time or 1, 1)) * 100, self.total_time or 0))
		except Exception as e:
			ku.logger('NextEp Timing', 'info_next_ep failed: %s' % e)
		finally:
			self.nextep_info_gathered = True

	def final_chapter(self, threshhold):
		try:
			final_chapter = float(ku.get_infolabel('Player.Chapters').split(',')[-1])
			if final_chapter >= threshhold: return final_chapter
		except: pass
		return None

	def kill_dialog(self):
		try: self.sources_object._kill_progress_dialog()
		except: ku.close_all_dialog()

	def set_constants(self, url, obj):
		self.url = url
		self.sources_object = obj
		self.is_generic = self.sources_object == 'video'
		if not self.is_generic:
			self.meta = self.sources_object.meta
			self.meta_get, self.kodi_monitor, self.playback_percent = self.meta.get, ku.kodi_monitor(), self.sources_object.playback_percent or 0.0
			self.playing_filename = self.sources_object.playing_filename
			self.media_marked, self.nextep_info_gathered, self.movie_stingers_run = False, False, False
			self.nextep_handoff_attempted = False   # LOCAL PATCH 2026-09-12: see monitor()
			# LOCAL PATCH 2026-09-03: see _refresh_after_playback.
			self.playback_chained, self.refresh_when_marked = False, False
			# LOCAL PATCH 2026-09-03 (Red Light 2.3.6 port): resolved once -- the loop below
			# runs every second and this reads a setting.
			self.watched_tick_percent = st.playback_watched_percent()
			self.playback_successful, self.cancel_all_playback = None, False
			self.playing_item = self.sources_object.playing_item
			self._init_skip_segments()

	def _stop_at_credits_if_no_next(self, segments):
		"""LOCAL PATCH 2026-08-25: stop playback at the credits when nothing follows.

		In autoplay_countdown mode the outro segment is normally handed to the autoplay
		flow — but on a finale (or when the next episode hasn't aired) that flow does
		nothing, so the credits just play out to the end. Here we detect that case and
		stop instead. Returns True when it stopped playback, False to leave the normal
		hand-off alone. Gated on skipsegment.stop_at_credits_no_next (default on)."""
		try:
			if get_setting('fenlight.skipsegment.stop_at_credits_no_next', 'true') != 'true': return False
			# Only act once we've actually reached a credible outro start. Same 15s
			# minimum the main skip loop uses, so bogus IntroDB timings (0s->5s) can't
			# kill playback seconds in.
			outro_start = None
			for (start, end) in segments:
				if start is None: continue
				end_eff = end if end is not None else self.total_time
				if end_eff is None or (end_eff - start) < 15: continue
				if self.curr_time >= start:
					outro_start = start
					break
			if outro_start is None: return False
			# Costs a metadata lookup, and this runs every second — resolve once.
			if self.nextep_available is None:
				from modules.episode_tools import next_episode_available
				self.nextep_available = next_episode_available(self.meta)
			if self.nextep_available: return False
			ku.logger('stop-at-credits', 'no next episode — stopping at outro_start=%s' % outro_start)
			self.skip_segments_consumed.add('outro')
			if not self.media_marked: self.media_watched_marker(force_watched=True)
			mark_internal_stop()   # LOCAL PATCH 2026-08-26: our stop, not the user's
			self.stop()
			return True
		except Exception:
			return False   # fail open — never let this break playback

	def _init_skip_segments(self):
		self.skip_segments_data = None
		self.skip_segments_consumed = set()
		self.nextep_available = None   # LOCAL PATCH 2026-08-25: cached once per playback
		self.active_skip_window = None
		self.active_skip_end = None
		self.active_skip_thread = None
		try:
			if not get_setting('fenlight.skipsegment.enabled') == 'true': return
			imdb_id = self.meta_get('imdb_id')
			if not imdb_id: return
			# LOCAL PATCH 2026-08-05: theintrodb.org now supports movies too — extend
			# skip-segments beyond TV. Episode path passes s/e; movie path passes None+None
			# and only theintrodb.org gets queried (introdb.app is TV-only).
			media_type = self.meta_get('media_type')
			if media_type == 'episode':
				season, episode = self.meta_get('season'), self.meta_get('episode')
				if season is None or episode is None: return
			elif media_type == 'movie':
				season, episode = None, None
			else:
				return
			from apis.introdb_api import fetch_segments
			# LOCAL PATCH 2026-08-27: tmdb_id lets fetch_segments try AniSkip for anime.
			# It is the key into the Fribb index, which yields the MAL id and the cour-
			# relative episode number AniSkip is addressed by. Non-anime is unaffected:
			# a Fribb miss means the two IntroDB providers run exactly as before.
			segs = fetch_segments(imdb_id, season, episode, self.meta_get('tmdb_id'))
			if segs:
				self.skip_segments_data = segs
				ku.logger('IntroDB segments', '%s for imdb=%s s=%s e=%s (%s)' % (list(segs.keys()), imdb_id, season, episode, media_type))
		except Exception as e:
			ku.logger('IntroDB init error', str(e))

	def _check_skip_segments(self):
		if not self.skip_segments_data: return
		curr = self.curr_time
		if self.active_skip_window:
			if curr >= (self.active_skip_end or float('inf')):
				try: self.active_skip_window.request_close()
				except: pass
				self.active_skip_window = None; self.active_skip_end = None; self.active_skip_thread = None
				return
			if getattr(self.active_skip_window, 'user_clicked', False):
				try: self.seekTime(self.active_skip_end or self.total_time)
				except: pass
				try: self.active_skip_window.request_close()
				except: pass
				self.active_skip_window = None; self.active_skip_end = None; self.active_skip_thread = None
				return
			return
		# LOCAL PATCH 2026-08-05: cache media_type once — used below to handle movies
		# (which never fire an autoplay next-ep flow, so 'autoplay_countdown' outro mode
		# would leave movies with no skip button; downgrade it to 'manual' for movies).
		_media_type = self.meta_get('media_type')
		for stype, segments in self.skip_segments_data.items():
			if stype in self.skip_segments_consumed: continue
			mode = get_setting('fenlight.skipsegment.%s.mode' % stype) or 'manual'
			if mode == 'off': continue
			# Outro in 'autoplay_countdown' mode: don't skip/show button here; the autoplay flow handles it.
			# BUT movies have no next-ep autoplay flow, so downgrade to 'manual' — user still gets a Skip Credits button.
			if stype == 'outro' and mode == 'autoplay_countdown':
				if _media_type == 'movie':
					mode = 'manual'
				elif self._stop_at_credits_if_no_next(segments):
					# Finale / next-not-yet-aired: nothing will hand off, so we stopped
					# playback at the outro instead of letting the credits run out.
					return
				else:
					# LOCAL PATCH 2026-09-05: do NOT mark the outro consumed here.
					#
					# This ran `self.skip_segments_consumed.add(stype)`, and _check_skip_segments
					# is called once a second from monitor() starting at t=0 -- so on the FIRST
					# tick, thousands of seconds before the credits, _stop_at_credits_if_no_next
					# correctly returned False (we have not reached outro_start yet) and the
					# outro was retired for the rest of the episode. The guard at the top of
					# this loop then skipped it on every later tick, so the check never got a
					# second chance and stop-at-credits could NEVER fire. Verified by ticking
					# the real method across a simulated episode: reached 1 time in 2700 ticks,
					# at t=0.
					#
					# `continue` alone already does the job this branch needs -- it stops the
					# skip/button code below from claiming an outro that the autoplay flow
					# owns. Consuming it was never required for that, only for not re-running,
					# and re-running is precisely what the stop check needs. It is cheap: the
					# segment scan is a few comparisons and next_episode_available() is
					# resolved once and cached in self.nextep_available.
					continue
			for (start, end) in segments:
				end_eff = end if end is not None else self.total_time
				# LOCAL PATCH 2026-07-10 (port of Red Light 1.6.7): reject bogus IntroDB
				# timings. IntroDB occasionally returns near-zero segments (e.g. 0s > 5s)
				# which manifest as "Skip Intro" flashing at the very start of the episode
				# and seeking a couple of seconds forward — feels like a backwards jump to
				# the user. Guard: (a) require the segment to be at least 15s long for
				# intro/outro (real intros/outros are ~30-90s; skips shorter than 15s are
				# almost always bad data); (b) require curr to be at least 3s BEFORE end
				# so a skip actually moves us meaningfully forward. Recap left at min 8s
				# since some real recaps are short.
				min_duration = 8 if stype == 'recap' else 15
				if (end_eff - start) < min_duration:
					self.skip_segments_consumed.add(stype)
					ku.logger('IntroDB reject', 'stype=%s start=%.1f end=%.1f duration=%.1f min=%d' % (stype, start, end_eff, end_eff - start, min_duration))
					continue
				if end_eff - curr < 3:
					self.skip_segments_consumed.add(stype)
					continue
				if start <= curr < end_eff:
					self.skip_segments_consumed.add(stype)
					if mode == 'auto':
						try: self.seekTime(end_eff)
						except Exception as e: ku.logger('IntroDB auto-skip error', str(e))
					elif mode == 'manual':
						self._spawn_skip_window(stype, end_eff)
					return

	def _spawn_skip_window(self, stype, end_time):
		try:
			from windows.base_window import create_window
			labels = {'intro': 'Skip Intro', 'outro': 'Skip Outro', 'recap': 'Skip Recap'}
			label = labels.get(stype, 'Skip ' + stype.title())
			corner = get_setting('fenlight.skipsegment.button_corner') or 'bottom-right'
			window = create_window(('windows.skip_segment', 'SkipSegment'), 'skip_segment.xml', label=label, corner=corner)
			if not window: return
			import threading
			self.active_skip_window = window
			self.active_skip_end = end_time
			t = threading.Thread(target=window.run, daemon=True)
			self.active_skip_thread = t
			t.start()
		except Exception as e:
			ku.logger('IntroDB spawn skip window error', str(e))

	def set_playback_properties(self):
		try:
			trakt_ids = {'tmdb': self.tmdb_id, 'imdb': self.imdb_id, 'slug': make_trakt_slug(self.title)}
			if self.media_type == 'episode': trakt_ids['tvdb'] = self.tvdb_id
			ku.set_property('script.trakt.ids', json.dumps(trakt_ids))
			if self.playing_filename: ku.set_property('subs.player_filename', self.playing_filename)
		except: pass

	def clear_playback_properties(self):
		ku.clear_property('fenlight.window_stack')
		ku.clear_property('script.trakt.ids')
		ku.clear_property('subs.player_filename')
		# LOCAL PATCH 2026-08-21: reset the stop-vs-end verdict at the start of each
		# playback (run() calls this before play_video) so a Stop on episode N can't
		# suppress the legitimate Next Up alert at the end of episode N+1.
		ku.clear_property(PLAYBACK_STOPPED_PROP)
		ku.clear_property(INTERNAL_STOP_PROP)   # LOCAL PATCH 2026-08-26

	def run_error(self):
		try: self.sources_object.playback_successful = False
		except: pass
		self.clear_playback_properties()
		ku.notification('Playback Failed', 3500)
		return False
