# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-06-15: Clean Stale Kodi Thumbnails helper (port from POV 5.07
# / tuneup.py:clear_thumbnails). Prompts user for a days threshold and removes
# Textures13.db entries + cached image files whose lastusetime is older than the
# cutoff. Kodi rebuilds the cache lazily as artwork is re-displayed.
#
# CoreELEC's Thumbnails dir grows unbounded (commonly 1+ GB after months of
# browsing) — Kodi has no built-in eviction. This gives the user a one-click
# prune that matches POV's behavior.

import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
import xbmc
import xbmcgui
import xbmcvfs
from modules import kodi_utils


def clear_stale_thumbnails():
	"""Interactive: ask for day-cutoff, prune Textures13.db + cache files older
	than that. No-op if user cancels at any prompt. Returns nothing — feedback
	via notifications + a final yes/no confirm before deletion."""
	thumbs_path = Path(xbmcvfs.translatePath('special://thumbnails/'))
	dbfile = Path(xbmcvfs.translatePath('special://database/'), 'Textures13.db')
	if not dbfile.exists():
		return kodi_utils.notification('Textures13.db not found', 3000)

	default_days = 30
	days = kodi_utils.kodi_dialog().input('Remove Thumbs Older Than (Days)…', defaultt=str(default_days), type=1)
	if not days:
		return
	try:
		days_int = int(days)
	except (TypeError, ValueError):
		return kodi_utils.notification('Invalid days value', 3000)
	if days_int <= 0:
		return kodi_utils.notification('Days must be > 0', 3000)

	current_date = datetime.now().date()
	back_date = (current_date - timedelta(days=days_int)).strftime('%Y-%m-%d %H:%M:%S')

	with sqlite3.connect(str(dbfile), timeout=20) as dbcon:
		dbcur = dbcon.cursor()
		try:
			dbcur.execute("PRAGMA synchronous = OFF")
			dbcur.execute("PRAGMA journal_mode = MEMORY")
		except Exception:
			pass
		total = dbcur.execute("SELECT COUNT(*) FROM sizes").fetchone()[0]
		keep_ids = [(r[0],) for r in dbcur.execute(
			"SELECT idtexture FROM sizes WHERE lastusetime >= ?", (back_date,)
		).fetchall()]
		expired = total - len(keep_ids)
		if expired <= 0:
			return kodi_utils.notification('No stale thumbnails (cutoff %d days)' % days_int, 3000)
		if not kodi_utils.confirm_dialog(heading='Clean Stale Kodi Thumbnails',
				text='Delete %d thumbnail entries older than %d days?' % (expired, days_int),
				ok_label='Yes', cancel_label='No'):
			return

		progress = xbmcgui.DialogProgress()
		progress.create('Thumbnails Cleaner', 'Gathering thumbnail info…')
		try:
			dbcur.execute("CREATE TEMP TABLE IF NOT EXISTS keep_thumbs (idtexture INTEGER)")
			dbcur.execute("DELETE FROM keep_thumbs")
			if keep_ids:
				dbcur.executemany("INSERT INTO keep_thumbs VALUES (?)", keep_ids)
			progress.update(20, 'Cleaning Database…[CR]Removing sizes entries…')
			dbcur.execute("DELETE FROM sizes WHERE idtexture NOT IN (SELECT idtexture FROM keep_thumbs)")
			progress.update(40, 'Cleaning Database…[CR]Removing texture entries…')
			dbcur.execute("DELETE FROM texture WHERE id NOT IN (SELECT idtexture FROM keep_thumbs)")
			progress.update(60, 'Cleaning Database…[CR]Vacuuming…')
			dbcon.commit()
			xbmc.sleep(500)
			try:
				dbcur.execute("VACUUM")
			except Exception:
				pass

			progress.update(80, 'Scanning for orphaned files…')
			keep_files = {r[0].split('/')[-1] for r in dbcur.execute("SELECT cachedurl FROM texture").fetchall() if r[0]}
			deleted, scanned = 0, 0
			line_tmpl = 'Scanned: %d files[CR]Removed: %d (expired/orphans)'
			for fp in thumbs_path.glob('**/?/*'):
				if progress.iscanceled():
					break
				if not fp.is_file():
					continue
				scanned += 1
				if fp.name in keep_files:
					continue
				try:
					fp.unlink(missing_ok=True)
				except Exception:
					continue
				deleted += 1
				if scanned % 50 == 0:
					progress.update(80, line_tmpl % (scanned, deleted))
			kodi_utils.notification('Removed %d stale thumbnails' % deleted, 3500)
		finally:
			progress.close()
