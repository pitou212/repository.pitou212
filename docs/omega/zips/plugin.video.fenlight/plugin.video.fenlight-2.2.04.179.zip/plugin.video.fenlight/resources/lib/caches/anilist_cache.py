# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-29: AniList watchlist cache.
#
# Deliberately NOT shaped like caches/simkl_cache.py. SIMKL carries watched / progress /
# watched_status tables of its own because it can be selected as the PRIMARY watched-
# indicator provider (watched_indicators == 3). AniList cannot -- it is anime-only and has
# nothing to say about movies or regular TV -- so it never feeds watched_status dispatch and
# needs no database of its own. Watchlist reads ride the shared lists_db under an
# `anilist_wl_` prefix, which also means AniListMonitor can invalidate them with one DELETE.

from caches.base_cache import connect_database
from caches.lists_cache import lists_cache_object

_PREFIX = 'anilist_wl_'


def anilist_cache_object(function, string, *args, expiration=None):
	"""Cache one watchlist read. `string` is the bare status; the prefix is added here so
	every caller lands in the namespace clear_anilist_lists_cache() knows how to wipe."""
	return lists_cache_object(function, _PREFIX + string, list(args) or 1, expiration=expiration)


def clear_anilist_lists_cache():
	"""Drop every cached AniList watchlist. Called by AniListMonitor when Viewer.updatedAt
	or the entry count changes, and after any mutation this addon makes -- without that
	second call the user's own edit would not show until the next poll."""
	try:
		dbcon = connect_database('lists_db')
		dbcon.execute("DELETE FROM lists WHERE id LIKE '%s%%'" % _PREFIX)
		return True
	except Exception:
		return False
