# -*- coding: utf-8 -*-
from caches.base_cache import connect_database, get_timestamp
# from modules.kodi_utils import logger

# LOCAL PATCH 2026-09-05: two bugs in this file, both measured.
#
# 1. get_many judged the WHOLE batch by cache_data[0]'s expiry. Rows come back ordered by
#    the unique index on (hash, debrid), so row [0] is simply the lowest hex hash in the
#    batch -- uncorrelated with when it expires. Simulated over the live table, 300 lookups
#    of 150 hashes: the first row was live 8.3% of the time. So 91.7% of lookups threw the
#    ENTIRE local cache away and re-checked every hash against the debrid service, and the
#    other 8.3% served every expired row in the batch as fresh (stale "CACHED" badges).
#    Worse, the else branch passed the whole result set to remove_many, deleting the LIVE
#    rows along with the expired ones. Now filtered per row, and only the expired subset is
#    removed. Measured cost of the unnecessary re-check on this install: ~1.0s per scrape.
#
# 2. Every method called dbcon.close() on a connection base_cache.connect_database CACHES
#    PER THREAD and hands back next time (base_cache.py:144-165 -- it only reconnects when
#    the generation counter changes, and never pings for liveness). So the second call in a
#    thread got a closed handle and raised into the bare except. remove_many runs in the
#    same thread as get_many, which is why it could NEVER succeed -- the mechanism behind
#    4,185 orphaned rows (90.6% of the table). The closes are gone; the pool owns the
#    connection's lifetime.
class DebridCache:
	def get_many(self, hash_list):
		result = None
		try:
			dbcon = connect_database('debridcache_db')
			current_time = get_timestamp()
			cache_data = dbcon.execute('SELECT * FROM debrid_data WHERE hash in (%s)' % (', '.join('?' for _ in hash_list)), hash_list).fetchall()
			if cache_data:
				live = [i for i in cache_data if i[3] > current_time]
				expired = [i for i in cache_data if i[3] <= current_time]
				if expired: self.remove_many(expired)
				result = live or None
		except: pass
		return result

	def set_many(self, hash_list, debrid, expires=24):
		try:
			dbcon = connect_database('debridcache_db')
			expires = get_timestamp(expires)
			insert_list = [(i[0], debrid, i[1], expires) for i in hash_list]
			dbcon.executemany('INSERT INTO debrid_data VALUES (?, ?, ?, ?)', insert_list)
		except: pass

	def remove_many(self, old_cached_data):
		# LOCAL PATCH 2026-09-05: delete by (hash, debrid), not hash alone. The table's unique
		# key is the pair, so one hash can legitimately hold a row per service -- and pruning
		# an expired TorBox verdict would take a live Real-Debrid one with it. Inert while
		# only one debrid is configured; wrong the moment a second is.
		try:
			dbcon = connect_database('debridcache_db')
			old_cached_data = [(str(i[0]), str(i[1])) for i in old_cached_data]
			dbcon.executemany('DELETE FROM debrid_data WHERE hash=? AND debrid=?', old_cached_data)
		except: pass

	def clear_debrid_results(self, debrid):
		try:
			dbcon = connect_database('debridcache_db')
			dbcon.execute('DELETE FROM debrid_data WHERE debrid=?', (debrid,))
			dbcon.execute('VACUUM')
			return True
		except: return False
	
	def clear_cache(self):
		try:
			dbcon = connect_database('debridcache_db')
			dbcon.execute('DELETE FROM debrid_data')
			dbcon.execute('VACUUM')
			return True
		except: return False

	def clean_database(self):
		try:
			dbcon = connect_database('debridcache_db')
			dbcon.execute('DELETE from debrid_data WHERE CAST(expires AS INT) <= ?', (get_timestamp(),))
			dbcon.execute('VACUUM')
			return True
		except: return False

debrid_cache = DebridCache()