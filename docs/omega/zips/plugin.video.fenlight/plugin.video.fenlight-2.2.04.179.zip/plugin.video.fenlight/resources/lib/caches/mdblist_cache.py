# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-23: MDBList cache module ported from POV's mdbl_cache.py.
# Mirrors caches/trakt_cache.py 1:1 in shape — same table layout (mdbl_data KV
# blob + watched + progress + watched_status), same set_bulk_* signatures so
# watched_status.py dispatch can call either interchangeably based on
# watched_indicators setting (1=Trakt, 2=MDBList).
from threading import Thread
from caches.base_cache import connect_database
from modules.kodi_utils import confirm_dialog


class MDBLCache:
	def get(self, string):
		result = None
		try:
			dbcon = connect_database('mdblist_db')
			cache_data = dbcon.execute('SELECT data FROM mdbl_data WHERE id = ?', (string,)).fetchone()
			if cache_data: result = eval(cache_data[0])
		except: pass
		return result

	def set(self, string, data):
		try:
			dbcon = connect_database('mdblist_db')
			dbcon.execute('INSERT OR REPLACE INTO mdbl_data (id, data) VALUES (?, ?)', (string, repr(data)))
		except: return None

	def delete(self, string):
		try:
			dbcon = connect_database('mdblist_db')
			dbcon.execute('DELETE FROM mdbl_data WHERE id = ?', (string,))
		except: pass

	# ─── Bulk setters (called from mdbl_indicators_* / mdbl_progress_*) ────
	# Signatures mirror TraktWatched so watched_status dispatch is drop-in
	# swappable. Same empty-list guard from trakt_cache.py:47 — never wipe
	# the local watched/progress table if the sync returned empty (API may
	# have failed; keep old data until the next successful sync).
	def set_bulk_movie_watched(self, insert_list):
		if not insert_list: return
		self._delete('DELETE FROM watched WHERE db_type = ?', ('movie',))
		self._executemany('INSERT OR IGNORE INTO watched VALUES (?, ?, ?, ?, ?, ?)', insert_list)

	def set_bulk_tvshow_watched(self, insert_list):
		if not insert_list: return
		self._delete('DELETE FROM watched WHERE db_type = ?', ('episode',))
		self._executemany('INSERT OR IGNORE INTO watched VALUES (?, ?, ?, ?, ?, ?)', insert_list)

	def set_bulk_movie_progress(self, insert_list):
		if not insert_list: return
		self._delete('DELETE FROM progress WHERE db_type = ?', ('movie',))
		self._executemany('INSERT OR IGNORE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', insert_list)

	def set_bulk_tvshow_progress(self, insert_list):
		if not insert_list: return
		self._delete('DELETE FROM progress WHERE db_type = ?', ('episode',))
		self._executemany('INSERT OR IGNORE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', insert_list)

	def _executemany(self, command, insert_list):
		dbcon = connect_database('mdblist_db')
		dbcon.executemany(command, insert_list)

	def _delete(self, command, args):
		# LOCAL PATCH 2026-08-10 (Red Light 2.2.1 port): VACUUM removed from the sync
		# hot path — see the matching comment in caches/trakt_cache.py. (simkl_cache
		# never had it.) Space is still reclaimed by clear_all_mdbl_cache_data().
		dbcon = connect_database('mdblist_db')
		dbcon.execute(command, args)


mdbl_cache = MDBLCache()


def cache_mdbl_object(function, string, url):
	cache = mdbl_cache.get(string)
	if cache is not None: return cache
	result = function(url)
	mdbl_cache.set(string, result)
	return result


# ═══════════════════════════════════════════════════════════════════════════
#  Activity pivot — the master sync in mdblist_api reads/writes this record.
# ═══════════════════════════════════════════════════════════════════════════

def reset_activity(latest_activities):
	string = 'mdbl_get_activity'
	try:
		dbcon = connect_database('mdblist_db')
		data = dbcon.execute('SELECT data FROM mdbl_data WHERE id = ?', (string,)).fetchone()
		if data: cached_data = eval(data[0])
		else: cached_data = default_activities()
		dbcon.execute('DELETE FROM mdbl_data WHERE id=?', (string,))
		mdbl_cache.set(string, latest_activities)
	except: cached_data = default_activities()
	return cached_data


# ═══════════════════════════════════════════════════════════════════════════
#  Cache invalidation — each write op or sync activity change calls these.
# ═══════════════════════════════════════════════════════════════════════════

def clear_mdbl_collection_watchlist_data(list_type):
	# list_type = 'collection' | 'watchlist'
	string = 'mdbl_%s' % list_type
	try:
		dbcon = connect_database('mdblist_db')
		dbcon.execute('DELETE FROM mdbl_data WHERE id=?', (string,))
	except: pass


def clear_mdbl_list_data(list_type):
	# list_type = 'my_lists' | 'external' | 'hidden_items_dropped'
	string = 'mdbl_%s' % list_type
	try:
		dbcon = connect_database('mdblist_db')
		dbcon.execute('DELETE FROM mdbl_data WHERE id=?', (string,))
	except: pass


def clear_mdbl_list_contents_data(list_type):
	string = 'mdbl_list_contents_' + list_type + '_%'
	try:
		dbcon = connect_database('mdblist_db')
		dbcon.execute('DELETE FROM mdbl_data WHERE id LIKE "%s"' % string)
	except: pass


def clear_all_mdbl_cache_data(silent=False, refresh=True):
	try:
		start = silent or confirm_dialog()
		if not start: return False
		dbcon = connect_database('mdblist_db')
		for table in ('progress', 'watched', 'watched_status'):
			dbcon.execute('DELETE FROM %s' % table)
		dbcon.execute('DELETE FROM mdbl_data')
		dbcon.execute('VACUUM')
		if refresh:
			from apis.mdblist_api import mdbl_sync_activities
			Thread(target=mdbl_sync_activities).start()
		return True
	except: return False


def default_activities():
	# MDBList's sync/last_activities response shape. Any field the server may
	# emit is present here at epoch so first-time diffs always trigger a rebuild.
	return {
		'collected_at':       '2020-01-01T00:00:01.000Z',
		'watchlisted_at':     '2020-01-01T00:00:01.000Z',
		'dropped_at':         '2020-01-01T00:00:01.000Z',
		'list_updated_at':    '2020-01-01T00:00:01.000Z',
		'watched_at':         '2020-01-01T00:00:01.000Z',
		'episode_watched_at': '2020-01-01T00:00:01.000Z',
		'paused_at':          '2020-01-01T00:00:01.000Z',
		'episode_paused_at':  '2020-01-01T00:00:01.000Z',
	}
