# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-28: AniList (GraphQL) browse client.
# Ported from Otaku's AniListBrowser.py (~1644 LOC) but stripped down to the
# minimal browse surface Fen Light needs. Jikan/MAL was the original target
# but is shutting down Oct 2026 — AniList (community-owned, GraphQL, no auth
# for browse, 90 req/min) is the actively-maintained replacement.
#
# Endpoint: https://graphql.anilist.co
# Docs: https://anilist.gitbook.io/anilist-apiv2-docs/
# All browse methods return: {'items': [...], 'has_next': bool, 'page': int}

import datetime
import json as _json
import time

from caches.lists_cache import lists_cache_object, lists_cache
from caches.settings_cache import get_setting, set_setting
from modules.kodi_utils import make_session, logger, notification, ok_dialog, kodi_dialog

_ANILIST_URL = 'https://graphql.anilist.co'
_APP_REGISTER_URL = 'https://anilist.co/settings/developer'

session = make_session(_ANILIST_URL)


# ═══════════════════════════════════════════════════════════════════════════
#  Account layer (LOCAL PATCH 2026-08-29)
#
#  Everything above the mutations stays anonymous -- browse never needs a token and must
#  keep working for users who never log in. Settings accessors strip whitespace, matching
#  simkl_api._client_id, because these values arrive by copy-paste.
# ═══════════════════════════════════════════════════════════════════════════

def _setting(name):
	val = (get_setting('fenlight.anilist.%s' % name, '') or '').strip()
	return val if val and val != 'empty_setting' else ''


def _access_token(): return _setting('token')


def _auth_headers():
	token = _access_token()
	return {'Authorization': 'Bearer %s' % token} if token else {}


def anilist_user_active():
	return bool(_access_token() and _setting('user'))

_SEASONS = ('WINTER', 'SPRING', 'SUMMER', 'FALL')

# GraphQL fragment for the minimal Media fields we need to hand off to TMDb.
# Full field list (title/coverImage/description/format/episodes/status/genres/
# duration/countryOfOrigin/averageScore/startDate) is what Otaku pulls too —
# reused so we can display richer info later without re-fetching.
_MEDIA_FIELDS = '''
	id
	idMal
	title { romaji english native }
	coverImage { extraLarge large }
	bannerImage
	startDate { year month day }
	endDate { year }
	description
	format
	episodes
	status
	genres
	# LOCAL PATCH 2026-08-29: AniList tags are far more specific than TMDb genres
	# ("Female Protagonist", "Time Manipulation", "Episodic"). rank is 0-100 and
	# isMediaSpoiler marks the ones that give plot away -- both are needed to filter
	# sensibly, so pull all three fields.
	tags { name rank isMediaSpoiler }
	duration
	averageScore
	countryOfOrigin
	trailer { id site }
'''


def _current_season():
	"""Return (season_enum, year) for the current calendar quarter."""
	now = datetime.datetime.utcnow()
	season = _SEASONS[(now.month - 1) // 3]
	return season, now.year


def _shift_season(base_season, base_year, direction):
	"""Advance/rewind by one season. direction=+1 for next, -1 for last."""
	idx = _SEASONS.index(base_season)
	new_idx = (idx + direction) % 4
	new_season = _SEASONS[new_idx]
	# Year rolls over on WINTER→FALL (backwards) or FALL→WINTER (forwards).
	if direction == 1 and base_season == 'FALL':
		return new_season, base_year + 1
	if direction == -1 and base_season == 'WINTER':
		return new_season, base_year - 1
	return new_season, base_year


def _season_for(period):
	"""period ∈ {'this', 'next', 'last'} → (season_enum, year)."""
	base_season, base_year = _current_season()
	if period == 'this': return base_season, base_year
	if period == 'next': return _shift_season(base_season, base_year, +1)
	if period == 'last': return _shift_season(base_season, base_year, -1)
	return base_season, base_year


# ═══════════════════════════════════════════════════════════════════════════
#  GraphQL POST + response cache
# ═══════════════════════════════════════════════════════════════════════════

def _post_anilist(query, variables, auth=False, node='Page'):
	"""Uncached POST. lists_cache_object handles caching around this.

	auth=True attaches the user's bearer token -- required for anything touching Viewer or
	SaveMediaListEntry. node names the field to unwrap from `data`; the browse queries all
	return a Page, the account queries and mutations do not, so they pass node=None and get
	the whole `data` object back.
	"""
	try:
		headers = _auth_headers() if auth else None
		r = session.post(_ANILIST_URL, json={'query': query, 'variables': variables},
						headers=headers, timeout=15)
		# A dead or revoked token answers 400/401 with an errors array; treat it like any
		# other miss rather than raising into a caller that may be tearing down playback.
		if r.status_code in (400, 401) and auth:
			logger('AniList: auth rejected', 'HTTP %s -- token may be expired or revoked' % r.status_code)
			return None
		r.raise_for_status()
		data = r.json()
		if 'errors' in data:
			if auth: logger('AniList: query errors', str(data['errors'])[:200])
			return None
		data = data.get('data') or {}
		return data if node is None else data.get(node)
	except Exception:
		return None


def _cached_page(cache_key, query, variables):
	"""Return {'items': [...], 'has_next': bool} from a cached AniList query.
	lists_cache_object stores the pickled result under `string=cache_key`."""
	def _fetch(_dummy_arg):
		res = _post_anilist(query, variables)
		if not res: return {'items': [], 'has_next': False}
		return {
			'items': res.get('ANIME') or res.get('media') or [],
			'has_next': (res.get('pageInfo') or {}).get('hasNextPage', False),
		}
	# lists_cache_object signature: (function, string, *args) — pass a
	# throwaway arg since _fetch requires one.
	# LOCAL PATCH 2026-08-29: key suffixed _t1 when `tags` joined _MEDIA_FIELDS. Pages cached
	# before that lack the field entirely and would show no tags until the 48h TTL lapsed.
	return lists_cache_object(_fetch, '%s_t1' % cache_key, 1)


# ═══════════════════════════════════════════════════════════════════════════
#  Query templates
# ═══════════════════════════════════════════════════════════════════════════

_BROWSE_QUERY = '''
query (
	$page: Int = 1,
	$perpage: Int = 25,
	$type: MediaType,
	$isAdult: Boolean = false,
	$season: MediaSeason,
	$year: String,
	$status: MediaStatus,
	$format: [MediaFormat],
	$genre: [String],
	$sort: [MediaSort] = [POPULARITY_DESC, SCORE_DESC]
) {
	Page(page: $page, perPage: $perpage) {
		pageInfo { hasNextPage }
		ANIME: media(
			type: $type,
			season: $season,
			startDate_like: $year,
			sort: $sort,
			status: $status,
			format_in: $format,
			genre_in: $genre,
			isAdult: $isAdult
		) {
''' + _MEDIA_FIELDS + '''
		}
	}
}
'''

_SEARCH_QUERY = '''
query ($page: Int = 1, $perpage: Int = 25, $search: String, $type: MediaType, $isAdult: Boolean = false) {
	Page(page: $page, perPage: $perpage) {
		pageInfo { hasNextPage }
		ANIME: media(
			search: $search,
			type: $type,
			sort: SEARCH_MATCH,
			isAdult: $isAdult
		) {
''' + _MEDIA_FIELDS + '''
		}
	}
}
'''


# ═══════════════════════════════════════════════════════════════════════════
#  Public browse methods — one per menu entry
#  All return {'items': [...], 'has_next': bool, 'page': int}
# ═══════════════════════════════════════════════════════════════════════════

def _airing_season(period, sort, page_no):
	season, year = _season_for(period)
	variables = {
		'page': int(page_no),
		'perpage': 25,
		'type': 'ANIME',
		'season': season,
		'year': '%s%%' % year,
		'sort': [sort],
	}
	cache_key = 'anilist_airing_%s_%s_%s' % (period, sort, page_no)
	res = _cached_page(cache_key, _BROWSE_QUERY, variables) or {'items': [], 'has_next': False}
	res['page'] = int(page_no)
	return res


# LOCAL PATCH 2026-09-04: fmt/genre ride the same engine. AniList's media() takes
# format_in and genre_in alongside everything already passed, so a format row is the
# existing ranked browse with one more filter -- not a new code path. This is where
# Otaku's Movies / TV Shorts / OVAs / ONAs / Specials rows come from; same API.
def _ranked(sort, period_mode, page_no, fmt=None, genre=None):
	"""period_mode ∈ {'all_time', 'this_year', 'last_year', 'this_season', 'last_season'}"""
	variables = {
		'page': int(page_no),
		'perpage': 25,
		'type': 'ANIME',
		'sort': [sort],
	}
	if period_mode == 'this_year':
		variables['year'] = '%s%%' % datetime.datetime.utcnow().year
	elif period_mode == 'last_year':
		variables['year'] = '%s%%' % (datetime.datetime.utcnow().year - 1)
	elif period_mode == 'this_season':
		season, year = _season_for('this')
		variables['season'] = season
		variables['year'] = '%s%%' % year
	elif period_mode == 'last_season':
		season, year = _season_for('last')
		variables['season'] = season
		variables['year'] = '%s%%' % year
	# 'all_time' -> no year/season filter
	if fmt: variables['format'] = list(fmt)
	if genre: variables['genre'] = list(genre)
	# the filters MUST reach the cache key or every format row would serve whichever one
	# was fetched first out of lists_cache.
	cache_key = 'anilist_%s_%s_%s%s%s' % (sort, period_mode, page_no,
			'_f' + '.'.join(fmt) if fmt else '', '_g' + '.'.join(genre) if genre else '')
	res = _cached_page(cache_key, _BROWSE_QUERY, variables) or {'items': [], 'has_next': False}
	res['page'] = int(page_no)
	return res


# Season / airing
def anilist_airing_this_season(page_no): return _airing_season('this', 'POPULARITY_DESC', page_no)
def anilist_airing_next_season(page_no): return _airing_season('next', 'POPULARITY_DESC', page_no)
def anilist_airing_last_season(page_no): return _airing_season('last', 'TRENDING_DESC', page_no)

# Trending
def anilist_trending_this_season(page_no): return _ranked('TRENDING_DESC', 'this_season', page_no)
def anilist_trending_this_year(page_no):   return _ranked('TRENDING_DESC', 'this_year', page_no)
def anilist_trending_all_time(page_no):    return _ranked('TRENDING_DESC', 'all_time', page_no)

# Popular
def anilist_popular_this_season(page_no):  return _ranked('POPULARITY_DESC', 'this_season', page_no)
def anilist_popular_this_year(page_no):    return _ranked('POPULARITY_DESC', 'this_year', page_no)
def anilist_popular_all_time(page_no):     return _ranked('POPULARITY_DESC', 'all_time', page_no)

# Top rated
def anilist_top_100(page_no):              return _ranked('SCORE_DESC', 'all_time', page_no)

# Most favorited
def anilist_favourites_all_time(page_no):  return _ranked('FAVOURITES_DESC', 'all_time', page_no)

# LOCAL PATCH 2026-09-04: periods the engine already supported but nothing exposed.
def anilist_popular_last_year(page_no):    return _ranked('POPULARITY_DESC', 'last_year', page_no)
def anilist_trending_last_season(page_no): return _ranked('TRENDING_DESC', 'last_season', page_no)

# LOCAL PATCH 2026-09-04: browse by format. MUSIC is deliberately absent -- _classify in
# indexers/anilist_lists.py returns None for it and _render drops those items, so a Music
# row would fetch happily and then display nothing.
def anilist_movies(page_no):     return _ranked('POPULARITY_DESC', 'all_time', page_no, fmt=['MOVIE'])
def anilist_tv_shorts(page_no):  return _ranked('POPULARITY_DESC', 'all_time', page_no, fmt=['TV_SHORT'])
def anilist_ovas(page_no):       return _ranked('POPULARITY_DESC', 'all_time', page_no, fmt=['OVA'])
def anilist_onas(page_no):       return _ranked('POPULARITY_DESC', 'all_time', page_no, fmt=['ONA'])
def anilist_specials(page_no):   return _ranked('POPULARITY_DESC', 'all_time', page_no, fmt=['SPECIAL'])


# Search
def anilist_search(query, page_no):
	variables = {'page': int(page_no), 'perpage': 25, 'search': query, 'type': 'ANIME'}
	cache_key = 'anilist_search_%s_%s' % (query, page_no)
	res = _cached_page(cache_key, _SEARCH_QUERY, variables) or {'items': [], 'has_next': False}
	res['page'] = int(page_no)
	return res


# ═══════════════════════════════════════════════════════════════════════════
#  Romaji title lookup by MAL id
#
#  LOCAL PATCH 2026-08-10: replaces the `mal_title` column of the retired
#  Goldenfreddy anime_mappings DB (upstream frozen since 2026-05-31, so it was
#  missing titles for ~30% of current-season anime — exactly the shows most
#  likely to be scraped). AniList always has them and is authoritative.
#
#  Romaji titles are what anime torrent releases actually use (Nyaa lists
#  "Tensei Shitara Slime Datta Ken", not TMDb's "That Time I Got Reincarnated
#  as a Slime"), so this feeds the nyaa search-alias path in scrapers/external.py.
#
#  Cost: ~600ms per uncached call, so results are cached 30 days — romaji titles
#  never change. The bulk variant fetches every cour of a show in ONE request,
#  so scraping any episode of a show warms the whole franchise at once.
# ═══════════════════════════════════════════════════════════════════════════

_ROMAJI_BY_MAL_QUERY = '''
query ($idMal: Int) {
	Page(page: 1, perPage: 1) {
		ANIME: media(idMal: $idMal, type: ANIME) {
			idMal
			title { romaji english native }
		}
	}
}
'''

_ROMAJI_BULK_QUERY = '''
query ($idMal_in: [Int]) {
	Page(page: 1, perPage: 50) {
		ANIME: media(idMal_in: $idMal_in, type: ANIME) {
			idMal
			title { romaji english native }
			coverImage { extraLarge large }
		}
	}
}
'''

_TITLE_CACHE_HOURS = 720   # 30 days — romaji titles are immutable in practice


def _pick_romaji(media):
	"""Prefer romaji (what release groups use), fall back to native then english."""
	t = (media or {}).get('title') or {}
	return t.get('romaji') or t.get('native') or t.get('english') or None


def anilist_romaji_for_mal(mal_id):
	"""MAL id -> romaji title (str) or None. Cached 30 days."""
	if not mal_id: return None
	try: mal_id = int(mal_id)
	except (TypeError, ValueError): return None
	def _fetch(_dummy):
		res = _post_anilist(_ROMAJI_BY_MAL_QUERY, {'idMal': mal_id})
		# Distinguish "request failed" from "AniList genuinely has no such id":
		# returning {} makes lists_cache_object apply its 0.3h short TTL, so a
		# transient network blip is retried in ~18min instead of poisoning the
		# cache for 30 days. A real miss caches the '' sentinel for the full TTL.
		if res is None: return {}
		media = res.get('ANIME') or res.get('media') or []
		return {'title': (_pick_romaji(media[0]) if media else None) or ''}
	out = lists_cache_object(_fetch, 'anilist_romaji_%s' % mal_id, 1, expiration=_TITLE_CACHE_HOURS)
	return (out or {}).get('title') or None


def _pick_cover(media):
	"""Best cover image URL for a media node, or None.

	LOCAL PATCH 2026-08-27: each cour of an anime is its own AniList entry with its own
	cover, which is what makes per-cour season art possible -- Bleach TYBW cour 1 is
	bx116674 and cour 2 (Ketsubetsu-tan) is bx159322, genuinely different images.
	"""
	c = (media or {}).get('coverImage') or {}
	return c.get('extraLarge') or c.get('large') or None


def anilist_media_bulk(mal_ids):
	"""Fetch title AND cover art for up to 50 MAL ids in ONE request.

	Returns {mal_id: {'title': str|None, 'poster': str|None}}.

	LOCAL PATCH 2026-08-27: this is the old anilist_romaji_bulk widened to carry the
	cover image. It costs nothing extra -- the request was already being made to name
	the cours, and coverImage simply rides along in the same query.
	"""
	ids = []
	for m in (mal_ids or []):
		try: ids.append(int(m))
		except (TypeError, ValueError): continue
	if not ids: return {}
	ids = ids[:50]
	res = _post_anilist(_ROMAJI_BULK_QUERY, {'idMal_in': ids})
	out = {}
	for media in ((res.get('ANIME') or res.get('media') or []) if res else []):
		mid = media.get('idMal')
		title, poster = _pick_romaji(media), _pick_cover(media)
		if mid and (title or poster):
			try: out[int(mid)] = {'title': title, 'poster': poster}
			except (TypeError, ValueError): pass
	# Warm the per-id cache so subsequent single lookups are free.
	for mid, rec in out.items():
		try:
			lists_cache_object(lambda _d, _r=rec: dict(_r), 'anilist_romaji_%s' % mid, 1, expiration=_TITLE_CACHE_HOURS)
		except Exception: pass
	return out


def anilist_romaji_bulk(mal_ids):
	"""{mal_id: romaji}. Thin wrapper kept so existing callers are untouched."""
	return {mid: rec['title'] for mid, rec in (anilist_media_bulk(mal_ids) or {}).items()
			if rec.get('title')}


# LOCAL PATCH 2026-09-01: per-cour episode counts, for the Fribb flat-season repair in
# caches/fribb_mappings._anilist_boundaries. Fribb records no episode_offset for a show it
# labels one-cour-per-season, so when TMDb has flattened those cours into a single season
# the boundaries have to come from elsewhere. AniList knows each cour's length because each
# cour is its own AniList entry -- the same property _pick_cover relies on for cour art.
_EPISODES_BULK_QUERY = '''
query ($idMal_in: [Int]) {
	Page(page: 1, perPage: 50) {
		ANIME: media(idMal_in: $idMal_in, type: ANIME) {
			idMal
			episodes
		}
	}
}
'''

# A finished cour's episode count never changes. A still-airing one reports null and is
# simply absent from the result, so 7 days only governs how soon it is re-asked.
_EPISODE_COUNT_CACHE_HOURS = 168


def anilist_episode_counts(mal_ids):
	"""{mal_id: episode_count} for up to 50 MAL ids in ONE request.

	Ids AniList does not know, and cours it reports with `episodes: null` (still
	airing, final count not yet fixed), are ABSENT from the returned dict rather
	than present as zero -- callers must treat a missing id as unknown.
	"""
	ids = []
	for m in (mal_ids or []):
		try: ids.append(int(m))
		except (TypeError, ValueError): continue
	if not ids: return {}
	ids = sorted(set(ids))[:50]
	def _fetch(_dummy):
		res = _post_anilist(_EPISODES_BULK_QUERY, {'idMal_in': ids})
		# None is a failed request; {} then earns lists_cache_object's 0.3h TTL so a
		# blip is retried in ~18min instead of being cached for a week.
		if res is None: return {}
		out = {}
		for media in (res.get('ANIME') or res.get('media') or []):
			mid, eps = media.get('idMal'), media.get('episodes')
			if mid is None or eps is None: continue
			try: out[int(mid)] = int(eps)
			except (TypeError, ValueError): pass
		return out
	key = 'anilist_epcounts_%s' % '_'.join(str(i) for i in ids)
	result = lists_cache_object(_fetch, key, 1, expiration=_EPISODE_COUNT_CACHE_HOURS)
	# LOCAL PATCH 2026-09-04: normalise keys to int. _fetch builds {int mal_id: int count} and
	# the only caller (fribb_mappings._anilist_boundaries) looks up counts.get(int(mal_id)),
	# but JSON stringifies int dict keys -- so once lists_cache serialises as JSON a cached
	# row comes back keyed '41487' and every lookup misses. That would not raise: it returns
	# 0, which _anilist_boundaries reads as "unknown cour length" and abandons the whole
	# cour-split repair. Format-agnostic here rather than coerced in the cache layer, so
	# legacy repr rows with real int keys keep working too.
	if not isinstance(result, dict): return {}
	out = {}
	for k, v in result.items():
		try: out[int(k)] = v
		except (TypeError, ValueError): continue
	return out


# ═══════════════════════════════════════════════════════════════════════════
#  Authenticated surface (LOCAL PATCH 2026-08-29)
#
#  CORRECTED 2026-08-29: the first cut of this used the implicit grant
#  (response_type=token) on the theory that it avoided needing a client secret. AniList
#  does not support that grant. Probing the token endpoint settles it -- grant_type
#  implicit/token returns "unsupported_grant_type" (the grant is not offered at all) while
#  authorization_code / refresh_token return "invalid_client" (offered, credentials wrong).
#
#  So this is the Authorization Code (PIN) flow, which DOES require the client secret:
#    1. user registers a client with Redirect URL exactly https://anilist.co/api/v2/oauth/pin
#    2. authorize with response_type=code -> AniList displays a PIN (the auth code)
#    3. POST that code + client_id + client_secret to the token endpoint
#    4. back comes a ~1-year access_token plus a refresh_token
#
#  The 1-year life is why there is still no refresh loop here: a background task that fires
#  once a year is untestable dead code. The refresh token is stored anyway so re-auth can be
#  automated later, and a rejected token is logged loudly by _post_anilist instead of failing
#  silently. This is still far lighter than MAL, whose token expires every 31 days.
# ═══════════════════════════════════════════════════════════════════════════

_AUTHORIZE_URL = 'https://anilist.co/api/v2/oauth/authorize?client_id=%s&redirect_uri=%s&response_type=code'
_TOKEN_URL = 'https://anilist.co/api/v2/oauth/token'
_REDIRECT_URI = 'https://anilist.co/api/v2/oauth/pin'

_VIEWER_QUERY = '''
query {
	Viewer { id name }
}
'''

_LAST_ACTIVITY_QUERY = '''
query {
	Viewer {
		updatedAt
		statistics { anime { count } }
	}
}
'''


def _exchange_code(client_id, client_secret, code):
	"""Swap the PIN for a token. Returns the token dict or None."""
	try:
		r = session.post(_TOKEN_URL, json={
			'grant_type': 'authorization_code',
			'client_id': client_id,
			'client_secret': client_secret,
			'redirect_uri': _REDIRECT_URI,
			'code': code,
		}, headers={'Content-Type': 'application/json', 'Accept': 'application/json'}, timeout=20)
		data = r.json()
		if r.status_code != 200 or 'access_token' not in data:
			# Surface AniList's own wording -- 'invalid_client' means the id/secret pair is
			# wrong, 'invalid_grant' means the PIN was stale or already spent.
			logger('AniList: token exchange failed', '%s %s' % (r.status_code, str(data)[:200]))
			return None
		return data
	except Exception as e:
		logger('AniList: token exchange error', str(e))
		return None


def anilist_authenticate(dummy=''):
	"""Authorise against the user's own AniList client. Called from the settings Authorize row."""
	client_id, client_secret = _setting('client_id'), _setting('client_secret')
	if not client_id or not client_secret:
		ok_dialog('AniList Authorize',
			'[B]Step 1:[/B] Open [B]%s[/B] and create a new client.[CR]'
			'[B]Step 2:[/B] Set its [B]Redirect URL[/B] to exactly:[CR]'
			'   [COLOR gold]%s[/COLOR][CR]'
			'[B]Step 3:[/B] Press OK, then enter its Client ID and Client Secret.'
			% (_APP_REGISTER_URL, _REDIRECT_URI))
		if not client_id:
			client_id = kodi_dialog().input('AniList Client ID')
			if not client_id: return notification('AniList Authorize Cancelled - no Client ID', 4000)
			client_id = client_id.strip()
			set_setting('anilist.client_id', client_id)
		if not client_secret:
			client_secret = kodi_dialog().input('AniList Client Secret')
			if not client_secret: return notification('AniList Authorize Cancelled - no Client Secret', 4000)
			client_secret = client_secret.strip()
			set_setting('anilist.client_secret', client_secret)

	auth_url = _AUTHORIZE_URL % (client_id, _REDIRECT_URI)
	try:
		from modules.utils import copy2clip
		copy2clip(auth_url)
	except Exception: pass

	ok_dialog('AniList Authorize',
		'[B]Step 1:[/B] Open this URL in any browser (copied to your clipboard):[CR]'
		'   [COLOR gold]%s[/COLOR][CR]'
		'[B]Step 2:[/B] Approve access. AniList will show you a PIN code.[CR]'
		'[B]Step 3:[/B] Press OK below and enter that PIN.' % auth_url)

	code = kodi_dialog().input('Paste the AniList PIN')
	if not code: return notification('AniList Authorize Cancelled - no PIN', 4000)

	tokens = _exchange_code(client_id, client_secret, code.strip())
	if not tokens:
		return notification('AniList Authorize Failed - PIN rejected. Check the Client Secret and that the PIN is fresh.', 7000)
	set_setting('anilist.token', tokens['access_token'])
	if tokens.get('refresh_token'): set_setting('anilist.refresh', tokens['refresh_token'])
	if tokens.get('expires_in'):
		try: set_setting('anilist.expires', str(int(time.time()) + int(tokens['expires_in'])))
		except Exception: pass

	# Verify rather than trust the exchange -- confirms the token actually authenticates.
	viewer = (_post_anilist(_VIEWER_QUERY, {}, auth=True, node=None) or {}).get('Viewer') or {}
	if not viewer.get('id'):
		set_setting('anilist.token', 'empty_setting')
		return notification('AniList Authorize Failed - token did not authenticate.', 6000)

	set_setting('anilist.userid', str(viewer['id']))
	set_setting('anilist.user', viewer.get('name') or 'Authorized')
	notification('AniList Authorized as %s' % (viewer.get('name') or 'user'), 5000)
	return True


def anilist_revoke_authentication(dummy=''):
	for name in ('token', 'user', 'userid', 'last_activity', 'refresh', 'expires'):
		set_setting('anilist.%s' % name, 'empty_setting')
	_invalidate_lists()
	notification('AniList Authorization Revoked', 4000)
	return True


def anilist_last_activity():
	"""Composite change key for the sync monitor.

	updatedAt alone misses deletions -- removing an entry does not bump it -- so the anime
	count rides along, the same pairing Otaku uses.
	"""
	if not anilist_user_active(): return None
	viewer = (_post_anilist(_LAST_ACTIVITY_QUERY, {}, auth=True, node=None) or {}).get('Viewer') or {}
	if not viewer: return None
	count = ((viewer.get('statistics') or {}).get('anime') or {}).get('count', 0)
	return '%s_%s' % (viewer.get('updatedAt', ''), count)


# ═══════════════════════════════════════════════════════════════════════════
#  List mutations
#
#  AniList counts `progress` WITHIN the entry, which is cour-relative. Callers must pass
#  the AniList id and episode number that fribb_mappings.find_cour_by_tmdb_coords returns
#  for the TMDb coordinates -- NOT TMDb's own episode number. Frieren TMDb S01E30 is entry
#  182255 progress 2, not entry 154587 progress 30.
# ═══════════════════════════════════════════════════════════════════════════

_SAVE_PROGRESS_MUTATION = '''
mutation ($mediaId: Int, $progress: Int, $status: MediaListStatus) {
	SaveMediaListEntry (mediaId: $mediaId, progress: $progress, status: $status) {
		id progress status
	}
}
'''

_SAVE_STATUS_MUTATION = '''
mutation ($mediaId: Int, $status: MediaListStatus) {
	SaveMediaListEntry (mediaId: $mediaId, status: $status) { id status }
}
'''

_SAVE_SCORE_MUTATION = '''
mutation ($mediaId: Int, $score: Float) {
	SaveMediaListEntry (mediaId: $mediaId, score: $score) { id score }
}
'''

_DELETE_ENTRY_MUTATION = '''
mutation ($id: Int) {
	DeleteMediaListEntry (id: $id) { deleted }
}
'''

_EPISODE_COUNT_QUERY = '''
query ($id: Int) {
	Media (id: $id, type: ANIME) { id episodes }
}
'''

# Entry episode counts are immutable once a show has finished airing and only ever grow
# for one that hasn't, so cache them as long as the romaji titles beside them.
_EPISODE_COUNT_CACHE_HOURS = _TITLE_CACHE_HOURS


def anilist_episode_count(anilist_id):
	"""Total episodes in an AniList entry, or None. Cached long, unauthenticated."""
	try: anilist_id = int(anilist_id)
	except (TypeError, ValueError): return None
	def _fetch(_dummy):
		res = _post_anilist(_EPISODE_COUNT_QUERY, {'id': anilist_id}, node='Media')
		return {'episodes': (res or {}).get('episodes')}
	try:
		return (lists_cache_object(_fetch, 'anilist_epcount_%s' % anilist_id, 1,
									expiration=_EPISODE_COUNT_CACHE_HOURS) or {}).get('episodes')
	except Exception:
		return None


def _invalidate_lists():
	"""Drop cached watchlist pages after we change something. Without this the user's own
	edit would not show until AniListMonitor next notices Viewer.updatedAt moved."""
	try:
		from caches.anilist_cache import clear_anilist_lists_cache
		clear_anilist_lists_cache()
	except Exception: pass


def anilist_set_progress(anilist_id, progress, status=None):
	"""Set watched-episode count on an entry. Returns True on success.

	status=None picks it: COMPLETED once progress reaches the entry's episode count,
	CURRENT otherwise. An unknown count falls back to CURRENT -- understating progress is
	recoverable, marking a show complete early is not.
	"""
	if not anilist_user_active(): return False
	try:
		anilist_id, progress = int(anilist_id), int(progress)
	except (TypeError, ValueError): return False
	if progress < 0: return False
	if status is None:
		# LOCAL PATCH 2026-08-29: progress 0 is now reachable, for Mark Unwatched on a
		# season/cour row. It used to be rejected outright, which was right while the only
		# caller was the player -- a scrobble of 0 is meaningless. Deliberately PLANNING
		# rather than CURRENT: an entry with 0 watched episodes is not in progress, and
		# leaving it CURRENT would keep it in the "Watching" list forever.
		if progress == 0: status = 'PLANNING'
		else:
			total = anilist_episode_count(anilist_id)
			status = 'COMPLETED' if (total and progress >= int(total)) else 'CURRENT'
	res = _post_anilist(_SAVE_PROGRESS_MUTATION,
						{'mediaId': anilist_id, 'progress': progress, 'status': status},
						auth=True, node='SaveMediaListEntry')
	if res:
		logger('AniList progress', 'entry %s -> ep %s (%s)' % (anilist_id, progress, status))
		_invalidate_lists()
	return bool(res)


def anilist_set_status(anilist_id, status):
	"""status in CURRENT / PLANNING / COMPLETED / DROPPED / PAUSED / REPEATING."""
	if not anilist_user_active(): return False
	res = _post_anilist(_SAVE_STATUS_MUTATION, {'mediaId': int(anilist_id), 'status': status},
						auth=True, node='SaveMediaListEntry')
	if res: _invalidate_lists()
	return bool(res)


def anilist_set_score(anilist_id, score):
	if not anilist_user_active(): return False
	res = _post_anilist(_SAVE_SCORE_MUTATION, {'mediaId': int(anilist_id), 'score': float(score)},
						auth=True, node='SaveMediaListEntry')
	if res: _invalidate_lists()
	return bool(res)


def anilist_delete_entry(entry_id):
	"""Takes the LIST ENTRY id (from MediaList.id), not the media id."""
	if not anilist_user_active(): return False
	res = _post_anilist(_DELETE_ENTRY_MUTATION, {'id': int(entry_id)}, auth=True,
						node='DeleteMediaListEntry')
	if (res or {}).get('deleted'): _invalidate_lists()
	return bool((res or {}).get('deleted'))


# ═══════════════════════════════════════════════════════════════════════════
#  List reads
# ═══════════════════════════════════════════════════════════════════════════

_MEDIA_LIST_QUERY = '''
query ($userId: Int, $status: MediaListStatus) {
	MediaListCollection (userId: $userId, type: ANIME, status: $status) {
		lists {
			entries {
				id
				progress
				score
				media { %s }
			}
		}
	}
}
''' % _MEDIA_FIELDS

_STATUSES = ('CURRENT', 'PLANNING', 'COMPLETED', 'PAUSED', 'DROPPED', 'REPEATING')


def anilist_media_list(status):
	"""All entries for one list status. Returns [{'entry_id','progress','score', **media}].

	MediaListCollection is not paged the way the browse queries are -- it returns the whole
	list in one response, grouped into custom lists which are flattened here.
	"""
	if not anilist_user_active(): return []
	if status not in _STATUSES: return []
	user_id = _setting('userid')
	if not user_id: return []
	res = _post_anilist(_MEDIA_LIST_QUERY, {'userId': int(user_id), 'status': status},
						auth=True, node='MediaListCollection')
	out = []
	for group in ((res or {}).get('lists') or []):
		for entry in (group.get('entries') or []):
			media = entry.get('media') or {}
			if not media.get('id'): continue
			item = dict(media)
			item['entry_id'] = entry.get('id')
			item['progress'] = entry.get('progress')
			item['user_score'] = entry.get('score')
			out.append(item)
	return out


# ═══════════════════════════════════════════════════════════════════════════
#  Bulk / throttled surface (LOCAL PATCH 2026-08-29)
#
#  Only the backfill tool needs these. AniList's measured limit is 30 requests/minute
#  (X-RateLimit-Limit: 30 -- the long-running degraded rate, not the documented 90), so a
#  150-write backfill is a five-minute job that MUST pace itself. The interactive paths
#  above make one or two requests and are deliberately left unthrottled.
# ═══════════════════════════════════════════════════════════════════════════

_RATE_MIN_INTERVAL = 2.2      # seconds between writes: 30/min with headroom
_RATE_FLOOR = 3               # start waiting for the reset once remaining drops this low
_last_request_at = [0.0]
_MEDIA_LIST_ALL_QUERY = '''
query ($userId: Int) {
	MediaListCollection (userId: $userId, type: ANIME) {
		lists {
			entries { id mediaId progress status }
		}
	}
}
'''


def anilist_media_list_all():
	"""Every entry on the user's anime list in ONE request: {media_id: {...}}.

	Deliberately does not select _MEDIA_FIELDS -- the backfill only needs to know what is
	already there and how far, and pulling full media for a 1000-entry list would be a
	large response for no gain.
	"""
	if not anilist_user_active(): return {}
	user_id = _setting('userid')
	if not user_id: return {}
	res = _post_anilist(_MEDIA_LIST_ALL_QUERY, {'userId': int(user_id)}, auth=True,
						node='MediaListCollection')
	out = {}
	for group in ((res or {}).get('lists') or []):
		for entry in (group.get('entries') or []):
			try: mid = int(entry['mediaId'])
			except (KeyError, TypeError, ValueError): continue
			out[mid] = {'entry_id': entry.get('id'),
						'progress': entry.get('progress') or 0,
						'status': entry.get('status')}
	return out
_COVERS_BULK_QUERY = '''
query ($ids: [Int]) {
	Page(page: 1, perPage: 50) {
		media(id_in: $ids, type: ANIME) { id coverImage { extraLarge large } }
	}
}
'''


def anilist_covers_bulk(anilist_ids):
	"""{anilist_id: cover_url} for any number of ids, 50 per request.

	AniList art is per COUR, which is the whole point of using it: Fribb maps a TMDb show
	to one entry per cour and each has its own key visual, while TMDb carries a single
	show-level poster. Cached as long as the romaji titles beside it -- a cour's cover does
	not change -- so this is one request on first load and free thereafter.

	Reads and writes lists_cache directly rather than going through lists_cache_object: that
	helper caches whatever its callback returns, so a miss would store a null cover for the
	full 30 days instead of being retried.
	"""
	ids, out, missing = [], {}, []
	for a in (anilist_ids or []):
		try: a = int(a)
		except (TypeError, ValueError): continue
		if a not in ids: ids.append(a)
	for a in ids:
		cached = None
		try: cached = lists_cache.get('anilist_cover_%s' % a)
		except Exception: cached = None
		cover = (cached or {}).get('cover') if isinstance(cached, dict) else None
		if cover: out[a] = cover
		else: missing.append(a)
	for i in range(0, len(missing), 50):
		chunk = missing[i:i + 50]
		res = _post_anilist(_COVERS_BULK_QUERY, {'ids': chunk}, node='Page')
		for media in ((res or {}).get('media') or []):
			cover = _pick_cover(media)
			if not cover: continue
			try: mid = int(media['id'])
			except (KeyError, TypeError, ValueError): continue
			out[mid] = cover
			try: lists_cache.set('anilist_cover_%s' % mid, {'cover': cover}, expiration=_TITLE_CACHE_HOURS)
			except Exception: pass
		if i + 50 < len(missing): time.sleep(_RATE_MIN_INTERVAL)
	return out


# LOCAL PATCH 2026-08-29: pick the tags worth showing on a list row.
#
# Spoiler-flagged tags are dropped outright -- "Ending" or a named twist has no business on
# a browse row. The rest are ranked 0-100 by community vote and popular shows carry 30+, so
# only the top few survive or the row overflows any skin layout.
_TAG_LIMIT = 5


def anilist_tag_names(media, limit=_TAG_LIMIT):
	"""['Female Protagonist', 'Elf', ...] -- highest-ranked non-spoiler tags first."""
	try:
		tags = [t for t in (media.get('tags') or []) if t and not t.get('isMediaSpoiler') and t.get('name')]
		tags.sort(key=lambda t: t.get('rank') or 0, reverse=True)
		return [t['name'] for t in tags[:limit]]
	except Exception:
		return []
