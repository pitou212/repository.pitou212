# -*- coding: utf-8 -*-
"""IntroDB API client. Fetches intro/outro/recap segments by IMDb id + season + episode
(TV mode) or IMDb id alone (movie mode — theintrodb.org only).

Two upstream providers walked in priority order, per POV 6.06's port to Fen Light on
2026-07-09:

  1. api.introdb.app       — richer: gives intro start+end AND outro start+end.
                             This is what the autoplay-nextep timing precision patch
                             (Plan B, cc333cd) relies on for the alert-at-outro-END
                             transition. When it has data, we prefer it.
                             TV-EPISODE-ONLY (400 on movie queries).
  2. api.theintrodb.org/v3  — sparser: gives intro start+end but only outro START
                             (outro end_ms is typically null in this dataset).
                             Used ONLY as fallback when introdb.app returns 404/no
                             segments — better than nothing for the ~15-25% of shows
                             introdb.app doesn't cover. **Also supports movies**
                             (LOCAL PATCH 2026-08-05) — same response shape but
                             without season/episode params.

Return shape (unchanged from before the dual-provider change so callers stay stable):
  {segment_type: [(start_sec, end_sec_or_None), ...]}
segment_type ∈ {'intro', 'outro', 'recap'}. Recap is introdb.app-only — theintrodb.org
doesn't expose one. Cache stores merged result; MISS sentinel written only when BOTH
providers returned nothing (a single successful provider populates the cache regardless
of whether the other one had data).
"""
import json
import requests
from modules.kodi_utils import get_property, set_property, logger
from caches.settings_cache import get_setting

_INTRODB_APP = 'https://api.introdb.app/segments'
_INTRODB_ORG = 'https://api.theintrodb.org/v3/media'
_SEGMENT_KEYS = ('intro', 'outro', 'recap')
_CACHE_PROP_PREFIX = 'fenlight.introdb.cache.'
# How far apart two providers may place the same boundary and still count as agreeing.
# 5s is comfortably wider than the observed spread on segments that genuinely match
# (Ace of Diamond S01E43: 64 vs 63 start, 154 vs 154.6 end) and far tighter than the
# gap between a real segment and a wrong one.
_CORROBORATE_SECONDS = 5

# LOCAL PATCH 2026-08-27: provider 3, anime only. api.aniskip.com is the anime-specific
# equivalent of the two above, keyed on MAL id + the episode number WITHIN that MAL entry.
#
# The two IntroDB providers do cover a lot of anime and address it correctly -- they use
# the same TMDb-style numbering Fen Light passes, so Bleach's Thousand-Year Blood War is
# reachable as S02E01 (its IMDb S17E01 form is not, and is not used). The gap they have is
# coverage, not addressing: Re:ZERO S01E26/E50 and Saga of Tanya S01E01 return nothing from
# either, while AniSkip has Re:ZERO. So this is an extra source for the gaps, not a
# replacement -- see the ordering note in fetch_segments.
_ANISKIP = 'https://api.aniskip.com/v2/skip-times/%s/%s'

# User-toggleable, OFF by default: Settings > Playback > Skip Segments > 'Also use
# AniSkip (anime)'. With it off the two IntroDB providers behave exactly as they did
# before AniSkip existed, for anime and everything else alike.
def _aniskip_enabled():
	try: return get_setting('fenlight.skipsegment.aniskip') == 'true'
	except Exception: return False

# AniSkip skipType -> Fen Light segment type. The `mixed-*` forms are deliberately second
# choice: they describe an opening that runs UNDER episode content, which is a different
# and overlapping window from the plain one. Frieren episode 1 reports op 3-93 AND
# mixed-op 59-149; Re:ZERO episode 1 reports op 139-229 and mixed-op 181-251. Preferring
# the mixed window would seek the viewer past the start of the episode proper.
_ANISKIP_TYPES = (('intro', ('op', 'mixed-op')),
				('outro', ('ed', 'mixed-ed')),
				('recap', ('recap',)))


def _cache_key(imdb_id, season, episode):
	# LOCAL PATCH 2026-08-05: 'movie' sentinel for movie queries (season+episode both None).
	if season is None and episode is None:
		return '%s%s_movie' % (_CACHE_PROP_PREFIX, imdb_id)
	return '%s%s_%s_%s' % (_CACHE_PROP_PREFIX, imdb_id, season, episode)


# LOCAL PATCH 2026-08-26: per-type minimum durations, mirroring the guards the
# consumers already apply (player._check_skip_segments since the Red Light 1.6.7
# port, and player.info_next_ep since 2bfbc15). Validating HERE additionally lets
# the provider fallback do its job: a segment that is present but bogus used to
# block the second service, because the merge below only asked it for segment
# types that were entirely ABSENT. That is how a 5s "outro" from introdb.app
# suppressed theintrodb.org's data for the same episode.
_MIN_SEGMENT_SECONDS = {'intro': 15, 'outro': 15, 'recap': 8}


def _plausible(stype, segs):
	"""True when the segment list looks like real data. Duration-only -- this layer
	has no runtime, so checks relative to total_time stay with the consumers."""
	try:
		if not segs: return False
		start, end = segs[0][0], segs[0][1] if len(segs[0]) > 1 else None
		if start is None or start < 0: return False
		if end is None: return True          # open-ended (theintrodb.org credits) -- can't judge
		if end <= start: return False
		return (end - start) >= _MIN_SEGMENT_SECONDS.get(stype, 15)
	except Exception:
		return False


def _corroborated(a, b):
	"""True when two providers describe the same segment. Used only to decide whether an
	IntroDB segment may fill a type AniSkip omitted -- see the note in fetch_segments.
	An open end (theintrodb.org credits carry start_ms only) is judged on the start alone,
	since there is nothing on the other side to compare."""
	try:
		a0, b0 = a[0], b[0]
		if abs(a0[0] - b0[0]) > _CORROBORATE_SECONDS: return False
		a1 = a0[1] if len(a0) > 1 else None
		b1 = b0[1] if len(b0) > 1 else None
		if a1 is None or b1 is None: return True
		return abs(a1 - b1) <= _CORROBORATE_SECONDS
	except Exception:
		return False

def _fetch_introdb_app(params):
	"""Provider 1 (rich): api.introdb.app. Returns dict in canonical shape or {} on miss/error."""
	try:
		r = requests.get(_INTRODB_APP, params=params, timeout=8)
		if r.status_code == 404: return {}
		if r.status_code != 200:
			logger('IntroDB.app: non-200', '%s for %s' % (r.status_code, params))
			return {}
		data = r.json()
	except Exception as e:
		logger('IntroDB.app: fetch error', str(e))
		return {}
	out = {}
	for stype in _SEGMENT_KEYS:
		seg = data.get(stype)
		if not isinstance(seg, dict): continue
		try:
			start = seg.get('start_sec')
			end = seg.get('end_sec')
			if start is None: continue
			start = float(start)
			end = float(end) if end is not None else None
			out[stype] = [(start, end)]
		except: continue
	return out


def _fetch_aniskip(mal_id, episode):
	"""Provider 3 (anime): api.aniskip.com. Canonical shape, or {} on miss/error.

	episodeLength=0 asks AniSkip not to filter by recorded runtime -- with a real length it
	only returns entries submitted against that exact duration, which throws away good data
	when our runtime differs slightly from the submitter's.
	"""
	# LOCAL PATCH 2026-08-27: ask for the three PLAIN types only -- they never carry
	# anything unique. Across two samples a mixed-* type did not once appear without its
	# plain counterpart, and _ANISKIP_TYPES prefers the plain one anyway, so requesting
	# them only widens the response for nothing.
	#
	# The retry is the important part. AniSkip RATE LIMITS, and answers a burst with HTTP
	# 500 rather than 429: hammering it during testing made 4 of 5 episodes look like
	# misses, and the same four returned data after a 45s pause. Real playback asks about
	# one episode at a time so this should rarely bite, but a single retry costs nothing
	# and turns a transient limit into a hit.
	#
	# episodeLength MUST stay 0 -- a real runtime (tried 24 and 1440) returns HTTP 500.
	data = None
	for _attempt in (1, 2):
		try:
			r = requests.get(_ANISKIP % (mal_id, episode),
							params=[('types[]', t) for t in ('op', 'ed', 'recap')]
									+ [('episodeLength', '0')], timeout=8)
			# 404 is how AniSkip says "nothing submitted for this episode" -- a clean
			# miss, and unlike a 500 it will not change on a retry.
			if r.status_code == 404: return {}
			if r.status_code == 200:
				data = r.json()
				break
			if _attempt == 2:
				logger('AniSkip: non-200', '%s for mal=%s ep=%s' % (r.status_code, mal_id, episode))
		except Exception as e:
			if _attempt == 2: logger('AniSkip: fetch error', str(e))
	if data is None: return {}
	found = {}
	for item in (data.get('results') or []):
		try:
			iv = item.get('interval') or {}
			start, end = iv.get('startTime'), iv.get('endTime')
			if start is None: continue
			found[item.get('skipType')] = (float(start), float(end) if end is not None else None)
		except Exception: continue
	out = {}
	for stype, keys in _ANISKIP_TYPES:
		for k in keys:                     # plain type wins; see _ANISKIP_TYPES
			if k in found:
				out[stype] = [found[k]]
				break
	return out


def _fetch_theintrodb_org(params):
	"""Provider 2 (sparse fallback): api.theintrodb.org/v3. Returns dict in canonical
	shape or {} on miss/error. Handles ms→sec conversion and list-first extraction.
	Uses 'credits' response key which maps to Fen Light's 'outro' segment. Note that
	theintrodb.org's credits[0].end_ms is typically null — outro_end will be None in
	the returned tuple, which is fine (Plan B falls back to outro_start in that case)."""
	try:
		r = requests.get(_INTRODB_ORG, params=params, timeout=6)
		if r.status_code == 404: return {}
		if r.status_code != 200:
			logger('IntroDB.org: non-200', '%s for %s' % (r.status_code, params))
			return {}
		data = r.json()
	except Exception as e:
		logger('IntroDB.org: fetch error', str(e))
		return {}
	out = {}
	# intro
	try:
		intro_list = data.get('intro') or []
		if intro_list:
			seg = intro_list[0] or {}
			start_ms = seg.get('start_ms')
			end_ms = seg.get('end_ms')
			if start_ms is not None:
				start = float(start_ms) / 1000.0
				end = float(end_ms) / 1000.0 if end_ms is not None else None
				out['intro'] = [(start, end)]
	except: pass
	# credits (outro)
	try:
		credits_list = data.get('credits') or []
		if credits_list:
			seg = credits_list[0] or {}
			start_ms = seg.get('start_ms')
			end_ms = seg.get('end_ms')
			if start_ms is not None:
				start = float(start_ms) / 1000.0
				end = float(end_ms) / 1000.0 if end_ms is not None else None
				out['outro'] = [(start, end)]
	except: pass
	return out


def fetch_segments(imdb_id, season, episode, tmdb_id=None):
	"""Returns dict {segment_type: [(start_sec, end_sec_or_None), ...]} or empty dict on miss/error.
	imdb_id like 'tt0944947'.
	  - Episode mode: pass season + episode (both required, both ints).
	  - Movie mode:   pass season=None + episode=None. Only theintrodb.org is
	    queried (introdb.app is TV-only and 400s on movie queries).
	Walks introdb.app first (TV only), then theintrodb.org for missing segment types."""
	if not imdb_id: return {}
	imdb_id = str(imdb_id)
	if not imdb_id.startswith('tt'): return {}
	# LOCAL PATCH 2026-08-05: allow movie-mode (both season+episode None).
	is_movie = (season is None and episode is None)
	if not is_movie and (season is None or episode is None): return {}
	key = _cache_key(imdb_id, season, episode)
	cached = get_property(key)
	if cached:
		if cached == 'MISS': return {}
		try:
			return {k: [tuple(s) for s in v] for k, v in json.loads(cached).items()}
		except: pass
	if is_movie:
		# Movie: only theintrodb.org accepts the {imdb_id} shape.
		params = {'imdb_id': imdb_id}
		merged = _fetch_theintrodb_org(params)
		for stype in list(merged):   # LOCAL PATCH 2026-08-26
			if not _plausible(stype, merged[stype]):
				logger('IntroDB.org: implausible %s' % stype, '%s -> discarded' % (merged[stype],))
				del merged[stype]
	else:
		params = {'imdb_id': imdb_id, 'season': str(season), 'episode': str(episode)}
		# LOCAL PATCH 2026-08-27: anime goes to AniSkip first, then falls through the two
		# IntroDB providers below for whatever it did not supply. AniSkip is the anime-
		# specific authority and is keyed on the numbering anime actually uses, so where it
		# has data it is the better answer; where it has none the existing chain is unchanged.
		#
		# A Fribb hit IS the anime test -- the index contains only anime -- so regular TV does
		# no extra work beyond one offline dict lookup. It also hands back the two things
		# AniSkip needs: the MAL id, and cour_ep, the episode number WITHIN that MAL entry.
		# cour_ep is the important half: a cour-2 entry counts from 1 again, so passing TMDb's
		# episode number would ask AniSkip about a completely different episode.
		merged, aniskip_answered = {}, False
		if tmdb_id and _aniskip_enabled():
			try:
				from caches import fribb_mappings
				cour = fribb_mappings.find_cour_by_tmdb_coords(tmdb_id, season, episode) or {}
				mal_id, cour_ep = cour.get('mal'), cour.get('cour_ep')
				if mal_id and cour_ep is not None:
					merged = _fetch_aniskip(int(mal_id), int(cour_ep))
					for stype in list(merged):
						if not _plausible(stype, merged[stype]):
							logger('AniSkip: implausible %s' % stype, '%s -> discarded' % (merged[stype],))
							del merged[stype]
					if merged: logger('AniSkip segments', '%s for mal=%s ep=%s' % (list(merged), mal_id, cour_ep))
				aniskip_answered = bool(merged)
			except Exception as e:
				logger('AniSkip lookup error', str(e))
				merged = {}
		# LOCAL PATCH 2026-08-27, revised 2026-08-29: AniSkip owns every segment type it
		# answered -- the IntroDB providers never override one. For a type AniSkip OMITTED
		# it is treated as authoritative only when nothing corroborates the alternative:
		# IntroDB may fill the gap, but solely when BOTH providers report that type and
		# agree to within _CORROBORATE_SECONDS at each end.
		#
		# Two real episodes, each with an AniSkip ED and no OP, forced this shape. Submission
		# count does NOT separate them -- both intros are single-submission:
		#   Saga of Tanya S01E01  introdb.app 84-180, theintrodb.org has no intro at all
		#                         -> uncorroborated, rejected; that skip cut 96s of episode.
		#   Ace of Diamond S01E43 introdb.app 64-154, theintrodb.org 63-154.6
		#                         -> agree within ~1s, accepted; a real 90s opening.
		# Cross-provider agreement is the signal that tells the two apart.
		#
		# AniSkip having NOTHING for the episode is not an answer -- the full IntroDB chain
		# then runs exactly as it always did, single-provider segments included.
		if aniskip_answered:
			# Only an intro/outro gap is worth two extra requests. recap is absent from
			# nearly every source, so counting it here would drag the corroboration pair
			# onto every anime episode -- including the ideal case where AniSkip already
			# returned both an OP and an ED. It is still filled below, for free, whenever
			# something else opened the payloads.
			missing = [s for s in _SEGMENT_KEYS if s not in merged]
			if [s for s in missing if s != 'recap']:
				app_segs = _fetch_introdb_app(params) or {}
				org_segs = _fetch_theintrodb_org(params) or {}
				for stype in missing:
					a, b = app_segs.get(stype), org_segs.get(stype)
					if not a or not b:
						if a or b: logger('AniSkip gap %s' % stype, 'only one provider has it -> not corroborated, skipped')
						continue
					if not _corroborated(a, b):
						logger('AniSkip gap %s' % stype, '%s vs %s disagree -> skipped' % (a[0], b[0]))
						continue
					if _plausible(stype, a):
						merged[stype] = a
						logger('AniSkip gap %s' % stype, 'filled from IntroDB %s (corroborated by %s)' % (a[0], b[0]))
		else:
			# Provider 1 (rich).
			if not all(k in merged for k in ('intro', 'outro')):
				for stype, segs in (_fetch_introdb_app(params) or {}).items():
					if stype not in merged: merged[stype] = segs
			# LOCAL PATCH 2026-08-26: discard implausible segments BEFORE deciding whether to
			# consult provider 2, so bad data falls back instead of blocking the fallback.
			for stype in list(merged):
				if not _plausible(stype, merged[stype]):
					logger('IntroDB.app: implausible %s' % stype, '%s -> discarded, trying theintrodb.org' % (merged[stype],))
					del merged[stype]
			# Provider 2 (sparse fallback) — fires when introdb.app is missing a segment type
			# or had one rejected above. Its own segments are validated the same way.
			if not merged or not all(k in merged for k in ('intro', 'outro')):
				fallback = _fetch_theintrodb_org(params)
				for stype in _SEGMENT_KEYS:
					if stype in merged or stype not in fallback: continue
					if _plausible(stype, fallback[stype]): merged[stype] = fallback[stype]
					else: logger('IntroDB.org: implausible %s' % stype, '%s -> discarded' % (fallback[stype],))
	try:
		set_property(key, json.dumps(merged) if merged else 'MISS')
	except: pass
	return merged
