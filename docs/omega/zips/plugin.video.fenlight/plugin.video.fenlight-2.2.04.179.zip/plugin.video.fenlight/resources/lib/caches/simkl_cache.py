# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-07-29: SIMKL cache module — same-shape as mdblist_cache.py.
# KV blob table `simkl_data` + watched + progress + watched_status tables so
# SIMKL can be selected via watched_indicators == 3 the same way trakt (1) and
# mdblist (2) are.
from threading import Thread
from caches.base_cache import connect_database
from modules.kodi_utils import confirm_dialog


class SimklCache:
	def get(self, string):
		result = None
		try:
			dbcon = connect_database('simkl_db')
			cache_data = dbcon.execute('SELECT data FROM simkl_data WHERE id = ?', (string,)).fetchone()
			if cache_data: result = eval(cache_data[0])
		except: pass
		return result

	def set(self, string, data):
		try:
			dbcon = connect_database('simkl_db')
			dbcon.execute('INSERT OR REPLACE INTO simkl_data (id, data) VALUES (?, ?)', (string, repr(data)))
		except: return None

	def delete(self, string):
		try:
			dbcon = connect_database('simkl_db')
			dbcon.execute('DELETE FROM simkl_data WHERE id = ?', (string,))
		except: pass

	# Bulk setters — SIMKL sync writes into these via simkl_indicators_* helpers.
	# Signatures mirror TraktWatched / MDBLCache so watched_status dispatch stays uniform.
	def set_bulk_movie_watched(self, insert_list):
		if not insert_list: return
		self._delete('DELETE FROM watched WHERE db_type = ?', ('movie',))
		self._executemany('INSERT OR IGNORE INTO watched VALUES (?, ?, ?, ?, ?, ?)', insert_list)

	def set_bulk_tvshow_watched(self, insert_list):
		if not insert_list: return
		self._delete('DELETE FROM watched WHERE db_type = ?', ('episode',))
		self._executemany('INSERT OR IGNORE INTO watched VALUES (?, ?, ?, ?, ?, ?)', insert_list)

	def set_bulk_movie_progress(self, insert_list):
		if not insert_list: return
		self._delete('DELETE FROM progress WHERE db_type = ?', ('movie',))
		self._executemany('INSERT OR IGNORE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', insert_list)

	def set_bulk_tvshow_progress(self, insert_list):
		if not insert_list: return
		self._delete('DELETE FROM progress WHERE db_type = ?', ('episode',))
		self._executemany('INSERT OR IGNORE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', insert_list)

	def _executemany(self, command, insert_list):
		dbcon = connect_database('simkl_db')
		dbcon.executemany(command, insert_list)

	def _delete(self, command, args):
		dbcon = connect_database('simkl_db')
		dbcon.execute(command, args)


simkl_cache = SimklCache()


# ═══════════════════════════════════════════════════════════════════════════
#  List caching (per-list-type keyed) — populated by indexers/simkl_lists.py
#  Follows mdblist_cache.simkl_cache_object pattern.
# ═══════════════════════════════════════════════════════════════════════════

def simkl_cache_object(function, string, *args, expiration=None):
	"""Read-through cache for arbitrary SIMKL fetches. Same signature as
	trakt_cache.trakt_cache_object so callers stay uniform."""
	result = simkl_cache.get(string)
	if result is not None: return result
	result = function(*args)
	if result is not None:
		simkl_cache.set(string, result)
	return result


# ═══════════════════════════════════════════════════════════════════════════
#  Cache invalidation — called on write ops and by SIMKLMonitor when activity
#  timestamps change.
# ═══════════════════════════════════════════════════════════════════════════

def clear_simkl_list(list_type, status=None):
	"""Clear a single cached list. list_type in {movies, shows, anime}. status optional."""
	string = 'simkl_%s_%s' % (list_type, status) if status else 'simkl_%s' % list_type
	try:
		dbcon = connect_database('simkl_db')
		if status:
			dbcon.execute('DELETE FROM simkl_data WHERE id=?', (string,))
		else:
			dbcon.execute('DELETE FROM simkl_data WHERE id LIKE ?', ('simkl_%s_%%' % list_type,))
	except: pass


def clear_simkl_lists_cache():
	"""Nuke all cached lists — called by SIMKLMonitor when /sync/activities
	shows any timestamp change. Preserves watched/progress tables (those are
	rebuilt by the next indicators-sync)."""
	try:
		dbcon = connect_database('simkl_db')
		dbcon.execute('DELETE FROM simkl_data')
	except: pass


def clear_all_simkl_cache_data(silent=False, refresh=True):
	try:
		start = silent or confirm_dialog()
		if not start: return False
		dbcon = connect_database('simkl_db')
		for table in ('progress', 'watched', 'watched_status'):
			dbcon.execute('DELETE FROM %s' % table)
		dbcon.execute('DELETE FROM simkl_data')
		dbcon.execute('VACUUM')
		if refresh:
			from apis.simkl_api import simkl_sync_activities
			Thread(target=simkl_sync_activities).start()
		return True
	except: return False
