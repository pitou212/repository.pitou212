# -*- coding: utf-8 -*-
import xbmcaddon

class Magneto:
	@staticmethod
	def sootio(search_name):
		try:
			magneto_addon = xbmcaddon.Addon('script.module.magneto')
			magneto_path = magneto_addon.getAddonInfo('path')
			import sys
			import os
			magneto_lib_path = os.path.join(magneto_path, 'lib')
			if magneto_lib_path not in sys.path:
				sys.path.insert(0, magneto_lib_path)
			
			from magneto.providers.torrents.sootio import Sootio
			sootio = Sootio()
			results = sootio.sources()
			return results
		except Exception as e:
			from modules.kodi_utils import logger
			logger('Magneto sootio API error', str(e))
			return []
