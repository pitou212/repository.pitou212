# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-06: Fanart.tv integration for curated backdrops.
#
# Fanart.tv exposes a per-title JSON with typed image arrays. For AF3's fanart
# cycler we only need the background arrays:
#   Movies:  data['moviebackground'] -> [{id, url, lang, likes}, ...]
#   TV:      data['showbackground']  -> [{id, url, lang, likes}, ...]
# Cache 7 days (art rarely changes). Silently degrade to empty list on any
# error — callers merge with TMDb backdrops so a fanart.tv miss doesn't
# blank the cycler.
#
# Setup: user registers a free Personal API Key at
# https://fanart.tv/get-an-api-key/. Stored as `fenlight.fanarttv_api`.
# Rate limit: 30 req / 5 min for personal keys — the 7-day per-title cache
# keeps us well under that.

from caches.main_cache import cache_object
from caches.settings_cache import get_setting
from modules.kodi_utils import make_session, logger

_API_BASE = 'https://webservice.fanart.tv/v3'
_TIMEOUT = 10
_CACHE_HOURS = 168  # 7 days
_session = make_session(_API_BASE)


def _enabled():
	"""LOCAL PATCH 2026-08-07: master toggle — off skips fanart.tv even when key set."""
	return get_setting('fenlight.fanarttv.enabled', 'true') == 'true'


def _api_key():
	v = (get_setting('fenlight.fanarttv_api', '') or '').strip()
	return v if v and v != 'empty_setting' else ''


def _get_json(url):
	"""HTTP fetcher used by cache_object with json=True (unwraps .json())."""
	return _session.get(url, timeout=_TIMEOUT)


def _pick_backgrounds(payload, key, cap=8):
	"""Sort by likes desc, prefer language-neutral (00) then English (en),
	strip duplicates, return up to `cap` URLs.
	Fanart.tv `lang` values: '00' = no language / clean, 'en'/'fr'/… = with text."""
	if not isinstance(payload, dict): return []
	items = payload.get(key) or []
	if not items: return []
	def _rank(item):
		lang = (item.get('lang') or '').lower()
		lang_score = 0 if lang == '00' else (1 if lang in ('', 'en') else 2)
		try: likes = int(item.get('likes') or 0)
		except (TypeError, ValueError): likes = 0
		return (lang_score, -likes)
	ordered = sorted(items, key=_rank)
	out, seen = [], set()
	for it in ordered:
		u = it.get('url')
		if not u or u in seen: continue
		seen.add(u)
		out.append(u)
		if len(out) >= cap: break
	return out


def fanart_movie_backgrounds(imdb_id, cap=8):
	"""Return up to `cap` fanart.tv `moviebackground` URLs for the given IMDb id.
	Silent on any failure (no key / HTTP error / no coverage) — returns []."""
	if not _enabled() or not _api_key(): return []
	if not imdb_id or not str(imdb_id).startswith('tt'): return []
	try:
		url = '%s/movies/%s?api_key=%s' % (_API_BASE, imdb_id, _api_key())
		cache_key = 'fanart_movie_%s' % imdb_id
		data = cache_object(_get_json, cache_key, url, expiration=_CACHE_HOURS)
		return _pick_backgrounds(data, 'moviebackground', cap)
	except Exception as e:
		logger('fanart.tv', 'movie fetch failed %s: %s' % (imdb_id, str(e)[:120]))
		return []


def fanart_tvshow_backgrounds(tvdb_id, cap=8):
	"""Return up to `cap` fanart.tv `showbackground` URLs for the given TVDB id.
	Silent on any failure — returns []."""
	if not _enabled() or not _api_key(): return []
	if not tvdb_id or str(tvdb_id) in ('', 'None', '0'): return []
	try:
		url = '%s/tv/%s?api_key=%s' % (_API_BASE, tvdb_id, _api_key())
		cache_key = 'fanart_tvshow_%s' % tvdb_id
		data = cache_object(_get_json, cache_key, url, expiration=_CACHE_HOURS)
		return _pick_backgrounds(data, 'showbackground', cap)
	except Exception as e:
		logger('fanart.tv', 'tv fetch failed %s: %s' % (tvdb_id, str(e)[:120]))
		return []


# LOCAL PATCH 2026-08-27: clearlogos from fanart.tv, preferred over TMDb's.
#
# Fen Light took its clearlogo from TMDb's images.logos[0] -- literally the first entry,
# with no ranking. fanart.tv's logos are community-curated with language tags and vote
# counts, are reliably transparent PNGs, and exist for titles TMDb has none for. Frieren
# alone has 9 hdtvlogo entries there.
#
# Free: the payload is already fetched and cached (7 days) for the fanart cycler under the
# same cache key, so asking it for a logo is a cache hit rather than a request.

# Highest-resolution array first. `clearlogo`/`movielogo` are the older, smaller uploads
# and are only reached when no HD one exists.
_TV_LOGO_KEYS = ('hdtvlogo', 'clearlogo')
_MOVIE_LOGO_KEYS = ('hdmovielogo', 'movielogo')


def _pick_logo(payload, keys, lang='en'):
	"""Best single logo URL, or ''.

	Ranking differs from _pick_backgrounds on purpose. A background is best when it is
	textless, so that function puts lang '00' first. A clearlogo IS the title as artwork,
	so the wanted language comes first and '00' is only a fallback; within a language the
	most-liked wins.
	"""
	if not isinstance(payload, dict): return ''
	def _rank(item):
		l = (item.get('lang') or '').lower()
		lang_score = 0 if l == lang else (1 if l in ('', '00') else 2)
		try: likes = int(item.get('likes') or 0)
		except (TypeError, ValueError): likes = 0
		return (lang_score, -likes)
	for key in keys:
		items = [i for i in (payload.get(key) or []) if isinstance(i, dict) and i.get('url')]
		if items: return sorted(items, key=_rank)[0]['url']
	return ''


def fanart_tvshow_clearlogo(tvdb_id):
	"""fanart.tv clearlogo URL for a TVDB id, or '' when unavailable."""
	if not _enabled() or not _api_key(): return ''
	if not tvdb_id or str(tvdb_id) in ('', 'None', '0'): return ''
	try:
		url = '%s/tv/%s?api_key=%s' % (_API_BASE, tvdb_id, _api_key())
		data = cache_object(_get_json, 'fanart_tvshow_%s' % tvdb_id, url, expiration=_CACHE_HOURS)
		return _pick_logo(data, _TV_LOGO_KEYS)
	except Exception as e:
		logger('fanart.tv', 'tv logo failed %s: %s' % (tvdb_id, str(e)[:120]))
		return ''


def fanart_movie_clearlogo(imdb_id):
	"""fanart.tv clearlogo URL for an IMDb id, or '' when unavailable."""
	if not _enabled() or not _api_key(): return ''
	if not imdb_id or not str(imdb_id).startswith('tt'): return ''
	try:
		url = '%s/movies/%s?api_key=%s' % (_API_BASE, imdb_id, _api_key())
		data = cache_object(_get_json, 'fanart_movie_%s' % imdb_id, url, expiration=_CACHE_HOURS)
		return _pick_logo(data, _MOVIE_LOGO_KEYS)
	except Exception as e:
		logger('fanart.tv', 'movie logo failed %s: %s' % (imdb_id, str(e)[:120]))
		return ''
