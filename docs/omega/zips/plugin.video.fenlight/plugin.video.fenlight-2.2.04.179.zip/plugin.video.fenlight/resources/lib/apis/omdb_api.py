# -*- coding: utf-8 -*-
from xml.dom.minidom import parseString as mdParse
from caches.meta_cache import meta_cache
from modules.metadata import movie_expiry, tvshow_expiry
from modules.utils import get_datetime, get_current_timestamp
from modules.kodi_utils import make_session, get_property, set_property, logger
import time as _time

# LOCAL PATCH 2026-08-26: https (the api key travelled in a cleartext query string).
session = make_session('https://www.omdbapi.com/')

# LOCAL PATCH 2026-08-26 (perf): remember a dead key instead of re-paying for it.
# get_result() used to funnel every failure through `except: return None`, so a 401
# looked identical to "this title has no ratings" and nothing recorded that the KEY
# was the problem. With the free tier at 1000 req/day -- one cold rebuild of a
# ~1250-item library exhausts it -- every subsequent cold item then spent ~700ms on a
# call that could not succeed. Measured: 52% of cached metas carry no extra_ratings,
# and a 6-widget cold home (120 items) wasted ~5.5s on 401s.
#
# OMDb returns HTTP 401 for BOTH key-level failures ("Request limit reached!",
# "Invalid API key!") and 200 for a per-title miss, so the status code is the
# discriminator; the text match is belt and braces. A title-level miss must NOT trip
# the cooldown -- it only means that one title has no data.
#
# Stored in a window property, not module state: reuselanguageinvoker=false wipes
# module globals every plugin invocation (same reason tmdb_api_host uses one).
_COOLDOWN_PROP = 'fenlight.omdb_cooldown_until'
_KEY_ERRORS = ('request limit', 'invalid api key')


def _cooldown_seconds():
	"""Until the next UTC midnight, when OMDb's daily quota resets. Capped at 12h and
	floored at 5min so a transient blip cannot disable ratings for long."""
	try:
		now = _time.time()
		midnight = (int(now // 86400) + 1) * 86400
		return max(300, min(int(midnight - now) + 60, 43200))
	except Exception:
		return 3600


def omdb_on_cooldown():
	"""True while the key is known-dead. Checked by metadata._fetch_omdb_for_meta so a
	cold meta build skips the request entirely."""
	try:
		until = get_property(_COOLDOWN_PROP)
		return bool(until) and _time.time() < float(until)
	except Exception:
		return False


def _start_cooldown(reason):
	try:
		secs = _cooldown_seconds()
		set_property(_COOLDOWN_PROP, str(_time.time() + secs))
		logger('OMDb', 'key unusable (%s) - skipping OMDb for %d min' % (reason, secs // 60))
	except Exception: pass

class OMDbAPI:
	def fetch_info(self, meta, api_key):
		imdb_id = meta.get('imdb_id')
		if not imdb_id or not api_key: return {}
		self.api_key = api_key
		data = self.process_result(imdb_id, meta)
		return data

	def process_result(self, imdb_id, meta):
		data = {}
		self.result = self.get_result(imdb_id)
		if not self.result: return {}
		self.result_get = self.result.get
		metascore_rating, tomatometer_rating, tomatousermeter_rating = self.process_rating('metascore'), self.process_rating('tomatoMeter'), self.process_rating('tomatoUserMeter')
		imdb_rating, tomato_image = self.process_rating('imdbRating'), self.process_rating('tomatoImage')
		if tomato_image: tomatometer_icon = 'rtcertified.png' if tomato_image == 'certified' else 'rtfresh.png' if tomato_image == 'fresh' else 'rtrotten.png'
		elif tomatometer_rating: tomatometer_icon = 'rtfresh.png' if int(tomatometer_rating) > 59 else 'rtrotten.png'
		else: tomatometer_icon = 'rtrotten.png'
		if tomatousermeter_rating: tomatousermeter_icon = 'popcorn.png' if int(tomatousermeter_rating) > 59 else 'popcorn_spilt.png'
		else: tomatousermeter_icon = 'popcorn_spilt.png'		
		data = {
				'metascore': {'rating': '%s%%' %  metascore_rating, 'icon': 'metacritic.png'},
				'tomatometer': {'rating': '%s%%' % tomatometer_rating, 'icon': tomatometer_icon},
				'tomatousermeter': {'rating': '%s%%' % tomatousermeter_rating, 'icon': tomatousermeter_icon},
				'imdb': {'rating': imdb_rating, 'icon': 'imdb.png'},
				'tmdb': {'rating': str(round(meta.get('rating'), 1)) if meta.get('rating') not in (0, 0.0, None) else '', 'icon': 'tmdb.png'},
				}
		media_type = meta.get('mediatype')
		expiry_function = movie_expiry if media_type == 'movie' else tvshow_expiry
		meta['extra_ratings'] = data
		meta_cache.set(media_type, 'tmdb_id', meta, expiry_function(get_datetime(), meta), get_current_timestamp())
		return data

	def get_result(self, imdb_id):
		try:
			response = session.get('https://www.omdbapi.com/?apikey=%s&i=%s&tomatoes=True&r=xml' % (self.api_key, imdb_id), timeout=20)
			result = response.text
			# Key-level failure: stop asking until the quota resets. 401 covers both
			# "Request limit reached!" and "Invalid API key!"; a per-title miss is a 200.
			if response.status_code == 401 or any(e in result.lower() for e in _KEY_ERRORS):
				_start_cooldown('HTTP %s' % response.status_code)
				return None
			response_test = dict(mdParse(result).getElementsByTagName('root')[0].attributes.items())
			if not response_test.get('response', 'False') == 'True': return None
			return dict(mdParse(result).getElementsByTagName('movie')[0].attributes.items())
		except: return None

	def process_rating(self, rating_name):
		return self.result_get(rating_name, '').replace('N/A', '')

fetch_ratings_info = OMDbAPI().fetch_info
