# -*- coding: utf-8 -*-
import time
from modules.kodi_utils import addon_fanart
from windows.base_window import BaseDialog
from modules.settings import avoid_episode_spoilers
# from modules.kodi_utils import logger

class NextEpisode(BaseDialog):
	episode_status_dict = {
	'season_premiere': ('Season Premiere', 'b30385b5'),
	'mid_season_premiere': ('Mid-Season Premiere', 'b385b503'),
	'series_finale': ('Series Finale', 'b38503b5'),
	'season_finale': ('Season Finale', 'b3b50385'),
	'mid_season_finale': ('Mid-Season Finale', 'b3b58503'),
	'':  (None, None)}
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.closed = False
		self.meta = kwargs.get('meta')
		self.selected = kwargs.get('default_action', 'cancel')
		# LOCAL PATCH 2026-08-25: chapters_detected was threaded here and never read.
		# countdown_mode ('fixed' | 'to_end') replaces it and actually drives monitor().
		self.countdown_mode = kwargs.get('countdown_mode', 'fixed')
		self.total_time = kwargs.get('total_time') or 0
		self.set_properties()

	def onInit(self):
		self.setFocusId(11)
		self.monitor()

	def run(self):
		self.doModal()
		self.clearProperties()
		self.clear_modals()
		return self.selected

	def onAction(self, action):
		if action in self.closing_actions:
			self.selected = 'cancel'
			self.closed = True
			self.close()

	def onClick(self, controlID):
		self.selected = {10: 'close', 11: 'play', 12: 'cancel'}[controlID]
		self.closed = True
		self.close()

	def set_properties(self):
		self.setProperty('mode', 'next_episode')
		self.setProperty('thumb', self.get_thumb())
		self.setProperty('clearlogo', self.meta.get('clearlogo', ''))
		self.setProperty('episode_label', '%s[B] | [/B]%02dx%02d[B] | [/B]%s' % (self.meta['title'], self.meta['season'], self.meta['episode'], self.meta['ep_name']))
		status_label, status_highlight = self.episode_status_dict[self.meta.get('episode_type', '')]
		if status_label:
			self.setProperty('episode_status.label', status_label)
			self.setProperty('episode_status.highlight', status_highlight)

	def get_thumb(self):
		if avoid_episode_spoilers() and int(self.meta.get('playcount', '0')) == 0: thumb = self.meta.get('fanart', '') or addon_fanart()
		else: thumb = self.meta.get('ep_thumb', None) or self.meta.get('fanart', '') or addon_fanart()
		return thumb

	def monitor(self):
		# LOCAL PATCH 2026-08-25: rebuilt around the timing tier chosen in
		# player.info_next_ep() and handed over as `countdown_mode`.
		#
		#   'fixed'  (HIGH confidence -- IntroDB outro / final chapter)
		#            The alert opened exactly when the credits started, so counting a
		#            short fixed interval into them and autoplaying is correct.
		#   'to_end' (LOW confidence -- percentage fallback)
		#            The alert point is arbitrary (5% of runtime, ~135s on a 45-min
		#            episode). Counting a fixed 10s from there used to autoplay ~125s
		#            of real episode early. Instead track the true remaining time and
		#            only fire when the video actually ends.
		#
		# Both modes are bounded by playback, replacing the old "modal timer, not a
		# playback observer" behaviour that let the countdown outlive the video and
		# keep ticking on top of Home.
		from caches.settings_cache import get_setting
		from modules.player import PLAYBACK_STOPPED_PROP
		from modules.kodi_utils import get_property
		try: countdown_duration = int(get_setting('fenlight.autoplay_alert_countdown_sec', '10') or '10')
		except: countdown_duration = 10
		countdown_start = time.time()
		try: total_time = self.total_time or self.player.getTotalTime()
		except: total_time = 0
		mode = self.countdown_mode
		# Was playback live when the alert opened? Separates "user pressed Stop" from
		# "alert opened after playback had already ended" (the outro-skip race that
		# 2026-07-22 deliberately keeps the alert for).
		try: playing_at_open = self.player.isPlaying()
		except: playing_at_open = False
		STOP_EPSILON = 5    # seconds; at or under this, "not playing" reads as a natural end
		playback_ended_at = None
		last_remaining = None
		while True:
			if self.closed: break
			try: playing = self.player.isPlaying()
			except: playing = False
			if playing:
				try:
					last_remaining = max(0, round(total_time - self.player.getTime()))
				except: pass
			remaining = last_remaining
			# --- dismissal on user stop -------------------------------------------
			# Position-based and therefore instant. PLAYBACK_STOPPED_PROP is
			# authoritative but Kodi sets it ~2.5s after isPlaying() flips, which loses
			# the race against a 10s countdown -- that is why the alert used to linger
			# on Home and then autoplay anyway. Property kept as a secondary signal.
			if playing_at_open and not playing:
				stopped_early = remaining is not None and remaining > STOP_EPSILON
				if stopped_early or get_property(PLAYBACK_STOPPED_PROP) == 'true':
					self.selected = 'cancel'
					self.closed = True
					self.close()
					break
			elif get_property(PLAYBACK_STOPPED_PROP) == 'true':
				# Alert opened with playback already over, and a stop verdict landed
				# late -- it was a user stop after all.
				self.selected = 'cancel'
				self.closed = True
				self.close()
				break
			# --- fire condition ----------------------------------------------------
			if mode == 'to_end':
				if playing:
					if remaining is not None and remaining <= 1:
						self.closed = True; self.close(); break
					# Above a minute leave `countdown` empty: the skin then renders its
					# Player.TimeRemaining() label, which is already live and M:SS
					# formatted. The countdown label hard-codes an "s" suffix, so only
					# feed it plain seconds.
					try:
						if remaining is not None and remaining <= 60: self.setProperty('countdown', str(int(remaining)))
						else: self.clearProperty('countdown')
					except: pass
				else:
					# Playback ended before we reached the end mark -- short grace so the
					# alert is still readable, then fire.
					if playback_ended_at is None: playback_ended_at = time.time()
					elapsed_since_end = time.time() - playback_ended_at
					try: self.setProperty('countdown', str(max(0, countdown_duration - int(elapsed_since_end))))
					except: pass
					if elapsed_since_end >= countdown_duration:
						self.closed = True; self.close(); break
			else:
				elapsed = time.time() - countdown_start
				try: self.setProperty('countdown', str(max(0, countdown_duration - int(elapsed))))
				except: pass
				if elapsed >= countdown_duration:
					self.closed = True; self.close(); break
				# Bounded by playback: if the video ends first, fire now instead of
				# continuing to tick over Home.
				if playing_at_open and not playing:
					self.closed = True; self.close(); break
			# --- pause handling (unchanged) ----------------------------------------
			if playing and self.selected == 'pause' and remaining is not None and remaining <= 10:
				self.player.pause()
				self.sleep(500)
				break
			self.sleep(500)
		if self.selected == 'pause':
			start_time = time.time()
			end_time = start_time + 900
			current_time = start_time
			while current_time <= end_time and self.selected == 'pause':
				try:
					current_time = time.time()
					pause_timer = time.strftime('%M:%S', time.gmtime(max(end_time - current_time, 0)))
					self.setProperty('pause_timer', pause_timer)
					self.sleep(1000)
				except: break
			if self.selected != 'cancel': self.player.pause()
		self.close()

class StillWatching(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.closed = False
		self.selected = False
		self.meta = kwargs.get('meta')
		self.check_text = kwargs.get('check_text')
		self.set_properties()

	def onInit(self):
		self.setFocusId(10)
		self.monitor()

	def run(self):
		self.doModal()
		self.clearProperties()
		self.clear_modals()
		return self.selected

	def onAction(self, action):
		if action in self.closing_actions:
			self.selected = 'no'
			self.closed = True
			self.close()

	def onClick(self, controlID):
		self.selected = {10: True, 11: False}[controlID]
		self.closed = True
		self.close()

	def set_properties(self):
		landscape, fanart, clearlogo = self.meta.get('landscape', ''), self.meta.get('fanart', ''), self.meta.get('clearlogo', '')
		self.setProperty('mode', 'still_watching')
		self.setProperty('thumb', landscape or fanart)
		if not landscape: self.setProperty('clearlogo', clearlogo)
		self.setProperty('episode_label', self.check_text % self.meta['title'])

	def monitor(self):
		pause_timer = 10
		while self.player.isPlaying():
			self.setProperty('pause_timer', '%02d %s' % (pause_timer, 'seconds' if pause_timer > 1 else 'second'))
			self.sleep(1000)
			if self.closed: break
			if pause_timer == 0: break
			pause_timer -= 1
		self.close()

class StingersNotification(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.stinger_dict = {'duringcreditsstinger': {'id': 200, 'property': 'color_during'}, 'aftercreditsstinger': {'id': 201, 'property': 'color_after'}}
		self.closed = False
		self.meta = kwargs.get('meta')
		self.stingers = self.meta.get('stinger_keys')
		self.set_properties()

	def onInit(self):
		self.make_stingers()
		self.monitor()

	def run(self):
		self.doModal()
		self.clearProperties()
		self.clear_modals()

	def onAction(self, action):
		if action in self.closing_actions:
			self.closed = True
			self.close()

	def make_stingers(self):
		for k, v in self.stinger_dict.items():
			if k in self.stingers:
				self.setProperty(v['property'], 'green')
				self.set_image(v['id'], 'fenlight_common/overlay_selected.png')
			else:
				self.setProperty(v['property'], 'red')
				self.set_image(v['id'], 'fenlight_common/cross.png')

	def set_properties(self):
		self.setProperty('mode', 'stinger')
		self.setProperty('thumb', self.meta.get('fanart', '')) or addon_fanart()
		self.setProperty('clearlogo', self.meta.get('clearlogo', ''))

	def monitor(self):
		total_time = 10000
		while self.player.isPlaying() and total_time > 0:
			if self.closed: break
			self.sleep(1000)
			total_time -= 1000
		self.close()