# -*- coding: utf-8 -*-
"""YouTube trailer search — LAST-RESORT fallback for season trailers.

LOCAL PATCH 2026-08-26.

TMDb covers only ~57% of seasons (measured over 56 seasons / 14 shows), and IMDb
was evaluated and rejected (see the plan: signed URLs expire in ~1.2 days, the
season lives only in the video's name, one extra call per show). YouTube fills
the rest, but with an important caveat that shapes this whole module:

  **YouTube search never returns nothing.** TMDb lacks a season trailer precisely
  when no clean official one exists, so the gap population is adversarial. Probing
  9 real TMDb-gap seasons returned 9 results, of which several were fan reuploads
  and one -- Code Geass "season 2" -- was an unrelated MOVIE trailer.

So the job here is not "find a video", it is "refuse anything that isn't clearly
the right trailer". _acceptable() below is deliberately strict; returning '' and
falling back to the show trailer beats confidently playing the wrong thing.

Two further design notes:
  * Searches happen ONLY when the user presses play (router mode
    'resolve_yt_trailer'), never while browsing. A search costs ~740KB / ~0.7s;
    doing that per season during list building is what made anime catalogs slow.
  * The official Data API is not usable: search.list costs 100 of a 10,000/day
    quota (~100 searches/day), and the addon's bundled Google key has the API
    blocked outright (403). The keyless InnerTube endpoint below has no quota.
    Video ids are permanently stable, so a hit is cached indefinitely.
"""
import re
from caches.meta_cache import meta_cache
from modules.kodi_utils import make_session
# from modules.kodi_utils import logger

_INNERTUBE_URL = 'https://www.youtube.com/youtubei/v1/search'
# Public InnerTube web key -- shipped in youtube.com's own page source, not a secret
# and not tied to any account. Carries no quota.
_INNERTUBE_KEY = 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8'
# params=EgIQAQ%3D%3D is YouTube's "Type: Video" search filter (excludes channels,
# playlists and shelves, which otherwise pollute the first results).
_TYPE_VIDEO = 'EgIQAQ%3D%3D'
_CLIENT = {'clientName': 'WEB', 'clientVersion': '2.20240101.00.00', 'hl': 'en', 'gl': 'US'}
_HEADERS = {
	'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
	'Accept-Language': 'en-US,en;q=0.9', 'Content-Type': 'application/json'}
_YOUTUBE_PLAY_URL = 'plugin://plugin.video.youtube/play/?video_id=%s'

session = make_session('https://www.youtube.com')

# Titles containing any of these are commentary/derivative, never the trailer itself.
_BANNED = ('reaction', 'react', 'review', 'breakdown', 'explained', 'recap', 'analysis',
			'theory', 'ranking', 'ranked', 'top 10', 'easter egg', 'behind the scenes',
			'making of', 'bloopers', 'gag reel', 'interview', 'concept', 'fan made',
			'fanmade', 'fan-made', 'ai trailer', 'what if', 'parody', 'edit', 'amv',
			'first look at', 'everything you need', 'ending explained')
_MUST_HAVE = ('trailer', 'teaser')
# Mirrors modules/metadata._SUB_HINTS -- prefer an intelligible trailer over a raw one.
_SUB_HINTS = ('subtitled', 'subbed', 'eng sub', 'english sub', 'with subtitles')
_ENG_HINTS = ('english trailer', 'english dub', 'dub trailer', 'english')


def _norm(text):
	return re.sub(r'[^a-z0-9 ]+', ' ', (text or '').lower())


def _season_ok(title_l, season):
	"""The season marker is MANDATORY. Without it a franchise movie or an adjacent
	season wins the search -- verified failures: Code Geass "S2" returned the
	Re;surrection movie, and unmarked season-1 queries returned the 2018 Paramount
	movie for "Overlord" and the "Immortal Man" film for "Peaky Blinders"."""
	if not season: return False
	s = int(season)
	patterns = (r'season\s*0*%d\b' % s, r'\bs0*%d\b' % s, r'\bpart\s*0*%d\b' % s,
				r'\b%d(?:st|nd|rd|th)\s+season\b' % s, r'series\s*0*%d\b' % s)
	return any(re.search(p, title_l) for p in patterns)


def _acceptable(video_title, show_title, season):
	"""Strict gate. Everything must line up or we return nothing at all."""
	title_l = _norm(video_title)
	if not any(w in title_l for w in _MUST_HAVE): return False
	if any(b in title_l for b in _BANNED): return False
	if not _season_ok(title_l, season): return False
	# The show's name must actually appear -- guards against a same-franchise
	# spin-off or an unrelated title outranking the real one.
	show_words = [w for w in _norm(show_title).split() if len(w) > 2]
	if show_words:
		matched = sum(1 for w in show_words if w in title_l)
		if matched < max(1, int(len(show_words) * 0.6)): return False
	return True


def _search(query):
	"""InnerTube search -> [(video_id, title, channel)]. Empty list on any failure."""
	body = {'context': {'client': _CLIENT}, 'query': query, 'params': _TYPE_VIDEO}
	try:
		r = session.post(_INNERTUBE_URL, params={'key': _INNERTUBE_KEY}, headers=_HEADERS, json=body, timeout=12)
		if r.status_code != 200: return []
		data = r.json()
	except Exception:
		return []
	out = []
	def walk(node):
		if len(out) >= 12: return
		if isinstance(node, dict):
			vr = node.get('videoRenderer')
			if vr:
				try:
					title = ''.join(x.get('text', '') for x in ((vr.get('title') or {}).get('runs') or []))
					channel = (((vr.get('ownerText') or {}).get('runs') or [{}])[0]).get('text', '')
					if vr.get('videoId'): out.append((vr['videoId'], title, channel))
				except Exception: pass
			for v in node.values(): walk(v)
		elif isinstance(node, list):
			for v in node: walk(v)
	try: walk(data)
	except Exception: pass
	return out


def find_season_trailer(show_title, season, year=None):
	"""Playable URL for this season's trailer, or '' when nothing passes the filter.

	Cached indefinitely by (title, season): YouTube video ids never change, and a
	negative result is cached too (24h) so a miss doesn't re-search on every press."""
	if not show_title: return ''
	try: season_no = int(season)
	except (TypeError, ValueError): season_no = 0
	# Season 1 is deliberately NOT searched. TMDb's show-level trailer already IS the
	# season 1 trailer, so there is no gap to fill -- and an unmarked "<show> official
	# trailer" query is exactly where same-name films slip through (Overlord 2018,
	# Peaky Blinders: The Immortal Man). Seasons 2+ carry a marker we can verify.
	if season_no < 2: return ''
	cache_key = 'yt_season_trailer_%s_%s' % (re.sub(r'\W+', '_', show_title.lower())[:60], season_no)
	try:
		cached = meta_cache.get_function(cache_key)
		if cached: return '' if cached.get('miss') else (cached.get('url') or '')
	except Exception: pass

	query = '%s Season %d official trailer' % (show_title, season_no)
	# Collect every acceptable hit, then prefer a subtitled/English one. Anime search
	# results routinely include a raw Japanese trailer above the subbed upload, and
	# taking the first hit would grab it. Falls back to the top hit when unmarked.
	accepted = [(vid, t) for vid, t, _ch in _search(query) if _acceptable(t, show_title, season_no)]
	url = ''
	if accepted:
		def _marked(hints):
			return next((v for v, t in accepted if any(h in t.lower() for h in hints)), None)
		video_id = _marked(_SUB_HINTS) or _marked(_ENG_HINTS) or accepted[0][0]
		url = _YOUTUBE_PLAY_URL % video_id
	try:
		if url: meta_cache.set_function(cache_key, {'url': url}, expiration=8760)
		else: meta_cache.set_function(cache_key, {'miss': True}, expiration=24)
	except Exception: pass
	return url


def play_resolved_trailer(params):
	"""Router target for mode 'resolve_yt_trailer'.

	Consumers set this plugin URL as a season's trailer when TMDb has no video for
	it, so nothing is searched while browsing -- the lookup happens here, only when
	the viewer actually presses play. Falls back to the show trailer when the filter
	rejects everything, which is the pre-YouTube behaviour."""
	import xbmcgui
	from modules.kodi_utils import execute_builtin, notification
	from modules.utils import get_datetime
	from modules import settings
	try:
		from modules.metadata import tvshow_meta
		tmdb_id, season = params.get('tmdb_id'), params.get('season')
		meta = tvshow_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime()) or {}
		url = find_season_trailer(meta.get('title'), season, meta.get('year'))
		if not url: url = meta.get('trailer') or ''
	except Exception:
		url = ''
	# AF3's trailer button runs PlayMedia(plugin://...) -- Kodi then invokes us with a
	# real handle and expects setResolvedUrl. Fen Light is script-style everywhere else
	# (handle -1 under RunPlugin), so support both rather than assuming one.
	import sys
	try: handle = int(sys.argv[1])
	except Exception: handle = -1
	if not url:
		if handle >= 0:
			import xbmcplugin
			xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
		return notification('No trailer found')
	if handle >= 0:
		import xbmcplugin
		return xbmcplugin.setResolvedUrl(handle, True, xbmcgui.ListItem(path=url))
	return execute_builtin('PlayMedia(%s)' % url)
