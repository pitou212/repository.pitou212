# -*- coding: utf-8 -*-
import sys
import re
from modules import kodi_utils, settings
from modules.metadata import tvshow_meta, season_trailer_for
from modules.utils import get_datetime, adjust_premiered_date, TaskPool
from modules.watched_status import get_database, watched_info_season, get_watched_status_season, get_progress_status_season, watched_info_episode
# logger = kodi_utils.logger

# LOCAL PATCH 2026-08-27: anime cours as season rows.
#
# TMDb groups anime by its own season layout, which is often not how the show
# aired. Frieren is one TMDb season of 38 episodes but two cours of 28 and 10, so
# TMDb episode 30 is really cour 2 episode 2. Fribb already records the boundaries
# offline, so the season list can show one row per cour with no extra service.
#
# This is presentation only. (season, episode) stays TMDb's everywhere it is used
# as an identity -- play urls, watched state, bookmarks, Trakt/Simkl sync and the
# scrapers -- because renumbering those would orphan existing watch history.
def _aired_per_season(season_data, total_seasons, total_aired_eps):
	"""{season_number: aired episode count}, mirroring the running total the
	season loop keeps: every season but the last reports its full TMDb count, and
	the last gets whatever is left of total_aired_eps."""
	out, acc = {}, 0
	# Ascending order matters: the running total is what decides how much of the
	# final season has actually aired.
	for item in sorted(season_data, key=lambda i: i.get('season_number') or 0):
		sn, ec = item.get('season_number'), item.get('episode_count') or 0
		if sn is None or sn == 0: continue
		if sn < total_seasons:
			out[sn] = ec
			acc += ec
		else: out[sn] = (total_aired_eps or 0) - acc
	return out


def _cour_watched_count(episode_rows, season_number, offset, length):
	"""How many episodes of one cour are watched.

	watched_info_season() only counts per TMDb season, which cannot be split, so
	the per-episode rows are counted directly. Rows are (season, episode) with
	TMDb numbering, so the cour covers offset+1 .. offset+length."""
	if not episode_rows: return 0
	total = 0
	for row in episode_rows:
		try: s, e = int(row[0]), int(row[1])
		except (TypeError, ValueError, IndexError): continue
		if s == season_number and offset < e <= offset + length: total += 1
	return total


def _expand_anime_cours(meta, season_data):
	"""season_data with multi-cour seasons replaced by one entry per cour.

	Returns the list unchanged when the setting is off, the show is not anime, or
	Fribb has no split for any of its seasons -- so non-anime and single-cour shows
	keep the existing code path exactly.
	"""
	if not settings.anime_split_cours(): return season_data
	try:
		from modules.metadata import is_anime_check
		if not is_anime_check(meta): return season_data
		from caches import fribb_mappings
		if not fribb_mappings.is_available(): return season_data
	except Exception: return season_data
	tmdb_id = meta.get('tmdb_id')
	split = {}
	for item in season_data:
		sn = item.get('season_number')
		if not sn: continue      # never split specials
		try: cours = fribb_mappings.cours_for_tmdb_season(tmdb_id, sn, item.get('episode_count') or 0)
		except Exception: cours = []
		if cours: split[sn] = cours
	if not split: return season_data
	# One bulk AniList request names every cour of the show; each id is also written
	# to the per-id cache, so later single lookups never hit the network.
	# LOCAL PATCH 2026-08-27: the same bulk call now also returns each cour's cover
	# art, so every cour row can show its own poster instead of them all sharing the
	# TMDb season's. No extra request -- coverImage rides along in the query that was
	# already being made to name the cours.
	titles, art = {}, {}
	try:
		from apis.anilist_api import anilist_media_bulk
		mal_ids = [c['mal'] for cs in split.values() for c in cs if c.get('mal')]
		if mal_ids:
			recs = anilist_media_bulk(mal_ids) or {}
			titles = {k: v.get('title') for k, v in recs.items() if v.get('title')}
			art = {k: v.get('poster') for k, v in recs.items() if v.get('poster')}
	except Exception: titles, art = {}, {}
	out = []
	for item in season_data:
		cours = split.get(item.get('season_number'))
		if not cours:
			out.append(item)
			continue
		# the first cour's title is the show's base name in the same language as the
		# others, which makes it the best prefix to strip
		base_title = titles.get(cours[0].get('mal')) or titles.get(str(cours[0].get('mal')))
		for cour in cours:
			entry = dict(item)
			entry['episode_count'] = cour['length']
			entry['_cour_offset'] = cour['offset']
			entry['_cour_len'] = cour['length']
			name = titles.get(cour.get('mal')) or titles.get(str(cour.get('mal')))
			info = {}
			try: info = fribb_mappings.find_cour_by_tmdb_coords(tmdb_id, item.get('season_number'), cour['offset'] + 1) or {}
			except Exception: pass
			# Falls back through TMDb's season poster to the show poster in _process().
			cour_art = art.get(cour.get('mal')) or art.get(str(cour.get('mal')))
			if cour_art: entry['_cour_poster'] = cour_art
			# LOCAL PATCH 2026-08-29: keep the AniList id. `info` was already being fetched
			# for the label and this was thrown away, so Mark Watched had no way to reach
			# AniList -- see the mark_season push in watched_status.
			if info.get('anilist'): entry['_cour_anilist'] = info['anilist']
			entry['_cour_title'] = _short_cour_label(
				name, base_title, meta.get('title'), info.get('cour_season'),
				info.get('cour_part') or cour['index'], info.get('cour_part_count') or len(cours),
				item.get('season_number'))
			out.append(entry)
	return out


_BARE_PART_RE = re.compile(r'^(?:part|cour)\s*\d+$', re.I)


def _trim_title_prefix(full, prefix):
	"""`full` with `prefix` and any separator removed, or None if it is not a prefix."""
	if not full or not prefix: return None
	if not full.lower().startswith(prefix.lower()): return None
	return full[len(prefix):].strip(' :-–—.·|/')


def _short_cour_label(full, base, show_title, cour_season, part, part_count, season_number):
	"""A season-row label with the show name taken off the front.

	LOCAL PATCH 2026-08-27. AniList gives the cour's whole name, which is mostly the
	show's: under Frieren the rows read 'Sousou no Frieren' and 'Sousou no Frieren 2nd
	Season'. The row already sits inside the show, so only the tail carries meaning.

	Trimming the FIRST cour's title first is what makes arc names survive -- Bleach's
	cours differ by 'Sennen Kessen-hen - Ketsubetsu-tan', which is worth showing and
	which a generic 'Part 2' would throw away.

	Falls back to the release season number (season.tvdb, so it matches what the
	episodes inside will be numbered as) rather than TMDb's."""
	candidates = []
	for prefix in (base, show_title):
		trimmed = _trim_title_prefix(full, prefix)
		if trimmed: candidates.append(trimmed)
	# Anything still long is the show's name in another language, not a cour marker.
	num = cour_season if cour_season else season_number
	for c in candidates:
		if len(c) > 40: continue
		# 'Part 2' on its own repeats across seasons -- Attack on Titan would list two
		# rows both reading 'Part 2'. Named arcs ('Ketsubetsu-tan') are already unique,
		# so only the bare markers get the season put back in front.
		if _BARE_PART_RE.match(c): return 'Season %s %s' % (num, c)
		return c
	# Nothing distinguishing left (usually cour 1, whose title IS the show title).
	if part_count and part_count > 1: return 'Season %s Part %s' % (num, part)
	return 'Season %s' % num


def build_season_list(params):
	def _process():
		total_aired_eps, episode_count = meta_get('total_aired_eps'), 0
		for item in season_data:
			try:
				cm = []
				cm_append = cm.append
				listitem = make_listitem()
				set_properties = listitem.setProperties
				item_get = item.get
				overview, poster_path, air_date = item_get('overview'), item_get('poster_path'), item_get('air_date')
				season_number, aired_eps = item_get('season_number'), item_get('episode_count')
				season_special = season_number == 0
				# A cour row carries the TMDb season it lives in plus its slice of it. Its
				# aired count has to be settled here, before `unaired` is derived below, so
				# that a cour which has not started yet is greyed out like an unaired season.
				cour_offset, cour_len = item_get('_cour_offset'), item_get('_cour_len')
				is_cour = cour_offset is not None
				if is_cour:
					aired_eps = max(0, min(cour_len, aired_map.get(season_number, cour_len) - cour_offset))
				# LOCAL PATCH 2026-08-26: this season's own trailer when TMDb has one
				# (~54% do), else the show trailer hoisted below.
				season_trailer = season_trailer_for(meta, season_number, trailer)
				if is_cour: title = item_get('_cour_title')
				elif use_name: title = item_get('name', None) or 'Season %s' % season_number
				else: title = 'Season %s' % season_number
				if custom_order is not None: title = '%s - %s' % (show_title, title)
				# LOCAL PATCH 2026-08-27: a cour gets its own AniList cover. Without this every
				# cour of one TMDb season showed that season's single poster, so Bleach's
				# Thousand-Year Blood War cours were indistinguishable in the list.
				poster = 'https://image.tmdb.org/t/p/w780%s' % poster_path if poster_path is not None else show_poster
				poster = item_get('_cour_poster') or poster
				thumb = poster or show_landscape or show_fanart
				try: year = air_date.split('-')[0]
				except: year = show_year or '2050'
				plot = overview or show_plot
				try: premiered = adjust_premiered_date(air_date, adjust_hours)[1]
				except: premiered = ''
				unaired = aired_eps == 0
				# LOCAL PATCH 2026-08-29: a season with zero aired episodes has nothing to
				# play, so it is dropped rather than listed red-italicised -- matching what
				# the episode list now does, and what POV's show_unaired does for both.
				# Specials are exempt: season 0 legitimately holds already-aired OVAs and
				# shorts, and aired_eps can read 0 for them through missing air dates.
				# continue, NOT return: _process() loops over season_data, so returning would
				# also drop every season AFTER the first unaired one.
				if unaired and not season_special and not include_unaired: continue
				# LOCAL PATCH 2026-09-03 (Red Light 2.3.1 port): Specials gets its own branch and
				# its own counts. It used to share the unaired branch, which was wrong twice over.
				#
				# First, that branch assigned `total_watched, total_unwatched` -- names used NOWHERE
				# else in this file. The values the row actually renders are `watched`/`unwatched`
				# (see set_properties below), which the branch never touched, so they kept whatever
				# the PREVIOUS loop iteration left behind. season_data sorts Specials last, so the
				# Specials row reliably showed the latest regular season's tally -- Red Light's
				# report of 'S5 10/10' appearing as 'Specials 10/37'. The intended zeroing never
				# happened either; it was written to the dead names.
				#
				# Second, zeroing is not what Specials wants. Season 0 holds real, already-aired
				# OVAs and shorts that can legitimately be watched, so it is counted like any other
				# season. Only a genuinely unaired season has nothing to count.
				if unaired:
					progress, playcount, watched, unwatched = 0, 0, 0, aired_eps
					title = '[COLOR red][I]%s[/I][/COLOR]' % title
				elif season_special:
					title = 'Specials'
					playcount, watched, unwatched = get_watched_status_season(watched_info.get(season_number, None), aired_eps)
					progress = get_progress_status_season(watched, aired_eps)
				else:
					if is_cour:
						# watched_info_season() counts per TMDb season and cannot be sliced,
						# so a cour is counted from the per-episode rows instead.
						playcount, watched, unwatched = get_watched_status_season(
							_cour_watched_count(episode_watched_rows, season_number, cour_offset, cour_len), aired_eps)
					else:
						if season_number < total_seasons:
							episode_count += aired_eps
						else: aired_eps = total_aired_eps - episode_count
						playcount, watched, unwatched = get_watched_status_season(watched_info.get(season_number, None), aired_eps)
					progress = get_progress_status_season(watched, aired_eps)
				visible_progress = 0 if progress == 100 else progress
				_ep_list_params = {'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': season_number}
				# `season` stays the TMDb one -- the cour is expressed as a slice of it.
				if is_cour: _ep_list_params.update({'cour_offset': cour_offset, 'cour_len': cour_len,
					  'cour_title': title, 'cour_poster': item_get('_cour_poster') or ''})
				url_params = build_url(_ep_list_params)
				extras_params = build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'tvshow', 'is_external': is_external, 'season': season_number})
				options_params = build_url({'mode': 'options_menu_choice', 'content': 'season', 'tmdb_id': tmdb_id, 'poster': show_poster, 'is_external': is_external})
				cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
				cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
				# LOCAL PATCH 2026-08-29: cour rows get Mark Watched/Unwatched again.
				#
				# They were suppressed because mark_season took only a season number and would
				# have marked the sibling cours too -- Reincarnated as a Slime season 2 is two
				# cours of 12, so marking part 2 would also have marked part 1. mark_season now
				# takes the range and pushes an episode list, so the mark is exact and the
				# suppression is no longer needed.
				_mark_params = {'mode': 'watched_status.mark_season', 'title': show_title, 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season_number}
				if is_cour: _mark_params.update({'cour_offset': cour_offset, 'cour_len': cour_len})
				# AniList counts progress WITHIN an entry, and an entry is one cour, so the
				# push needs the entry id and how many episodes complete it. For an unsplit
				# season the entry is the whole season, resolved in mark_season from S/E 1.
				_al = item_get('_cour_anilist')
				if _al: _mark_params['anilist_id'] = _al
				if playcount:
					if hide_watched: continue
				elif not unaired and not season_special:
					cm_append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url(dict(_mark_params, action='mark_as_watched')))])
				if progress:
					cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url(dict(_mark_params, action='mark_as_unwatched')))])
				set_properties({'watchedepisodes': str(watched), 'unwatchedepisodes': str(unwatched)})
				set_properties({'totalepisodes': str(aired_eps), 'watchedprogress': str(visible_progress),
								'fenlight.extras_params': extras_params, 'fenlight.options_params': options_params})
				if is_external:
					cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
							['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
				if custom_cm_menu:
					try: cm = sorted([i for i in cm if i[0] in cm_sort_order], key=lambda k: cm_sort_order[k[0]])
					except: pass
				cm = [i[1] for i in cm]
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setMediaType('season'), info_tag.setTitle(title), info_tag.setOriginalTitle(orig_title), info_tag.setTvShowTitle(show_title), info_tag.setIMDBNumber(imdb_id)
				# A cour row still lives in its TMDb season, but should present the season
				# number releases use -- both Frieren cours are TMDb season 1.
				_display_season = season_number
				if is_cour:
					try:
						from modules.metadata import cour_display_numbers
						_display_season = cour_display_numbers(meta, season_number, cour_offset + 1)[0]
					except Exception: pass
				info_tag.setSeason(_display_season), info_tag.setPlot(plot), info_tag.setDuration(episode_run_time), info_tag.setPlaycount(playcount), info_tag.setGenres(genre)
				info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str_tmdb_id, 'tvdb': str_tvdb_id})
				info_tag.setTvShowStatus(status), info_tag.setFirstAired(premiered), info_tag.setStudios(studio), info_tag.setYear(int(year))
				info_tag.setRating(rating), info_tag.setVotes(votes), info_tag.setMpaa(mpaa), info_tag.setCountries(country), info_tag.setTrailer(season_trailer)
				info_tag.setCast([kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
				listitem.setLabel(title)
				listitem.setArt({'poster': poster, 'season.poster': poster, 'fanart': show_fanart, 'clearlogo': show_clearlogo, 'landscape': show_landscape, 'thumb': thumb,
								'icon': show_landscape, 'tvshow.poster': poster, 'tvshow.clearlogo': show_clearlogo})
				listitem.addContextMenuItems(cm)
				yield (url_params, listitem, True)
			except: pass
	kodi_actor, make_listitem, build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
	poster_empty, fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	watched_indicators, adjust_hours, hide_watched = settings.watched_indicators(), settings.date_offset(), is_external and settings.widget_hide_watched()
	current_date = get_datetime()
	cm_sort_order = settings.cm_sort_order()
	custom_cm_menu = cm_sort_order != settings.cm_default_order()
	rpdb_info = settings.rpdb_info('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	use_name = settings.use_season_name()
	include_unaired = settings.include_unaired_episodes()
	meta = tvshow_meta('tmdb_id', params['tmdb_id'], settings.tmdb_api_key(), settings.mpaa_region(), current_date)
	meta_get = meta.get
	tmdb_id, tvdb_id, imdb_id, show_title, show_year = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id'), meta_get('title'), meta_get('year') or '2050'
	orig_title, status, show_plot = meta_get('original_title', ''), meta_get('status'), meta_get('plot')
	str_tmdb_id, str_tvdb_id, rating, genre = str(tmdb_id), str(tvdb_id), meta_get('rating'), meta_get('genre')
	cast = meta_get('short_cast', []) or meta_get('cast', []) or []
	mpaa, votes, trailer, studio, country = meta_get('mpaa'), meta_get('votes'), str(meta_get('trailer')), meta_get('studio'), meta_get('country')
	episode_run_time, season_data, total_seasons = meta_get('duration'), meta_get('season_data'), meta_get('total_seasons')
	if rpdb_api_key:
		try: show_poster = meta_get('rpdb_poster') % rpdb_api_key + rpdb_format
		except: show_poster = meta_get('poster') or poster_empty
	else: show_poster = meta_get('poster') or poster_empty
	show_fanart = meta_get('fanart') or fanart_empty
	show_clearlogo, show_landscape = meta_get('clearlogo') or '', meta_get('landscape') or ''
	custom_order = params.get('custom_order', None)
	if settings.show_specials(): season_data.sort(key=lambda i: (i['season_number'] == 0, i['season_number']))
	elif custom_order is not None: season_data = [i for i in season_data if i['season_number'] == params['season']]
	else:
		season_data = [i for i in season_data if not i['season_number'] == 0]
		season_data.sort(key=lambda k: k['season_number'])
	watched_info = watched_info_season(tmdb_id, get_database(watched_indicators))
	# Anime whose TMDb seasons bundle several cours get one row per cour. Skipped
	# for custom_order, which renders a single season inside another list and
	# returns list_items[0] -- splitting there would silently drop the later cours.
	if custom_order is None: season_data = _expand_anime_cours(meta, season_data)
	if any('_cour_offset' in i for i in season_data):
		aired_map = _aired_per_season(meta_get('season_data') or [], total_seasons, meta_get('total_aired_eps'))
		episode_watched_rows = watched_info_episode(tmdb_id, get_database(watched_indicators))
	else: aired_map, episode_watched_rows = {}, []
	list_items = list(list(_process()))
	if custom_order is not None: return (list_items[0], custom_order)
	kodi_utils.add_items(handle, list_items)
	kodi_utils.set_content(handle, 'seasons')
	kodi_utils.set_category(handle, show_title)
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	kodi_utils.set_view_mode('view.seasons', 'seasons', is_external)
	# LOCAL PATCH 2026-08-09: auto-focus the earliest not-fully-watched season
	# so opening a show lands on "where you're up to" instead of Season 1.
	# Shares the episodes-list autoscroll setting + firing mechanism.
	if not is_external and settings.autoscroll_unwatched():
		try:
			target = None
			for idx, (_u, _li, _isf) in enumerate(list_items):
				try:
					info = _li.getVideoInfoTag()
					if info.getPlayCount() > 0: continue          # fully-watched season
					t = info.getTitle() or ''
					if t.startswith('[COLOR red]') or t == 'Specials': continue  # unaired / specials
					target = idx
					break
				except: continue
			if target: kodi_utils.autoscroll_focus(target, len(list_items))
		except: pass

def single_seasons(seasons_list):
	season_results = []
	threads = TaskPool().tasks(lambda x: season_results.append(build_season_list(x)), seasons_list, min(len(seasons_list), settings.max_threads()))
	[i.join() for i in threads]
	return [i for i in season_results if i]
