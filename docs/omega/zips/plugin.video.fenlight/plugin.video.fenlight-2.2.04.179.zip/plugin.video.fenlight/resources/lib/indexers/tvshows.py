# -*- coding: utf-8 -*-
import re
import sys
import json
from modules.metadata import tvshow_meta, is_anime_check
from modules.utils import get_datetime, get_current_timestamp, paginate_list, TaskPool, manual_function_import, extra_rating_props
from caches import fribb_mappings
from modules import kodi_utils, settings, watched_status
# logger = kodi_utils.logger

# LOCAL PATCH 2026-08-26: cour identity for anime catalog tiles.
# indexers/anilist_lists.py tags a later cour's ids dict with 'cour_label' (the
# catalog source's own title, e.g. "The Apothecary Diaries Season 3"). Without it
# the tile shows the PARENT TMDb show -- TMDb 220542 is one 49-episode season, so
# S1/S2/S3 all render identically and an upcoming cour looks like a rerun.
#
# Only the visible label is affected. `title` still feeds favourites/personal-list
# URLs, context-menu strings and setTvShowTitle, which must stay the parent show.

def _norm_title(text):
	return re.sub(r'[^a-z0-9]+', '', (text or '').lower())


def _display_label(tmdb_title, cour_label, cour_suffix=''):
	"""Which name to show on a later-cour tile.

	tmdb_title  -- the SHOW's name; authoritative and always present.
	cour_label  -- the catalog source's own name for this cour, e.g. "The Apothecary
	               Diaries Season 3". Usually the best label, but AniList falls back
	               to ROMAJI when it has no English title, and flipping a tile to
	               "Kusuriya no Hitorigoto 3rd Season" is a regression for anyone
	               browsing in English.
	cour_suffix -- just the season marker out of cour_label ("Season 3").

	Rule: if the two are in the same naming language (cour_label starts with the
	show title) the source's own wording wins -- it is human-curated and handles
	subtitled cours like "Jujutsu Kaisen: Shimetsu Kaiyuu Zenpen". Otherwise keep the
	TMDb name and graft the marker on, so the English name always leads. If we cannot
	reconcile them at all, change nothing rather than guess.
	"""
	if not cour_label: return tmdb_title
	if not tmdb_title: return cour_label
	if _norm_title(cour_label).startswith(_norm_title(tmdb_title)): return cour_label
	if cour_suffix: return '%s - %s' % (tmdb_title, cour_suffix)
	return tmdb_title


class TVShows:
	# LOCAL PATCH 2026-08-05 (POV 6.08 P1 port): tmdb_tv_trending added as Trakt-independent trending source
	main = ('tmdb_tv_popular', 'tmdb_tv_popular_today', 'tmdb_tv_trending', 'tmdb_tv_premieres', 'tmdb_tv_airing_today','tmdb_tv_on_the_air', 'tmdb_tv_upcoming',
	'tmdb_anime_popular', 'tmdb_anime_popular_recent', 'tmdb_anime_premieres', 'tmdb_anime_upcoming', 'tmdb_anime_on_the_air')
	special = ('tmdb_tv_languages', 'tmdb_tv_networks', 'tmdb_tv_providers', 'tmdb_tv_year', 'tmdb_tv_decade', 'tmdb_tv_recommendations', 'tmdb_tv_genres',
	'tmdb_tv_search', 'tmdb_tv_keyword_results', 'tmdb_tv_keyword_results_direct', 'tmdb_anime_year', 'tmdb_anime_decade', 'tmdb_anime_genres',
	'tmdb_anime_providers', 'ai_similar')
	personal = {'in_progress_tvshows': ('modules.watched_status', 'get_in_progress_tvshows'),
	'watched_tvshows': ('modules.watched_status', 'get_watched_items'),
	'recent_watched_tvshows': ('modules.watched_status', 'get_recently_watched'),
	'favorites_tvshows': ('modules.favorites', 'get_favorites'),
	'favorites_anime': ('modules.favorites', 'get_favorites')}
	trakt_main = ('trakt_tv_trending', 'trakt_tv_trending_recent', 'trakt_tv_most_watched', 'trakt_tv_most_favorited',
	'trakt_anime_trending', 'trakt_anime_trending_recent', 'trakt_anime_most_watched', 'trakt_anime_most_favorited')
	trakt_special = ('trakt_tv_certifications', 'trakt_anime_certifications')
	trakt_personal = ('trakt_collection', 'trakt_watchlist', 'trakt_collection_lists', 'trakt_watchlist_lists', 'trakt_favorites')
	
	def __init__(self, params):
		self.params = params
		self.params_get = self.params.get
		self.category_name = self.params_get('category_name', None) or self.params_get('name', None) or 'TV Shows'
		self.id_type, self.list, self.action = self.params_get('id_type', 'tmdb_id'), self.params_get('list', []), self.params_get('action', None)
		self.tmdb_api_key = settings.tmdb_api_key()
		self.items, self.new_page, self.total_pages, self.is_external = [], {}, None, kodi_utils.external()
		self.is_anime()
		if self.is_external:
			self.widget_hide_next_page = settings.widget_hide_next_page()
			self.widget_hide_watched = self.action not in ('watched_tvshows', 'recent_watched_tvshows') and settings.widget_hide_watched()
		else: self.widget_hide_next_page, self.widget_hide_watched = False, False
		self.custom_order = self.params_get('custom_order', 'false') == 'true'
		self.paginate_start = int(self.params_get('paginate_start', '0'))
		self.append = self.items.append

	def is_anime(self):
		if 'is_anime_list' in self.params: self.is_anime_list = self.params['is_anime_list'] == 'true'
		elif self.action in self.personal:
			if settings.include_anime_tvshow(): self.is_anime_list = None
			else: self.is_anime_list = False
		else: self.is_anime_list = None

	def fetch_list(self):
		handle = int(sys.argv[1])
		try:
			is_random = self.params_get('random', 'false') == 'true'
			try: page_no = int(self.params_get('new_page', '1'))
			except: page_no = self.params_get('new_page')
			if page_no == 1 and not self.is_external:
				folder_path = kodi_utils.folder_path()
				if not any([x in folder_path for x in ('build_season_list', 'build_episode_list')]): kodi_utils.set_property('fenlight.exit_params', folder_path)
			if self.action in self.personal: var_module, import_function = self.personal[self.action]
			else: var_module, import_function = 'apis.%s_api' % self.action.split('_')[0], self.action
			try: function = manual_function_import(var_module, import_function)
			except: pass
			if self.action in self.main:
				data = function(page_no)
				results = data['results']
				self.list = [i['id'] for i in results]
				if not is_random and data['total_pages'] > page_no: self.new_page = {'new_page': str(page_no + 1)}
			elif self.action in self.special:
				key_id = self.params_get('key_id') or self.params_get('query')
				if not key_id: return
				data = function(key_id, page_no)
				results = data['results']
				self.list = [i['id'] for i in results]
				if not is_random and data['total_pages'] > page_no: self.new_page = {'new_page': str(page_no + 1), 'key_id': key_id}
			elif self.action in self.personal:
				data = function('tvshow', page_no)
				data, total_pages = self.paginate_list(data, page_no)
				self.list = [i['media_id'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}
			elif self.action in self.trakt_main:
				self.id_type = 'trakt_dict'
				data = function(page_no)
				try: self.list = [i['show']['ids'] for i in data]
				except: self.list = [i['ids'] for i in data]
				if not is_random and self.action != 'trakt_recommendations': self.new_page = {'new_page': str(page_no + 1)}
			elif self.action in self.trakt_special:
				key_id = self.params_get('key_id', None) or self.params_get('query')
				if not key_id: return
				self.id_type = 'trakt_dict'
				data = function(key_id, page_no)
				self.list = [i['show']['ids'] for i in data]
				if not is_random: self.new_page = {'new_page': str(page_no + 1), 'key_id': key_id}
			elif self.action in self.trakt_personal:
				self.id_type = 'trakt_dict'
				data = function('shows', page_no)
				if self.action in ('trakt_collection_lists', 'trakt_watchlist_lists', 'trakt_favorites'): total_pages = 1
				else: data, total_pages = self.paginate_list(data, page_no)
				self.list = [i['media_ids'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}
				except: pass
			elif self.action == 'trakt_recommendations':
				self.id_type = 'trakt_dict'
				data = function('shows')
				data, total_pages = self.paginate_list(data, page_no)
				self.list = [i['ids'] for i in data]
				if total_pages > 2: self.total_pages = total_pages
				try:
					if total_pages > page_no: self.new_page = {'new_page': str(page_no + 1), 'paginate_start': self.paginate_start}
				except: pass
			elif self.action == 'tmdb_tv_discover':
				url = self.params_get('url')
				data = function(url, page_no)
				results = data['results']
				self.list = [i['id'] for i in results]
				if data['total_pages'] > page_no: self.new_page = {'url': url, 'new_page': str(data['page'] + 1)}
			elif self.action == 'trakt_dropped':
				from apis.trakt_api import trakt_get_hidden_items
				self.list = [i for i in (trakt_get_hidden_items('dropped') or []) if i]
			elif self.action == 'trakt_tv_related':
				self.id_type = 'trakt_dict'
				key_id = self.params_get('key_id')
				if not key_id.startswith('tt'): key_id = tvshow_meta('tmdb_id', key_id, self.tmdb_api_key, settings.mpaa_region(), get_datetime())['imdb_id']
				data = function(key_id)
				self.list = [i['ids'] for i in data]
			elif self.action == 'imdb_more_like_this':
				from apis.imdb_api import imdb_more_like_this
				self.id_type = 'imdb_id'
				key_id = self.params_get('key_id')
				if self.params_get('get_imdb'):
					key_id = tvshow_meta('tmdb_id', key_id, self.tmdb_api_key, settings.mpaa_region(), get_datetime(), get_current_timestamp())['imdb_id']
				self.list = imdb_more_like_this(key_id)
			self._maybe_filter_dropped()
			kodi_utils.add_items(handle, self.worker())
			if self.total_pages and self.total_pages > 2 and settings.jump_to_enabled() and not self.is_external:
				url_params = json.dumps({**self.new_page, **{'mode': 'build_tvshow_list', 'action': self.action, 'category_name': self.category_name}})
				kodi_utils.add_dir(handle, {'mode': 'navigate_to_page_choice', 'current_page': page_no, 'total_pages': self.total_pages, 'url_params': url_params},
											'Jump To...', 'item_jump', kodi_utils.get_icon('item_jump_landscape'), isFolder=False)
			if self.new_page and not self.widget_hide_next_page:
				self.new_page.update({'mode': 'build_tvshow_list', 'action': self.action, 'category_name': self.category_name})
				if self.is_anime_list is not None: self.new_page['is_anime_list'] == {True: 'true', False: 'false'}[self.is_anime_list]
				kodi_utils.add_dir(handle, self.new_page, 'Next Page (%s) >>' % self.new_page['new_page'], 'nextpage', kodi_utils.get_icon('nextpage_landscape'))
		except: pass
		kodi_utils.set_content(handle, 'tvshows')
		kodi_utils.set_category(handle, self.category_name)
		kodi_utils.end_directory(handle, cacheToDisc=False if self.is_external else True)
		if not self.is_external:
			if self.params_get('refreshed') == 'true': kodi_utils.sleep(1000)
			kodi_utils.set_view_mode('view.tvshows', 'tvshows', self.is_external)

	def build_tvshow_content(self, _position, _id):
		try:
			meta = tvshow_meta(self.id_type, _id, self.tmdb_api_key, self.mpaa_region, self.current_date, self.current_time, self.is_anime_list)
			if not meta or 'blank_entry' in meta: return
			cm = []
			cm_append = cm.append
			listitem = self.make_listitem()
			set_properties = listitem.setProperties
			meta_get = meta.get
			premiered = meta_get('premiered')
			trailer, title, year = meta_get('trailer'), meta_get('title'), meta_get('year') or '2050'
			# LOCAL PATCH 2026-08-26: cour identity -- display only. `_id` is a dict solely
			# on the trakt_dict path (anime catalogs); every other caller passes a bare id.
			# LOCAL PATCH 2026-08-26: an airing show advertises its CURRENT season; ended
			# shows keep the canonical show trailer (user's choice, 2026-08-26). max() picks
			# the highest season that actually HAS one -- the newest season is often unaired
			# with no trailer yet. Runs BEFORE the cour override below, which is finer
			# grained (a cour, not a TMDb season) and must win.
			if meta_get('status') in ('Returning Series', 'In Production'):
				_season_trailers = meta_get('season_trailers') or {}
				if _season_trailers: trailer = _season_trailers[max(_season_trailers)] or trailer
			label = title
			if isinstance(_id, dict):
				_cour = _id.get('cour_label')
				if _cour: label = _display_label(title, _cour, _id.get('cour_suffix', '')) or title
				# Season-correct trailer. meta['trailer'] is picked off the TMDb SHOW and
				# cached per tmdb_id, so every cour would otherwise share season 1's.
				_cour_trailer = _id.get('cour_trailer')
				if _cour_trailer: trailer = _cour_trailer
			tvdb_id, imdb_id = meta_get('tvdb_id'), meta_get('imdb_id')
			if self.rpdb_api_key:
				try: poster = meta_get('rpdb_poster') % self.rpdb_api_key + self.rpdb_format
				except: poster = meta_get('poster') or self.poster_empty
			else: poster = meta_get('poster') or self.poster_empty
			fanart = meta_get('fanart') or self.fanart_empty
			clearlogo, landscape = meta_get('clearlogo') or '', meta_get('landscape') or ''
			thumb = poster or landscape or fanart
			tmdb_id, total_seasons, total_aired_eps = meta_get('tmdb_id'), meta_get('total_seasons'), meta_get('total_aired_eps')
			unaired = total_aired_eps == 0
			if unaired: progress, playcount, total_watched, total_unwatched = 0, 0, 0, total_aired_eps
			else:
				playcount, total_watched, total_unwatched = watched_status.get_watched_status_tvshow(self.watched_info.get(str(tmdb_id), None), total_aired_eps)
				if total_watched: progress = watched_status.get_progress_status_tvshow(total_watched, total_aired_eps)
				else: progress = 0
			# LOCAL PATCH 2026-09-04: assign visible_progress on BOTH branches. It used to be
			# set only in the else, but set_properties() below reads it unconditionally -- so
			# every wholly-unaired show (total_aired_eps == 0) raised NameError straight into
			# this function's bare `except: pass` and was silently dropped, AFTER its full meta
			# fetch and context menu had been built. That is what made tmdb_tv_upcoming /
			# tmdb_anime_upcoming / tmdb_anime_premieres render empty. indexers/seasons.py
			# assigns it unconditionally, which is the shape this should have kept.
			visible_progress = '0' if progress == 100 else progress
			# LOCAL PATCH 2026-09-04: bail before building the urls and context menu, for the
			# same reason as the equivalent early return in indexers/movies.py.
			if playcount and self.widget_hide_watched: return
			extras_params = self.build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'tvshow', 'is_external': self.is_external})
			options_params = self.build_url({'mode': 'options_menu_choice', 'content': 'tvshow', 'tmdb_id': tmdb_id, 'poster': poster,
										'is_external': self.is_external})
			browse_recommended_params = self.build_url({'mode': 'build_tvshow_list', 'action': 'tmdb_tv_recommendations', 'key_id': tmdb_id, 'is_external': self.is_external,
										'name': 'Recommended based on %s' % title})
			browse_related_params = self.build_url({'mode': 'build_tvshow_list', 'action': 'trakt_tv_related', 'key_id': imdb_id, 'is_external': self.is_external,
										'name': 'Related to %s' % title})
			browse_more_like_this_params = self.build_url({'mode': 'build_tvshow_list', 'action': 'imdb_more_like_this', 'key_id': imdb_id, 'is_external': self.is_external,
										'name': 'More Like This based on %s' % title, 'is_external': self.is_external})
			browse_similar_params = self.build_url({'mode': 'build_tvshow_list', 'action': 'ai_similar', 'is_external': self.is_external,
										'key_id': 'tvshow|%s' % tmdb_id, 'name': 'Similar based on %s' % title})
			browse_in_trakt_list_params = self.build_url({'mode': 'trakt.list.in_trakt_lists', 'media_type': 'tvshow', 'imdb_id': imdb_id, 'is_external': self.is_external,
										'category_name': '%s In Trakt Lists' % title})
			trakt_manager_params = self.build_url({'mode': 'trakt_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow', 'icon': poster})
			personal_manager_params = self.build_url({'mode': 'personallists_manager_choice', 'list_type': 'tvshow', 'tmdb_id': tmdb_id, 'title': title,
										'premiered': premiered, 'current_time': self.current_time, 'icon': poster})
			tmdb_manager_params = self.build_url({'mode': 'tmdblists_manager_choice', 'media_type': 'tv', 'tmdb_id': tmdb_id, 'icon': poster})
			favorites_manager_params = self.build_url({'mode': 'favorites_manager_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'title': title})
			if self.all_episodes:
				if self.all_episodes == 1 and total_seasons > 1: url_params = self.build_url({'mode': 'build_season_list', 'tmdb_id': tmdb_id})
				else: url_params = self.build_url({'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': 'all'})
			else: url_params = self.build_url({'mode': 'build_season_list', 'tmdb_id': tmdb_id})
			if self.open_extras:
				cm_append(['extras', ('[B]Browse[/B]', 'Container.Update(%s)' % url_params)])
				url_params = extras_params
			else: cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
			cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
			cm_append(['recommended', ('[B]Browse Recommended[/B]', self.window_command % browse_recommended_params)])
			cm_append(['related', ('[B]Browse Related[/B]', self.window_command % browse_related_params)])
			cm_append(['more_like_this', ('[B]Browse More Like This[/B]', self.window_command % browse_more_like_this_params)])
			if self.ai_model_active: cm_append(['similar', ('[B]Browse Similar[/B]', self.window_command % browse_similar_params)])
			cm_append(['in_trakt_list', ('[B]In Trakt Lists[/B]', self.window_command % browse_in_trakt_list_params)])
			cm_append(['trakt_manager', ('[B]Trakt Lists Manager[/B]', 'RunPlugin(%s)' % trakt_manager_params)])
			# LOCAL PATCH 2026-08-29: AniList list manager. Gated on BOTH an authorized account
			# and a Fribb hit -- the latter is also the anime test, so regular TV never sees it.
			# LOCAL PATCH 2026-09-04: an is_anime_check() pre-gate in front of the Fribb hit.
			# Using the Fribb lookup AS the anime test meant every item of every TV widget
			# loaded the 7.5 MB index (~124 ms, and 10.8x that when 20 TaskPool threads raced
			# it) purely to decide this one context-menu entry. is_anime_check reads the TMDb
			# keywords already present in meta, so non-anime never touches Fribb at all.
			# TRADE-OFF: anime that Fribb knows but TMDb has not tagged with keyword 210024
			# lose this entry. Accepted deliberately; if it bites, widen the gate to a cached
			# anime-tmdb-id set rather than going back to loading the index unconditionally.
			if self.anilist_cm_active and is_anime_check(meta) and fribb_mappings.tmdb_tv_to_fribb_rows(tmdb_id):
				cm_append(['anilist_manager', ('[B]AniList Manager[/B]', 'RunPlugin(%s)' % self.build_url(
					{'mode': 'anilist_manager_choice', 'tmdb_id': tmdb_id, 'title': title,
					'media_type': 'tvshow', 'icon': poster}))])
			# LOCAL PATCH 2026-07-23: MDBList Manager context-menu entry (with Toggle Drop built into the manager dialog).
			mdblist_manager_params = self.build_url({'mode': 'mdblist_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow', 'icon': poster})
			cm_append(['mdblist_manager', ('[B]MDBList Manager[/B]', 'RunPlugin(%s)' % mdblist_manager_params)])
			# LOCAL PATCH 2026-07-30: SIMKL Manager context-menu entry.
			simkl_manager_params = self.build_url({'mode': 'simkl_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'media_type': 'tvshow', 'icon': poster})
			cm_append(['simkl_manager', ('[B]SIMKL Manager[/B]', 'RunPlugin(%s)' % simkl_manager_params)])
			try: _is_dropped = int(tmdb_id) in self.dropped_set
			except: _is_dropped = False
			_drop_action = 'undrop' if _is_dropped else 'drop'
			_drop_label = '[B]Undrop Show[/B]' if _is_dropped else '[B]Drop Show[/B]'
			_drop_url = self.build_url({'mode': 'trakt_drop_show', 'action': _drop_action, 'media_id': tmdb_id})
			cm_append(['drop_show', (_drop_label, 'RunPlugin(%s)' % _drop_url)])
			cm_append(['personal_manager', ('[B]Personal Lists Manager[/B]', 'RunPlugin(%s)' % personal_manager_params)])
			cm_append(['tmdb_manager', ('[B]TMDb Lists Manager[/B]', 'RunPlugin(%s)' % tmdb_manager_params)])
			cm_append(['favorites_manager', ('[B]Favorites Manager[/B]', 'RunPlugin(%s)' % favorites_manager_params)])
			# LOCAL PATCH 2026-09-04: was `if playcount: if widget_hide_watched: return / elif
			# not unaired:` -- the return moved up to just after the watched lookup, so the
			# playcount branch had nothing left in it. Same condition, stated directly.
			if not playcount and not unaired:
				cm_append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'watched_status.mark_tvshow', 'action': 'mark_as_watched',
																			'title': title,'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id}))])
			if progress:
				cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'watched_status.mark_tvshow', 'action': 'mark_as_unwatched',
																			'title': title, 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id}))])
			set_properties({'watchedepisodes': str(total_watched), 'unwatchedepisodes': str(total_unwatched)})
			set_properties({'watchedprogress': visible_progress, 'totalepisodes': str(total_aired_eps), 'totalseasons': str(total_seasons)})
			if not self.is_external: cm_append(['exit', ('[B]Exit TV Show List[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'navigator.exit_media_menu'}))])
			if self.is_external:
				cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'refresh_widgets'}))],
						['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % self.build_url({'mode': 'kodi_refresh'}))]])
			cm = self.context_menu(cm)
			listitem.setLabel(label)
			listitem.addContextMenuItems(cm)
			# LOCAL PATCH 2026-08-06: extra_fanart_list from meta feeds AF3's fanart cycler
			# (Includes_DialogInfo.xml reads ListItem.Art(fanart1)..(fanart8)).
			art = {'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo, 'landscape': landscape, 'thumb': thumb, 'icon': landscape,
					'tvshow.poster': poster, 'tvshow.clearlogo': clearlogo}
			try:
				for _idx, _bg in enumerate(meta_get('extra_fanart_list') or [], start=1):
					if _idx > 8: break
					art['fanart%d' % _idx] = _bg
			except Exception: pass
			listitem.setArt(art)
			info_tag = listitem.getVideoInfoTag(True)
			info_tag.setMediaType('tvshow'), info_tag.setTitle(label), info_tag.setTvShowTitle(title), info_tag.setOriginalTitle(meta_get('original_title'))
			info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str(tmdb_id), 'tvdb': str(tvdb_id)}), info_tag.setIMDBNumber(imdb_id)
			info_tag.setPlot(meta_get('plot')), info_tag.setPlaycount(playcount), info_tag.setGenres(meta_get('genre')), info_tag.setYear(int(year))
			info_tag.setTagLine(meta_get('tagline')), info_tag.setStudios(meta_get('studio')), info_tag.setWriters(meta_get('writer')), info_tag.setDirectors(meta_get('director'))
			info_tag.setVotes(meta_get('votes')), info_tag.setMpaa(meta_get('mpaa')), info_tag.setDuration(meta_get('duration')), info_tag.setCountries(meta_get('country'))
			info_tag.setTrailer(trailer), info_tag.setPremiered(premiered)
			info_tag.setTvShowStatus(meta_get('status')), info_tag.setRating(meta_get('rating'))
			cast = meta_get('short_cast', []) or meta_get('cast', []) or []
			info_tag.setCast([self.kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
			set_properties({
				'fenlight.extras_params': extras_params,
				'fenlight.options_params': options_params,
				'fenlight.browse_recommended_params': browse_recommended_params,
				'fenlight.browse_related_params': browse_related_params,
				'fenlight.browse_more_like_this_params': browse_more_like_this_params,
				'fenlight.browse_similar_params': browse_similar_params,
				'fenlight.browse_in_trakt_list_params': browse_in_trakt_list_params,
				'fenlight.trakt_manager_params': trakt_manager_params,
				'fenlight.personal_manager_params': personal_manager_params,
				'fenlight.tmdb_manager_params': tmdb_manager_params,
				'fenlight.favorites_manager_params': favorites_manager_params
				})
			extra_props = extra_rating_props(meta)
			if extra_props: set_properties(extra_props)
			self.append(((url_params, listitem, self.is_folder), _position))
		except: pass

	def worker(self):
		self.kodi_actor, self.make_listitem, self.build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
		self.poster_empty, self.fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
		self.current_date, self.current_time = get_datetime(), get_current_timestamp()
		self.mpaa_region = settings.mpaa_region()
		self.ai_model_active = settings.ai_model_active()
		rpdb_info = settings.rpdb_info('tvshow')
		self.rpdb_api_key, self.rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
		self.all_episodes, self.open_extras = settings.default_all_episodes(), settings.media_open_action('tvshow') == 1
		self.cm_sort_order = settings.cm_sort_order()
		self.custom_cm_menu = self.cm_sort_order != settings.cm_default_order()
		# LOCAL PATCH 2026-09-04: hoisted out of build_tvshow_content, where it was 2 settings
		# reads per item. The 'anilist_manager' half is free and skips the whole gate when the
		# user has that context-menu entry turned off.
		self.anilist_cm_active = 'anilist_manager' in self.cm_sort_order and settings.anilist_user_active()
		self.is_folder = False if self.open_extras else True
		self.watched_indicators = settings.watched_indicators()
		self.watched_info = watched_status.watched_info_tvshow(watched_status.get_database(self.watched_indicators))
		self._load_dropped_set()
		self.window_command = 'ActivateWindow(Videos,%s,return)' if self.is_external else 'Container.Update(%s)'
		if self.custom_order:
			threads = TaskPool().tasks(self.build_tvshow_content, self.list, min(len(self.list), settings.max_threads()))
			[i.join() for i in threads]
		else:
			threads = TaskPool().tasks_enumerate(self.build_tvshow_content, self.list, min(len(self.list), settings.max_threads()))
			[i.join() for i in threads]
			self.items.sort(key=lambda k: k[1])
			self.items = [i[0] for i in self.items]
		return self.items

	EXEMPT_FROM_DROP_FILTER = frozenset({
		'trakt_dropped',
		'trakt_collection', 'trakt_collection_lists',
		'trakt_watchlist', 'trakt_watchlist_lists',
		'trakt_favorites',
		'in_progress_tvshows', 'watched_tvshows', 'recent_watched_tvshows',
		'favorites_tvshows', 'favorites_anime',
	})

	def _load_dropped_set(self):
		if hasattr(self, 'dropped_set'): return self.dropped_set
		self.dropped_set = set()
		# LOCAL PATCH 2026-07-28 / 2026-07-29: pull dropped set from the currently-
		# selected watched-indicator provider (MDBList if 2, SIMKL if 3, Trakt if 1).
		# For SIMKL, "hold" counts as hidden alongside "dropped".
		chosen = settings.watched_indicators()
		if chosen == 2 and settings.mdblist_user_active():
			try:
				from apis.mdblist_api import mdbl_get_hidden_items
				self.dropped_set = set(int(i) for i in (mdbl_get_hidden_items('dropped') or []) if i)
			except: pass
			return self.dropped_set
		if chosen == 3 and settings.simkl_user_active():
			try:
				from apis.simkl_api import simkl_list
				hidden = set()
				# LOCAL PATCH 2026-07-30: cover anime too — SIMKL splits shows vs anime.
				for list_type in ('shows', 'anime'):
					for status in ('dropped', 'hold'):
						data = simkl_list(list_type, status) or {}
						for it in (data.get(list_type) or []):
							tmdb = (it.get('show') or {}).get('ids', {}).get('tmdb')
							if tmdb: hidden.add(int(tmdb))
				self.dropped_set = hidden
			except: pass
			return self.dropped_set
		if not settings.trakt_user_active(): return self.dropped_set
		try:
			from apis.trakt_api import trakt_get_hidden_items
			self.dropped_set = set(int(i) for i in (trakt_get_hidden_items('dropped') or []) if i)
		except: pass
		return self.dropped_set

	def _maybe_filter_dropped(self):
		from caches.settings_cache import get_setting as _get_setting
		if _get_setting('fenlight.dropshow.hide_from_lists', 'true') != 'true': return
		if self.action in self.EXEMPT_FROM_DROP_FILTER: return
		dropped = self._load_dropped_set()
		if not dropped or not self.list: return
		if self.id_type == 'tmdb_id':
			self.list = [i for i in self.list if i and int(i) not in dropped]
		elif self.id_type == 'trakt_dict':
			def _ok(d):
				try: return not (d.get('tmdb') and int(d['tmdb']) in dropped)
				except: return True
			self.list = [i for i in self.list if _ok(i)]

	def context_menu(self, context_menu_items):
		if self.custom_cm_menu:
			try: context_menu_items = sorted([i for i in context_menu_items if i[0] in self.cm_sort_order], key=lambda k: self.cm_sort_order[k[0]])
			except: pass
		return [i[1] for i in context_menu_items]

	def paginate_list(self, data, page_no):
		if settings.paginate(self.is_external):
			limit = settings.page_limit(self.is_external)
			data, total_pages = paginate_list(data, page_no, limit, self.paginate_start)
			if self.is_external: self.paginate_start = limit
		else: total_pages = 1
		return data, total_pages
