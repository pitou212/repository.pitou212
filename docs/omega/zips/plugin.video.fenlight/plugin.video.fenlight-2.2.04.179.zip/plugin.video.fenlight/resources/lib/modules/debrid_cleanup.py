# -*- coding: utf-8 -*-
"""LOCAL PATCH 2026-08-31: shared driver for "delete everything from the debrid cloud".

The providers differ only in how they enumerate and how they delete one item. Everything
around that -- the confirmation, the progress window, cancellation, counting what failed,
clearing the cache and refreshing the container -- is identical, so it lives here once
instead of four times.

Deliberately SEQUENTIAL. This is destructive and rarely used; being able to cancel it
half way and be told exactly how far it got matters far more than finishing quickly. A
worker pool would also make the progress count meaningless and the cancel unreliable.
"""
from modules import kodi_utils


def delete_all(provider_name, items, delete_one, clear_cache=None, icon=None):
	"""Delete every handle in `items`, reporting progress.

	items       opaque handles, whatever the caller's delete_one understands
	delete_one  callable(handle) -> truthy on success. Must not raise; if it does we
	            count it as a failure and carry on rather than abandoning the rest.
	clear_cache optional callable, run once after the loop
	"""
	total = len(items)
	if not total: return kodi_utils.notification('%s cloud is already empty' % provider_name)
	if not kodi_utils.confirm_dialog(
			heading='[B]Delete All - %s[/B]' % provider_name,
			text='Permanently delete all %d item(s) from your %s cloud?[CR]This cannot be undone.' % (total, provider_name),
			ok_label='Delete All', cancel_label='Cancel'):
		return
	progress = kodi_utils.progress_dialog('Deleting from %s cloud' % provider_name, icon)
	deleted, failed, cancelled = 0, 0, False
	try:
		for n, handle in enumerate(items, 1):
			try:
				if progress.iscanceled():
					cancelled = True
					break
			except Exception: pass
			try: progress.update('%d of %d' % (n, total), int(n * 100.0 / total), icon)
			except Exception: pass
			try: ok = delete_one(handle)
			except Exception as e:
				kodi_utils.logger('debrid delete_all', '%s raised on %s: %s' % (provider_name, handle, e))
				ok = False
			if ok: deleted += 1
			else:
				failed += 1
				kodi_utils.logger('debrid delete_all', '%s failed on %s' % (provider_name, handle))
	finally:
		try: progress.close()
		except Exception: pass
		kodi_utils.sleep(100)
	cache_result = 'not requested'
	if clear_cache:
		# Report what the cache step actually did. When 8 deleted items kept showing after
		# a bulk delete, the log could not say whether the cache was cleared or not.
		try: cache_result = clear_cache()
		except Exception as e: cache_result = 'raised: %s' % e
	kodi_utils.execute_builtin('Container.Refresh')
	# Always say what actually happened -- a silent finish after a destructive bulk action
	# leaves you unable to tell "deleted everything" from "deleted nothing".
	if cancelled: msg = '%s: cancelled after %d of %d' % (provider_name, deleted, total)
	elif failed: msg = '%s: deleted %d, FAILED %d' % (provider_name, deleted, failed)
	else: msg = '%s: deleted %d item(s)' % (provider_name, deleted)
	# Log the outcome too, not just the failures. Successes and cancellations used to be
	# indistinguishable in kodi.log -- both silent -- which is backwards for a destructive
	# bulk action people diagnose from the log afterwards.
	kodi_utils.logger('debrid delete_all', '%s | total=%s deleted=%s failed=%s cancelled=%s' % (
		provider_name, total, deleted, failed, cancelled) + ' cache=%s' % (cache_result,))
	kodi_utils.notification(msg, 4000 if (failed or cancelled) else 3000)
