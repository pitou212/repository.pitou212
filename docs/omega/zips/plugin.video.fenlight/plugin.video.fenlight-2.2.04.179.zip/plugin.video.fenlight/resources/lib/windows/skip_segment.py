# -*- coding: utf-8 -*-
"""Skip Segment overlay: small button shown during intro/credits/recap allowing manual skip."""
from windows.base_window import BaseDialog


class SkipSegment(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.label = kwargs.get('label', 'Skip')
		self.corner = kwargs.get('corner', 'bottom-right')
		self.user_clicked = False
		self.closed_externally = False
		self.setProperty('label', self.label)
		self.setProperty('corner', self.corner)

	def onClick(self, controlID):
		if controlID == 10:
			self.user_clicked = True
			self.close()

	def onAction(self, action):
		if action in self.closing_actions:
			self.close()

	def request_close(self):
		"""Called from outside (player monitor) when segment ends or playback stops."""
		self.closed_externally = True
		try: self.close()
		except: pass

	def run(self):
		self.doModal()
		self.clearProperties()
		return self.user_clicked
