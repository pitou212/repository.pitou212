# -*- coding: utf-8 -*-
import re
import json
import base64
import time
import requests
from threading import Thread
from functools import lru_cache
from urllib.parse import unquote, unquote_plus
from caches.settings_cache import get_setting
from modules.metadata import episodes_meta, series_absolute_episode
from modules.settings import date_offset
from modules.kodi_utils import supported_media, get_property, set_property, notification, make_session
from modules.utils import adjust_premiered_date, get_datetime, jsondate_to_datetime, subtract_dates, chunks
# from modules.kodi_utils import logger

# LOCAL PATCH 2026-07-10 (port of POV debrid session-pooling): module-level
# requests.Session with connection pool + pre-set headers for the debrid cache-check
# hot path. get_external_cache_status previously used bare requests.get/post which
# re-did TCP + TLS handshake per call (~50-200ms each). With RD+TB active and
# mediafusion + torrentio + DMM three-way checks fanning out for every scrape, this
# was adding ~300-800ms per scrape. Session pool amortizes to near-zero for repeat
# hosts (which is exactly what these three services are: same 3 hosts every time).
_debrid_cache_session = make_session('https://')
_debrid_cache_session.headers.update({'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json'})

def extras():
	return ('sample', 'extra', 'extras', 'deleted', 'unused', 'footage', 'inside', 'blooper', 'bloopers',
			'making.of', 'feature', 'featurette', 'behind.the.scenes', 'trailer')

def unwanted_tags():
	return (
'tamilrockers.com', 'www.tamilrockers.com', 'www.tamilrockers.ws', 'www.tamilrockers.pl', 'www-tamilrockers-cl', 'www.tamilrockers.cl', 'www.tamilrockers.li',
'www.tamilrockerrs.pl', 'www.tamilmv.bid', 'www.tamilmv.biz', 'www.1tamilmv.org', 'gktorrent-bz', 'gktorrent-com', 'www.torrenting.com', 'www.torrenting.org',
'www-torrenting-com', 'www-torrenting-org', 'katmoviehd.pw', 'katmoviehd-pw', 'www.torrent9.nz', 'www-torrent9-uno', 'torrent9-cz', 'torrent9.cz',
'agusiq-torrents-pl', 'oxtorrent-bz', 'oxtorrent-com', 'oxtorrent.com', 'oxtorrent-sh', 'oxtorrent-vc', 'www.movcr.tv', 'movcr-com', 'www.movcr.to', '(imax)',
'imax', 'xtorrenty.org', 'nastoletni.wilkoak', 'www.scenetime.com', 'kst-vn', 'www.movierulz.vc', 'www-movierulz-ht', 'www.2movierulz.ac', 'www.2movierulz.ms',
'www.3movierulz.com', 'www.3movierulz.tv', 'www.3movierulz.ws', 'www.3movierulz.ms', 'www.7movierulz.pw', 'www.8movierulz.ws', 'mkvcinemas.live', 'www.bludv.tv',
'ramin.djawadi', 'extramovies.casa', 'extramovies.wiki', '13+', '18+', 'taht.oyunlar', 'crazy4tv.com', 'karibu', '989pa.com', 'best-torrents-net', '1-3-3-8.com',
'ssrmovies.club', 'va:', 'zgxybbs-fdns-uk', 'www.tamilblasters.mx', 'www.1tamilmv.work', 'www.xbay.me', 'crazy4tv-com', '(es)')

def audio_filter_choices():
	return (
('DOLBY DIGITAL', 'DD'), ('DOLBY DIGITAL PLUS', 'DD+'), ('DOLBY DIGITAL EX', 'DD-EX'), ('DOLBY ATMOS', 'ATMOS'), ('DOLBY TRUEHD', 'TRUEHD'),
('DTS', 'DTS'), ('DTS-HD MASTER AUDIO', 'DTS-HD MA'), ('DTS-X', 'DTS-X'), ('DTS-HD', 'DTS-HD'), ('AAC', 'AAC'), ('OPUS', 'OPUS'), ('MP3', 'MP3'),
('8CH AUDIO', '8CH'), ('7CH AUDIO', '7CH'), ('6CH AUDIO', '6CH'), ('2CH AUDIO', '2CH'))

def source_filters():
	return (
('PACK', 'PACK'), ('DOLBY VISION', '[B]D/VISION[/B]'), ('HIGH DYNAMIC RANGE (HDR)', '[B]HDR[/B]'), ('IMAX', 'IMAX'), ('HYBRID', '[B]HYBRID[/B]'), ('AV1', '[B]AV1[/B]'),
('HEVC (X265)', '[B]HEVC[/B]'), ('REMUX', 'REMUX'), ('BLURAY', 'BLURAY'), ('AI ENHANCED/UPSCALED', '[B]AI ENHANCED/UPSCALED[/B]'), ('SDR', 'SDR'), ('3D', '[B]3D[/B]'),
('DOLBY ATMOS', 'ATMOS'), ('DOLBY TRUEHD', 'TRUEHD'), ('DOLBY DIGITAL EX', 'DD-EX'), ('DOLBY DIGITAL PLUS', 'DD+'), ('DOLBY DIGITAL', 'DD'),
('DTS-HD MASTER AUDIO', 'DTS-HD MA'), ('DTS-X', 'DTS-X'), ('DTS-HD', 'DTS-HD'), ('DTS', 'DTS'), ('AAC', 'AAC'), ('OPUS', 'OPUS'), ('MP3', 'MP3'), ('8CH AUDIO', '8CH'),
('7CH AUDIO', '7CH'), ('6CH AUDIO', '6CH'), ('2CH AUDIO', '2CH'), ('DVD SOURCE', 'DVD'), ('WEB SOURCE', 'WEB'), ('MULTIPLE LANGUAGES', 'MULTI-LANG'),
('SUBTITLES', 'SUBS'))

def include_exclude_filters():
	# LOCAL PATCH 2026-06-15: HDR10+ added as separate filter (port-extension of POV per-codec sort).
	return {'hevc': 'HEVC', '3d': '3D', 'hdr': 'HDR', 'hdr10plus': 'HDR10+', 'dv': 'D/VISION', 'av1': 'AV1', 'enhanced_upscaled': 'AI ENHANCED/UPSCALED', 'hybrid': 'HYBRID'}

def get_aliases_titles(aliases):
	try: result = [i['title'] for i in aliases]
	except: result = []
	return result

def make_alias_dict(meta, title):
	aliases = []
	alternative_titles = meta.get('alternative_titles', [])
	original_title = meta['original_title']
	cunt_codes = meta.get('country_codes', [])
	country_codes = set([i.replace('GB', 'UK') for i in cunt_codes])
	if alternative_titles: aliases = [{'title': i, 'country': ''} for i in alternative_titles]
	if original_title not in alternative_titles: aliases.append({'title': original_title, 'country': ''})
	if country_codes: aliases.extend([{'title': '%s %s' % (title, i), 'country': ''} for i in country_codes])
	return aliases

def internal_results(provider, sources):
	set_property('fenlight.internal_results.%s' % provider, json.dumps(sources))

def normalize(title):
	import unicodedata
	try:
		title = ''.join(c for c in unicodedata.normalize('NFKD', title) if unicodedata.category(c) != 'Mn')
		return str(title)
	except: return title

def pack_enable_check(meta, season, episode):
	try:
		status = meta['extra_info']['status']
		if status in ('Ended', 'Canceled'): return True, True
		adjust_hours, current_date = date_offset(), get_datetime()
		episodes_data = episodes_meta(season, meta)
		unaired_episodes = [adjust_premiered_date(i['premiered'], adjust_hours)[0] for i in episodes_data]
		if None in unaired_episodes or any(i > current_date for i in unaired_episodes): return False, False
		else: return True, False
	except: pass
	return False, False

def clear_scrapers_cache(silent=False):
	from caches.base_cache import clear_cache
	for item in ('internal_scrapers', 'external_scrapers'): clear_cache(item, silent=True)
	if not silent: notification('Success')

def supported_video_extensions():
	supported_video_extensions = supported_media().split('|')
	return [i for i in supported_video_extensions if not i in ('','.zip','.rar','.iso')]

# LOCAL PATCH 2026-08-31: precompiled at import. Both run on every release title the
# debrid-cloud scrapers examine, which is once per file across the whole cloud.
_RE_TITLE_CLEAN = re.compile(r'[^A-Za-z0-9-]+')
_RE_VERSION_SUFFIX = re.compile(r'(?<=\d)v\d+(?=\D|$)')


@lru_cache(maxsize=512)
def _seas_ep_pattern(season, episode, strict):
	"""The compiled season/episode alternation for one (season, episode, strict).

	LOCAL PATCH 2026-08-31: this ~20-branch alternation was rebuilt and re-compiled on EVERY
	seas_ep_filter() call, even though only release_title varies during a scrape -- season,
	episode and strict are fixed for the whole pass. The debrid-cloud scrapers call the filter
	once per file (rd_cloud, ad_cloud, tb_cloud, pm_cloud), so a large cloud recompiled the
	identical pattern once per file while the user waited for playback. Memoised on the only
	three inputs it actually depends on.
	"""
	str_season, str_episode = str(season), str(episode)
	season_fill, episode_fill = str_season.zfill(2), str_episode.zfill(2)
	str_ep_plus_1, str_ep_minus_1 = str(episode+1), str(episode-1)
	string1 = r'(s<<S>>[.-]?e[p]?[.-]?<<E>>[.-])'
	string2 = r'(season[.-]?<<S>>[.-]?episode[.-]?<<E>>[.-])'#|([s]?<<S>>[x.]<<E>>[.-])'
	string3 = r'(s<<S>>e<<E1>>[.-]?e?<<E2>>[.-])'
	string4 = r'([.-]<<S>>[.-]<<E>>[.-])' if strict else r'([.-]<<S>>[.-]?<<E>>[.-])'
	string5 = r'(episode[.-]?<<E>>[.-])'
	string6 = r'([.-]e[p]?[.-]?<<E>>[.-])'
	# LOCAL PATCH 2026-08-27: the NxNN guard was `\d+x\d+`, which is meant to spot an
	# explicit season-x-episode marker ('1x04') and stand down when one is present. It also
	# matched RESOLUTIONS, so any file naming its dimensions -- 'Youjo Senki - 04v3 -
	# Campus Life (BDremux 1920x1080)' -- disabled this pattern and the episode became
	# unmatchable, leaving a 3.8MB preview as the only candidate for episode 4.
	# A season-x-episode marker is at most 2 digits by 3; a resolution is 3-4 by 3-4.
	string7 = r'(^(?=.*\.e?0*<<E>>\.)(?:(?!((?:s|season)[.-]?\d+[.-x]?(?:ep?|episode)[.-]?\d+)|(?<!\d)\d{1,2}x\d{1,3}(?!\d)).)*$)'
	string8 = r'([s]?<<S>>x<<E>>[.-])'
	string_list = []
	string_list_append = string_list.append
	string_list_append(string1.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string1.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string1.replace('<<S>>', season_fill).replace('<<E>>', str_episode))
	string_list_append(string1.replace('<<S>>', str_season).replace('<<E>>', str_episode))
	string_list_append(string2.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string2.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string2.replace('<<S>>', season_fill).replace('<<E>>', str_episode))
	string_list_append(string2.replace('<<S>>', str_season).replace('<<E>>', str_episode))
	string_list_append(string3.replace('<<S>>', season_fill).replace('<<E1>>', str_ep_minus_1.zfill(2)).replace('<<E2>>', episode_fill))
	string_list_append(string3.replace('<<S>>', season_fill).replace('<<E1>>', episode_fill).replace('<<E2>>', str_ep_plus_1.zfill(2)))
	string_list_append(string4.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string4.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string5.replace('<<E>>', episode_fill))
	string_list_append(string5.replace('<<E>>', str_episode))
	string_list_append(string6.replace('<<E>>', episode_fill))
	string_list_append(string7.replace('<<E>>', episode_fill))
	string_list_append(string8.replace('<<S>>', season_fill).replace('<<E>>', episode_fill))
	string_list_append(string8.replace('<<S>>', str_season).replace('<<E>>', episode_fill))
	string_list_append(string8.replace('<<S>>', season_fill).replace('<<E>>', str_episode))
	string_list_append(string8.replace('<<S>>', str_season).replace('<<E>>', str_episode))
	final_string = '|'.join(string_list)
	return re.compile(final_string)


def seas_ep_filter(season, episode, release_title, split=False, return_match=False, strict=False):
	"""Does `release_title` name this season/episode?

	LOCAL PATCH 2026-08-27 -- `strict` tightens string4 for ANIME ONLY. string4 joins the
	season and episode with an OPTIONAL separator, so '.101.' reads as season 1 episode 01.
	For Western TV that is deliberate and correct: 'Show.101.720p' really does mean S01E01.
	For anime it is a disaster, because 101 there is an absolute episode number --
	'Naruto.101.v4.480p.mkv' was answering requests for episode 1, and 'Naruto.110' was
	answering episode 10. Not a preview but a completely different episode, which is worse
	because it looks plausible on screen.

	The two conventions genuinely conflict, so this cannot be fixed globally. Callers that
	know they are dealing with anime pass strict=True; everyone else keeps today's exact
	behaviour. 'Naruto.001' is unaffected either way -- it matches through string7.
	"""
	release_title = _RE_TITLE_CLEAN.sub('.', unquote(release_title).replace('\'', '')).lower()
	# LOCAL PATCH 2026-08-27: drop the re-release version suffix glued to an episode
	# number -- '04v3' means episode 4, version 3. Anime groups revise releases constantly
	# so v2/v3 are everywhere, and with the suffix attached NOT ONE pattern below matches:
	# '.04v3.' is neither '.04.' nor 'e04'. That is how Saga of Tanya the Evil ended up
	# playing a preview. In the 'Youjo Senki v3 (BDremux)' pack the real 6.60GB
	# 'Youjo Senki - 04v3 - Campus Life' did not match episode 4 at all, while the 3.8MB
	# 'Youjo Senki Episode 04 - ... Preview' matched cleanly -- so the preview was not
	# beating the episode, it was the ONLY candidate.
	# Safe for every other convention: a digit must immediately precede the 'v', so
	# 'AV1', 'x264', 'DivX3' and '1920x1080' are untouched, and Western 'S01E05v2'
	# correctly becomes 'S01E05'.
	release_title = _RE_VERSION_SUFFIX.sub('', release_title)
	reg_pattern = _seas_ep_pattern(season, episode, strict)
	if split: return release_title.split(re.search(reg_pattern, release_title).group(), 1)[1]
	if return_match: return re.search(reg_pattern, release_title).group()
	return bool(re.search(reg_pattern, release_title))

# LOCAL PATCH 2026-08-27: anime episode numbering for file selection inside packs.
#
# THE PROBLEM
# seas_ep_filter() above matches a filename against TMDb's season/episode. That is
# right for Western TV and wrong for anime, because anime releases are not numbered
# the way TMDb files them. Three numberings are in active use and all three are
# "correct" -- they just count from different places:
#
#   Re:ZERO, the episode TMDb calls S01E50, appears in packs as
#     "Re Zero ... - 50.mkv"                    series-absolute
#     "Re Zero ... Season 2 - 24.mkv"           release-season-relative
#     "Re Zero ... 2nd Season Part 2 - 12.mkv"  cour-relative
#
# So a season pack that Fen Light happily lists would resolve to nothing on click:
# seas_ep_filter looked for episode 50 in a pack whose files stop at 12, found no
# file, and resolve_magnet returned None. The source appeared broken.
#
# THE APPROACH, AND WHY IT IS ORDERED RATHER THAN OR-ED
# The obvious fix -- match ANY of the three numbers -- is wrong. A complete-series
# pack contains a file "12" as well as the file "50" we actually want, so an OR
# would happily play episode 12 instead. Order fixes this without any knowledge of
# what kind of pack it is: try the HIGHEST episode number first and stop at the
# first one that matches anything.
#
#   complete-series pack -> "50" exists, wins immediately
#   season pack          -> no "50", falls through to "24"
#   cour pack            -> neither, falls through to "12"
#
# Each pack is matched by the numbering it actually uses. The ordering is what makes
# this safe, and it orders by episode number alone -- TMDb's own numbering gets no
# special priority, because for anime it is usually the one a release does NOT use.


def anime_episode_candidates(meta, tmdb_id, season, episode):
	"""Alternate (season, episode) pairs this anime episode may be numbered as.

	Ordered widest-first, see the note above. Empty for non-anime, which leaves
	every existing caller behaving exactly as it did.
	"""
	try:
		from modules.metadata import is_anime_check
		if not is_anime_check(meta, tmdb_id): return []
	except Exception: return []
	try: season, episode = int(season), int(episode)
	except (TypeError, ValueError): return []
	# LOCAL PATCH 2026-08-27: the primary pair is included so that a NON-EMPTY result
	# means 'this is anime' exactly, rather than incidentally. pick_episode_files uses
	# that as its signal to match strictly, and a season-1 anime with no Fribb row and
	# no earlier seasons would otherwise return [] and be treated as Western TV.
	# Harmless downstream: ordered_episode_candidates prepends and de-duplicates it.
	candidates = [(season, episode)]
	# series-absolute: TMDb's own season_data is enough, no mapping needed, so this
	# works even for shows Fribb has no cour row for (Naruto is one such).
	# LOCAL PATCH 2026-09-02: was an inlined `sum(earlier episode_count) + episode` with no
	# already-absolute guard, which is wrong for every show TMDb numbers absolutely. It
	# turned One Piece S02E62 into 123 and Naruto S02E53 into 105 -- both REAL OTHER
	# EPISODES -- and ordered_episode_candidates below sorts DESCENDING, so the bogus number
	# was tried FIRST against a complete-series pack and won. Now shared with
	# scrapers/external.py, which publishes the same number as data['absolute_episode'], so
	# the number the providers get and the number the debrid layer picks a file with cannot
	# drift apart. `!= episode` only suppresses a duplicate of candidates[0].
	try:
		absolute = series_absolute_episode(meta, season, episode)
		if absolute and absolute != episode: candidates.append((season, absolute))
	except Exception: pass
	try:
		from caches import fribb_mappings
		# LOCAL PATCH 2026-09-05: allow_repair=False -- these candidates are matched against
		# release FILENAMES, both when scraping and when picking a file out of a pack, so
		# they must use numbering releases actually carry. See the same flag at
		# scrapers/external.py and the note on the repair branch in fribb_mappings.
		info = fribb_mappings.find_cour_by_tmdb_coords(tmdb_id, season, episode, allow_repair=False) or {}
		# cour_season is season.tvdb -- the season number RELEASES use. TMDb files
		# every Re:ZERO cour under season 1, so `season` cannot stand in for it.
		cour_season = info.get('cour_season') or season
		for number in (info.get('season_ep'), info.get('cour_ep')):
			if number: candidates.append((int(cour_season), int(number)))
	except Exception: pass
	return candidates


# LOCAL PATCH 2026-08-27: things that sit inside a pack but are not the show -- credit
# sequences, previews, menus, extras. They routinely carry an episode number, so the
# episode test alone cannot tell them from the episode: in SeaDex's Frieren PMR pack
# 'NCOP 01' and 'NCED 01' (0.39GB each) both answer a request for episode 1 alongside the
# real 6.99GB file. Whichever the torrent happens to list first is what played, which is
# why the symptom was intermittent.
#
# extras() does not cover any of this -- it has no ncop/nced/preview/menu -- and it is used
# by the movie path and the cloud scrapers, so it is left alone and this sits beside it.
#
# magneto's providers/torrents/seadex.py has an equivalent `_NOT_AN_EPISODE` for its own
# file picking. The module boundary prevents sharing (magneto cannot import Fen Light), so
# the two are kept in step by hand -- change one, look at the other.
_NON_EPISODE = re.compile(
	r'(?:^|[^a-z0-9])(?:nc)?(?:op|ed)\d*(?:[^a-z0-9]|$)|'
	r'(?:^|[^a-z0-9])(?:preview|pv|menu|creditless|clean|textless|sample|trailer|teaser|'
	r'promo|cm|spot|bonus|interview|omake|recap|digest|prologue|epilogue|'
	r'making\.?of|behind\.?the\.?scenes|featurette|blooper|bloopers|outtake|outtakes|'
	# LOCAL PATCH 2026-08-27 (same day, second pass): the trailing \d* is the whole point.
	# The first version only allowed a number after op/ed, so 'NCOP1' was caught but
	# 'Youjo Senki PV1.mkv' was not -- and promos are numbered as a matter of course
	# (PV1, PV2, PV3), which is exactly how a Saga of Tanya the Evil promo kept playing.
	# Same hole applied to Preview2, CM1, Menu1, Promo1, Spot2 and Teaser1.
	r'commentary|karaoke|logo|scan|scans|booklet)\d*(?:[^a-z0-9]|$)', re.I)


def non_episode_file(name, title=None):
	"""True when this file is in the pack but is not an episode of the show.

	`title` is the show/episode title. A word is never used as evidence when it appears in
	the title itself -- the same guard the movie branch already applies via
	`extras_filtering_list` -- so a show actually called "Preview" is not wiped out.
	"""
	name = (name or '').lower()
	if not name: return False
	title = (title or '').lower()
	match = _NON_EPISODE.search(name)
	if match and match.group(0).strip('.-_ ') not in title: return True
	# the long-standing extras vocabulary, same title guard as the movie path
	return any(word in name for word in extras() if word not in title)


def ordered_episode_candidates(season, episode, candidates=None):
	"""Every numbering this episode may be called, highest episode number first.

	LOCAL PATCH 2026-08-27: the single home for this ordering. It was written twice --
	here and again in magneto's seadex provider, whose copy said in its own docstring
	that it "mirrors" this one. Two copies of a rule this subtle will drift, so the
	scrape path now publishes the result of THIS function in data['episode_candidates']
	and the provider reads it instead of recomputing.

	Highest episode number first -- including TMDb's own pair, which for anime is
	usually NOT what a release uses and must not get priority just for being ours.
	Verified the hard way: pinning it first made Naruto S04E01 (absolute 159) match
	'Naruto - 001', and AoT S03E20 (absolute 57) match '- 20' in an absolute-numbered
	pack. Both play the WRONG EPISODE, which is worse than the failure being fixed.
	Descending is safe in the way ascending is not: a low number can turn up by
	coincidence inside a pack numbered a wider way, but a pack numbered a narrow way
	has no file carrying the wider number at all -- so a high candidate never matches
	spuriously, it simply finds nothing and the search falls through.
	"""
	ordered, seen = [], set()
	for pair in [(season, episode)] + list(candidates or []):
		if pair[0] is None or pair[1] is None or pair in seen: continue
		seen.add(pair)
		ordered.append(pair)
	ordered.sort(key=lambda pair: -int(pair[1]))
	return ordered


_SIZE_KEYS = ('size', 'bytes', 's', 'filesize', 'length')


def _file_size(f):
	"""Bytes for a debrid file dict, whatever the provider calls the field.

	TorBox/EasyDebrid/Premiumize use 'size', Real-Debrid 'bytes', AllDebrid 's'.
	Returns 0 when unknown, which leaves such files in their original order.
	"""
	if not isinstance(f, dict): return 0
	for k in _SIZE_KEYS:
		v = f.get(k)
		if v is None: continue
		try: return int(v)
		except (TypeError, ValueError): continue
	return 0


def pick_episode_files(files, season, episode, key=None, candidates=None, title=None):
	"""(matching files, the (season, episode) pair that matched them), largest first.

	Returns the pair as well because the debrid modules call seas_ep_filter a second
	time with split=True on a file they have already matched, to inspect what follows
	the episode marker. That second call must use the SAME numbering -- with split=True
	a miss is not False, it is re.search(...) returning None and .group() raising.
	It stays non-strict, which is safe: non-strict matches a superset of strict.

	LOCAL PATCH 2026-08-27 -- two defences against playing the wrong file out of a pack,
	both here because all five debrid modules route through this one function:

	  * credit sequences, previews and extras are dropped before matching. They carry
	    episode numbers, so the episode test cannot tell them apart -- see non_episode_file.
	  * whatever still matches is returned LARGEST FIRST. Every caller takes the first hit,
	    and until now that was simply the torrent's own file order, so a 0.39GB NCOP could
	    beat a 6.99GB episode purely by being listed earlier. Measured over 142 resolutions
	    against real pack listings: 20% matched more than one file, and in 15 of those 28
	    the first was not the largest.

	`strict` episode matching is enabled whenever candidates are supplied, which is exactly
	when the caller has told us this is anime (see anime_episode_candidates).
	"""
	def _name(f):
		if key is None: return f
		# callable for the callers whose match text is derived, not a plain field
		# (Premiumize matches on the basename of item['path'])
		return key(f) if callable(key) else f[key]
	strict = bool(candidates)
	try: usable = [f for f in files if not non_episode_file(_name(f), title)]
	except Exception: usable = list(files)
	# Never let the filter empty the pack -- a release whose every file trips a keyword is
	# better matched loosely than not at all.
	if not usable: usable = list(files)
	# LOCAL PATCH 2026-08-27: and a size floor, which needs no vocabulary at all. Saga of
	# Tanya the Evil packs ship an 'Extra/Preview/' folder holding a 3-5MB promo for EVERY
	# episode, beside 1GB episodes -- 'Youjo Senki 04 Preview.mkv' really is episode 4's
	# preview, so it matches an episode-4 request perfectly. The name test catches these,
	# but only because someone wrote "Preview"; the next pack will use a word nobody
	# listed. A file at 0.4% of the pack's typical size is not an episode whatever it is
	# called, so drop anything under a tenth of the median -- a 25x margin over the real
	# previews, and far below any genuine episode (even a 480p copy in a mixed pack runs
	# ~27% of the median).
	if len(usable) >= 4:
		sizes = sorted(_file_size(f) for f in usable)
		median = sizes[len(sizes) // 2]
		if median > 0:
			floor = median * 0.10
			big_enough = [f for f in usable if _file_size(f) >= floor]
			if big_enough: usable = big_enough
	for pair in ordered_episode_candidates(season, episode, candidates):
		try: hits = [f for f in usable if seas_ep_filter(pair[0], pair[1], _name(f), strict=strict)]
		except Exception: continue
		if hits:
			hits.sort(key=_file_size, reverse=True)
			# LOCAL PATCH 2026-08-31: publish the file we actually chose out of the pack.
			# Every caller takes hits[0] and the debrid modules then return ONLY a url --
			# TorBox's is an opaque uuid with no filename in it -- so nothing downstream
			# could tell which episode was really played. player.playing_filename is the
			# PACK name, which made subtitle release matching blind for pack playback:
			# 'Reply.1988.(2015).Complete.2160p.UHDTV...-HThoreau' scored 5 against
			# per-episode candidates because the packager's name can never match theirs.
			# All five debrid modules route through here, so this is the one honest place
			# to record it. Consumers must re-verify -- see subtitles._played_name().
			try: set_property('fenlight.playing.pack_file', str(_name(hits[0])))
			except Exception: pass
			return hits, pair
	return [], (season, episode)


def find_season_in_release_title(release_title):
	release_title = re.sub(r'[^A-Za-z0-9-]+', '.', unquote(release_title).replace('\'', '')).lower()
	match = None
	regex_list = [r's(\d+)', r's\.(\d+)', r'(\d+)x', r'(\d+)\.x', r'season(\d+)', r'season\.(\d+)']
	for item in regex_list:
		try:
			match = re.search(item, release_title)
			if match:
				match = int(str(match.group(1)).lstrip('0'))
				break
		except: pass
	return match

def check_title(title, release_title, aliases, year, season, episode):
	try:
		all_titles = [title]
		if aliases: all_titles += aliases
		cleaned_titles = []
		cleaned_titles_append = cleaned_titles.append
		year = str(year)
		for i in all_titles:
			cleaned_titles_append(
				i.lower().replace('\'', '').replace(':', '').replace('!', '').replace('(', '').replace(')', '').replace('&', 'and').replace(' ', '.').replace(year, ''))
		release_title = strip_non_ascii_and_unprintable(release_title).lstrip('/ ').replace(' ', '.').replace(':', '.').lower()
		releasetitle_startswith = release_title.startswith
		unwanted = unwanted_tags()
		for i in unwanted:
			if releasetitle_startswith(i):
				i_startswith = i.startswith
				pattern = r'\%s' % i if i_startswith('[') or i_startswith('+') else r'%s' % i
				release_title = re.sub(r'^%s' % pattern, '', release_title, 1, re.I)
		release_title = release_title.lstrip('.-:/')
		release_title = re.sub(r'^\[.*?]', '', release_title, 1, re.I)
		release_title = release_title.lstrip('.-[](){}:/')
		if season:
			if season == 'pack': hdlr = ''
			else:
				try: hdlr = seas_ep_filter(season, episode, release_title, return_match=True)
				except: return False
		else: hdlr = year
		if hdlr:
			release_title = release_title.split(hdlr.lower())[0]
			release_title = release_title.replace(year, '').replace('(', '').replace(')', '').replace('&', 'and').rstrip('.-').rstrip('.').rstrip('-').replace(':', '')
			if not any(item in release_title for item in cleaned_titles): return False
			# if not any(release_title == i for i in cleaned_titles): return False
		else:
			release_title = release_title.replace(year, '').replace('(', '').replace(')', '').replace('&', 'and').rstrip('.-').rstrip('.').rstrip('-').replace(':', '')
			if not any(i in release_title for i in cleaned_titles): return False
		return True
	except: return True

def strip_non_ascii_and_unprintable(text):
	try:
		result = ''.join(char for char in text if char in printable)
		return result.encode('ascii', errors='ignore').decode('ascii', errors='ignore')
	except: pass
	return text

def release_info_format(release_title):
	try:
		release_title = url_strip(release_title)
		release_title = release_title.lower().replace("'", "").lstrip('.').rstrip('.')
		title = '.%s.' % re.sub(r'[^a-z0-9-~]+', '.', release_title).replace('.-.', '.').replace('-.', '.').replace('.-', '.').replace('--', '.')
		return title
	except:
		return release_title.lower()

def clean_title(title):
	try:
		if not title: return
		title = title.lower()
		title = re.sub(r'&#(\d+);', '', title)
		title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
		title = title.replace('&quot;', '\"').replace('&amp;', '&')
		title = re.sub(r'\n|([\[({].+?[})\]])|([:;–\-"\',!_.?~$@])|\s', '', title)
	except: pass
	return title

def url_strip(url):
	try:
		url = unquote_plus(url)
		if 'magnet:' in url: url = url.split('&dn=')[1]
		url = url.lower().replace("'", "").lstrip('.').rstrip('.')
		title = re.sub(r'[^a-z0-9]+', ' ', url)
		if 'http' in title: return None
		if title == '': return None
		return title
	except: return None

# LOCAL PATCH 2026-08-27: a disc source with no resolution token is not SD.
#
# get_release_quality() only recognises 720p/1080p/4K, so a release whose name says
# what it IS but not what size it is falls through to the 'SD' default. That is very
# wrong for the biggest files in the list: an 84GB "Bleach - Sennen Kessen-hen -
# Season 01 BD Remux [FLAC]" pack was being labelled SD, which sorts it last and hides
# it entirely from anyone with a 1080p minimum. Disc-sourced releases carry the tag but
# often omit the resolution, because for them it is assumed.
#
# 1080p is the floor for a Blu-ray, so it is the safe answer -- a 2160p disc release
# says 2160p and is caught by get_release_quality() before this ever runs.
_DISC_SOURCE = re.compile(r'remux|bluray|blu\.ray|bdrip|bd\.rip|bdmv|blu-ray', re.I)
# Explicit low-resolution and DVD markers must still win: "BDRip 480p" is a Blu-ray
# SOURCE at SD resolution, and assuming 1080p for it would be a straight downgrade in
# accuracy rather than an upgrade.
_LOW_RES = re.compile(r'480p|576p|360p|240p|\bdvd|dvdrip|dvd\.rip|\bvhs', re.I)


def get_file_info(name_info=None, url=None, default_quality='SD'):
	title = None
	if name_info: title = name_info
	elif url: title = url_strip(url)
	if not title: return 'SD', ''
	quality = get_release_quality(title)
	if not quality and _DISC_SOURCE.search(title) and not _LOW_RES.search(title):
		quality = '1080p'
	quality = quality or default_quality
	info = get_info(title)
	return quality, info

def get_release_quality(release_info):
	if any(i in release_info for i in ('.scr.', 'screener', 'dvdscr', 'dvd.scr', '.r5', '.r6')):
		return 'SCR'
	if any(i in release_info for i in ('.cam.', 'camrip', 'hdcam', '.hd.cam', 'hqcam', '.hq.cam', 'cam.rip', 'dvdcam')):
		return 'CAM'
	if any(i in release_info for i in ('.tc.', '.ts.', 'tsrip', 'hdts', 'hdtc', '.hd.tc', 'dvdts', 'telesync', 'tele.sync', 'telecine', 'tele.cine')):
		return 'TELE'
	if any(i in release_info for i in ('720', '720p', '720i', 'hd720', '720hd', 'hd720p', '72o', '72op')):
		return '720p'
	if any(i in release_info for i in ('1080', '1080p', '1080i', 'hd1080', '1080hd', 'hd1080p', 'm1080p', 'fullhd', 'full.hd', '1o8o', '1o8op',
		'108o', '108op', '1o80', '1o80p')): return '1080p'
	if any(i in release_info for i in ('.4k', 'hd4k', '4khd', '.uhd', 'ultrahd', 'ultra.hd', 'hd2160', '2160hd', '2160', '2160p', '216o', '216op')):
		return '4K'
	return None

def get_info(title):
	# thanks 123Venom and gaiaaaiaai, whom I knicked most of this code from. :)
	info = []
	info_append = info.append
	if any(i in title for i in ('.3d.', '.sbs.', '.hsbs', 'sidebyside', 'side.by.side', 'stereoscopic', '.tab.', '.htab.', 'topandbottom', 'top.and.bottom')):
		info_append('[B]3D[/B]')
	if '.sdr' in title:
		info_append('SDR')
	elif any(i in title for i in ('dolby.vision', 'dolbyvision', '.dovi.', '.dv.')):
		info_append('[B]D/VISION[/B]')
	elif any(i in title for i in ('2160p.bluray.hevc.truehd', '2160p.bluray.hevc.dts', '2160p.bluray.hevc.lpcm', '2160p.blu.ray.hevc.truehd', '2160p.blu.ray.hevc.dts',
		'2160p.uhd.bluray', '2160p.uhd.blu.ray', '2160p.us.bluray.hevc.truehd', '2160p.us.bluray.hevc.dts', '.hdr.', 'hdr10', 'hdr.10', 'uhd.bluray.2160p',
		'uhd.blu.ray.2160p')):
		info_append('[B]HDR[/B]')
	elif all(i in title for i in ('2160p', 'remux')):
		info_append('[B]HDR[/B]')
	if '[B]D/VISION[/B]' in info:
		if any(i in title for i in ('.hdr.', '.hdr10.', 'hdr.10')) or 'hybrid' in title:
			info_append('[B]HDR[/B]')
		if '[B]HDR[/B]' in info:
			info_append('[B]HYBRID[/B]')
	# LOCAL PATCH 2026-06-15: HDR10+ token (release_info_format normalizes "+" → "."
	# so HDR10+ literal becomes "hdr10." which is ambiguous with HDR10; rely on
	# the explicit "hdr10.plus" / "hdr10plus" tokens release groups actually use.
	# HDR10+ titles also keep the broad [B]HDR[/B] tag (they ARE HDR), so existing
	# HDR=Exclude users still filter HDR10+ out without extra config.
	if '[B]HDR[/B]' in info and any(i in title for i in ('hdr10.plus', 'hdr10plus', '.hdr10plus.')):
		info_append('[B]HDR10+[/B]')
	if any(i in title for i in ('avc', 'h264', 'h.264', 'x264', 'x.264')):
		info_append('AVC')
	elif '.av1.' in title:
		info_append('[B]AV1[/B]')
	elif any(i in title for i in ('h265', 'h.265', 'hevc', 'x265', 'x.265')):
		info_append('[B]HEVC[/B]')
	elif any(i in info for i in ('[B]HDR[/B]', '[B]D/VISION[/B]')):
		info_append('[B]HEVC[/B]')
	if any(i in title for i in ('.imax.', '.(imax).', '.(.imax.).')):
		info_append('IMAX')
	elif any(i in title for i in ('.enhanced.', '.upscaled.', '.enhance.', '.upscale.', '.ai.')):
		info_append('[B]AI ENHANCED/UPSCALED[/B]')
	if '.atvp' in title:
		info_append('APPLETV+')
	elif any(i in title for i in ('xvid', '.x.vid')):
		info_append('XVID')
	elif any(i in title for i in ('divx', 'div2', 'div3', 'div4')):
		info_append('DIVX')
	if any(i in title for i in ('remux', 'bdremux')):
		info_append('REMUX')
	if any(i in title for i in ('bluray', 'blu.ray', 'bdrip', 'bd.rip')):
		info_append('BLURAY')
	elif any(i in title for i in ('dvdrip', 'dvd.rip')):
		info_append('DVD')
	elif any(i in title for i in ('.web.', 'webdl', 'web.dl', 'web-dl', 'webrip', 'web.rip')):
		info_append('WEB')
	elif 'hdtv' in title:
		info_append('HDTV')
	elif 'pdtv' in title:
		info_append('PDTV')
	elif any(i in title for i in ('.hdrip', '.hd.rip')):
		info_append('HDRIP')
	if 'atmos' in title:
		info_append('ATMOS')
	if any(i in title for i in ('true.hd', 'truehd')):
		info_append('TRUEHD')
	if any(i in title for i in ('dolby.digital.plus', 'dolbydigital.plus', 'dolbydigitalplus', 'dd.plus.', 'ddplus', '.ddp.', 'ddp2', 'ddp5', 'ddp7', 'eac3', '.e.ac3')):
		info_append('DD+')
	elif any(i in title for i in ('.dd.ex.', 'ddex', 'dolby.ex.', 'dolby.digital.ex.', 'dolbydigital.ex.')):
		info_append('DD-EX')
	elif any(i in title for i in ('dd2.', 'dd5', 'dd7', 'dolby.digital', 'dolbydigital', '.ac3', '.ac.3.', '.dd.')):
		info_append('DD')
	if 'aac' in title:
		info_append('AAC')
	elif 'mp3' in title:
		info_append('MP3')
	elif '.flac.' in title:
		info_append('FLAC')
	elif 'opus' in title and not title.endswith('opus.'):
		info_append('OPUS')
	if any(i in title for i in ('.dts.x.', 'dtsx')):
		info_append('DTS-X')
	elif any(i in title for i in ('hd.ma', 'hdma')):
		info_append('DTS-HD MA')
	elif any(i in title for i in ('dts.hd.', 'dtshd')):
		info_append('DTS-HD')
	elif '.dts' in title:
		info_append('DTS')
	if any(i in title for i in ('ch8.', '8ch.', '7.1ch', '7.1.')):
		info_append('8CH')
	elif any(i in title for i in ('ch7.', '7ch.', '6.1ch', '6.1.')):
		info_append('7CH')
	elif any(i in title for i in ('ch6.', '6ch.', '5.1ch', '5.1.')):
		info_append('6CH')
	elif any(i in title for i in ('ch2', '2ch', '2.0ch', '2.0.', 'audio.2.0.', 'stereo')):
		info_append('2CH')
	if '.wmv' in title:
		info_append('WMV')
	elif any(i in title for i in ('.mpg', '.mp2', '.mpeg', '.mpe', '.mpv', '.mp4', '.m4p', '.m4v', 'msmpeg', 'mpegurl')):
		info_append('MPEG')
	elif '.avi' in title:
		info_append('AVI')
	elif any(i in title for i in ('.mkv', 'matroska')):
		info_append('MKV')
	if any(i in title for i in ('hindi.eng', 'ara.eng', 'ces.eng', 'chi.eng', 'cze.eng', 'dan.eng', 'dut.eng', 'ell.eng', 'esl.eng', 'esp.eng', 'fin.eng', 'fra.eng',
		'fre.eng', 'frn.eng', 'gai.eng', 'ger.eng', 'gle.eng', 'gre.eng', 'gtm.eng', 'heb.eng', 'hin.eng', 'hun.eng', 'ind.eng', 'iri.eng', 'ita.eng', 'jap.eng',
		'jpn.eng', 'kor.eng', 'lat.eng', 'lebb.eng', 'lit.eng', 'nor.eng', 'pol.eng', 'por.eng', 'rus.eng', 'som.eng', 'spa.eng', 'sve.eng', 'swe.eng', 'tha.eng',
		'tur.eng', 'uae.eng', 'ukr.eng', 'vie.eng', 'zho.eng', 'dual.audio', 'multi')):
		info_append('MULTI-LANG')
	if any(i in title for i in ('1xbet', 'betwin')):
		info_append('ADS')
	if any(i in title for i in ('subita', 'subfrench', 'subspanish', 'subtitula', 'swesub', 'nl.subs', 'subbed')):
		info_append('SUBS')
	return ' | '.join(filter(None, info))

def get_cache_expiry(media_type, meta, season):
	try:
		current_date = get_datetime()
		if media_type == 'movie':
			premiered = jsondate_to_datetime(meta['premiered'], '%Y-%m-%d', remove_time=True)
			difference = subtract_dates(current_date, premiered)
			if difference == 0: single_expiry = 3
			elif difference <= 7: single_expiry = 24
			elif difference <= 14: single_expiry = 48
			elif difference <= 21: single_expiry = 72
			elif difference <= 30: single_expiry = 96
			elif difference <= 60: single_expiry = 168
			else: single_expiry = 336
			season_expiry, show_expiry = 0, 0
		else:
			recently_ended = False
			extra_info = meta['extra_info']
			ended = extra_info['status'] in ('Ended', 'Canceled')
			premiered = adjust_premiered_date(meta['premiered'], date_offset())[0]
			difference = subtract_dates(current_date, premiered)
			last_episode_to_air = jsondate_to_datetime(extra_info['last_episode_to_air']['air_date'], '%Y-%m-%d', remove_time=True)
			last_ep_difference = subtract_dates(current_date, last_episode_to_air)
			if ended and last_ep_difference <= 14: recently_ended = True
			if not ended or recently_ended:
				if difference == 0: single_expiry = 3
				elif difference <= 3: single_expiry = 24
				elif difference <= 7: single_expiry = 72
				else: single_expiry = 168
				if meta['total_seasons'] == season:
					if last_ep_difference <= 7: season_expiry = 72
					else: season_expiry = 240
				else: season_expiry = 720
				show_expiry = 240
			else: single_expiry, season_expiry, show_expiry = 240, 720, 720
	except: single_expiry, season_expiry, show_expiry = 72, 72, 240
	return single_expiry, season_expiry, show_expiry

def get_external_cache_status(debrid, unchecked_hashes, data, active_debrid):
	def _process(service, hashes):
		result = []
		if service in ('mediafusion', 'torrentio'):
			if service == 'mediafusion':
				base_link, name_test = 'https://mediafusion.elfhosted.com/%s=%s' % (debrid_name, token), '⚡'
				params = json.dumps({'enable_catalogs': False, 'max_streams_per_resolution': 99, 'torrent_sorting_priority':[], 'certification_filter': ['Disable'],
											'nudity_filter': ['Disable'], 'streaming_provider': {'token': token, 'service': debrid_name,
											'only_show_cached_streams': True}}).encode('utf-8')
				headers = {'encoded_user_data': base64.b64encode(params).decode('utf-8')}
			elif service == 'torrentio':
				base_link, name_test = 'https://torrentio.strem.fun/%s=%s' % (debrid_name, token), '[RD+]'
				headers = {'User-Agent': 'Mozilla/5.0'}
			try:
				if 'tvshowtitle' in data: url = '%s%s' % (base_link, '/stream/series/%s:%s:%s.json' % (imdb_id, data['season'], data['episode']))
				else: url = '%s%s' % (base_link, '/stream/movie/%s.json' % imdb_id)
				result = _debrid_cache_session.get(url, headers=headers, timeout=9)
				result = result.json()['streams']
				if result:
					result = [re.search(r'\b\w{40}\b', i.get('url')) for i in result if name_test in i['name']]
					result = [i.group() for i in result if i]
			except: pass
		elif service == 'dmm':
			import ctypes, random
			def get_secret():
				def calc_value_alg(t, n, const):
					temp = t ^ n
					t = ctypes.c_long((temp * const)).value
					t4 = ctypes.c_long(t << 5).value
					t5 = ctypes.c_long((t & 0xFFFFFFFF) >> 27).value
					return t4 | t5
				def slice_hash(s, n):
					half = int(len(s) // 2)
					left_s, right_s = s[:half], s[half:]
					left_n, right_n = n[:half], n[half:]
					l = ''.join(ls + ln for ls, ln in zip(left_s, left_n))
					return l + right_n[::-1] + right_s[::-1]
				def generate_hash(e):
					t = ctypes.c_long(0xDEADBEEF ^ len(e)).value
					a = 1103547991 ^ len(e)
					for ch in e:
						n = ord(ch)
						t = calc_value_alg(t, n, 2654435761)
						a = calc_value_alg(a, n, 1597334677)
					t = ctypes.c_long(t + ctypes.c_long(a * 1566083941).value).value
					a = ctypes.c_long(a + ctypes.c_long(t * 2024237689).value).value
					return (ctypes.c_long(t ^ a).value & 0xFFFFFFFF)
				ran = random.randrange(10 ** 80)
				hex_str = f"{ran:064x}"[:8]
				timestamp = int(time.time())
				dmmProblemKey = f"{hex_str}-{timestamp}"
				s = generate_hash(dmmProblemKey)
				s = f"{s:x}"
				n = generate_hash("debridmediamanager.com%%fe7#td00rA3vHz%VmI-" + hex_str)
				n = f"{n:x}"
				solution = slice_hash(s, n)
				return dmmProblemKey, solution
			def fetch(hash_chunk):
				try:
					json_data = {'dmmProblemKey': dmmProblemKey, 'solution': solution, 'imdbId': imdb_id, 'hashes': hash_chunk}
					r = _debrid_cache_session.post('https://debridmediamanager.com/api/availability/check', json=json_data, timeout=9).json()
					r = [i['hash'] for i in r['available'] if 'hash' in i]
					result_extend(r)
				except: pass
			result = []
			result_extend = result.extend
			dmmProblemKey, solution = get_secret()
			unchecked_hashes_chunks = list(chunks(unchecked_hashes, 100))
			threads = [Thread(target=fetch, args=(item,)) for item in unchecked_hashes_chunks]
			[i.start() for i in threads]
			[i.join() for i in threads]
		results.extend(result)
	try:
		results = []
		imdb_id = data['imdb']
		debrid_name, services, token = {'Real-Debrid': ('realdebrid', ['torrentio'], get_setting('fenlight.rd.token')),
										'AllDebrid': ('alldebrid', ['mediafusion'], get_setting('fenlight.ad.token'))}[debrid]
		threads = [Thread(target=_process, args=(item, unchecked_hashes)) for item in services]
		[i.start() for i in threads]
		[i.join() for i in threads]
		results = list(set(results))
	except: pass
	if debrid == 'Real-Debrid':
		try: _process('dmm', [i for i in unchecked_hashes if not i in results])
		except: pass
	return results

# LOCAL PATCH 2026-08-29: pre-signed URL expiry, shared by the http_streams and aiostreams
# scrapers.
#
# Pre-signed S3/R2 links carry the moment they die in their own query string -- X-Amz-Date
# plus X-Amz-Expires -- so an expired one can be recognised with NO network call. Measured
# over 427 http_streams sources, each fetched for real and checked for a container magic
# number, evaluated against the time its label was taken:
#
#     150 pre-signed (35%)   36 expired -> all dead    114 fresh -> all alive
#     0 wrongly dropped, 0 wrongly kept
#
# Both scrapers see these URLs: the same FSL / R2 / PixelDrain hosts reach AIOStreams through
# the manifest, where 8 of 9 pre-signs on Dune Part Two and 7 of 7 on LOTR Fellowship were
# already expired.
PRESIGN_GRACE = 300           # 5 min: send a borderline link to a probe rather than dropping


def presign_expiry(url):
	"""Epoch at which a pre-signed URL stops working, or None if it is not pre-signed."""
	try:
		from urllib.parse import urlparse, parse_qs
		import calendar, time as _time
		q = parse_qs(urlparse(url).query)
		signed_at, lifetime = q.get('X-Amz-Date', [None])[0], q.get('X-Amz-Expires', [None])[0]
		if not signed_at or not lifetime: return None
		# calendar.timegm, not mktime: the stamp is UTC.
		return calendar.timegm(_time.strptime(signed_at, '%Y%m%dT%H%M%SZ')) + int(lifetime)
	except Exception:
		return None


def presign_reference(server_date, urls):
	"""Reference clock for the expiry check -> (now_epoch, trustworthy).

	Prefers the provider's own Date header. A CoreELEC box with no RTC can boot with a badly
	wrong clock, and a wrong clock here would silently drop every source. With no server date
	it falls back to the local clock, but reports untrustworthy if anything was signed in the
	future -- which can only mean our clock is behind.
	"""
	import time as _time
	if server_date:
		try:
			import email.utils
			return email.utils.parsedate_to_datetime(server_date).timestamp(), True
		except Exception:
			pass
	now = _time.time()
	for u in urls:
		exp = presign_expiry(u)
		if exp is None: continue
		try:
			from urllib.parse import urlparse, parse_qs
			life = int(parse_qs(urlparse(u).query).get('X-Amz-Expires', ['0'])[0])
		except Exception:
			continue
		if exp - life > now + PRESIGN_GRACE:
			return now, False
	return now, True


def drop_expired_presigns(sources, server_date, url_of=None, mark='_presign_ok'):
	"""Drop pre-signed sources past their expiry; flag the rest as needing no probe."""
	if not sources: return sources
	get = url_of or (lambda s: (s.get('url_dl') or s.get('url') or '').split('|', 1)[0])
	now, ok = presign_reference(server_date, [get(s) for s in sources])
	if not ok:
		from modules.kodi_utils import logger
		logger('presign gate', 'skipped: local clock appears to be behind')
		return sources
	kept, dropped = [], 0
	for s in sources:
		exp = presign_expiry(get(s))
		if exp is None:
			kept.append(s); continue
		if exp < now - PRESIGN_GRACE:
			dropped += 1; continue
		s[mark] = True
		kept.append(s)
	if dropped:
		from modules.kodi_utils import logger
		logger('presign gate', 'dropped %d expired of %d' % (dropped, len(sources)))
	return kept

# LOCAL PATCH 2026-08-29: HDHub's transcoded HLS ladder, shared by both scrapers.
#
# HDHub exposes /resolve/cj/tmdb/<id>/<res>.m3u8 alongside the real files. The rows tag
# themselves by RESOLUTION and carry a bitrate nowhere near it -- read out of the master
# playlists for LOTR The Two Towers:
#
#     4K    3840x2160  BANDWIDTH=8390585  ->  8.4 Mbps
#     1080p 1920x1080  BANDWIDTH=2112780  ->  2.1 Mbps
#     720p  1280x720   BANDWIDTH=1588374  ->  1.6 Mbps
#
# A real 4K remux runs 50-100 Mbps, so a row reading "4K" here is a heavily compressed
# stream sitting next to a 29 GB file claiming the same thing. Nothing else catches them:
# they play, so validation passes them, and quality sorting keys on the resolution token,
# which is honest. They also report 0.00-0.02 GB, so they do not sort down either.
#
# Matched on the endpoint, NOT on '.m3u8' in general -- img1's index_NNN.m3u8 is a
# full-length stream (Fellowship: 4148 segments, 228 min) and must survive.
_TRANSCODE_MARKER = '/resolve/cj/'


def is_transcode_url(url):
	"""True for HDHub's resolution-ladder HLS, which is not the release it claims to be."""
	return _TRANSCODE_MARKER in (url or '').lower()

# LOCAL PATCH 2026-09-01: release-name parsing shared by the subtitle scorer
# (indexers/subtitles.py) and the SmartPlay sticky matcher (modules/sources.py). It lived in
# subtitles.py first and was moved here because modules/ must not import from indexers/.
# Deliberately NOT merged with normalize() above -- that one strips unicode accents, this one
# reduces release separators to single spaces. Different jobs, similar names.

def release_norm(text):
	"""Lowercase, with every release separator reduced to a single space.

	Padded with spaces at both ends so a needle like ' web ' cannot match inside a word.
	"""
	text = (text or '').lower()
	for ch in ('.', '_', '-', '[', ']', '(', ')', '+', "'", ','):
		text = text.replace(ch, ' ')
	return ' %s ' % ' '.join(text.split())


# LOCAL PATCH 2026-09-02: site tags that are legitimate release groups despite the dot.
# Deliberately a closed TLD list rather than r'\.[a-z]{2,4}$' -- the open form would also
# swallow '...-Something.2001' style title hyphens.
_SITE_TAG_RE = re.compile(r'^([a-z0-9]{2,})\.(com|net|org|to|me|cc|tv|io|co|info|xyz|site|link|pw|in|is|se|nu|ws|sx)$')

# LOCAL PATCH 2026-09-03: tails that are an episode marker rather than a releaser.
_EPISODE_TOKEN_RE = re.compile(r'^(?:s\d{1,3}e\d{1,4}|e\d{1,4}|ep\d{1,4}|\d{1,4})(?:v\d{1,2})?$')


# LOCAL PATCH 2026-09-03: the group-token rules, shared by the pipe and hyphen paths in
# release_group so the two cannot drift. A site tag may carry ONE dot plus a known TLD
# (stripped); anything else dotted is release metadata, not a group.
def _clean_group_token(raw):
	tok = re.split(r'[\[\](){}]', raw or '')[0].strip().lower()
	if '.' in tok:
		m = _SITE_TAG_RE.match(tok)
		if not m: return ''
		tok = m.group(1)
	if not tok or ' ' in tok or len(tok) > 20: return ''
	if tok.isdigit(): return ''
	# LOCAL PATCH 2026-09-03: an EPISODE MARKER after the final separator is not a group.
	# '[Judas] Re.Zero - S04E01.mkv' was parsing as group 's04e01', and SmartPlay's
	# same-release tier compares release_group(candidate) against the pin's -- 's04e01'
	# against the next episode's 's04e02' can never be equal, so the tier could not chain
	# a Judas-style name at all. Third case of the same family as the '4KHDHub.com' and
	# pipe-tag fixes. The v-suffix is allowed for so 'S04E01v2' is caught too.
	if _EPISODE_TOKEN_RE.match(tok): return ''
	return tok

def release_group(name):
	"""Release group -- the token after the final '-', where scene and p2p names put it.

	Parsed from the RAW name, before _norm() would eat the hyphen. Returns '' when the name
	does not follow the convention, so a hyphen inside a title cannot masquerade as a group.
	"""
	name = re.sub(r'\.(mkv|mp4|avi|m2ts|ts|srt|vtt|ass|ssa|sub)$', '', (name or '').strip(), flags=re.I)
	# LOCAL PATCH 2026-09-03: some sources put the tag after a PIPE, not a hyphen, and for
	# those the hyphen rule below reads garbage out of the middle of the name. The
	# http_streams/PixelDrain form ends '... | <host> | 4KHDHub', so
	#   '[PixelDrain] The.Rising.of.the.Shield.Hero.S02E02....AAC2.0. pixeldrain | 4KHDHub'
	# split on its final '-' gives 'DL.MULTi.AAC2.0. pixeldrain | 4khdhub' -- dots, spaces
	# and a pipe, so it was rejected and pin_group came back ''. sources.py runs the
	# same-release tier only `if pin_group`, so the tier was skipped outright: observed as
	# 'sticky entry present but unmatched in 29 results' on Shield Hero S02E03 while the pin
	# was a PixelDrain S02E02, and the same for the Frieren pin.
	#
	# Taking the LAST pipe field normalises it to '4khdhub' -- the same token the hyphen
	# form '-4kHdHub.Com' yields -- so a PixelDrain pin now follows onto that site's
	# ordinary releases and back again. Tried before the hyphen rule because when a pipe is
	# present the hyphen tail is meaningless; it falls through if the pipe field is not a
	# clean token, so a name that merely happens to contain a pipe is unaffected.
	if '|' in name:
		_piped = _clean_group_token(name.rsplit('|', 1)[1])
		if _piped: return _piped
	if '-' not in name: return ''
	tail = name.rsplit('-', 1)[1]
	# A real group token is not just digits; a tail with a dot is usually a hyphen from
	# the title itself ('A-Movie-With-Hyphens.2001.1080p'), not a group.
	#
	# LOCAL PATCH 2026-09-02: except when the dot belongs to a SITE TAG, which is a real
	# group name. Rejecting every dotted tail silently disabled SmartPlay's same-release
	# tier for every release from a site-tagged source: the pin
	# 'Lanterns.S01E02.Trust.Fall.2160p.AMZN.WEB-DL...H.265-4KHDHub.com.mkv' parsed to '',
	# and sources.py only runs that tier `if pin_group`, so Lanterns S01E03 fell through to
	# the picker every time -- logged as 'sticky entry present but unmatched in 55 results'
	# with the correct release sitting in those 55. Same for Re:ZERO's '-4kHdHub.Com'.
	#
	# A site tag is domain-shaped: ONE dot and a short alpha TLD. The title-hyphen case it
	# has to stay separated from carries release metadata after the dot ('hyphens.2001.1080p'
	# -- two dots, no TLD), so requiring exactly one dot plus a known TLD keeps them apart.
	# The TLD is then STRIPPED, so '4KHDHub.com', '4kHdHub.Com' and a bare '4KHDHub' all
	# normalise to '4khdhub' and a pin matches its own site's other releases however that
	# site chose to spell itself on the day.
	return _clean_group_token(tail)



def release_source(norm_text):
	"""Source family, '' when the name says nothing about it.

	Order matters: the specific spellings must be tested before the generic ones, or
	'web dl' is caught by the bare 'web' test and a bdremux by 'bluray'.
	"""
	for needle, family in (
		(' bdremux ', 'remux'), (' remux ', 'remux'),
		(' bluray ', 'bluray'), (' blu ray ', 'bluray'), (' bdrip ', 'bluray'), (' brrip ', 'bluray'),
		(' web dl ', 'web'), (' webdl ', 'web'), (' webrip ', 'web'), (' web ', 'web'),
		(' uhdtv ', 'hdtv'), (' hdtv ', 'hdtv'), (' dvdrip ', 'dvd'), (' dvd ', 'dvd'), (' hdrip ', 'hdrip')):
		if needle in norm_text: return family
	return ''

def release_service(norm_text):
	"""Streaming service a WEB release came from, '' when the name does not say.

	LOCAL PATCH 2026-09-01. release_source() answers the FAMILY question -- web vs bluray vs
	hdtv -- and deliberately lumps every WEB platform together, which is right for scoring a
	subtitle but far too loose for following a SmartPlay pin. Observed: a pin on
	'...S01E03.Smoke.3.1080p.NF.WEB-DL...-VARYG' chained onto
	'...S01E04.Learning....1080p.CR.WEB-DL...-VARYG'. Same group, same quality, same audio,
	same codec, same family -- but Netflix and Crunchyroll are different masters, with their
	own encodes and their own intro placement. The naming convention gives it away too: the
	NF line numbers its episodes 'Smoke.3', the CR line uses the real episode title.

	Tags kept deliberately unambiguous once separators become spaces. Notably ABSENT: 'ma',
	which would match the MA in 'DTS-HD.MA', and any other two-letter token that collides
	with an audio or codec field.
	"""
	for tag in (' nf ', ' amzn ', ' dsnp ', ' hmax ', ' atvp ', ' hulu ', ' cr ', ' funi ',
		' hidive ', ' pcok ', ' stan ', ' crav ', ' viu ', ' tving ', ' adn ', ' starz ',
		' mubi ', ' roku ', ' itunes ', ' aniplus ', ' bilibili ', ' b global '):
		if tag in norm_text: return tag.strip()
	return ''
