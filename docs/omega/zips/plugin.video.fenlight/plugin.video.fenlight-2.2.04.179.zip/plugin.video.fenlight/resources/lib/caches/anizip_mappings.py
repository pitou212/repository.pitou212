# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-27: ani.zip -> AniDB episode ids.
#
# WHY THIS EXISTS
# Every anime scraping bug fought in this codebase comes from one root choice:
# releases are identified by PARSING THEIR NAMES. That cannot be made correct,
# because the same episode legitimately ships under several different numbers.
# Bleach's Thousand-Year Blood War premiere is on nyaa as BOTH "S01E01" (the arc's
# own numbering) and "S17E01" (Bleach counted continuously). Re:ZERO's TMDb episode
# 50 is named "Season 2 - 24". AoT S3E20 is "S03E20 (57)". No regex is right about
# all of these, and each rule added to cover one convention re-opens another.
#
# AniDB assigns every episode a stable numeric id (eid), and AnimeTosho tags the
# torrents it mirrors from nyaa with that eid. So an eid turns "which torrents are
# this episode?" from a parsing problem into a lookup. ani.zip is the free, keyless
# bridge from an AniList id (which Fribb already gives us offline) to those eids.
#
# This module is ONLY the mapping. It never decides anything about a release.
#
# Endpoint: https://api.ani.zip/mappings?anilist_id=<id>   (no key, no rate limit
# published; we cache anyway so a scrape costs at most one call per show per day).

from caches.lists_cache import lists_cache_object
from modules.kodi_utils import make_session
# from modules.kodi_utils import logger

_ANIZIP_URL = 'https://api.ani.zip/mappings'

session = make_session(_ANIZIP_URL)

# Airing shows gain an episode a week, so this cannot be cached indefinitely, but
# an episode's eid never changes once assigned -- a day is a safe compromise.
_CACHE_HOURS = 24


def _fetch(query):
	"""Compact {episode_key: eid} maps for one anime entry, plus its ids.

	`query` is a full lookup pair, e.g. 'anilist_id=154587' or 'anidb_id=19873'.

	Deliberately reshaped rather than cached whole: the raw response carries
	per-episode overviews, images and titles in seven languages, which is ~50x the
	bytes of the four fields used here and would bloat the cache db for nothing.
	"""
	try:
		r = session.get('%s?%s' % (_ANIZIP_URL, query), timeout=10)
		if r.status_code != 200: return {}
		data = r.json()
	except Exception: return {}
	if not isinstance(data, dict): return {}
	by_ep, by_abs = {}, {}
	for key, ep in (data.get('episodes') or {}).items():
		if not isinstance(ep, dict): continue
		eid = ep.get('anidbEid')
		if not eid: continue
		# `key` is the entry-local number ("1".."28"), or "S1" for a special. Specials
		# are kept out: our episode numbers never address them, and a stray "S1" key
		# colliding with a real episode would silently scrape the wrong thing.
		if key.isdigit(): by_ep[key] = eid
		abs_no = ep.get('absoluteEpisodeNumber')
		if abs_no is not None: by_abs[str(abs_no)] = eid
	if not by_ep and not by_abs: return {}
	mappings = data.get('mappings') or {}
	# `count` is the number of real (non-special) episodes in this entry. It is what
	# tells a whole-series entry from a single cour -- see anizip_whole_run_ids below.
	return {'eps': by_ep, 'abs': by_abs, 'count': len(by_ep),
			'anidb': mappings.get('anidb_id'), 'anilist': mappings.get('anilist_id'),
			'kitsu': mappings.get('kitsu_id'), 'mal': mappings.get('mal_id')}


def anizip_episode_ids(anilist_id, cour_episode=None, absolute_episode=None, anidb_id=None):
	"""Ids for one episode as a dict: aid, eid, anilist, kitsu, mal. Any may be None.

	A dict rather than a tuple because callers want different subsets of it -- the
	animetosho provider needs the eid, seadex needs the AniList id, and the Kitsu
	paths in torrentio/comet need the Kitsu id -- and a 5-tuple would be unreadable
	at every call site.

	`cour_episode` is the episode's index within the entry, which is exactly how
	ani.zip keys its `episodes` map -- so it is tried first. `absolute_episode` is the
	fallback for shows whose entry covers the whole run (Boruto is one entry, so its
	episode 220 is both).

	LOCAL PATCH 2026-08-27: falls back to looking up by AniDB id. Fribb's rows are not
	uniformly populated -- Chainsmoker Cat has anidb=19873 but no anilist/mal/kitsu at
	all -- and without an AniList id there was nothing to query, so animetosho got no
	eid and seadex got no key. Querying by anidb_id is the same lookup at the same
	granularity (Fribb's anidb IS this cour's AniDB anime, so the episode keys line up
	with cour_episode exactly as the AniList path does), and it also RECOVERS the
	AniList id that Fribb was missing, which is what lets seadex work for these shows.
	5 anime in the current library are in this state.

	Deliberately NOT extended to ani.zip's themoviedb_id lookup, which also works but
	is not safe here: for a show TMDb splits into seasons, ani.zip reports seasonNumber
	1 for the whole run, and its absoluteEpisodeNumber is missing (Naruto, One Piece)
	or disagrees with its own episode key (Fairy Tail: key 881 vs absolute 865 -- two
	different episodes). Guessing between them risks playing the wrong one.
	"""
	queries = []
	try:
		if anilist_id: queries.append(('anilist_id', int(anilist_id)))
	except (TypeError, ValueError): pass
	try:
		if anidb_id: queries.append(('anidb_id', int(anidb_id)))
	except (TypeError, ValueError): pass
	if not queries: return {}

	maps = {}
	for key, value in queries:
		maps = lists_cache_object(_fetch, 'anizip_%s_%s' % (key, value),
								'%s=%s' % (key, value), expiration=_CACHE_HOURS)
		if maps: break
	if not maps: return {}
	found = {'aid': maps.get('anidb'), 'eid': None,
			'anilist': maps.get('anilist') or anilist_id,
			'kitsu': maps.get('kitsu'), 'mal': maps.get('mal')}
	for table, number in (('eps', cour_episode), ('abs', absolute_episode)):
		if number is None: continue
		eid = (maps.get(table) or {}).get(str(number))
		if eid:
			found['eid'] = eid
			break
	return found


def anizip_whole_run_ids(tmdb_id, total_aired_eps):
	"""Ids for a show Fribb has no row for, but ONLY if one entry covers the whole run.

	LOCAL PATCH 2026-08-27. 16 anime in the current library have no Fribb cour row at
	all -- Naruto, Naruto Shippuden, Hunter x Hunter, Fairy Tail, One Piece and other
	long-runners. They therefore get no kitsu_id and no cour_episode, so the Kitsu
	paths in torrentio and comet never engage and they fall back to title searching,
	which is what this whole effort exists to avoid.

	ani.zip answers a themoviedb_id lookup for them and supplies the Kitsu id. The
	episode number to pair it with is the series-absolute one, which external.py
	already computes from TMDb's season_data for every anime.

	THE GUARD IS THE WHOLE POINT. An absolute number is only meaningful against an
	entry that covers the entire series; against a single cour it addresses a
	completely different episode. Comparing ani.zip's episode count with TMDb's total
	aired count separates the two cleanly, measured:

	    Naruto            220 vs 220   whole run  -> safe
	    Naruto Shippuden  500 vs 500   whole run  -> safe
	    Hunter x Hunter   148 vs 148   whole run  -> safe
	    Fairy Tail         26 vs 328   one cour   -> REJECTED
	    One Piece        1180 vs 1100  mismatch   -> REJECTED

	One Piece is arguably whole-run and is rejected anyway. That is the intended bias:
	a show left on the title-search path merely scrapes the way it always did, while a
	wrong guess here plays the wrong episode.

	Returns {} when there is no entry, no Kitsu id, or the counts disagree.
	"""
	if not tmdb_id: return {}
	try:
		tmdb_id, total_aired_eps = int(tmdb_id), int(total_aired_eps)
	except (TypeError, ValueError): return {}
	if total_aired_eps < 1: return {}
	maps = lists_cache_object(_fetch, 'anizip_themoviedb_id_%s' % tmdb_id,
							'themoviedb_id=%s' % tmdb_id, expiration=_CACHE_HOURS)
	if not maps or not maps.get('kitsu'): return {}
	count = maps.get('count') or 0
	# 5%, floored at 5 episodes: specials and recap numbering differ slightly between
	# TMDb and AniDB even for entries that genuinely cover the same run.
	if abs(count - total_aired_eps) > max(5, total_aired_eps * 0.05): return {}
	return {'kitsu': maps.get('kitsu'), 'mal': maps.get('mal'),
			'anilist': maps.get('anilist'), 'aid': maps.get('anidb'), 'count': count}
