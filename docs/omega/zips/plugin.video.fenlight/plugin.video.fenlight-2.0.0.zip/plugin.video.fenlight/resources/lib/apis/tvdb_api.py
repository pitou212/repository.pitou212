# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-09-14: TheTVDB v4, used for artwork selection only.
#
# Why a fourth artwork provider exists: "use the latest backdrop" cannot be answered from
# TMDb. Its image objects carry aspect_ratio, file_path, height, iso_3166_1, iso_639_1,
# vote_average, vote_count and width -- and no date of any kind. The only ordering
# available there is array position, whose tail is the unvoted block (68 of 139 backdrops
# on Breaking Bad), so "newest" would mean "unvetted, possibly with burnt-in text":
# Inception's last two entries were Polish and Spanish.
#
# TVDB answers it, though not via the obvious field. Probed live 2026-09-14:
#   * updatedAt EXISTS and is 0 on every artwork -- 344/344 on Breaking Bad, 102/102 on
#     Frieren. The named date field is a red herring; do not trust it.
#   * the artwork `id` is a monotonic auto-increment and IS the recency signal. Breaking
#     Bad's backgrounds span id 20470 to 64164075, a 2009-era upload beside a recent one.
#   * includesText is a real boolean, populated 344/344, so textless selection stops being
#     the iso_639_1-is-null guess TMDb forces.
#
# Artwork type ids, from /artwork/types: 3 series/Background, 7 season/Poster,
# 15 movie/Background. Hardcoded rather than fetched, to save a request per cold item for
# values that have been stable for the life of the v4 API.
import time

from caches.main_cache import main_cache
from caches.settings_cache import get_setting
from modules.kodi_utils import make_session, get_property, set_property, logger

_API_BASE = 'https://api4.thetvdb.com/v4'
_TIMEOUT = 10
_CACHE_HOURS = 168

_TYPE_SERIES_BACKGROUND = 3
_TYPE_SEASON_POSTER = 7
_TYPE_MOVIE_BACKGROUND = 15

# Bearer tokens last ~30 days. Held in a window property rather than module state because
# reuselanguageinvoker=false wipes module globals every plugin invocation -- the same
# reason omdb_api keeps its cooldown there.
_TOKEN_PROP = 'fenlight.tvdb_token'
_TOKEN_EXPIRY_PROP = 'fenlight.tvdb_token_expires'
_TOKEN_TTL = 20 * 24 * 3600

session = make_session(_API_BASE)


def _api_key():
	key = get_setting('fenlight.tvdb_api', '')
	return '' if key in ('empty_setting', None) else key


def _token():
	"""Cached bearer token, or '' when unavailable. A failed login is deliberately not
	cached: the key may simply be absent, and rechecking costs one request at most."""
	try:
		cached, expires = get_property(_TOKEN_PROP), get_property(_TOKEN_EXPIRY_PROP)
		if cached and expires and time.time() < float(expires):
			return cached
	except Exception:
		pass
	key = _api_key()
	if not key:
		return ''
	try:
		response = session.post('%s/login' % _API_BASE, json={'apikey': key}, timeout=_TIMEOUT)
		token = ((response.json() or {}).get('data') or {}).get('token') or ''
		if not token:
			logger('TVDB', 'login returned no token (HTTP %s)' % response.status_code)
			return ''
		set_property(_TOKEN_PROP, token)
		set_property(_TOKEN_EXPIRY_PROP, str(time.time() + _TOKEN_TTL))
		return token
	except Exception as e:
		logger('TVDB login error', str(e)[:200])
		return ''


def _get(path):
	"""Authorised GET returning the `data` payload, or None. A 401 drops the cached token
	so the next call re-logs in rather than spending a whole cache window on refusals."""
	token = _token()
	if not token:
		return None
	try:
		response = session.get('%s%s' % (_API_BASE, path),
							   headers={'Authorization': 'Bearer %s' % token}, timeout=_TIMEOUT)
		if response.status_code == 401:
			set_property(_TOKEN_EXPIRY_PROP, '0')
			return None
		return (response.json() or {}).get('data')
	except Exception as e:
		logger('TVDB request error', '%s: %s' % (path, str(e)[:160]))
		return None


def _cached(key, builder):
	"""main_cache with one deliberate difference from cache_object: only a truthy result
	is stored. cache_object writes whatever the builder returned, so a transient failure
	or a rejected token would pin an empty result for the full 168h window."""
	try:
		hit = main_cache.get(key)
		if hit:
			return hit
		result = builder()
		if result:
			main_cache.set(key, result, expiration=_CACHE_HOURS)
		return result
	except Exception:
		return None


def _sort_key(mode):
	"""Newest = highest artwork id, the upload ordering. Best = highest score, with id as
	the tie-break so the choice is stable when scores are equal -- Frieren's season posters
	all score 0, which would otherwise leave the order at the mercy of the response."""
	if mode == 'best':
		return lambda a: (a.get('score') or 0, a.get('id') or 0)
	return lambda a: a.get('id') or 0


def _pick(pool, mode):
	return max(pool, key=_sort_key(mode))


# LOCAL PATCH 2026-09-15: the ranked list, not just its first entry. The whole artworks array
# is already fetched and cached (tvdb_artworks_%s / tvdb_movieart_%s, 168h), and a well covered
# show carries far more than one usable background -- Game of Thrones has 140 series backgrounds,
# 109 of them textless. Returning N costs NO extra request; the singular accessors below now
# delegate here so the filter and the ordering have exactly one implementation.
def _ranked_backgrounds(artworks, art_type, mode, cap):
	backgrounds = [a for a in artworks if a.get('type') == art_type and a.get('image')]
	if not backgrounds:
		return []
	# Textless preferred; if a title has none the filter is dropped, since a texted backdrop
	# still beats no backdrop. Never mixed: a texted image among textless ones looks like a
	# mistake rather than a choice.
	textless = [a for a in backgrounds if not a.get('includesText')]
	pool = sorted(textless or backgrounds, key=_sort_key(mode), reverse=True)
	out, seen = [], set()
	for a in pool:
		url = a.get('image')
		if not url or url in seen:
			continue
		seen.add(url)
		out.append(url)
		if len(out) >= cap:
			break
	return out


def _series_artworks(tvdb_id):
	return _cached('tvdb_artworks_%s' % tvdb_id,
				   lambda: ((_get('/series/%s/artworks' % tvdb_id) or {}).get('artworks') or [])) or []


def series_backdrops(tvdb_id, mode='newest', cap=20):
	"""Up to `cap` TVDB series background urls, best first for the given mode, or [].
	TVDB's `image` is already an absolute url."""
	if not tvdb_id or str(tvdb_id) in ('', 'None', '0'):
		return []
	try:
		return _ranked_backgrounds(_series_artworks(tvdb_id), _TYPE_SERIES_BACKGROUND, mode, cap)
	except Exception as e:
		logger('TVDB backdrop error', str(e)[:200])
		return []


def series_backdrop(tvdb_id, mode='newest'):
	"""The single best TVDB series background url, or ''."""
	return next(iter(series_backdrops(tvdb_id, mode, cap=1)), '')


def _season_number_map(tvdb_id):
	"""TVDB seasonId -> season number, OFFICIAL seasons only.

	Needed because artworks carry a seasonId and never a number. TVDB files several
	orderings per series -- Breaking Bad returns 13 seasons across official, dvd and
	absolute -- and only the official ones line up with the TMDb numbering used
	everywhere else here. That is also why not every season poster resolves: 86 of
	Breaking Bad's 154 belong to official seasons, the rest hang off the other orderings
	and are dropped rather than mapped to the wrong season."""
	def _build():
		seasons = (_get('/series/%s/extended' % tvdb_id) or {}).get('seasons') or []
		return {str(s['id']): s.get('number') for s in seasons
				if s.get('id') is not None and (s.get('type') or {}).get('type') == 'official'}
	return _cached('tvdb_seasonmap_%s' % tvdb_id, _build) or {}


def season_posters(tvdb_id, mode='newest'):
	"""{season number: image url} from TVDB, or {}.

	Unlike backgrounds, includesText is NOT filtered on here: a season poster carries the
	season name by design and Breaking Bad's are text-bearing almost without exception, so
	filtering would return nothing at all."""
	if not tvdb_id or str(tvdb_id) in ('', 'None', '0'):
		return {}
	try:
		numbers = _season_number_map(tvdb_id)
		if not numbers:
			return {}
		best = {}
		for artwork in _series_artworks(tvdb_id):
			if artwork.get('type') != _TYPE_SEASON_POSTER or not artwork.get('image'):
				continue
			number = numbers.get(str(artwork.get('seasonId')))
			if number is None:
				continue
			current = best.get(number)
			if current is None or artwork is _pick([artwork, current], mode):
				best[number] = artwork
		return {n: a['image'] for n, a in best.items()}
	except Exception as e:
		logger('TVDB season posters error', str(e)[:200])
		return {}


def _movie_id(imdb_id):
	"""TVDB movie id for an IMDb id, or ''. Movies need this hop because TVDB is the only
	provider here not already keyed by an id the add-on holds; shows do not, since tvdb_id
	comes free from TMDb's external_ids."""
	def _build():
		for entry in (_get('/search/remoteid/%s' % imdb_id) or []):
			movie = entry.get('movie')
			if movie and movie.get('id'):
				return str(movie['id'])
		return ''
	return _cached('tvdb_movieid_%s' % imdb_id, _build) or ''


def movie_backdrops(imdb_id, mode='newest', cap=20):
	"""Up to `cap` TVDB movie background urls, best first, or []. Two cached requests on a
	cold item: the remoteid lookup, then /movies/{id}/extended -- movie artworks live there,
	as there is no /movies/{id}/artworks counterpart to the series endpoint."""
	if not imdb_id or str(imdb_id) in ('', 'None', 'tt0000000'):
		return []
	try:
		movie_id = _movie_id(imdb_id)
		if not movie_id:
			return []
		artworks = _cached('tvdb_movieart_%s' % movie_id,
						   lambda: ((_get('/movies/%s/extended' % movie_id) or {}).get('artworks') or [])) or []
		return _ranked_backgrounds(artworks, _TYPE_MOVIE_BACKGROUND, mode, cap)
	except Exception as e:
		logger('TVDB movie backdrop error', str(e)[:200])
		return []


def movie_backdrop(imdb_id, mode='newest'):
	"""The single best TVDB movie background url, or ''."""
	return next(iter(movie_backdrops(imdb_id, mode, cap=1)), '')
