# -*- coding: utf-8 -*-
import json
import re
import time
from threading import Thread
from windows.base_window import open_window, create_window
from caches.episode_groups_cache import episode_groups_cache
from caches.settings_cache import get_setting
from scrapers import external, folders
from modules import debrid, kodi_utils, settings, metadata, watched_status
from modules.player import FenLightPlayer, PLAYBACK_STOPPED_PROP, mark_internal_stop
from modules.source_utils import get_cache_expiry, make_alias_dict, include_exclude_filters, anime_episode_candidates, seas_ep_filter, release_group, release_source, release_norm, get_release_quality, release_service
from modules.utils import clean_file_name, string_to_float, safe_string, remove_accents, get_datetime, append_module_to_syspath, manual_function_import
# logger = kodi_utils.logger

# LOCAL PATCH 2026-09-06: a torrent whose name ends in a video extension is a SINGLE FILE --
# multi-file torrents are directories and carry no extension on the name. _sticky_save used
# to label EVERY episode pin 'season', so pack-play then asked the debrid service to find
# episode N+1 inside a torrent holding only episode N. That can never succeed: BLACK TORCH
# e4-e8 each logged 'resolve_cached returned None' after ~1.5s before falling back to the
# scrape it should have gone straight to. Providers report this name themselves, so a pack
# whose name happens to look like a file merely degrades to the scrape path -- which is
# exactly today's behaviour -- rather than breaking anything.
_SINGLE_FILE_NAME = re.compile(r'\.(?:mkv|mp4|avi|ts|m2ts|mov|wmv|flv|m4v|mpg|mpeg|webm)$', re.I)
# LOCAL PATCH 2026-09-06: an explicit SxxExx token names exactly ONE episode. Providers
# routinely report a pin name with no file extension at all -- kodi.log 12:33 shows
# 'Daemons.of.the.Shadow.Realm.S01E22.1080p.CR.WEB-DL.AAC.2' -- so the extension test
# above cannot stand alone. A real season pack ('...S01.1080p...') carries no Exx.
_EPISODE_MARKER = re.compile(r'[sS]\d{1,3}[ ._-]?[eE]\d{1,4}')
# LOCAL PATCH 2026-09-07: a season token with NO episode after it -- 'S01' in
# 'Lion.S01.2160p...' -- names one whole season. The lookbehind keeps 'DTS5.1' / 'x265'
# out; the lookahead is exactly the shape _EPISODE_MARKER accepts, so the two never both
# match the same token.
_SEASON_MARKER = re.compile(r'(?<![A-Za-z0-9])[sS](\d{1,3})(?![ ._-]?[eE]\d)(?![0-9])')

class Sources():
	def __init__(self):
		self.params = {}
		self.prescrape_scrapers, self.prescrape_threads, self.prescrape_sources, self.uncached_results = [], [], [], []
		self.threads, self.providers, self.sources, self.internal_scraper_names, self.remove_scrapers = [], [], [], [], ['external']
		self.clear_properties, self.filters_ignored, self.active_folders, self.resolve_dialog_made, self.episode_group_used = True, False, False, False, False
		self.sources_total = self.sources_4k = self.sources_1080p = self.sources_720p = self.sources_sd = 0
		self.prescrape, self.disabled_ext_ignored = 'true', 'false'
		self.ext_name, self.ext_folder = '', ''
		self.progress_dialog, self.progress_thread = None, None
		self.playing_filename = ''
		self.scrape_count = 0
		self.count_tuple = (('sources_4k', '4K', self._quality_length), ('sources_1080p', '1080p', self._quality_length), ('sources_720p', '720p', self._quality_length),
							('sources_sd', '', self._quality_length_sd), ('sources_total', '', self._quality_length_final))
		self.filter_keys = include_exclude_filters()
		self.filter_keys.pop('hybrid')
		self.default_internal_scrapers = ('easynews', 'rd_cloud', 'pm_cloud', 'ad_cloud', 'tb_cloud', 'aiostreams', 'http_streams', 'folders')
		self.debrids = {'Real-Debrid': ('apis.real_debrid_api', 'RealDebridAPI'), 'rd_cloud': ('apis.real_debrid_api', 'RealDebridAPI'),
		'rd_browse': ('apis.real_debrid_api', 'RealDebridAPI'), 'Premiumize.me': ('apis.premiumize_api', 'PremiumizeAPI'), 'pm_cloud': ('apis.premiumize_api', 'PremiumizeAPI'),
		'pm_browse': ('apis.premiumize_api', 'PremiumizeAPI'), 'AllDebrid': ('apis.alldebrid_api', 'AllDebridAPI'), 'ad_cloud': ('apis.alldebrid_api', 'AllDebridAPI'),
		'ad_browse': ('apis.alldebrid_api', 'AllDebridAPI'), 'TorBox': ('apis.torbox_api', 'TorBoxAPI'), 'tb_cloud': ('apis.torbox_api', 'TorBoxAPI'),
		'tb_browse': ('apis.torbox_api', 'TorBoxAPI')}
		self.retry_actions = settings.rescrape_settings()

	def playback_prep(self, params=None):
		kodi_utils.hide_busy_dialog()
		if params: self.params = params
		params_get = self.params.get
		if not kodi_utils.external_playback_check(self.params): return
		self.play_type = params_get('play_type', '')
		# LOCAL PATCH 2026-08-31 (doc only): `background` carries THREE unrelated meanings and
		# no caller can separate them. Produced only by episode_tools.py:94 (next episode) and
		# episode_tools.py:141 (random-continual, links 2+):
		#   1. show no UI    -- suppresses the progress window, joins scraper threads
		#                       synchronously, downgrades dialogs to toasts (lines 110, 136,
		#                       141, 156, 810, 821, 1066, and via meta['background'] into
		#                       scrapers/external.py)
		#   2. chain to another episode -- continue_resolve_check (line ~1147) uses it to
		#                       decide whether play_file is the tail end of an episode. THIS
		#                       IS LOAD-BEARING: without background, nothing chains at all
		#   3. play, do not ask -- the tail of play_source
		# So "silent play but do not chain", and "chain but do ask", are both inexpressible.
		# Meaning 3 is what silently played a wrong source when code wanted meaning 2.
		self.background = params_get('background', 'false') == 'true'
		self.prescrape = params_get('prescrape', self.prescrape) == 'true'
		self.random, self.random_continual = params_get('random', 'false') == 'true', params_get('random_continual', 'false') == 'true'
		if 'external_cache_check' in self.params: self.external_cache_check = params_get('external_cache_check') == 'true'
		else: self.external_cache_check = settings.external_cache_check()
		if self.play_type:
			if self.play_type == 'autoplay_nextep': self.autoplay_nextep, self.autoscrape_nextep = True, False
			elif self.play_type == 'random_continual': self.autoplay_nextep, self.autoscrape_nextep = False, False
			else: self.autoplay_nextep, self.autoscrape_nextep = False, True
		else: self.autoplay_nextep, self.autoscrape_nextep = settings.autoplay_next_episode(), settings.autoscrape_next_episode()
		self.autoscrape = self.autoscrape_nextep and self.background		
		self.ignore_scrape_filters = params_get('ignore_scrape_filters', 'false') == 'true'
		self.nextep_settings, self.disable_autoplay_next_episode = params_get('nextep_settings', {}), params_get('disable_autoplay_next_episode', 'false') == 'true'
		# LOCAL PATCH 2026-09-04: hashes whose cached resolve failed during THIS attempt.
		self._sticky_dead_hashes = set()
		self.disabled_ext_ignored = params_get('disabled_ext_ignored', self.disabled_ext_ignored) == 'true'
		self.folders_ignore_filters = get_setting('fenlight.results.folders_ignore_filters', 'false') == 'true'
		self.filter_size_method = int(get_setting('fenlight.results.filter_size_method', '0'))
		self.media_type, self.tmdb_id = params_get('media_type'), params_get('tmdb_id')		
		self.custom_title, self.custom_year = params_get('custom_title', None), params_get('custom_year', None)
		self.episode_group_label, self.episode_id = params_get('episode_group_label', ''), params_get('episode_id', None)
		self.playcount, self.watch_count = params_get('playcount', None), params_get('watch_count', 1)
		if self.media_type == 'episode':
			self.season, self.episode = int(params_get('season')), int(params_get('episode'))
			self.custom_season, self.custom_episode = params_get('custom_season', None), params_get('custom_episode', None)
			self.check_episode_group()
		else: self.season, self.episode, self.custom_season, self.custom_episode = '', '', '', ''
		if 'autoplay' in self.params: self.autoplay = params_get('autoplay', 'false') == 'true'
		else: self.autoplay = settings.auto_play(self.media_type)
		self.get_meta()
		self.determine_scrapers_status()
		self.sleep_time, self.provider_sort_ranks, self.scraper_settings = 100, settings.provider_sort_ranks(), settings.scraping_settings()
		self.include_prerelease_results = settings.include_prerelease_results()
		self.limit_resolve = settings.limit_resolve()
		self.weight_size = settings.size_sort_weighted()
		self.sort_function, self.quality_filter = settings.results_sort_order(), self._quality_filter()
		self.include_unknown_size = get_setting('fenlight.results.size_unknown', 'false') == 'true'
		self.make_search_info()
		if self.autoscrape: self.autoscrape_nextep_handler()
		else:
			# LOCAL PATCH 2026-08-31 (doc only): this returns and SKIPS THE SCRAPE ENTIRELY when
			# the pin has a pack, so _sticky_match never runs for pack pins. The matcher only
			# sees NON-pack pins (http_streams, direct links). Worth knowing before trying to
			# observe match/miss behaviour: with a pack pinned you will see only
			# "pack-play[debrid]" in the log and no match line at all, which looks like the
			# matcher is broken when it simply was not consulted.
			if self._sticky_pack_play(): return
			return self.get_sources()

	def check_episode_group(self):
		try:
			if any([self.custom_season, self.custom_episode]) or 'skip_episode_group_check' in self.params: return
			group_info = episode_groups_cache.get(self.tmdb_id)
			if not group_info: return
			group_details = metadata.group_episode_data(metadata.group_details(group_info['id']), self.episode_id, self.season, self.episode)
			if group_details:
				self.custom_season, self.custom_episode, self.episode_group_used = group_details['season'], group_details['episode'], True
				self.episode_group_label = '[B]CUSTOM GROUP: S%02dE%02d[/B]' % (self.custom_season, self.custom_episode)
		except: self.custom_season, self.custom_episode = None, None

	def determine_scrapers_status(self):
		self.active_internal_scrapers = settings.active_internal_scrapers()
		if not 'external' in self.active_internal_scrapers and self.disabled_ext_ignored: self.active_internal_scrapers.append('external')
		self.active_external = 'external' in self.active_internal_scrapers
		if self.active_external:
			self.debrid_enabled = debrid.debrid_enabled()
			if not self.debrid_enabled:
				return self.disable_external('No Debrid Services Enabled' if all(scraper == 'external' for scraper in self.active_internal_scrapers) else 'EN used only')
			self.ext_folder, self.ext_name = settings.external_scraper_info()
			if not self.ext_folder or not self.ext_name: return self.disable_external('Error Importing External Module')

	def get_sources(self):
		self.scrape_count += 1
		if not self.progress_dialog and not self.background: self._make_progress_dialog()
		results = []
		if self.prescrape and any(x in self.active_internal_scrapers for x in self.default_internal_scrapers):
			if self.prepare_internal_scrapers():
				results = self.collect_prescrape_results()
				if results: results = self.process_results(results)
		if not results:
			self.prescrape = False
			self.prepare_internal_scrapers()
			if self.active_external: self.activate_external_providers()
			elif not self.active_internal_scrapers: self._kill_progress_dialog()
			self.orig_results = self.collect_results()
			if not self.orig_results and not self.active_external: self._kill_progress_dialog()
			results = self.process_results(self.orig_results)
		if not results: return self._process_post_results()
		if self.autoscrape: return results
		else: return self.play_source(results)

	def collect_results(self):
		self.sources.extend(self.prescrape_sources)
		threads_append = self.threads.append
		if self.active_folders: self.append_folder_scrapers(self.providers)
		self.providers.extend(self.internal_sources())
		if self.providers:
			for i in self.providers: threads_append(Thread(target=self.activate_providers, args=(i[0], i[1], False), name=i[2]))
			[i.start() for i in self.threads]
		if self.active_external or self.background:
			if self.active_external:
				self.external_args = (self.meta, self.external_providers, self.debrid_enabled, self.external_cache_check, self.internal_scraper_names,
										self.prescrape_sources, self.progress_dialog, self.disabled_ext_ignored)
				self.activate_providers('external', external, False)
			if self.background: [i.join() for i in self.threads]
		elif self.active_internal_scrapers: self.scrapers_dialog()
		return self.sources

	def collect_prescrape_results(self):
		threads_append = self.prescrape_threads.append
		if self.active_folders:
			if settings.check_prescrape_sources('folders', self.media_type):
				self.append_folder_scrapers(self.prescrape_scrapers)
				self.remove_scrapers.append('folders')
		self.prescrape_scrapers.extend(self.internal_sources(True))
		if not self.prescrape_scrapers: return []
		for i in self.prescrape_scrapers: threads_append(Thread(target=self.activate_providers, args=(i[0], i[1], True), name=i[2]))
		[i.start() for i in self.prescrape_threads]
		self.remove_scrapers.extend(i[2] for i in self.prescrape_scrapers)
		if self.background: [i.join() for i in self.prescrape_threads]
		else: self.scrapers_dialog()
		return self.prescrape_sources

	def process_results(self, results):
		results = self.deduplicate_results(results)
		results = self.sort_results(results)
		min_seeders = settings.uncached_min_seeders()
		all_uncached_results = [i for i in results if 'Uncached' in i.get('cache_provider', '')]
		# LOCAL PATCH 2026-08-10 (Red Light 2.2.0 port): treat missing/None/non-numeric
		# seeders as 0. `i.get('seeders', '0')` only defaults when the KEY is absent —
		# providers that return an explicit `seeders: None` made int(None) raise
		# TypeError here, which killed the whole scrape and left the results window
		# stuck open with no sources.
		def _seeders(item):
			try: return int(item.get('seeders') or 0)
			except (TypeError, ValueError): return 0
		self.uncached_results = [i for i in all_uncached_results if _seeders(i) >= min_seeders]
		results = [i for i in results if not i in all_uncached_results]
		if self.ignore_scrape_filters: self.filters_ignored = True
		else:
			results = self.filter_results(results)
			results = self.filter_audio(results)
			results = self.filter_banned_keywords(results)
			for file_type in self.filter_keys: results = self.special_filter(results, file_type)
		results = self.sort_preferred_filters(results)
		if self.prescrape:
			self.all_scrapers = self.active_internal_scrapers
			autoplay_results = [i for i in results if i['scrape_provider'] in self.active_internal_scrapers and settings.autoplay_prescrape(i['scrape_provider'])]
			if autoplay_results:
				self.autoplay = True
				results = autoplay_results
		else:
			self.all_scrapers = list(set(self.active_internal_scrapers + self.remove_scrapers))
			kodi_utils.clear_property('fs_filterless_search')
		results = self.sort_first(results)
		if self.ignore_scrape_filters: return results
		results = self.limit_quality_numbers(results)
		results = self.limit_quality_total(results)
		return results

	def deduplicate_results(self, results):
		# LOCAL PATCH 2026-06-20: dedup keys include cache_provider so the SAME hash cached
		# on multiple debrids (e.g. Real-Debrid AND TorBox) yields one row per debrid in the
		# picker instead of only the first-arriving thread's entry winning. scrapers/external.py
		# emits one entry per (hash, debrid) — without this, the second debrid's rows were
		# silently swallowed by hash/url/size-quality dedup.
		seen_urls = set()
		seen_hashes = set()
		seen_size_quality = set()
		deduplicated = []
		for item in results:
			if item.get('scrape_provider') == 'aiostreams':
				deduplicated.append(item)
				continue
			url = (item.get('url_dl', '') or item.get('url', '') or '').strip()
			info_hash = (item.get('infoHash', '') or item.get('hash', '') or '').strip().lower()
			cache_provider = item.get('cache_provider', '')
			if url and (url, cache_provider) in seen_urls: continue
			if info_hash and (info_hash, cache_provider) in seen_hashes: continue
			quality = item.get('quality', 'SD')
			size = item.get('size', 0)
			size_quality_key = (quality, size, cache_provider)
			if size_quality_key in seen_size_quality: continue
			if url: seen_urls.add((url, cache_provider))
			if info_hash: seen_hashes.add((info_hash, cache_provider))
			seen_size_quality.add(size_quality_key)
			deduplicated.append(item)
		return deduplicated

	def sort_results(self, results):
		results = [dict(i, **{
			'provider_rank': self._get_provider_rank(i['debrid'].lower()), 'quality_rank': self._get_quality_rank(i.get('quality', 'SD')),
			'size_rank': self._get_size_rank(i)}) for i in results]
		results.sort(key=self.sort_function)
		results = self._sort_uncached_results(results)
		return results

	def filter_results(self, results):
		if self.folders_ignore_filters:
			folder_results = [i for i in results if i['scrape_provider'] == 'folders']
			results = [i for i in results if not i in folder_results]
		else: folder_results = []
		results = [i for i in results if i['quality'] in self.quality_filter]
		if self.filter_size_method:
			min_size = string_to_float(get_setting('fenlight.results.%s_size_min' % self.media_type, '0'), '0') / 1000
			if min_size == 0.0 and not self.include_unknown_size: min_size = 0.02
			if self.filter_size_method == 1:
				duration = self.meta['duration'] or (5400 if self.media_type == 'movie' else 2400)
				max_size = ((0.125 * (0.90 * string_to_float(get_setting('results.line_speed', '25'), '25'))) * duration)/1000
			elif self.filter_size_method == 2:
				max_size = string_to_float(get_setting('fenlight.results.%s_size_max' % self.media_type, '10000'), '10000') / 1000
			results = [i for i in results if i['scrape_provider'] == 'folders' or min_size <= i['size'] <= max_size]
		results += folder_results
		return results

	def filter_audio(self, results):
		a_filters = settings.audio_filters()
		return [i for i in results if not any(x in i['extraInfo'] for x in a_filters)]

	# LOCAL PATCH 2026-06-20: Real Debrid filename-keyword filter. Drops sources whose raw
	# filename contains any of the comma-separated banned tokens (case-insensitive substring).
	# Matches on the 'name' field (raw scraper output), NOT display_name (cleaned for UI) or
	# extraInfo (BBCODE tags only). Setting ships pre-populated with RD's confirmed blocked
	# tokens (WEB-DL, AMZN, RARBG, [rarbg], etc. from the May 2026 FNEF/DSA filter rollout);
	# user can edit/clear the setting. Empty setting = filter disabled (no-op pass-through).
	#
	# Scope (refined 2026-06-23): only drops a row when ALL of the following hold —
	#   1) scrape_provider == 'external'  (i.e. magnet torrent path, not aiostreams/easynews/
	#      sootio/http_streams/cloud/folders — those bypass addMagnet entirely)
	#   2) cache_provider contains 'Real-Debrid'  (covers both 'Real-Debrid' cached entries
	#      AND 'Uncached Real-Debrid' rows — the only debrid running the FNEF filename ban)
	#   3) name contains one of the banned tokens
	# TorBox / Premiumize / AllDebrid have no filename ban — their cache_provider-tagged rows
	# pass through even when the filename has WEB-DL/AMZN/RARBG, so the user keeps full access
	# to those same magnets via the non-RD debrids (handy when the multi-debrid dedup fix has
	# placed twin rows for the same hash). Same hash, two cache_provider rows: RD row drops,
	# TB row stays.
	def filter_banned_keywords(self, results):
		raw = settings.banned_keywords_filter()
		if not raw: return results
		tokens = [t.strip().lower() for t in raw.split(',') if t.strip()]
		if not tokens: return results
		return [r for r in results
				if r.get('scrape_provider') != 'external'
				or 'Real-Debrid' not in (r.get('cache_provider') or '')
				or not any(tok in (r.get('name') or '').lower() for tok in tokens)]

	def special_filter(self, results, file_type):
		enable_setting, key = settings.filter_status(file_type), self.filter_keys[file_type]
		if key == 'HEVC' and enable_setting == 0:
			hevc_max_quality = self._get_quality_rank(get_setting('fenlight.filter.hevc.%s' % ('max_autoplay_quality' if self.autoplay else 'max_quality'), '4K'))
			results = [i for i in results if not key in i['extraInfo'] or i['quality_rank'] >= hevc_max_quality]
		if enable_setting == 1:
			if key in ('D/VISION', 'HDR'):
				if not settings.filter_status({'D/VISION': 'hdr', 'HDR': 'dv'}[key]) == 0: results = [i for i in results if not key in i['extraInfo']]
				else: results = [i for i in results if not (key in i['extraInfo'] and not 'HYBRID' in i['extraInfo'])]
			else: results = [i for i in results if not key in i['extraInfo']]
		# LOCAL PATCH 2026-06-15: per-codec Sort to Top (port from POV 5.12). When the
		# filter setting is 2, bubble items whose extraInfo contains this codec/HDR
		# key to the top while preserving relative order within each group (stable).
		# Applies to HEVC/HDR/DV/AV1 — each codec's setting acts independently and
		# they stack: later filters in the special_filter loop will sort on top of
		# earlier ones, so the LAST processed codec ends up most-on-top.
		elif enable_setting == 2:
			priority = [i for i in results if key in i['extraInfo']]
			if priority and len(priority) != len(results):
				priority_ids = {id(i) for i in priority}
				remainder = [i for i in results if id(i) not in priority_ids]
				results = priority + remainder
		return results

	def sort_preferred_filters(self, results):
		if settings.sort_to_top_filter(self.autoplay):
			try:
				preferences = settings.preferred_filters()
				if not preferences: return results
				preferences = [self.filter_keys.get(i.lower(), i) for i in preferences]
				preference_results = [i for i in results if any(x in i['extraInfo'] for x in preferences)]
				if not preference_results: return results
				results = [i for i in results if not i in preference_results]
				preference_results = sorted([dict(item, **{'pref_includes': sum([{0:100, 1:50, 2:20, 3:10, 4:5, 5:2}[preferences.index(x)] \
					for x in [i for i in preferences if i in item['extraInfo']]])}) for item in preference_results], key=lambda k: k['pref_includes'], reverse=True)
				return preference_results + results
			except: pass
		return results

	def sort_first(self, results):
		try:
			sort_first_scrapers = []
			if 'folders' in self.all_scrapers and settings.sort_to_top('folders'): sort_first_scrapers.append('folders')
			sort_first_scrapers.extend([i for i in self.all_scrapers if i in ('rd_cloud', 'pm_cloud', 'ad_cloud', 'tb_cloud') and settings.sort_to_top(i)])
			if not sort_first_scrapers: return results
			sort_first = [i for i in results if i['scrape_provider'] in sort_first_scrapers]
			sort_first.sort(key=lambda k: (self._sort_folder_to_top(k['scrape_provider']), k['quality_rank']))
			sort_last = [i for i in results if not i in sort_first]
			results = sort_first + sort_last
		except: pass
		return results

	def limit_quality_numbers(self, results):
		if self.autoplay or self.ignore_scrape_filters: return results
		quality_limit = settings.limit_number_quality()
		if not quality_limit: return results
		quality_counter_dict, limit_list = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0, 'SCR': 0, 'CAM': 0, 'TELE': 0}, []
		for i in results:
			if quality_counter_dict[i['quality']] < quality_limit:
				quality_counter_dict[i['quality']] += 1
				limit_list.append(i)
		return limit_list

	def limit_quality_total(self, results):
		if self.autoplay or self.ignore_scrape_filters: return results
		total_limit = settings.limit_number_total()
		if not total_limit: return results
		return results[:total_limit]

	def prepare_internal_scrapers(self):
		if self.active_external and len(self.active_internal_scrapers) == 1: return
		active_internal_scrapers = [i for i in self.active_internal_scrapers if not i in self.remove_scrapers]
		if self.prescrape and not self.active_external and all([settings.check_prescrape_sources(i, self.media_type) for i in active_internal_scrapers]): return False
		if 'folders' in active_internal_scrapers:
			folder_info = self.get_folderscraper_info()
			self.folder_info = [i for i in folder_info if settings.source_folders_directory(self.media_type, i[1])]
			if self.folder_info:
				self.active_folders = True
				self.internal_scraper_names = [i for i in active_internal_scrapers if not i == 'folders'] + [i[0] for i in self.folder_info]
			else: self.internal_scraper_names = [i for i in active_internal_scrapers if not i == 'folders']
		else:
			self.folder_info = []
			self.internal_scraper_names = active_internal_scrapers[:]
		self.active_internal_scrapers = active_internal_scrapers
		if self.clear_properties: self._clear_properties()
		return True

	def activate_providers(self, module_type, function, prescrape):
		sources = self._get_module(module_type, function).results(self.search_info)
		if not sources: return
		if prescrape: self.prescrape_sources.extend(sources)
		else: self.sources.extend(sources)

	def activate_external_providers(self):
		self.external_providers = self.external_sources()
		if not self.external_providers: self.disable_external('No External Providers Enabled')

	def disable_external(self, line1=''):
		if line1: kodi_utils.notification(line1, 2000)
		try: self.active_internal_scrapers.remove('external')
		except: pass
		self.active_external, self.external_providers = False, []

	def internal_sources(self, prescrape=False):
		active_sources = [i for i in self.active_internal_scrapers if i in ['easynews', 'rd_cloud', 'pm_cloud', 'ad_cloud', 'tb_cloud', 'aiostreams', 'http_streams']]
		try: sourceDict = [('internal', manual_function_import('scrapers.%s' % i, 'source'), i) for i in active_sources \
												if not (prescrape and not settings.check_prescrape_sources(i, self.media_type))]
		except: sourceDict = []
		return sourceDict

	def external_sources(self):
		append_module_to_syspath('special://home/addons/%s/lib' % self.ext_folder)
		try: sourceDict = manual_function_import(self.ext_name, 'sources')(specified_folders=['torrents'], ret_all=self.disabled_ext_ignored)
		except: sourceDict = []
		return sourceDict

	def folder_sources(self):
		def import_info():
			for item in self.folder_info:
				scraper_name = item[0]
				module = manual_function_import('scrapers.folders', 'source')
				yield ('folders', (module, (item[1], scraper_name, item[2])), scraper_name)
		# LOCAL PATCH 2026-08-31: an identical unguarded call sat above this try. It did the
		# full import work, threw the result away, and -- being outside the try -- raised
		# past the except that exists to catch exactly that failure.
		try: sourceDict = list(import_info())
		except: sourceDict = []
		return sourceDict

	def play_source(self, results):
		matched = self._sticky_match(results)
		if matched is not None:
			self.play_file([matched], matched)
			if self.playback_successful: return
			# LOCAL PATCH 2026-07-02: read self.user_cancelled (genuine user Back / cancel),
			# not self.cancel_all_playback (which also fires on playback failure).
			user_cancelled = self.user_cancelled
			self._sticky_reset_play_state()
			if user_cancelled:
				from modules.kodi_utils import logger
				logger('SmartPlay', 'user cancelled sticky resolve; aborting (sticky preserved)')
				return
			from modules.kodi_utils import logger, notification
			# LOCAL PATCH 2026-09-07: mirrors the sticky-MISS handling below. Under background /
			# autoplay the handoff has already stopped the previous episode, so a picker here
			# strands the user exactly as a miss did -- the pinned source failing to play is no
			# stronger a reason to halt the show than its being absent. Drop the source that just
			# failed, prefer the pin's release group among what is left, and play on. Foreground
			# keeps the picker (2026-08-31 reasoning: the user is at the screen, nothing stopped).
			if self.background or self.autoplay:
				rest = [i for i in results if i is not matched]
				if rest:
					logger('SmartPlay', 'sticky-matched source failed; playing best of remaining %d' % len(rest))
					notification('SmartPlay: saved source failed - playing best match', 3000)
					return self.play_file(self._prefer_pinned_group(rest))
			logger('SmartPlay', 'sticky-matched source failed; showing picker')
			notification('SmartPlay: saved source failed - showing picker', 3000)
			return self.display_results(results)
		# LOCAL PATCH 2026-08-31: a sticky MISS opens the picker even when background/autoplay
		# would otherwise play results[0] silently. The next-episode handler passes
		# background='true' (episode_tools.next_episode_info), so without this the pinned
		# source merely being absent meant some other source played unannounced -- the
		# opposite of what pinning one is for. Deliberately narrow: needs SmartPlay on AND a
		# saved entry for this show AND a failed match. No sticky saved, SmartPlay off,
		# prescrape and in-dialog rescrape all keep plain upstream behaviour.
		if getattr(self, 'sticky_miss', False):
			from modules.kodi_utils import notification
			# LOCAL PATCH 2026-09-06: narrowed from "always show the picker". On the background /
			# autoplay path autoplay_nextep_handler has ALREADY stopped the previous episode for
			# the handoff, so a picker here strands the user on a dialog instead of continuing the
			# show. A miss is also a weak signal: the pinned release is often merely absent from
			# one scrape run and present in the next -- BLACK TORCH S01E08 missed against 10
			# results at 10:14:21 and same-release matched at 10:16:31. Play the best result and
			# say so. Foreground plays keep the picker: nothing was stopped and the user is there.
			if self.background or self.autoplay:
				notification('SmartPlay: saved source not found - playing best match', 3000)
				return self.play_file(self._prefer_pinned_group(results))   # LOCAL PATCH 2026-09-07
			notification('SmartPlay: saved source not found - showing picker', 3000)
			return self.display_results(results)
		if self.background or self.autoplay: return self.play_file(results)
		return self.display_results(results)

	def _smartplay_enabled(self):
		return get_setting('fenlight.smartplay.enabled', 'false') == 'true'

	def _sticky_load_all(self):
		try:
			raw = get_setting('fenlight.smartplay.state', '')
			if not raw or raw == 'empty_setting': return {}
			data = json.loads(raw)
			return data if isinstance(data, dict) else {}
		except: return {}

	def _sticky_save_all(self, data):
		try:
			from caches.settings_cache import set_setting
			set_setting('smartplay.state', json.dumps(data) if data else 'empty_setting')
		except: pass

	def _sticky_reset_play_state(self):
		self.resolve_dialog_made = False
		self.progress_dialog, self.progress_thread = None, None
		self.playback_successful, self.cancel_all_playback, self.user_cancelled = None, False, False

	def _sticky_match(self, results):
		from modules.kodi_utils import logger
		import re
		# LOCAL PATCH 2026-08-31: this returns None for six different reasons and only ONE of
		# them -- a sticky entry exists for this show but nothing in the results matches it --
		# should change what play_source does. Flag that case specifically; every early
		# return below leaves it False so unrelated paths keep plain upstream behaviour.
		self.sticky_miss = False
		if not self._smartplay_enabled(): return None
		# LOCAL PATCH 2026-08-31 (doc only): tested by KEY PRESENCE, not value -- passing
		# prescrape:'false' still disables SmartPlay. Right today by accident: every branch
		# of the rescrape menu (dialogs.py:784-889) and the autoscrape chain
		# (episode_tools.py:96) set the key and all of them SHOULD let the user choose.
		# The next caller to add it for an unrelated reason turns SmartPlay off unaware.
		if 'prescrape' in self.params: return None
		if self.scrape_count > 1:
			logger('SmartPlay', 'in-dialog rescrape detected; bypassing sticky match to let user pick')
			return None
		if not results: return None
		# LOCAL PATCH 2026-09-04: drop anything this attempt has already proved dead before
		# any tier looks at it, so the name tiers cannot re-offer it either.
		_dead = getattr(self, '_sticky_dead_hashes', None)
		if _dead:
			_before = len(results)
			results = [i for i in results if (i.get('hash') or '').lower() not in _dead]
			if len(results) != _before:
				logger('SmartPlay', 'skipping %d result(s) whose resolve already failed this attempt'
					% (_before - len(results),))
			if not results: return None
		state = self._sticky_load_all().get(str(self.tmdb_id))
		if not state: return None
		saved_hash = (state.get('hash') or '').lower()
		saved_name = state.get('last_name') or ''
		if saved_hash:
			for item in results:
				if (item.get('hash') or '').lower() == saved_hash:
					logger('SmartPlay hash match', '%s' % saved_hash[:12])
					return item
		if saved_name:
			lp = re.sub(r'\[[0-9A-Fa-f]{8,}\]', '', saved_name).strip()
			for item in results:
				rel = re.sub(r'\[[0-9A-Fa-f]{8,}\]', '', item.get('name', '') or '').strip()
				if rel == lp:
					logger('SmartPlay name exact match', rel[:80])
					return item
			if self.media_type == 'episode':
				# LOCAL PATCH 2026-08-31: this fallback exists to follow a sticky source to the
				# NEXT episode -- same group, same quality, one number changed. It used to check
				# only that a candidate matched the saved name except for L characters at some
				# digit position, and never that those characters were the episode being asked
				# for; startswith/endswith do not constrain length either. With S01E05 sticky and
				# episode 6 requested it therefore matched S01E01 (whichever came first in the
				# scrape), S02E05, S01E0999, even a 2080p re-encode -- reported as "it just plays
				# the first episode it finds" whenever the exact sticky source was gone.
				#
				# Three guards now: the lengths must agree so it is a substitution rather than a
				# prefix, the substituted digits must BE the wanted episode, and the result is
				# confirmed with seas_ep_filter so no other digit in the name can stand in for
				# the episode number.
				ep_forms = []
				for _form in (str(self.episode or 0), str(self.episode or 0).zfill(2)):
					if _form not in ep_forms: ep_forms.append(_form)
				for ep in ep_forms:
					L = len(ep)
					digit_positions = [i for i in range(len(lp) - L + 1) if lp[i:i + L].isdigit()]
					if not digit_positions: continue
					for item in results:
						rel = re.sub(r'\[[0-9A-Fa-f]{8,}\]', '', item.get('name', '') or '').strip()
						if len(rel) != len(lp): continue
						for pos in digit_positions:
							if rel[pos:pos + L] != ep: continue
							if not (rel.startswith(lp[:pos]) and rel.endswith(lp[pos + L:])): continue
							try:
								if not seas_ep_filter(int(self.season), int(self.episode), rel): continue
							except Exception: continue
							logger('SmartPlay name position match', rel[:80])
							return item
				# LOCAL PATCH 2026-09-01: same-release tier. The position match above can only follow a
				# pin when ONE digit run changes, so it fails outright on names that embed the episode
				# TITLE: 'Naruto.S01E01.Enter.Naruto.Uzumaki...-iVy' against S01E02's '<other title>'
				# differ in LENGTH and every candidate is rejected before a digit is examined. That is
				# every AIOStreams pin, because that path has no torrent to re-index --
				# _sticky_aiostreams_play has to find a DIFFERENT stream for the next episode and knows
				# it only by name. Observed: 'unmatched in 10 results' for e=2 and e=3, while e=1
				# matched exactly because the pin WAS e=1.
				#
				# So follow the release's stable identity -- group, source family, quality -- and let
				# seas_ep_filter be the sole authority on WHICH episode. That gate is not optional:
				# 847bf62 exists because a loose matcher replayed the wrong episode, and every test
				# here is looser than the one it follows. No group in the pin (an underscore-separated
				# group, say) means no tier -- fall through to the picker rather than guess.
				pin_group = release_group(lp)
				# LOCAL PATCH 2026-09-03: say WHY the tier found nothing. It used to report only
				# 'unmatched in N results', which is indistinguishable between 'the tier never ran
				# because the pin had no parseable group' and 'it ran and every candidate failed on
				# one axis'. Both happened on Shield Hero within four minutes and the log could not
				# tell them apart. Same idea as nyaa's rejects={...} line, which is what made the
				# One Piece numbering bug findable.
				_t4 = {}
				if not pin_group:
					logger('sticky.tier4', 'skipped: no parseable group in pin %r' % lp[:70])
				if pin_group:
					pin_source = release_source(release_norm(lp))
					pin_quality = get_release_quality(lp.lower())
					pin_service = release_service(release_norm(lp))
					same_release = []
					for item in results:
						rel = item.get('name', '') or ''
						if not rel:
							_t4['no_name'] = _t4.get('no_name', 0) + 1
							continue
						try:
							if not seas_ep_filter(int(self.season), int(self.episode), rel):
								_t4['episode'] = _t4.get('episode', 0) + 1
								continue
						except Exception:
							_t4['episode_error'] = _t4.get('episode_error', 0) + 1
							continue
						if release_group(rel) != pin_group:
							_t4['group'] = _t4.get('group', 0) + 1
							continue
						# Normalised once: release_source and release_service both want it, and this was
						# running release_norm twice for every candidate.
						rel_norm = release_norm(rel)
						if release_source(rel_norm) != pin_source:
							_t4['source'] = _t4.get('source', 0) + 1
							continue
						if get_release_quality(rel.lower()) != pin_quality:
							_t4['quality'] = _t4.get('quality', 0) + 1
							continue
						# A pin that names its service must stay on it. Only enforced when the PIN
						# carries a tag: an untagged pin has told us nothing to hold it to, and the
						# picker is a fine outcome when nothing qualifies.
						if pin_service and release_service(rel_norm) != pin_service:
							_t4['service'] = _t4.get('service', 0) + 1
							continue
						same_release.append(item)
					if not same_release:
						logger('sticky.tier4', 'no candidate matched pin group=%s source=%s quality=%s service=%s -- rejected on %s'
									% (pin_group, pin_source, pin_quality, pin_service or '-', _t4 or '{}'))
					if same_release:
						# Largest first, as pick_episode_files does out of a pack: among identical
						# releases of one episode the biggest file is the real one, not a sample.
						same_release.sort(key=lambda i: i.get('size') or 0, reverse=True)
						best = same_release[0]
						logger('SmartPlay same-release match', (best.get('name', '') or '')[:80])
						return best
		# Reached only when a sticky entry EXISTS and no tier matched it -- not hash, not exact
		# name, not position, not same-release. The saved source is genuinely absent here.
		self.sticky_miss = True
		logger('SmartPlay', 'sticky entry present but unmatched in %s results' % len(results))
		return None

	def _sticky_save(self, source):
		from modules.kodi_utils import logger
		if not self._smartplay_enabled(): return
		if not source or not self.tmdb_id: return
		try:
			entry = {
				'last_name': source.get('name', '') or '',
				'hash': (source.get('hash') or '').lower(),
				'scrape_provider': source.get('scrape_provider', ''),
				'ts': int(time.time()),
			}
			pkg_raw = source.get('package', '')
			cache_provider = source.get('cache_provider', '')
			magnet_url = source.get('url') or source.get('url_dl') or ''
			scrape_provider = source.get('scrape_provider', '')
			if cache_provider in ('Real-Debrid', 'Premiumize.me', 'AllDebrid', 'TorBox') and magnet_url and entry['hash']:
				if pkg_raw in ('show', 'season'): pack_default = pkg_raw
				elif self.media_type != 'episode': pack_default = ''
				# LOCAL PATCH 2026-09-06: was unconditionally 'season' for every episode pin, which is
				# what made pack-play fail on every transition. See _SINGLE_FILE_NAME.
				elif _SINGLE_FILE_NAME.search(entry['last_name'] or ''): pack_default = 'episode'
				else: pack_default = 'season'
				entry['pack'] = {
					'type': 'debrid',
					'cache_provider': cache_provider,
					'url': magnet_url,
					'hash': entry['hash'],
					'name': entry['last_name'],
					'package': pack_default,
					# LOCAL PATCH 2026-09-06: which episode this pin actually holds, so a single-file
					# pin can still pack-play an instant REPLAY of the same episode while being
					# skipped for every other one.
					'season': getattr(self, 'season', None),
					'episode': getattr(self, 'episode', None),
					'quality': source.get('quality', 'SD'),
					'size': source.get('size', 0),
					'size_label': source.get('size_label', ''),
					'extraInfo': source.get('extraInfo', ''),
					'debrid': source.get('debrid', cache_provider),
					'scrape_provider': scrape_provider or 'external',
					'media_type': self.media_type,
				}
			elif scrape_provider == 'aiostreams':
				entry['pack'] = {
					'type': 'aiostreams',
					'name': entry['last_name'],
					'hash': entry['hash'],
					'media_type': self.media_type,
				}
			data = self._sticky_load_all()
			data[str(self.tmdb_id)] = entry
			if len(data) > 10:
				data = dict(sorted(data.items(), key=lambda kv: kv[1].get('ts', 0), reverse=True)[:10])
			self._sticky_save_all(data)
			logger('SmartPlay save', 'tmdb=%s pack=%s name=%s' % (self.tmdb_id, 'pack' in entry, entry['last_name'][:80]))
		except Exception as e: logger('SmartPlay save exception', str(e))

	def _sticky_touch(self):
		"""LOCAL PATCH 2026-09-07: refresh the pin timestamp after a successful pack-play.
		_sticky_save only runs when a source is chosen in the results window, and the pin
		store is a 10-entry LRU on ts -- so a show watched daily via pack-play never had its
		stamp touched, and ten picker choices on OTHER shows would silently evict the one
		pin that was working best. Touch only; nothing else about the pin changes."""
		try:
			data = self._sticky_load_all()
			entry = data.get(str(self.tmdb_id))
			if not entry: return
			entry['ts'] = int(time.time())
			self._sticky_save_all(data)
		except Exception: pass

	def _prefer_pinned_group(self, results):
		"""LOCAL PATCH 2026-09-07: soft group affinity for the best-match fallback.
		_sticky_match tier 4 demands group AND source AND quality AND service; on a miss the
		fallback then played results[0] blind. The 10:14 BLACK TORCH miss rejected five
		candidates on group alone -- their other axes matched -- so a same-group release at
		another quality was sitting right there. Stable partition: same-group items first,
		the rest after, each half keeping the scrape's own order. Not a new tier: it changes
		nothing about WHICH episode plays (seas_ep_filter still gates every item promoted),
		only which of the already-acceptable results is tried first."""
		try:
			state = self._sticky_load_all().get(str(self.tmdb_id)) or {}
			lp = re.sub(r'\[[0-9A-Fa-f]{8,}\]', '', state.get('last_name') or '').strip()
			pin_group = release_group(lp) if lp else None
			if not pin_group: return results
			same, rest = [], []
			for item in results:
				rel = item.get('name', '') or ''
				ok = False
				if rel and release_group(rel) == pin_group:
					if self.media_type == 'episode':
						try: ok = bool(seas_ep_filter(int(self.season), int(self.episode), rel))
						except Exception: ok = False
					else: ok = True
				(same if ok else rest).append(item)
			if same:
				from modules.kodi_utils import logger
				logger('SmartPlay', 'group affinity: %d of %d results share pin group %s; trying those first' % (len(same), len(results), pin_group))
				return same + rest
			return results
		except Exception:
			return results

	def _sticky_pack_play(self):
		if not self._smartplay_enabled(): return False
		# LOCAL PATCH 2026-08-31 (doc only): tested by KEY PRESENCE, not value -- passing
		# prescrape:'false' still disables SmartPlay. Right today by accident: every branch
		# of the rescrape menu (dialogs.py:784-889) and the autoscrape chain
		# (episode_tools.py:96) set the key and all of them SHOULD let the user choose.
		# The next caller to add it for an unrelated reason turns SmartPlay off unaware.
		if 'prescrape' in self.params: return False
		pack = (self._sticky_load_all().get(str(self.tmdb_id)) or {}).get('pack')
		if not pack: return False
		ptype = pack.get('type') or ('debrid' if pack.get('cache_provider') else '')
		# LOCAL PATCH 2026-09-06 (revised): key this on the pin's own NAME, not on the stored
		# package label. The first version required package=='episode' plus a recorded
		# season/episode and so missed both real cases in kodi.log the same day:
		#   - tmdb 285993 was pinned BEFORE the patch, has neither field, and kept paying the
		#     futile resolve (12:33:15 -> 12:33:17 'resolve_cached returned None').
		#   - tmdb 260463 WAS saved by patched code, but its provider name carries no file
		#     extension ('...S01E22.1080p.CR.WEB-DL.AAC.2'), so it was still labelled 'season'.
		# A name saying SxxExx names ONE episode; if that is not the episode being asked for,
		# the torrent cannot hold it -- skip to the scrape and let _sticky_match's same-release
		# tiers follow the pin. A genuine pack ('...S01.1080p', no Exx) has no marker and is
		# untouched. Name-keyed, so it also heals pins saved before today with no re-save.
		# seas_ep_filter stays non-strict on purpose: a false positive only means we do NOT
		# skip, i.e. exactly today's behaviour.
		_pin_name = pack.get('name') or ''
		if self.media_type == 'episode' and _EPISODE_MARKER.search(_pin_name):
			try: _wanted = seas_ep_filter(int(self.season), int(self.episode), _pin_name)
			except Exception: _wanted = True
			if not _wanted:
				from modules.kodi_utils import logger
				logger('SmartPlay pack-play', 'pin names one episode (%s); skipping pack resolve for S%sE%s'
					% (_pin_name[:60], self.season, self.episode))
				return False
		# LOCAL PATCH 2026-09-07: the season-pack counterpart of the check above. A pin named
		# '...S01.2160p...' (tmdb 323557, Lion) IS a pack, so the Exx test rightly leaves it
		# alone -- but once S01 is finished and S02E01 is requested, pack-play would search the
		# S01 torrent for it: the same futile resolve, different shape. One Sxx token and no Exx
		# names one season; if that is not the season requested, skip. Multi-season packs
		# ('S01-S05', 'S01.S02') carry several tokens and are left alone, since any of them
		# might hold the episode. The recorded pack.season is preferred when the pin has it;
		# the name is the fallback for pins saved before it was recorded.
		if self.media_type == 'episode' and not _EPISODE_MARKER.search(_pin_name):
			_seasons = _SEASON_MARKER.findall(_pin_name)
			if len(_seasons) == 1:
				try:
					_pin_season = pack.get('season')
					_pin_season = int(_pin_season) if _pin_season is not None else int(_seasons[0])
					if _pin_season != int(self.season):
						from modules.kodi_utils import logger
						logger('SmartPlay pack-play', 'pin is a season pack for S%02d (%s); skipping pack resolve for S%sE%s'
							% (_pin_season, _pin_name[:50], self.season, self.episode))
						return False
				except Exception: pass
			# LOCAL PATCH 2026-09-13: the anime absolute-numbering gap. Reached when the name
			# carries NO Exx and NO Sxx at all -- the fansub shape, 'Okusama.ga.Seitokaichou!.-.03.
			# [...].mkv'. Both tests above are keyed on the pin NAME, and neither can read that,
			# so pack-play went on to resolve the torrent for whatever episode was asked next.
			# That is the wrong-episode bug: the pin holds exactly episode 03 and nothing else.
			# The pin itself already knows. _sticky_save saw the name end '.mkv', so
			# _SINGLE_FILE_NAME matched and package was written 'episode', alongside the season
			# and episode it was pinned for. Those ints are written by our own code rather than
			# parsed out of a provider string, so once the name has told us nothing they are the
			# only trustworthy thing left -- this is the metadata test from the first 2026-09-06
			# version, restored as a FALLBACK rather than as the primary test, so the two cases
			# that made it fail then (no recorded fields; name with no extension) still take the
			# name path above and are unaffected.
			# elif, so a pin with one or more Sxx tokens keeps the season-pack behaviour above.
			elif not _seasons:
				try:
					_pin_pkg = pack.get('package') or ''
					_pin_s, _pin_e = pack.get('season'), pack.get('episode')
					# Both halves must be certain before skipping. package=='episode' means
					# _SINGLE_FILE_NAME matched at save time, i.e. the pin is ONE file, and both
					# ints must actually be recorded -- a pin saved before 2026-09-06 has neither
					# and must fall through rather than be guessed at. The errors here are
					# asymmetric: NOT skipping costs one futile ~1.5s resolve_cached and lands on
					# today's behaviour, while skipping wrongly loses a pack-play that would have
					# worked, so anything less than certain falls through.
					if _pin_pkg == 'episode' and _pin_s is not None and _pin_e is not None:
						# Compare the PAIR, and compare it in TMDb space. Both sides were written
						# from self.season/self.episode -- the pin's copy at save time, ours now --
						# so the filename's absolute '03' never enters the comparison and cannot
						# mislead it. That is the whole reason this test works where the name tests
						# cannot. != rather than an unconditional skip keeps the instant REPLAY the
						# 2026-09-06 patch added: same episode asked for again still pack-plays.
						# int() both sides -- self.season/self.episode are strings on this path.
						if (int(_pin_s), int(_pin_e)) != (int(self.season), int(self.episode)):
							from modules.kodi_utils import logger
							logger('SmartPlay pack-play', 'pin is a single file holding S%02dE%02d (%s); skipping pack resolve for S%sE%s'
								% (int(_pin_s), int(_pin_e), _pin_name[:50], self.season, self.episode))
							return False
				# The except stays -- nothing here may raise into pack-play -- but it must not be
				# SILENT. int() is the realistic raiser: self.season/self.episode are strings on
				# this path and a pin could hold '' or a non-numeric from an older save. Swallowed
				# quietly, the skip simply never fires and the symptom is the wrong episode playing
				# with no line in the log saying why -- indistinguishable from the patch not being
				# installed at all. Falling through is still the right behaviour; only the silence
				# is wrong.
				except Exception as e:
					try:
						from modules.kodi_utils import logger
						logger('SmartPlay pack-play', 'single-file pin test failed (%s: %s); pin s=%r e=%r asked s=%r e=%r -- proceeding with pack resolve'
							% (type(e).__name__, e, pack.get('season'), pack.get('episode'), self.season, self.episode))
					except Exception: pass
		if ptype == 'aiostreams': return self._sticky_aiostreams_play()
		if ptype == 'debrid': return self._sticky_debrid_play(pack)
		return False

	def _sticky_debrid_play(self, pack):
		from modules.kodi_utils import logger
		cache_provider = pack.get('cache_provider', '')
		info_hash = pack.get('hash', '')
		magnet_url = pack.get('url', '')
		pack_type = pack.get('package', 'season')
		if not (cache_provider and info_hash and magnet_url): return False
		is_episode = self.media_type == 'episode'
		logger('SmartPlay pack-play[debrid]', 'cache=%s hash=%s media=%s s=%s e=%s' % (cache_provider, info_hash[:12], self.media_type, self.season, self.episode))
		try: title = self.meta.get('title', '') if isinstance(getattr(self, 'meta', None), dict) else ''
		except: title = ''
		try:
			kodi_utils.show_busy_dialog()
			if is_episode:
				# LOCAL PATCH 2026-08-27: this path is a pack by definition, so the anime
				# numbering alternatives matter here even more than on the normal resolve path.
				_cands = anime_episode_candidates(self.meta, (self.meta or {}).get('tmdb_id'), int(self.season), int(self.episode))
				url = self.resolve_cached(cache_provider, magnet_url, info_hash, title, int(self.season), int(self.episode), pack_type in ('show', 'season'), _cands)
			else:
				url = self.resolve_cached(cache_provider, magnet_url, info_hash, title, None, None, False)
		except Exception as e:
			logger('SmartPlay pack-play[debrid] resolve error', str(e))
			url = None
		finally:
			kodi_utils.hide_busy_dialog()
		if not url:
			# LOCAL PATCH 2026-09-04: remember that this hash did not resolve, so the fallback
			# scrape below does not hand it straight back. The pin is unchanged in state, so
			# _sticky_match's hash tier matched the very same torrent seconds later and played
			# it into the same failure -- observed on Chainsmoker Cat S01E09:
			#   09:07:59  pack-play[debrid] resolve_cached returned None
			#   09:08:02  SmartPlay hash match e24a8dcced8f      <- the hash that just failed
			#   09:08:04  sticky-matched source failed; showing picker
			# Instance-scoped on purpose: it is one playback attempt's verdict, not a lasting
			# judgement on the torrent, and playback_prep runs pack-play and the scrape on the
			# same Sources object. The pin itself is deliberately left alone.
			try:
				if info_hash: self._sticky_dead_hashes.add(str(info_hash).lower())
			except Exception: pass
			logger('SmartPlay pack-play[debrid]', 'resolve_cached returned None; falling back to scrape')
			return False
		source = {
			'name': pack.get('name', ''),
			'display_name': pack.get('name', ''),
			'quality': pack.get('quality', 'SD'),
			'size': pack.get('size', 0),
			'size_label': pack.get('size_label', '0.00 GB'),
			'extraInfo': pack.get('extraInfo', ''),
			'url': magnet_url,
			'url_dl': magnet_url,
			'id': info_hash,
			'hash': info_hash,
			'cache_provider': cache_provider,
			'debrid': pack.get('debrid', cache_provider),
			'scrape_provider': pack.get('scrape_provider', 'external'),
			'package': pack_type,
			'local': False,
			'direct': False,
		}
		try: self.play_file([source], source)
		except Exception as e: logger('SmartPlay pack-play[debrid] play_file error', str(e))
		if self.playback_successful:
			self._sticky_touch()   # LOCAL PATCH 2026-09-07: keep a working pin from ageing out of the LRU
			return True
		# LOCAL PATCH 2026-07-02: check user_cancelled (set only on genuine user Back-press /
		# next-ep cancel), NOT cancel_all_playback (which also fires on playback failure —
		# exhaustion / monitor exception). Prior code treated any cancel_all_playback=True as
		# user-cancel, so a bad sticky source silently closed the picker instead of falling
		# through to a fresh scrape. Now: user-cancel → return True (preserve sticky, no
		# retry); playback failure → return False (fresh scrape → picker opens).
		if self.user_cancelled:
			logger('SmartPlay pack-play[debrid]', 'user cancelled; aborting (no fallback scrape)')
			self._sticky_reset_play_state()
			return True
		logger('SmartPlay pack-play[debrid]', 'play_file failed; falling back to scrape')
		self._sticky_reset_play_state()
		return False

	def _sticky_aiostreams_play(self):
		from modules.kodi_utils import logger
		logger('SmartPlay pack-play[aiostreams]', 'media=%s s=%s e=%s' % (self.media_type, self.season, self.episode))
		try:
			from scrapers.aiostreams import source as aios_source
			info = getattr(self, 'search_info', None) or {
				'media_type': self.media_type,
				'imdb_id': self.meta.get('imdb_id') if isinstance(getattr(self, 'meta', None), dict) else '',
				'title': self.meta.get('title', '') if isinstance(getattr(self, 'meta', None), dict) else '',
				'year': self.meta.get('year', '') if isinstance(getattr(self, 'meta', None), dict) else '',
				'season': self.season,
				'episode': self.episode,
				'aliases': self.meta.get('aliases', []) if isinstance(getattr(self, 'meta', None), dict) else [],
				'ep_name': self.meta.get('ep_name', '') if isinstance(getattr(self, 'meta', None), dict) else '',
			}
			kodi_utils.show_busy_dialog()
			results = aios_source().results(info) or []
		except Exception as e:
			logger('SmartPlay pack-play[aiostreams] scrape error', str(e))
			results = []
		finally:
			kodi_utils.hide_busy_dialog()
		if not results:
			logger('SmartPlay pack-play[aiostreams]', 'no results; falling back to scrape')
			return False
		matched = self._sticky_match(results)
		if matched is None:
			logger('SmartPlay pack-play[aiostreams]', 'no match in %d results; falling back to scrape' % len(results))
			return False
		try: self.play_file([matched], matched)
		except Exception as e: logger('SmartPlay pack-play[aiostreams] play_file error', str(e))
		if self.playback_successful:
			self._sticky_touch()   # LOCAL PATCH 2026-09-07: keep a working pin from ageing out of the LRU
			return True
		# LOCAL PATCH 2026-07-02: see _sticky_debrid_play — check user_cancelled, not
		# cancel_all_playback.
		if self.user_cancelled:
			logger('SmartPlay pack-play[aiostreams]', 'user cancelled; aborting (no fallback scrape)')
			self._sticky_reset_play_state()
			return True
		logger('SmartPlay pack-play[aiostreams]', 'play_file failed; falling back to scrape')
		self._sticky_reset_play_state()
		return False

	def append_folder_scrapers(self, current_list):
		current_list.extend(self.folder_sources())

	def get_folderscraper_info(self):
		folder_info = [(get_setting('fenlight.%s.display_name' % i), i, settings.source_folders_directory(self.media_type, i))
						for i in ('folder1', 'folder2', 'folder3', 'folder4', 'folder5')]
		return [i for i in folder_info if not i[0] in (None, 'None', '') and i[2]]

	def scrapers_dialog(self):
		def _scraperDialog():
			monitor = kodi_utils.kodi_monitor()
			start_time = time.time()
			while not self.progress_dialog.iscanceled() and not monitor.abortRequested():
				try:
					remaining_providers = [x.getName() for x in _threads if x.is_alive() is True]
					self._process_internal_results()
					current_progress = max((time.time() - start_time), 0)
					line1 = ', '.join(remaining_providers).upper()
					percent = int((current_progress/float(25))*100)
					self.progress_dialog.update_scraper(self.sources_sd, self.sources_720p, self.sources_1080p, self.sources_4k, self.sources_total, line1, percent)
					kodi_utils.sleep(self.sleep_time)
					if len(remaining_providers) == 0: break
					if percent >= 100: break
				except:	return self._kill_progress_dialog()
		if self.prescrape: scraper_list, _threads = self.prescrape_scrapers, self.prescrape_threads
		else: scraper_list, _threads = self.providers, self.threads
		self.internal_scrapers = self._get_active_scraper_names(scraper_list)
		if not self.internal_scrapers: return
		_scraperDialog()
		try: del monitor
		except: pass

	# LOCAL PATCH 2026-09-02: never draw the picker over a still-playing episode when the
	# scrape was the AUTOMATIC next-episode handoff.
	#
	# The next-ep alert fires at outro_start -- measured on Lanterns S01E02:
	# 'source=introdb_outro_start window_time=123s (4.0% before end of 3093s)' -- so the
	# scrape runs while the credits are still rolling. When SmartPlay could not chain, the
	# picker appeared over those last two minutes. Observed: picker at 19:20:10 against
	# CVideoPlayer::CloseFile() at 19:20:49, 38 seconds later.
	#
	# autoscrape_nextep_handler already waits (`while player.isPlayingVideo()`), and so does
	# random_continual_handler; the autoplay path never got it. Putting the wait in
	# display_results covers every route into the picker for that flow, including a rescrape
	# from _process_post_results, and is idempotent where the caller already waited.
	#
	# Gated on play_type, NOT on autoplay_nextep: that flag is simply the
	# autoplay_next_episode SETTING for an ordinary manual play (log shows
	# 'background=False autoplay_nextep=True' on hand-started scrapes), so keying off it
	# would also delay a picker the user opened mid-episode on purpose -- the usual reason
	# being a stalling stream they want to replace NOW. play_type is set only by
	# episode_tools' next-episode handoff and is '' for anything the user started.
	_NEXTEP_PLAY_TYPES = ('autoplay_nextep', 'autoscrape_nextep')

	def _wait_out_playback(self):
		if getattr(self, 'play_type', '') not in self._NEXTEP_PLAY_TYPES: return
		try:
			player = kodi_utils.kodi_player()
			if not player.isPlayingVideo(): return
			# LOCAL PATCH 2026-09-03: cut the credits rather than sit through them.
			#
			# We only reach here because the handoff could NOT auto-play -- SmartPlay did not
			# match, so a picker is coming. Nothing is going to take over the outro, and
			# _check_skip_segments has already marked it consumed without skipping (that is
			# what outro.mode 'autoplay_countdown' means: the alert owns the outro). So the
			# episode played its credits out with nothing on screen and the picker appeared
			# minutes later -- measured 09:59:32 -> 10:01:56, two and a half minutes.
			#
			# Gated on timing_confidence, which info_next_ep already computes for exactly this
			# kind of decision. 'high' means the window came from IntroDB outro data or a final
			# chapter, so everything left really is credits and ending here loses nothing.
			# 'low' is the percentage fallback -- an arbitrary point that can still have real
			# episode after it -- so that keeps waiting, which is the pre-existing behaviour.
			_ns = getattr(self, 'nextep_settings', None) or {}
			_conf, _srcname = _ns.get('timing_confidence'), _ns.get('transition_source')
			if _conf == 'high':
				kodi_utils.logger('DialogFlash display_results', 'no auto-play; ending credits early (source=%s) then opening picker' % _srcname)
				try:
					mark_internal_stop()   # ours, not the user's -- see onPlayBackStopped
					player.stop()
				except Exception: pass
			else:
				kodi_utils.logger('DialogFlash display_results', 'holding picker until playback ends (play_type=%s confidence=%s)' % (self.play_type, _conf))
			while player.isPlayingVideo(): kodi_utils.sleep(100)
		except Exception: pass

	def display_results(self, results):
		self._wait_out_playback()
		window_format, window_number = settings.results_format()
		action, chosen_item = open_window(('windows.sources', 'SourcesResults'), 'sources_results.xml',
				window_format=window_format, window_id=window_number, results=results, meta=self.meta, episode_group_label=self.episode_group_label,
				scraper_settings=self.scraper_settings, prescrape=self.prescrape, filters_ignored=self.filters_ignored,
				uncached_results=self.uncached_results, external_cache_check=self.external_cache_check)
		if not action: self._kill_progress_dialog()
		elif action == 'play':
			try: self._sticky_save(chosen_item)
			except: pass
			# LOCAL PATCH 2026-09-03: the user has just chosen this source by hand, so the
			# next-episode countdown must not then ask whether to play it. See
			# continue_resolve_check.
			self.chosen_by_user = True
			return self.play_file(results, chosen_item)
		elif self.prescrape and action == 'perform_full_search':
			self.prescrape, self.clear_properties = False, False
			return self.get_sources()
		elif action == 'cache_change_rescrape':
			self.external_cache_check = chosen_item == 'true'
			self.sources, self.orig_results, self.threads = [], [], []
			self.prescrape, self.clear_properties = False, False
			return self.get_sources()

	def _get_active_scraper_names(self, scraper_list):
		return [i[2] for i in scraper_list]

	def _process_post_results(self):
		if not self.retry_actions: return self._no_results()
		next_action, next_setting, order = self.retry_actions.pop(0)
		if next_action == 'cache_ignored':
			if next_setting in (1, 2) and self.active_external and self.orig_results and self.external_cache_check \
																				and debrid.debrid_for_ext_cache_check(self.debrid_enabled):
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With Cache Check Disabled?'):
					self.threads, self.prescrape, self.external_cache_check = [], False, False
					return self.get_sources()
			self._process_post_results()
		if next_action == 'imdb_year':
			if next_setting in (1, 2) and self.active_external and not self.orig_results and not self.meta.get('custom_year'):
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With IMDb Year Data?'):
					from apis.imdb_api import imdb_year_check
					imdb_year = str(imdb_year_check(self.meta.get('imdb_id')))
					if imdb_year != self.get_search_year():
						self.meta['custom_year'] = imdb_year
						self.make_search_info()
						self.threads, self.prescrape = [], False
						return self.get_sources()
			self._process_post_results()
		if next_action == 'with_all':
			if next_setting in (1, 2) and self.active_external:
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With All Scrapers?'):
					self.threads, self.disabled_ext_ignored, self.prescrape = [], True, False
					return self.get_sources()
			self._process_post_results()
		if next_action == 'episode_group':
			if next_setting in (1, 2) and self.media_type == 'episode':
				if next_setting == 1 \
											or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results.[CR]Retry With Custom Episode Group if Possible?'):
					if self.episode_group_used:
						self.params.update({'custom_season': None, 'custom_episode': None, 'episode_group_label': '[B]CUSTOM GROUP: S%02dE%02d[/B]' % (self.season, self.episode),
											'skip_episode_group_check': True})
						self.threads, self.disabled_ext_ignored, self.prescrape = [], True, False
						return self.playback_prep()
					if next_setting == 2:
						from indexers.dialogs import episode_groups_choice
						try: group_id = episode_groups_choice({'meta': self.meta, 'poster': self.meta['poster']})
						except: group_id = None
					else:
						try: group_id = metadata.episode_groups(self.tmdb_id)[0]['id']
						except: group_id = None
					if group_id:
						try: group_details = metadata.group_episode_data(metadata.group_details(group_id), None, self.season, self.episode)
						except: group_details = None
						if group_details:
							season, episode = group_details['season'], group_details['episode']
							self.params.update({'custom_season': season, 'custom_episode': episode, 'episode_group_label': '[B]CUSTOM GROUP: S%02dE%02d[/B]' % (season, episode)})
							self.threads, self.disabled_ext_ignored, self.prescrape = [], True, False
							return self.playback_prep()
			self._process_post_results()
		if next_action == 'ignore_filters':
			if next_setting in (1, 2) and self.orig_results and not self.background:
				if next_setting == 1 or kodi_utils.confirm_dialog(heading=self.meta.get('rootname', ''), text='No results. Access Filtered Results?'):
					if self.autoplay: kodi_utils.notification('Filters Ignored & Autoplay Disabled')
					self.threads, self.ignore_scrape_filters, self.disabled_ext_ignored, self.autoplay = [], True, True, False
					return self.get_sources()
			self._process_post_results()

	def _no_results(self):
		self._kill_progress_dialog()
		try: kodi_utils.hide_busy_dialog()
		except: pass
		if self.background: return kodi_utils.notification('[B]Next Up:[/B] No Results', 5000)
		title = self.meta.get('title') or self.meta.get('rootname') or ''
		text = 'No sources found' + ((' for [B]%s[/B]' % title) if title else '')
		try: kodi_utils.ok_dialog(heading='No Results', text=text)
		except: kodi_utils.notification('No Results', 3000)

	def get_search_title(self):
		search_title = self.meta.get('custom_title', None) or self.meta.get('english_title') or self.meta.get('title')
		return search_title

	def get_search_year(self):
		year = self.meta.get('custom_year', None) or self.meta.get('year')
		return year

	def get_season(self):
		season = self.meta.get('custom_season', None) or self.meta.get('season')
		try: season = int(season)
		except: season = None
		return season

	def get_episode(self):
		episode = self.meta.get('custom_episode', None) or self.meta.get('episode')
		try: episode = int(episode)
		except: episode = None
		return episode

	def get_ep_name(self):
		ep_name = None
		if self.meta['media_type'] == 'episode':
			ep_name = self.meta.get('ep_name')
			try: ep_name = safe_string(remove_accents(ep_name))
			except: ep_name = safe_string(ep_name)
		return ep_name

	def _process_internal_results(self):
		for i in self.internal_scrapers:
			win_property = kodi_utils.get_property('fenlight.internal_results.%s' % i)
			if win_property in ('checked', '', None): continue
			try: sources = json.loads(win_property)
			except: continue
			kodi_utils.set_property('fenlight.internal_results.%s' % i, 'checked')
			self._sources_quality_count(sources)
	
	def _sources_quality_count(self, sources):
		for item in self.count_tuple: setattr(self, item[0], getattr(self, item[0]) + item[2](sources, item[1]))

	def _quality_filter(self):
		setting = 'results_quality_%s' % self.media_type if not self.autoplay else 'autoplay_quality_%s' % self.media_type
		filter_list = settings.quality_filter(setting)
		if self.include_prerelease_results and 'SD' in filter_list: filter_list += ['SCR', 'CAM', 'TELE']
		return filter_list

	def _get_size_rank(self, item):
		if self.weight_size: return item['size'] * 2 if 'HEVC' in item['extraInfo'] else item['size']
		else: return item['size']

	def _get_quality_rank(self, quality):
		return {'4K': 1, '1080p': 2, '720p': 3, 'SD': 4, 'SCR': 5, 'CAM': 5, 'TELE': 5}[quality]

	def _get_provider_rank(self, account_type):
		return self.provider_sort_ranks[account_type] or 11

	def _sort_folder_to_top(self, provider):
		if provider == 'folders': return 0
		else: return 1

	def _sort_uncached_results(self, results):
		uncached = [i for i in results if 'Uncached' in i.get('cache_provider', '')]
		cached = [i for i in results if not i in uncached]
		return cached + uncached

	def get_meta(self):
		prefetched = self.params.get('_prefetched_meta') if isinstance(self.params, dict) else None
		if (self.media_type == 'episode' and isinstance(prefetched, dict)
				and 'tvshow_plot' in prefetched and 'season_data' in prefetched):
			self.meta = prefetched
			self.meta.update({'playcount': self.playcount, 'watch_count': self.watch_count,
							'custom_season': self.custom_season, 'custom_episode': self.custom_episode})
		elif self.media_type == 'movie':
			self.meta = metadata.movie_meta('tmdb_id', self.tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
		else:
			try:
				self.meta = metadata.tvshow_meta('tmdb_id', self.tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), get_datetime())
				episodes_data = metadata.episodes_meta(self.season, self.meta)
				episode_data = [i for i in episodes_data if i['episode'] == self.episode][0]
				ep_thumb = episode_data.get('thumb', None) or self.meta.get('fanart') or ''
				episode_type = episode_data.get('episode_type', '')
				self.meta.update({'season': episode_data['season'], 'episode': episode_data['episode'], 'premiered': episode_data['premiered'], 'episode_type': episode_type,
								'ep_name': episode_data['title'], 'ep_thumb': ep_thumb, 'plot': episode_data['plot'], 'tvshow_plot': self.meta['plot'],
								'playcount': self.playcount, 'watch_count': self.watch_count, 'custom_season': self.custom_season, 'custom_episode': self.custom_episode})
			except: pass
		self.meta.update({'media_type': self.media_type, 'background': self.background, 'custom_title': self.custom_title, 'custom_year': self.custom_year})

	def make_search_info(self):
		title, year, ep_name = self.get_search_title(), self.get_search_year(), self.get_ep_name()
		aliases = make_alias_dict(self.meta, title)
		expiry_times = get_cache_expiry(self.media_type, self.meta, self.season)
		self.search_info = {'media_type': self.media_type, 'title': title, 'year': year, 'tmdb_id': self.tmdb_id, 'imdb_id': self.meta.get('imdb_id'), 'aliases': aliases,
							'season': self.get_season(), 'episode': self.get_episode(), 'tvdb_id': self.meta.get('tvdb_id'), 'ep_name': ep_name, 'expiry_times': expiry_times,
							'total_seasons': self.meta.get('total_seasons', 1)}

	def _get_module(self, module_type, function):
		if module_type == 'external': module = function.source(*self.external_args)
		elif module_type == 'folders': module = function[0](*function[1])
		else: module = function()
		return module

	def _clear_properties(self):
		def_internal = self.default_internal_scrapers
		for item in def_internal: kodi_utils.clear_property('fenlight.internal_results.%s' % item)
		if self.active_folders:
			for item in self.folder_info: kodi_utils.clear_property('fenlight.internal_results.%s' % item[0])

	def _make_progress_dialog(self):
		from modules.kodi_utils import logger
		logger('DialogFlash _make_progress_dialog', 'creating new SourcesPlayback (background=%s, autoplay_nextep=%s)' % (self.background, getattr(self, 'autoplay_nextep', 'n/a')))
		try:
			self.progress_dialog = create_window(('windows.sources', 'SourcesPlayback'), 'sources_playback.xml', meta=self.meta)
			self.progress_thread = Thread(target=self.progress_dialog.run)
			self.progress_thread.start()
		except Exception as e:
			logger('SourcesPlayback init failed', str(e))
			self.progress_dialog, self.progress_thread = None, None
			try: kodi_utils.close_all_dialog()
			except: pass

	def _make_resolve_dialog(self):
		from modules.kodi_utils import logger
		logger('DialogFlash _make_resolve_dialog', 'resolve_dialog_made=%s progress_dialog=%s' % (self.resolve_dialog_made, self.progress_dialog is not None))
		self.resolve_dialog_made = True
		if not self.progress_dialog: self._make_progress_dialog()
		self.progress_dialog.enable_resolver()

	def _make_resume_dialog(self, percent):
		if not self.progress_dialog: self._make_progress_dialog()
		self.progress_dialog.enable_resume(percent)
		return self.progress_dialog.resume_choice

	def _make_nextep_dialog(self, default_action='cancel'):
		# LOCAL PATCH 2026-08-25: pass the timing tier through to the dialog. `chapters_detected`
		# used to be threaded here and was never read by anything; it is replaced by
		# countdown_mode, which actually drives how NextEpisode counts down:
		#   'fixed'  -> HIGH confidence (IntroDB outro / chapter): count N seconds into the
		#               credits, then autoplay. Netflix-style.
		#   'to_end' -> LOW confidence (percentage fallback): the alert point is arbitrary, so
		#               count down the real remaining playback time and only autoplay at the
		#               true end of the video. Prevents cutting ~125s of episode at defaults.
		ns = getattr(self, 'nextep_settings', None)
		if not isinstance(ns, dict): ns = {}
		countdown_mode = 'to_end' if ns.get('timing_confidence') == 'low' else 'fixed'
		try:
			action = open_window(('windows.playback_notifications', 'NextEpisode'), 'playback_notifications.xml',
								meta=self.meta, default_action=default_action,
								countdown_mode=countdown_mode, total_time=ns.get('total_time'))
		except: action = 'cancel'
		return action

	def _make_still_watching_dialog(self, check_text):
		try: action = open_window(('windows.playback_notifications', 'StillWatching'), 'playback_notifications.xml', meta=self.meta, check_text=check_text)
		except: action = 'no'
		return action

	def _kill_progress_dialog(self):
		from modules.kodi_utils import logger
		import traceback
		caller = traceback.extract_stack()[-2]
		logger('DialogFlash _kill_progress_dialog', 'called from %s:%d in %s' % (caller.filename.rsplit('\\', 1)[-1], caller.lineno, caller.name))
		success = 0
		try:
			self.progress_dialog.close()
			success += 1
		except: pass
		try:
			self.progress_thread.join()
			success += 1
		except: pass
		if success != 2:
			try: kodi_utils.close_all_dialog()
			except: pass
		self.progress_dialog, self.progress_thread = None, None

	def debridPacks(self, debrid_provider, name, magnet_url, info_hash, download=False):
		kodi_utils.show_busy_dialog()
		debrid_info = {'Real-Debrid': 'rd_browse', 'Premiumize.me': 'pm_browse', 'AllDebrid': 'ad_browse', 'TorBox': 'tb_browse'}[debrid_provider]
		debrid_function = self.debrid_importer(debrid_info)
		try: debrid_files = debrid_function().display_magnet_pack(magnet_url, info_hash)
		except: debrid_files = None
		kodi_utils.hide_busy_dialog()
		if not debrid_files: return kodi_utils.notification('Error')
		debrid_files.sort(key=lambda k: k['filename'].lower())
		if download: return debrid_files, debrid_function
		list_items = [{'line1': '%.2f GB | %s' % (float(item['size'])/1073741824, clean_file_name(item['filename']).upper())} for item in debrid_files]
		kwargs = {'items': json.dumps(list_items), 'heading': name, 'enumerate': 'true', 'narrow_window': 'true'}
		chosen_result = kodi_utils.select_dialog(debrid_files, **kwargs)
		if chosen_result is None: return None
		link = self.resolve_internal(debrid_info, chosen_result['link'], '')
		name = chosen_result['filename']
		self._kill_progress_dialog()
		return FenLightPlayer().run(link, 'video')

	def play_file(self, results, source={}):
		# LOCAL PATCH 2026-07-02: user_cancelled is set only when the user actively pressed
		# Back / cancel; distinct from cancel_all_playback which fires on both user-cancel
		# and playback failure (all sources exhausted / monitor exception). Sticky-fallback
		# checks user_cancelled — the former case keeps the sticky, the latter should fall
		# through to a fresh scrape so the picker opens.
		self.playback_successful, self.cancel_all_playback, self.user_cancelled = None, False, False
		retry_easynews = settings.easynews_playback_method('retry')
		retry_easynews_limit = settings.easynews_playback_method_retries()
		try:
			kodi_utils.hide_busy_dialog()
			url = None
			results = [i for i in results if not 'Uncached' in i.get('cache_provider', '')]
			if not source: source = results[0]
			items = [source]
			if not self.limit_resolve: 
				source_index = results.index(source)
				results.remove(source)
				items_prev = results[:source_index]
				items_prev.reverse()
				items_next = results[source_index:]
				items = items + items_next + items_prev
			processed_items = []
			processed_items_append = processed_items.append
			for count, item in enumerate(items, 1):
				resolve_item = dict(item)
				provider = item['scrape_provider']
				if provider == 'external': provider = item['debrid'].replace('.me', '')
				elif provider == 'folders': provider = item['source']
				provider_text = provider.upper()
				extra_info = '[B]%s[/B] | [B]%s[/B] | %s' %  (item['quality'], item['size_label'], item['extraInfo'])
				display_name = item['display_name'].upper()
				resolve_item['resolve_display'] = '%02d. [B]%s[/B][CR]%s[CR]%s' % (count, provider_text, extra_info, display_name)
				processed_items_append(resolve_item)
				if provider == 'easynews' and retry_easynews:
					for retry in range(1, retry_easynews_limit):
						resolve_item = dict(item)
						resolve_item['resolve_display'] = '%02d. [B]%s (RETRYx%s)[/B][CR]%s[CR]%s' % (count, provider_text, retry, extra_info, display_name)
						processed_items_append(resolve_item)
			items = list(processed_items)
			if not self.continue_resolve_check(): return self._kill_progress_dialog()
			kodi_utils.hide_busy_dialog()
			self.playback_percent = self.get_playback_percent()
			if self.playback_percent == None: return self._kill_progress_dialog()
			if not self.resolve_dialog_made: self._make_resolve_dialog()
			if self.background: kodi_utils.sleep(1000)
			monitor = kodi_utils.kodi_monitor()
			from modules.kodi_utils import logger as _dflogger
			_dflogger('DialogFlash play_file loop', 'items=%d background=%s autoplay=%s autoplay_nextep=%s' % (len(items), self.background, self.autoplay, getattr(self, 'autoplay_nextep', 'n/a')))
			for count, item in enumerate(items, 1):
				try:
					_dflogger('DialogFlash play_file iter %d' % count, 'name=%s' % (item.get('name', '')[:60]))
					kodi_utils.hide_busy_dialog()
					if not self.progress_dialog: break
					self.progress_dialog.reset_is_cancelled()
					self.progress_dialog.update_resolver(text=item['resolve_display'])
					self.progress_dialog.busy_spinner()
					if count > 1:
						kodi_utils.sleep(200)
						try: del player
						except: pass
					url, self.playback_successful, self.cancel_all_playback, self.user_cancelled = None, None, False, False
					self.playing_filename = item['name']
					self.playing_item = item
					player = FenLightPlayer()
					try:
						if self.progress_dialog.iscanceled() or monitor.abortRequested(): break
						url = self.resolve_sources(item)
						if url:
							resolve_percent = 0
							self.progress_dialog.busy_spinner('false')
							self.progress_dialog.update_resolver(percent=resolve_percent)
							kodi_utils.sleep(200)
							player.run(url, self)
						else: continue
						if self.cancel_all_playback: break
						if self.playback_successful: break
						if count == len(items):
							self.cancel_all_playback = True
							mark_internal_stop()   # LOCAL PATCH 2026-08-26: our stop, not the user's
							player.stop()
							break
					except: pass
				except: pass
		except: self._kill_progress_dialog()
		if self.cancel_all_playback: return self._kill_progress_dialog()
		if not self.playback_successful or not url: self.playback_failed_action()
		try: del monitor
		except: pass

	def get_playback_percent(self):
		if self.media_type == 'movie': percent = watched_status.get_progress_status_movie(watched_status.get_bookmarks_movie(), str(self.tmdb_id))
		elif any((self.random, self.random_continual)): return 0.0
		else: percent = watched_status.get_progress_status_episode(watched_status.get_bookmarks_episode(self.tmdb_id, self.season), self.episode)
		if not percent: return 0.0
		action = self.get_resume_status(percent)
		if action == 'cancel': return None
		if action == 'start_over':
			watched_status.erase_bookmark(self.media_type, self.tmdb_id, self.season, self.episode)
			return 0.0
		return float(percent)

	def get_resume_status(self, percent):
		if settings.auto_resume(self.media_type, self.autoplay): return float(percent)
		return self._make_resume_dialog(percent)

	def playback_failed_action(self):
		self._kill_progress_dialog()
		if self.prescrape and self.autoplay:
			self.resolve_dialog_made, self.prescrape, self.prescrape_sources = False, False, []
			self.get_sources()

	def still_watching_check(self):
		watching_check = self.nextep_settings['watching_check']
		if watching_check == 0: return True
		player = kodi_utils.kodi_player()
		if not player.isPlayingVideo(): return False
		watch_count = self.meta.get('watch_count')
		if watch_count == watching_check: still_watching, watch_count = self._make_still_watching_dialog('Are you still watching [B]%s[/B]?'), 0
		else: still_watching = True
		watch_count += 1
		self.meta['watch_count'] = watch_count
		return still_watching

	def continue_resolve_check(self):
		try:
			if not self.background or self.autoscrape_nextep: return True
			# LOCAL PATCH 2026-09-03: a source picked out of the picker is already the user's
			# answer to 'play the next episode?', so do not put the countdown up afterwards.
			# Observed: picker at 10:01:56, then the NextEpisode dialog at 10:02:01 with
			# 'entry playing=False' -- asking whether to start something the user had just
			# selected, after playback had already finished. The alert exists for the AUTOMATIC
			# handoff, where nothing has been chosen yet.
			if getattr(self, 'chosen_by_user', False):
				kodi_utils.logger('autoplay_nextep_handler', 'skipped: source was chosen from the picker')
				return True
			if self.autoplay_nextep: return self.autoplay_nextep_handler()
			return self.random_continual_handler()
		except: return False

	def random_continual_handler(self):
		kodi_utils.notification('[B]Next Up:[/B] %s S%02dE%02d' % (self.meta.get('title'), self.meta.get('season'), self.meta.get('episode')), 6500, self.meta.get('poster'))
		player = kodi_utils.kodi_player()
		while player.isPlayingVideo(): kodi_utils.sleep(100)
		self._make_resolve_dialog()
		return True

	def autoplay_nextep_handler(self):
		from modules.kodi_utils import logger as _dflogger
		if not self.nextep_settings:
			_dflogger('autoplay_nextep_handler', 'no nextep_settings — aborting')
			return False
		if not self.still_watching_check():
			kodi_utils.notification('Cancel Autoplay', icon=self.meta.get('poster'))
			return False
		player = kodi_utils.kodi_player()
		use_window, window_time, default_action = self.nextep_settings['use_window'], self.nextep_settings['window_time'], self.nextep_settings['default_action']
		playing_at_entry = player.isPlayingVideo()
		_dflogger('autoplay_nextep_handler', 'entry playing=%s use_window=%s window_time=%s default_action=%s' % (playing_at_entry, use_window, window_time, default_action))
		# LOCAL PATCH 2026-07-22: the outer isPlayingVideo() check used to gate this
		# entire block was blocking the dialog when the previous episode ended before
		# we got here (outro auto-skip + slow scrape race). Now we open the dialog
		# regardless — we only wait for the timing window if the video IS still playing.
		action = None if use_window else 'close'
		continue_nextep = False
		last_remaining = None   # DIAG/fallback 2026-08-25: position at last sample
		if playing_at_entry:
			try: total_time = player.getTotalTime()
			except: total_time = 0
			while player.isPlayingVideo():
				try:
					remaining_time = round(total_time - player.getTime())
					last_remaining = remaining_time
					if remaining_time <= window_time:
						continue_nextep = True
						break
					kodi_utils.sleep(1000)
				except: pass
		# If we exit the wait loop because playback ended (or we never entered it because
		# playback was already over), fall through to showing the dialog anyway — user's
		# intent was autoplay-with-alert. Only suppress on explicit cancel.
		# LOCAL PATCH 2026-08-21: ...but a plain Stop is ALSO an explicit cancel. It sets
		# neither cancel_all_playback nor user_cancelled (those are only set on
		# progress-dialog cancel / exception), so this fallback used to fire on a normal
		# Stop and pop Next Up after the video was already closed. FenLightPlayer's
		# onPlayBackStopped/onPlayBackEnded now record the verdict in a window property
		# (an instance flag can't be used — this runs on a fresh Sources() from
		# episode_tools.auto_nextep, not the player's sources_object).
		if not continue_nextep:
			# Reaching here means the wait loop exited WITHOUT ever hitting the alert
			# window. A natural end cannot do that: as playback nears the end,
			# remaining_time drops below window_time and the loop breaks with
			# continue_nextep=True first. So an exit while remaining is still ABOVE
			# window_time means playback was cut short — the user pressed Stop.
			#
			# This position test is the primary signal because it needs no callback.
			# onPlayBackStopped is authoritative but Kodi delivers it ~2.5s after
			# isPlayingVideo() flips (measured: loop exit 10:55:54.86, callback
			# 10:55:57.31), long after this gate has already decided.
			ended_before_window = last_remaining is not None and last_remaining > window_time
			user_stopped = kodi_utils.get_property(PLAYBACK_STOPPED_PROP) == 'true'
			if not user_stopped and not ended_before_window:
				# Inconclusive — give the late callback a brief chance before allowing.
				kodi_utils.sleep(600)
				user_stopped = kodi_utils.get_property(PLAYBACK_STOPPED_PROP) == 'true'
			if user_stopped or ended_before_window or getattr(self, 'cancel_all_playback', False) or getattr(self, 'user_cancelled', False):
				_dflogger('autoplay_nextep_handler', 'suppressing dialog — user_stopped=%s ended_before_window=%s (last_remaining=%s window_time=%s)'
					% (user_stopped, ended_before_window, last_remaining, window_time))
			else:
				# last_remaining is None => playback was already over when we got here
				# (outro auto-skip + slow scrape race, the 2026-07-22 case). Alert is wanted.
				continue_nextep = True
		_dflogger('autoplay_nextep_handler', 'pre-dialog continue_nextep=%s cancel_all=%s user_cancelled=%s' % (continue_nextep, getattr(self, 'cancel_all_playback', False), getattr(self, 'user_cancelled', False)))
		if continue_nextep:
			if use_window:
				_dflogger('autoplay_nextep_handler', 'opening NextEpisode dialog default_action=%s' % default_action)
				action = self._make_nextep_dialog(default_action=default_action)
				_dflogger('autoplay_nextep_handler', 'dialog returned action=%r' % action)
			else:
				kodi_utils.notification('[B]Next Up:[/B] %s S%02dE%02d' \
					% (self.meta.get('title'), self.meta.get('season'), self.meta.get('episode')), 6500, self.meta.get('poster'))
			if not action: action = default_action
			_dflogger('autoplay_nextep_handler', 'final action=%r' % action)
			if action == 'cancel':
				# Set cancel_all_playback so _sticky_pack_play upstream sees user-cancel
				# (without this, sticky pack-play sees play_file returning unsuccessfully
				# and falls back to a full scrape — re-firing the popup at episode end).
				self.cancel_all_playback, self.user_cancelled = True, True
				return False
			elif action == 'pause':
				self.cancel_all_playback, self.user_cancelled = True, True
				mark_internal_stop()   # LOCAL PATCH 2026-08-26: our stop, not the user's
				try: player.stop()
				except: pass
				return False
			elif action == 'play':
				self._make_resolve_dialog()
				# LOCAL PATCH 2026-08-26: this stop is OURS -- we are handing off to the next
				# episode. Unmarked, onPlayBackStopped recorded it as a user stop, and the
				# handler invocation for the NEW episode then read that stale verdict and
				# suppressed itself. When the sticky source failed, that also blocked
				# SmartPlay's fallback scrape, turning a recoverable failure into a dead stop.
				mark_internal_stop()
				try: player.stop()
				except: pass
				return True
			else:
				while player.isPlayingVideo(): kodi_utils.sleep(100)
				self._make_resolve_dialog()
				return True
		else: return False

	def autoscrape_nextep_handler(self):
		if settings.autoscrape_confirm():
			if not self._make_still_watching_dialog('Autoscrape Next Episode of [B]%s[/B]?'): return kodi_utils.notification('Cancel Autoscrape', icon=self.meta.get('poster'))
		player = kodi_utils.kodi_player()
		if player.isPlayingVideo():
			results = self.get_sources()
			if not results: return kodi_utils.notification(33092, 3000)
			else:
				kodi_utils.notification('[B]Next Episode Ready:[/B] %s S%02dE%02d' \
						% (self.meta.get('title'), self.meta.get('season'), self.meta.get('episode')), 6500, self.meta.get('poster'))
				while player.isPlayingVideo(): kodi_utils.sleep(100)
			self.display_results(results)
		else: return

	def debrid_importer(self, debrid_provider):
		return manual_function_import(*self.debrids[debrid_provider])

	def resolve_sources(self, item, meta=None):
		if meta: self.meta = meta
		url = None
		try:
			if 'cache_provider' in item:
				cache_provider = item['cache_provider']
				if self.meta['media_type'] == 'episode':
					if hasattr(self, 'search_info'):
						title, season, episode, pack = self.search_info['title'], self.search_info['season'], self.search_info['episode'], 'package' in item
					else: title, season, episode, pack = self.get_ep_name(), self.get_season(), self.get_episode(), 'package' in item
				else: title, season, episode, pack = self.get_search_title(), None, None, False
				# LOCAL PATCH 2026-08-27: anime files inside a pack are not numbered the way
				# TMDb numbers them, so the debrid layer needs the alternatives to find the
				# right file. Empty for everything that is not anime.
				ep_candidates = anime_episode_candidates(self.meta, self.meta.get('tmdb_id'), season, episode) if season else []
				if cache_provider in ('Real-Debrid', 'Premiumize.me', 'AllDebrid', 'TorBox'):
					url = self.resolve_cached(cache_provider, item['url'], item['hash'], title, season, episode, pack, ep_candidates)
			elif item.get('scrape_provider', None) in self.default_internal_scrapers:
				url = self.resolve_internal(item['scrape_provider'], item['id'], item['url_dl'], item.get('direct_debrid_link', False))
			else: url = item['url']
		except: pass
		return url

	def resolve_cached(self, debrid_provider, item_url, _hash, title, season, episode, pack, ep_candidates=None):
		# LOCAL PATCH 2026-08-31: cleared at both resolution entry points so a pack file
		# recorded by a previous playback cannot leak into this one.
		try: kodi_utils.set_property('fenlight.playing.pack_file', '')
		except Exception: pass
		debrid_function = self.debrid_importer(debrid_provider)
		store_to_cloud = settings.store_resolved_to_cloud(debrid_provider, pack)
		try: url = debrid_function().resolve_magnet(item_url, _hash, store_to_cloud, title, season, episode, ep_candidates)
		except: url = None
		return url

	def resolve_internal(self, scrape_provider, item_id, url_dl, direct_debrid_link=False):
		try: kodi_utils.set_property('fenlight.playing.pack_file', '')
		except Exception: pass
		url = None
		try:
			if direct_debrid_link or scrape_provider == 'folders': url = url_dl
			elif scrape_provider == 'easynews':
				from indexers.easynews import resolve_easynews
				url = resolve_easynews({'url_dl': url_dl, 'play': 'false'})
			else:
				debrid_function = self.debrid_importer(scrape_provider)
				if any(i in scrape_provider for i in ('rd_', 'ad_', 'tb_')):
					url = debrid_function().unrestrict_link(item_id)
				else:
					if '_cloud' in scrape_provider: item_id = debrid_function().get_item_details(item_id)['link']
					url = debrid_function().add_headers_to_url(item_id)
		except: pass
		return url

	def _quality_length(self, items, quality):
		return len([i for i in items if i['quality'] == quality])

	def _quality_length_sd(self, items, dummy):
		return len([i for i in items if i['quality'] in ('SD', 'CAM', 'TELE', 'SYNC')])

	def _quality_length_final(self, items, dummy):
		return len(items)
