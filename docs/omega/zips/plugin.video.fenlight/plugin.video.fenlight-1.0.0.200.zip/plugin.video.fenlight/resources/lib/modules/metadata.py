# -*- coding: utf-8 -*-
from operator import itemgetter
from caches.meta_cache import meta_cache
from apis.tmdb_api import movie_details, tvshow_details, season_episodes_details, movie_set_details, movie_external_id, tvshow_external_id, \
								episode_groups_data, episode_group_details
from modules.utils import jsondate_to_datetime, subtract_dates
# from modules.kodi_utils import logger

# LOCAL PATCH 2026-08-26: per-season trailers. This preference cascade was written
# inline twice (movie_meta and tvshow_meta); it is now shared so each TMDb season's
# videos can be reduced the same way the show's are.
# LOCAL PATCH 2026-08-26: prefer an English-intelligible trailer.
# TMDb already returns only the en-US locale (tvshow_details passes language=en), so
# iso_639_1 is 'en' on every row and cannot discriminate -- the signal lives in the
# NAME: "[Subtitled]", "Official Subtitled Trailer", "English Subbed", "English Dub".
# Anime shows often carry both a raw Japanese trailer and a subbed one; without this
# the pick was arbitrary (first alphabetically after the name sort). Subtitled outranks
# dubbed, and both outrank an unmarked trailer. For English-language shows nothing
# matches and the original cascade below runs untouched.
_SUB_HINTS = ('subtitled', 'subbed', 'eng sub', 'english sub', 'with subtitles')
_ENG_HINTS = ('english trailer', 'english dub', 'dub trailer', 'english')


def _name_has(video, hints):
	try: return any(h in (video.get('name') or '').lower() for h in hints)
	except Exception: return False


def _pick_trailer(youtube_videos, youtube_url):
	"""Best YouTube trailer from a TMDb videos list, as a playable URL, or ''.
	Order: official 'official trailer' -> official Trailer -> any Trailer ->
	anything named trailer -> anything at all."""
	if not youtube_videos: return ''
	try:
		trailers = [i for i in youtube_videos if i.get('type') == 'Trailer']
		for hints in (_SUB_HINTS, _ENG_HINTS):
			preferred = [i for i in trailers if _name_has(i, hints)]
			if preferred:
				best = next((i for i in preferred if i.get('official')), preferred[0])
				return youtube_url % best['key']
	except Exception: pass
	try:
		return \
		next((youtube_url % i['key'] for i in youtube_videos if i['official'] and i['type'] == 'Trailer' and 'official trailer' in i['name'].lower()), None) or \
		next((youtube_url % i['key'] for i in youtube_videos if i['official'] and i['type'] == 'Trailer'), None) or \
		next((youtube_url % i['key'] for i in youtube_videos if i['type'] == 'Trailer'), None) or \
		next((youtube_url % i['key'] for i in youtube_videos if 'trailer' in i['name'].lower()), None) or \
		next((youtube_url % i['key'] for i in youtube_videos), None) or ''
	except Exception:
		return ''


def _season_trailers(data_get, youtube_url):
	"""{season_number: trailer_url} from the season/N/videos blocks appended to the
	show request by apis/tmdb_api.tvshow_details. Only the chosen URL is kept -- the
	raw video arrays are discarded so meta grows ~60 bytes per season, not 2-5KB.
	Seasons the show does not have are absent from the response and simply skipped."""
	out = {}
	for season_no in range(1, 13):
		try:
			block = data_get('season/%d/videos' % season_no, None)
			if not block: continue
			yt = sorted([i for i in (block.get('results') or []) if i.get('site') == 'YouTube'], key=lambda x: x['name'])
			url = _pick_trailer(yt, youtube_url)
			if url: out[season_no] = url
		except Exception: continue
	return out


def season_trailer_for(meta, season_number, fallback=''):
	"""Trailer for one TMDb season. Callers pass season numbers as int or str
	depending on the code path, hence the cast.

	TMDb only covers ~57% of seasons. For the rest we hand back a plugin URL that
	searches YouTube AT PLAY TIME (apis/youtube_api.play_resolved_trailer) rather
	than searching now -- a search costs ~740KB/~0.7s and browsing must stay free.
	That resolver falls back to `fallback` itself, so behaviour is never worse."""
	try:
		# Key lookup is int-OR-str on purpose: the cache layer may serialise this dict
		# as JSON, which stringifies int keys. Tolerating both keeps the consumer
		# independent of the storage format, instead of a coercion table that a future
		# int-keyed dict would silently escape.
		_st = meta.get('season_trailers') or {}
		direct = _st.get(int(season_number)) or _st.get(str(int(season_number)))
		if direct: return direct
	except Exception:
		return fallback
	try:
		tmdb_id = meta.get('tmdb_id')
		# Seasons 2+ only -- see apis/youtube_api.find_season_trailer.
		if tmdb_id and int(season_number) > 1:
			from modules.kodi_utils import build_url
			return build_url({'mode': 'resolve_yt_trailer', 'tmdb_id': tmdb_id, 'season': season_number})
	except Exception: pass
	return fallback


# LOCAL PATCH 2026-05-28: inline OMDb rating fetch during meta build. When a meta dict is being
# constructed (cold cache for the item), also pull IMDb/RT/MetaCritic ratings from OMDb so the
# AF3 rating chip reads them instantly from ListItem.Property on first focus — no async lag.
# Cost: ~300-1500ms per cold item. Mitigated by indexers using TaskPool for parallel meta
# builds. After the first cache hit, OMDb data is part of meta_cache; no further OMDb calls.
def _fetch_omdb_for_meta(meta):
	try:
		from caches.settings_cache import get_setting
		omdb_key = get_setting('fenlight.omdb_api', '')
		if not omdb_key or omdb_key in ('empty_setting', ''):
			return
		if not meta.get('imdb_id') or meta.get('extra_ratings'):
			return
		from apis.omdb_api import fetch_ratings_info, omdb_on_cooldown
		# LOCAL PATCH 2026-08-26 (perf): third early return -- skip entirely while the key
		# is known rate-limited or invalid. Without this, every cold item paid ~700ms for a
		# guaranteed 401; a 6-widget cold home burned ~5.5s on them.
		if omdb_on_cooldown(): return
		fetch_ratings_info(meta, omdb_key)
	except Exception: pass

# LOCAL PATCH 2026-09-07: OMDb backfill on the CACHE-HIT path. _fetch_omdb_for_meta above
# runs only while a meta is being BUILT, and movie_meta / tvshow_meta return a cached meta
# before reaching it -- so any meta cached without ratings (built before the OMDb patch,
# during a key cooldown, or while the network was down) stayed that way for its whole TTL:
# up to 4368h for ended shows and older films. metacache.db on 2026-09-07 held 1153 metas
# with an IMDb id, 118 of them (10%) with no ratings. Those are exactly the items that show
# no rating chip on first focus: no DeadLight fallback exists for them, so they depend
# entirely on TMDbHelper's per-focus fetch and inherit its timing races.
#
# This runs on a hot path, so it must be free when there is nothing to do (one dict lookup
# on extra_ratings) and bounded when there is. On success, OMDbAPI.process_result already
# persists extra_ratings to meta_cache itself -- and it always writes a populated dict, even
# when every value is N/A, so a successful lookup never repeats. Failures are the problem:
# get_result returns None for both a network blip and an IMDb id OMDb does not know (many
# of the 118 are 2025/2026 releases), and writes nothing. Without a marker each would retry
# on every render at ~700ms. So a failed attempt is stamped into the meta and retried at
# most once per _BACKFILL_RETRY_HOURS. A key cooldown does NOT burn the attempt: it lifts on
# its own and the item should be tried the moment it does.
_BACKFILL_RETRY_HOURS = 24

def _backfill_omdb(meta, current_date, current_time=None):
	try:
		if not isinstance(meta, dict) or meta.get('extra_ratings') or meta.get('blank_entry'): return
		imdb_id = meta.get('imdb_id')
		if not imdb_id or imdb_id == 'tt0000000': return
		from modules.utils import get_current_timestamp
		now = current_time or get_current_timestamp()
		if now - (meta.get('omdb_backfill_ts') or 0) < _BACKFILL_RETRY_HOURS * 3600: return
		from caches.settings_cache import get_setting
		omdb_key = get_setting('fenlight.omdb_api', '')
		if not omdb_key or omdb_key == 'empty_setting': return
		from apis.omdb_api import fetch_ratings_info, omdb_on_cooldown
		if omdb_on_cooldown(): return
		from modules.kodi_utils import logger
		title = (meta.get('title') or '')[:40]
		fetch_ratings_info(meta, omdb_key)
		if meta.get('extra_ratings'):
			logger('OMDb backfill', 'filled %s (%s)' % (imdb_id, title))
			return
		meta['omdb_backfill_ts'] = now
		media_type = meta.get('mediatype')
		expiry_function = movie_expiry if media_type == 'movie' else tvshow_expiry
		meta_cache.set(media_type, 'tmdb_id', meta, expiry_function(current_date, meta), current_time)
		logger('OMDb backfill', 'no data for %s (%s); next try in %dh' % (imdb_id, title, _BACKFILL_RETRY_HOURS))
	except Exception: pass

# LOCAL PATCH 2026-09-14: MDBList ratings, layered on top of OMDb rather than replacing
# it. Runs AFTER the OMDb call at every site, and mdblist_ratings_info never overwrites a
# key OMDb already filled, so the RT / Metacritic / IMDb chips a user already sees are
# unaffected. What it adds is MyAnimeList, Letterboxd, Trakt and MDBList's own score --
# none of which OMDb returns -- plus coverage for the items OMDb structurally cannot
# serve, the ones with no imdb_id (22 of 1414 cached metas when this was written).
#
# Deliberately NOT folded into _fetch_omdb_for_meta: that function early-returns when
# extra_ratings is already populated, which is exactly the state OMDb leaves behind on
# success. Sharing the sentinel would mean MDBList only ever ran when OMDb had failed.
def _fetch_mdblist_for_meta(meta):
	try:
		from apis.mdblist_api import mdblist_ratings_info
		mdblist_ratings_info(meta)
	except Exception: pass


# The cache-hit counterpart, mirroring _backfill_omdb. It carries its OWN stamp: a title
# OMDb has no data for is not necessarily one MDBList has no data for, and sharing
# omdb_backfill_ts would let either provider's failure suppress the other's retry.
_MDBL_BACKFILL_RETRY_HOURS = 24

def _backfill_mdblist(meta, current_date, current_time=None):
	try:
		if not isinstance(meta, dict) or meta.get('blank_entry'): return
		if not meta.get('tmdb_id'): return
		from modules.utils import get_current_timestamp
		now = current_time or get_current_timestamp()
		if now - (meta.get('mdblist_backfill_ts') or 0) < _MDBL_BACKFILL_RETRY_HOURS * 3600: return
		from apis.mdblist_api import mdblist_ratings_info
		before = len(meta.get('extra_ratings') or {})
		mdblist_ratings_info(meta)
		if len(meta.get('extra_ratings') or {}) > before: return   # it wrote the cache itself
		meta['mdblist_backfill_ts'] = now
		media_type = meta.get('mediatype')
		expiry_function = movie_expiry if media_type == 'movie' else tvshow_expiry
		meta_cache.set(media_type, 'tmdb_id', meta, expiry_function(current_date, meta), current_time)
	except Exception: pass


def movie_meta(id_type, media_id, api_key, mpaa_region, current_date, current_time=None):
	if id_type == 'trakt_dict':
		if media_id.get('tmdb', None): id_type, media_id = 'tmdb_id', media_id['tmdb']
		elif media_id.get('imdb', None): id_type, media_id = 'imdb_id', media_id['imdb']
		else: id_type, media_id = None, None
	if media_id == None: return None
	meta = meta_cache.get('movie', id_type, media_id, current_time)
	if meta:
		_backfill_omdb(meta, current_date, current_time)   # LOCAL PATCH 2026-09-07
		_backfill_mdblist(meta, current_date, current_time)   # LOCAL PATCH 2026-09-14
		return meta
	try:
		if id_type in ('tmdb_id', 'imdb_id'): data = movie_details(media_id, api_key)
		else:
			external_result = movie_external_id(id_type, media_id, api_key)
			if not external_result: data = None
			else: data = movie_details(external_result['id'], api_key)
		if not data: return None
		elif data.get('status_code') in (6, 34, 37):
			if id_type == 'tmdb_id': meta = {'tmdb_id': media_id, 'imdb_id': 'tt0000000', 'tvdb_id': '0000000', 'blank_entry': True}
			else: meta = {'tmdb_id': '0000000', 'imdb_id': media_id, 'tvdb_id': '0000000', 'blank_entry': True}
			meta_cache.set('movie', id_type, meta, 24, current_time)
			return meta
		tmdb_image_url, youtube_url = 'https://image.tmdb.org/t/p/%s%s', 'plugin://plugin.video.youtube/play/?video_id=%s'
		data_get = data.get
		cast, short_cast, writer, director, all_trailers, country, country_codes, studio, stinger_keys = [], [], [], [], [], [], [], [], []
		mpaa, trailer = '', ''
		tmdb_id, imdb_id = data_get('id', ''), data_get('imdb_id', '')
		rating, votes = data_get('vote_average', ''), data_get('vote_count', '')
		plot, tagline, premiered = data_get('overview', ''), data_get('tagline', ''), data_get('release_date', '')
		rpdb_poster = 'https://api.ratingposterdb.com/%s/tmdb/poster-default/movie-%s.jpg?fallback=true' % ('%s', tmdb_id)
		poster_path = data_get('poster_path', '')
		if poster_path: poster = tmdb_image_url % ('w780', poster_path)
		else: poster = ''
		backdrop_path = data_get('backdrop_path', '')
		if backdrop_path: fanart = tmdb_image_url % ('w1280', backdrop_path)
		else: fanart = ''
		images = data_get('images', {})
		if images:
			# LOCAL PATCH 2026-08-27: fanart.tv is now the preferred clearlogo source, with
			# TMDb as the fallback. TMDb's logos are unranked -- this took images.logos[0],
			# whatever happened to be first -- while fanart.tv's are community-curated with
			# language tags and vote counts, are reliably transparent PNGs, and cover titles
			# TMDb has none for. It costs no request: that payload is already fetched and
			# cached for the fanart cycler under the same key.
			#
			# The TMDb branch below replaces two consecutive try/excepts that computed the
			# same value twice, the second silently overwriting the first.
			clearlogo = ''
			try:
				from apis.fanart_api import fanart_movie_clearlogo
				clearlogo = fanart_movie_clearlogo(imdb_id) or ''
			except Exception: clearlogo = ''
			if not clearlogo:
				try:
					logo_path = (images.get('logos') or [])[0].get('file_path')
					# Kodi wants a png; TMDb's CDN serves one for an svg path.
					if not logo_path.endswith('png'):
						logo_path = logo_path.replace(logo_path.split('.')[-1], 'png')
					clearlogo = tmdb_image_url % ('original', logo_path)
				except Exception: clearlogo = ''
			try: landscape = next((tmdb_image_url % ('w1280', i['file_path']) for i in images['backdrops'] if i['iso_639_1'] == 'en'), '')
			except: landscape = ''
			if not poster: poster = next((tmdb_image_url % ('w780', i['file_path']) for i in images['posters'] if i['iso_639_1'] == 'en'), '')
			if not fanart: fanart = next((tmdb_image_url % ('w1280', i['file_path']) for i in images['backdrops'] if i['iso_639_1'] in (None, 'xx')), '')
			# LOCAL PATCH 2026-08-06: extra_fanart list for AF3-style multi-fanart cycling.
			# AF3 reads ListItem.Art(fanart1)...(fanart8) and cycles between them.
			# Prefer fanart.tv's curated backdrops (higher quality, textless) when the
			# user has a key; fall back to TMDb's images.backdrops (language-neutral).
			# Dedupe against the primary `fanart` URL. Cap at 8.
			# LOCAL PATCH 2026-08-07 (revised): 8 best-voted TMDb backdrops. TMDb's default
			# response order does NOT sort by votes — sort explicitly by (vote_count desc,
			# vote_average desc) so consensus-favorite backdrops always appear first.
			# vote_count is primary because a highly-rated backdrop with few votes is less
			# reliable than a moderately-rated one with many votes (community signal beats
			# individual score). fanart.tv's _pick_backgrounds already ranks by `likes`.
			# Trade-off: AF3's focus-load burst may show 2-3 quick swaps before settling —
			# accepted for more visual variety per title.
			try:
				bd = images.get('backdrops') or []
				bd = sorted(bd, key=lambda i: (int(i.get('vote_count') or 0), float(i.get('vote_average') or 0)), reverse=True)
				tmdb_bgs = [tmdb_image_url % ('w1280', i['file_path']) for i in bd
							if i.get('iso_639_1') in (None, '', 'xx')]
				try:
					from apis.fanart_api import fanart_movie_backgrounds
					fanart_bgs = fanart_movie_backgrounds(imdb_id, cap=8)
				except Exception: fanart_bgs = []
				merged, seen = [], {fanart}
				for u in fanart_bgs + tmdb_bgs:
					if not u or u in seen: continue
					seen.add(u); merged.append(u)
					if len(merged) >= 8: break
				extra_fanart_list = merged
			except: extra_fanart_list = []
		else:
			clearlogo, landscape, extra_fanart_list = '', '', []
		title, original_title = data_get('title'), data_get('original_title')
		try:
			translations = data_get('translations')['translations']
			english_title = next((i['data']['title'] for i in translations if i['iso_639_1'] == 'en'), None)
		except: english_title = None
		try: year = str(data_get('release_date').split('-')[0])
		except: year = ''
		try: duration = int(data_get('runtime', '90') * 60)
		except: duration = 0
		try:
			genres = data_get('genres')
			genre = [i['name'] for i in genres]
		# LOCAL PATCH 2026-08-31: was `genre == []` -- a comparison, not an assignment, so a
		# TMDb payload with no 'genres' key left genre unbound. It is read below in the
		# meta dict, raising NameError inside the outer try, which the bare `except: pass`
		# swallowed -- losing the ENTIRE movie build. tvshow_meta always had this right.
		except: genre = []
		rootname = '%s (%s)' % (title, year)
		companies = data_get('production_companies')
		if companies:
			if len(companies) == 1: studio = ([i['name'] for i in companies][0],)
			else:
				# LOCAL PATCH 2026-08-31: a bare next() on an empty generator raises StopIteration
				# BEFORE python evaluates the `or`, so the 'no logo anywhere -> take the first'
				# fallback never actually ran; it always landed in the except and left studio [].
				# companies has 2+ entries in this branch, so indexing [0] cannot fail.
				try: studio = (next((i['name'] for i in companies if i['logo_path'] not in ('', 'None', None)), None) or companies[0]['name'],)
				except: pass
		production_countries = data_get('production_countries', None)
		if production_countries:
			country = [i['name'] for i in production_countries]
			country_codes = [i['iso_3166_1'] for i in production_countries]
		release_dates = data_get('release_dates')
		if release_dates:
			release_results = release_dates['results']
			try: mpaa = next(x['certification'] for i in release_results for x in i['release_dates'] if i['iso_3166_1'] == mpaa_region and x['certification'] != '')
			except: pass
		credits = data_get('credits')
		if credits:
			all_cast = credits.get('cast', None)
			if all_cast:
				try:
					cast = [{'name': i['name'], 'role': i['character'], 'thumbnail': tmdb_image_url % ('h632', i['profile_path'])if i['profile_path'] else ''} for i in all_cast]
					short_cast = cast[:10]
				except: pass
			crew = credits.get('crew', None)
			if crew:
				try: writer = [i['name'] for i in crew if i['job'] in ('Author', 'Writer', 'Screenplay', 'Characters')]
				except: pass
				try: director = [i['name'] for i in crew if i['job'] == 'Director']
				except: pass
		alternative_titles = data_get('alternative_titles', [])
		if alternative_titles:
			alternatives = alternative_titles['titles']
			alternative_titles = [i['title'] for i in alternatives if i['iso_3166_1'] in ('US', 'GB', 'UK', '')]
		else: alternative_titles = []
		videos = data_get('videos', None)
		if videos:
			try:
				vid_results = videos['results']
				all_trailers = sorted([i for i in vid_results if i['site'] == 'YouTube'], key=lambda x: x['name'])
				if all_trailers:
					trailer = \
					next((youtube_url % i['key'] for i in all_trailers if i['official'] and i['type'] == 'Trailer' and 'official trailer' in i['name'].lower()), None) or \
					next((youtube_url % i['key'] for i in all_trailers if i['official'] and i['type'] == 'Trailer'), None) or \
					next((youtube_url % i['key'] for i in all_trailers if i['type'] == 'Trailer'), None) or \
					next((youtube_url % i['key'] for i in all_trailers if 'trailer' in i['name'].lower()), None) or \
					next((youtube_url % i['key'] for i in all_trailers), None) or ''
				else: trailler = ''
			except: pass
		keywords = data_get('keywords', None)
		if keywords: stinger_keys = [i['name'] for i in keywords['keywords'] if i['name'] in ('duringcreditsstinger', 'aftercreditsstinger')]
		status, homepage = data_get('status', 'N/A'), data_get('homepage', 'N/A')
		belongs_to_collection = data_get('belongs_to_collection')
		if belongs_to_collection: ei_collection_name, ei_collection_id = belongs_to_collection['name'], belongs_to_collection['id']
		else: ei_collection_name, ei_collection_id = None, None
		try: ei_budget = '${:,}'.format(data_get('budget'))
		except: ei_budget = '$0'
		try: ei_revenue = '${:,}'.format(data_get('revenue'))
		except: ei_revenue = '$0'
		extra_info = {'status': status, 'budget': ei_budget, 'revenue': ei_revenue, 'homepage': homepage, 'collection_name': ei_collection_name, 'collection_id': ei_collection_id}
		meta = {'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'rating': rating, 'tagline': tagline, 'votes': votes, 'premiered': premiered, 'imdbnumber': imdb_id, 'trailer': trailer,
				'poster': poster, 'fanart': fanart, 'genre': genre, 'title': title, 'original_title': original_title, 'english_title': english_title, 'year': year, 'cast': cast,
				'duration': duration, 'rootname': rootname, 'country': country, 'country_codes': country_codes, 'mpaa': mpaa,'writer': writer, 'all_trailers': all_trailers,
				'director': director, 'alternative_titles': alternative_titles, 'plot': plot, 'studio': studio, 'extra_info': extra_info, 'mediatype': 'movie', 'tvdb_id': 'None',
				'clearlogo': clearlogo, 'landscape': landscape, 'keywords': keywords, 'rpdb_poster': rpdb_poster, 'short_cast': short_cast, 'stinger_keys': stinger_keys,
				'extra_fanart_list': extra_fanart_list}
		_fetch_omdb_for_meta(meta)
		_fetch_mdblist_for_meta(meta)   # LOCAL PATCH 2026-09-14
		meta_cache.set('movie', id_type, meta, movie_expiry(current_date, meta), current_time)
	except: pass
	return meta

def tvshow_meta(id_type, media_id, api_key, mpaa_region, current_date, current_time=None, is_anime_list=None):
	if id_type == 'trakt_dict':
		if media_id.get('tmdb', None): id_type, media_id = 'tmdb_id', media_id['tmdb']
		elif media_id.get('imdb', None): id_type, media_id = 'imdb_id', media_id['imdb']
		elif media_id.get('tvdb', None): id_type, media_id = 'tvdb_id', media_id['tvdb']
		else: id_type, media_id = None, None
	if media_id == None: return None
	meta = meta_cache.get('tvshow', id_type, media_id, current_time)
	if meta:
		_backfill_omdb(meta, current_date, current_time)   # LOCAL PATCH 2026-09-07
		_backfill_mdblist(meta, current_date, current_time)   # LOCAL PATCH 2026-09-14
		return meta_valid_check(meta, is_anime_list)
	try:
		if id_type == 'tmdb_id': data = tvshow_details(media_id, api_key)
		else:
			external_result = tvshow_external_id(id_type, media_id, api_key)
			if not external_result: data = None
			else: data = tvshow_details(external_result['id'], api_key)
		if not data or data.get('status_code', '') in (6, 34, 37):
			if id_type == 'tmdb_id': meta = {'tmdb_id': media_id, 'imdb_id': 'tt0000000', 'tvdb_id': '0000000', 'blank_entry': True}
			elif id_type == 'imdb_id': meta = {'tmdb_id': '0000000', 'imdb_id': media_id, 'tvdb_id': '0000000', 'blank_entry': True}
			else: meta = {'tmdb_id': '0000000', 'imdb_id': 'tt0000000', 'tvdb_id': media_id, 'blank_entry': True}
			meta_cache.set('tvshow', id_type, meta, 24, current_time)
			return meta
		tmdb_image_url, youtube_url = 'https://image.tmdb.org/t/p/%s%s', 'plugin://plugin.video.youtube/play/?video_id=%s'
		data_get = data.get
		cast, short_cast, writer, director, studio, all_trailers, country, country_codes = [], [], [], [], [], [], [], []
		mpaa, trailer = '', ''
		external_ids = data_get('external_ids')
		tmdb_id, imdb_id, tvdb_id = data_get('id', ''), external_ids.get('imdb_id', ''), external_ids.get('tvdb_id', 'None')
		rating, votes = data_get('vote_average', ''), data_get('vote_count', '')
		plot, tagline, premiered = data_get('overview', ''), data_get('tagline', ''), data_get('first_air_date', '')
		season_data, total_seasons = data_get('seasons'), data_get('number_of_seasons')
		rpdb_poster = 'https://api.ratingposterdb.com/%s/tmdb/poster-default/series-%s.jpg?fallback=true' % ('%s', tmdb_id)
		poster_path = data_get('poster_path', '')
		if poster_path: poster = tmdb_image_url % ('w780', poster_path)
		else: poster = ''
		backdrop_path = data_get('backdrop_path', '')
		if backdrop_path: fanart = tmdb_image_url % ('w1280', backdrop_path)
		else: fanart = ''
		images = data_get('images', {})
		if images:
			# LOCAL PATCH 2026-08-27: fanart.tv is now the preferred clearlogo source, with
			# TMDb as the fallback. TMDb's logos are unranked -- this took images.logos[0],
			# whatever happened to be first -- while fanart.tv's are community-curated with
			# language tags and vote counts, are reliably transparent PNGs, and cover titles
			# TMDb has none for. It costs no request: that payload is already fetched and
			# cached for the fanart cycler under the same key.
			#
			# The TMDb branch below replaces two consecutive try/excepts that computed the
			# same value twice, the second silently overwriting the first.
			clearlogo = ''
			try:
				from apis.fanart_api import fanart_tvshow_clearlogo
				clearlogo = fanart_tvshow_clearlogo(tvdb_id) or ''
			except Exception: clearlogo = ''
			if not clearlogo:
				try:
					logo_path = (images.get('logos') or [])[0].get('file_path')
					# Kodi wants a png; TMDb's CDN serves one for an svg path.
					if not logo_path.endswith('png'):
						logo_path = logo_path.replace(logo_path.split('.')[-1], 'png')
					clearlogo = tmdb_image_url % ('original', logo_path)
				except Exception: clearlogo = ''
			try: landscape = next((tmdb_image_url % ('w1280', i['file_path']) for i in images['backdrops'] if i['iso_639_1'] == 'en'), '')
			except: landscape = ''
			if not poster: poster = next((tmdb_image_url % ('w780', i['file_path']) for i in images['posters'] if i['iso_639_1'] == 'en'), '')
			if not fanart: fanart = next((tmdb_image_url % ('w1280', i['file_path']) for i in images['backdrops'] if i['iso_639_1'] == 'xx'), '')
			# LOCAL PATCH 2026-08-06: extra_fanart list for AF3 multi-fanart cycling.
			# Merges fanart.tv's showbackground (when API key set) with TMDb backdrops.
			# LOCAL PATCH 2026-08-07 (revised): 8 best-voted TMDb backdrops sorted by
			# (vote_count desc, vote_average desc). See movie_meta for full rationale.
			try:
				bd = images.get('backdrops') or []
				bd = sorted(bd, key=lambda i: (int(i.get('vote_count') or 0), float(i.get('vote_average') or 0)), reverse=True)
				tmdb_bgs = [tmdb_image_url % ('w1280', i['file_path']) for i in bd
							if i.get('iso_639_1') in (None, '', 'xx')]
				try:
					from apis.fanart_api import fanart_tvshow_backgrounds
					fanart_bgs = fanart_tvshow_backgrounds(tvdb_id, cap=8)
				except Exception: fanart_bgs = []
				merged, seen = [], {fanart}
				for u in fanart_bgs + tmdb_bgs:
					if not u or u in seen: continue
					seen.add(u); merged.append(u)
					if len(merged) >= 8: break
				extra_fanart_list = merged
			except: extra_fanart_list = []
		else:
			clearlogo, landscape, extra_fanart_list = '', '', []
		title, original_title = data_get('name'), data_get('original_name')
		try:
			translations = data_get('translations')['translations']
			english_title = [i['data']['name'] for i in translations if i['iso_639_1'] == 'en'][0]
		except: english_title = None
		try: year = str(data_get('first_air_date').split('-')[0]) or ''
		except: year = ''
		try: duration = min(data_get('episode_run_time'))*60
		except: duration = 0
		try:
			genres = data_get('genres')
			genre = [i['name'] for i in genres]
		except: genre = []
		rootname = '%s (%s)' % (title, year)
		networks = data_get('networks', None)
		if networks:
			if len(networks) == 1: studio = ([i['name'] for i in networks][0],)
			else:
				# LOCAL PATCH 2026-08-31: as movie_meta above, plus the fallback referenced
				# `network` (singular), which is not defined anywhere -- a NameError masked by
				# the same except. networks has 2+ entries in this branch.
				try: studio = (next((i['name'] for i in networks if i['logo_path'] not in ('', 'None', None)), None) or networks[0]['name'],)
				except: pass
		production_countries = data_get('production_countries', None)
		if production_countries:
			country = [i['name'] for i in production_countries]
			country_codes = [i['iso_3166_1'] for i in production_countries]
		content_ratings = data_get('content_ratings', None)
		if content_ratings:
			try: mpaa = next((i['rating'] for i in content_ratings['results'] if i['iso_3166_1'] == mpaa_region), '')
			except: pass
		credits = data_get('credits')
		if credits:
			all_cast = credits.get('cast', None)
			if all_cast:
				try:
					cast = [{'name': i['name'], 'role': i['character'], 'thumbnail': tmdb_image_url % ('h632', i['profile_path']) if i['profile_path'] else ''} for i in all_cast]
					short_cast = cast[:10]
				except: pass
			crew = credits.get('crew', None)
			if crew:
				try: writer = [i['name'] for i in crew if i['job'] in ('Author', 'Writer', 'Screenplay', 'Characters')]
				except: pass
				try: director = [i['name'] for i in crew if i['job'] == 'Director']
				except: pass
		alternative_titles = data_get('alternative_titles', [])
		if alternative_titles:
			alternatives = alternative_titles['results']
			alternative_titles = [i['title'] for i in alternatives if i['iso_3166_1'] in ('US', 'GB', 'UK', '')]
		videos = data_get('videos', None)
		if videos:
			try:
				vid_results = videos['results']
				all_trailers = sorted([i for i in vid_results if i['site'] == 'YouTube'], key=lambda x: x['name'])
				if all_trailers: trailer = _pick_trailer(all_trailers, youtube_url)
			except: pass
		# LOCAL PATCH 2026-08-26: per-season trailers from the season/N/videos blocks
		# appended by apis/tmdb_api.tvshow_details. Consumers fall back to `trailer`
		# for the ~46% of seasons TMDb has no video for.
		season_trailers = _season_trailers(data_get, youtube_url)
		keywords = data_get('keywords', None)
		status, _type, homepage = data_get('status', 'N/A'), data_get('type', 'N/A'), data_get('homepage', 'N/A')
		created_by = data_get('created_by', None)
		if created_by:
			try: ei_created_by = ', '.join([i['name'] for i in created_by])
			except: ei_created_by = 'N/A'
		else: ei_created_by = 'N/A'
		ei_next_ep, ei_last_ep = data_get('next_episode_to_air', None), data_get('last_episode_to_air', None)
		# LOCAL PATCH 2026-08-05 (Red Light R2 port): ended/canceled shows on TMDb
		# sometimes carry phantom placeholder seasons (announced-then-scrapped S2
		# etc.) that inflate `number_of_episodes` — leaves shows stuck In-Progress.
		# Use the seasons-before-last + ei_last_ep formula regardless of status
		# (works for ended too — last_episode_to_air is the FINAL ep for ended shows).
		# When ei_last_ep is absent, sum season_data but only for seasons whose
		# air_date is set (drops phantom placeholders).
		# LOCAL PATCH 2026-08-07: long-running anime (Naruto Shippuden, HxH, One Piece)
		# often have TMDb `last_episode_to_air.episode_number` in ABSOLUTE numbering
		# (500, 148, 1120) instead of the per-season position. The naive formula
		# `sum(before) + last_ep.episode_number` then produces wildly inflated totals
		# — e.g. Naruto Shippuden: 413 + 500 = 913 aired vs actual 500 → show stays
		# stuck in In-Progress showing 500/913 despite being fully watched.
		# Detect absolute mode by comparing last_e against the last season's own
		# episode_count; if it overflows, use the last season's count directly.
		if ei_last_ep:
			last_s = ei_last_ep['season_number']
			last_e = ei_last_ep['episode_number']
			seasons_before_sum = sum([i['episode_count'] for i in season_data if i['season_number'] < last_s and i['season_number'] != 0])
			last_season = next((i for i in season_data if i['season_number'] == last_s), None)
			last_season_count = (last_season or {}).get('episode_count', 0)
			if last_season_count and last_e > last_season_count:
				# Absolute-numbering case: last_e is a total-across-series index, not
				# a per-season position. Use the last season's episode_count instead.
				total_aired_eps = seasons_before_sum + last_season_count
			else:
				total_aired_eps = seasons_before_sum + last_e
		else:
			aired_seasons = [i for i in season_data if i['season_number'] != 0 and i.get('air_date') and i.get('episode_count', 0) > 0]
			total_aired_eps = sum([i['episode_count'] for i in aired_seasons]) if aired_seasons else data_get('number_of_episodes')
		extra_info = {'status': status, 'type': _type, 'homepage': homepage, 'created_by': ei_created_by, 'next_episode_to_air': ei_next_ep, 'last_episode_to_air': ei_last_ep}
		meta = {'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'imdb_id': imdb_id, 'rating': rating, 'plot': plot, 'tagline': tagline, 'votes': votes, 'premiered': premiered, 'year': year,
				'poster': poster, 'fanart': fanart, 'genre': genre, 'title': title, 'original_title': original_title, 'english_title': english_title, 'season_data': season_data,
				'alternative_titles': alternative_titles, 'duration': duration, 'rootname': rootname, 'imdbnumber': imdb_id, 'country': country, 'mpaa': mpaa, 'trailer': trailer,
				'country_codes': country_codes, 'writer': writer, 'director': director, 'all_trailers': all_trailers, 'cast': cast, 'studio': studio, 'extra_info': extra_info,
				'total_aired_eps': total_aired_eps, 'mediatype': 'tvshow', 'total_seasons': total_seasons, 'tvshowtitle': title, 'status': status, 'clearlogo': clearlogo,
				'landscape': landscape, 'keywords': keywords, 'rpdb_poster': rpdb_poster, 'short_cast': short_cast, 'extra_fanart_list': extra_fanart_list,
				'season_trailers': season_trailers}
		_fetch_omdb_for_meta(meta)
		_fetch_mdblist_for_meta(meta)   # LOCAL PATCH 2026-09-14
		meta_cache.set('tvshow', id_type, meta, tvshow_expiry(current_date, meta), current_time)
	except: pass
	return meta_valid_check(meta, is_anime_list)

# LOCAL PATCH 2026-09-02: TMDb serves TV episode numbers in TWO conventions and the
# scrape path needs the series-absolute number out of whichever one it was handed.
#
#   (a) per-season position -- nearly every show. Bleach S2 (Thousand-Year Blood War)
#       is numbered 1..50, so S02E46's absolute number really is 366 + 46 = 412.
#   (b) series-absolute ALREADY -- long-running weekly anime. Verified against the API:
#       One Piece S1 is 1..61, S2 is 62..77, S23 is 1156..1181; Naruto S4 is 159..220;
#       Hunter x Hunter S2 is 63..136; Naruto Shippuden's last episode is S20E500 in a
#       season holding 87 episodes.
#
# `sum(episode_count of earlier seasons) + episode` is correct only for (a). Applied to
# (b) it double-counts, and the damage is not merely a miss:
#   One Piece S23E1176 -> 1155 + 1176 = 2331  (1181-episode show; no such episode)
#   One Piece S02E62   ->   61 +   62 =  123  <- a REAL, DIFFERENT episode
#   Naruto    S02E53   ->   52 +   53 =  105  <- a REAL, DIFFERENT episode
#   Naruto    S04E159  ->  158 +  159 =  317  (220-episode show)
#   Shippuden S20E500  ->  413 +  500 =  913  (500-episode show)
#   HxH       S03E148  ->  136 +  148 =  284  (148-episode show)
# The 123 and 105 rows are the dangerous ones. absolute_episode is cour_match()'s FIRST
# early accept, and ordered_episode_candidates() tries the HIGHEST number first, so a
# complete-series pack -- how One Piece is distributed -- hands back episode 123 for a
# request for 62 and plays it. Observed live before this patch: a One Piece scrape for
# TMDb S6E157 searched absolute 277 and never searched 157, rejecting 108 of 181 results.
#
# TWO signals, OR-ed, because either alone leaves a hole:
#   1. this episode overflows its OWN season's episode_count. Same test as the
#      total_aired_eps guard in tvshow_meta above, verified there over 40 shows, and the
#      only signal available when extra_info is thin.
#      Hole: HxH S2 holds 74 episodes numbered 63..136, so S02E63..E74 do not overflow
#      74 and would still compute 62 + 63 = 125 -- a real episode again.
#   2. the SHOW numbers absolutely: last_episode_to_air overflows ITS season's
#      episode_count. That is exactly the 474-485 test, promoted from a statement about
#      one episode to a statement about the show, and safe to promote because
#      last_episode_to_air is always its season's MAXIMUM episode number. HxH is S03E148
#      against a 12-episode S03, so signal 2 covers all 74 of S2.
#      Cannot false-positive: under (a) an episode_number is by construction <= its own
#      season's episode_count. Measured -- Bleach (46 vs 50), Detective Conan (1211 vs
#      1212), Tokyo Revengers (50 vs 50) and Frieren (38 vs 38) all read as (a) and keep
#      today's numbers to the digit.
#      Remaining hole, documented rather than solved: an absolute show whose final season
#      is long and has barely started airing. None in this library.
#
# Written here rather than in source_utils because it is a fact about a TMDb payload, not
# about a release name, and because source_utils already imports this module -- the
# reverse would be a cycle, which would leave the guard above unable to ever share this.
# Red Light's sibling is source_utils.absolute_episode_from_season_data; it carries
# signal 1 only, so the HxH case is still open there.
def _tmdb_numbering_is_absolute(season_data, extra_info, season, episode):
	def _count(number):
		try: return next((int(i.get('episode_count') or 0) for i in season_data if int(i.get('season_number') or -1) == int(number)), 0)
		except (TypeError, ValueError): return 0
	own_count = _count(season)
	if own_count and episode > own_count: return True
	last = (extra_info or {}).get('last_episode_to_air') or {}
	try: last_s, last_e = int(last['season_number']), int(last['episode_number'])
	except (KeyError, TypeError, ValueError): return False
	if last_s < 1: return False
	last_count = _count(last_s)
	return bool(last_count and last_e > last_count)

def series_absolute_episode(meta, season, episode):
	"""TMDb's (season, episode) as a SERIES-ABSOLUTE episode number, or None.

	The single home for this. It was written twice WITHOUT the guard above -- in
	scrapers/external.py for data['absolute_episode'] and again in
	source_utils.anime_episode_candidates for picking a file out of a pack -- and both
	numbers reach the same magneto providers, so the two cannot be allowed to disagree.

	Returns `episode` unchanged when TMDb already numbers the show absolutely, and when
	there is no earlier season to add (season 0 and season 1 included) -- which is exactly
	what the unguarded formula produced for those, so nothing moves for them."""
	try: season, episode = int(season), int(episode)
	except (TypeError, ValueError): return None
	try:
		season_data = (meta or {}).get('season_data') or []
		prior = sum(int(i.get('episode_count') or 0) for i in season_data
				if 0 < int(i.get('season_number') or 0) < season)
	except (AttributeError, TypeError, ValueError): return None
	if not prior: return episode
	if _tmdb_numbering_is_absolute(season_data, (meta or {}).get('extra_info'), season, episode): return episode
	return prior + episode

def movieset_meta(media_id, api_key, current_time=None):
	if media_id == None: return None
	id_type = 'tmdb_id'
	meta = meta_cache.get('movie_set', id_type, media_id, current_time)
	if meta: return meta
	try:
		data = movie_set_details(media_id, api_key)
		if not data: return None
		elif 'status_code' in data and data.get('status_code') in (6, 34, 37):
			meta = {'tmdb_id': media_id, 'fanart_added': True, 'blank_entry': True}
			meta_cache.set('movie_set', id_type, meta, 24, current_time)
			return meta
		data_get = data.get
		tmdb_image_url = 'https://image.tmdb.org/t/p/%s%s'
		title, tmdb_id, plot = data_get('name'), data_get('id'), data_get('overview', '')
		poster_path = data_get('poster_path', None)
		if poster_path: poster = tmdb_image_url % ('w780', poster_path)
		else: poster = ''
		backdrop_path = data_get('backdrop_path', None)
		if backdrop_path: fanart = tmdb_image_url % ('w1280', backdrop_path)
		else: fanart = ''
		parts = data_get('parts')
		meta = {'tmdb_id': tmdb_id, 'title': title, 'plot': plot, 'poster': poster, 'fanart': fanart, 'parts': parts, 'imdb_id': 'None', 'tvdb_id': 'None'}
		meta_cache.set('movie_set', id_type, meta, 720, current_time)
	except: pass
	return meta

_THUMBLESS_EXPIRATION = 6


def _thumbless_expiration(data, expiration):
	"""Cap the season TTL while an already-aired episode is missing its still."""
	try:
		if not data or expiration <= _THUMBLESS_EXPIRATION: return expiration
		from modules.utils import get_datetime
		current_date = get_datetime()
		for ep in data:
			if ep.get('thumb'): continue
			premiered = ep.get('premiered')
			if not premiered: continue
			try: aired = jsondate_to_datetime(premiered, '%Y-%m-%d', remove_time=True)
			except Exception: continue
			# Unaired episodes legitimately have no still; only a gap on one that HAS aired
			# means TMDb has not caught up yet.
			if aired and current_date >= aired: return _THUMBLESS_EXPIRATION
	except Exception: pass
	return expiration


def episodes_meta(season, meta):
	def _process():
		midseason_premiere = False
		for ep_data in details:
			writer, director, guest_stars = [], [], []
			ep_data_get = ep_data.get
			title, plot, premiered = ep_data_get('name'), ep_data_get('overview'), ep_data_get('air_date')
			season, episode, episode_id = ep_data_get('season_number'), ep_data_get('episode_number'), ep_data_get('id')
			try:
				if episode == 1:
					if 'premiere' in season_type: episode_type = 'series_premiere'
					else: episode_type = 'season_premiere'
				elif midseason_premiere: episode_type, midseason_premiere = 'mid_season_premiere', False
				else:
					episode_type = ep_data_get('episode_type')
					if episode_type == 'mid_season': episode_type, midseason_premiere = 'mid_season_finale', True
					elif episode_type == 'finale':
						if 'finale' in season_type: episode_type = 'series_finale'
						else: episode_type = 'season_finale'
					else: episode_type = ''
			except: episode_type = ''
			try: duration = ep_data_get('runtime')*60
			except: duration = 30*60
			rating, votes, still_path = ep_data_get('vote_average'), ep_data_get('vote_count'), ep_data_get('still_path', None)
			if still_path: thumb = tmdb_image_url % ('original', still_path)
			else: thumb = None
			cast = ep_data_get('guest_stars', [])
			if cast:
				try: guest_stars = [{'name': i['name'], 'role': i['character'], 'thumbnail': tmdb_image_url % ('h632', i['profile_path']) if i['profile_path'] else ''}\
									for i in cast]
				except: pass
			crew = ep_data_get('crew', None)
			if crew:
				try: writer = [i['name'] for i in crew if i['job'] in ('Author', 'Writer', 'Screenplay', 'Characters')]
				except: pass
				try: director = [i['name'] for i in crew if i['job'] == 'Director']
				except: pass
			yield {'writer': writer, 'director': director, 'mediatype': 'episode', 'episode_type': episode_type, 'episode_id': episode_id, 'title': title, 'plot': plot,
					'duration': duration, 'premiered': premiered, 'season': season, 'episode': episode, 'rating': rating, 'votes': votes, 'thumb': thumb, 'guest_stars': guest_stars}
	media_id, data = meta['tmdb_id'], None
	prop_string = '%s_%s' % (media_id, season)
	data = meta_cache.get_season(prop_string)
	if data is not None: return data
	try:
		tmdb_image_url = 'https://image.tmdb.org/t/p/%s%s'
		season, tvshow_status, total_seasons = int(season), meta['status'], meta['total_seasons']
		if season == 1: season_type = 'premiere_finale' if (total_seasons == season and tvshow_status in ('Ended', 'Canceled')) else 'premiere'
		else: season_type = 'finale' if (total_seasons == season and tvshow_status in ('Ended', 'Canceled')) else ''
		if tvshow_status in ('Ended', 'Canceled') or total_seasons > int(season): expiration = 4368
		else: expiration = 96
		try:
			details = season_episodes_details(media_id, season)['episodes']
			total_episodes = len(details)
			data = list(_process())
			# LOCAL PATCH 2026-08-07: enrich episodes with Trakt UTC first_aired
			# timestamps when Trakt is authorized. Gives accurate per-episode
			# air-datetime for streaming platforms (Netflix midnight-PT, Apple
			# TV+ Thu 21:00, HBO Sun 21:00 ET, anime late-night JST) — replaces
			# the "TMDb date + 20:00 local" approximation for the aired-check.
			# Silent no-op when Trakt unavailable or show/season not on Trakt.
			try:
				from apis.trakt_air import get_season_air_times
				airtimes = get_season_air_times(meta.get('imdb_id'), meta.get('tmdb_id'), season)
				if airtimes:
					for ep in data:
						fa = airtimes.get(ep.get('episode'))
						if fa: ep['first_aired_utc'] = fa
			except Exception: pass
			# LOCAL PATCH 2026-09-14: per-episode IMDb ratings, one request for the whole
			# season. Enriches here rather than at render time so the values ride the
			# season cache (96h airing / 4368h ended) alongside first_aired_utc above,
			# and cost one call per season per cache window rather than one per episode.
			#
			# Stored under its own key. TMDb's `rating` is left exactly as it was -- it
			# still feeds info_tag.setRating, so sorting and anything reading
			# ListItem.Rating are unaffected; this only adds a value the IMDb chip can
			# show. Worth keeping separate because the two disagree a lot: TMDb's episode
			# scores here have a median of 6 votes, IMDb's are thousands.
			try:
				from caches.settings_cache import get_setting
				_okey = get_setting('fenlight.omdb_api', '')
				if _okey and _okey != 'empty_setting' and get_setting('fenlight.omdb.episode_ratings', 'true') == 'true':
					from apis.omdb_api import season_episode_ratings
					_eps = season_episode_ratings(meta.get('imdb_id'), season, _okey)
					if _eps:
						for ep in data:
							r = _eps.get(ep.get('episode'))
							if r: ep['imdb_rating'] = r
			except Exception: pass
		except: data, expiration = [], 96
	except: data, expiration = [], 96
	# LOCAL PATCH 2026-08-30: shorten the cache while an aired episode still has no
	# still image. TMDb rarely has one the moment an episode drops -- it is uploaded
	# hours later -- so the season was cached with thumb=None and stayed blank for the
	# whole window. On an airing season that is 4 days, which is why episode thumbs
	# appeared never to refresh without clearing the cache by hand.
	#
	# Only the gap is re-checked: once every aired episode has a thumb the normal TTL
	# applies, so this costs an extra request only while something is genuinely missing.
	expiration = _thumbless_expiration(data, expiration)
	meta_cache.set_season(prop_string, data, expiration)
	return data

def all_episodes_meta(meta, include_specials=False):
	from threading import Thread
	def _get_tmdb_episodes(season):
		try: data.extend(episodes_meta(season, meta))
		except: pass
	try:
		data = []
		season_data = meta['season_data']
		seasons = [i['season_number'] for i in season_data]
		if not include_specials: seasons = [i for i in seasons if not i == 0]
		threads = [Thread(target=_get_tmdb_episodes, args=(i,)) for i in seasons]
		[i.start() for i in threads]
		[i.join() for i in threads]
	except: pass
	return data

def episode_groups(media_id):
	try: groups = episode_groups_data(media_id)['results']
	except: groups = None
	return groups or None

def group_details(group_id):
	return episode_group_details(group_id)

def group_episode_data(details, episode_id=None, season_number=None, episode_number=None):
	def _comparer(episode_item):
		if episode_id: return episode_item['id'] == int(episode_id)
		else: return episode_item['season_number'] == int(season_number) and episode_item['episode_number'] == int(episode_number)
	groups = details['groups']
	episode_data = next(({'season': item['order'], 'episode': i['order'] + 1} for item in groups for i in item['episodes'] if _comparer(i)), None)
	return episode_data

def movie_meta_external_id(external_source, external_id, api_key):
	return movie_external_id(external_source, external_id, api_key)

def tvshow_meta_external_id(external_source, external_id, api_key):
	return tvshow_external_id(external_source, external_id, api_key)

def movie_expiry(current_date, meta):
	try:
		difference = subtract_dates(current_date, jsondate_to_datetime(meta['premiered'], '%Y-%m-%d', remove_time=True))
		if difference < 0: expiration = abs(difference) + 1
		elif difference <= 14: expiration = 168
		elif difference <= 30: expiration = 336
		elif difference <= 180: expiration = 720
		else: expiration = 4368
	except: return 720
	return max(expiration, 168)

def tvshow_expiry(current_date, meta):
	try:
		if meta['status'] in ('Ended', 'Canceled'): expiration = 4368
		else:
			data = subtract_dates(jsondate_to_datetime(meta['extra_info']['next_episode_to_air']['air_date'], '%Y-%m-%d', remove_time=True), current_date) - 24
			if data <= 1: expiration = 24
			else: expiration = data*24
	except: expiration = 96
	return expiration

def meta_valid_check(meta, is_anime_list):
	if is_anime_list == None: return meta
	if is_anime_check(meta) != is_anime_list: meta = {}
	return meta

def cour_display_numbers(meta, season, episode):
	"""(season, episode) the way anime is actually numbered, for DISPLAY only.

	LOCAL PATCH 2026-08-27. TMDb files multi-cour anime under one season, so its
	numbering is not what anyone recognises: Frieren S1E30 is season 2 episode 2,
	and every Re:ZERO cour is TMDb season 1. Fribb has the real boundaries offline.

	Callers must use this for LABELS ONLY. The TMDb pair remains the identity for
	play urls, watched state, bookmarks, Trakt/Simkl sync and scraping -- renumbering
	any of those would orphan existing history.

	Returns the input unchanged for non-anime, when the setting is off, or when
	Fribb has no mapping, so every non-anime caller is unaffected.
	"""
	try:
		from modules import settings
		if not settings.anime_split_cours(): return season, episode
		if not is_anime_check(meta): return season, episode
		from caches import fribb_mappings
		if not fribb_mappings.is_available(): return season, episode
		info = fribb_mappings.find_cour_by_tmdb_coords(meta.get('tmdb_id'), season, episode)
		if not info: return season, episode
		cs, se = info.get('cour_season'), info.get('season_ep')
		if cs is None or se is None: return season, episode
		return int(cs), int(se)
	except Exception: return season, episode


def is_anime_check(meta=None, tmdb_id=None):
	if not meta: meta = meta_cache.get('tvshow', 'tmdb_id', tmdb_id)
	# LOCAL PATCH 2026-09-04: short-circuiting any() instead of building the full id list and
	# calling .index() on it. This is now a per-item gate in front of the Fribb index load
	# (indexers/tvshows.py), so it runs for every tile of every TV widget.
	try:
		return any(k.get('id') == 210024 for k in meta.get('keywords').get('results', []))
	except: return False
