# -*- coding: utf-8 -*-
# LOCAL PATCH (2026-06-12): HTTP Streams scraper for Fen Light.
# Hosts two direct-URL providers ported from plugin.video.tmdbmovies (Angelitto):
#   - HDHub   (JSON aggregator at hdhub.thevolecitor.qzz.io)
#   - HDHub4u (HDHub4u → MKVCinemas redirect-chain web scraper, movie-only)
#
# The heavy lifting (~2000 lines of regex-driven page parsing, redirect chasing,
# cloud-page processing) lives in `_http_providers_core.py` as a near-verbatim
# extraction of the upstream code. This wrapper does the Fen Light glue:
#   - reads info dict, applies per-provider settings gates
#   - calls into core functions in parallel
#   - converts core's stream dicts to Fen Light's source dict format
#   - external_cache (SQLite) for repeat scrapes
#   - URL hash dedup
import hashlib
import re
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
from caches.settings_cache import get_setting
from modules import source_utils
from modules.kodi_utils import make_session
from modules.utils import clean_file_name

# LOCAL PATCH 2026-08-29: pooled session for the validation probes, matching aiostreams.py:20.
# Validation was calling the module-level requests.head, which opens and discards a TCP+TLS
# connection per probe. Across ~25 sources spanning a handful of hosts that is most of the
# cost: measured on Harry Potter and the Goblet of Fire, the same 25 probes took ~25s bare
# and 10.8s pooled. This had been in place before and was lost in the revert at 69da61d.
_session = make_session('https://')


# LOCAL PATCH 2026-09-26: the display name, without the upstream formatter's debris.
#
# The HDHub aggregator returns Stremio-formatted rows whose name is three layers glued together:
#   'Dark.Matter.2024.S02E05...-4kHdHub.Com.mkv|^|4KMKVWEB-DL...~25.8Mbps4kmkv... .pad-4KHDHub
#    📡 Dark Matter (2024) • S02E05 🎞️ 4K • MKV • WEB-DL ... 🛰️ Source: 4KHDHub · R2🎧 Audio: ...'
# i.e. the real filename, then '|^|' and a squashed tag block (once cased, once lowercased)
# ending in '.pad-<source>', then an emoji description. All of it reached the source list.
# Rows with no filename (MoviesDrives) START at the tag block, so they showed only debris:
# '1080px264MKV1080px264mkv pad-MoviesDrives 📡 ...'.
#
# Kept: the filename when there is one; otherwise the description's title, episode and tags
# ('The Revolutionaries - Behroopiya (2026) S01E01 4K WEB-DL SDR x264 MKV'). Dropped: the tag
# block, the bitrate, and the Source/Audio tail -- source and host have their own column and
# audio languages are already extracted into extraInfo. Display only: quality and extraInfo
# are still parsed from the full upstream text, which is where the tags are richest.
#
# Films open the description with 🍿 instead of 📡 (Baby Do Die Do, 14 MoviesDrives rows, all
# shown whole: '🍿 Baby Do Die Do (2026) 🎞️ 4K • WEB-DL • SDR • MKV • ~14.9 Mbps 🛰️ Source: ...').
_DESC_START = re.compile('\U0001f4e1|\U0001f37f')  # 📡 episodes / 🍿 films
_DESC_STOP = re.compile(r'(?:\U0001f6f0️?|\U0001f3a7)')  # 🛰️ source / 🎧 audio
_DESC_SPLIT = re.compile(r'\s*(?:•|\U0001f39e️?)\s*')  # • and 🎞️
_BITRATE = re.compile(r'^~?\s*[\d.,]+\s*[kmg]bps$', re.I)
_TAG_BLOCK = re.compile(r'^\S*\.pad-\S+\s*')
_ZIP = re.compile(r'\.zip\b', re.I)
_MIRROR = re.compile(r'Source:\s*[^·|\n]*·\s*([A-Za-z0-9][\w.-]*)')  # 'Source: MoviesDrives · FSL' -> FSL


def _clean_display(raw):
	raw = (raw or '').strip()
	head, sep, tail = raw.partition('|^|')
	if sep and head.strip(): return head.strip()
	text = tail if sep else raw
	start = _DESC_START.search(text)
	if start:
		desc = _DESC_STOP.split(text[start.end():], 1)[0]
		parts = [p.strip() for p in _DESC_SPLIT.split(desc)]
		parts = [p for p in parts if p and not _BITRATE.match(p)]
		if parts: return ' '.join(parts)
	return _TAG_BLOCK.sub('', text).strip() or raw


# LOCAL PATCH 2026-08-29: the pre-signed expiry helpers moved to source_utils so the
# aiostreams scraper could use them too -- it sees the same FSL / R2 / PixelDrain hosts
# through its manifest. See source_utils.presign_expiry for the measurements.


class source:
	def __init__(self):
		self.scrape_provider = 'http_streams'
		self.sources = []
		self.timeout = 25

	def results(self, info):
		media_type = info.get('media_type')
		tmdb_id = info.get('tmdb_id')
		title = info.get('title') or ''
		year = info.get('year', '')
		season_key = info.get('season') if media_type == 'episode' else ''
		episode_key = info.get('episode') if media_type == 'episode' else ''
		imdb = info.get('imdb_id') or ''

		# Cache lookup (skip if no tmdb_id since cache is keyed by it)
		if tmdb_id:
			try:
				from caches.external_cache import external_cache
				cached = external_cache.get('http_streams', media_type, tmdb_id, title, year, season_key, episode_key)
				if cached is not None:
					self.sources = cached
					return self._return()
			except Exception: pass

		# Master gate
		if get_setting('fenlight.provider.http_streams', 'false') != 'true':
			return self._return()
		# LOCAL PATCH 2026-09-22: fall back to a `tmdb:` id when TMDb has no IMDb.
		# 25 of 890 cached shows (2.8%) carry no usable imdb -- regional TV mostly, plus
		# anthology seasons TMDb files as their own S01. The old gate returned zero for
		# every one of them. Both upstreams declare `tmdb:` in their manifest idPrefixes,
		# but a manifest claim is not a contract and only Sootio honours it for series.
		# Measured 2026-09-22, counting rows that carry a url (both pad their responses
		# with donation/Discord notice rows, so len(streams) overstates):
		#   Breaking Bad S01E01  HDHub  tt 16 playable | tmdb 0 ('No streams found')
		#   Breaking Bad S01E01  Sootio tt  6 playable | tmdb 6
		#   Dune Part Two movie  HDHub  tt 62 playable | tmdb 62
		# HDHub's movie path is fine and its series path is not, so the skip below is
		# series-only rather than a blanket HDHub exclusion.
		#
		# This is also why the Cinemeta parent-imdb remap (Red Light 2.6.4) was not
		# ported. On its own flagship case -- Monster: The Lizzie Borden Story, tmdb
		# 299939, no imdb -- Cinemeta maps S01E01 onto the parent as tt13207736:4:1,
		# which returns 0 playable on both providers, while tmdb:299939:1:1 returns 13
		# on Sootio with correctly matched titles. These upstreams index the show the
		# way TMDb numbers it, not the way IMDb does.
		imdb = self._valid_imdb(imdb)
		tmdb_stream_id = 'tmdb:%s' % tmdb_id if tmdb_id else ''
		if not imdb and not tmdb_stream_id:
			return self._return()

		# Translate media_type to upstream content_type ('movie' or 'tv')
		content_type = 'movie' if media_type == 'movie' else 'tv'
		season = info.get('season') if media_type == 'episode' else None
		episode = info.get('episode') if media_type == 'episode' else None

		# Per-provider id. Sootio takes either form for either content type; HDHub takes
		# `tmdb:` for movies only. An empty id means that provider has nothing to ask with.
		sootio_stream_id = imdb or tmdb_stream_id
		hdhub_stream_id = imdb or (tmdb_stream_id if content_type == 'movie' else '')

		scrape_ran = False
		try:
			from scrapers import _http_providers_core as core
			collected = []

			# Providers are Stremio-shaped JSON endpoints; _scrape_json_provider appends
			# /stream/{movie,series}/{imdb}[:s:e].json to whichever base it is handed.
			# scrape_hdhub4u and the MoviesDrive port were removed from _http_providers_core
			# on 2026-08-29 rather than left as unreachable code.
			run_hdhub = get_setting('fenlight.http_streams.hdhub', 'false') == 'true'
			run_sootio = get_setting('fenlight.http_streams.sootio', 'false') == 'true'

			tasks = []
			if run_hdhub and hdhub_stream_id:
				# Generic JSON aggregator at hdhub.thevolecitor.qzz.io
				HDHUB_URL = "https://hdhub.thevolecitor.qzz.io/eyJ0b3Jib3giOiJ1bnNldCIsInF1YWxpdGllcyI6IjIxNjBwLDEwODBwLDcyMHAiLCJzb3J0IjoiZGVzYyJ9"
				tasks.append(('HDHub', lambda: core._scrape_json_provider(
					HDHUB_URL, 'stream', 'HDHub',
					hdhub_stream_id, content_type, season, episode,
					title_query=title, year_query=year)))

			# LOCAL PATCH 2026-08-29: Sootio (sooti/sootio-stremio-addon) configured for
			# httpstreaming. Needs no parsing of its own -- it is Stremio-shaped, so the same
			# helper HDHub uses reads it unchanged.
			#
			# Worth having because it resolves the HubCloud interstitial SERVER-side, handing
			# back /resolve/httpstreaming/<encoded> which 302s to real storage. That is the
			# thing the direct path cannot do since the interstitial resolver was reverted:
			# on Silo S03E07 HDHub offered one playable 2160p (the FSL copy -- both HubCloud
			# DV links 404) while Sootio returned four, 8 of 9 playable overall.
			#
			# Self-hosted, and the whole config is embedded in the URL path, so the base has
			# to be a setting -- the same reason aiostreams.manifest_url is one.
			if run_sootio:
				sootio_url = (get_setting('fenlight.http_streams.sootio_url', '') or '').strip()
				# The configure page hands out .../manifest.json; the helper wants the base.
				if sootio_url.endswith('/manifest.json'): sootio_url = sootio_url[:-len('/manifest.json')]
				sootio_url = sootio_url.rstrip('/')
				# Enabled but unconfigured is a no-op, not a request to a bad base.
				if sootio_url.startswith('http') and sootio_stream_id:
					tasks.append(('Sootio', lambda: core._scrape_json_provider(
						sootio_url, 'stream', 'Sootio',
						sootio_stream_id, content_type, season, episode,
						title_query=title, year_query=year)))

			if not tasks:
				return self._return()

			# One worker per provider, capped at 3; fall back to sequential on RuntimeError
			# for embedded-box thread limits.
			try:
				with ThreadPoolExecutor(max_workers=min(3, len(tasks))) as ex:
					futures = [ex.submit(self._run_task, label, fn) for label, fn in tasks]
					for fut in futures:
						try:
							res = fut.result(timeout=self.timeout)
							if res: collected.extend(res)
						except Exception: pass
			except RuntimeError:
				for label, fn in tasks:
					try:
						res = self._run_task(label, fn)
						if res: collected.extend(res)
					except Exception: pass

			# Convert upstream stream dicts → Fen Light source dicts
			extras = source_utils.extras()
			self.sources = [s for s in (self._make_item(item, extras) for item in collected) if s]
			self.sources = self._drop_expired_presigns(self.sources, collected)
			# Dedup by URL hash
			seen = set()
			deduped = []
			for s in self.sources:
				h = s.get('hash') or ''
				if h and h in seen: continue
				if h: seen.add(h)
				deduped.append(s)
			self.sources = self._filter_dead_urls(deduped)
			scrape_ran = True
		except Exception as e:
			from modules.kodi_utils import logger
			logger('http_streams scraper Exception', str(e))

		# Cache result. HDHub's CDN URLs use ~1-hour-lived ?token= query params
		# (cdn.fsl-buckets.work returns 404 once expired), so cache for SHORT
		# windows — 30 min on success — to keep URLs fresh. 1 hour on empty so we
		# don't re-hammer hdhub for content it doesn't have. Ignore upstream
		# info['expiry_times'] (24h default would routinely outlast the tokens).
		if scrape_ran and tmdb_id:
			try:
				from caches.external_cache import external_cache
				expiry_hours = 0.5 if self.sources else 1
				external_cache.set('http_streams', media_type, tmdb_id, title, year, season_key, episode_key, self.sources, expiry_hours)
			except Exception: pass

		return self._return()

	# LOCAL PATCH 2026-09-22: TMDb hands back several flavours of 'no imdb' and a bare
	# truthiness check misses most of them -- metacache holds literal 'tt0000000' and ''
	# alongside None, and DeadLight's own settings use 'empty_setting' as their null.
	# Set taken from Red Light's _INVALID_IMDB so the two agree on what counts as missing.
	_INVALID_IMDB = ('', 'none', 'null', '0', 'tt0000000', 'tt0', 'empty_setting')

	@classmethod
	def _valid_imdb(cls, imdb):
		"""The id in tt-form, or '' when TMDb gave us nothing usable."""
		imdb = str(imdb or '').strip()
		if not imdb or imdb.lower() in cls._INVALID_IMDB: return ''
		if not imdb.startswith('tt'): imdb = 'tt' + imdb
		return '' if imdb.lower() in cls._INVALID_IMDB else imdb

	@staticmethod
	def _drop_expired_presigns(sources, raw_items):
		"""Drop pre-signed URLs past their expiry; mark the rest as needing no probe.

		Reference clock is the aggregator's Date header, carried on the raw items by
		_scrape_json_provider, not the local one -- see source_utils.presign_reference.
		"""
		server_date = next((i.get('server_date') for i in (raw_items or []) if i.get('server_date')), None)
		return source_utils.drop_expired_presigns(sources, server_date)

	@staticmethod
	def _filter_dead_urls(sources):
		# HEAD-check each URL in parallel; drop ones that 4xx/5xx/timeout/refuse
		# or return a non-video Content-Type (catches expired/CDN-error pages).
		# Gated on `http_streams.validate_urls` (default off) because validation
		# adds up to `validate_timeout` seconds of latency per scrape.
		if get_setting('fenlight.http_streams.validate_urls', 'false') != 'true':
			return sources
		if not sources:
			return sources
		try:
			timeout = max(2, int(get_setting('fenlight.http_streams.validate_timeout', '5') or '5'))
		except Exception:
			timeout = 5

		import requests
		ok_status = (200, 206)
		ok_ctype_prefixes = (
			'video/',
			'application/octet-stream',
			'application/vnd.apple.mpegurl',
			'application/x-mpegurl',
			'application/dash+xml',
		)

		def _response_ok(r):
			if r is None:
				return False
			if getattr(r, 'status_code', 999) not in ok_status:
				return False
			try:
				ctype = (r.headers.get('Content-Type') or '').lower().split(';', 1)[0].strip()
			except Exception:
				return False
			if not ctype:
				return False
			return any(ctype.startswith(p) for p in ok_ctype_prefixes)

		def is_alive(source):
			# LOCAL PATCH 2026-08-29: already settled by the pre-signed expiry gate. Those
			# links are inside their signed window, and 114 of 114 measured that way were
			# alive, so a probe can only cost time or invent a failure.
			if source.get('_presign_ok'):
				return source
			# http_streams URLs may have |Header=... suffix appended for Kodi's
			# player; strip it before the HEAD probe so requests doesn't choke.
			url = (source.get('url_dl') or source.get('url') or '').split('|', 1)[0]
			if not url:
				return None
			# LOCAL PATCH 2026-08-29: send NO explicit User-Agent. This looks like an omission
			# and is not. hcdn.hakunaymatata.com serves 200 video/mp4 to requests' default UA
			# and answers 428 Precondition Required to any browser UA, so a "send the source's
			# own headers" probe turns 4 working sources into 4 dead ones. Verified directly:
			#     bare / default UA -> 200 video/mp4 with real ftyp data
			#     browser UA        -> 428 'Precondition Required.'
			try:
				r = _session.head(url, timeout=timeout, allow_redirects=True)
				if _response_ok(r):
					return source
				# LOCAL PATCH 2026-08-29: retry once on 403. PixelDrain rate-limits under
				# concurrency and answers 403 application/json to links that serve fine a
				# moment later -- probing at 8 workers produced 4 such phantom failures, while
				# at 3 workers with a retry PixelDrain measured 0 dead of 71. This runs 6
				# workers, so without the retry validation manufactures its own dead links.
				if getattr(r, 'status_code', 0) == 403:
					time.sleep(1.0)
					r = _session.head(url, timeout=timeout, allow_redirects=True)
					if _response_ok(r):
						return source
				# Rate-limited on the HEAD: keep it, and do not spend a GET making it worse.
				if getattr(r, 'status_code', 0) == 429:
					return source
				r = _session.get(url, timeout=timeout, headers={'Range': 'bytes=0-0'}, stream=True)
				if _response_ok(r):
					return source
				if getattr(r, 'status_code', 0) == 403:
					time.sleep(1.0)
					r = _session.get(url, timeout=timeout, headers={'Range': 'bytes=0-0'}, stream=True)
					if _response_ok(r):
						return source
				# LOCAL PATCH 2026-08-29: 429 means US, not the link -- keep the source.
				#
				# Sootio rate-limits its /resolve/ endpoint ("Too many resolve requests"), and
				# it is easy to trip because every probe of a Sootio row makes THEIR server
				# perform the HubCloud resolution. Validating ~11 of them per scrape is enough.
				# Treating that as a dead link is plainly wrong -- it is a statement about our
				# request rate -- and it showed up as Lanterns S01E02 returning 35 rows instead
				# of 39, the four missing ones being perfectly playable.
				#
				# Dropping on 429 would also be self-reinforcing: the busier the scrape, the
				# more good sources disappear.
				if getattr(r, 'status_code', 0) == 429:
					return source
			except Exception:
				return None
			return None

		# Cap at 6: enough to keep validation off the critical path, low enough not to break
		# it. DO NOT RAISE. More workers looks like a free speedup and is not -- past 10 the
		# extra concurrency causes timeouts that silently discard WORKING sources. Measured on
		# Harry Potter and the Goblet of Fire, 25 rows, where 16 is the correct answer:
		#      6 workers / 3s  10.8s  kept 16   <- correct
		#     10 workers / 3s  10.1s  kept 16   <- correct, 0.7s faster, not worth the pids
		#     16 workers / 3s   7.3s  kept 14   <- two working sources thrown away
		#     16 workers / 5s  11.4s  kept 15
		#     24 workers / 5s  10.2s  kept 15
		# Same failure mode as PixelDrain's rate-limit 403s: load creates the failure that the
		# probe then reports as a dead link. 6 also stays modest for CoreELEC/LibreELEC, where
		# the kernel pid limit is the concern; the RuntimeError fallback below still degrades
		# to sequential if thread creation fails.
		max_workers = max(1, min(len(sources), 6))
		try:
			with ThreadPoolExecutor(max_workers=max_workers) as ex:
				checked = list(ex.map(is_alive, sources))
		except RuntimeError as e:
			from modules.kodi_utils import logger
			logger('http_streams thread pool failed', str(e))
			checked = [is_alive(s) for s in sources]
		return [s for s in checked if s is not None]

	@staticmethod
	def _run_task(label, fn):
		from modules.kodi_utils import logger
		try:
			out = fn() or []
			logger('http_streams %s' % label, 'returned %d streams' % len(out))
			return out
		except Exception as e:
			logger('http_streams %s error' % label, str(e))
			return []

	def _make_item(self, item, extras):
		"""Convert upstream stream dict to Fen Light source dict.
		Upstream shape (from _process_resolved_results / _scrape_json_provider):
		    {'name': str (host | size, e.g. "HubCloud | 2.1 GB"),
		     'url': str (with optional |Header=... suffix),
		     'quality': str ('4K'/'1080p'/'720p'/'SD'),
		     'title': str (full filename, e.g. "Movie.2024.1080p.BluRay.x265.HEVC.mkv"),
		     'size': str ('2.1 GB'),
		     'info': str (provider | branch info)}
		"""
		try:
			url = (item.get('url') or '').strip()
			if not url: return None
			url_part = url.split('|', 1)[0]
			if not self._is_valid_http_url(url_part): return None

			# Pick the most info-rich string for the display name + Fen Light's
			# release_info parser (codec / HDR / audio / source tags).
			# Priority order (mirrors AIOStreams' verbose-name convention):
			#   1. A real filename (.mkv/.mp4/etc.) — gold standard
			#   2. The upstream `info` field if it looks like a release name (has
			#      a 4-digit year OR a quality token like "2160p"/"1080p"/"720p").
			#      HDHub's _scrape_json_provider stuffs the rich tag-laden release
			#      name in here while leaving `title` as a short label.
			#   3. The longer of `title` / `name`
			upstream_title = (item.get('title') or '').strip()
			upstream_name = (item.get('name') or '').strip()
			upstream_info_raw = (item.get('info') or '').strip()

			# LOCAL PATCH 2026-08-29: drop HDHub's "10Gbps Download Only" rows, checked
			# against the RAW upstream fields rather than the display name -- the aiostreams
			# filter this mirrors reads behaviorHints.filename for the same reason.
			#
			# Matched on the '10gbps' tag specifically, not a bare 'download' substring.
			# Both select exactly the same rows today (verified on Silo S03E07/S03E02, Dune
			# Part Two and Lanterns S01E02 -- 6/6, 6/6, 23/23, 11/11 identical), but 'download'
			# is a common enough word in a release name that it would eventually catch
			# something real. '10Gbps Download Only' is HDHub's own label for the HubCloud
			# link-generator pages and means only that.
			#
			# HDHub tags its HubCloud rows "[10Gbps Download Only]" in `info`. Those are not
			# media URLs but link-generator pages (pixel.hubcloud.cx / gpdl.hubcloud.cx):
			# fetched, they answer 206 text/html, so Kodi has nothing to play. Measured on
			# two titles, `info` matches them exactly and nothing else:
			#     Dune Part Two    57 raw, 21 hubcloud, 21 with 'download' in info
			#     Lanterns S01E02  35 raw, 11 hubcloud, 11 with 'download' in info
			#
			# Checking display_source instead missed every one: when `title` ends in a video
			# extension it wins the display, and the bracket only lives in `info`.
			# Checking the URL would be worse than useless -- PixelDrain's API spells its
			# raw-file flag "?download", so 12 of Dune's URLs match and all 12 are playable.
			if '10gbps' in (upstream_info_raw + ' ' + upstream_name + ' ' + upstream_title).lower():
				return None
			# LOCAL PATCH 2026-08-29: drop HDHub's transcoded HLS ladder. See
			# source_utils.is_transcode_url -- these tag themselves 4K/1080p/720p while
			# carrying 8.4/2.1/1.6 Mbps, and nothing downstream can tell.
			if source_utils.is_transcode_url(url_part):
				return None
			# LOCAL PATCH 2026-09-26: drop zip archives (whole-season packs Kodi cannot play),
			# e.g. 'Bleach.S01.1080p.WEB-DL.Hindi...-HDHub4u.Ms.zip' from HDHub. Read from the raw
			# names: that row's URL was an opaque pengu.uk/direct/<token> with no extension.
			# '.zip' with the dot, so a title merely containing the word is not caught.
			if _ZIP.search(upstream_info_raw + ' ' + upstream_name + ' ' + upstream_title + ' ' + url_part):
				return None

			import re as _re_dn
			info_looks_release = bool(_re_dn.search(r'\b(19|20)\d{2}\b|\b(?:2160|1080|720|480)p\b', upstream_info_raw, _re_dn.IGNORECASE))
			has_video_ext = any(upstream_title.lower().endswith(ext) for ext in ('.mkv', '.mp4', '.avi', '.mov', '.ts', '.webm'))
			if has_video_ext:
				parse_source = upstream_title
				display_source = upstream_title
			elif info_looks_release and len(upstream_info_raw) > len(upstream_title):
				# Use the rich info as the display, but strip noise that's already
				# shown in other columns (HOSTER + SIZE):
				#   - leading hoster acronym in brackets: "[FSL]", "[FSLV2]", "[PIXELDRAIN]"
				#   - size with optional emoji: "[💾 29.79 GB]", "💾 29.79 GB", "[2.1 GB]"
				cleaned_info = upstream_info_raw
				# Strip ALL leading bracketed acronym tokens (FSL, FSLV2, PIXELDRAIN, HUBCDN, etc.)
				# Loop because there can be multiple in a row ("[FSL] [💾 29.79 GB] ...").
				while True:
					m = _re_dn.match(r'\s*\[([A-Z][A-Z0-9_-]+)\]\s*', cleaned_info)
					if not m: break
					cleaned_info = cleaned_info[m.end():]
				# Strip size pattern wherever it appears (emoji-prefixed or bracketed)
				cleaned_info = _re_dn.sub(r'\[?\s*💾\s*[\d.,]+\s*(?:GB|GiB|MB|MiB|TB|TiB)\s*\]?', '', cleaned_info, flags=_re_dn.IGNORECASE)
				cleaned_info = _re_dn.sub(r'\[\s*[\d.,]+\s*(?:GB|GiB|MB|MiB|TB|TiB)\s*\]', '', cleaned_info, flags=_re_dn.IGNORECASE)
				cleaned_info = _re_dn.sub(r'\s+', ' ', cleaned_info).strip(' |\t\n')
				parse_source = cleaned_info
				display_source = cleaned_info
			elif len(upstream_title) >= len(upstream_name):
				parse_source = upstream_title or upstream_name
				display_source = upstream_title or upstream_name
			else:
				parse_source = upstream_name
				display_source = upstream_name

			# LOCAL PATCH 2026-09-26: see _clean_display. parse_source stays raw for the tag parser.
			display_source = _clean_display(display_source)
			if not display_source: return None
			if any(x in display_source.lower() for x in extras): return None
			# De-dup "HDHub | HDHub …" in the display when upstream's _scrape_json_provider
			# attached the label twice ({label} + clean_name where clean_name also has it).
			display_source_clean = _re_dn.sub(r'\bHDHub\s*\|?\s*HDHub\b', 'HDHub', display_source, flags=_re_dn.IGNORECASE)
			display_name = clean_file_name(display_source_clean)

			# Size: upstream's size field shape varies by provider:
			#   - HDHub4u (_process_resolved_results): item['size'] = "2.1 GB" string (from branch [2.1 GB])
			#   - HDHub JSON aggregator (_scrape_json_provider): NO size field; size is embedded
			#     in item['info'] as Stremio behaviorHints text like "💾 9.58 GB"
			#   - Sometimes size is in the filename itself (item['title']: "Movie.2024.2.1GB.mkv")
			# Try all three in order.
			size_gb, size_str = self._extract_size(item.get('size'), item.get('info'), upstream_title, upstream_name)

			# Quality + extraInfo: feed Fen Light's release_info parser as much text
			# as possible. Upstream sometimes gives short names ("HDHub 2160p",
			# "Project Hail Mary") with the actual codec/HDR/audio tags living in
			# item['info'] (Stremio behaviorHints description). Combining title +
			# info gives the parser enough to extract HEVC/HDR/WEB/DDP/etc. for
			# items that would otherwise show "INFO: N/A".
			upstream_info_text = (item.get('info') or '').strip()
			parse_combined = (parse_source + ' ' + upstream_info_text).strip() if upstream_info_text else parse_source
			fl_quality, details = source_utils.get_file_info(name_info=source_utils.release_info_format(parse_combined))
			# If Fen Light couldn't extract a quality (defaulted to SD) but upstream has
			# a definite quality (4K/1080p/720p), prefer upstream's signal.
			upstream_q = (item.get('quality') or '').strip()
			quality_map = {'4k': '4K', '2160p': '4K', '1080p': '1080p', '720p': '720p', '480p': 'SD', 'sd': 'SD'}
			mapped_upstream_q = quality_map.get(upstream_q.lower(), upstream_q if upstream_q in ('4K', '1080p', '720p', 'SD') else '')
			if fl_quality == 'SD' and mapped_upstream_q and mapped_upstream_q != 'SD':
				quality = mapped_upstream_q
			else:
				quality = fl_quality or mapped_upstream_q or 'SD'

			# Append detected audio-language tokens (Hindi, English, Tamil, etc.) to
			# the info tag list — same convention as Fen Light's existing MULTI-LANG tag.
			# Look across all upstream string fields since languages can appear in any.
			langs = self._extract_languages(parse_source, upstream_info_text, upstream_title, upstream_name)
			lang_str = ' | '.join(langs) if langs else ''
			# extraInfo = Fen Light's parsed codec/HDR/audio tags + language tags.
			# Upstream info is otherwise discarded (duplicates title/size/filename).
			parts = []
			if details: parts.append(details)
			if lang_str: parts.append(lang_str)
			extra_info = ' | '.join(parts)

			# Derive the actual hoster (PixelDrain / FSL-V2 / HubCloud / etc.) from
			# the URL's domain pattern — same helper the upstream redirect resolver
			# uses to label files. Surfaces as the Hoster column in the source picker.
			try:
				from scrapers import _http_providers_core as core
				hoster = core._identify_host_from_url(url_part) or ''
			except Exception:
				hoster = ''
			# LOCAL PATCH 2026-09-26: behind HDHub's pengu.uk proxy the URL names no host, so the
			# identifier falls back to the domain and every row read 'Pengu' -- which also made
			# each file's FSL and PixelDrain copies indistinguishable once the description was
			# cleaned out of the name. The aggregator names the mirror there instead:
			# 'Source: MoviesDrives · FSL'. Used only over that domain fallback, so a URL that
			# does identify its host (PixelDrain, HubCloud, ...) keeps its label. The fallback is
			# recognised by its exact spelling, first label .title()'d ('Pengu') or 'Direct':
			# a case-blind compare also caught 'PixelDrain' against pixeldrain.dev.
			netloc = urlparse(url_part).netloc.lower().replace('www.', '')
			if hoster in ('', 'Direct', netloc.split('.')[0].title()):
				mirror = _MIRROR.search(upstream_info_raw + ' ' + upstream_name + ' ' + upstream_title)
				if mirror: hoster = mirror.group(1)

			url_hash = hashlib.sha1(url_part.encode('utf-8')).hexdigest()[:24]
			return {
				'name': display_source,                 # full filename when available
				'display_name': display_name,
				'quality': quality,
				'size': size_gb,
				'size_label': size_str if size_str else ('%.2f GB' % size_gb if size_gb > 0 else '0.00 GB'),
				'extraInfo': extra_info,
				'url_dl': url,
				'id': url_hash,
				'debrid': self.scrape_provider,
				'scrape_provider': self.scrape_provider,
				'direct': True,
				'direct_debrid_link': True,
				'local': False,
				'source': self.scrape_provider,
				'hash': url_hash,
				'hoster': hoster,                       # PixelDrain / FSL-V2 / etc.; consumed by windows/sources.py
			}
		except Exception:
			return None

	# Common audio-language tokens worth detecting. Order matters — first match
	# wins per language to avoid double-counting. Each entry: (display_label,
	# list-of-lowercase-patterns-to-match-as-whole-words-or-bracketed).
	_LANG_PATTERNS = (
		('HINDI',     ('hindi', 'hin')),
		('ENGLISH',   ('english', 'eng')),
		('TAMIL',     ('tamil', 'tam')),
		('TELUGU',    ('telugu', 'tel')),
		('MALAYALAM', ('malayalam', 'mal')),
		('KANNADA',   ('kannada', 'kan')),
		('BENGALI',   ('bengali', 'ben')),
		('PUNJABI',   ('punjabi', 'pun')),
		('MARATHI',   ('marathi', 'mar')),
		('GUJARATI',  ('gujarati', 'guj')),
		('URDU',      ('urdu', 'urd')),
		('SPANISH',   ('spanish', 'spa', 'esp')),
		('FRENCH',    ('french', 'fre', 'fra')),
		('GERMAN',    ('german', 'ger', 'deu')),
		('ITALIAN',   ('italian', 'ita')),
		('RUSSIAN',   ('russian', 'rus')),
		('JAPANESE',  ('japanese', 'jap', 'jpn')),
		('KOREAN',    ('korean', 'kor')),
		('CHINESE',   ('chinese', 'chi', 'zho')),
		('ARABIC',    ('arabic', 'ara')),
		('TURKISH',   ('turkish', 'tur')),
		('DUTCH',     ('dutch', 'dut', 'nld')),
		('POLISH',    ('polish', 'pol')),
		('PORTUGUESE',('portuguese', 'por')),
	)

	@classmethod
	def _extract_languages(cls, *candidates):
		"""Scan candidate strings for audio-language tokens. Returns a
		deduplicated ordered list of UPPERCASE language labels found.
		Detection uses word-boundary regex against the lowercased input so
		that random substrings (e.g. 'china' inside 'machinaut') don't false-match."""
		import re as _re
		hits = []
		seen = set()
		joined = ' '.join((c or '') for c in candidates if c).lower()
		if not joined: return hits
		for label, pats in cls._LANG_PATTERNS:
			for pat in pats:
				# \b doesn't work next to brackets/punctuation in some cases; use a
				# permissive boundary that accepts start/end/non-letter on each side.
				if _re.search(r'(?<![a-z])' + _re.escape(pat) + r'(?![a-z])', joined):
					if label not in seen:
						hits.append(label)
						seen.add(label)
					break
		return hits

	@staticmethod
	def _extract_size(*candidates):
		"""Best-effort size extractor — try each candidate string for a size pattern
		and return (size_gb_float, size_label_str). Returns (0.0, '') if nothing parses.
		Patterns recognized (case-insensitive):
		    "[2.1 GB]"             — HDHub4u branch format with brackets
		    "💾 9.58 GB"           — Stremio behaviorHints (emoji + size)
		    "Size: 2.1 GB"         — generic label
		    "2.1 GB" / "2.1GB"     — bare format
		    "2100 MB" / "1.2 TB"   — unit variants
		"""
		import re as _re
		# Order patterns by specificity (most specific first to avoid false positives).
		patterns = (
			_re.compile(r'\[([\d.,]+)\s*(GB|GiB|MB|MiB|TB|TiB)\]', _re.IGNORECASE),
			_re.compile(r'💾\s*([\d.,]+)\s*(GB|GiB|MB|MiB|TB|TiB)', _re.IGNORECASE),
			_re.compile(r'(?:size|file\s*size)\s*[:\-]\s*([\d.,]+)\s*(GB|GiB|MB|MiB|TB|TiB)', _re.IGNORECASE),
			_re.compile(r'(?<![A-Za-z0-9])([\d.,]+)\s*(GB|GiB|MB|MiB|TB|TiB)(?![A-Za-z0-9])', _re.IGNORECASE),
		)
		for candidate in candidates:
			if not candidate or not isinstance(candidate, str): continue
			text = candidate.strip()
			if not text: continue
			for pat in patterns:
				m = pat.search(text)
				if not m: continue
				try:
					num = float(m.group(1).replace(',', '.'))
					unit = m.group(2).upper().rstrip('B').rstrip('I')  # GB/GIB → G, MB/MIB → M
					if unit == 'G': size_gb = num
					elif unit == 'M': size_gb = num / 1024.0
					elif unit == 'T': size_gb = num * 1024.0
					else: continue
					if size_gb <= 0 or size_gb > 500: continue  # sanity: >500GB is bogus (4K remux ceiling)
					return round(size_gb, 2), '%.2f GB' % size_gb
				except Exception: continue
		return 0.0, ''

	@staticmethod
	def _is_valid_http_url(url):
		"""Strict http/https URL validation (same convention as aiostreams)."""
		if not url or not isinstance(url, str): return False
		url = url.strip()
		if not url or len(url) > 8000: return False
		if any(c in url for c in ('\n', '\r', '\t', '\0', ' ')): return False
		lower = url.lower()
		if not (lower.startswith('http://') or lower.startswith('https://')): return False
		try:
			from urllib.parse import urlparse
			p = urlparse(url)
			if p.scheme not in ('http', 'https'): return False
			host = (p.hostname or '').lower()
			if not host: return False
			if host in ('localhost', 'example.com', 'placeholder', '0.0.0.0'): return False
			return True
		except Exception:
			return False

	def _return(self):
		source_utils.internal_results(self.scrape_provider, self.sources)
		return self.sources
