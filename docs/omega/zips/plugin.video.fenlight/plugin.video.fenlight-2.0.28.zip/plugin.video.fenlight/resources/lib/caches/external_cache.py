# -*- coding: utf-8 -*-
from caches.base_cache import connect_database, get_timestamp
# from modules.kodi_utils import logger

class ExternalCache(object):
	def get(self, source, media_type, tmdb_id, title, year, season, episode):
		result = None
		try:
			cache_data = self._execute(
				'SELECT results, expires FROM results_data WHERE provider = ? AND db_type = ? AND tmdb_id = ? AND title = ? AND year = ? AND season = ? AND episode = ?',
				(source, media_type, tmdb_id, title, year, season, episode)).fetchone()
			if cache_data:
				if cache_data[1] > get_timestamp(): result = eval(cache_data[0])
				else: self.delete(source, media_type, tmdb_id, title, year, season, episode)
		except: pass
		return result

	def set(self, source, media_type, tmdb_id, title, year, season, episode, results, expire_time):
		try:
			expires = get_timestamp(expire_time)
			self._execute('INSERT OR REPLACE INTO results_data VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
				(source, media_type, tmdb_id, title, year, season, episode, repr(results or []), int(expires)))
		except: pass

	# LOCAL PATCH 2026-09-26: `year` was missing from this signature and its parameters while the SQL
	# has seven placeholders, and get() called it with seven arguments in a different order -- a
	# TypeError swallowed by get()'s bare except, so an expired row was never deleted on read (only
	# overwritten later by set()'s INSERT OR REPLACE).
	def delete(self, source, media_type, tmdb_id, title, year, season, episode):
		try:
			self._execute('DELETE FROM results_data WHERE provider = ? AND db_type = ? AND tmdb_id = ? AND title = ? AND year = ? AND season = ? AND episode = ?',
				(source, media_type, tmdb_id, title, year, season, episode))
		except: return

	def delete_cache_single(self, media_type, tmdb_id):
		try:
			self._execute('DELETE FROM results_data WHERE db_type=? AND tmdb_id=?', (media_type, tmdb_id))
			self._vacuum()
			return True
		except: return False

	def clear_cache(self):
		try:
			self._execute('DELETE FROM results_data', ())
			self._vacuum()
			return True
		except: return False

	def _execute(self, command, params):
		self.dbcon = connect_database('external_db')
		return self.dbcon.execute(command, params)

	# LOCAL PATCH 2026-09-26: no dbcon.close() here or in _vacuum -- the same bug debrid_cache.py
	# fixed on 2026-09-05. connect_database caches the connection PER THREAD and hands the same
	# object back, so closing it left a dead handle for the next call: clean_database closed it and
	# _vacuum then got it back closed, so 'Clean Databases' always reported EXTERNAL CACHE FAILED,
	# and delete_cache_single (every rescrape) left later external_cache calls on that thread
	# failing silently. The pool owns the connection's lifetime.
	def clean_database(self):
		try:
			dbcon = connect_database('external_db')
			dbcon.execute('DELETE from results_data WHERE CAST(expires AS INT) <= ?', (get_timestamp(),))
			self._vacuum()
			return True
		except: return False

	def _vacuum(self):
		dbcon = connect_database('external_db')
		dbcon.execute('VACUUM')

external_cache = ExternalCache()
