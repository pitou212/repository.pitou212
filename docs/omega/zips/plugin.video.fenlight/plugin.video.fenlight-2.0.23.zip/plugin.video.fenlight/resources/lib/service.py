# -*- coding: utf-8 -*-
from xbmc import Monitor
import os
import json
import inspect
from time import time
from threading import Thread
from caches.settings_cache import get_setting, set_setting, sync_settings
from modules import kodi_utils

pause_services_prop = 'fenlight.pause_services'
firstrun_update_prop = 'fenlight.firstrun_update'
current_skin_prop = 'fenlight.current_skin'
trakt_service_string = 'TraktMonitor Service Update %s - %s'
trakt_success_line_dict = {'success': 'Trakt Update Performed', 'no account': '(Unauthorized) Trakt Update Performed'}
# LOCAL PATCH 2026-07-23: MDBList background sync monitor — mirrors TraktMonitor.
mdblist_service_string = 'MDBListMonitor Service Update %s - %s'
mdblist_success_line_dict = {'success': 'MDBList Update Performed', 'no account': '(Unauthorized) MDBList Update Performed'}
# LOCAL PATCH 2026-07-29: SIMKL sync monitor string constants.
simkl_service_string = 'SIMKLMonitor Service Update %s - %s'
simkl_success_line_dict = {'success': 'SIMKL Update Performed', 'no account': '(Unauthorized) SIMKL Update Performed'}
update_string = 'Next Update in %s minutes...'
anilist_service_string = 'AniListMonitor Service Update %s - %s'

class SetAddonConstants:
	def run(self):
		kodi_utils.logger('DeadLight', 'SetAddonConstants Service Starting')
		import random
		addon_items = [
			('fenlight.playback_key', str(random.randint(1000, 10000))),
			('fenlight.addon_name', kodi_utils.addon_info('name')),
			('fenlight.addon_version', kodi_utils.addon_info('version')),
			('fenlight.addon_path', kodi_utils.addon_info('path')),
			('fenlight.addon_profile', kodi_utils.translate_path(kodi_utils.addon_info('profile'))),
			('fenlight.addon_icon', kodi_utils.translate_path(kodi_utils.addon_info('icon'))),
			('fenlight.addon_icon_mini', os.path.join(kodi_utils.addon_info('path'), 'resources', 'media', 'addon_icons', 'minis',
			os.path.basename(kodi_utils.translate_path(kodi_utils.addon_info('icon'))))),
			('fenlight.addon_fanart', kodi_utils.addon_fanart())
					]
		for item in addon_items: kodi_utils.set_property(*item)
		return kodi_utils.logger('DeadLight', 'SetAddonConstants Service Finished')

class DatabaseMaintenance:
	def run(self):
		kodi_utils.logger('DeadLight', 'DatabaseMaintenance Service Starting')
		# LOCAL PATCH 2026-05-26: defer 15s so PRAGMA integrity_check across 15 SQLite DBs
		# (potentially 100-500ms) doesn't block Kodi's critical boot path. Integrity is safety-
		# critical but checking it 15s into the session vs at t=0 has no user-visible difference.
		# LOCAL PATCH 2026-09-04: gate on "not playing" instead of picking a bigger number.
		#
		# An earlier version of this patch moved the defer 15s -> 90s, reasoning that 15s
		# landed in the home screen's widget build. That was a bad trade and it broke
		# playback: integrity_check READS EVERY BYTE of every DB (~40 MB here) on its own
		# database.connect() handles, which bypass the thread-local pool, and 90s after boot
		# is precisely when a user has finished navigating and pressed play. Observed:
		# service start 18:57:19, check fired 18:58:50, four seconds after the demuxer came
		# up on a 2160p HDR stream, which then stalled. 15s is a moment when nothing else is
		# happening; 90s is a moment when everything is.
		#
		# The delay was never the real control. Every sync monitor in this file already waits
		# on `is_playing() or pause_services`, and this is the one background job heavy enough
		# to need it most. So: keep the proven 15s, then hold for playback the same way they
		# do. Contending with a widget build only makes widgets slower; contending with a
		# video stream makes it stutter.
		monitor = kodi_utils.kodi_monitor()
		player = kodi_utils.kodi_player()
		if monitor.waitForAbort(15):
			return kodi_utils.logger('DeadLight', 'DatabaseMaintenance Service Finished')
		while player.isPlayingVideo() or kodi_utils.get_property(pause_services_prop) == 'true':
			if monitor.waitForAbort(10):
				return kodi_utils.logger('DeadLight', 'DatabaseMaintenance Service Finished')
		from caches.base_cache import check_databases_integrity
		check_databases_integrity(silent=True)
		return kodi_utils.logger('DeadLight', 'DatabaseMaintenance Service Finished')

class SyncSettings:
	def run(self):
		kodi_utils.logger('DeadLight', 'SyncSettings Service Starting')
		sync_settings()
		return kodi_utils.logger('DeadLight', 'SyncSettings Service Finished')

class OnUpdateChanges:
	def run(self):
		kodi_utils.logger('DeadLight', 'OnUpdateChanges Service Starting')
		try:
			for method in list(filter(lambda x: x[0] != 'run', inspect.getmembers(OnUpdateChanges, predicate=inspect.isfunction))):
				if not get_setting('fenlight.updatechecks.%s' % method[0], 'false') == 'true':
					method[1](self)
					set_setting('updatechecks.%s' % method[0], 'true')
		except: pass
		return kodi_utils.logger('DeadLight', 'OnUpdateChanges Service Finished')

	def refresh_addon_keys(self):
		# For update 2.2.01 - 03
		from caches.trakt_cache import clear_all_trakt_cache_data
		from caches.tmdb_lists import tmdb_lists_cache
		from caches.settings_cache import restore_setting_default
		show_dialog = False
		if get_setting('fenlight.tmdb_api') == 'b370b60447737762ca38457bd77579b3':
			restore_setting_default({'silent': 'true', 'setting_id': 'tmdb_api'})
			set_setting('tmdb.token', 'empty_setting')
			set_setting('tmdb.account_id', 'empty_setting')
			set_setting('tmdb.username', 'empty_setting')
			set_setting('tmdb.session_id', 'empty_setting')
			set_setting('tmdb.account_session_id', 'empty_setting')
			tmdb_lists_cache.clear_all()
			show_dialog = True
		if get_setting('fenlight.trakt.client') == '1038ef327e86e7f6d39d80d2eb5479bff66dd8394e813c5e0e387af0f84d89fb':
			restore_setting_default({'silent': 'true', 'setting_id': 'trakt.client'})
			set_setting('trakt.user', 'empty_setting')
			set_setting('trakt.expires', '0')
			set_setting('trakt.token', '0')
			set_setting('trakt.refresh', '0')
			set_setting('trakt.next_daily_clear', '0')
			set_setting('watched_indicators', '0')
			clear_all_trakt_cache_data(silent=True, refresh=False)
			show_dialog = True
		if show_dialog:
			text = 'The original developer of Fen Light has revoked all keys (Trakt, TMDb) that have been used up until now '\
			'within this addon, with permission, due to security concerns.'
			kodi_utils.ok_dialog(heading='Addon Credentials Reset', text=text)
			text = 'This unfortunately means you will need to re-authenticate your Trakt & TMDb accounts through Fen Light AM  if you are currently using them. ' \
			'My apologies, but with the previous keys being revoked, this is necessary.'
			kodi_utils.ok_dialog(heading='Addon Credentials Reset', text=text)

	# LOCAL PATCH 2026-08-29: cm_sort_order drops any item missing from the STORED order, so
	# a new context entry is invisible on an existing install without this. Same shape as
	# register_drop_show_cm below.
	def register_anilist_manager_cm(self):
		for key in ('context_menu.enabled', 'context_menu.order'):
			stored = get_setting('fenlight.%s' % key, '')
			if not stored or 'anilist_manager' in stored.split(','): continue
			items = stored.split(',')
			try: idx = items.index('trakt_manager') + 1
			except ValueError: idx = len(items)
			items.insert(idx, 'anilist_manager')
			set_setting(key, ','.join(items))

	def register_drop_show_cm(self):
		for key in ('context_menu.enabled', 'context_menu.order'):
			stored = get_setting('fenlight.%s' % key, '')
			if not stored or 'drop_show' in stored.split(','): continue
			items = stored.split(',')
			try: idx = items.index('trakt_manager') + 1
			except ValueError: idx = len(items)
			items.insert(idx, 'drop_show')
			set_setting(key, ','.join(items))

class CustomWindowsPrepare:
	def run(self):
		kodi_utils.logger('DeadLight', 'CustomWindowsPrepare Service Starting')
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		kodi_utils.clear_property(current_skin_prop)
		# LOCAL PATCH 2026-05-26: defer the heavy windows.base_window import + ExtrasUtils().run()
		# off Kodi's critical boot path. Wait 15s for Kodi to settle, then do the one-shot init
		# and start the font-monitor loop. Cuts boot-blocking work by ~50-150ms.
		if wait_for_abort(15):
			return kodi_utils.logger('DeadLight', 'CustomWindowsPrepare Service Finished')
		from windows.base_window import FontUtils, ExtrasUtils
		ExtrasUtils().run()
		font_utils = FontUtils()
		while not monitor.abortRequested():
			font_utils.execute_custom_fonts()
			wait_for_abort(20)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('DeadLight', 'CustomWindowsPrepare Service Finished')

class TraktMonitor:
	def run(self):
		kodi_utils.logger('DeadLight', 'TraktMonitor Service Starting')
		from apis.trakt_api import trakt_sync_activities
		from modules.settings import trakt_user_active, trakt_sync_interval
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				sync_interval, wait_time = trakt_sync_interval()
				next_update_string = update_string % sync_interval
				# LOCAL PATCH 2026-09-12: was `if trakt_user_active:` -- the bare function
				# object, always truthy, so the 'no_auth' branch below was unreachable and a
				# de-authenticated Trakt logged 'Success' every hour. MDBListMonitor already
				# calls its equivalent. trakt_sync_activities() guards internally, so this
				# only ever mislabelled the log -- but during an auth outage that misdirects.
				if trakt_user_active(): status = trakt_sync_activities()
				else: status = 'no_auth'
				if status == 'failed': kodi_utils.logger('DeadLight', trakt_service_string % ('Failed. Error from Trakt', next_update_string))
				elif status == 'no_auth': kodi_utils.logger('DeadLight', trakt_service_string % ('Not Run. No Current Trakt Account', next_update_string))
				else:
					if status in ('success', 'no account'):
						kodi_utils.logger('DeadLight', trakt_service_string % ('Success. %s' % trakt_success_line_dict[status], next_update_string))
					else:
						kodi_utils.logger('DeadLight', trakt_service_string % ('Success. No Changes Needed', next_update_string))# 'not needed'
					if status == 'success' and get_setting('fenlight.trakt.refresh_widgets', 'false') == 'true':
						kodi_utils.run_plugin({'mode': 'kodi_refresh'})
			except Exception as e: kodi_utils.logger('DeadLight', trakt_service_string % ('Failed', 'The following Error Occured: %s' % str(e)))
			wait_for_abort(wait_time)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('DeadLight', 'TraktMonitor Service Finished')

# LOCAL PATCH 2026-07-23: MDBList background sync — same shape as TraktMonitor.
# Runs in its own thread, polls mdbl_sync_activities on the configured interval,
# gated on mdblist_user_active + not-playing + pause-services flag.
class MDBListMonitor:
	def run(self):
		kodi_utils.logger('DeadLight', 'MDBListMonitor Service Starting')
		# LOCAL PATCH 2026-08-07 (POV OAuth port): also import mdbl_expires so we refresh
		# the OAuth access_token proactively before the next sync tick when in OAuth mode.
		# No-op when in legacy API-key mode.
		from apis.mdblist_api import mdbl_sync_activities, mdbl_expires
		from modules.settings import mdblist_user_active, mdblist_sync_interval
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				sync_interval, wait_time = mdblist_sync_interval()
				next_update_string = update_string % sync_interval
				if mdblist_user_active():
					try: mdbl_expires()  # refresh access_token if close to expiry (OAuth mode only)
					except Exception: pass
					status = mdbl_sync_activities()
				else: status = 'no_auth'
				if status == 'failed': kodi_utils.logger('DeadLight', mdblist_service_string % ('Failed. Error from MDBList', next_update_string))
				elif status == 'no_auth': kodi_utils.logger('DeadLight', mdblist_service_string % ('Not Run. No Current MDBList Account', next_update_string))
				else:
					if status in ('success', 'no account'):
						kodi_utils.logger('DeadLight', mdblist_service_string % ('Success. %s' % mdblist_success_line_dict[status], next_update_string))
					else:
						kodi_utils.logger('DeadLight', mdblist_service_string % ('Success. No Changes Needed', next_update_string))
					if status == 'success' and get_setting('fenlight.mdblist.refresh_widgets', 'false') == 'true':
						kodi_utils.run_plugin({'mode': 'kodi_refresh'})
			except Exception as e: kodi_utils.logger('DeadLight', mdblist_service_string % ('Failed', 'The following Error Occured: %s' % str(e)))
			wait_for_abort(wait_time)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('DeadLight', 'MDBListMonitor Service Finished')


# LOCAL PATCH 2026-07-29: SIMKL background sync — same shape as MDBListMonitor.
# Selected via watched_indicators == 3. Polls /sync/activities on the
# simkl.sync_interval; when any timestamp advances, invalidates list caches.
class SIMKLMonitor:
	def run(self):
		kodi_utils.logger('DeadLight', 'SIMKLMonitor Service Starting')
		from apis.simkl_api import simkl_sync_activities
		from modules.settings import simkl_user_active, simkl_sync_interval
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				sync_interval, wait_time = simkl_sync_interval()
				next_update_string = update_string % sync_interval
				if simkl_user_active(): status = simkl_sync_activities()
				else: status = 'no_auth'
				if status == 'failed': kodi_utils.logger('DeadLight', simkl_service_string % ('Failed. Error from SIMKL', next_update_string))
				elif status == 'no_auth': kodi_utils.logger('DeadLight', simkl_service_string % ('Not Run. No Current SIMKL Account', next_update_string))
				else:
					if status in ('success', 'no account'):
						kodi_utils.logger('DeadLight', simkl_service_string % ('Success. %s' % simkl_success_line_dict[status], next_update_string))
					else:
						kodi_utils.logger('DeadLight', simkl_service_string % ('Success. No Changes Needed', next_update_string))
					if status == 'success' and get_setting('fenlight.simkl.refresh_widgets', 'true') == 'true':
						kodi_utils.run_plugin({'mode': 'kodi_refresh'})
			except Exception as e: kodi_utils.logger('DeadLight', simkl_service_string % ('Failed', 'The following Error Occured: %s' % str(e)))
			wait_for_abort(wait_time)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('DeadLight', 'SIMKLMonitor Service Finished')


# LOCAL PATCH 2026-08-29: AniList watchlist invalidation.
#
# Shorter than the Trakt/MDbList/SIMKL monitors because AniList has no sync endpoint to
# call -- it is never the primary watched-indicator provider, so there is nothing to pull
# into local tables. All this does is notice that the user changed their list somewhere
# else (the AniList app, the website) and drop the cached list pages so the next browse
# re-reads. One cheap Viewer query per interval.
class AniListMonitor:
	def run(self):
		kodi_utils.logger('DeadLight', 'AniListMonitor Service Starting')
		from apis.anilist_api import anilist_last_activity
		from caches.anilist_cache import clear_anilist_lists_cache
		from modules.settings import anilist_user_active, anilist_sync_interval
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				sync_interval, wait_time = anilist_sync_interval()
				next_update_string = update_string % sync_interval
				if not anilist_user_active():
					kodi_utils.logger('DeadLight', anilist_service_string % ('Not Run. No Current AniList Account', next_update_string))
				else:
					activity = anilist_last_activity()
					if activity is None:
						kodi_utils.logger('DeadLight', anilist_service_string % ('Failed. Error from AniList', next_update_string))
					elif activity != get_setting('fenlight.anilist.last_activity', ''):
						set_setting('anilist.last_activity', activity)
						clear_anilist_lists_cache()
						kodi_utils.logger('DeadLight', anilist_service_string % ('Success. AniList Lists Refreshed', next_update_string))
						if get_setting('fenlight.anilist.refresh_widgets', 'true') == 'true':
							kodi_utils.run_plugin({'mode': 'kodi_refresh'})
					else:
						kodi_utils.logger('DeadLight', anilist_service_string % ('Success. No Changes Needed', next_update_string))
			except Exception as e: kodi_utils.logger('DeadLight', anilist_service_string % ('Failed', 'The following Error Occured: %s' % str(e)))
			wait_for_abort(wait_time)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('DeadLight', 'AniListMonitor Service Finished')


# LOCAL PATCH 2026-07-29: anime-mappings DB bootstrap. Delays 8s at first
# call to let the boot sequence settle, then downloads if missing / stale.
# LOCAL PATCH 2026-08-10: Goldenfreddy Otaku-Mappings retired — its upstream
# froze 2026-05-31 and it resolved only 7 of 75 current-season items vs Fribb's
# 43, while its one unique field (mal_title) is now sourced live from AniList.
# Fribb anime-lists is the sole mapping download: mal/anilist → tmdb + season +
# episode_offset, all local (7.2 MB JSON, no per-lookup network).
def _bootstrap_anime_mappings():
	try:
		kodi_utils.sleep(8000)
		from caches import fribb_mappings
		fribb_mappings.download_mappings(silent=True)
	except Exception as e:
		kodi_utils.logger('fribb_mappings bootstrap', str(e))


class UpdateCheck:
	def run(self):
		if kodi_utils.get_property(firstrun_update_prop) == 'true': return
		kodi_utils.logger('DeadLight', 'UpdateCheck Service Starting')
		from modules.updater import update_check
		from modules.settings import update_action, update_delay
		end_pause = time() + update_delay()
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while time() < end_pause: wait_for_abort(1)
			while kodi_utils.get_property(pause_services_prop) == 'true' or is_playing(): wait_for_abort(1)
			update_check(update_action())
			break
		kodi_utils.set_property(firstrun_update_prop, 'true')
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('DeadLight', 'UpdateCheck Service Finished')

class WidgetRefresher:
	def run(self):
		kodi_utils.logger('DeadLight', 'WidgetRefresher Service Starting')
		from time import time
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, self.is_playing = monitor.waitForAbort, player.isPlayingVideo
		wait_for_abort(10)
		self.set_next_refresh(time())
		while not monitor.abortRequested():
			try:
				wait_for_abort(10)
				offset = int(get_setting('fenlight.widget_refresh_timer', '60'))
				if offset != self.offset:
					self.set_next_refresh(time())
					continue
				if self.condition_check(): continue
				if self.next_refresh < time():
					kodi_utils.logger('DeadLight', 'WidgetRefresher Service - Widgets Refreshed')
					kodi_utils.refresh_widgets()
					self.set_next_refresh(time())
			except: pass
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('DeadLight', 'WidgetRefresher Service Finished')

	def condition_check(self):
		if not self.external(): return True

		if self.next_refresh == None or self.is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': return True
		if kodi_utils.get_property('fenlight.window_loaded') == 'true': return True 
		try:
			window_stack = json.loads(kodi_utils.get_property('fenlight.window_stack'))
			if window_stack or window_stack == []: return True
		except: pass
		return False

	def set_next_refresh(self, _time):
		self.offset = int(get_setting('fenlight.widget_refresh_timer', '60'))
		if self.offset: self.next_refresh = _time + (self.offset*60)
		else: self.next_refresh = None

	def external(self):
		return 'plugin' not in kodi_utils.get_infolabel('Container.PluginName')

class AutoStart:
	def run(self):
		kodi_utils.logger('DeadLight', 'AutoStart Service Starting')
		from modules.settings import auto_start_fenlight
		if auto_start_fenlight(): kodi_utils.run_addon()
		return kodi_utils.logger('DeadLight', 'AutoStart Service Finished')

class AddonXMLCheck:
	def run(self):
		kodi_utils.logger('DeadLight', 'AddonXMLCheck Service Starting')
		from xml.dom.minidom import parse as mdParse
		self.addon_xml = kodi_utils.translate_path('special://home/addons/plugin.video.fenlight/addon.xml')
		self.root = mdParse(self.addon_xml)
		self.change_list = []
		self.check_property('reuse_language_invoker', 'reuselanguageinvoker')
		self.check_property('addon_icon_choice', 'icon')
		self.change_xml_file()
		return kodi_utils.logger('DeadLight', 'AddonXMLCheck Service Finished')

	def check_property(self, setting, tag_name):
		current_addon_setting = get_setting('fenlight.%s' % setting, None)
		if current_addon_setting is None: return
		tag_instance = self.root.getElementsByTagName(tag_name)[0].firstChild
		current_property = tag_instance.data
		if current_property != current_addon_setting:
			tag_instance.data = current_addon_setting
			self.change_list.append(tag_name)

	def change_xml_file(self):
		if not self.change_list: return
		if 'icon' in self.change_list: self.reassign_addon_icon()
		kodi_utils.notification('Refreshing Addon XML. Restarting Addons')
		new_xml = str(self.root.toxml()).replace('<?xml version="1.0" ?>', '')
		# Explicit UTF-8: open(...,'w') uses the platform codec, which on Windows is
		# cp1252 and TRUNCATES addon.xml to 0 bytes on any character outside it -
		# and this runs automatically, so Kodi would simply stop loading the add-on.
		import io as _io
		with _io.open(self.addon_xml, 'w', encoding='utf-8', newline='') as f: f.write(new_xml)
		kodi_utils.logger('DeadLight', 'AddonXMLCheck Service - Change Detected. Restarting Addons')
		kodi_utils.execute_builtin('ActivateWindow(Home)', True)
		kodi_utils.update_local_addons()
		kodi_utils.disable_enable_addon()

	def reassign_addon_icon(self):
		from indexers.dialogs import addon_icon_choice
		# LOCAL PATCH 2026-09-05: fallback must name a file that exists. It said
		# fenlight_icon_01.png, and after the artwork was renamed to deadlight_* a
		# fresh settings.db (no addon_icon_choice_name row yet) made this rewrite
		# <icon> to a missing file, leaving the add-on with no tile at all.
		addon_icon_choice({'set_icon': get_setting('addon_icon_choice_name', 'deadlight_icon_09.png')})

class FenLightMonitor(Monitor):
	def __init__ (self):
		Monitor.__init__(self)
		self.startServices()

	# LOCAL PATCH 2026-08-31: these handlers called a bare logger(), which this module never
	# imports -- it only imports kodi_utils. Any genuine startup failure therefore raised
	# NameError from inside its own except block, hiding the real error and propagating out
	# of __init__, so a transient service fault could take the whole service down.
	def startServices(self):
		try: SetAddonConstants().run()
		except Exception as e: kodi_utils.logger('SetAddonConstants', str(e))
		# LOCAL PATCH 2026-05-26: DatabaseMaintenance moved from synchronous boot path to a
		# background thread (with internal 15s delay inside .run()). Saves 100-500ms of boot.
		Thread(target=DatabaseMaintenance().run).start()
		try: SyncSettings().run()
		except Exception as e: kodi_utils.logger('SyncSettings', str(e))
		try: OnUpdateChanges().run()
		except Exception as e: kodi_utils.logger('OnUpdateChanges', str(e))
		try: AddonXMLCheck().run()
		except Exception as e: kodi_utils.logger('AddonXMLCheck', str(e))
		Thread(target=CustomWindowsPrepare().run).start()
		Thread(target=TraktMonitor().run).start()
		# LOCAL PATCH 2026-07-23: MDBList sync monitor runs alongside Trakt.
		Thread(target=MDBListMonitor().run).start()
		# LOCAL PATCH 2026-07-29: SIMKL sync monitor (4th watched-indicator provider).
		Thread(target=SIMKLMonitor().run).start()
		Thread(target=AniListMonitor().run).start()
		# LOCAL PATCH 2026-07-29: anime-mappings DB bootstrap (~6MB SQLite) — fetched
		# once on first run, refreshed every 30d. Used by AniList catalogs for
		# precise TMDb resolution.
		Thread(target=_bootstrap_anime_mappings).start()
		Thread(target=UpdateCheck().run).start()
		Thread(target=WidgetRefresher().run).start()
		try: AutoStart().run()
		except Exception as e: kodi_utils.logger('AutoStart', str(e))

	def onNotification(self, sender, method, data):
		if method in ('GUI.OnScreensaverActivated', 'System.OnSleep'):
			kodi_utils.set_property(pause_services_prop, 'true')
			kodi_utils.logger('OnNotificationActions', 'PAUSING Fen Light Services Due to Device Sleep')
		elif method in ('GUI.OnScreensaverDeactivated', 'System.OnWake'):
			kodi_utils.clear_property(pause_services_prop)
			kodi_utils.logger('OnNotificationActions', 'UNPAUSING Fen Light Services Due to Device Awake')

kodi_utils.logger('DeadLight', 'Main Monitor Service Starting')
FenLightMonitor().waitForAbort()
kodi_utils.logger('DeadLight', 'Main Monitor Service Finished')
