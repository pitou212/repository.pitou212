# -*- coding: utf-8 -*-
from modules.kodi_utils import notification
from modules import settings
# from modules.kodi_utils import logger


def drop_show(params):
	# LOCAL PATCH 2026-07-28 / 2026-07-29: route drop-show to the currently-
	# selected watched indicator. Priority: chosen indicator (Trakt/MDBList/SIMKL),
	# fall back to Trakt if not authorized on chosen.
	action = params.get('action', 'drop')
	media_id = params.get('media_id')
	if not media_id: return
	chosen = settings.watched_indicators()
	if chosen == 2 and settings.mdblist_user_active():
		from apis.mdblist_api import hide_unhide_mdbl_items
		mdbl_action = 'hide' if action == 'drop' else 'unhide'
		# LOCAL PATCH 2026-09-20: report what actually happened. hide_unhide_mdbl_items
		# used to return None on every path, so the only way to reach the failure
		# notification was an exception -- a request MDBList accepted but matched to
		# nothing still said 'Show Dropped'. Mirrors the SIMKL branch below.
		try: ok = hide_unhide_mdbl_items(mdbl_action, 'shows', media_id, 'dropped')
		except: ok = False
		if not ok: return notification('MDBList Unreachable', 3000)
		return notification('Show Dropped' if action == 'drop' else 'Show Undropped', 2500)
	if chosen == 3 and settings.simkl_user_active():
		# LOCAL PATCH 2026-07-29: SIMKL uses list-status semantics — dropping a show
		# means moving it to the 'dropped' status list; undropping means moving to
		# 'watching' (SIMKL has no "remove from dropped" endpoint per se — status
		# transition implicitly removes from the old status).
		from apis.simkl_api import simkl_add_to_list
		target_status = 'dropped' if action == 'drop' else 'watching'
		try:
			ok = simkl_add_to_list('shows', 'tmdb', int(media_id), target_status)
		except: ok = False
		if not ok: return notification('SIMKL Unreachable', 3000)
		try:
			from caches.simkl_cache import clear_simkl_lists_cache
			clear_simkl_lists_cache()
		except Exception: pass
		return notification('Show Dropped' if action == 'drop' else 'Show Undropped', 2500)
	if not settings.trakt_user_active():
		return notification('No Active Trakt / MDBList / SIMKL Account', 3500)
	from apis.trakt_api import hide_unhide_progress_items
	success = hide_unhide_progress_items({'action': action, 'media_type': 'shows', 'media_id': media_id, 'section': 'dropped'})
	if not success:
		return notification('Trakt Unreachable', 3000)
	notification('Show Dropped' if action == 'drop' else 'Show Undropped', 2500)
