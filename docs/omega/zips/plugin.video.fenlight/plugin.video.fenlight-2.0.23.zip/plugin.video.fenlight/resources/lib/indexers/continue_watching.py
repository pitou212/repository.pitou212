# -*- coding: utf-8 -*-
# LOCAL PATCH 2026-08-29: one Continue Watching widget across movies, TV and anime.
#
# Fen Light shipped four separate rows -- In Progress (movies), In Progress Episodes,
# Next Episodes, and their anime twins. This is all of it in a single list: everything
# you are part-way through, plus the next episode of every show you have not finished.
#
# Mixed-media rendering follows indexers/trakt_lists.py:build_trakt_list, which already
# has to put movies and episodes in one directory: each builder runs in its own thread and
# returns [(listitem, order), ...], the caller merges and sorts on `order`. Movies come
# from Movies(...).worker() with custom_order set; episodes come from build_single_episode
# via its existing return_results path.
#
# Ordering is assigned here rather than by either builder, because it has to interleave
# two sources: everything with a resume point first (movies and episodes together, most
# recent first), then the next-episode rows in whatever order the user's nextep settings
# produce. That way the widget opens on what you actually abandoned mid-play.

import sys
from threading import Thread

from indexers.episodes import build_single_episode, continue_watching_plan
from indexers.movies import Movies
from modules import kodi_utils, settings
from modules import watched_status as ws

# logger = kodi_utils.logger


def _sort_time(entry):
	"""Best-effort recency key. Providers write ISO8601, the local DB writes
	'YYYY-mm-dd HH:MM:SS'; both sort correctly as plain strings once the 'T' is gone, and
	anything missing sorts last rather than raising."""
	value = entry.get('last_played') or entry.get('date') or ''
	return str(value).replace('T', ' ')


def build_continue_watching(params=None):
	params = params or {}
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	item_list = []
	try:
		watched_indicators = settings.watched_indicators()
		hidden = set(ws.get_hidden_progress_items(watched_indicators) or [])

		# --- resume points -------------------------------------------------------
		# LOCAL PATCH 2026-09-04: pass the hidden set we just built. It used to be derived
		# three times per render -- here, inside continue_watching_plan, and again inside
		# get_in_progress_episodes -- which under SIMKL indicators was 12 simkl_list() reads.
		resume_eps, upcoming_eps = continue_watching_plan(watched_indicators, hidden)
		try:
			resume_movies = ws.get_in_progress_movies(None, None) or []
		except Exception:
			resume_movies = []
		resume_movies = [i for i in resume_movies if _int(i.get('media_id')) not in hidden]

		# Movies and episodes are ranked against each other so the widget reflects what you
		# last touched, not which builder produced it.
		mixed = [('movie', i) for i in resume_movies] + [('episode', i) for i in resume_eps]
		mixed.sort(key=lambda kv: _sort_time(kv[1]), reverse=True)

		movie_entries, episode_entries, order = [], [], 0
		for kind, entry in mixed:
			if kind == 'movie':
				tmdb_id = _int(entry.get('media_id'))
				if tmdb_id is not None: movie_entries.append((order, tmdb_id))
			else:
				entry['custom_order'] = order
				episode_entries.append(entry)
			order += 1
		for entry in upcoming_eps:
			entry['custom_order'] = order
			episode_entries.append(entry)
			order += 1

		if not movie_entries and not episode_entries:
			return _finish(handle, [], is_external)

		# --- build both kinds in parallel ----------------------------------------
		def _movies():
			try:
				if movie_entries:
					item_list.extend(Movies({'list': movie_entries, 'custom_order': 'true'}).worker())
			except Exception: pass

		def _episodes():
			try:
				if episode_entries:
					result = build_single_episode('episode.continue', dict(params, prepared=episode_entries))
					if result: item_list.extend(result)
			except Exception: pass

		threads = [Thread(target=_movies), Thread(target=_episodes)]
		[t.start() for t in threads]
		[t.join() for t in threads]
		item_list.sort(key=lambda k: k[1])
		_apply_anilist_covers(item_list, episode_entries, movie_entries)
	except Exception:
		pass
	return _finish(handle, item_list, is_external)


def _int(value):
	try: return int(value)
	except (TypeError, ValueError): return None


def _finish(handle, item_list, is_external):
	# Content type is 'videos' rather than 'movies'/'episodes': the list holds both, and
	# claiming either makes skins apply a layout half the rows do not fit.
	kodi_utils.add_items(handle, [i[0] for i in item_list])
	kodi_utils.set_content(handle, 'videos')
	kodi_utils.set_category(handle, 'Continue Watching')
	kodi_utils.end_directory(handle, cacheToDisc=False)
	kodi_utils.set_view_mode('view.episodes_single', 'episodes', is_external)


# LOCAL PATCH 2026-08-29: cour-accurate posters for the anime rows.
#
# Both builders render the TMDb SHOW poster, because Fribb maps every cour of a show to the
# same parent TMDb id. AniList keeps art per cour, so the two disagree wherever a show has
# more than one: Re:Zero's airing cour is entry 189046 "4th Season" with its own key visual,
# while TMDb 65942 still serves the season-1 poster. Same story for Mushoku Tensei, which is
# what prompted this.
#
# Batched deliberately. Resolving covers inside the per-item builder would fire one AniList
# request per row from inside a thread pool, and AniList allows 30 a minute -- a large list
# would be throttled instantly. One bulk call per load, cached 30 days, costs nothing after
# the first (~1ms warm for this list).
#
# WHETHER IT IS VISIBLE DEPENDS ON THE SKIN LAYOUT, and that is not an oversight. Arctic
# Fuse 3 resolves art through two chains (script-skinvariables-images-includes.xml):
#   Image_Poster    -> Art(poster) / Art(season.poster) / Art(tvshow.poster)   <- poster set here
#   Image_Landscape -> for DBType==episode, Art(thumb), the episode still      <- NOT set here
# So a Poster-layout widget shows the cour cover and a Landscape-layout one shows the still.
# Kept anyway because Continue Watching is MIXED media: its movie rows are genuine poster
# rows whatever the layout. This is also why Next Episodes and In Progress Episodes were
# deliberately NOT given the same treatment -- they are episodes only, so on a landscape
# layout the work would be entirely invisible.
#
# Do not "fix" this by also setting thumb. AF3's landscape chain guards with
# `!String.IsEqual(ListItem.Art(thumb), ListItem.Art(poster))` precisely to detect a
# portrait image masquerading as a still; setting thumb to a cover would defeat that
# fallback and break landscape layouts.
def _apply_anilist_covers(item_list, episode_entries, movie_entries):
	try:
		from apis.anilist_api import anilist_covers_bulk
		from caches import fribb_mappings
		from modules import settings
	except Exception:
		return
	# LOCAL PATCH 2026-09-04: gate before the Fribb index load, matching every other caller
	# (indexers/seasons.py, indexers/tvshows.py). This ran unconditionally, so the top Home
	# widget paid ~124 ms parsing 7.5 MB of anime mappings even with no anime in the list and
	# no AniList account configured. NOTE this only spares users without AniList: with an
	# account set up the cour lookup genuinely needs the index, and the plan entries carry no
	# TMDb keywords to gate on the way tvshows.py can. The slim sidecar is the fix for that.
	if not settings.anilist_user_active() or not fribb_mappings.is_available(): return
	wanted = {}          # position -> anilist id
	for entry in episode_entries:
		try:
			tmdb = int(entry['media_ids']['tmdb'])
			season, episode = int(entry['season']), int(entry['episode'])
		except (KeyError, TypeError, ValueError): continue
		# For a next-episode row the plan holds the episode you LAST WATCHED, while the row
		# renders the one after it -- and that can be the first of the following cour
		# (Frieren S01E28 is cour 154587, S01E29 is cour 182255). Prefer the lookahead when
		# it resolves so the poster matches the episode actually shown; resume rows name
		# their own episode, so both lookups agree and the fallback is exact.
		cour = None
		if entry.get('is_next'):
			cour = fribb_mappings.find_cour_by_tmdb_coords(tmdb, season, episode + 1)
		if not cour:
			cour = fribb_mappings.find_cour_by_tmdb_coords(tmdb, season, episode)
		anilist_id = (cour or {}).get('anilist')
		if anilist_id: wanted[entry.get('custom_order')] = anilist_id
	for position, tmdb_id in movie_entries:
		try: anilist_id = fribb_mappings.anilist_for_tmdb_movie(tmdb_id)
		except Exception: anilist_id = None
		if anilist_id: wanted[position] = anilist_id
	if not wanted: return
	movie_positions = {position for position, _ in movie_entries}
	covers = anilist_covers_bulk(set(wanted.values())) or {}
	for entry, position in item_list:
		cover = covers.get(wanted.get(position))
		if not cover: continue
		# thumb is the EPISODE STILL on an episode row -- landscape, and what widgets show
		# in list layouts. Replacing it with a portrait cover would wreck those, so episodes
		# get poster art only. A movie row's thumb IS its poster, so it is safe there.
		art = {'poster': cover}   # LOCAL PATCH 2026-09-14: season./tvshow. keys dropped, see the note at _art in indexers/episodes.py
		if position in movie_positions: art = {'poster': cover, 'thumb': cover}
		try: entry[1].setArt(art)
		except Exception: pass
