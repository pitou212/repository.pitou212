# -*- coding: utf-8 -*-
import json
from caches.debrid_cache import debrid_cache
from apis.real_debrid_api import RealDebridAPI
from apis.premiumize_api import PremiumizeAPI
from apis.alldebrid_api import AllDebridAPI
from apis.torbox_api import TorBoxAPI
from modules.source_utils import get_external_cache_status
from modules.kodi_utils import show_busy_dialog, hide_busy_dialog, notification
from modules.settings import enabled_debrids_check
# from modules.kodi_utils import logger

def debrid_enabled():
	return [
	i[0] for i in [('Real-Debrid', 'rd'), ('Premiumize.me', 'pm'), ('AllDebrid', 'ad'), ('TorBox', 'tb')] if enabled_debrids_check(i[1])]

def debrid_for_ext_cache_check(enabled_debrid=None):
	if not enabled_debrid: enabled_debrid = debrid_enabled()
	return any(i in ['Real-Debrid', 'AllDebrid'] for i in enabled_debrid)

def manual_add_magnet_to_cloud(params):
	show_busy_dialog()
	debrid_list_modules = [('Real-Debrid', RealDebridAPI), ('Premiumize.me', PremiumizeAPI), ('AllDebrid', AllDebridAPI), ('TorBox', TorBoxAPI)]
	function = [i[1] for i in debrid_list_modules if i[0] == params['provider']][0]
	result = function().create_transfer(params['magnet_url'])
	function().clear_cache()
	hide_busy_dialog()
	if result == 'failed': notification('Failed')
	else: notification('Success')

def query_local_cache(hash_list):
	return debrid_cache.get_many(hash_list) or []

# LOCAL PATCH 2026-09-22: the per-file listing recorded alongside a cached verdict.
# Read from the database rather than returned by the check on purpose. Only UNCHECKED
# hashes are ever sent to the service (see cached_check), so on a re-scrape within the
# 24h window most hashes never reach TorBox at all -- and a listing that came back only
# from a live call would make a pack's size change between two scrapes of the same
# episode. Going through the table makes both paths answer identically.
def query_local_cache_files(hash_list, debrid='tb'):
	return debrid_cache.get_files_many(hash_list, debrid) or {}

def add_to_local_cache(hash_list, debrid, expires=24):
	debrid_cache.set_many(hash_list, debrid, expires)

def cached_check(hash_list, cached_hashes, debrid):
	cached_list = [i[0] for i in cached_hashes if i[1] == debrid and i[2] == 'True']
	unchecked_list = [i for i in hash_list if not any([h for h in cached_hashes if h[0] == i and h[1] == debrid])]
	return cached_list, unchecked_list

def RD_check(hash_list, cached_hashes, data, active_debrid):
	expires = 24
	cached_hashes, unchecked_hashes = cached_check(hash_list, cached_hashes, 'rd')
	if unchecked_hashes:
		results = get_external_cache_status('Real-Debrid', unchecked_hashes, data, active_debrid)
		if results:
			cached_append = cached_hashes.append
			process_list = []
			process_append = process_list.append
			try:
				for h in unchecked_hashes:
					cached = 'False'
					if h in results:
						cached_append(h)
						cached = 'True'
					process_append((h, cached))
			except:
				for i in unchecked_hashes: process_append((i, 'False'))
		# LOCAL PATCH 2026-08-26 (Red Light 2.3.2/2.3.5 port): a failed check is NOT
		# evidence that the hashes are uncached. This branch used to record every
		# unchecked hash as 'False' and persist that verdict for 2h, so one debrid
		# timeout or empty reply made every source look uncached and kept it that way
		# across later scrapes. Write nothing instead -- the hashes stay unknown and
		# get re-checked next time. (Red Light additionally surfaces the provider as
		# UNCHECKED in the results list; that is a UI change and not ported here.)
		else: process_list, expires = [], 2
		add_to_local_cache(process_list, 'rd', expires)
	return cached_hashes

def AD_check(hash_list, cached_hashes, data, active_debrid):
	# LOCAL PATCH 2026-07-10 (port of Red Light 1.7.3): AllDebrid retired the
	# magnet/instant API in 2025. Mediafusion cache-probes for AD (via
	# get_external_cache_status) are slow, unreliable behind VPN, and often
	# return NO_SERVER or hang for the full timeout. Skip the external check
	# entirely and return every hash as "unchecked" — AD sources still play
	# (they'll be resolved on-demand at play time), they just don't get a
	# pre-play cache badge. Behaves the same as external_cache_check=False.
	# Saves 2-5s per scrape when AllDebrid is an active debrid.
	return cached_hashes

def PM_check(hash_list, cached_hashes):
	expires = 24
	cached_hashes, unchecked_hashes = cached_check(hash_list, cached_hashes, 'pm')
	if unchecked_hashes:
		results = PremiumizeAPI().check_cache(unchecked_hashes)
		if results:
			cached_append = cached_hashes.append
			process_list = []
			process_append = process_list.append
			try:
				results = results['response']
				for c, h in enumerate(unchecked_hashes):
					cached = 'False'
					try:
						if results[c] is True:
							cached_append(h)
							cached = 'True'
					except: pass
					process_append((h, cached))
			except:
				for i in unchecked_hashes: process_append((i, 'False'))
		# LOCAL PATCH 2026-08-26 (Red Light 2.3.2/2.3.5 port): a failed check is NOT
		# evidence that the hashes are uncached. This branch used to record every
		# unchecked hash as 'False' and persist that verdict for 2h, so one debrid
		# timeout or empty reply made every source look uncached and kept it that way
		# across later scrapes. Write nothing instead -- the hashes stay unknown and
		# get re-checked next time. (Red Light additionally surfaces the provider as
		# UNCHECKED in the results list; that is a UI change and not ported here.)
		else: process_list, expires = [], 2
		add_to_local_cache(process_list, 'pm', expires)
	return cached_hashes

def TB_check(hash_list, cached_hashes):
	expires = 24
	cached_hashes, unchecked_hashes = cached_check(hash_list, cached_hashes, 'tb')
	if unchecked_hashes:
		results = TorBoxAPI().check_cache(unchecked_hashes)
		if results:
			cached_append = cached_hashes.append
			process_list = []
			process_append = process_list.append
			try:
				data = results['data']
				# LOCAL PATCH 2026-09-22: keep the per-file listing, trimmed to the two fields anything
				# downstream uses -- short_name (what TorBox's own resolver matches on) and size. The
				# raw entry also carries id and opensubtitles_hash, which would roughly double the blob
				# for no consumer. Absent for an uncached hash, since it is not in the response at all.
				file_map = {}
				for i in data:
					try:
						_files = [{'name': f.get('short_name') or f.get('name'), 'size': f.get('size')}
							for f in (i.get('files') or []) if f.get('size')]
						if _files: file_map[str(i['hash']).lower()] = json.dumps(_files, separators=(',', ':'))
					except Exception: pass
				results = [i['hash'] for i in data]
				for h in unchecked_hashes:
					cached = 'False'
					if h in results:
						cached_append(h)
						cached = 'True'
					process_append((h, cached, file_map.get(str(h).lower())))
			except:
				for i in unchecked_hashes: process_append((i, 'False'))
		# LOCAL PATCH 2026-08-26 (Red Light 2.3.2/2.3.5 port): a failed check is NOT
		# evidence that the hashes are uncached. This branch used to record every
		# unchecked hash as 'False' and persist that verdict for 2h, so one debrid
		# timeout or empty reply made every source look uncached and kept it that way
		# across later scrapes. Write nothing instead -- the hashes stay unknown and
		# get re-checked next time. (Red Light additionally surfaces the provider as
		# UNCHECKED in the results list; that is a UI change and not ported here.)
		else: process_list, expires = [], 2
		add_to_local_cache(process_list, 'tb', expires)
	return cached_hashes
