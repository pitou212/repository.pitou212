#!/usr/bin/env python3
"""Validate the settings screen markup and print its heading map.

    python tools/check_settings_xml.py            # map + checks
    python tools/check_settings_xml.py --quiet    # checks only, for a commit gate

Run it before AND after moving settings between sections, and diff the two maps.
That diff is the point of this tool. Two things keep going wrong with this file,
and neither is visible until Kodi renders the window:

  1. The file stops being well-formed XML, and Kodi fails to build the settings
     window at all. Easy to cause by accident: a literal '--' is illegal inside an
     XML comment, so writing 'foo -- bar' in a LOCAL PATCH note breaks the file
     while looking entirely ordinary in a diff. (Hit on 2026-09-20.)

  2. A row ends up under the wrong heading. There is no grouping construct here: a
     row belongs to whichever separator precedes it in document order within the
     same Container(2000).HasFocus(N) section. Moving a block therefore re-parents
     whatever followed it. The TVDB key landed under the Fanart.tv heading this way
     on 2026-09-16; 'Exclude Specials from Show Progress' nearly landed under 'Next
     Episodes' on 2026-09-20.

Note that (2) CANNOT be detected by a rule. A row under the wrong heading still has
a heading, so it is structurally identical to a correct one. Only a human reading
the map can see that 'TVDB API Key' has no business under 'Fanart.tv' -- which is
why this prints the map rather than pretending to validate it.

Rows appearing before a section's first separator are correct, not orphans: the tab
title is their heading. See the 2026-08-05 note at the top of the General section.

Exits non-zero only for things that are unambiguously broken: malformed XML, and a
heading left with no rows under it (what a moved-out block leaves behind).
"""
import io
import os
import sys
import xml.etree.ElementTree as ET

DEFAULT = os.path.join('resources', 'skins', 'Default', '1080i', 'settings_manager.xml')
SECTIONS = [('10', 'General'), ('20', 'Features'), ('30', 'Content'), ('40', 'Interface'),
            ('50', 'Accounts'), ('60', 'Debrid'), ('70', 'Results'), ('80', 'Playback'),
            ('90', 'Scrapers')]
NAMES = dict(SECTIONS)
TAB_TITLE = '(tab title)'


def between(text, start, end):
    """Text between the first `start` and the next `end`, or None."""
    i = text.find(start)
    if i == -1:
        return None
    i += len(start)
    j = text.find(end, i)
    return None if j == -1 else text[i:j]


def read_items(path):
    """Yield (line_no, section, is_separator, label) for each settings row.

    Rows carrying no HasFocus condition are the category list itself, not settings.
    """
    lines = io.open(path, encoding='utf-8').read().split(chr(10))
    block = start = None
    for n, line in enumerate(lines, 1):
        stripped = line.strip()
        if stripped.startswith('<item'):
            block, start = [line], n
        elif block is not None:
            block.append(line)
            if stripped.startswith('</item>'):
                text = chr(10).join(block)
                block = None
                section = between(text, 'HasFocus(', ')')
                if section is not None:
                    label = between(text, 'setting_label">', '<') or '(unlabelled)'
                    yield start, section, 'setting_type">separator<' in text, label


def build(path):
    """section -> list of [heading_label, heading_line, [(line, label), ...]]"""
    tree = {}
    for line_no, section, is_sep, label in read_items(path):
        groups = tree.setdefault(section, [])
        if is_sep:
            groups.append([label, line_no, []])
        else:
            if not groups:
                groups.append([TAB_TITLE, line_no, []])
            groups[-1][2].append((line_no, label))
    return tree


def main(argv):
    path = DEFAULT
    quiet = False
    for arg in argv:
        if arg == '--quiet':
            quiet = True
        else:
            path = arg

    if not os.path.isfile(path):
        print('not found: %s' % path)
        return 2

    try:
        ET.parse(path)
    except ET.ParseError as err:
        print('FAIL  not well-formed XML: %s' % err)
        print("      a literal '--' inside an <!-- comment --> is the usual cause;")
        print('      the rest of this file uses an em dash for that.')
        return 1

    tree = build(path)
    rows = sum(len(g[2]) for groups in tree.values() for g in groups)

    empty = []
    for section, groups in tree.items():
        for label, line_no, members in groups:
            if not members:
                empty.append((NAMES.get(section, section), line_no, label))

    if not quiet:
        for section, name in SECTIONS:
            groups = tree.get(section)
            if not groups:
                continue
            print(name)
            for label, line_no, members in groups:
                mark = '  <-- EMPTY' if not members else ''
                print('  %-5d %s%s' % (line_no, label, mark))
                for member_line, member_label in members:
                    print('    %-5d   %s' % (member_line, member_label))
            print('')

    for name, line_no, label in sorted(empty):
        print('FAIL  %-9s line %-5d heading %r has no rows under it' % (name, line_no, label))
    if empty:
        print('%d heading(s) left empty -- a moved block usually leaves its separator behind.'
              % len(empty))
        return 1

    print('OK    %s' % path)
    print('      well-formed, %d rows under %d headings across %d sections'
          % (rows, sum(len(g) for g in tree.values()), len(tree)))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
