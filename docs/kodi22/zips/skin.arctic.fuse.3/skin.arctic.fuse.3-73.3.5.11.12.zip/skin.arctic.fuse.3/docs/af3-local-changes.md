# Local AF3 changes

## Navigation and artwork indicators

Baseline commit: `3bb6035` (Refine AF3 navigation and artwork indicators).

- Horizontal navigation offers **Text + icons** and **Icons** in the same left-aligned capsule. Vertical navigation remains available.
- Search stays icon-only. Hiding Search removes its extra width. Add-ons and Settings use optically balanced icons, with a small focus outline for utility controls. The current section uses a plain light pill.
- The top bar and the clock and weather capsule use matching translucent charcoal textures. The temperature sits beside a weather icon when available. The capsule contracts to the clock when weather is disabled.
- Colour presets preserve the selected menu style. Focus accents and progress use the configured accent colour.
- Artwork uses a small lift and a shared outside focus treatment. Continue Watching adds a play or open icon when the item supplies the corresponding action.
- Inset is the artwork progress style. Watched and unwatched badges continue to use the existing indicator settings. Old style controls, unused indicator code, and superseded capsule textures were removed.
- Shortcut templates pass the top-bar icon options through to the generated hubs.
- **Rebuild needed on every device:** the generator template changed (`shortcuts/generator/data/parts/hub_include.xmltemplate`,
  `shortcuts/generator/data/base/home_hubs.xml`: `topbar_icon` / `topbar_label`). skinvariables keeps the old generated include
  until it is forced: run `RunScript(script.skinvariables,action=buildtemplate,force=True)` once after installing (the PC was
  rebuilt 2026-11-22). Without it the right-side top-bar cells all show the Settings gear and label.
  Still true for a generator TEMPLATE change: skinvariables' hash covers `skinvariables-generator.json`, the call's parameters
  and the generated file itself, not the `generator/data/` parts.
- **Home-load template build restored (2026-11-28):** upstream's `Action_BuildShortcuts_OnLoad` (Home.xml + Includes_Actions.xml,
  identical to upstream) was deleted by accident on 2026-11-11 (`b89618df`, the TMDb Helper fold pass took the line below
  `TMDbHelper.UseLocalWindowIDs`), and its definition by the next day's dead-code pass (`78d49323`, no callers left). Without it
  nothing built the generated includes except leaving the menu editor: an add-on update (which wipes them) left every hub empty,
  and the Setup Wizard's presets / Finish and the ratings migration (they only stamp `Shortcuts.RebuildDateTime`) showed late.
  With it, the first Home load rebuilds a wiped or re-stamped file (PC: 2.58 s + one skin reload) and skips an unchanged one.
  Its hubs migration only writes a menu file that does not exist (skinvariables `MenuTemplate.write`), so edited hubs are safe.
- **Dialog progress bars (2026-11-28):** upstream draws the progress dialog's bar (`Dialog_DialogConfirm.xml` id 20) under the
  faded Cancel button in the accent colour. Soft forces the accent to white (white slab, label hidden), and the 2026-11-26
  `plate=true` glass (alpha 62) made the bar disappear. Both progress controls (also `Dialog_Lists.xml` achievements) now take
  `ColorProgressFill` (Includes_Colors): 60 % white under Soft, the focus colour otherwise. `plate=true` is for focus PLATES
  behind text, never for a progress fill.
- Hub icons follow hub SLOTS, not hub content (1101 movies, 1102 shows, 1103 anime in `Includes_Home.xml`; 1108 add-ons in the
  generator rule). Re-ordering hubs needs those maps changed too.

## Shared UI and XML organization

- Home, standard window headers, Search, and the playback seek overlay use the same clock and weather component. Search also uses the matching charcoal input backing and rounded suggestion focus.
- Skin Settings, Kodi Settings, and list dialogs share rounded focus plates. Settings panels use neutral charcoal.
- Focused artwork keeps the lift, border, and shadow. The white sheen layer and its unused texture were removed.
- The root include manifest loads the smaller settings, layout, information, and OSD XML files. The moved definitions retain their names and order, so callers and Kodi control IDs continue to work.
- The expanded playback overlay darkens the lower part of the picture so controls and timing remain legible on bright scenes.
- The startup splash skips its final half-second hold when the user has disabled waiting for widgets. The existing wait behavior still applies when enabled.

See [the layout and performance plan](af3-unification.md) for file ownership and verification.

## Focus styles across AF3

- Added **Focus style** to Skin Settings → Appearance. The existing setup-wizard toggle still controls the same setting.
- Rounded focus plates now support the Solid fill and the Outlined ring. The shared styles cover Settings, native dialog actions, selection and context rows, File Manager lists, and Search suggestions.
- Focused labels and icons get the foreground colour for their mode. The sidebar marks the selected category with a subdued fill when focus moves into the file list.
- Kodi checks covered the Appearance switch, confirmation, selection, context menus, and File Manager. The Home menu's active pill stays plain.

## Artwork progress settings

- Views → Indicators exposes an Artwork progress toggle that controls the inset bars on artwork. Watched and episode-count badges remain separate.
- The colour picker previews the real badge and inset bar. The bar uses the saved artwork progress colour, or the preset accent if a progress colour has not been set. The bar stays solid in both focus modes.
- Verified the toggle and colour-picker preview in Kodi and restored the original progress setting after testing.

## Keyboard, details, library and playback

- The on-screen keyboard shares Search's charcoal input field. IME suggestions now use the correct visibility condition.
- Weather shows the clock in its header and separates the location and provider attribution from the forecast. The current temperature stays on the first forecast tile.
- Movie, show and episode details use the shared action focus styles. Episode metadata omits the leading separator when duration is the first available field.
- Basic library rows use the rounded focus pill. Expanded rows use a rounded rectangle with the Solid fill or a transparent interior in Outlined mode. Progress and focused labels use matching contrast.
- Audio and subtitle panels use the shared charcoal backing and focus styles. Stream metadata appears on the same row as the track name. The chapter list uses the **Chapters and bookmarks** heading when the video has chapters.

## Navigation and Options follow-up

- **Text + icons** shows the icon beside the current section and bold labels for the other sections. The bar stays left aligned with Search at the start. Utility tooltips appear while their controls have focus.
- Shared focus plates now use small corners, soft fills and light foregrounds. **Outlined** adds a subdued border. Artwork retains its lift with a softer edge.
- Options tiles, list entries and the footer follow the selected theme and focus style. The footer uses the theme focus plate (2026-11-23, replacing the original circle, whose 56 px caption cut "Reload Skin").
- **Skin Settings → Interface → Skin theme** switches between **Skin default** and **Soft**. Startup respects the saved Kodi theme selection. **Appearance → Focus style** controls the fill or outline within the selected theme.
- The AF3 theme selector preserves the font selected in Kodi's Interface settings. Weather radar labels and codec badges use that same font family.
- The menu bar's active section and focused utility icons follow the selected theme and focus style.

## Vertical navigation and settings contrast

- The vertical menu uses brighter inactive icons and a full-brightness current-hub icon. The accent bar sits inside the rail, and the focused icon uses the shared header highlight and its matching foreground.
- The Setup Wizard step rail uses the shared focus foreground. The Hubs sidebar and settings rows with icons use the shared settings focus plate.
- Kodi verification covered the Wizard's Welcome step, the focused Hubs Layout row, and the vertical menu's outline and current-hub marker in the Soft theme.

## Session 69 (2026-11-23): suggestions, watched dim, tray, Soft colours

- **Search suggestions** also show in **Standard** search mode (were Combined only); Wall keeps its own layout.
- **Dim watched artwork** (Skin Settings → Indicators, on by default, follows the Watched switch): a black tint over the picture of anything the check badge calls watched, in Poster, Square, Landscape and Flyer cards, under the badge and progress bar (`Object_WatchedTint`).
- Kodi blends a translucent `colordiffuse` additively on Windows (a 55% red added +140 to R and left G/B unchanged), so a black tint coloured that way adds nothing. Dims now bake the alpha into the texture: `extras/alpha/white_20/50/55.png`, coloured opaque black. The weather, OSD stream dialog, startup and music visualisation dims were converted too. The tint image also needs its size spelled out; with none it drew nothing.
- **Options tray** footer: the theme focus plate, 96 × 84, with a 92 px caption. The idle date tile reads "Mon" / "23 Nov" (was cut to "Mon…" / "23 No…").
- **Soft ignores the colour scheme**: highlight, focus plate and selected-text colours are the default white look under Soft (`Includes_Colors.xml`); a scheme still sets the window and dialog backgrounds.
- Verified in Kodi (Windows): suggestions, tray, watched dim (red probes plus pixel measurements, then the user's eyes).

## Session 70 (2026-11-23): one pill system for the artwork indicators

- Every artwork indicator is now the same pill as the watched badge: 30 high, the `pill30` backing and rim, a 22 px white glyph or `font_hint_bold` caps. **Top right** is your state, one badge by priority: playing, recording / timer, **Dropped** (new), unwatched count, watched, library, collection. **Top left** is the release pill with a colour dot, one at a time: **PREMIERE / FINALE** (until the episode is watched), else **NEW**.
- **NEW** reads DeadLight's `deadlight.new_episode`: aired in the last 7 days and unwatched (a show tile uses its latest aired episode). Skin Settings → Indicators → Artwork Overlay → **New episode**, on by default (`Indicator.DisableNewEpisode`). Green dot.
- **Dropped** reads DeadLight's `deadlight.dropped` (the show is on the Trakt / MDBList / SIMKL dropped list), shown with a ban icon (`media/indicator/dropped.png`, sized to the check mark's proportions), list views too. Skin Settings → Indicators → **Dropped**, on by default (`Indicator.DisableDropped`).
- PREMIERE / FINALE keeps one pill per episode type, so each keeps its colour picker colour (`ColorBanner_*`) as the dot; a season premiere follows the highlight colour.
- Kodi has no auto width inside list layouts, so each release pill has a fixed width that fits its label in every font set (NEW 80, FINALE 98, PREMIERE 122).
- The dot is `media/indicator/dot-full.png`, a circle filling its canvas: `indicator/dot.png` holds a 6 px dot in 24 px and drew as a 3 px speck.
- **Removed:** the full-width premiere / finale and video-version banners over the title art (`Object_BannerOverlay`, `Object_EpisodeTypeBanner`, `Object_MovieVersionBanner`), the status badge's slide-down under them, the video-version indicator and its colours, the Trakt watchlist / favourites overlays (only TMDb Helper sets `watchlist_rank` / `favorites_rank`; DeadLight never does) and the Live TV guide's catch-up indicator (recordings and timers keep theirs).
- Verified in Kodi (Windows): NEW on Continue Watching (dot measured 14 px at 1800p = 8 skin px), PREMIERE next to the check mark, Dropped on the Dropped Shows list (user).
- **Colour picker under Soft:** the Highlight swatch shows the colour picked (Soft draws white whatever is picked), and the Preview heading reads "Preview · unused in Soft" while Highlight is being picked (the half-width swatch label had no room for the note). Verified in Kodi.

## Re-anchored on upstream 73.3.5.2 (session 71, 2026-11-25)

The patch layer moved from upstream 73.3.4.18 onto signde/omega 73.3.5.2 (88 upstream commits). Every decision is in the
re-anchor report (`af3-reanchor-73.3.5.2.report/decisions.log` on the PC). Rules used:

- **No TMDb Helper features.** Upstream's new TMDb Helper work (SkinVariables multisearch replacing the Search hub, the
  crew / person details view, person gallery, watched-on statistics, TMDb Helper blur and container properties) is not
  taken. Names upstream code still refers to are constant stubs (`Exp_Hubs_Window_IsMultiSearch`, `Exp_TMDbHelper_IsData`
  = false; `MultiSearch_OnBack`, `DialogInfo_PersonImageContent` empty).
- **The Search hub (1105) stays.** Upstream 889f966's multisearch rewiring was undone in files that merged cleanly (menu
  item, click handling, vertical icon, top-menu overlay, header label, no-results item, generator template), the fork's
  search generator files and `Dialog_DialogShortcuts.xml` were kept.
- **Skin Settings stay hand-written** (`Includes_SkinSettings_*`); upstream's SkinVariables JSON template (6acb588) is not
  used.
- **Split include files kept:** upstream's edits to `Includes_Info` / `Includes_OSD` / `Includes_Layouts` were ported into
  the split files (incl. the fake-textbox removal, `Layout_Poster`'s `main_artwork` and the `Layout_MediaList` rewrite).
- **Strings:** both sides' strings kept (none deleted); the fork's text wins where both changed an id.
- **addon.xml:** upstream 73.3.5.2 plus the fork's imports (no TMDb Helper, `script.af3.helper`, TinyPPI optional); the
  Surrealist background pack is not a hard dependency.
- A Kodi 22 (piers) build of the same layer exists on branch `reanchor-73.3.5.2-piers` (not published: one build serves
  Kodi 21 and 22).

## Session 74 (2026-11-26): re-anchored on jurialmunkey 3.5.11

- The fork now follows jurialmunkey directly (rules: [upstream-policy.md](upstream-policy.md)); signde's p3i / CoreELEC /
  TinyPPI work is carried in our layer. Taken from upstream: OSD stream cards, slider ruler, EDL markers, ring seek nib
  (in the accent colour), weather redesign (trend / UV / radar pages, weather hub widget), info-dialog gallery in the
  artwork panel (local artwork only), viewtype selector and icon styles, Simple hub layout, FlixArt options, the Anime
  background style, info-tag pills (opt-in) and the 3D tag (both in Skin Settings > Details), Icon style (Views).
- Kept ours: ratings (af3.helper), Search hub, Skin Settings, background picker, one-pill indicators, OSD pills.
- 38 string ids collided with signde's process-info labels; ours moved to 32900-32937.
- Font sets: our four sets' plot line spacing is calibrated to Default's line height (Font.xml).
- Home plot box 119 (was 112: it cut the third line's descenders); info dialog buttons at 412 (clear of our ratings row);
  weather trend columns follow the aspect ratio (constants per 16:10 / 3:2 / 4:3).
