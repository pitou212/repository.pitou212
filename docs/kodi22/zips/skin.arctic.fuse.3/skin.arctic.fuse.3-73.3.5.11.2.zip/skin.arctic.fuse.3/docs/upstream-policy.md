# Following upstream

This fork follows **jurialmunkey/skin.arctic.fuse.3** directly (since 3.5.11, 2026-11-26).

- `piers` is his trunk (Kodi 22). Our `piers` = his release + our patch layer, published to `kodi22`.
- His `omega` is `piers` plus one commit that lowers `xbmc.gui`. Our `main` = our `piers` + one "Kodi 21 backport"
  commit (`xbmc.gui` 5.17.0, the optional `script.signde.tinyppi` import), published to `kodi21`.
- Version: `73.` + his version (73.3.5.11 = his 3.5.11) + `.N` patch commits over the vendor branches `upstream` /
  `upstream-piers`, which point at the release we are anchored on.

## When

The weekly **Upstream drift** workflow keeps one issue (label `upstream-drift`) with the commits we are behind, the
files a merge would conflict on and the commits that touch TMDb Helper. It merges nothing. Re-anchor at one of his
`:bookmark: Version bump` commits, not at every commit.

## How

Re-anchor in a separate worktree, never on `main`: old base = the release we are on, ours = `main`, new = the bump
commit. Tools: `addon_patches\harness\session74\` (`af3_reanchor_wt.sh`, `show_hunks.py`, `set_hunk.py`,
`resolve_hunks.py`, `port_split_hunks.py`, `po_merge3.py`, `str_collisions.py`, `af3_tree_check.py`, `color_check.py`,
`param_defaults.py`, `reach_diff.py`, `font_calibrate.py --check`). Keep the old branches as
`main-pre-reanchor-<version>` / `piers-pre-reanchor-<version>`. Test in Kodi after a forced generator rebuild
(`RunScript(script.skinvariables,action=buildtemplate,force=True)`) before committing.

## Rules (what each conflict is judged by)

1. **TMDb Helper features are not taken** (person bios, online fanart, Trakt comments, multisearch, watched-on
   statistics, upstream's ratings system built on TMDb Helper). Dead upstream parameters that only fed them are removed.
2. **Our Skin Settings stay hand-written**; upstream's new SkinVariables settings are ported by hand.
3. Upstream's edits to `Includes_Info` / `Includes_Layouts` / `Includes_OSD` are **ported into our split files**.
4. **Strings: union.** Ids added on both sides collide: ours move (32900+ since 3.5.11), upstream keeps its ids.
5. **Upstream improvements are taken unless they undo one of our features** (Soft theme and focus plates, one-pill
   artwork indicators, OSD pills and C+ layout, our background picker, our Search hub, af3.helper ratings, the
   DeadLight next-aired labels, p3i / CoreELEC / TinyPPI).
6. After merging: no undefined names, colours or `$PARAM[listitem]` defaults (the checks above), and every font set's
   plot line height equal to Default's (`font_calibrate.py --check`) -- AF3's fixed text boxes are sized for Default.

`skin.arctic.fuse.3`'s dependencies are mirrored into repository.pitou212 (`tools/mirror_deps.py`): Kodi looks a
dependency up only in the repository the add-on came from.
